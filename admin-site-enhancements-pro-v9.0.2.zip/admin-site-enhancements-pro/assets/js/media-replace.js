(function( $ ) {
	'use strict';

	$(document).ready( function() {

		// Place the Replace Media section after the side metaboxes
		$('#media-replace-div').appendTo('#postbox-container-1');
		
	});

})( jQuery );

// let asenhaMRVars = asenhaMR;

// Open media modal on clicking Select New Media File button. 
// This is set with onclick="replaceMedia('mime/type')" on the button HTML
function replaceMedia(originalAttachmentId,oldImageMimeType) {
	if ( oldImageMimeType ) {
		// There's a mime type defined. Do nothing.
	} else {
		// We're in the grid view of an image. Get the mime type form the file info in DOM.
		if ( jQuery('.details .file-type').length ) {
			var oldImageMimeTypeFromDom = jQuery('.details .file-type').html();		
		}
		// Sometimes .file-type div is not there, and instead, a second .filename div is used to display file type info
		else if ( jQuery('.details .filename:nth-child(2)').length ) {
			var oldImageMimeTypeFromDom = jQuery('.details .filename:nth-child(2)').html();		
		}
		// Replace '<strong>File type:</strong>' in any language with empty string
		oldImageMimeTypeFromDom = oldImageMimeTypeFromDom.replace(/<strong>(.*?)<\/strong>/, '');
		// Replace one blank spacing with an empty space / no space
		oldImageMimeType = oldImageMimeTypeFromDom.replace(' ', '');
	}

	// https://codex.wordpress.org/Javascript_Reference/wp.media
	// https://github.com/ericandrewlewis/wp-media-javascript-guide

	// Instantiate the media frame
	mediaFrame = wp.media({
		title: mediaReplace.selectMediaText,
		button: {
			text: mediaReplace.performReplacementText
		},
		multiple: false // Enable/disable multiple select
	});
	

	// Open the media dialog and store it in a variable
	var mediaFrameEl = jQuery(mediaFrame.open().el);

	// Open the "Upload files" tab on load
	mediaFrameEl.find('#menu-item-upload').click();
	
	// Function to check and display mime type warning/notice
	function checkMimeType() {
		var selection = mediaFrame.state().get('selection');
		
		// Check if there's a selection
		if (!selection || selection.length === 0) {
			return;
		}
		
		var selectedAttachment = selection.first().toJSON();
		var selectedAttachmentMimeType = selectedAttachment.mime;
		
		// Always remove all existing notices first to prevent duplicates
		jQuery('.media-frame-toolbar .media-toolbar-primary .mime-type-warning').remove();
		/*! <fs_premium_only> */
		jQuery('.media-frame-toolbar .media-toolbar-primary .advanced-replacement-notice').remove();
		/*! </fs_premium_only> */

		if ( oldImageMimeType != selectedAttachmentMimeType ) {
			// Different mime type detected
			var mimeTypeWarning = '<div class="mime-type-warning">'+mediaReplace.mimeTypeWarning+'</div>';
			jQuery('.media-frame-toolbar .media-toolbar-primary').prepend(mimeTypeWarning);
			jQuery('.media-frame-toolbar .media-toolbar-primary .media-button-select').prop('disabled', true);
			/*! <fs_premium_only> */
			// Pro version: Enable advanced replacement with confirmation dialog
			jQuery('.media-frame-toolbar .media-toolbar-primary .mime-type-warning').remove();
			jQuery('.media-frame-toolbar .media-toolbar-primary .media-button-select').prop('disabled', false);
			/*! </fs_premium_only> */
		} else {
			// Same mime type - enable button
			jQuery('.media-frame-toolbar .media-toolbar-primary .media-button-select').prop('disabled', false);
		}
	}
	
	// When an image is selected by clicking
	mediaFrameEl.on('click', 'li.attachment', function(e) {
		checkMimeType();
	});
	
	// When selection changes (including after upload)
	mediaFrame.on('selection:toggle', function() {
		checkMimeType();
	});
	
	// When selection is added (after upload auto-select)
	mediaFrame.on('selection:add', function() {
		checkMimeType();
	});
	
	// When toolbar is created/rendered (handles upload completion)
	mediaFrame.on('toolbar:create:select', function() {
		checkMimeType();
	});
	
	mediaFrame.on('toolbar:render:select', function() {
		checkMimeType();
	});
	
	// Make sure the "Drop files to upload" blue overlay is closed after dropping one or more files
	jQuery('.supports-drag-drop:not(.upload.php)').on( 'drop', function() {
		jQuery('.uploader-window').hide();
	});

	// When Perform Replacement button is clicked in the media frame...
	mediaFrame.on('select', function() {

		// Get media attachment details from the frame state
		var attachment = mediaFrame.state().get('selection').first().toJSON();
		var newImageMimeType = attachment.mime;
		
		/*! <fs_premium_only> */
		// Pro version: All replacements go through confirmation dialog
		showReplacementConfirmation(originalAttachmentId, attachment.id, oldImageMimeType, newImageMimeType);
		return; // Stop execution - wait for user confirmation
		/*! </fs_premium_only> */
		
		// Free version: Simple direct replacement for same type only
		if ( oldImageMimeType == newImageMimeType ) {

			// Send the attachment id of the replacement / new image to our hidden input
			jQuery('#new-attachment-id-'+originalAttachmentId).val(attachment.id);

			if (jQuery('#new-attachment-id-'+originalAttachmentId).closest('.media-modal').length) {
				// For media library grid view - this code won't run in Pro due to early return above
			} else {
				// For media library list view
				// "Perform Replacement" button has been clicked. Submit the edit form, which includes 'new-attachment-id'
				jQuery('#new-attachment-id-'+originalAttachmentId).closest("form").submit();
				jQuery(mediaFrame.close());
			}			
		}

	});

}

/*! <fs_premium_only> */
/**
 * Show replacement confirmation dialog (Pro only)
 * Works for both same-type and different-type replacements
 */
function showReplacementConfirmation(oldAttachmentId, newAttachmentId, oldMimeType, newMimeType) {
	// Show loading state
	var loadingHtml = '<div class="asenha-replacement-loading"><div class="asenha-replacement-loading-inner"><span class="spinner is-active"></span><p>' + mediaReplace.analyzingText + '</p></div></div>';
	jQuery('body').append(loadingHtml);

	// Make AJAX call to get replacement analysis
	jQuery.ajax({
		url: ajaxurl,
		type: 'POST',
		data: {
			action: 'asenha_media_replace_analysis',
			nonce: mediaReplace.nonce,
			old_attachment_id: oldAttachmentId,
			new_attachment_id: newAttachmentId
		},
		success: function(response) {
			jQuery('.asenha-replacement-loading').remove();
			
			if (response.success) {
				displayConfirmationDialog(response.data, oldAttachmentId, newAttachmentId);
			} else {
				alert(response.data.message || mediaReplace.errorAnalyzing);
			}
		},
		error: function() {
			jQuery('.asenha-replacement-loading').remove();
			alert(mediaReplace.errorServer);
		}
	});
}

/**
 * Display the confirmation dialog with replacement details
 */
function displayConfirmationDialog(data, oldAttachmentId, newAttachmentId) {
	var dialogHtml = '<div class="asenha-confirmation-overlay">';
	dialogHtml += '<div class="asenha-confirmation-dialog">';
	
	// Header
	dialogHtml += '<div class="asenha-dialog-header">';
	dialogHtml += '<h2>' + mediaReplace.confirmTitle + '</h2>';
	dialogHtml += '</div>';
	
	// Content
	dialogHtml += '<div class="asenha-dialog-content">';
	
	// Three-column layout: Image previews and posts list
	if (data.old_preview_url && data.new_preview_url) {
		dialogHtml += '<div class="asenha-image-preview-section asenha-three-columns">';
		
		// Column 1 - Old media preview and files to be replaced
		dialogHtml += '<div class="asenha-preview-column">';
		dialogHtml += '<h4>'+mediaReplace.currentImageLabel+'</h4>';
		
		// Display image preview or media icon
		if (data.old_is_image) {
			dialogHtml += '<div class="asenha-preview-wrapper">';
			dialogHtml += '<img src="' + data.old_preview_url + '" alt="' + data.old_filename + '" class="asenha-preview-image" />';
			dialogHtml += '</div>';
		} else {
			dialogHtml += '<div class="asenha-preview-wrapper asenha-media-icon-wrapper">';
			dialogHtml += '<img src="' + data.old_preview_url + '" alt="' + data.old_filename + '" class="asenha-media-icon" />';
			dialogHtml += '</div>';
		}
		
		dialogHtml += '<p class="asenha-file-info"><strong>' + data.old_filename + '</strong><br>';
		// dialogHtml += '(' + data.old_mime;
		if (data.old_dimensions) {
			// dialogHtml += ' | ' + data.old_dimensions;
			dialogHtml += data.old_dimensions;
		}
		// dialogHtml += ')</p>';
		dialogHtml += '</p>';
		
		// Files to be replaced
		dialogHtml += '<div class="asenha-files-list">';
		dialogHtml += '<h5>' + mediaReplace.filesToReplaceLabel + ':</h5>';
		dialogHtml += '<ul>';
		for (var j = 0; j < data.files_to_replace.length; j++) {
			var oldFile = data.files_to_replace[j];
			dialogHtml += '<li>';
			// Only show size label for image files
			if (data.old_is_image) {
				dialogHtml += '<strong>' + oldFile.size + ':</strong> ';
			}
			dialogHtml += '<code>' + oldFile.file + '</code>';
			if (oldFile.filesize) {
				dialogHtml += ' <span class="asenha-filesize">(' + oldFile.filesize + ')</span>';
			}
			dialogHtml += '</li>';
		}
		dialogHtml += '</ul>';
		dialogHtml += '</div>';
		
		dialogHtml += '</div>';
		
		// Column 2 - New media preview and replacement files
		dialogHtml += '<div class="asenha-preview-column">';
		dialogHtml += '<h4>'+mediaReplace.replacementImageLabel+'</h4>';
		
		// Display image preview or media icon
		if (data.new_is_image) {
			dialogHtml += '<div class="asenha-preview-wrapper">';
			dialogHtml += '<img src="' + data.new_preview_url + '" alt="' + data.new_filename + '" class="asenha-preview-image" />';
			dialogHtml += '</div>';
		} else {
			dialogHtml += '<div class="asenha-preview-wrapper asenha-media-icon-wrapper">';
			dialogHtml += '<img src="' + data.new_preview_url + '" alt="' + data.new_filename + '" class="asenha-media-icon" />';
			dialogHtml += '</div>';
		}
		
		dialogHtml += '<p class="asenha-file-info"><strong>' + data.new_filename + '</strong><br>';
		// dialogHtml += '(' + data.new_mime;
		if (data.new_dimensions) {
			// dialogHtml += ' | ' + data.new_dimensions;
			dialogHtml += data.new_dimensions;
		}
		// dialogHtml += ')</p>';
		dialogHtml += '</p>';
		
		// Replacement files
		dialogHtml += '<div class="asenha-files-list">';
		dialogHtml += '<h5>' + mediaReplace.replacementFilesLabel + ':</h5>';
		dialogHtml += '<ul>';
		for (var k = 0; k < data.replacement_files.length; k++) {
			var newFile = data.replacement_files[k];
			dialogHtml += '<li>';
			// Only show size label for image files
			if (data.new_is_image) {
				dialogHtml += '<strong>' + newFile.size + ':</strong> ';
			}
			dialogHtml += '<code>' + newFile.file + '</code>';
			if (newFile.filesize) {
				dialogHtml += ' <span class="asenha-filesize">(' + newFile.filesize + ')</span>';
			}
			dialogHtml += '</li>';
		}
		dialogHtml += '</ul>';
		dialogHtml += '</div>';
		
		dialogHtml += '</div>';
		
		// Column 3 - Posts using this media
		dialogHtml += '<div class="asenha-posts-column">';
		dialogHtml += '<h4>' + mediaReplace.postsUsingMediaLabel + '</h4>';
		dialogHtml += '<div class="asenha-posts-list-wrapper">';
		if (data.affected_posts && data.affected_posts.length > 0) {
			dialogHtml += '<ul>';
			for (var i = 0; i < data.affected_posts.length; i++) {
				var post = data.affected_posts[i];
				dialogHtml += '<li>';
				dialogHtml += '<span class="asenha-post-type-pill">' + post.type_label + '</span> ';
				dialogHtml += '<a href="' + post.permalink + '" target="_blank">' + post.title + '</a>';
				dialogHtml += ' <em>(' + post.status_label + ')</em>';
				dialogHtml += '<span class="asenha-post-actions"> | <a href="' + post.edit_url + '" class="asenha-edit-link">' + mediaReplace.editLabel + '</a></span>';
				dialogHtml += '</li>';
			}
			dialogHtml += '</ul>';
		} else {
			dialogHtml += '<p class="asenha-posts-empty">' + mediaReplace.noPostsLabel + '</p>';
		}
		dialogHtml += '</div>';
		
		// Check if basenames (without extension) are different
		var oldBasename = data.old_filename.substring(0, data.old_filename.lastIndexOf('.')) || data.old_filename;
		var newBasename = data.new_filename.substring(0, data.new_filename.lastIndexOf('.')) || data.new_filename;
		var basenamesDifferent = (oldBasename !== newBasename);
		
		// Add "After replacement:" section if basenames are different
		if (basenamesDifferent) {
			// Derive new values from the replacement filename
			var newPostTitle = newBasename;
			var newPostName = newBasename.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
			
			dialogHtml += '<h4 style="margin-top: 20px;">' + mediaReplace.afterReplacementLabel + '</h4>';
			dialogHtml += '<div class="asenha-after-replacement-section">';
			
			// post_title row - strikethrough applied by default since checkbox is checked
			dialogHtml += '<div class="asenha-post-info-row">';
			dialogHtml += '<strong>' + mediaReplace.postTitleLabel + '</strong>';
			dialogHtml += '<span class="asenha-current-value asenha-strikethrough">' + (data.old_post_title || '') + '</span>';
			dialogHtml += '<span class="asenha-arrow"> → </span>';
			dialogHtml += '<span class="asenha-new-value">' + newPostTitle + '</span>';
			dialogHtml += '</div>';
			
			// post_name row - strikethrough applied by default since checkbox is checked
			dialogHtml += '<div class="asenha-post-info-row">';
			dialogHtml += '<strong>' + mediaReplace.postNameLabel + '</strong>';
			dialogHtml += '<span class="asenha-current-value asenha-strikethrough">' + (data.old_post_name || '') + '</span>';
			dialogHtml += '<span class="asenha-arrow"> → </span>';
			dialogHtml += '<span class="asenha-new-value">' + newPostName + '</span>';
			dialogHtml += '</div>';
			
			dialogHtml += '</div>';
		}
		
		dialogHtml += '</div>';
		
		dialogHtml += '</div>';
	}
	
	dialogHtml += '</div>';
	
	// Footer with checkboxes and buttons
	dialogHtml += '<div class="asenha-dialog-footer">';
	
	// Checkbox container
	dialogHtml += '<div class="asenha-checkboxes-container">';
	
	// Add preserve filename checkbox only if same mime type
	if (data.same_mime_type) {
		dialogHtml += '<label class="asenha-preserve-filename">';
		dialogHtml += '<input type="checkbox" id="asenha-preserve-filename-checkbox"> ';
		dialogHtml += mediaReplace.preserveFilenameLabel;
		dialogHtml += '</label>';
	}
	
	// Add update post title checkbox only if basenames are different
	var oldBasename = data.old_filename.substring(0, data.old_filename.lastIndexOf('.')) || data.old_filename;
	var newBasename = data.new_filename.substring(0, data.new_filename.lastIndexOf('.')) || data.new_filename;
	var basenamesDifferent = (oldBasename !== newBasename);
	
	if (basenamesDifferent) {
		dialogHtml += '<label class="asenha-update-post-title">';
		dialogHtml += '<input type="checkbox" id="asenha-update-post-title-checkbox" checked> ';
		dialogHtml += mediaReplace.updatePostTitleLabel;
		dialogHtml += '</label>';
	}
	
	dialogHtml += '</div>';
	
	// Button group
	dialogHtml += '<div class="asenha-button-group">';
	dialogHtml += '<button type="button" class="button button-secondary asenha-cancel-replacement">' + mediaReplace.cancelLabel + '</button>';
	dialogHtml += '<button type="button" class="button button-primary asenha-confirm-replacement">' + mediaReplace.confirmLabel + '</button>';
	dialogHtml += '</div>';
	
	dialogHtml += '</div>';
	
	dialogHtml += '</div></div>';
	
	jQuery('body').append(dialogHtml);
	
	// Handle preserve filename checkbox interaction with update post title checkbox
	jQuery('#asenha-preserve-filename-checkbox').on('change', function() {
		var isChecked = jQuery(this).is(':checked');
		var updatePostTitleCheckbox = jQuery('#asenha-update-post-title-checkbox');
		
		if (isChecked) {
			// When preserving filename, uncheck and disable the update post title checkbox
			updatePostTitleCheckbox.prop('checked', false).prop('disabled', true);
			// Trigger change to update the UI
			updatePostTitleCheckbox.trigger('change');
		} else {
			// When not preserving filename, re-enable and check the update post title checkbox
			updatePostTitleCheckbox.prop('disabled', false).prop('checked', true);
			// Trigger change to update the UI
			updatePostTitleCheckbox.trigger('change');
		}
	});
	
	// Handle checkbox toggle for post_title/post_name/guid update
	jQuery('#asenha-update-post-title-checkbox').on('change', function() {
		var isChecked = jQuery(this).is(':checked');
		
		if (isChecked) {
			// Show strikethrough on current values and show new values
			jQuery('.asenha-current-value').addClass('asenha-strikethrough');
			jQuery('.asenha-arrow').show();
			jQuery('.asenha-new-value').show();
		} else {
			// Remove strikethrough and hide new values
			jQuery('.asenha-current-value').removeClass('asenha-strikethrough');
			jQuery('.asenha-arrow').hide();
			jQuery('.asenha-new-value').hide();
		}
	});
	
	// Handle cancel
	jQuery('.asenha-cancel-replacement').on('click', function() {
		jQuery('.asenha-confirmation-overlay').remove();
	});
	
	// Handle confirm
	jQuery('.asenha-confirm-replacement').on('click', function() {
		// Capture checkbox states BEFORE removing the overlay
		var preserveFilename = jQuery('#asenha-preserve-filename-checkbox').is(':checked');
		var updatePostTitle = jQuery('#asenha-update-post-title-checkbox').is(':checked');
		jQuery('.asenha-confirmation-overlay').remove();
		performAdvancedReplacement(oldAttachmentId, newAttachmentId, preserveFilename, updatePostTitle);
	});
	
	// Handle click outside
	jQuery('.asenha-confirmation-overlay').on('click', function(e) {
		if (jQuery(e.target).hasClass('asenha-confirmation-overlay')) {
			jQuery('.asenha-confirmation-overlay').remove();
		}
	});
}

/**
 * Perform the advanced replacement after confirmation
 * Works for both same-type and different-type replacements
 * 
 * @param {number} oldAttachmentId - The ID of the attachment being replaced
 * @param {number} newAttachmentId - The ID of the replacement attachment
 * @param {boolean} preserveFilename - Whether to preserve the old filename
 * @param {boolean} updatePostTitle - Whether to update post_title, post_name, and guid
 */
function performAdvancedReplacement(oldAttachmentId, newAttachmentId, preserveFilename, updatePostTitle) {
	// Set the new attachment ID
	jQuery('#new-attachment-id-' + oldAttachmentId).val(newAttachmentId);
	
	// Add advanced replacement flag to the form
	var form = jQuery('#new-attachment-id-' + oldAttachmentId).closest('form');
	if (!form.find('input[name="asenha_advanced_replacement"]').length) {
		form.append('<input type="hidden" name="asenha_advanced_replacement" value="1" />');
	}
	
	// Use the preserve filename flag passed as parameter
	var preserveFilenameValue = preserveFilename ? '1' : '0';
	if (!form.find('input[name="asenha_preserve_filename"]').length) {
		form.append('<input type="hidden" name="asenha_preserve_filename" value="' + preserveFilenameValue + '" />');
	}
	
	// Use the update post title flag passed as parameter
	var updatePostTitleValue = updatePostTitle ? '1' : '0';
	if (!form.find('input[name="asenha_update_post_title_name"]').length) {
		form.append('<input type="hidden" name="asenha_update_post_title_name" value="' + updatePostTitleValue + '" />');
	}
	
	// Submit the form
	if (jQuery('#new-attachment-id-' + oldAttachmentId).closest('.media-modal').length) {
		// For media library grid view
		jQuery('#new-attachment-id-' + oldAttachmentId).change();
		setTimeout(function() {
			location.href = 'upload.php?item=' + oldAttachmentId;
		}, 1000);
	} else {
		// For media library list view
		form.submit();
	}
}
/*! </fs_premium_only> */