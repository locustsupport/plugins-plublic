<?php

namespace ASENHA\Classes;

/**
 * Class related to rendering of settings fields on the admin page
 *
 * @since 2.2.0
 */
class Settings_Fields_Render {

	/**
	 * Render checkbox field as a toggle/switcher
	 *
	 * @since 1.0.0
	 */
	function render_checkbox_toggle( $args ) {

		$option_name = isset( $args['option_name'] ) ? $args['option_name'] : '';
		
		if ( ! empty( $option_name ) ) {
			$options = get_option( $option_name, array() );
		} else {
			$options = get_option( ASENHA_SLUG_U, array() );		
		}

		$field_name = $args['field_name'];
		$field_title = isset( $args['field_title'] ) ? $args['field_title'] : '';
		$field_description = $args['field_description'];
		$field_option_value = ( array_key_exists( $args['field_id'], $options ) ) ? $options[$args['field_id']] : false;

		echo '<input type="checkbox" id="' . esc_attr( $field_name ) . '" class="asenha-field-checkbox" name="' . esc_attr( $field_name ) . '" ' . checked( $field_option_value, true, false ) . '>';
		echo '<label for="' . esc_attr( $field_name ) . '"></label>';

		// For field with additional options / sub-fields, we add a wrapper to enclose field descriptions
		if ( array_key_exists( 'field_options_wrapper', $args ) && $args['field_options_wrapper'] ) {
			// For when the options / sub-fields occupy lengthy vertical space, we add show all / less toggler
			if ( array_key_exists( 'field_options_moreless', $args ) && $args['field_options_moreless'] ) {
				echo '<div class="asenha-field-with-options field-show-more">';
				echo '<a id="' . esc_attr( $args['field_slug'] ) . '-show-moreless" class="show-more-less show-more" href="#">' . __( 'Expand', 'admin-site-enhancements' ) . ' &#9660;</a>';
				echo '<div class="asenha-field-options-wrapper wrapper-show-more">';
			} else {
				echo '<div class="asenha-field-with-options">';
				echo '<div class="asenha-field-options-wrapper">';
			}

		}

		echo '<div class="asenha-field-description" data-search-filter data-module-info="' . esc_attr( strtolower( $field_title ) ) . '">' . wp_kses_post( $field_description ) . '</div>';

		// For field with additional options / sub-fields, we add wrapper for them
		if ( array_key_exists( 'field_options_wrapper', $args ) && $args['field_options_wrapper'] ) {
			echo '<div class="asenha-subfields" style="display:none"></div>';
		}


		// For field with additional options / sub-fields, we add a wrapper to enclose field descriptions
		if ( array_key_exists( 'field_options_wrapper', $args ) && $args['field_options_wrapper'] ) {
			echo '</div>';
			echo '</div>';
		}

	}

	/**
	 * Render checkbox field as sub-field of a toggle/switcher checkbox
	 *
	 * @since 1.9.0
	 */
	function render_checkbox_plain( $args ) {

		$option_name = $args['option_name'];
		
		if ( ! empty( $option_name ) ) {
			$options = get_option( $option_name, array() );
		} else {
			$options = get_option( ASENHA_SLUG_U, array() );		
		}

		$field_name = $args['field_name'];
		$field_label = $args['field_label'];
		
		$default_value = false;
		switch ( $args['field_id'] ) {
			case 'login_page_disable_registration':
				$default_value = ( 1 == get_option( 'users_can_register' ) ) ? false : true;
				break;
		}
		
		$field_option_value = ( isset( $options[$args['field_id']] ) ) ? $options[$args['field_id']] : $default_value;

		$display_none_on_load = isset( $args['display_none_on_load'] ) ? $args['display_none_on_load'] : false;
		if ( $display_none_on_load ) {
			$inline_style = 'display:none;';
		} else {
			$inline_style = '';
		}

		$field_disabled = ! empty( $args['field_disabled'] );

		// Disabled checkboxes are omitted from POST; preserve a checked value so save does not wipe it.
		if ( $field_disabled && $field_option_value ) {
			echo '<input type="hidden" name="' . esc_attr( $field_name ) . '" value="on">';
		}

		echo '<input type="checkbox" id="' . esc_attr( $field_name ) . '" class="asenha-subfield-checkbox" style="' . esc_attr( $inline_style ) . '" name="' . esc_attr( $field_name ) . '" ' . checked( $field_option_value, true, false ) . ' ' . disabled( $field_disabled, true, false ) . '>';
		echo '<label for="' . esc_attr( $field_name ) . '" class="asenha-subfield-checkbox-label" style="' . esc_attr( $inline_style ) . '">' . wp_kses_post( $field_label ) . '</label>';

	}

	/**
	 * Render Select2 multi-select for posts where Gutenberg is always disabled.
	 *
	 * @since 8.9.1
	 * @param array $args Field arguments from add_settings_field().
	 */
	function render_disable_gutenberg_always_on_posts__premium_only( $args ) {
		$option_name = $args['option_name'];

		if ( ! empty( $option_name ) ) {
			$options = get_option( $option_name, array() );
		} else {
			$options = get_option( ASENHA_SLUG_U, array() );
		}

		$field_name = $args['field_name'];
		$field_id   = $args['field_id'];
		$selected_ids = ( isset( $options[ $field_id ] ) && is_array( $options[ $field_id ] ) ) ? array_map( 'absint', $options[ $field_id ] ) : array();
		$selected_ids = array_values( array_filter( $selected_ids ) );

		$parent_enabled = ! empty( $options['disable_gutenberg_always'] );
		$wrapper_style  = $parent_enabled ? '' : 'display:none;';

		echo '<div class="disable-gutenberg-always-on-wrap" style="' . esc_attr( $wrapper_style ) . '">';
		echo '<select multiple="multiple" id="disable-gutenberg-always-on-select" class="disable-gutenberg-always-on-select" name="' . esc_attr( $field_name ) . '" style="width:100%;">';

		foreach ( $selected_ids as $post_id ) {
			$post = get_post( $post_id );
			if ( ! $post instanceof \WP_Post ) {
				continue;
			}

			$post_type_object = get_post_type_object( $post->post_type );
			$singular_label   = ( $post_type_object && isset( $post_type_object->labels->singular_name ) )
				? $post_type_object->labels->singular_name
				: $post->post_type;
			$option_text = '[' . $singular_label . '] ' . $post->post_title;

			echo '<option value="' . esc_attr( (string) $post_id ) . '" selected="selected">' . esc_html( $option_text ) . '</option>';
		}

		echo '</select>';
		echo '</div>';
	}

	/**
	 * Render Select2 multi-select for posts where Gutenberg is always enabled.
	 *
	 * @since 8.9.2
	 * @param array $args Field arguments from add_settings_field().
	 */
	function render_disable_gutenberg_always_enable_on_posts__premium_only( $args ) {
		$option_name = $args['option_name'];

		if ( ! empty( $option_name ) ) {
			$options = get_option( $option_name, array() );
		} else {
			$options = get_option( ASENHA_SLUG_U, array() );
		}

		$field_name = $args['field_name'];
		$field_id   = $args['field_id'];
		$selected_ids = ( isset( $options[ $field_id ] ) && is_array( $options[ $field_id ] ) ) ? array_map( 'absint', $options[ $field_id ] ) : array();
		$selected_ids = array_values( array_filter( $selected_ids ) );

		$parent_enabled = ! empty( $options['disable_gutenberg_always_enable'] );
		$wrapper_style  = $parent_enabled ? '' : 'display:none;';

		echo '<div class="disable-gutenberg-always-enable-on-wrap" style="' . esc_attr( $wrapper_style ) . '">';
		echo '<select multiple="multiple" id="disable-gutenberg-always-enable-on-select" class="disable-gutenberg-always-enable-on-select" name="' . esc_attr( $field_name ) . '" style="width:100%;">';

		foreach ( $selected_ids as $post_id ) {
			$post = get_post( $post_id );
			if ( ! $post instanceof \WP_Post ) {
				continue;
			}

			$post_type_object = get_post_type_object( $post->post_type );
			$singular_label   = ( $post_type_object && isset( $post_type_object->labels->singular_name ) )
				? $post_type_object->labels->singular_name
				: $post->post_type;
			$option_text = '[' . $singular_label . '] ' . $post->post_title;

			echo '<option value="' . esc_attr( (string) $post_id ) . '" selected="selected">' . esc_html( $option_text ) . '</option>';
		}

		echo '</select>';
		echo '</div>';
	}

	/**
	 * Render checkbox field as sub-field of a toggle/switcher checkbox
	 *
	 * @since 1.3.0
	 */
	function render_checkbox_subfield( $args ) {

		$option_name = $args['option_name'];
		
		if ( ! empty( $option_name ) ) {
			$options = get_option( $option_name, array() );
		} else {
			$options = get_option( ASENHA_SLUG_U, array() );		
		}

		$field_name = $args['field_name'];
		$field_label = $args['field_label'];
		
		$parent_field_id = isset( $args['parent_field_id'] ) ? $args['parent_field_id'] : '';
		$sub_field_id = isset( $args['sub_field_id'] ) ? $args['sub_field_id'] : '';

		if ( in_array( $parent_field_id, array(
			'enable_duplication_for',
			'enable_rest_api_for',
		) ) ) {
			// Default is true/enabled. Usually for options introduced at a later date where the previous default is true/enabled.
			$default_value = true;
		} else {
			// Default is false / checked
			$default_value = false;
		}

		if ( ! empty( $parent_field_id ) && ! empty( $sub_field_id ) && isset( $options[ $parent_field_id ][ $sub_field_id ][ $args['field_id'] ] ) ) {
			$field_option_value = $options[ $parent_field_id ][ $sub_field_id ][ $args['field_id'] ];
		} elseif ( in_array( $parent_field_id, array(
			'redirect_after_login_for_separate',
			'redirect_after_logout_for_separate',
		), true ) && ! empty( $sub_field_id ) ) {
			$field_option_value = ( isset( $options[ $sub_field_id ][ $args['field_id'] ] ) ) ? $options[ $sub_field_id ][ $args['field_id'] ] : $default_value;
		} elseif ( empty( $parent_field_id ) && ! empty( $args['field_id'] ) ) {
			$field_option_value = isset( $options[ $args['field_id'] ] ) ? $options[ $args['field_id'] ] : $default_value;
		} else {
			$field_option_value = ( isset( $options[ $parent_field_id ][ $args['field_id'] ] ) ) ? $options[ $parent_field_id ][ $args['field_id'] ] : $default_value;
		}
		
		echo '<input type="checkbox" id="' . esc_attr( $field_name ) . '" class="asenha-subfield-checkbox" name="' . esc_attr( $field_name ) . '" ' . checked( $field_option_value, true, false ) . '>';
		echo '<label for="' . esc_attr( $field_name ) . '" class="asenha-subfield-checkbox-label">' . wp_kses_post( $field_label ) . '</label>';

		if ( ! empty( $args['field_description'] ) ) {
			$desc_display = isset( $args['field_description_display'] ) ? $args['field_description_display'] : 'inline';

			if ( 'tooltip' === $desc_display ) {
				echo '<span class="asenha-info-tooltip-wrap">';
				echo '<button type="button" class="asenha-info-tooltip-toggle" aria-label="' . esc_attr__( 'More information', 'admin-site-enhancements' ) . '">';
				echo '<span class="dashicons dashicons-info-outline" aria-hidden="true"></span>';
				echo '</button>';
				echo '<span class="asenha-info-tooltip" role="tooltip">' . esc_html( $args['field_description'] ) . '</span>';
				echo '</span>';
			} else {
				echo '<div class="asenha-subfield-description">' . wp_kses_post( $args['field_description'] ) . '</div>';
			}
		}

	}

	/**
	 * Render radio buttons field as sub-field of a toggle/switcher checkbox
	 *
	 * @since 1.3.0
	 */
	function render_radio_buttons_subfield( $args ) {

		$option_name = $args['option_name'];
		
		if ( ! empty( $option_name ) ) {
			$options = get_option( $option_name, array() );
		} else {
			$options = get_option( ASENHA_SLUG_U, array() );		
		}

		$field_id = $args['field_id'];
		$field_name = $args['field_name'];
		$field_radios = $args['field_radios'];
		if ( ! empty( $args['field_default'] ) ) {
			$default_value = $args['field_default'];
		} else {
			$default_value = false;
		}
		$field_description = ( isset( $args['field_description'] ) ) ? $args['field_description'] : '';
		$field_option_value = ( isset( $options[$field_id] ) ) ? $options[$field_id] : $default_value;

		echo '<div class="asenha-subfield-radio-button-wrapper">';
		foreach ( $field_radios as $radio_label => $radio_value ) {
			echo '<input type="radio" id="' . esc_attr( $field_id . '_' . $radio_value ) . '" class="asenha-subfield-radio-button" name="' . esc_attr( $field_name ) . '" value="' . esc_attr( $radio_value ) . '" ' . checked( $radio_value, $field_option_value, false ) . '>';
			echo '<label for="' . esc_attr( $field_id . '_' . $radio_value ) . '" class="asenha-subfield-radio-button-label">' . wp_kses_post( $radio_label ) . '</label>';
		}
		echo '</div>';
		if ( ! empty( $field_description ) ) {
			echo '<div class="asenha-subfield-description">' . wp_kses_post( $field_description ) . '</div>';
		}

	}

	/**
	 * Render checkboxes field as sub-field of a toggle/switcher checkbox
	 *
	 * @since 6.9.2
	 */
	function render_checkboxes_subfield( $args ) {
		$options = get_option( ASENHA_SLUG_U, array() );		

		$field_id = $args['field_id'];
		$field_name = $args['field_name'];
		$field_options = $args['field_options'];
		$layout = ! empty( $args['layout'] ) ? $args['layout'] : 'horizontal';
		$default_value = ! empty( $args['field_default'] ) ? $args['field_default'] : array();
		$parent_field_id = isset( $args['parent_field_id'] ) ? $args['parent_field_id'] : '';
		$sub_field_id = isset( $args['sub_field_id'] ) ? $args['sub_field_id'] : '';

		if ( ! empty( $parent_field_id ) && ! empty( $sub_field_id ) && isset( $options[ $parent_field_id ][ $sub_field_id ][ $field_id ] ) ) {
			$field_option_value = (array) $options[ $parent_field_id ][ $sub_field_id ][ $field_id ];
		} else {
			$field_option_value = ( isset( $options[ $field_id ] ) ) ? (array) $options[ $field_id ] : $default_value;
		}

		// Back-compat: legacy naming for Two-Factor Recovery Codes.
		if ( in_array( $field_id, array( 'two_factor_available_providers', 'available_providers' ), true ) && is_array( $field_option_value ) ) {
			$field_option_value = array_map(
				static function( $provider_key ) {
					return ( 'backup_codes' === $provider_key ) ? 'recovery_codes' : $provider_key;
				},
				$field_option_value
			);
		}

		echo '<div class="wrapper-for-checkboxes ' . esc_attr( $layout ) . '">';
		foreach ( $field_options as $option_label => $option_value ) {
			$checkbox_id = ( ! empty( $parent_field_id ) && ! empty( $sub_field_id ) )
				? $parent_field_id . '_' . $sub_field_id . '_' . $field_id . '_' . $option_value
				: $field_id . '_' . $option_value;
			echo '<div>';
			echo '<input type="checkbox" id="' . esc_attr( $checkbox_id ) . '" class="asenha-subfield-radio-button" name="' . esc_attr( $field_name ) . '" value="' . esc_attr( $option_value ) . '" ' . checked( in_array( $option_value, $field_option_value ), 1, false ) . '>';
			echo '<label for="' . esc_attr( $checkbox_id ) . '" class="asenha-subfield-radio-button-label">' . wp_kses_post( $option_label ) . '</label>';
			echo '</div>';
		}
		echo '</div>';

	}

	/**
	 * Render text field as sub-field of a toggle/switcher checkbox
	 *
	 * @since 1.4.0
	 */
	function render_text_subfield( $args ) {
		$option_name = $args['option_name'];
		
		if ( ! empty( $option_name ) ) {
			$options = get_option( $option_name, array() );
		} else {
			$options = get_option( ASENHA_SLUG_U, array() );		
		}

		$field_id = $args['field_id'];
		$field_slug = str_replace( '_', '-', $field_id );
		$field_name = $args['field_name'];
		$field_width_classname = isset( $args['field_width_classname'] ) ? $args['field_width_classname'] : '';
		$field_type = $args['field_type'];
		$field_prefix = isset( $args['field_prefix'] ) ? $args['field_prefix'] : '';
		$field_suffix = isset( $args['field_suffix'] ) ? $args['field_suffix'] : '';
		$field_is_read_only = isset( $args['read_only'] ) ? $args['read_only'] : false;
		$field_is_read_only_output = ( $field_is_read_only ) ? ' readonly="readonly"' : '';
		$field_placeholder = isset( $args['field_placeholder'] ) ? $args['field_placeholder'] : '';
		$field_description = $args['field_description'];

		if ( isset( $options[$field_id] ) ) {
			if ( 'live_site_url' == $field_id ) {
				if ( false !== strpos( $options[$field_id], 'http' ) ) {
					$field_option_value = $options[$field_id];
				} else {
					// Legacy support for when base64 encoding was used prior to v7.3.1
					$field_option_value = base64_decode( $options[$field_id] );
				}
			} elseif ( 'login_page_logo_image_width' == $field_id || 'login_page_logo_image_height' == $field_id  ) {
				if ( isset( $options[$field_id] )
				) {
					if ( is_numeric( $options[$field_id] ) ) {
						$field_option_value = $options[$field_id];
					} else {
						$field_option_value = str_replace( 'px', '', $options[$field_id] );
					}
				}
			} else {
				$field_option_value = $options[$field_id];
			}			
		} else {
			if ( 'altcha_secret_key' == $field_id ) {
				if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
					$captcha_protection_altcha = new CAPTCHA_Protection_ALTCHA;
					$field_option_value = $captcha_protection_altcha->random_secret();
				} else {
					$field_option_value = '';
				}
			} else {
				$field_option_value = '';
			}
		}

		if ( ! empty( $field_prefix ) && ! empty( $field_suffix ) ) {
			$field_classname = ' with-prefix with-suffix';
		} elseif ( ! empty( $field_prefix ) && empty( $field_suffix ) ) {
			$field_classname = ' with-prefix';
		} elseif ( empty( $field_prefix ) && ! empty( $field_suffix ) ) {
			$field_classname = ' with-suffix';
		} else {
			$field_classname = '';
		}
		
		if ( ! empty( $field_width_classname ) ) {
			$field_classname .= ' ' . $field_width_classname;
		}
		
		echo wp_kses_post( $field_prefix ) . '<input type="text" id="' . esc_attr( $field_name ) . '" class="asenha-subfield-text' . esc_attr( $field_classname ) . '" name="' . esc_attr( $field_name ) . '" placeholder="' . esc_attr( $field_placeholder ) . '" value="' . esc_attr( $field_option_value ) . '"' . esc_html( $field_is_read_only_output ) .'>' . wp_kses_post( $field_suffix );
		if ( ! empty( $field_description ) ) {
			echo '<label for="' . esc_attr( $field_name ) . '" class="asenha-subfield-checkbox-label">' . wp_kses_post( $field_description ) . '</label>';
		}

	}

	/**
	 * Render text field as sub-field of a checkbox field. e.g. in Redirect After Login module
	 *
	 * @since 7.3.3
	 */
	function render_checkbox_field_text_subfield( $args ) {
		$option_name = $args['option_name'];
		
		if ( ! empty( $option_name ) ) {
			$options = get_option( $option_name, array() );
		} else {
			$options = get_option( ASENHA_SLUG_U, array() );		
		}

		$field_id = $args['field_id'];
		$field_name = $args['field_name'];
		$field_width_classname = isset( $args['field_width_classname'] ) ? $args['field_width_classname'] : '';
		$field_type = $args['field_type'];
		$field_prefix = $args['field_prefix'];
		$field_suffix = $args['field_suffix'];
		$field_placeholder = isset( $args['field_placeholder'] ) ? $args['field_placeholder'] : '';
		$field_description = $args['field_description'];

		$parent_field_id = isset( $args['parent_field_id'] ) ? $args['parent_field_id'] : '';
		$sub_field_id = isset( $args['sub_field_id'] ) ? $args['sub_field_id'] : '';

		if ( 'redirect_after_login_for_separate' == $parent_field_id 
			&& ! empty( $sub_field_id )
		) {
			$field_option_value = ( isset( $options[$sub_field_id][$field_id] ) ) ? $options[$sub_field_id][$field_id] : '';
		} else {
			$field_option_value = ( isset( $options[$parent_field_id][$field_id] ) ) ? $options[$parent_field_id][$field_id] : '';		
		}
		
		// $field_option_value = ( isset( $options[$field_id] ) ) ? $options[$field_id] : '';
		$field_option_value = ( isset( $options[$parent_field_id . '_slug'][$args['field_id']] ) ) ? $options[$parent_field_id . '_slug'][$field_id] : '';

		if ( ! empty( $field_prefix ) && ! empty( $field_suffix ) ) {
			$field_classname = ' with-prefix with-suffix';
		} elseif ( ! empty( $field_prefix ) && empty( $field_suffix ) ) {
			$field_classname = ' with-prefix';
		} elseif ( empty( $field_prefix ) && ! empty( $field_suffix ) ) {
			$field_classname = ' with-suffix';
		} else {
			$field_classname = '';		
		}
		
		if ( ! empty( $field_width_classname ) ) {
			$field_classname .= ' ' . $field_width_classname;
		}

		echo wp_kses_post( $field_prefix ) . '<input type="text" id="' . esc_attr( $field_name ) . '" class="asenha-subfield-text' . esc_attr( $field_classname ) . '" name="' . esc_attr( $field_name ) . '" placeholder="' . esc_attr( $field_placeholder ) . '" value="' . esc_attr( $field_option_value ) . '">' . wp_kses_post( $field_suffix );
		echo '<label for="' . esc_attr( $field_name ) . '" class="asenha-subfield-checkbox-label">' . esc_html( $field_description ) . '</label>';
	}
	
	/**
	 * Render description field as sub-field of a toggle/switcher checkbox
	 *
	 * @since 4.6.0
	 */
	function render_description_subfield( $args ) {

		$field_description = $args['field_description'];

		echo '<div class="asenha-subfield-description">' . wp_kses( $field_description, get_kses_with_style_src_svg_ruleset() ) . '</div>';

	}

	/**
	 * Render View Admin as Role recovery URL description at display time.
	 *
	 * @since 8.8.5
	 * @param array $args Settings field arguments.
	 * @return void
	 */
	function render_view_admin_as_role_recovery_description( $args ) {
		$view_admin_as_role = new View_Admin_As_Role();
		$recovery_url       = $view_admin_as_role->get_recovery_url_for_settings( get_current_user_id() );

		$field_description = '<div class="asenha-warning"><strong>' . sprintf(
			/* translators: %s is the secret recovery URL or instructional text */
			__( 'If something goes wrong</strong> and you need to regain access to your account as an administrator, please visit the following URL: <br /><strong>%s</strong><br /><br />If you use <strong>Ninja Firewall</strong>, please uncheck "Block attempts to gain administrative privileges" in the Firewall Policies settings before you try to view as a non-admin user role to <strong>prevent being locked out</strong> of your admin account.', 'admin-site-enhancements' ),
			esc_html( $recovery_url )
		) . '<br /><br />' . __( 'In any case, please also <strong>create at least one backup admin user</strong> as a last resort should your primary admin user fails to properly login as admin. With this second admin user, you can also restore the admin role for your primary admin user.', 'admin-site-enhancements' ) . '</div>';

		echo '<div class="asenha-subfield-description">' . wp_kses( $field_description, get_kses_with_style_src_svg_ruleset() ) . '</div>';
	}

	/**
	 * Render heading for sub-fields of a toggle/switcher checkbox
	 *
	 * @since 5.0.0
	 */
	function render_subfields_heading( $args ) {

		$subfields_heading = $args['subfields_heading'];

		echo '<div class="asenha-subfields-heading">' . wp_kses_post( $subfields_heading ) . '</div>';

	}

	/**
	 * Render password field as sub-field of a toggle/switcher checkbox
	 *
	 * @since 4.1.0
	 */
	function render_password_subfield( $args ) {

		$option_name = $args['option_name'];
		
		if ( ! empty( $option_name ) ) {
			$options = get_option( $option_name, array() );
		} else {
			$options = get_option( ASENHA_SLUG_U, array() );		
		}

		$field_id = $args['field_id'];
		$field_name = $args['field_name'];
		$field_type = $args['field_type'];
		$field_prefix = $args['field_prefix'];
		$field_suffix = $args['field_suffix'];
		$field_description = $args['field_description'];
		$field_option_value = ( isset( $options[$args['field_id']] ) ) ? $options[$args['field_id']] : '';
		$hide_stored_value = isset( $args['hide_stored_value'] ) ? (bool) $args['hide_stored_value'] : false;

		if ( ! empty( $field_prefix ) && ! empty( $field_suffix ) ) {
			$field_classname = ' with-prefix with-suffix';
		} elseif ( ! empty( $field_prefix ) && empty( $field_suffix ) ) {
			$field_classname = ' with-prefix';
		} elseif ( empty( $field_prefix ) && ! empty( $field_suffix ) ) {
			$field_classname = ' with-suffix';
		} else {
			$field_classname = '';		
		}

		if ( $hide_stored_value ) {
			$field_option_value = '';
		}

		$placeholder = isset( $args['field_placeholder'] ) ? $args['field_placeholder'] : '';

		echo wp_kses_post( $field_prefix ) . '<input type="password" id="' . esc_attr( $field_name ) . '" class="asenha-subfield-password' . esc_attr( $field_classname ) . '" name="' . esc_attr( $field_name ) . '" placeholder="' . esc_attr( $placeholder ) . '" size="24" autocomplete="off" value="' . esc_attr( $field_option_value ) . '">' . wp_kses_post( $field_suffix );
		echo '<label for="' . esc_attr( $field_name ) . '" class="asenha-subfield-checkbox-label">' . esc_html( $field_description ) . '</label>';

	}

	/**
	 * Render SMTP password field with live storage status and inline warning.
	 *
	 * @since 8.8.7
	 *
	 * @param array $args Field registration arguments.
	 * @return void
	 */
	function render_smtp_password_subfield( $args ) {

		$option_name = isset( $args['option_name'] ) ? $args['option_name'] : ASENHA_SLUG_U;
		$field_name  = $args['field_name'];
		$placeholder = isset( $args['field_placeholder'] ) ? $args['field_placeholder'] : '';

		if ( function_exists( '\asenha_get_option_array' ) ) {
			$options = \asenha_get_option_array( $option_name, true );
		} else {
			$options = get_option( $option_name, array() );
		}

		$email_delivery = new Email_Delivery();
		$ui_state       = method_exists( $email_delivery, 'get_smtp_password_ui_state' )
			? $email_delivery->get_smtp_password_ui_state( $options )
			: array(
				'description'     => __( 'Leave blank to keep the current password.', 'admin-site-enhancements' ),
				'show_warning'    => false,
				'warning_message' => '',
			);

		echo '<div class="asenha-subfield-password-wrapper">';
		echo '<input type="password" id="' . esc_attr( $field_name ) . '" class="asenha-subfield-password" name="' . esc_attr( $field_name ) . '" placeholder="' . esc_attr( $placeholder ) . '" size="24" autocomplete="off" value="">';
		echo '<label for="' . esc_attr( $field_name ) . '" class="asenha-subfield-description asenha-smtp-password-description">' . esc_html( $ui_state['description'] ) . '</label>';

		echo '<div class="asenha-smtp-password-warning"' . ( empty( $ui_state['show_warning'] ) ? ' style="display:none;"' : '' ) . '>';
		if ( ! empty( $ui_state['show_warning'] ) && ! empty( $ui_state['warning_message'] ) ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html( $ui_state['warning_message'] ) . '</p></div>';
		}
		echo '</div>';
		echo '</div>';

	}

	/**
	 * Render encrypted Google Maps API key subfield for Custom Content Types.
	 *
	 * @since 8.9.2
	 *
	 * @param array $args Field registration arguments.
	 * @return void
	 */
	function render_cct_google_maps_api_key_subfield( $args ) {
		$option_name = isset( $args['option_name'] ) ? $args['option_name'] : ASENHA_SLUG_U;
		$field_name  = $args['field_name'];
		$placeholder = isset( $args['field_placeholder'] ) ? $args['field_placeholder'] : '';

		if ( function_exists( '\asenha_get_option_array' ) ) {
			$options = \asenha_get_option_array( $option_name, true );
		} else {
			$options = get_option( $option_name, array() );
		}

		if ( ! class_exists( __NAMESPACE__ . '\CCT_Secrets' ) ) {
			require_once ASENHA_PATH . 'includes/premium/custom-content/class-cct-secrets.php';
		}

		$cct_secrets = new CCT_Secrets();
		$ui_state    = $cct_secrets->get_api_key_ui_state( $options );

		echo '<div class="asenha-subfield-password-wrapper">';
		echo '<input type="password" id="' . esc_attr( $field_name ) . '" class="asenha-subfield-password" name="' . esc_attr( $field_name ) . '" placeholder="' . esc_attr( $placeholder ) . '" size="40" autocomplete="off" value="">';
		echo '<label for="' . esc_attr( $field_name ) . '" class="asenha-subfield-description">' . esc_html( $ui_state['description'] ) . '</label>';
		echo '</div>';
	}

	/**
	 * Render number field as sub-field of a toggle/switcher checkbox
	 *
	 * @since 1.4.0
	 */
	function render_number_subfield( $args ) {

		$option_name = $args['option_name'];
		
		if ( ! empty( $option_name ) ) {
			$options = get_option( $option_name, array() );
		} else {
			$options = get_option( ASENHA_SLUG_U, array() );		
		}

		$field_id = $args['field_id'];
		$field_name = $args['field_name'];
		$field_type = $args['field_type'];
		$field_prefix = $args['field_prefix'];
		$field_suffix = $args['field_suffix'];
		$field_intro = $args['field_intro'];
		$field_placeholder = isset( $args['field_placeholder'] ) ? $args['field_placeholder'] : '';
		$field_min = isset( $args['field_min'] ) ? $args['field_min'] : 1;
		$field_max = isset( $args['field_max'] ) ? $args['field_max'] : 10;
		$field_description = isset( $args['field_description'] ) ? $args['field_description'] : '';
		$field_option_value = ( isset( $options[$args['field_id']] ) ) ? $options[$args['field_id']] : '';

		if ( ! empty( $field_prefix ) && ! empty( $field_suffix ) ) {
			$field_classname = ' with-prefix with-suffix';
		} elseif ( ! empty( $field_prefix ) && empty( $field_suffix ) ) {
			$field_classname = ' with-prefix';
		} elseif ( empty( $field_prefix ) && ! empty( $field_suffix ) ) {
			$field_classname = ' with-suffix';
		} else {
			$field_classname = '';		
		}

		echo '<div class="asenha-subfield-number-wrapper">';

		if ( ! empty( $field_intro ) ) {
			echo '<div class="asenha-subfield-number-intro">' . wp_kses_post( $field_intro ) . '</div>';
		}

		echo '<div>' . wp_kses_post( $field_prefix ) . '<input type="number" id="' . esc_attr( $field_name ) . '" class="asenha-subfield-number' . esc_attr( $field_classname ) . '" name="' . esc_attr( $field_name ) . '" placeholder="' . esc_attr( $field_placeholder ) . '" step="1" min="' . esc_attr( $field_min ) . '" max="' . esc_attr( $field_max ) . '" value="' . esc_attr( $field_option_value ) . '">' . wp_kses_post( $field_suffix ) . '</div>';

		if ( ! empty( $field_description ) ) {
			echo '<div class="asenha-subfield-number-description">' . wp_kses_post( $field_description ) . '</div>';
		}

		echo '</div>';

	}

	/**
	 * Render select field as sub-field of a toggle/switcher checkbox
	 *
	 * @since 1.4.0
	 */
	function render_select_subfield( $args ) {

		$option_name = $args['option_name'];
		
		if ( ! empty( $option_name ) ) {
			$options = get_option( $option_name, array() );
		} else {
			$options = get_option( ASENHA_SLUG_U, array() );		
		}
		
		$field_id = $args['field_id'];
		$field_name = $args['field_name'];
		$field_type = $args['field_type'];
		$field_prefix = $args['field_prefix'];
		$field_suffix = $args['field_suffix'];
		$field_select_options = $args['field_select_options'];
		$field_select_default = $args['field_select_default'];
		$field_intro = $args['field_intro'];
		$field_description = $args['field_description'];
		$parent_field_id = isset( $args['parent_field_id'] ) ? $args['parent_field_id'] : '';
		$sub_field_id = isset( $args['sub_field_id'] ) ? $args['sub_field_id'] : '';
		if ( ! empty( $field_select_default ) ) {
			$default_value = $field_select_default;
		} else {
			$default_value = false;
		}

		if ( ! empty( $parent_field_id ) && ! empty( $sub_field_id ) && isset( $options[ $parent_field_id ][ $sub_field_id ][ $field_id ] ) ) {
			$field_option_value = $options[ $parent_field_id ][ $sub_field_id ][ $field_id ];
		} else {
			$field_option_value = ( isset( $options[ $field_id ] ) ) ? $options[ $field_id ] : $default_value;
		}

		if ( ! empty( $field_prefix ) && ! empty( $field_suffix ) ) {
			$field_classname = ' with-prefix with-suffix';
		} elseif ( ! empty( $field_prefix ) && empty( $field_suffix ) ) {
			$field_classname = ' with-prefix';
		} elseif ( empty( $field_prefix ) && ! empty( $field_suffix ) ) {
			$field_classname = ' with-suffix';
		} else {
			$field_classname = '';		
		}

		$display_none_on_load = isset( $args['display_none_on_load'] ) ? $args['display_none_on_load'] : false;
		if ( $display_none_on_load ) {
			$inline_style = 'display:none;';
		} else {
			$inline_style = '';
		}

		echo '<div class="asenha-subfield-select-wrapper">';

		if ( ! empty( $field_intro ) ) {
			echo '<div class="asenha-subfield-select-intro">' . wp_kses_post( $field_intro ) . '</div>';
		}

		echo '<div style="' . esc_attr( $inline_style ) . '" class="asenha-subfield-select-inner">' . wp_kses_post( $field_prefix );
		echo '<select name="' . esc_attr( $field_name ) . '" class="asenha-subfield-select' . esc_attr( $field_classname ) . '">';

		foreach ( $field_select_options as $label => $value ) {
			echo '<option value="' . esc_attr( $value ) . '" ' . selected( $value, $field_option_value, false ) . '>' . esc_html( $label ) . '</option>';
		}

		echo '</select>';
		echo wp_kses_post( $field_suffix ) . '</div>';

		if ( ! empty( $field_description ) ) {
			echo '<div class="asenha-subfield-select-description">' . wp_kses_post( $field_description ) . '</div>';
		}

		echo '</div>';

	}

	/**
	 * Render textarea field as sub-field of a toggle/switcher checkbox
	 *
	 * @since 2.3.0
	 */
	function render_textarea_subfield( $args ) {

		$option_name = $args['option_name'];
		
		if ( ! empty( $option_name ) ) {
			$options = get_option( $option_name, array() );
		} else {
			$options = get_option( ASENHA_SLUG_U, array() );		
		}

		$field_id = $args['field_id'];
		$field_slug = $args['field_slug'];
		$field_name = $args['field_name'];
		$field_type = $args['field_type'];
		$field_rows = $args['field_rows'];
		$field_intro = $args['field_intro'];
		$field_description = $args['field_description'];
		$field_placeholder = isset( $args['field_placeholder'] ) ? $args['field_placeholder'] : '';

		// Always load textarea content from robots.txt URL, whether it's a real, custom-made robots.txt file or a virtual one generated by WordPress
		if ( 'robots_txt_content' == $field_id ) {
			if ( array_key_exists( 'manage_robots_txt', $options ) ) { // Manage robots.txt feature has been enabled before
				if ( ! $options['manage_robots_txt'] ) { // Manage robots.txt feature is NOT enabled
					if ( array_key_exists( 'robots_txt_content', $options ) && $options['robots_txt_content'] ) {
						$field_option_value = $options['robots_txt_content'];
					} else {
						$robots_txt_content = wp_remote_get( get_site_url() . '/robots.txt' );
						$robots_txt_content = esc_textarea( trim( wp_remote_retrieve_body( $robots_txt_content ) ) );
						$field_option_value = $robots_txt_content;						
					}
				} else { // Manage robots.txt feature is enabled
					if ( array_key_exists( 'robots_txt_content', $options ) && $options['robots_txt_content'] ) {
						$field_option_value = $options['robots_txt_content'];
					} else {
						$robots_txt_content = wp_remote_get( get_site_url() . '/robots.txt' );
						$robots_txt_content = esc_textarea( trim( wp_remote_retrieve_body( $robots_txt_content ) ) );
						$field_option_value = $robots_txt_content;						
					}
				}
			} else { // Manage robots.txt feature has never been enabled yet
					$robots_txt_content = wp_remote_get( get_site_url() . '/robots.txt' );
					$robots_txt_content = esc_textarea( trim( wp_remote_retrieve_body( $robots_txt_content ) ) );
					$field_option_value = $robots_txt_content;				
			}
		} else {
			$field_option_value = ( isset( $options[$args['field_id']] ) ) ? $options[$args['field_id']] : '';
		}

		echo '<div class="asenha-subfield-textarea-wrapper">';

		if ( ! empty( $field_intro ) ) {
			echo '<div class="asenha-subfield-textarea-intro">' . wp_kses_post( $field_intro ) . '</div>';
		}


		echo '<textarea rows="' . esc_attr( $field_rows ) . '" class="asenha-subfield-textarea" id="' . esc_attr( $field_name ) . '" name="' . esc_attr( $field_name ) . '" placeholder="' . esc_attr( $field_placeholder ) . '">' . esc_textarea( $field_option_value ) . '</textarea>';

		if ( ! empty( $field_description ) ) {
			echo '<div class="asenha-subfield-textarea-description">' . wp_kses_post( $field_description ) . '</div>';
		}

		echo '</div>';

	}

	/**
	 * Render textarea field as sub-field of a toggle/switcher checkbox
	 *
	 * @since 2.3.0
	 */
	function render_wpeditor_subfield( $args ) {
		$option_name = $args['option_name'];
		
		if ( ! empty( $option_name ) ) {
			$options = get_option( $option_name, array() );
		} else {
			$options = get_option( ASENHA_SLUG_U, array() );		
		}

		$field_id = $args['field_id'];
		$field_slug = $args['field_slug'];
		$field_name = $args['field_name'];
		$field_type = $args['field_type'];
		$field_intro = $args['field_intro'];
		$field_description = $args['field_description'];
		$field_placeholder = isset( $args['field_placeholder'] ) ? $args['field_placeholder'] : '';
		$field_option_value = ( isset( $options[$args['field_id']] ) ) ? $options[$args['field_id']] : '';
		$editor_settings = $args['editor_settings']; // https://developer.wordpress.org/reference/classes/_wp_editors/parse_settings/

		echo '<div class="asenha-subfield-wpeditor-wrapper">';

		if ( ! empty( $field_intro ) ) {
			echo '<div class="asenha-subfield-wpeditor-intro">' . wp_kses_post( $field_intro ) . '</div>';
		}

		$content = $field_option_value;
		$editor_id = str_replace( array( '[', ']' ), array( '--', '' ), $field_name );
		// vi( $editor_id, '', 'for ' . $field_name );
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo wp_editor( $content , $editor_id, $editor_settings );

		if ( ! empty( $field_description ) ) {
			echo '<div class="asenha-subfield-wpeditor-description">' . wp_kses_post( $field_description ) . '</div>';
		}

		echo '</div>';
	}

	/**
	 * Render custom HTML subfield
	 *
	 * @since 5.3.0
	 */
	function render_custom_html( $args ) {
		
		echo wp_kses( $args['html'], get_kses_with_custom_html_ruleset() );
		
	}
	
	/**
	 * Render media subfield
	 * 
	 * @since 6.2.2
	 */
	function render_media_subfield( $args ) {

		$field_id = $args['field_id'];
		$field_slug = $args['field_slug'];
		$field_name = $args['field_name'];
		$field_media_frame_title = $args['field_media_frame_title'];
		$field_media_frame_multiple = $args['field_media_frame_multiple'];
		$field_media_frame_library_type = $args['field_media_frame_library_type'];
		$field_media_frame_button_text = $args['field_media_frame_button_text'];
		$field_intro = $args['field_intro'];
		$field_description = $args['field_description'];
		
		$options = get_option( $args['option_name'], array() );
		$field_option_value = ( isset( $options[$field_id] ) ) ? $options[$field_id] : '';
		?>
		<div class="media-subfield-wrapper">
			<input id="<?php echo esc_attr( $field_slug ); ?>" class="image-picker" type="text" size="40" name="<?php echo esc_attr( $field_name ); ?>" value="<?php echo esc_url( $field_option_value ); ?>" />
			<button id="<?php echo esc_attr( $field_slug ); ?>-button" class="image-picker-button button-secondary"><?php echo __( 'Select an Image', 'admin-site-enhancements' ); ?></button>
			<?php
			if ( array_key_exists( 'field_hidden_inputs', $args ) && is_array( $args['field_hidden_inputs'] ) ) {
				foreach ( $args['field_hidden_inputs'] as $hidden_input ) {
					$hidden_option_key = isset( $hidden_input['option_key'] ) ? sanitize_key( $hidden_input['option_key'] ) : '';
					$hidden_id         = isset( $hidden_input['field_id'] ) ? (string) $hidden_input['field_id'] : '';
					$hidden_name       = isset( $hidden_input['field_name'] ) ? (string) $hidden_input['field_name'] : '';

					if ( empty( $hidden_option_key ) || empty( $hidden_id ) || empty( $hidden_name ) ) {
						continue;
					}

					$hidden_value = isset( $options[ $hidden_option_key ] ) ? absint( $options[ $hidden_option_key ] ) : 0;

					echo '<input type="hidden" id="' . esc_attr( $hidden_id ) . '" class="asenha-hidden-media-dim" name="' . esc_attr( $hidden_name ) . '" value="' . esc_attr( $hidden_value ) . '" />';
				}
			}
			?>
			<?php
			if ( ! empty( $field_description ) ) {
				echo '<div class="asenha-subfield-description media-subfield">' . wp_kses_post( $field_description ) . '</div>';
			}
			?>
		</div>
		<?php
	}

	/**
	 * Render media subfield
	 * 
	 * @since 6.2.2
	 */
	function render_color_picker_subfield( $args ) {

		$common_methods = new Common_Methods;

		$field_id = $args['field_id'];
		$field_slug = $args['field_slug'];
		$field_name = $args['field_name'];
		$field_intro = $args['field_intro'];
		$field_description = $args['field_description'];
		$field_default_value = $args['field_default_value'];

		$options = get_option( $args['option_name'], array() );
		$field_option_value = ( isset( $options[$field_id] ) ) ? $options[$field_id] : $field_default_value;
		?>
		<div class="color-subfield-wrapper">
			<input type="text" id="<?php echo esc_attr( $field_slug ); ?>" name="<?php echo esc_attr( $field_name ); ?>" value="<?php echo esc_attr( $common_methods->sanitize_hex_color( $field_option_value ) ); ?>" data-default-color="<?php echo esc_attr( $common_methods->sanitize_hex_color( $field_default_value ) ); ?>" class="color-picker"/>
		</div>
		<?php
	}

	/**
	 * Render text field as sub-field of a toggle/switcher checkbox
	 *
	 * @since 1.4.0
	 */
	function render_content_toggler( $args ) {
		$field_id = $args['field_id'];
		$field_slug = $args['field_slug'];
		$field_slug = str_replace( '_', '-', $field_id );

		$show_text = isset( $args['show_text'] ) ? $args['show_text'] : '';
		$hide_text = isset( $args['hide_text'] ) ? $args['hide_text'] : '';
		$content_selector = isset( $args['content_selector'] ) ? $args['content_selector'] : '';
		?>
		<div class="subfield-content-toggler <?php echo esc_attr( $field_slug ); ?>"><a href="#" data-show-text="<?php echo esc_attr( $show_text ); ?>" data-hide-text="<?php echo esc_attr( $hide_text ); ?>" data-target-selector="<?php echo esc_attr( $content_selector ); ?>" class="asenha-content-toggler" data-expanded="no"><?php echo esc_html( $show_text ); ?> <span>▼</span></a></div>
		<?php
	}

	/**
	 * Human-readable label fragment for an admin menu separator slug (AMO sortable UI).
	 *
	 * WordPress core and plugins use slugs like separator1, separator-last, separator-woocommerce.
	 * Internal slugs stay unchanged; this output is display-only (Spacer-* wording).
	 *
	 * @since 8.5.3
	 *
	 * @param string $menu_slug Separator menu slug from global $menu item index 2.
	 * @return string Middle segment only (without surrounding ~~); safe for esc_html when wrapped.
	 */
	private function format_admin_menu_separator_slug_for_display( $menu_slug ) {
		$name = str_replace( 'separator', 'Spacer-', $menu_slug );
		$name = str_replace( '--last', '-Last', $name );
		$name = str_replace( '--woocommerce', '--WooCommerce', $name );
		return $name;
	}

	/**
	 * Render sortable menu field
	 *
	 * @since 2.0.0
	 */
	function render_sortable_menu() {
		$triangle_right_icon = '<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 16 16"><path fill="currentColor" d="M14.222 6.687a1.5 1.5 0 0 1 0 2.629l-10 5.499A1.5 1.5 0 0 1 2 13.5V2.502a1.5 1.5 0 0 1 2.223-1.314z"/></svg>';

		?>
		<ul id="custom-admin-menu" class="menu ui-sortable">
		<?php

		global $menu, $submenu;
		
		$common_methods = new Common_Methods;		
		$options_extra = get_option( ASENHA_SLUG_U . '_extra', array() );
		$options = isset( $options_extra['admin_menu'] ) ? $options_extra['admin_menu'] : array();

		// Parsed early so Pro merge of custom spacers and render loops can use the same list.
		$deleted_separators = isset( $options['custom_menu_deleted_separators'] ) ? $options['custom_menu_deleted_separators'] : '';
		$deleted_separators_array = array();
		if ( is_string( $deleted_separators ) && ! empty( $deleted_separators ) ) {
			$deleted_separators_array = json_decode( $deleted_separators, true );
			if ( ! is_array( $deleted_separators_array ) ) {
				$deleted_separators_array = array();
			}
		}
		
        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
			// Ensure custom separators are added to the menu before rendering
			// This is needed because add_new_separators__premium_only() may not have run yet
			// when the AMO page is accessed directly
			$new_separators = isset( $options['custom_menu_new_separators'] ) ? $options['custom_menu_new_separators'] : '';
			
			if ( is_string( $new_separators ) && ! empty( $new_separators ) ) {
				$new_separators = json_decode( $new_separators, true );
				
				if ( is_array( $new_separators ) && ! empty( $new_separators ) ) {
					// Check which separators are already in the menu to avoid duplicates.
					// Omit user-deleted built-in rows still present in $menu so ASE spacers with the same slug can merge.
					$existing_separator_ids = array();
					foreach ( $menu as $menu_item ) {
						if ( ! isset( $menu_item[4] ) || false === strpos( $menu_item[4], 'wp-menu-separator' ) ) {
							continue;
						}
						if ( $common_methods->is_deleted_builtin_separator_menu_row__premium_only( $menu_item, $deleted_separators_array ) ) {
							continue;
						}
						if ( isset( $menu_item[2] ) ) {
							$existing_separator_ids[] = $menu_item[2];
						}
					}
					
				// Add any missing separators
				foreach( $new_separators as $separator_menu_item_id => $info ) {
					if ( ! in_array( $separator_menu_item_id, $existing_separator_ids ) ) {
						$menu[] = array(
							'',
							'read',
							$separator_menu_item_id,
							'',
							'wp-menu-separator additional-separator',
						);
					}
				}
			}
		}
	}

	// Set menu items to be excluded from title renaming. These are from WordPress core.
		$renaming_not_allowed = array( 
			'menu-dashboard', 
			'menu-pages', 
			// 'menu-posts', 
			'menu-media', 
			'menu-comments', 
			'menu-appearance', 
			'menu-plugins', 
			'menu-users', 
			'menu-tools', 
			'menu-settings' 
		);

		// Get custom menu item titles
		if ( array_key_exists( 'custom_menu_titles', $options ) ) {
			$custom_menu_titles = $options['custom_menu_titles'];
			$custom_menu_titles = explode( ',', $custom_menu_titles );
		} else {
			$custom_menu_titles = array();
		}

        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
			// Get data on menu items to be hidden by user roles
			if ( isset( $options['custom_menu_always_hidden'] ) ) {
				$menu_always_hidden = $options['custom_menu_always_hidden'];
				$menu_always_hidden = $common_methods->decode_amo_visibility_rules_option_value__premium_only( $menu_always_hidden );
			} else {
				$menu_always_hidden = array();
			}
			
			// Get custom menu items for submenu detection
			$custom_menu_items = array();
			if ( isset( $options['custom_menu_new_items'] ) ) {
				$custom_menu_items_raw = $options['custom_menu_new_items'];
				if ( is_string( $custom_menu_items_raw ) && ! empty( $custom_menu_items_raw ) ) {
					$custom_menu_items = json_decode( $custom_menu_items_raw, true );
					if ( ! is_array( $custom_menu_items ) ) {
						$custom_menu_items = array();
					}
				}
			}
        }

		// Get menu items hidden by toggle
		$menu_hidden_by_toggle = $common_methods->get_menu_hidden_by_toggle();

		$i = 1;

		// Check if there's an existing custom menu order data stored in options

		if ( array_key_exists( 'custom_menu_order', $options ) ) {

		$custom_menu = $options['custom_menu_order'];
		$custom_menu = explode( ',', $custom_menu );

		$menu_key_in_use = array();

		// Render sortables with data in custom menu order

	foreach ( $custom_menu as $custom_menu_item ) {

		foreach ( $menu as $menu_key => $menu_info ) {

			// Skip deleted built-in separators only for real separator rows; Pro distinguishes ASE additional-separator rows.
			$skip_deleted_separator = false;
			if ( isset( $menu_info[2], $menu_info[4] ) && false !== strpos( $menu_info[4], 'wp-menu-separator' ) ) {
				$skip_deleted_separator = in_array( $menu_info[2], $deleted_separators_array, true );
				if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
					$skip_deleted_separator = $common_methods->is_deleted_builtin_separator_menu_row__premium_only( $menu_info, $deleted_separators_array );
				}
			}
			if ( $skip_deleted_separator ) {
				continue;
			}

	        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
					// Initialize to ensure variable is always defined
					$is_custom_menu_check = 'no';
					if ( false !== strpos( $menu_info[4], 'wp-menu-separator' ) ) {
						$menu_item_title = $menu_info[2];
						$menu_item_id = $menu_info[2];
						$submenu_sortable_id = '';
						$menu_url_fragment = '';
					} else {
						$menu_item_title = $menu_info[0];
						// Check if this is a custom menu item - if so, use slug instead of CSS ID
						$is_custom_menu_check = $this->is_custom_menu_item__premium_only( $menu_info[2] );
						if ( $is_custom_menu_check === 'yes' ) {
							$menu_item_id = $menu_info[2]; // Use slug for custom menus
						} else {
							$menu_item_id = $menu_info[5]; // Use CSS ID for regular menus
						}
						$submenu_sortable_id = $menu_info[2];
						$menu_url_fragment = $menu_info[2];
				}			        	

				// Check if submenu exists (either WordPress submenu or custom submenu)
				if ( array_key_exists( $menu_info[2], $submenu ) && @is_countable( $submenu[$menu_info[2]] ) ) {
					// Count submenu items, excluding the parent menu itself
					$submenu_count = 0;
					foreach ( $submenu[$menu_info[2]] as $submenu_item ) {
						$submenu_item_slug = isset( $submenu_item[2] ) ? $submenu_item[2] : '';
						// Skip if this is the parent menu itself
						if ( $submenu_item_slug !== $menu_info[2] ) {
							$submenu_count++;
						}
					}
					if ( $submenu_count > 0 ) {
						$submenu_exists = true;
					} elseif ( $is_custom_menu_check === 'yes' && $this->has_custom_submenus__premium_only( $menu_info[2], $custom_menu_items ) ) {
						$submenu_exists = true;
					} else {
						$submenu_exists = false;
					}
				} elseif ( $is_custom_menu_check === 'yes' && $this->has_custom_submenus__premium_only( $menu_info[2], $custom_menu_items ) ) {
					$submenu_exists = true;
				} else {
					$submenu_exists = false;
				}		        	
	        } else {
					if ( false !== strpos( $menu_info[4], 'wp-menu-separator' ) ) {
						$menu_item_title = $menu_info[2];
						$menu_item_id = $menu_info[2];
					} else {
						$menu_item_title = $menu_info[0];
						$menu_item_id = $menu_info[5];
					}
					$menu_url_fragment = '';
		        }

			if ( $custom_menu_item == $menu_item_id ) {

				$menu_item_id_transformed = $common_methods->transform_menu_item_id( $menu_item_id );

					if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
						// Check using menu slug ($menu_info[2]) since that's what's used when registering custom menus
						$is_custom_menu = $this->is_custom_menu_item__premium_only( $menu_info[2] );						
					} else {
						$is_custom_menu = 'no';
					}

					$menu_required_capability = isset( $menu_info[1] ) ? $menu_info[1] : '';

					?>
					<li id="<?php echo esc_attr( $menu_item_id ); ?>" class="menu-item parent-menu-item menu-item-depth-0" data-custom-menu-item="<?php echo esc_attr( $is_custom_menu ); ?>" data-menu-slug="<?php echo esc_attr( $menu_info[2] ); ?>">
						<div class="menu-item-bar">
							<div class="menu-item-handle">
								<span class="dashicons dashicons-menu"></span>
									<div class="item-title">
										<div class="title-wrapper">
											<span class="menu-item-title">
											<?php
											if ( false !== strpos( $menu_info[4], 'wp-menu-separator' ) ) {
												echo '~~ ' . esc_html( $this->format_admin_menu_separator_slug_for_display( $menu_info[2] ) ) . ' ~~';
											} else {
												if ( in_array( $menu_item_id, $renaming_not_allowed ) ) {
													$menu_item_title = $menu_info[0];
													echo wp_kses_post( $common_methods->strip_html_tags_and_content( $menu_item_title ) );
												} else {

													// Get defaul/custom menu item title
													foreach ( $custom_menu_titles as $custom_menu_title ) {

														// At this point, $custom_menu_title value looks like toplevel_page_snippets__Code Snippets

														$custom_menu_title = explode( '__', $custom_menu_title );

														if ( $custom_menu_title[0] == $menu_item_id ) {
															$menu_item_title = $common_methods->strip_html_tags_and_content( $custom_menu_title[1] ); // e.g. Code Snippets
															break; // stop foreach loop so $menu_item_title is not overwritten in the next iteration
														} else {
															$menu_item_title = $common_methods->strip_html_tags_and_content( $menu_info[0] );
														}

													}

													?>
													<input type="text" value="<?php echo wp_kses_post( wp_unslash( $menu_item_title ) ); ?>" class="menu-item-custom-title" data-menu-item-id="<?php echo esc_attr( $menu_item_id ); ?>">
													<?php
												}
											}
											?>
											</span><!-- end of .menu-item-title -->
										<?php
								        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
											if ( $submenu_exists ) {
												?>
												<div class="submenu-toggle"><span class="arrow-right"><?php echo wp_kses( $triangle_right_icon, $common_methods->get_kses_extended_ruleset() ); ?></span><span class="submenu-text"><?php echo esc_html__( 'Submenu', 'admin-site-enhancements' ); ?></span></div>
												<?php
											} elseif ( $is_custom_menu === 'yes' && false === strpos( $menu_info[4], 'wp-menu-separator' ) ) {
												// Show "Add Submenu" link for custom menu items without submenus (excluding separators)
												?>
												<a href="#" class="add-submenu-to-custom-parent" data-parent-menu-id="<?php echo esc_attr( $menu_info[2] ); ?>"><?php echo esc_html__( 'Add Submenu', 'admin-site-enhancements' ); ?></a>
												<?php
											}								        	
								        }
										?>
										</div><!-- end of .title-wrapper -->
										<div class="options-for-hiding">
											<?php
									        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
									        	$hide_text = __( 'Hide', 'admin-site-enhancements' );
									        	$checkbox_class = 'parent-menu-hide-checkbox-prm';
									        } else {
									        	$hide_text = __( 'Hide until toggled', 'admin-site-enhancements' );
									        	$checkbox_class = 'parent-menu-hide-checkbox';	        	
									        }
								        	?>
											<label class="menu-item-checkbox-label">
												<?php
													if ( in_array( $custom_menu_item, $menu_hidden_by_toggle ) ) {
													?>
												<input type="checkbox" id="hide-status-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="<?php echo esc_attr( $checkbox_class ); ?>" data-menu-item-title="<?php echo esc_attr( $common_methods->strip_html_tags_and_content( $menu_item_title ) ); ?>" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>" data-menu-item-id-ori="<?php echo esc_attr( $menu_item_id ); ?>" data-menu-url-fragment="<?php echo esc_attr( $menu_url_fragment ); ?>" data-required-capability="<?php echo esc_attr( $menu_required_capability ); ?>" checked>
												<span><?php echo esc_html( $hide_text ); ?></span>
													<?php
													} else {
													?>
												<input type="checkbox" id="hide-status-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="<?php echo esc_attr( $checkbox_class ); ?>" data-menu-item-title="<?php echo esc_attr( $common_methods->strip_html_tags_and_content( $menu_item_title ) ); ?>" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>" data-menu-item-id-ori="<?php echo esc_attr( $menu_item_id ); ?>" data-menu-url-fragment="<?php echo esc_attr( $menu_url_fragment ); ?>" data-required-capability="<?php echo esc_attr( $menu_required_capability ); ?>">
												<span><?php echo esc_html( $hide_text ); ?></span>
													<?php
													}
												?>
											</label>
											<?php
									        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
											?>
												<div class="options-toggle" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>">
													<span class="arrow-right"><?php echo wp_kses( $triangle_right_icon, $common_methods->get_kses_extended_ruleset() ); ?></span><span class="options-text"><?php echo esc_html__( 'Options', 'admin-site-enhancements' ); ?></span>
												</div>
											<?php
									        }
											?>
										</div><!-- end of .options-for-hiding -->
									</div><!-- end of .item-title -->
								</div><!-- end of .menu-item-handle -->
							</div><!-- end of .menu-item-bar -->
							<?php
					        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
								$always_hide_checked_status = '';
								$all_or_selected_roles = '';
								if ( is_array( $menu_always_hidden ) && ! empty( $menu_always_hidden ) ) {
									foreach( $menu_always_hidden as $hidden_menu_item_id => $info ) {
										$hidden_menu_item_id = $common_methods->restore_menu_item_id( $hidden_menu_item_id );
										if ( $hidden_menu_item_id == $menu_item_id) {
											if ( isset( $info['always_hide'] ) && $info['always_hide'] ) {
												$always_hide_checked_status = ' checked';
											}				
											if ( isset( $info['always_hide_for'] ) && $info['always_hide_for'] ) {
												$all_or_selected_roles = $info['always_hide_for'];
											}

										}
									}									
								}

								// Get custom menu item data if this is a custom menu
								$custom_menu_data = null;
								if ( $is_custom_menu === 'yes' ) {
									$custom_menu_data = $this->get_custom_menu_item_data__premium_only( $menu_item_id );
								}

								$this->render_sortable_menu_options__premium_only( $menu_item_id, $menu_required_capability, $always_hide_checked_status, $all_or_selected_roles, true, $custom_menu_data );
					        }

						$i = 1;

				        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
							if ( $submenu_exists ) {
					        	// Render submenu
								$menu_item_id = $menu_info[2];
								$this->render_sortable_submenu__premium_only( $submenu, $menu_item_id, $submenu_sortable_id );
							}
				        }

							if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
								// Add delete icon for separators (built-in and custom). Pro only.
								if ( strpos( $menu_info[2], 'separator' ) !== false ) {
									?>
								<div class="remove-menu-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path fill="#bbbbbb" d="M24 2.4L21.6 0L12 9.6L2.4 0L0 2.4L9.6 12L0 21.6L2.4 24l9.6-9.6l9.6 9.6l2.4-2.4l-9.6-9.6z"/></svg></div>
									<?php
								}

								// Add delete icon for saved custom menu items (not separators). Pro only.
								if ( $is_custom_menu === 'yes' && strpos( $menu_info[2], 'separator' ) === false ) {
									?>
									<div class="remove-custom-menu-item-saved" data-menu-item-id="<?php echo esc_attr( $menu_info[2] ); ?>">
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24">
											<path fill="#bbbbbb" d="M24 2.4L21.6 0L12 9.6L2.4 0L0 2.4L9.6 12L0 21.6L2.4 24l9.6-9.6l9.6 9.6l2.4-2.4l-9.6-9.6z"/>
										</svg>
									</div>
									<?php
								}
							}
							?>
						</li>
						<?php
						$menu_key_in_use[] = $menu_key;
					}
				}
			}

			// Render the rest of the current menu towards the end of the sortables

		foreach ( $menu as $menu_key => $menu_info ) {

			if ( ! in_array( $menu_key, $menu_key_in_use ) ) {

				// Skip deleted built-in separators only for real separator rows; Pro distinguishes ASE additional-separator rows.
				$skip_deleted_separator = false;
				if ( isset( $menu_info[2], $menu_info[4] ) && false !== strpos( $menu_info[4], 'wp-menu-separator' ) ) {
					$skip_deleted_separator = in_array( $menu_info[2], $deleted_separators_array, true );
					if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
						$skip_deleted_separator = $common_methods->is_deleted_builtin_separator_menu_row__premium_only( $menu_info, $deleted_separators_array );
					}
				}
				if ( $skip_deleted_separator ) {
					continue;
				}

		        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
						if ( false !== strpos( $menu_info[4], 'wp-menu-separator' ) ) {
							$menu_item_id = $menu_info[2];
							$menu_url_fragment = '';
						} else {
							$menu_item_id = $menu_info[5];
							$menu_url_fragment = $menu_info[2];
						}			        	
				$submenu_sortable_id = $menu_info[2];
				$menu_item_title = $menu_info[0];

				// Check if submenu exists (either WordPress submenu or custom submenu)
				if ( array_key_exists( $menu_info[2], $submenu ) && @is_countable( $submenu[$menu_info[2]] ) ) {
					// Count submenu items, excluding the parent menu itself
					$submenu_count = 0;
					foreach ( $submenu[$menu_info[2]] as $submenu_item ) {
						$submenu_item_slug = isset( $submenu_item[2] ) ? $submenu_item[2] : '';
						// Skip if this is the parent menu itself
						if ( $submenu_item_slug !== $menu_info[2] ) {
							$submenu_count++;
						}
					}
					if ( $submenu_count > 0 ) {
						$submenu_exists = true;
					} elseif ( $this->is_custom_menu_item__premium_only( $menu_info[2] ) === 'yes' && $this->has_custom_submenus__premium_only( $menu_info[2], $custom_menu_items ) ) {
						$submenu_exists = true;
					} else {
						$submenu_exists = false;
					}
				} elseif ( $this->is_custom_menu_item__premium_only( $menu_info[2] ) === 'yes' && $this->has_custom_submenus__premium_only( $menu_info[2], $custom_menu_items ) ) {
					$submenu_exists = true;
				} else {
					$submenu_exists = false;
				}
	        } else {
						if ( false !== strpos( $menu_info[4], 'wp-menu-separator' ) ) {
							$menu_item_id = $menu_info[2];
						} else {
							$menu_item_id = $menu_info[5];
						}			        	
						$menu_item_title = $menu_info[0];
						$menu_url_fragment = '';
			        }
			        
			        // Strip tags
					$menu_item_title = $common_methods->strip_html_tags_and_content( $menu_item_title );

					// Exclude Show All/Less toggles

					if ( false === strpos( $menu_item_id, 'toplevel_page_asenha_' ) ) {

					$menu_item_id_transformed = $common_methods->transform_menu_item_id( $menu_item_id );

					if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
						// Check using menu slug ($menu_info[2]) since that's what's used when registering custom menus
						$is_custom_menu = $this->is_custom_menu_item__premium_only( $menu_info[2] );						
					} else {
						$is_custom_menu = 'no';
					}

					$menu_required_capability = isset( $menu_info[1] ) ? $menu_info[1] : '';

					?>
					<li id="<?php echo esc_attr( $menu_item_id ); ?>" class="menu-item parent-menu-item menu-item-depth-0" data-custom-menu-item="<?php echo esc_attr( $is_custom_menu ); ?>">
							<div class="menu-item-bar">
								<div class="menu-item-handle">
									<span class="dashicons dashicons-menu"></span>
									<div class="item-title">
										<div class="title-wrapper">
											<span class="menu-item-title">
												<?php
												if ( false !== strpos( $menu_info[4], 'wp-menu-separator' ) ) {
													echo '~~ ' . esc_html( $this->format_admin_menu_separator_slug_for_display( $menu_info[2] ) ) . ' ~~';
												} else {
												?>
													<input type="text" value="<?php echo wp_kses_post( wp_unslash( $menu_item_title ) ); ?>" class="menu-item-custom-title" data-menu-item-id="<?php echo esc_attr( $menu_item_id ); ?>">
												<?php													
												}
												?>
											</span>
											<?php
									        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
												if ( $submenu_exists ) {
													?>
													<div class="submenu-toggle"><span class="arrow-right"><?php echo wp_kses( $triangle_right_icon, $common_methods->get_kses_extended_ruleset() ); ?></span><span class="submenu-text"><?php echo esc_html__( 'Submenu', 'admin-site-enhancements' ); ?></span></div>
													<?php
												}
											}
											?>
										</div>
										<div class="options-for-hiding">
											<?php
									        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
									        	$hide_text = __( 'Hide', 'admin-site-enhancements' );
									        	$checkbox_class = 'parent-menu-hide-checkbox-prm';
									        } else {
									        	$hide_text = __( 'Hide until toggled', 'admin-site-enhancements' );
									        	$checkbox_class = 'parent-menu-hide-checkbox';	        	
									        }
								        	?>
								        	<label class="menu-item-checkbox-label">
												<input type="checkbox" id="hide-status-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="<?php echo esc_attr( $checkbox_class ); ?>" data-menu-item-title="<?php echo esc_attr( $common_methods->strip_html_tags_and_content( $menu_item_title ) ); ?>" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>" data-menu-item-id-ori="<?php echo esc_attr( $menu_item_id ); ?>" data-menu-url-fragment="<?php echo esc_attr( $menu_url_fragment ); ?>" data-required-capability="<?php echo esc_attr( $menu_required_capability ); ?>">
												<span><?php echo esc_html( $hide_text ); ?></span>
											</label>
											<?php
									        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
											?>
												<div class="options-toggle" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>">
													<span class="arrow-right"><?php echo wp_kses( $triangle_right_icon, $common_methods->get_kses_extended_ruleset() ); ?></span><span class="options-text">Options</span>
												</div>
											<?php
									        }
											?>
										</div><!-- end of .options-for-hiding -->
									</div><!-- end of .item-title -->
								</div><!-- end of .menu-item-handle -->
							</div><!-- end of .menu-item-bar -->
							<?php
					        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
								$always_hide_checked_status = '';
								$all_or_selected_roles = '';
								$this->render_sortable_menu_options__premium_only( $menu_item_id, $menu_required_capability, $always_hide_checked_status, $all_or_selected_roles, true );
					        }

						$i = 1;

				        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
							if ( $submenu_exists ) {
					        	// Render submenu
								$menu_item_id = $menu_info[2];
								$this->render_sortable_submenu__premium_only( $submenu, $menu_item_id, $submenu_sortable_id );
							}
				        }

							// Add delete icon for separators (built-in and custom). Pro only.
							if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
								if ( strpos( $menu_info[2], 'separator' ) !== false ) {
									?>
								<div class="remove-menu-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path fill="#bbbbbb" d="M24 2.4L21.6 0L12 9.6L2.4 0L0 2.4L9.6 12L0 21.6L2.4 24l9.6-9.6l9.6 9.6l2.4-2.4l-9.6-9.6z"/></svg></div>
									<?php
								}
							}
							// Add delete icon for saved custom menu items (not separators)
							if ( $is_custom_menu === 'yes' && strpos( $menu_info[2], 'separator' ) === false ) {
								?>
								<div class="remove-custom-menu-item-saved" data-menu-item-id="<?php echo esc_attr( $menu_info[2] ); ?>">
									<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24">
										<path fill="#bbbbbb" d="M24 2.4L21.6 0L12 9.6L2.4 0L0 2.4L9.6 12L0 21.6L2.4 24l9.6-9.6l9.6 9.6l2.4-2.4l-9.6-9.6z"/>
									</svg>
								</div>
								<?php
							}
							?>
						</li><!-- end of .menu-item -->
						<?php
					}
				}
			}
		} else { // No custom menu order has been saved yet

			// Render sortables with existing items in the admin menu

		foreach ( $menu as $menu_key => $menu_info ) {

			// Skip deleted built-in separators only for real separator rows; Pro distinguishes ASE additional-separator rows.
			$skip_deleted_separator = false;
			if ( isset( $menu_info[2], $menu_info[4] ) && false !== strpos( $menu_info[4], 'wp-menu-separator' ) ) {
				$skip_deleted_separator = in_array( $menu_info[2], $deleted_separators_array, true );
				if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
					$skip_deleted_separator = $common_methods->is_deleted_builtin_separator_menu_row__premium_only( $menu_info, $deleted_separators_array );
				}
			}
			if ( $skip_deleted_separator ) {
				continue;
			}

	        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
				// Initialize to ensure variable is always defined
				$is_custom_menu_check = 'no';
				if ( false !== strpos( $menu_info[4], 'wp-menu-separator' ) ) {
						$menu_item_id = $menu_info[2];
						$submenu_sortable_id = '';
						$menu_url_fragment = '';
					} else {
						// Check if this is a custom menu item - if so, use slug instead of CSS ID
						$is_custom_menu_check = $this->is_custom_menu_item__premium_only( $menu_info[2] );
						if ( $is_custom_menu_check === 'yes' ) {
							$menu_item_id = $menu_info[2]; // Use slug for custom menus
						} else {
							$menu_item_id = $menu_info[5]; // Use CSS ID for regular menus
						}
						$submenu_sortable_id = $menu_info[2];
						$menu_url_fragment = $menu_info[2];
			}			        	
			$menu_item_title = $menu_info[0];

			// Check if submenu exists (either WordPress submenu or custom submenu)
			if ( array_key_exists( $menu_info[2], $submenu ) && @is_countable( $submenu[$menu_info[2]] ) ) {
				// Count submenu items, excluding the parent menu itself
				$submenu_count = 0;
				foreach ( $submenu[$menu_info[2]] as $submenu_item ) {
					$submenu_item_slug = isset( $submenu_item[2] ) ? $submenu_item[2] : '';
					// Skip if this is the parent menu itself
					if ( $submenu_item_slug !== $menu_info[2] ) {
						$submenu_count++;
					}
				}
				if ( $submenu_count > 0 ) {
					$submenu_exists = true;
				} elseif ( $is_custom_menu_check === 'yes' && $this->has_custom_submenus__premium_only( $menu_info[2], $custom_menu_items ) ) {
					$submenu_exists = true;
				} else {
					$submenu_exists = false;
				}
			} elseif ( $is_custom_menu_check === 'yes' && $this->has_custom_submenus__premium_only( $menu_info[2], $custom_menu_items ) ) {
				$submenu_exists = true;
			} else {
				$submenu_exists = false;
			}
        } else {
					if ( false !== strpos( $menu_info[4], 'wp-menu-separator' ) ) {
						$menu_item_id = $menu_info[2];
					} else {
						$menu_item_id = $menu_info[5];
					}
					$menu_url_fragment = '';
					$menu_item_title = $menu_info[0];
		        }

			$menu_item_id_transformed = $common_methods->transform_menu_item_id( $menu_item_id );

	        // Strip tags
			$menu_item_title = $common_methods->strip_html_tags_and_content( $menu_item_title );

			if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
				// Check using menu slug ($menu_info[2]) since that's what's used when registering custom menus
				$is_custom_menu = $this->is_custom_menu_item__premium_only( $menu_info[2] );						
			} else {
				$is_custom_menu = 'no';
			}

			$menu_required_capability = isset( $menu_info[1] ) ? $menu_info[1] : '';

			$custom_menu_data         = null;
			$menu_item_handle_classes = 'menu-item-handle';

			if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
				if ( 'yes' === $is_custom_menu ) {
					$custom_menu_data = $this->get_custom_menu_item_data__premium_only( $menu_item_id );

					if ( isset( $custom_menu_data['target_type'] ) && 'none' === $custom_menu_data['target_type'] ) {
						$menu_item_handle_classes .= ' menu-item-target-none';
					}
				}
			}

			?>
			<li id="<?php echo esc_attr( $menu_item_id ); ?>" class="menu-item parent-menu-item menu-item-depth-0" data-custom-menu-item="<?php echo esc_attr( $is_custom_menu ); ?>" data-menu-slug="<?php echo esc_attr( $menu_info[2] ); ?>">
					<div class="menu-item-bar">
						<div class="<?php echo esc_attr( $menu_item_handle_classes ); ?>">
							<span class="dashicons dashicons-menu"></span>
							<div class="item-title">
								<div class="title-wrapper">
									<span class="menu-item-title">
									<?php
									if ( false !== strpos( $menu_info[4], 'wp-menu-separator' ) ) {
										echo '~~ ' . esc_html( $this->format_admin_menu_separator_slug_for_display( $menu_info[2] ) ) . ' ~~';
									} else {
										if ( in_array( $menu_item_id, $renaming_not_allowed ) ) {
												echo wp_kses_post( $menu_item_title );
										} else {
											?>
											<input type="text" value="<?php echo wp_kses_post( wp_unslash( $menu_item_title ) ); ?>" class="menu-item-custom-title" data-menu-item-id="<?php echo esc_attr( $menu_item_id ); ?>">
											<?php
										}
									}
									?>
									</span>
									<?php
							        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
										if ( $submenu_exists ) {
											?>
											<div class="submenu-toggle"><span class="arrow-right"><?php echo wp_kses( $triangle_right_icon, $common_methods->get_kses_extended_ruleset() ); ?></span><span class="submenu-text"><?php echo esc_html__( 'Submenu', 'admin-site-enhancements' ); ?></span></div>
											<?php
										} elseif ( $is_custom_menu === 'yes' && false === strpos( $menu_info[4], 'wp-menu-separator' ) ) {
											// Show "Add Submenu" link for custom menu items without submenus (excluding separators)
											?>
											<a href="#" class="add-submenu-to-custom-parent" data-parent-menu-id="<?php echo esc_attr( $menu_info[2] ); ?>"><?php echo esc_html__( 'Add Submenu', 'admin-site-enhancements' ); ?></a>
											<?php
										}
									}
									?>
								</div><!-- end of .title-wrapper -->
								<div class="options-for-hiding">
									<?php
							        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
							        	$hide_text = __( 'Hide', 'admin-site-enhancements' );
							        	$checkbox_class = 'parent-menu-hide-checkbox-prm';
							        } else {
							        	$hide_text = __( 'Hide until toggled', 'admin-site-enhancements' );
							        	$checkbox_class = 'parent-menu-hide-checkbox';	        	
							        }
						        	?>
									<label class="menu-item-checkbox-label">
										<input type="checkbox" id="hide-status-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="<?php echo esc_attr( $checkbox_class ); ?>" data-menu-item-title="<?php echo esc_attr( $common_methods->strip_html_tags_and_content( $menu_item_title ) ); ?>" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>" data-menu-item-id-ori="<?php echo esc_attr( $menu_item_id ); ?>" data-menu-url-fragment="<?php echo esc_attr( $menu_url_fragment ); ?>" data-required-capability="<?php echo esc_attr( $menu_required_capability ); ?>">
										<span><?php echo esc_html( $hide_text ); ?></span>
									</label>
									<?php
							        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
									?>
										<div class="options-toggle" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>">
											<span class="arrow-right"><?php echo wp_kses( $triangle_right_icon, $common_methods->get_kses_extended_ruleset() ); ?></span><span class="options-text">Options</span>
										</div>
									<?php
							        }
									?>
								</div><!-- end of .options-for-hiding -->
							</div><!-- end of .item-title -->
						</div><!-- end of .menu-item-handle -->
					</div><!-- end of .menu-item-bar -->
				<?php
		        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
					$always_hide_checked_status = '';
					$all_or_selected_roles = '';

					$this->render_sortable_menu_options__premium_only( $menu_item_id, $menu_required_capability, $always_hide_checked_status, $all_or_selected_roles, true, $custom_menu_data );
		        }

				$i = 1;

		        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
					if ( $submenu_exists ) {
				        // Render submenu
						$menu_item_id = $menu_info[2];
						$this->render_sortable_submenu__premium_only( $submenu, $menu_item_id, $submenu_sortable_id );
					}
				}

					// Add delete icon for separators (built-in and custom). Pro only.
					if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
						if ( strpos( $menu_info[2], 'separator' ) !== false ) {
							?>
						<div class="remove-menu-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path fill="#bbbbbb" d="M24 2.4L21.6 0L12 9.6L2.4 0L0 2.4L9.6 12L0 21.6L2.4 24l9.6-9.6l9.6 9.6l2.4-2.4l-9.6-9.6z"/></svg></div>
							<?php
						}
					}
					// Add delete icon for saved custom menu items (not separators)
					if ( $is_custom_menu === 'yes' && strpos( $menu_info[2], 'separator' ) === false ) {
						?>
						<div class="remove-custom-menu-item-saved" data-menu-item-id="<?php echo esc_attr( $menu_info[2] ); ?>">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24">
								<path fill="#bbbbbb" d="M24 2.4L21.6 0L12 9.6L2.4 0L0 2.4L9.6 12L0 21.6L2.4 24l9.6-9.6l9.6 9.6l2.4-2.4l-9.6-9.6z"/>
							</svg>
						</div>
						<?php
					}
					?>
				</li>
				<?php
			}
		}
		?>
		</ul>
		<?php

		if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
			$this->render_admin_menu_separator_clone_template__premium_only( $triangle_right_icon );
		}
		?>
		<div class="admin-menu-actions-wrapper">
			<?php
			if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
				?>
				<div class="admin-menu-main-actions">
					<a id="add-custom-menu" class="admin-menu-action" href="#"><?php echo esc_html__( 'Add Menu or Separator', 'admin-site-enhancements' ); ?></a>
					<a id="add-menu-separator" class="admin-menu-action" href="#"><?php echo esc_html__( 'Add Spacer', 'admin-site-enhancements' ); ?></a>
				</div>
				<?php
			}
			?>
			<div class="reset-menu-wrapper">
				<img src="<?php echo esc_attr( ASENHA_URL ); ?>assets/img/oval.svg" class="reset-menu-spinner" style="display: none;" /><a href="#" id="reset-menu"><?php echo esc_html__( 'Reset Menu', 'admin-site-enhancements' ); ?></a>
			</div>
		</div>
		<?php

		// Hidden input field to store custom menu order (from options as is, or sortupdate) upon clicking Save Changes. 

        $field_id = 'custom_menu_order';
		$field_option_value = ( isset( $options[$field_id] ) ) ? $options[$field_id] : '';

		echo '<input type="hidden" id="' . esc_attr( $field_id ) . '" class="asenha-subfield-text" name="' . esc_attr( $field_id ) . '" value="' . esc_attr( $field_option_value ) . '">';

		// Hidden input field to store hidden menu items (from options as is, or 'Hide' checkbox clicks) upon clicking Save Changes.
		$this->output_admin_menu_organizer_hidden_field( 'custom_menu_hidden' );

		// Hidden input field to store custom menu titles (from options as is, or custom values entered on each non-WP-default menu items.
		$this->output_admin_menu_organizer_hidden_field( 'custom_menu_titles' );

        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {

			// Hidden input field to store menu items that should always be hidden for all or some roles upon clicking Save Changes.
			$this->output_admin_menu_organizer_hidden_field( 'custom_menu_always_hidden' );
			
			// Hidden input field to store custom submenu items order upon clicking Save Changes.
			$this->output_admin_menu_organizer_hidden_field( 'custom_submenus_order' );
			
			// Hidden input field to store submenu items that should always be hidden for all or some roles upon clicking Save Changes.
			$this->output_admin_menu_organizer_hidden_field( 'custom_submenu_always_hidden' );
			
		// Hidden input field to store new separators upon clicking Save Changes.
		$this->output_admin_menu_organizer_hidden_field( 'custom_menu_new_separators' );
		
		// Hidden input field to store deleted built-in separators upon clicking Save Changes.
		$this->output_admin_menu_organizer_hidden_field( 'custom_menu_deleted_separators' );
		
		// Hidden input field to store new custom menu items upon clicking Save Changes.
		$this->output_admin_menu_organizer_hidden_field( 'custom_menu_new_items' );
			
        }
        
	}

	/**
	 * Decode and re-encode JSON option values for AMO hidden fields so WordPress-slashed or legacy
	 * strings become valid for JavaScript JSON.parse(), without applying stripslashes() to raw strings
	 * (which would break JSON \\u Unicode escapes).
	 *
	 * @since 8.5.3
	 *
	 * @param string $value Raw option value.
	 * @return string
	 */
	private function normalize_admin_menu_json_option_for_output( $value ) {
		if ( ! is_string( $value ) || '' === $value ) {
			return $value;
		}

		// Use objects (not associative arrays) so JSON objects stay objects and arrays stay arrays.
		$decoded = json_decode( $value, false );
		if ( JSON_ERROR_NONE === json_last_error() ) {
			return wp_json_encode( $decoded );
		}

		$decoded = json_decode( wp_unslash( $value ), false );
		if ( JSON_ERROR_NONE === json_last_error() ) {
			return wp_json_encode( $decoded );
		}

		return $value;
	}

	/**
	 * Output hidden field
	 *
	 * @since 6.9.13
	 */
	public function output_admin_menu_organizer_hidden_field( $field_id ) {
		$options_extra = get_option( ASENHA_SLUG_U . '_extra', array() );
		$options       = isset( $options_extra['admin_menu'] ) ? $options_extra['admin_menu'] : array();

		$field_name         = $field_id;
		$field_option_value = ( isset( $options[ $field_id ] ) ) ? $options[ $field_id ] : '';

		$json_option_field_ids = array(
			'custom_menu_new_separators',
			'custom_menu_deleted_separators',
			'custom_submenus_order',
			'custom_menu_always_hidden',
			'custom_submenu_always_hidden',
			'custom_menu_new_items',
		);

		if ( in_array( $field_id, $json_option_field_ids, true ) ) {
			$field_option_value = $this->normalize_admin_menu_json_option_for_output( $field_option_value );
		}

		echo '<input type="hidden" id="' . esc_attr( $field_name ) . '" class="asenha-subfield-text" name="' . esc_attr( $field_name ) . '" value="' . esc_attr( $field_option_value ) . '">';
	}

	/**
	 * Render sortable submenu items
	 *
	 * @since 5.1.0
	 */
	function render_sortable_submenu__premium_only( $submenu, $menu_item_id, $submenu_sortable_id ) {
		$triangle_right_icon = '<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 16 16"><path fill="currentColor" d="M14.222 6.687a1.5 1.5 0 0 1 0 2.629l-10 5.499A1.5 1.5 0 0 1 2 13.5V2.502a1.5 1.5 0 0 1 2.223-1.314z"/></svg>';
		
		$common_methods = new Common_Methods;
		$submenu_sortable_id = $common_methods->transform_menu_item_id( $submenu_sortable_id );

		// Exception/exclusion: $menu_item_id which should have their $submenu_item_title stripped of HTML tags but have the text/title intact
		$menu_item_ids_for_preserving_submenu_titles = array(
			'mainwp_tab', // https://wordpress.org/plugins/mainwp/
			'cff-top', // https://wordpress.org/plugins/custom-facebook-feed/
		);
		?>
		<div class="submenu-wrapper" style="display:none;">
			<ul id="<?php echo esc_attr( $submenu_sortable_id ); ?>" class="submenu-sortable">
				<?php
			foreach( $submenu[$menu_item_id] as $item_key => $item_info ) {
				$submenu_item_title = isset( $item_info[0] ) ? $item_info[0] : '';
				// Very rarely, submenu items use special characters / symbols, which breaks the JS. Let's remove it.
				$submenu_item_title = str_replace( 
					array( 
						'↳', 
						'➤', // e.g. WP fail2ban
						'⭐️', 
						'✛',
                        '<img draggable="false" role="img" class="emoji" alt="👋" src="https://s.w.org/images/core/emoji/15.0.3/svg/1f44b.svg">', // WOW-Plugin (Float Menu plugin) sub-menu 'Hey' has this image at the end of the title.
                        '👋', // WOW-Plugin (Float Menu plugin) sub-menu 'Hey' has this image at the end of the title.
                        '→', // Independent Analytics >> Upgrade to Pro submenu item
                        '»', // wpDiscuz
					), 
					'', 
					$submenu_item_title 
				);
				$submenu_item_title_slug = sanitize_title( $submenu_item_title );
				$submenu_item_slug = isset( $item_info[1] ) ? $item_info[1] : '';

				$submenu_required_capability = $submenu_item_slug;

			$submenu_item_id = isset( $item_info[2] ) ? $item_info[2] : '';
			
			// Skip if this submenu item is the parent menu itself AND the parent is a custom menu
			// (WordPress adds parent as first submenu item for custom menus)
			if ( $submenu_item_id === $menu_item_id && strpos( $menu_item_id, 'custom-menu-' ) === 0 ) {
				continue;
			}
					$submenu_item_id_length = strlen( $submenu_item_id );
					// Get the first two and last two characters and generate hex code
					// $submenu_item_title_hex = bin2hex( substr( $submenu_item_title_slug, 0, 2 ) . substr( $submenu_item_title_slug, -2 ) );
					$submenu_url_fragment = $submenu_item_id;

					// We need to make this as unique as possible for JS interactions, so, we string together three parts
					$submenu_item_id_combination = $submenu_sortable_id . '_-_' . $submenu_item_title_slug .'-_-' . $submenu_item_id_length;
					// e.g. index_php_-_site-options-_-24

			// $submenu_item_id_combination = $submenu_sortable_id . '_-_' . $submenu_item_title_slug .'-_-' . $submenu_item_title_hex;
			// e.g. index_php_-_site-options-_-696e6564
			
			// Check if this is a custom submenu item (check both the item ID and combination ID)
			$is_custom_submenu = ( strpos( $submenu_item_id, 'custom-submenu-' ) === 0 || strpos( $submenu_item_id_combination, 'custom-submenu-' ) !== false ) ? 'yes' : 'no';
			?>
			<li id="<?php echo esc_attr( $submenu_item_id ); ?>" class="menu-item menu-item-depth-0" data-custom-menu-item="<?php echo esc_attr( $is_custom_submenu ); ?>">
						<div class="menu-item-bar">
							<div class="menu-item-handle">
								<span class="dashicons dashicons-menu"></span>
								<div class="item-title">
									<div class="title-wrapper">
										<?php if ( $is_custom_submenu === 'yes' ): ?>
										<span class="menu-item-title">
											<input type="text" value="<?php echo esc_attr( $common_methods->strip_html_tags_and_content( $submenu_item_title ) ); ?>" class="menu-item-custom-title custom-submenu-title-input-saved" data-menu-item-id="<?php echo esc_attr( $submenu_item_id ); ?>">
										</span>
										<?php elseif ( in_array( $menu_item_id, $menu_item_ids_for_preserving_submenu_titles ) ): ?>
										<span class="menu-item-title"><?php echo wp_kses_post( strip_tags( $submenu_item_title ) ); ?></span>
										<?php else: ?>
										<span class="menu-item-title"><?php echo wp_kses_post( $common_methods->strip_html_tags_and_content( $submenu_item_title ) ); ?></span>
										<?php endif; ?>
									</div>
									<?php
										$custom_menu_item = '';
										$submenu_hidden_by_toggle = array();
									?>
									<div class="options-for-hiding">
										<?php
								        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
								        	$hide_text = __( 'Hide', 'admin-site-enhancements' );
								        	$checkbox_class = 'submenu-hide-checkbox-prm';
								        } else {
								        	$hide_text = __( 'Hide until toggled', 'admin-site-enhancements' );
								        	$checkbox_class = 'submenu-hide-checkbox';	        	
								        }
							        	?>
										<label class="menu-item-checkbox-label">
											<?php
												if ( in_array( $custom_menu_item, $submenu_hidden_by_toggle ) ) {
												?>
											<input type="checkbox" id="hide-status-for-<?php echo esc_attr( $submenu_item_id_combination ); ?>" class="<?php echo esc_attr( $checkbox_class ); ?>" data-menu-item-title="<?php echo esc_attr( $common_methods->strip_html_tags_and_content( $submenu_item_title ) ); ?>" data-menu-item-id="<?php echo esc_attr( $submenu_item_id_combination ); ?>" data-menu-item-id-ori="<?php echo esc_attr( $submenu_item_id ); ?>" data-menu-url-fragment="<?php echo esc_attr( $submenu_url_fragment ); ?>" data-required-capability="<?php echo esc_attr( $submenu_required_capability ); ?>" checked>
											<span><?php echo esc_html( $hide_text ); ?></span>
												<?php
												} else {
												?>
											<input type="checkbox" id="hide-status-for-<?php echo esc_attr( $submenu_item_id_combination ); ?>" class="<?php echo esc_attr( $checkbox_class ); ?>" data-menu-item-title="<?php echo esc_attr( $common_methods->strip_html_tags_and_content( $submenu_item_title ) ); ?>" data-menu-item-id="<?php echo esc_attr( $submenu_item_id_combination ); ?>" data-menu-item-id-ori="<?php echo esc_attr( $submenu_item_id ); ?>" data-menu-url-fragment="<?php echo esc_attr( $submenu_url_fragment ); ?>" data-required-capability="<?php echo esc_attr( $submenu_required_capability ); ?>">
											<span><?php echo esc_html( $hide_text ); ?></span>
												<?php
												}
											?>
										</label>
										<?php
								        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
										?>
											<div class="options-toggle" data-menu-item-id="<?php echo esc_attr( $submenu_item_id_combination ); ?>">
												<span class="arrow-right"><?php echo wp_kses( $triangle_right_icon, $common_methods->get_kses_extended_ruleset() ); ?></span><span class="options-text"><?php echo esc_html__( 'Options', 'admin-site-enhancements' ); ?></span>
											</div>
										<?php
								        }
										?>
									</div><!-- end of .options-for-hiding -->
								</div><!-- end of .item-title -->
							</div><!-- end of .menu-item-handle -->
						</div><!-- end of .menu-item-bar -->
						<?php
						// Get data on menu items to be hidden by user roles
			            $options_extra = get_option( ASENHA_SLUG_U . '_extra', array() );
			            $options = isset( $options_extra['admin_menu'] ) ? $options_extra['admin_menu'] : array();

						if ( isset( $options['custom_submenu_always_hidden'] ) ) {
							$submenu_always_hidden = $options['custom_submenu_always_hidden'];
							$submenu_always_hidden = $common_methods->decode_amo_visibility_rules_option_value__premium_only( $submenu_always_hidden );
						} else {
							$submenu_always_hidden = array();
						}

						$always_hide_checked_status = '';
						$all_or_selected_roles = '';
						if ( is_array( $submenu_always_hidden ) && ! empty( $submenu_always_hidden ) ) {
							foreach( $submenu_always_hidden as $hidden_submenu_item_id => $info ) {
								if ( $hidden_submenu_item_id == $submenu_item_id_combination) {
									if ( isset( $info['always_hide'] ) && $info['always_hide'] ) {
										$always_hide_checked_status = ' checked';
									}				
									if ( isset( $info['always_hide_for'] ) && $info['always_hide_for'] ) {
										$all_or_selected_roles = $info['always_hide_for'];
									}

								}
							}									
						}

				// Get custom menu item data if this is a custom submenu
				$custom_menu_data = null;
				$custom_submenu_item_id = null;
				if ( strpos( $submenu_item_id, 'custom-submenu-' ) === 0 ) {
					$custom_menu_data = $this->get_custom_menu_item_data__premium_only( $submenu_item_id );
					$custom_submenu_item_id = $submenu_item_id; // Pass the actual submenu ID for custom field IDs
				}

				$this->render_sortable_menu_options__premium_only( $submenu_item_id_combination, $submenu_required_capability, $always_hide_checked_status, $all_or_selected_roles, false, $custom_menu_data, $custom_submenu_item_id );
		        ?>
					<?php
					// Add delete icon for saved custom submenu items
					if ( strpos( $submenu_item_id, 'custom-submenu-' ) === 0 ) {
						?>
						<div class="remove-custom-menu-item-saved" data-menu-item-id="<?php echo esc_attr( $submenu_item_id ); ?>">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24">
								<path fill="#bbbbbb" d="M24 2.4L21.6 0L12 9.6L2.4 0L0 2.4L9.6 12L0 21.6L2.4 24l9.6-9.6l9.6 9.6l2.4-2.4l-9.6-9.6z"/>
							</svg>
						</div>
						<?php
					}
					?>
				</li>
					<?php
				}
				?>
				<div class="submenu-actions">
					<a href="#" class="add-custom-submenu" data-parent-menu-id="<?php echo esc_attr( $menu_item_id ); ?>"><?php echo esc_html__( 'Add Menu', 'admin-site-enhancements' ); ?></a>
				</div>
			</ul><!-- end of .submenu-sortable -->
		</div><!-- end of .submenu-wrapper -->
		<?php		
	}

	/**
	 * Hidden spacer row for JS cloning when no separator exists in #custom-admin-menu (e.g. all built-ins removed).
	 *
	 * @since 8.5.3
	 *
	 * @param string $triangle_right_icon SVG markup for options toggle (same as sortable menu field).
	 */
	function render_admin_menu_separator_clone_template__premium_only( $triangle_right_icon ) {

		$common_methods             = new Common_Methods();
		$menu_item_id               = 'amo-separator-clone-source';
		$menu_item_id_transformed   = $common_methods->transform_menu_item_id( $menu_item_id );
		$menu_item_title            = $menu_item_id;
		$menu_url_fragment          = '';
		$menu_required_capability   = 'read';
		$checkbox_class             = 'parent-menu-hide-checkbox-prm';
		$hide_text                  = __( 'Hide', 'admin-site-enhancements' );

		?>
		<div id="amo-separator-clone-template-wrapper" class="amo-separator-clone-template-wrapper" style="display:none;" aria-hidden="true">
			<ul class="amo-separator-clone-template-list">
				<li id="<?php echo esc_attr( $menu_item_id ); ?>" class="menu-item parent-menu-item menu-item-depth-0" data-custom-menu-item="no" data-menu-slug="<?php echo esc_attr( $menu_item_id ); ?>">
					<div class="menu-item-bar">
						<div class="menu-item-handle">
							<span class="dashicons dashicons-menu"></span>
							<div class="item-title">
								<div class="title-wrapper">
									<span class="menu-item-title"><?php echo esc_html( '~~ ' . $this->format_admin_menu_separator_slug_for_display( 'separator1' ) . ' ~~' ); ?></span>
								</div>
								<div class="options-for-hiding">
									<label class="menu-item-checkbox-label">
										<input type="checkbox" id="hide-status-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="<?php echo esc_attr( $checkbox_class ); ?>" data-menu-item-title="<?php echo esc_attr( $common_methods->strip_html_tags_and_content( $menu_item_title ) ); ?>" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>" data-menu-item-id-ori="<?php echo esc_attr( $menu_item_id ); ?>" data-menu-url-fragment="<?php echo esc_attr( $menu_url_fragment ); ?>" data-required-capability="<?php echo esc_attr( $menu_required_capability ); ?>" />
										<span><?php echo esc_html( $hide_text ); ?></span>
									</label>
									<div class="options-toggle" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>">
										<span class="arrow-right"><?php echo wp_kses( $triangle_right_icon, $common_methods->get_kses_extended_ruleset() ); ?></span><span class="options-text"><?php echo esc_html__( 'Options', 'admin-site-enhancements' ); ?></span>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php
					$this->render_sortable_menu_options__premium_only( $menu_item_id, $menu_required_capability, '', '', true, null );
					?>
					<div class="remove-menu-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path fill="#bbbbbb" d="M24 2.4L21.6 0L12 9.6L2.4 0L0 2.4L9.6 12L0 21.6L2.4 24l9.6-9.6l9.6 9.6l2.4-2.4l-9.6-9.6z"/></svg></div>
				</li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render sortable menu options for hiding by role
	 *
	 * @since 5.1.0
	 */
	function render_sortable_menu_options__premium_only( $menu_item_id, $menu_required_capability, $always_hide_checked_status, $all_or_selected_roles, $is_parent_menu = true, $custom_menu_data = null, $custom_menu_item_id = null ) {
		
		$common_methods = new Common_Methods;

		// For parent menu items
		$menu_hidden_by_toggle = $common_methods->get_menu_hidden_by_toggle();
		$menu_item_id_transformed = $common_methods->transform_menu_item_id( $menu_item_id );

		if ( ! empty( $menu_hidden_by_toggle ) && in_array( $menu_item_id, $menu_hidden_by_toggle ) ) {
			$hide_by_toggle_checked_status = ' checked';
		} else {
			$hide_by_toggle_checked_status = '';			
		}
		
		// For submenu items
		if ( ! $is_parent_menu ) {
			if ( false !== strpos( $menu_item_id, '_-_') ) {
				$submenu_item_id_parts = explode( '_-_', $menu_item_id );
				$submenu_item_id = $common_methods->restore_menu_item_id( $submenu_item_id_parts[0] ) . '_-_' . $submenu_item_id_parts[1];
				
				// Get indexed array of strings that looks like index.php_-_submenu-item-slug
				// Notice index.php is the regular (not transformed) submenu item's ID
				$submenu_hidden_by_toggle = $common_methods->get_submenu_hidden_by_toggle__premium_only();

				if ( ! empty( $submenu_hidden_by_toggle ) && in_array( $submenu_item_id, $submenu_hidden_by_toggle ) ) {
					$hide_by_toggle_checked_status = ' checked';
				} else {
					$hide_by_toggle_checked_status = '';			
				}
			}
		}
		
		if ( $is_parent_menu ) {
			$menu_type = 'parent';
			$settings_class = 'parent-menu';
			$hide_by_toggle_class = 'hide-until-toggled-checkbox';
		} else {
			$menu_type = 'sub';
			$settings_class = 'submenu';			
			$hide_by_toggle_class = 'hide-until-toggled-submenu-checkbox';
		}
		
		if ( $all_or_selected_roles == 'all-roles' ) {
			$all_roles_checked_status = ' checked';
			$all_roles_except_checked_status = '';
			$selected_roles_checked_status = '';
		} elseif ( $all_or_selected_roles == 'all-roles-except' ) {
			$all_roles_checked_status = '';
			$all_roles_except_checked_status = ' checked';
			$selected_roles_checked_status = '';			
		} elseif ( $all_or_selected_roles == 'selected-roles' ) {
			$all_roles_checked_status = '';
			$all_roles_except_checked_status = '';
			$selected_roles_checked_status = ' checked';			
		} else {
			$all_roles_checked_status = ' checked';
			$all_roles_except_checked_status = '';			
			$selected_roles_checked_status = '';			
		}
		
		// Handle "Posts >> Tags" submenu item. It requires 'manage_post_tags' capability, which is mapped to 'manage_categories' capability. Ref: https://wordpress.stackexchange.com/a/296144
		if ( 'manage_post_tags' == $menu_required_capability ) {
			$menu_required_capability = 'manage_categories';
		}

		$always_show_for_users = $common_methods->get_user_ids_menu_is_always_shown_for__premium_only( $menu_item_id_transformed, $is_parent_menu );
		$always_show_user_options = array();
		$always_show_user_choices = array();
		if ( ! empty( $always_show_for_users ) ) {
			$selected_users = get_users(
				array(
					'include' => $always_show_for_users,
					'orderby' => 'include',
				)
			);

			foreach ( $selected_users as $selected_user ) {
				$user_label = $common_methods->format_user_label_for_menu_visibility__premium_only( $selected_user );
				$always_show_user_options[ $selected_user->ID ] = $user_label;
				$always_show_user_choices[] = array(
					'id'   => (string) $selected_user->ID,
					'text' => $user_label,
				);
			}
		}
    	?>
		<!-- Render options panel for hiding menu -->
		<div id="options-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="menu-item-settings <?php echo esc_attr( $settings_class ); ?>-item-settings wp-clearfix" style="display:none;">
			<?php
			// Render custom menu configuration fields if this is a custom menu item
			if ( $custom_menu_data !== null ) {
				$target_url = isset( $custom_menu_data['url'] ) ? $custom_menu_data['url'] : '';
				$capability = isset( $custom_menu_data['capability'] ) ? $custom_menu_data['capability'] : 'manage_options';
				$icon = isset( $custom_menu_data['icon'] ) ? $custom_menu_data['icon'] : 'dashicons-admin-generic';
				$parent_id = isset( $custom_menu_data['parent_id'] ) ? $custom_menu_data['parent_id'] : '';
				$is_submenu = !empty( $parent_id );
				
			// Use custom_menu_item_id if provided (for submenus), otherwise use menu_item_id
			$field_id = ( $custom_menu_item_id !== null ) ? $custom_menu_item_id : $menu_item_id;
			
		// Get target type and styling data
		$target_type = isset( $custom_menu_data['target_type'] ) ? $custom_menu_data['target_type'] : 'url';
		$text_transform = isset( $custom_menu_data['text_transform'] ) ? $custom_menu_data['text_transform'] : 'title';
		$text_size = isset( $custom_menu_data['text_size'] ) ? $custom_menu_data['text_size'] : 'normal';
		$font_weight = isset( $custom_menu_data['font_weight'] ) ? $custom_menu_data['font_weight'] : 'normal';
		$alignment = isset( $custom_menu_data['alignment'] ) ? $custom_menu_data['alignment'] : 'left';
		$color_type = isset( $custom_menu_data['color_type'] ) ? $custom_menu_data['color_type'] : 'title';
		$color_value = isset( $custom_menu_data['color_value'] ) ? $custom_menu_data['color_value'] : '';
		$line_style = isset( $custom_menu_data['line_style'] ) ? $custom_menu_data['line_style'] : 'no-line';
			?>
			<div class="custom-menu-saved-fields">
			<?php if ( !$is_submenu ) { ?>
			<!-- Target type selection (pro-only, parent menus only) -->
			<div class="custom-menu-field">
				<label><?php esc_html_e( 'Target:', 'admin-site-enhancements' ); ?></label>
				<div class="custom-menu-target-type-radios" style="display:flex; gap:16px;">
					<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
						<input type="radio" name="target-type-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-target-type-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="url" <?php checked( $target_type, 'url' ); ?> />
						<span><?php esc_html_e( 'URL', 'admin-site-enhancements' ); ?></span>
					</label>
					<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
						<input type="radio" name="target-type-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-target-type-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="none" <?php checked( $target_type, 'none' ); ?> />
						<span><?php esc_html_e( 'None', 'admin-site-enhancements' ); ?></span>
					</label>
				</div>
			</div>
			<?php } ?>
			
			<!-- Target URL field -->
			<div class="custom-menu-field custom-menu-url-field-saved" style="<?php echo ( $target_type === 'none' && !$is_submenu ) ? 'display:none;' : ''; ?>">
				<label><?php esc_html_e( 'Target URL:', 'admin-site-enhancements' ); ?></label>
				<input type="text" class="custom-menu-target-url-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="<?php echo esc_attr( $target_url ); ?>" />
			</div>
			
		<?php if ( !$is_submenu ) { ?>
		<!-- Icon field (parent menus only) -->
		<div class="custom-menu-field custom-menu-icon-field-saved" style="<?php echo ( $target_type === 'none' ) ? 'display:none;' : ''; ?>">
			<label><?php esc_html_e( 'Icon:', 'admin-site-enhancements' ); ?></label>
			<?php
			// Default diamond icon (same as CPT module)
			$default_icon = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgdmlld0JveD0iMCAwIDIwIDIwIj48cGF0aCBmaWxsPSJjdXJyZW50Q29sb3IiIGQ9Ik0yLjU4NiAxMS40MTRhMiAyIDAgMCAxIDAtMi44MjhsNi4wMDItNmEyIDIgMCAwIDEgMi44MjggMGw2LjAwMiA2YTIgMiAwIDAgMSAwIDIuODI4bC02LjAwMiA2YTIgMiAwIDAgMS0yLjgyOCAwbC02LjAwMi02WiI+PC9wYXRoPjwvc3ZnPg==';
			$default_icon_svg = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><path fill="currentColor" d="M2.586 11.414a2 2 0 0 1 0-2.828l6.002-6a2 2 0 0 1 2.828 0l6.002 6a2 2 0 0 1 0 2.828l-6.002 6a2 2 0 0 1-2.828 0l-6.002-6Z"></path></svg>';

			// Set default icon if empty
			if ( empty( $icon ) ) {
				$icon = $default_icon;
			}

			// Decode icon for display if it's base64
			$icon_svg = '';
			if ( ! empty( $icon ) && strpos( $icon, 'data:image/svg+xml;base64,' ) === 0 ) {
				$icon_svg = base64_decode( str_replace( 'data:image/svg+xml;base64,', '', $icon ) );
			}

			// Fallback to default SVG if decoding fails
			if ( empty( $icon_svg ) ) {
				$icon_svg = $default_icon_svg;
			}
			?>
			<div class="icon-picker-wrapper">
				<div class="icon-picker">
					<div class="selected-menu-icon"><?php echo $icon_svg; ?></div>
					<input type="text" class="custom-menu-icon-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="<?php echo esc_attr( $icon ); ?>" placeholder="e.g. data:image/svg+xml;base64,..." />
				</div>
				<div class="icon-picker-controls">
					<button type="button" class="button icon-picker-button" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>"><?php esc_html_e( 'Change Icon', 'admin-site-enhancements' ); ?></button>
					<img src="<?php echo esc_attr( ASENHA_URL ); ?>assets/img/oval.svg" class="icon-picker-spinner" style="display: none;" />
					<input type="search" class="icon-picker-search" placeholder="<?php esc_attr_e( 'Search...', 'admin-site-enhancements' ); ?>" style="display:none;" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" />
				</div>
			</div>
			<div class="icon-library-container" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" style="display:none; position:relative;">
				<span class="icon-picker-close" style="display: none;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 16 16"><path fill="currentColor" d="M15.1 3.1L12.9.9L8 5.9L3.1.9L.9 3.1l5 4.9l-5 4.9l2.2 2.2l4.9-5l4.9 5l2.2-2.2l-5-4.9z"/></svg></span>
				<!-- Icon library will be loaded here via AJAX -->
			</div>
		</div>
		
		<!-- Styling options wrapper (shown when target type is "none") -->
		<div class="asenha-accordion custom-menu-styling-options-saved" style="<?php echo ( $target_type === 'none' ) ? '' : 'display:none;'; ?>">
			<h4 class="asenha-accordion-heading">
				<button aria-expanded="false" class="asenha-accordion-trigger" aria-controls="menu-style-panel-<?php echo esc_attr( $field_id ); ?>" type="button">
					<span class="title"><?php esc_html_e( 'Menu Style', 'admin-site-enhancements' ); ?></span>
					<span class="icon"></span>
				</button>
			</h4>
			<div id="menu-style-panel-<?php echo esc_attr( $field_id ); ?>" class="asenha-accordion-panel" hidden="hidden">
				<!-- Text Transform -->
				<div class="custom-menu-field">
					<label><?php esc_html_e( 'Text Transform:', 'admin-site-enhancements' ); ?></label>
					<div style="display:flex; gap:16px;">
						<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
							<input type="radio" name="text-transform-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-text-transform-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="uppercase" <?php checked( $text_transform, 'uppercase' ); ?> />
							<span><?php esc_html_e( 'UPPER CASE', 'admin-site-enhancements' ); ?></span>
						</label>
						<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
							<input type="radio" name="text-transform-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-text-transform-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="title" <?php checked( $text_transform, 'title' ); ?> />
							<span><?php esc_html_e( 'Title Case', 'admin-site-enhancements' ); ?></span>
						</label>
						<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
							<input type="radio" name="text-transform-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-text-transform-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="lowercase" <?php checked( $text_transform, 'lowercase' ); ?> />
							<span><?php esc_html_e( 'lower case', 'admin-site-enhancements' ); ?></span>
						</label>
					</div>
				</div>
				
				<!-- Text Size -->
				<div class="custom-menu-field">
					<label><?php esc_html_e( 'Font Size:', 'admin-site-enhancements' ); ?></label>
					<div style="display:flex; gap:16px;">
						<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
							<input type="radio" name="text-size-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-text-size-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="smaller" <?php checked( $text_size, 'smaller' ); ?> />
							<span><?php esc_html_e( 'Smaller', 'admin-site-enhancements' ); ?></span>
						</label>
						<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
							<input type="radio" name="text-size-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-text-size-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="normal" <?php checked( $text_size, 'normal' ); ?> />
							<span><?php esc_html_e( 'Normal', 'admin-site-enhancements' ); ?></span>
						</label>
						<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
							<input type="radio" name="text-size-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-text-size-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="larger" <?php checked( $text_size, 'larger' ); ?> />
							<span><?php esc_html_e( 'Larger', 'admin-site-enhancements' ); ?></span>
						</label>
					</div>
				</div>
				
					<!-- Font Weight -->
					<div class="custom-menu-field">
						<label><?php esc_html_e( 'Font Weight:', 'admin-site-enhancements' ); ?></label>
						<div style="display:flex; gap:16px;">
							<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
								<input type="radio" name="font-weight-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-font-weight-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="normal" <?php checked( $font_weight, 'normal' ); ?> />
								<span><?php esc_html_e( 'Normal', 'admin-site-enhancements' ); ?></span>
							</label>
							<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
								<input type="radio" name="font-weight-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-font-weight-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="medium" <?php checked( $font_weight, 'medium' ); ?> />
								<span><?php esc_html_e( 'Medium', 'admin-site-enhancements' ); ?></span>
							</label>
							<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
								<input type="radio" name="font-weight-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-font-weight-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="bold" <?php checked( $font_weight, 'bold' ); ?> />
								<span><?php esc_html_e( 'Bold', 'admin-site-enhancements' ); ?></span>
							</label>
						</div>
					</div>
					
					<!-- Alignment -->
					<div class="custom-menu-field">
						<label><?php esc_html_e( 'Alignment:', 'admin-site-enhancements' ); ?></label>
						<div style="display:flex; gap:16px;">
							<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
								<input type="radio" name="alignment-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-alignment-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="left" <?php checked( $alignment, 'left' ); ?> />
								<span><?php esc_html_e( 'Left', 'admin-site-enhancements' ); ?></span>
							</label>
							<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
								<input type="radio" name="alignment-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-alignment-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="center" <?php checked( $alignment, 'center' ); ?> />
								<span><?php esc_html_e( 'Center', 'admin-site-enhancements' ); ?></span>
							</label>
							<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
								<input type="radio" name="alignment-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-alignment-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="right" <?php checked( $alignment, 'right' ); ?> />
								<span><?php esc_html_e( 'Right', 'admin-site-enhancements' ); ?></span>
							</label>
						</div>
					</div>
					
					<!-- Color -->
					<div class="custom-menu-field">
						<label><?php esc_html_e( 'Color:', 'admin-site-enhancements' ); ?></label>
						<div style="display:flex; gap:16px; margin-bottom:8px;">
							<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
								<input type="radio" name="color-type-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-color-type-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="title" <?php checked( $color_type, 'title' ); ?> />
								<span><?php esc_html_e( 'Title', 'admin-site-enhancements' ); ?></span>
							</label>
							<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
								<input type="radio" name="color-type-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-color-type-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="background" <?php checked( $color_type, 'background' ); ?> />
								<span><?php esc_html_e( 'Background', 'admin-site-enhancements' ); ?></span>
							</label>
						</div>
						<input type="text" class="custom-menu-color-picker-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="<?php echo esc_attr( $color_value ); ?>" />
					</div>
					
					<!-- Line Style -->
					<div class="custom-menu-field custom-menu-line-style-field-saved" style="<?php echo ( $color_type === 'background' ) ? 'display:none;' : ''; ?>">
						<label><?php esc_html_e( 'Line Style:', 'admin-site-enhancements' ); ?></label>
						<div style="display:flex; gap:16px;">
							<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
								<input type="radio" name="line-style-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-line-style-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="no-line" <?php checked( $line_style, 'no-line' ); ?> />
								<span><?php esc_html_e( 'No line', 'admin-site-enhancements' ); ?></span>
							</label>
							<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
								<input type="radio" name="line-style-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-line-style-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="underline" <?php checked( $line_style, 'underline' ); ?> />
								<span><?php esc_html_e( 'Underline', 'admin-site-enhancements' ); ?></span>
							</label>
							<label style="display:flex; align-items:center; gap:4px; font-weight:normal;">
								<input type="radio" name="line-style-saved-<?php echo esc_attr( $field_id ); ?>" class="custom-menu-line-style-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" value="side-line" <?php checked( $line_style, 'side-line' ); ?> />
								<span><?php esc_html_e( 'Sideline', 'admin-site-enhancements' ); ?></span>
							</label>
						</div>
					</div>
			</div><!-- .asenha-accordion-panel -->
		</div><!-- .asenha-accordion -->
			<?php } ?>
			
			<!-- Required Capability field -->
			<div class="custom-menu-field custom-menu-capability-field-saved">
				<label><?php esc_html_e( 'Required Capability:', 'admin-site-enhancements' ); ?></label>
				<select class="custom-menu-capability-saved" data-menu-item-id="<?php echo esc_attr( $field_id ); ?>" data-current-value="<?php echo esc_attr( $capability ); ?>">
					<!-- Options will be populated via JS -->
				</select>
			</div>
			</div>
			<?php
			}
			?>
			<div class="hide-toggle-or-always">
				<label class="menu-item-checkbox-label">
					<input type="checkbox" id="hide-until-toggled-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="<?php echo esc_attr( $hide_by_toggle_class ); ?>" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>"<?php echo esc_attr( $hide_by_toggle_checked_status ); ?>>
					<span><?php _e( 'Hide until toggled', 'admin-site-enhancements' ); ?></span>
				</label>
			</div>
			<div id="all-selected-roles-options-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="all-selected-roles-options" data-menu-item-id="<?php echo esc_attr( $menu_item_id ); ?>">
				<label class="menu-item-checkbox-label">
					<input type="checkbox" id="hide-by-role-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="hide-by-role-checkbox" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>" data-menu-type="<?php echo esc_attr( $menu_type ); ?>" <?php echo esc_attr( $always_hide_checked_status ); ?>>
					<span><?php echo esc_html__( 'Always hide for user role(s)', 'admin-site-enhancements' ); ?></span>
				</label>
				<fieldset id="all-selected-roles-radio-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" style="display:none;">
				    <div>
				      <input type="radio" id="all-roles-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="all-selected-roles-radios" name="hide-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" value="all-roles" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>" data-menu-type="<?php echo esc_attr( $menu_type ); ?>" <?php echo esc_attr( $all_roles_checked_status ); ?>>
				      <label for="all-roles-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>">all roles</label>
				    </div>
				    <div>
				      <input type="radio" id="all-roles-except-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="all-selected-roles-radios" name="hide-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" value="all-roles-except" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>" data-menu-type="<?php echo esc_attr( $menu_type ); ?>" <?php echo esc_attr( $all_roles_except_checked_status ); ?>>
				      <label for="all-roles-except-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>">all roles except</label>
				    </div>
				    <div>
				      <input type="radio" id="selected-roles-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="all-selected-roles-radios" name="hide-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" value="selected-roles" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>" data-menu-type="<?php echo esc_attr( $menu_type ); ?>" <?php echo esc_attr( $selected_roles_checked_status ); ?>>
				      <label for="selected-roles-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>">selected roles</label>
				    </div>
				</fieldset>
			</div>
			<div id="hide-for-roles-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="hide-for-roles-options" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>" data-menu-type="<?php echo esc_attr( $menu_type ); ?>" style="display:none;">
				<?php
	        	global $wp_roles;
				$roles = $wp_roles->get_names();
				if ( $all_or_selected_roles == 'all-roles-except' || $all_or_selected_roles == 'selected-roles' ) {
					$roles_menu_is_hidden_for = $common_methods->get_roles_menu_is_hidden_for__premium_only( $menu_item_id_transformed, $is_parent_menu );
				}
				foreach ( $roles as $role_slug => $role_name ) {
					$role_obj = get_role( $role_slug );
					if ( is_object( $role_obj ) && is_array( $role_obj->capabilities ) ) {
						$role_capabilities = array_keys( $role_obj->capabilities );
					} else {
						$role_capabilities = array();
					}

					if ( in_array( $menu_required_capability, $role_capabilities ) ) {
						$role_is_checked_status = '';
						if ( $all_or_selected_roles == 'all-roles-except' ||  $all_or_selected_roles == 'selected-roles' ) {
							if ( in_array( $role_slug, $roles_menu_is_hidden_for ) ) {
								$role_is_checked_status = ' checked';
							}							
						}
						?>
						<label class="menu-item-checkbox-label">
							<input type="checkbox" class="menu-item-checkbox role-checkbox" data-role="<?php echo esc_attr( $role_slug ); ?>"<?php echo esc_attr( $role_is_checked_status ); ?>>
							<span><?php echo esc_html( $role_name ); ?></span>
						</label>
						<?php
					}
				}
				?>
			</div>
			<div id="menu-required-capability-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="menu-required-capability" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>" style="display:none;"><?php echo wp_kses_post( 
				sprintf( 
				/* translators: the required user capability to view menu item */
				__( 'The role(s) above have the <code>%s</code> capability required to view and access the menu item.', 'admin-site-enhancements' ), 
				$menu_required_capability 
				) 
			); ?>
			</div>
			<div id="always-show-for-users-for-<?php echo esc_attr( $menu_item_id_transformed ); ?>" class="always-show-for-users-options" data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>" data-menu-type="<?php echo esc_attr( $menu_type ); ?>" style="display:none;">
				<label for="always-show-for-users-select-<?php echo esc_attr( $menu_item_id_transformed ); ?>"><?php esc_html_e( 'Always show for the following users', 'admin-site-enhancements' ); ?></label>
				<input
					id="always-show-for-users-select-<?php echo esc_attr( $menu_item_id_transformed ); ?>"
					class="amo-user-exclusions-select"
					data-menu-item-id="<?php echo esc_attr( $menu_item_id_transformed ); ?>"
					data-menu-type="<?php echo esc_attr( $menu_type ); ?>"
					data-required-capability="<?php echo esc_attr( $menu_required_capability ); ?>"
					data-selected-users="<?php echo esc_attr( wp_json_encode( $always_show_user_choices ) ); ?>"
					type="hidden"
					value="<?php echo esc_attr( implode( ',', array_keys( $always_show_user_options ) ) ); ?>"
					style="width:100%;"
				/>
			</div>
		</div><!-- end of .menu-item-settings -->
    	<?php
	}
	
	/**
	 * Check if a menu item is a custom menu added via "Add menu" or "Add separator"
	 * 
	 * @since 6.9.13
	 */
	public function is_custom_menu_item__premium_only( $menu_item_id ) {
        $options_extra = get_option( ASENHA_SLUG_U . '_extra', array() );
        $options = isset( $options_extra['admin_menu'] ) ? $options_extra['admin_menu'] : array();
		
		// Get custom menu items added via "Add separator"
        $new_separators = isset( $options['custom_menu_new_separators'] ) ? $options['custom_menu_new_separators'] : '';
        $new_separators = json_decode( $new_separators, true );
        if ( is_array( $new_separators ) ) {
	        $new_separators_menu_ids = array_keys( $new_separators ); // e.g. array( 'separator5', 'separator6' )
        } else {
        	$new_separators_menu_ids = array();
        }

		// Get custom menu items added via "Add menu"
        $new_menus = isset( $options['custom_menu_new_items'] ) ? $options['custom_menu_new_items'] : '';
        $new_menus = json_decode( $new_menus, true );
        if ( is_array( $new_menus ) ) {
	        $new_menus_menu_ids = array_keys( $new_menus ); // e.g. array( 'custom-menu-1', 'custom-submenu-1' )
        } else {
        	$new_menus_menu_ids = array();
        }

		if ( in_array( $menu_item_id, $new_separators_menu_ids ) || in_array( $menu_item_id, $new_menus_menu_ids ) ) {
			return 'yes';
		} else {
			return 'no';
		}		
	}

	/**
	 * Get custom menu item data (URL, capability, icon)
	 * 
	 * @since 7.x.x
	 */
	public function get_custom_menu_item_data__premium_only( $menu_item_id ) {
		$options_extra = get_option( ASENHA_SLUG_U . '_extra', array() );
		$options = isset( $options_extra['admin_menu'] ) ? $options_extra['admin_menu'] : array();
		
		$new_menus = isset( $options['custom_menu_new_items'] ) ? $options['custom_menu_new_items'] : '';
		$new_menus = json_decode( $new_menus, true );
		
		if ( is_array( $new_menus ) && isset( $new_menus[$menu_item_id] ) ) {
			return $new_menus[$menu_item_id];
		}
		
		return null;
	}

	/**
	 * Check if custom submenu items exist for a parent menu
	 * 
	 * @param string $parent_menu_id The parent menu ID (slug)
	 * @param array $custom_menu_items The custom menu items array
	 * @return bool True if custom submenus exist, false otherwise
	 * @since 7.10.0
	 */
	private function has_custom_submenus__premium_only( $parent_menu_id, $custom_menu_items ) {
		if ( ! is_array( $custom_menu_items ) || empty( $custom_menu_items ) ) {
			return false;
		}
		
		foreach ( $custom_menu_items as $item_id => $item_info ) {
			if ( isset( $item_info['parent_id'] ) && $item_info['parent_id'] === $parent_menu_id ) {
				return true;
			}
		}
		
		return false;
	}

	/**
	 * Render textarea field as sub-field of a toggle/switcher checkbox
	 *
	 * @since 2.3.0
	 */
	function render_datatable( $args ) {

		global $wpdb;

		$option_name = $args['option_name'];
		
		if ( ! empty( $option_name ) ) {
			$options = get_option( $option_name, array() );
		} else {
			$options = get_option( ASENHA_SLUG_U, array() );		
		}

		$field_id = $args['field_id'];
		$field_slug = $args['field_slug'];
		$field_name = $args['field_name'];
		$field_type = $args['field_type'];
		$field_description = $args['field_description'];
		$table_title = $args['table_title'];
		$table_name = $args['table_name'];
		$field_option_value = ( isset( $options[$args['field_id']] ) ) ? $options[$args['field_id']] : '';

		$login_fails_allowed      = isset( $options['login_fails_allowed'] ) ? (int) $options['login_fails_allowed'] : 3;
		$login_lockout_maxcount   = isset( $options['login_lockout_maxcount'] ) ? (int) $options['login_lockout_maxcount'] : 3;
		$login_fails_allowed      = ( $login_fails_allowed > 0 ) ? $login_fails_allowed : 3;
		$login_lockout_maxcount   = ( $login_lockout_maxcount > 0 ) ? $login_lockout_maxcount : 3;
		$default_lockout_period   = 60 * 15; // 15 minutes in seconds.
		$extended_lockout_period  = 24 * 60 * 60; // 24 hours in seconds.
		$now                      = time();

		$ip_address_whitelist = array();
		if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
			$ip_address_whitelist_raw = isset( $options['limit_login_attempts_ip_whitelist'] ) ? $options['limit_login_attempts_ip_whitelist'] : '';
			$ip_address_whitelist_raw = is_string( $ip_address_whitelist_raw ) ? $ip_address_whitelist_raw : '';
			$ip_address_whitelist_parsed = preg_split( "/\r\n|\r|\n/", $ip_address_whitelist_raw );
			if ( is_array( $ip_address_whitelist_parsed ) && ! empty( $ip_address_whitelist_parsed ) ) {
				foreach ( $ip_address_whitelist_parsed as $ip_address ) {
					$ip_address = trim( $ip_address );
					if ( '' === $ip_address ) {
						continue;
					}
					$ip_address_whitelist[] = $ip_address;
				}
			}
		}

		?>
		<table id="login-attempts-log" class="wp-list-table widefat striped datatable">
			<thead>
				<tr class="datatable-tr">
					<th class="datatable-th"><?php _e( 'IP Address<br />Last Username', 'admin-site-enhancements' ); ?></th>
					<th class="datatable-th"><?php _e( 'Attempts<br />Lockouts', 'admin-site-enhancements' ); ?></th>
					<th class="datatable-th"><?php _e( 'Last Attempt On', 'admin-site-enhancements' ); ?></th>
					<th class="datatable-th"><?php _e( 'Actions', 'admin-site-enhancements' ); ?></th>
				</tr>
			</thead>
			<tbody>
		<?php

		$limit = 1000;

		$sql = $wpdb->prepare( "SELECT * FROM {$table_name} ORDER BY unixtime DESC LIMIT %d", array( $limit ) );

		$entries = $wpdb->get_results( $sql, ARRAY_A );

		foreach( $entries as $entry ) {

			$unixtime = $entry['unixtime'];
			$ip_address = isset( $entry['ip_address'] ) ? (string) $entry['ip_address'] : '';
			$fail_count = isset( $entry['fail_count'] ) ? (int) $entry['fail_count'] : 0;
			$lockout_count = isset( $entry['lockout_count'] ) ? (int) $entry['lockout_count'] : 0;

			$locked_condition = ( $fail_count > 0 && ( $fail_count % $login_fails_allowed === 0 ) );
			$is_extended_lockout = ( $lockout_count >= $login_lockout_maxcount );
			$lockout_period = $is_extended_lockout ? $extended_lockout_period : $default_lockout_period;
			$is_locked_out = ( $locked_condition && ( ( $now - (int) $unixtime ) <= $lockout_period ) );
			$is_whitelisted = in_array( $ip_address, $ip_address_whitelist, true );

			if ( function_exists( 'wp_date' ) ) {
				$date = wp_date( 'F j, Y', $unixtime );
				$time = wp_date( 'H:i:s', $unixtime );
			} else {
				$date = date_i18n( 'F j, Y', $unixtime );
				$time = date_i18n( 'H:i:s', $unixtime );
			}
			?>
			<tr class="datatable-tr">
				<td class="datatable-td"><?php echo esc_html( $ip_address ); ?><br /><?php echo esc_html( $entry['username'] ); ?></td>
				<td class="datatable-td"><?php echo esc_html( $fail_count ); ?><br /><?php echo esc_html( $lockout_count ); ?></td>
				<td class="datatable-td"><span class="unixtime"><?php echo esc_html( $entry['unixtime'] ); ?></span><?php echo esc_html( $date ); ?><br /><?php echo esc_html( $time ); ?></td>
				<td class="datatable-td">
					<?php if ( $is_locked_out && ! $is_whitelisted ) : ?>
						<a href="#" class="button button-secondary button-small asenha-release-login-lock" data-ip-address="<?php echo esc_attr( $ip_address ); ?>"><?php _e( 'Release Lock', 'admin-site-enhancements' ); ?></a>
					<?php endif; ?>
					<?php
					if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
						if ( $is_whitelisted ) {
							?>
							<span class="asenha-whitelisted-indicator"><span class="asenha-whitelisted-check">✓</span> <span class="asenha-whitelisted-text"><?php esc_html_e( 'Whitelisted', 'admin-site-enhancements' ); ?></span></span>
							<?php
						} else {
							?>
							<a href="#" class="button button-secondary button-small asenha-whitelist-login-ip" data-ip-address="<?php echo esc_attr( $ip_address ); ?>"><?php _e( 'Whitelist', 'admin-site-enhancements' ); ?></a>
							<?php
						}
					}
					?>
				</td>
			</tr>
			<?php
		}

		?>
			</tbody>
		</table>
		<?php

		echo '<div class="asenha-subfield-description">' . esc_html( $field_description ) . '</div>';
		echo '<input type="hidden" id="' . esc_attr( $field_name ) . '" class="asenha-subfield-datatable" name="' . esc_attr( $field_name ) . '" value="' . esc_attr( $field_option_value ) . '">';
	}
	
	/**
	 * Render checks and status for AVIF support
	 * 
	 * @link https://php.watch/versions/8.1/gd-avif
	 * @since 5.7.0
	 */
	public function render_avif_support_status() {
		
		// Check status of GD extension and it's AVIF support

		if ( extension_loaded( 'gd' ) && function_exists( 'gd_info' ) ) {
			$is_gd_enabled = true;
			$gd_info = gd_info();
			$gd_version = $gd_info['GD Version'];
			$gd_avif_support = ( isset( $gd_info['AVIF Support'] ) ) ? isset( $gd_info['AVIF Support'] ) : false ;
			if ( $gd_avif_support ) {
				$gd_status = $gd_version . ' <span class="supported">' . __( 'with AVIF support', 'admin-site-enhancements' ) . '</span>';
			} else {
				$gd_status = $gd_version . ' <span class="unsupported">' . __( 'without AVIF support', 'admin-site-enhancements' ) . '</span>';				
			}
		} else {
			$is_gd_enabled = false;
			$gd_avif_support = false;
			$gd_status = __( 'Not available', 'admin-site-enhancements' );
		}

		// Check status of ImageMagick library and it's AVIF support
		
		if ( extension_loaded( 'imagick' ) && class_exists( 'Imagick' ) ) {
			$is_imagick_enabled = true;
			$imagick_version = \Imagick::getVersion();
			
			if ( preg_match( '/((?:[0-9]+\.?)+)/', $imagick_version['versionString'], $matches ) ) {
				$imagick_version = $matches[0];
			} else {
				$imagick_version = $imagick_version['versionString'];			
			}
						
			if ( version_compare( $imagick_version, '7.0.25', '>=' ) ) {
				$imagick_avif_support = true;
				$imagick_status = $imagick_version . ' <span class="supported">with AVIF support</span>';
			} else {
				$imagick_avif_support = false;
				$imagick_status = $imagick_version . ' <span class="unsupported">without AVIF support</span>';
			}

		} else {
			$is_imagick_enabled = false;
			$imagick_avif_support = false;
			$imagick_status = __( 'Not available', 'admin-site-enhancements' );
		}

		echo '<div class="asenha-subfield-status">';
		echo '<div class="status-title">' . __( 'AVIF Support Status', 'admin-site-enhancements' ) . '</div>';
		echo '<div class="status-body">';
		echo '<div class="status-item"><span class="status-item-title">PHP</span> : ' . wp_kses_post( phpversion() ) . '</div>';
		echo '<div class="status-item"><span class="status-item-title">GD</span> : ' . wp_kses_post( $gd_status ) . '</div>';
		echo '<div class="status-item"><span class="status-item-title">ImageMagick</span> : ' . wp_kses_post( $imagick_status) . '</div>';
		echo '</div>';
		echo '<div class="status-footer">' . __( 'Full AVIF support requires that your server / hosting has <a href="https://php.watch/versions/8.1/gd-avif" target="_blank">GD extension</a> compiled with AVIF support in PHP 8.1 or greater, or, <a href="https://web.archive.org/web/20240104012918/https://avif.io/blog/tutorials/imagemagick/" target="_blank">ImageMagick 7.0.25 or greater</a> installed. Without either, you can still upload AVIF files but without auto-generation of the smaller thumbnail sizes. A majority of <a href="https://web.archive.org/web/20231207174740/https://avif.io/blog/articles/avif-browser-support/" target="_blank">modern desktop and mobile browsers</a> support the display of AVIF files.', 'admin-site-enhancements' ) . '</div>';
		echo '</div>';
	}

}