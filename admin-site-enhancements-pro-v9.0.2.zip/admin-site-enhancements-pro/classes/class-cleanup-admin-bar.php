<?php

namespace ASENHA\Classes;

/**
 * Class for Clean Up Admin Bar module
 *
 * @since 6.9.5
 */
class Cleanup_Admin_Bar {

    /**
     * Node ID prefix for Admin Bar Custom Elements (Pro). Must match generateItemId() in assets/premium/js/admin-bar-custom-elements.js.
     *
     * @var string
     */
    const ADMIN_BAR_CUSTOM_ELEMENTS_NODE_ID_PREFIX = 'asenha-ab-';

    /**
     * Modify admin bar menu for Admin Interface >> Hide or Modify Elements feature
     *
     * @param $wp_admin_bar object The admin bar.
     * @link https://wordpress.stackexchange.com/a/12652
     * @since 1.9.0
     */
    public function modify_admin_bar_menu( $wp_admin_bar ) {
        $options = get_option( ASENHA_SLUG_U, array() );

        // Hide WP Logo Menu
        if ( array_key_exists( 'hide_ab_wp_logo_menu', $options ) && $options['hide_ab_wp_logo_menu'] ) {
            remove_action( 'admin_bar_menu', 'wp_admin_bar_wp_menu', 10 ); // priority needs to match default value. Use QM to reference.
        }
        
        // Hide home icon and site name
        if ( array_key_exists( 'hide_ab_site_menu', $options ) && $options['hide_ab_site_menu'] ) {
            remove_action( 'admin_bar_menu', 'wp_admin_bar_site_menu', 30 ); // priority needs to match default value. Use QM to reference.
        }

        // Hide Customize Menu
        if ( array_key_exists( 'hide_ab_customize_menu', $options ) && $options['hide_ab_customize_menu'] ) {
            remove_action( 'admin_bar_menu', 'wp_admin_bar_customize_menu', 40 ); // priority needs to match default value. Use QM to reference.
        }

        // Hide Updates Counter/Link
        if ( array_key_exists( 'hide_ab_updates_menu', $options ) && $options['hide_ab_updates_menu'] ) {
            remove_action( 'admin_bar_menu', 'wp_admin_bar_updates_menu', 50 ); // priority needs to match default value. Use QM to reference.
        }

        // Hide Comments Counter/Link
        if ( array_key_exists( 'hide_ab_comments_menu', $options ) && $options['hide_ab_comments_menu'] ) {
            remove_action( 'admin_bar_menu', 'wp_admin_bar_comments_menu', 60 ); // priority needs to match default value. Use QM to reference.
        }

        // Hide New Content Menu
        if ( array_key_exists( 'hide_ab_new_content_menu', $options ) && $options['hide_ab_new_content_menu'] ) {
            remove_action( 'admin_bar_menu', 'wp_admin_bar_new_content_menu', 70 ); // priority needs to match default value. Use QM to reference.
        }
    }

    /**
     * Remove 'Howdy' (or localized greeting) from admin bar's account item.
     *
     * Runs on wp_before_admin_bar_render (priority 100) so the final title is set
     * after third-party Howdy removers that comma-split the title and can shred
     * avatar srcset HTML (e.g. Divi Assistant's pac_da_custom_admin_bar_user_name).
     *
     * Does not remove_action wp_admin_bar_my_account_item or rebuild the account tree;
     * only updates the existing my-account node title/meta via add_node merge.
     *
     * @since 7.3.1
     * @since 8.9.x Avoid remove_action rebuild; set core-compatible title after third parties.
     */
    public function remove_howdy() {
        $options = get_option( ASENHA_SLUG_U, array() );

        if ( ! array_key_exists( 'hide_ab_howdy', $options ) || ! $options['hide_ab_howdy'] ) {
            return;
        }

        global $wp_admin_bar;

        if ( ! $wp_admin_bar instanceof \WP_Admin_Bar ) {
            return;
        }

        $node = $wp_admin_bar->get_node( 'my-account' );
        if ( ! $node ) {
            return;
        }

        $current_user = wp_get_current_user();
        $user_id      = get_current_user_id();
        $display_name = $current_user->display_name;
        $avatar       = get_avatar( $user_id, 26 );

        // Core-compatible markup without the greeting; keeps display-name span + avatar intact.
        $title = '<span class="display-name">' . $display_name . '</span>' . $avatar;

        $wp_admin_bar->add_node(
            array(
                'id'    => 'my-account',
                'title' => $title,
                'meta'  => array(
                    'menu_title' => $display_name,
                ),
            )
        );
    }
    
    /** 
     * Get admin bar nodes
     * 
     * @since 6.2.1
     */
    public function capture_extra_admin_bar_nodes__premium_only() {
        global $wp_admin_bar;
        $nodes = $wp_admin_bar->get_nodes();

        // Exclude nodes already handled by free version of ASE
        $excluded_main_nodes = array(
            'menu-toggle',
            'wp-logo',
            'site-name',
            'updates',
            'comments',
            'new-content',
            'customize',
            'top-secondary',
        );
        
        $excluded_secondary_nodes = array(
            'my-account',
        );
        
        $options = get_option( ASENHA_SLUG_U . '_extra', array() );
        $workable_nodes = ( isset( $options['ab_nodes_workable'] ) ) ? $options['ab_nodes_workable'] : array();

        // Drop Admin Bar Custom Elements nodes from stored list (they are managed under Settings → Admin Bar).
        foreach ( array_keys( $workable_nodes ) as $stored_id ) {
            if ( 0 === strpos( $stored_id, self::ADMIN_BAR_CUSTOM_ELEMENTS_NODE_ID_PREFIX ) ) {
                unset( $workable_nodes[ $stored_id ] );
            }
        }

        foreach( $nodes as $node_id => $node_obj ) {
            if ( 0 === strpos( $node_id, self::ADMIN_BAR_CUSTOM_ELEMENTS_NODE_ID_PREFIX ) ) {
                continue;
            }
            $node = (array) $node_obj;
            // Some plugins set top-level node parent to null (e.g. Paymattic / wp-payment-form).
            $is_top_level = ( false === $node['parent'] || '' === $node['parent'] || null === $node['parent'] );
            // Only work with nodes that are not excluded and are parent nodes or direct child of the top-secondary node, 
            // the container for ab items in the right hand side of the admin bar
            if ( ( ! in_array( $node_id, $excluded_main_nodes ) && $is_top_level )
                || ( ! in_array( $node_id, $excluded_secondary_nodes ) && 'top-secondary' == $node['parent'] )
            ) {
                $workable_nodes[$node_id] = $node;
                if ( 'edit' == $node_id ) {
                    $workable_nodes[$node_id]['title'] = __( 'Edit Page / Post / CPT', 'admin-site-enhancements' );
                }
            }           
        }

        $options['ab_nodes_workable'] = $workable_nodes;
        update_option( ASENHA_SLUG_U . '_extra', $options, true );

    }
        
    /**
     * Maybe remove extra admin bar menu items, e.g. tbose added by other plugins
     * 
     * @link https://wpdirectory.net/search/01H8R48FDDSGN9HX5PP880Q8RD
     * @since 5.7.0
     */
    public function remove_extra_admin_bar_nodes__premium_only() {
        global $wp_admin_bar;
        $nodes = $wp_admin_bar->get_nodes();

        $options = get_option( ASENHA_SLUG_U, array() );
        $disabled_plugins_admin_bar_items = ( isset( $options['disabled_plugins_admin_bar_items'] ) ) ? $options['disabled_plugins_admin_bar_items'] : array();
        
        $wp_admin_bar_nodes = $wp_admin_bar->get_nodes();
        
        foreach( $disabled_plugins_admin_bar_items as $disabled_ab_item => $ab_item_is_disabled ) {
            if ( in_array( $disabled_ab_item, array_keys( $wp_admin_bar_nodes ) ) && $ab_item_is_disabled ) {
                $wp_admin_bar->remove_menu( $disabled_ab_item );
            }
        }
        
    }

    /**
     * Hide the Help tab and drawer
     *
     * @since 4.5.0
     */
    public function hide_help_drawer() {
        if ( is_admin() ) {
            $screen = get_current_screen();
            $screen->remove_help_tabs();
        }
    }

    /**
     * Clear stored workable admin bar nodes so they can be re-detected.
     *
     * Used by Admin Interface >> Clean Up Admin Bar >> Rescan Extra Elements button.
     *
     * @since 8.0.2
     */
    public function rescan_admin_bar_nodes__premium_only() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error(
                array(
                    'message' => __( 'You are not allowed to do this.', 'admin-site-enhancements' ),
                ),
                403
            );
        }

        $nonce = isset( $_REQUEST['nonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) ) : '';
        if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'asenha-' . get_current_user_id() ) ) {
            wp_send_json_error(
                array(
                    'message' => __( 'Invalid request.', 'admin-site-enhancements' ),
                ),
                403
            );
        }

        $options_extra = get_option( ASENHA_SLUG_U . '_extra', array() );

        if ( isset( $options_extra['ab_nodes_workable'] ) ) {
            unset( $options_extra['ab_nodes_workable'] );
            update_option( ASENHA_SLUG_U . '_extra', $options_extra, true );
        }

        wp_send_json_success(
            array(
                'cleared' => true,
            )
        );
    }
        
}