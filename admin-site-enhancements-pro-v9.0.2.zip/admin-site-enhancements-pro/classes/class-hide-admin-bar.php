<?php

namespace ASENHA\Classes;

/**
 * Class for Hide Admin Bar module
 *
 * @since 6.9.5
 */
class Hide_Admin_Bar {

	/**
	 * Whether the current user should see the frontend admin bar per Hide Admin Bar role rules.
	 *
	 * @since 8.9.0
	 * @return bool True when the toolbar should display on the frontend.
	 */
	public function is_frontend_admin_bar_visible_for_current_user() {

		$options = get_option( ASENHA_SLUG_U );
		if ( ! is_array( $options ) ) {
			return false;
		}

		$for_roles_frontend = isset( $options['hide_admin_bar_for'] ) ? $options['hide_admin_bar_for'] : array();
		$always_show_for_admins_on_frontend = isset( $options['hide_admin_bar_always_show_for_admins'] ) ? $options['hide_admin_bar_always_show_for_admins'] : false;

		$current_user       = wp_get_current_user();
		$current_user_roles = (array) $current_user->roles;

		if ( count( $current_user_roles ) === 0 ) {
			return false;
		}

		if (
			in_array( 'administrator', $current_user_roles, true )
			&& $always_show_for_admins_on_frontend
		) {
			return true;
		}

		if ( isset( $for_roles_frontend ) && count( $for_roles_frontend ) > 0 ) {

			$roles_admin_bar_hidden_frontend = array();

			foreach ( $for_roles_frontend as $role_slug => $admin_bar_hidden ) {
				if ( $admin_bar_hidden ) {
					$roles_admin_bar_hidden_frontend[] = $role_slug;
				}
			}

			foreach ( $current_user_roles as $role ) {
				if ( in_array( $role, $roles_admin_bar_hidden_frontend, true ) ) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Hide admin bar on the frontend for the user roles selected
	 *
	 * @since 1.3.0
	 * @param bool $show Default visibility from WordPress.
	 * @return bool
	 */
	public function hide_admin_bar_for_roles_on_frontend( $show = true ) {

		if ( ! $show ) {
			return false;
		}

		return $this->is_frontend_admin_bar_visible_for_current_user();
	}

	/**
	 * Enqueue frontend assets for auto-collapsing the toolbar into a toggle control (Pro).
	 *
	 * @since 8.9.0
	 */
	public function maybe_enqueue_frontend_auto_collapse__premium_only() {

		if ( ! bwasenha_fs()->can_use_premium_code__premium_only() ) {
			return;
		}

		$options = get_option( ASENHA_SLUG_U );
		if ( ! is_array( $options ) ) {
			return;
		}

		if ( ! array_key_exists( 'hide_admin_bar', $options ) ) {
			return;
		}

		if ( ! $options['hide_admin_bar'] ) {
			return;
		}

		if ( ! isset( $options['hide_admin_bar_auto_collapse_toggle'] ) ) {
			return;
		}

		if ( ! $options['hide_admin_bar_auto_collapse_toggle'] ) {
			return;
		}

		if ( is_admin() ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			return;
		}

		if ( is_customize_preview() ) {
			return;
		}

		if ( ! $this->is_frontend_admin_bar_visible_for_current_user() ) {
			return;
		}

		wp_enqueue_style(
			'asenha-hide-admin-bar-auto-collapse',
			ASENHA_URL . 'assets/premium/css/hide-admin-bar-auto-collapse.css',
			array(),
			ASENHA_VERSION
		);

		wp_enqueue_script(
			'asenha-hide-admin-bar-auto-collapse',
			ASENHA_URL . 'assets/premium/js/hide-admin-bar-auto-collapse.js',
			array(),
			ASENHA_VERSION,
			true
		);

		$asenha_abac_storage_key = 'asenha_ab_ac_tb_' . get_current_blog_id() . '_' . get_current_user_id();

		/* translators: Accessible label for the toolbar toggle when the toolbar is collapsed. */
		$asenha_abac_expand_label = __( 'Show toolbar', 'admin-site-enhancements' );
		/* translators: Accessible label for the toolbar toggle when the toolbar is expanded. */
		$asenha_abac_collapse_label = __( 'Hide toolbar', 'admin-site-enhancements' );

		wp_localize_script(
			'asenha-hide-admin-bar-auto-collapse',
			'asenhaHideAdminBarAutoCollapse',
			array(
				'storageKey'         => $asenha_abac_storage_key,
				'animationSpeed'     => 100,
				'delay'              => 200,
				'interval'           => 100,
				'showToggle'         => true,
				'showArrow'          => true,
				'arrowPosition'      => 'left',
				'hideOnSmallScreens' => true,
				'smallScreenMaxPx'   => 782,
				'i18n'               => array(
					'expandToolbar'   => $asenha_abac_expand_label,
					'collapseToolbar' => $asenha_abac_collapse_label,
				),
			)
		);

		wp_add_inline_script(
			'asenha-hide-admin-bar-auto-collapse',
			'window.asenhaHideAdminBarAutoCollapse = window.asenhaHideAdminBarAutoCollapse || {};'
			. 'if ( ! window.asenhaHideAdminBarAutoCollapse.storageKey ) { window.asenhaHideAdminBarAutoCollapse.storageKey = ' . wp_json_encode( $asenha_abac_storage_key ) . '; }',
			'before'
		);
	}

	/**
	 * Hide admin bar on the backend for the user roles selected
	 *
	 * @since 6.1.3
	 */
	public function hide_admin_bar_for_roles_on_backend__premium_only() {

		$options = get_option( ASENHA_SLUG_U );
		$hide_admin_bar = $options['hide_admin_bar'];
		$for_roles_backend = $options['hide_admin_bar_on_backend_for'];
		$always_show_for_admins_on_backend = isset( $options['hide_admin_bar_always_show_for_admins_on_backend'] ) ? $options['hide_admin_bar_always_show_for_admins_on_backend'] : false;

		$current_user = wp_get_current_user();
		$current_user_roles = (array) $current_user->roles; // single dimensional array of role slugs

		// User has no role, i.e. logged-out

		if ( count( $current_user_roles ) == 0 ) {
			return;
		}

		// Maybe show admin bar if user is an administrator.
		// Useful when an administrator has multiple roles and the admin bar is hidden for another role.
		if (
			in_array( 'administrator', $current_user_roles, true )
			&& $always_show_for_admins_on_backend
		) {
			return;
		}

		if ( isset( $for_roles_backend ) && ( count( $for_roles_backend ) > 0 ) ) {

			// Assemble single-dimensional array of roles for which admin bar would be hidden

			$roles_admin_bar_hidden_backend = array();

			foreach ( $for_roles_backend as $role_slug => $admin_bar_hidden ) {
				if ( $admin_bar_hidden ) {
					$roles_admin_bar_hidden_backend[] = $role_slug;
				}
			}

			foreach ( $current_user_roles as $role ) {
				if ( in_array( $role, $roles_admin_bar_hidden_backend, true ) ) {
					?>
					<style type="text/css" media="screen">
						html.wp-toolbar {
							padding-top: 0;
						}
						#wpadminbar {
							display: none;
						}
					</style>
					<?php
				}
			}

		}

	}

}
