<?php

namespace ASENHA\Classes;

/**
 * Class for Media Replacement module
 *
 * @since 6.9.5
 */
class Media_Replacement {

    /**
     * Modify the 'Edit' link to be 'Edit or Replace'
     * 
     */
    public function modify_media_list_table_edit_link( $actions, $post ) {

        $new_actions = array();

        foreach( $actions as $key => $value ) {

            if ( $key == 'edit' ) {

                $new_actions['edit'] = '<a href="' . get_edit_post_link( $post ) . '" aria-label="Edit or Replace">Edit or Replace</a>';

            } else {

                $new_actions[$key] = $value;

            }

        }

        return $new_actions;

    }
        
    /**
     * Register attachment_fields_to_edit filter on admin_init for reliable admin-ajax hookup.
     *
     * @since 7.9.0
     */
    public function register_attachment_fields_filter() {
        add_filter( 'attachment_fields_to_edit', [ $this, 'add_media_replacement_button' ], 10, 2 );
    }

    /**
     * Add media replacement button in the edit screen of media/attachment
     *
     * @since 1.1.0
     */
    public function add_media_replacement_button( $fields, $post ) {
        if ( ! is_admin() || $this->is_page_builder_context() ) {
            return $fields;
        }

        global $pagenow, $typenow;

        $is_attachment_edit = ( 'post.php' === $pagenow && 'attachment' === $typenow );
        $screen             = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        $is_media_library   = ( $screen && 'upload' === $screen->base );

        // Attachment edit screen, media library screen, or grid modal compat via upload.php AJAX only.
        if ( ! $is_attachment_edit && ! $is_media_library && ! $this->is_native_media_library_compat_ajax() ) {
            return $fields;
        }

        $original_attachment_id = '';
        $image_mime_type        = '';
        if ( is_object( $post ) ) {
            $original_attachment_id = $post->ID;
            if ( property_exists( $post, 'post_mime_type' ) ) {
                $image_mime_type = $post->post_mime_type;
            }
        }

        if ( $original_attachment_id ) {
            // Add new field to attachment fields for the media replace functionality
            // Conditional description based on Pro status
            if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
                $description = __( 'The current file will be replaced with the uploaded / selected file (of the same or different type) while retaining the current ID and publish date. All references in your database will be updated accordingly.', 'admin-site-enhancements' );
            } else {
                $description = __( 'The current file will be replaced with the uploaded / selected file (of the same type) while retaining the current ID, publish date and file name. Thus, no existing links will break.', 'admin-site-enhancements' );
            }
            
            $fields['asenha-media-replace'] = array();
            $fields['asenha-media-replace']['label'] = '';
            $fields['asenha-media-replace']['input'] = 'html';
            $fields['asenha-media-replace']['html'] = '
                <div id="media-replace-div' . '" class="postbox attachment-id-' . $original_attachment_id . '" data-original-image-id="' . $original_attachment_id . '">
                    <div class="postbox-header">
                        <h2 class="hndle ui-sortable-handle">' . __( 'Replace Media', 'admin-site-enhancements' ) . '</h2>
                    </div>
                    <div class="inside">
                    <button type="button" id="asenha-media-replace" class="button-secondary button-large asenha-media-replace-button" data-old-image-mime-type="' . $image_mime_type . '" onclick="replaceMedia(\'' . $original_attachment_id . '\',\'' . $image_mime_type . '\');">' . __( 'Select New Media File', 'admin-site-enhancements' ) . '</button>
                    <input type="hidden" id="new-attachment-id-' . $original_attachment_id . '" name="new-attachment-id-' . $original_attachment_id . '" />
                    <div class="asenha-media-replace-notes"><p>' . $description . '</p></div>
                    </div>
                </div>
            ';
        }

        return $fields;

    }
    
    public function attachment_for_js( $image_url, $attachment_id ) {
        // vi( $image_url );
        // vi( $attachment_id );
    }

    /**
     * Replace existing media with the newly updated file
     *
     * @link https://plugins.trac.wordpress.org/browser/replace-image/tags/1.1.7/hm-replace-image.php#L55
     * @since 1.1.0
     */
    public function replace_media( $old_attachment_id ) {
        // vi( $old_attachment_id, '', 'replace_media has been triggered via edit_attachment_hook' );

        // Get the new attachment/media ID, meta and mime type
        if ( isset( $_POST['new-attachment-id-'.$old_attachment_id] ) && ! empty( $_POST['new-attachment-id-'.$old_attachment_id] ) ) {
            $new_attachment_id = intval( sanitize_text_field( $_POST['new-attachment-id-'.$old_attachment_id] ) );
            // vi( $new_attachment_id, '', '$new_attachment_id is detected in replace_media' );

            // Verify the user has permission to delete the new attachment (source file for replacement)
            // This prevents unauthorized users from using another user's attachment as a replacement source
            // which would result in that attachment being deleted
            if ( ! current_user_can( 'delete_post', $new_attachment_id ) ) {
                return;
            }

            $old_post_meta = get_post( $old_attachment_id, ARRAY_A );
            $old_post_mime = $old_post_meta['post_mime_type']; // e.g. 'image/jpeg'
            // vi( $old_post_mime, '', 'old_post_mime is detected in replace_media' );

            $new_post_meta = get_post( $new_attachment_id, ARRAY_A );
            $new_post_mime = $new_post_meta['post_mime_type']; // e.g. 'image/jpeg'
            // vi( $new_post_mime, '', 'new_post_mime is detected in replace_media' );

            // Check if the media file ID selected via the media frame and passed on to the #new-attachment-id hidden field
            if ( ! empty( $new_attachment_id ) && is_numeric( $new_attachment_id ) ) {
                
                // Check if this is Pro version with advanced replacement flag
                if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
                    // Pro: Use advanced replacement (works for both same and different file types)
                    if ( isset( $_POST['asenha_advanced_replacement'] ) ) {
                        // We nest this under the Pro version check to make sure generation of free version doesn't include bwasenha_fs() check
                        $this->perform_advanced_replacement__premium_only( $old_attachment_id, $new_attachment_id, $old_post_mime, $new_post_mime );
                    }
                } elseif ( $old_post_mime == $new_post_mime ) {
                    // Free: Same-type replacement with simple approach
                    // vi( $new_attachment_id, '', 'We are processing the replacement of the old image.' );

                    $new_attachment_meta = wp_get_attachment_metadata( $new_attachment_id );

                    // If original file is larger than 2560 pixel
                    // https://make.wordpress.org/core/2019/10/09/introducing-handling-of-big-images-in-wordpress-5-3/
                    if ( is_array( $new_attachment_meta ) && array_key_exists( 'original_image', $new_attachment_meta ) ) {

                        // Get the original media file path
                        $new_media_file_path = wp_get_original_image_path( $new_attachment_id );

                    } else {

                        // Get the path to newly uploaded media file. An image file name may end with '-scaled'.
                        $new_attachment_file = get_post_meta( $new_attachment_id, '_wp_attached_file', true );
                        $upload_dir = wp_upload_dir();
                        $new_media_file_path = $upload_dir['basedir'] . '/' . $new_attachment_file;

                    }

                    // Check if the new media file exist / was successfully uploaded
                    if ( ! is_file( $new_media_file_path ) ) {
                        return false;
                    }

                    // Delete existing/old media files. Post and post meta entries for it are still there in the database.
                    $this->delete_media_files( $old_attachment_id );

                    // If original file is larger than 2560 pixel
                    // https://make.wordpress.org/core/2019/10/09/introducing-handling-of-big-images-in-wordpress-5-3/
                    if ( is_array( $new_attachment_meta ) && array_key_exists( 'original_image', $new_attachment_meta ) ) {

                        // Get the original media file path
                        $old_media_file_path = wp_get_original_image_path( $old_attachment_id );

                    } else {

                        // Get the path to the old/existing media file that will be replaced and deleted. An image file name may end with '-scaled'.
                        $old_attachment_file = get_post_meta( $old_attachment_id, '_wp_attached_file', true );
                        $old_media_file_path = $upload_dir['basedir'] . '/' . $old_attachment_file;

                    }

                    // Check if the directory path to the old media file is still intact
                    if ( ! file_exists( dirname( $old_media_file_path ) ) ) {

                        // Recreate the directory path
                        mkdir( dirname( $old_media_file_path ), 0755, true );

                    }

                    // Copy the new media file into the old media file's path
                    copy( $new_media_file_path, $old_media_file_path );

                    // Regenerate attachment meta data and image sub-sizes from the new media file that was just copied to the old path
                    $old_media_post_meta_updated = wp_generate_attachment_metadata( $old_attachment_id, $old_media_file_path );

                    // Update new media file's meta data with the ones from the old media. i.e. new media file will carry over the post ID and post meta of the old media file. i.e. only the files are replaced for the old media's ID and post meta in the database.
                    wp_update_attachment_metadata( $old_attachment_id, $old_media_post_meta_updated );

                    // Delete the newly uploaded media file and it's sub-sizes, and also delete post and post meta entries for it in the database.
                    wp_delete_attachment( $new_attachment_id, true );
                    
                    // Add old attachment ID to recently replaced media option. This will be used for cache busting to ensure the new replacement images are immediately loaded in the browser / wp-admin
                    $options_extra = get_option( ASENHA_SLUG_U . '_extra', array() );
                    $recently_replaced_media = isset( $options_extra['recently_replaced_media'] ) ? $options_extra['recently_replaced_media'] : array();
                    $max_media_number_to_cache_bust = 5;
                    // vi( $recently_replaced_media, '', 'before' );
                    if ( count( $recently_replaced_media ) >= $max_media_number_to_cache_bust ) {
                        // Remove first/oldest attachment ID
                        array_shift( $recently_replaced_media );
                    }
                    $recently_replaced_media[] = $old_attachment_id;
                    $recently_replaced_media = array_unique( $recently_replaced_media );
                    // vi( $recently_replaced_media, '', 'after' );
                    $options_extra['recently_replaced_media'] = $recently_replaced_media;
                    update_option( ASENHA_SLUG_U . '_extra', $options_extra, true );
                    sleep(2);
                    
                }
            }
        }
    }

    /**
     * Delete the existing/old media files when performing media replacement
     *
     * @link https://plugins.trac.wordpress.org/browser/replace-image/tags/1.1.7/hm-replace-image.php#L80
     * @since 1.1.0
     */
    public function delete_media_files( $post_id ) {

        $attachment_meta = wp_get_attachment_metadata( $post_id );

        // Will get '-scaled' version if it exists, e.g. /path/to/uploads/year/month/file-name.jpg
        $attachment_file_path = get_attached_file( $post_id ); 

        // e.g. file-name.jpg
        $attachment_file_basename = basename( $attachment_file_path );

        // Delete intermediate images if there are any
        
        if ( isset( $attachment_meta['sizes'] ) && is_array( $attachment_meta['sizes'] ) ) {

            foreach( $attachment_meta['sizes'] as $size => $size_info) {

                // /path/to/uploads/year/month/file-name.jpg --> /path/to/uploads/year/month/file-name-1024x768.jpg
                $intermediate_file_path = str_replace( $attachment_file_basename, $size_info['file'], $attachment_file_path );
                wp_delete_file( $intermediate_file_path );

            }

        }

        // Delete the attachment file, which maybe the '-scaled' version
        wp_delete_file( $attachment_file_path );

        // If original file is larger than 2560 pixel
        // https://make.wordpress.org/core/2019/10/09/introducing-handling-of-big-images-in-wordpress-5-3/
        $attachment_original_file_path = wp_get_original_image_path( $post_id );

        // Maybe delete the original file if it's an image file, and the original file path exists / was found
        if ( $attachment_original_file_path ) {
            wp_delete_file( $attachment_original_file_path );            
        }

    }

    /**
     * Customize the attachment updated message
     *
     * @link https://github.com/WordPress/wordpress-develop/blob/6.0.2/src/wp-admin/edit-form-advanced.php#L180
     * @since 1.1.0
     */
    public function attachment_updated_custom_message( $messages ) {

        $new_messages = array();

        foreach( $messages as $post_type => $messages_array ) {

            if ( $post_type == 'attachment' ) {

                // Message ID for successful edit/update of an attachment is 4. e.g. /wp-admin/post.php?post=a&action=edit&classic-editor&message=4 Customize it here.
                $messages_array[4] = 'Media file updated. You may need to <a href="https://fabricdigital.co.nz/blog/how-to-hard-refresh-your-browser-and-clear-cache" target="_blank">hard refresh</a> your browser to see the updated media preview image below.';

            }

            $new_messages[$post_type] = $messages_array;

        }

        return $new_messages;

    }
    
    /**
     * Append cache busting parameter to the end of image srcset
     * 
     * @since 5.7.0
     */
    public function append_cache_busting_param_to_image_srcset( $sources, $size_array, $image_src, $image_meta, $attachment_id ) {
        $options_extra = get_option( ASENHA_SLUG_U . '_extra', array() );
        $recently_replaced_media = isset( $options_extra['recently_replaced_media'] ) ? $options_extra['recently_replaced_media'] : array();
        $attachment_mime_type = get_post_mime_type( $attachment_id );

        if ( in_array( $attachment_id, $recently_replaced_media ) 
            && false !== strpos( $attachment_mime_type, 'image' )
        ) {
            foreach ( $sources as $size => $source ) {
                $source['url'] .= $this->maybe_append_timestamp_parameter( $source['url'] );
                $sources[$size] = $source;
                // vi( $source, '', 'cache busting added via append_cache_busting_param_to_image_srcset' );
            }
        }
        return $sources;
    }

    /**
     * Append cache busting parameter to the end of image src
     * 
     * @since 5.7.0
     */
    public function append_cache_busting_param_to_attachment_image_src( $image, $attachment_id ) {
        $options_extra = get_option( ASENHA_SLUG_U . '_extra', array() );
        $recently_replaced_media = isset( $options_extra['recently_replaced_media'] ) ? $options_extra['recently_replaced_media'] : array();
        $attachment_mime_type = get_post_mime_type( $attachment_id );

        if ( ! empty( $image[0] ) 
            && in_array( $attachment_id, $recently_replaced_media ) 
            && false !== strpos( $attachment_mime_type, 'image' )
        ) {
            $image[0] .= $this->maybe_append_timestamp_parameter( $image[0] );
            // vi( $image, '', 'cache busting added via append_cache_busting_param_to_attachment_image_src' );
         }

        return $image;
    }

    /**
     * Append cache busting parameter to image src for js
     * 
     * @since 5.7.0
     */
    public function append_cache_busting_param_to_attachment_for_js( $response, $attachment ) {
        $options_extra = get_option( ASENHA_SLUG_U . '_extra', array() );
        $recently_replaced_media = isset( $options_extra['recently_replaced_media'] ) ? $options_extra['recently_replaced_media'] : array();
        $attachment_mime_type = get_post_mime_type( $attachment->ID );

        if ( in_array( $attachment->ID, $recently_replaced_media ) 
            // && false !== strpos( $attachment_mime_type, 'image' )
        ) {
            if ( false !== strpos( $response['url'], '?' ) ) {
                $response['url'] .= $this->maybe_append_timestamp_parameter( $response['url'] );
                // vi( $response, '', 'cache busting added via append_cache_busting_param_to_attachment_for_js' );
            }
            if ( isset( $response['sizes'] ) ) {
                foreach ( $response['sizes'] as $size_name => $size ) {
                    $response['sizes'][$size_name]['url'] .= $this->maybe_append_timestamp_parameter( $size['url'] );
                    // vi( $response, '', 'cache busting added via append_cache_busting_param_to_attachment_for_js' );
                }
            }
        }

        return $response;
    }
    
    /**
     * Append cache busting parameter to attachment URL
     * 
     * @since 6.8.2
     */
    public function append_cache_busting_param_to_attachment_url( $url, $attachment_id ) {
        $options_extra = get_option( ASENHA_SLUG_U . '_extra', array() );
        $recently_replaced_media = isset( $options_extra['recently_replaced_media'] ) ? $options_extra['recently_replaced_media'] : array();
        $attachment_mime_type = get_post_mime_type( $attachment_id );

        if ( in_array( $attachment_id, $recently_replaced_media ) 
            // && false !== strpos( $attachment_mime_type, 'image' )
        ) {
            $url .= $this->maybe_append_timestamp_parameter( $url );
            // vi( $url, '', 'cache busting added via append_cache_busting_param_to_attachment_url' );
        }
        
        return $url;
    }
    
    /**
     * Maybe append timestamp parameter
     * 
     * @since 7.7
     */
    public function maybe_append_timestamp_parameter( $url ) {
        $parts = parse_url( $url );
        $additional_url_parameter = '';

        if ( isset( $parts['query'] ) ) {
            parse_str( $parts['query'], $query );

            if ( isset( $query['t'] ) && ! empty( $query['t'] ) ) {
                // Do not add another timestamp parameter
            } else {
                $additional_url_parameter = ( false === strpos( $url, '?' ) ? '?' : '&' ) . 't=' . time();
            }
            
        } else {
                $additional_url_parameter = ( false === strpos( $url, '?' ) ? '?' : '&' ) . 't=' . time();
        }

        return $additional_url_parameter;
    }

    /**
     * Whether the current request is in a page builder editor context.
     *
     * @since 7.9.0
     *
     * @return bool
     */
    private function is_page_builder_context() {
        $is_page_builder = false;

        $request_action = isset( $_REQUEST['action'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $core_media_ajax_actions = array( 'get-attachment', 'save-attachment-compat', 'query-attachments' );
        $skip_request_builder_keys = wp_doing_ajax() && in_array( $request_action, $core_media_ajax_actions, true );

        if ( ! $skip_request_builder_keys && ! empty( $_REQUEST ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            if ( 'elementor' === $request_action ) {
                $is_page_builder = true;
            } elseif ( isset( $_REQUEST['fl_builder'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $is_page_builder = true;
            } elseif ( isset( $_REQUEST['et_fb'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $is_page_builder = true;
            } elseif ( isset( $_REQUEST['ct_builder'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $is_page_builder = true;
            } elseif ( isset( $_REQUEST['vc_editable'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $is_page_builder = true;
            } elseif ( isset( $_REQUEST['vcv-editable'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $is_page_builder = true;
            } elseif ( isset( $_REQUEST['tve'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $is_page_builder = true;
            } elseif ( isset( $_REQUEST['bricks'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $is_page_builder = true;
            } elseif ( isset( $_REQUEST['breakdance'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $is_page_builder = true;
            } elseif ( isset( $_REQUEST['_cs_nonce'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $is_page_builder = true;
            } elseif (
                isset( $_REQUEST['tb-preview'], $_REQUEST['tb-id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            ) {
                $is_page_builder = true;
            }
        }

        if ( ! $is_page_builder ) {
            $referer = $this->get_media_replacement_request_referer();

            if ( $referer ) {
                $referer_patterns = array(
                    'action=elementor',
                    'fl_builder',
                    'et_fb=',
                    'ct_builder',
                    'vc_editable',
                    'vcv-editable',
                    'tve=',
                    'tb-preview=',
                    'bricks=',
                    'breakdance=',
                    'breakdance_builder',
                );

                foreach ( $referer_patterns as $pattern ) {
                    if ( false !== strpos( $referer, $pattern ) ) {
                        $is_page_builder = true;
                        break;
                    }
                }
            }
        }

        /**
         * Filters whether the current request is a page builder editor context.
         *
         * @since 7.9.0
         *
         * @param bool $is_page_builder Whether the request is from a page builder.
         */
        return (bool) apply_filters( 'asenha_media_replacement_is_page_builder_context', $is_page_builder );
    }

    /**
     * Whether this is a native Media Library compat AJAX request (upload.php).
     *
     * @since 7.9.0
     *
     * @return bool
     */
    private function is_native_media_library_compat_ajax() {
        if ( ! wp_doing_ajax() || $this->is_page_builder_context() ) {
            return false;
        }

        $action = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

        if ( ! in_array( $action, array( 'get-attachment', 'save-attachment-compat', 'query-attachments' ), true ) ) {
            return false;
        }

        $referer = $this->get_media_replacement_request_referer();

        if ( $referer ) {
            if ( false !== strpos( $referer, 'upload.php' ) ) {
                return true;
            }

            // Exclude classic/block post editor media modals.
            if ( false !== strpos( $referer, 'post.php' ) || false !== strpos( $referer, 'post-new.php' ) ) {
                return false;
            }
        }

        // Referer missing or non-upload admin URL: allow (Media Library often has no usable referer).
        return true;
    }

    /**
     * Referer URL for media replacement context checks.
     *
     * @since 7.9.0
     *
     * @return string
     */
    private function get_media_replacement_request_referer() {
        $referer = wp_get_referer();

        if ( ! $referer && ! empty( $_SERVER['HTTP_REFERER'] ) ) {
            $referer = esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) );
        }

        return is_string( $referer ) ? $referer : '';
    }
    
    /**
     * Get replacement analysis for advanced replacement (Pro only)
     * Works for both same-type and different-type replacements
     * 
     * @since 8.0.5
     */
    public function get_replacement_analysis__premium_only() {
        // Verify nonce
        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'asenha_media_replace_nonce' ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'admin-site-enhancements' ) ) );
        }
        
        // Check capabilities
        if ( ! current_user_can( 'upload_files' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'admin-site-enhancements' ) ) );
        }
        
        // Get attachment IDs
        $old_attachment_id = isset( $_POST['old_attachment_id'] ) ? intval( $_POST['old_attachment_id'] ) : 0;
        $new_attachment_id = isset( $_POST['new_attachment_id'] ) ? intval( $_POST['new_attachment_id'] ) : 0;
        
        if ( ! $old_attachment_id || ! $new_attachment_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid attachment IDs.', 'admin-site-enhancements' ) ) );
        }
        
        // Check user can edit the attachment
        if ( ! current_user_can( 'edit_post', $old_attachment_id ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to edit this attachment.', 'admin-site-enhancements' ) ) );
        }
        
        // Get file information
        $old_file_path = get_attached_file( $old_attachment_id );
        $new_file_path = get_attached_file( $new_attachment_id );
        
        $old_filename = basename( $old_file_path );
        $new_filename = basename( $new_file_path );
        
        $old_mime = get_post_mime_type( $old_attachment_id );
        $new_mime = get_post_mime_type( $new_attachment_id );
        
        // Build paired file lists (old and new files that can be properly matched)
        $file_pairs = $this->build_file_pairs__premium_only( 
            $old_attachment_id, 
            $new_attachment_id,
            $old_file_path,
            $new_file_path
        );
        
        $files_to_replace = $file_pairs['old_files'];
        $replacement_files = $file_pairs['new_files'];
        
        // Get posts using this attachment
        $affected_posts = $this->get_posts_using_attachment__premium_only( $old_attachment_id, $old_file_path );
        
        // Sort affected posts by post type label
        if ( ! empty( $affected_posts ) ) {
            usort( $affected_posts, function( $a, $b ) {
                return strcmp( $a['type_label'], $b['type_label'] );
            });
        }
        
        // Check for special usage
        $special_warnings = $this->check_special_usage__premium_only( $old_attachment_id, $old_file_path );
        
        // Check dimension differences
        $dimension_warning = $this->check_dimension_differences__premium_only( $old_attachment_id, $new_attachment_id );
        
        // Check if media files are images
        $old_is_image = strpos( $old_mime, 'image/' ) === 0;
        $new_is_image = strpos( $new_mime, 'image/' ) === 0;
        
        // Get preview URLs or icons based on media type
        if ( $old_is_image ) {
            // Get preview image URLs (prefer 'medium' size, fallback to full)
            $old_preview_url = wp_get_attachment_image_url( $old_attachment_id, 'medium' );
            if ( ! $old_preview_url ) {
                $old_preview_url = wp_get_attachment_image_url( $old_attachment_id, 'full' );
            }
        } else {
            // Get media icon for non-image files
            $old_preview_url = wp_mime_type_icon( $old_attachment_id );
        }
        
        if ( $new_is_image ) {
            // Get preview image URLs (prefer 'medium' size, fallback to full)
            $new_preview_url = wp_get_attachment_image_url( $new_attachment_id, 'medium' );
            if ( ! $new_preview_url ) {
                $new_preview_url = wp_get_attachment_image_url( $new_attachment_id, 'full' );
            }
        } else {
            // Get media icon for non-image files
            $new_preview_url = wp_mime_type_icon( $new_attachment_id );
        }
        
        // Get image dimensions (only for images)
        $old_metadata = wp_get_attachment_metadata( $old_attachment_id );
        $new_metadata = wp_get_attachment_metadata( $new_attachment_id );
        
        $old_dimensions = '';
        if ( $old_is_image && isset( $old_metadata['width'] ) && isset( $old_metadata['height'] ) ) {
            $old_dimensions = $old_metadata['width'] . ' x ' . $old_metadata['height'] . ' pixels';
        }
        
        $new_dimensions = '';
        if ( $new_is_image && isset( $new_metadata['width'] ) && isset( $new_metadata['height'] ) ) {
            $new_dimensions = $new_metadata['width'] . ' x ' . $new_metadata['height'] . ' pixels';
        }
        
        // Get old attachment post data for post_title and post_name
        $old_attachment_post = get_post( $old_attachment_id );
        $old_post_title = $old_attachment_post ? $old_attachment_post->post_title : '';
        $old_post_name = $old_attachment_post ? $old_attachment_post->post_name : '';
        
        $response_data = array(
            'old_filename'        => $old_filename,
            'new_filename'        => $new_filename,
            'old_mime'            => $old_mime,
            'new_mime'            => $new_mime,
            'old_dimensions'      => $old_dimensions,
            'new_dimensions'      => $new_dimensions,
            'old_is_image'        => $old_is_image,
            'new_is_image'        => $new_is_image,
            'same_mime_type'      => ( $old_mime === $new_mime ),
            'files_to_replace'    => $files_to_replace,
            'replacement_files'   => $replacement_files,
            'affected_posts'      => $affected_posts,
            'special_warnings'    => $special_warnings,
            'dimension_warning'   => $dimension_warning,
            'old_preview_url'     => $old_preview_url,
            'new_preview_url'     => $new_preview_url,
            'old_post_title'      => $old_post_title,
            'old_post_name'       => $old_post_name,
        );
        
        wp_send_json_success( $response_data );
    }
    
    /**
     * Build file pairs for database updates (Pro only)
     * Used during the actual replacement process after metadata has been regenerated
     * 
     * @since 8.0.5
     */
    private function build_file_pairs_for_database__premium_only( $old_metadata, $new_metadata, $old_extension, $new_extension, $old_basename_no_ext, $target_basename_no_ext ) {
        $pairs = array();
        
        // 1. Main file (this is the -scaled version if image was scaled)
        $pairs[ $old_basename_no_ext . '.' . $old_extension ] = $target_basename_no_ext . '.' . $new_extension;
        
        // 2. Handle scaled/original files
        // WordPress creates -scaled versions for images > 2560px
        $old_has_scaled = isset( $old_metadata['original_image'] );
        $new_has_scaled = isset( $new_metadata['original_image'] );
        
        if ( $old_has_scaled && $new_has_scaled ) {
            // Case 1: Both images are large (>2560px) and have scaled versions
            // Replace both the original and -scaled files
            $old_original = $old_metadata['original_image'];
            $new_original = $new_metadata['original_image'];
            $pairs[ $old_original ] = $new_original;
            
            // Also map old -scaled to new -scaled
            $old_scaled_filename = $old_basename_no_ext . '-scaled.' . $old_extension;
            $new_scaled_filename = $target_basename_no_ext . '-scaled.' . $new_extension;
            $pairs[ $old_scaled_filename ] = $new_scaled_filename;
        } elseif ( $old_has_scaled && ! $new_has_scaled ) {
            // Case 2 (EDGE CASE): Old large (>2560px), new smaller (<2560px)
            // Example: 3000x2000.jpg → 1500x1000.webp
            // Old files: image.jpg (original) + image-scaled.jpg (main)
            // New file: image.webp (only one file, no scaling)
            // Map both old files to the single new file
            $old_scaled_filename = $old_basename_no_ext . '-scaled.' . $old_extension;
            $new_full_filename = $target_basename_no_ext . '.' . $new_extension;
            $pairs[ $old_scaled_filename ] = $new_full_filename;
            
            // Also map the old original to the new full
            $old_original = $old_metadata['original_image'];
            $pairs[ $old_original ] = $new_full_filename;
        } elseif ( ! $old_has_scaled && $new_has_scaled ) {
            // Case 3: Old smaller (<2560px), new large (>2560px)
            // Example: 1500x1000.jpg → 3000x2000.webp
            // Old file: image.jpg (only one file)
            // New files: image.webp (original) + image-scaled.webp (main)
            // Map old single file to new -scaled (the main file)
            $old_full_filename = $old_basename_no_ext . '.' . $old_extension;
            $new_scaled_filename = $target_basename_no_ext . '-scaled.' . $new_extension;
            $pairs[ $old_full_filename ] = $new_scaled_filename;
        }
        
        // Intermediate sizes - only include if we can find a match
        if ( isset( $old_metadata['sizes'] ) && is_array( $old_metadata['sizes'] ) && 
             isset( $new_metadata['sizes'] ) && is_array( $new_metadata['sizes'] ) ) {
            
            foreach ( $old_metadata['sizes'] as $size_name => $old_size_data ) {
                $old_filename = $old_size_data['file'];
                $matched_new_file = null;
                
                // Strategy 1: Look for exact size name match
                if ( isset( $new_metadata['sizes'][$size_name] ) ) {
                    $matched_new_file = $new_metadata['sizes'][$size_name]['file'];
                } else {
                    // Strategy 2: For 2048px sizes, look for 2048px size in new image
                    $old_width = isset( $old_size_data['width'] ) ? $old_size_data['width'] : 0;
                    $old_height = isset( $old_size_data['height'] ) ? $old_size_data['height'] : 0;
                    $is_2048_size = ( $old_width === 2048 || $old_height === 2048 );
                    
                    if ( $is_2048_size ) {
                        foreach ( $new_metadata['sizes'] as $new_size_name => $new_size_data ) {
                            $new_width = isset( $new_size_data['width'] ) ? $new_size_data['width'] : 0;
                            $new_height = isset( $new_size_data['height'] ) ? $new_size_data['height'] : 0;
                            
                            if ( $new_width === 2048 || $new_height === 2048 ) {
                                $matched_new_file = $new_size_data['file'];
                                break;
                            }
                        }
                    }
                    
                    // Strategy 3: Find closest by dimensions
                    if ( ! $matched_new_file ) {
                        $min_distance = PHP_FLOAT_MAX;
                        $best_match = null;
                        
                        foreach ( $new_metadata['sizes'] as $new_size_name => $new_size_data ) {
                            $new_width = isset( $new_size_data['width'] ) ? $new_size_data['width'] : 0;
                            $new_height = isset( $new_size_data['height'] ) ? $new_size_data['height'] : 0;
                            
                            // Calculate Euclidean distance
                            $distance = sqrt( 
                                pow( $old_width - $new_width, 2 ) + 
                                pow( $old_height - $new_height, 2 ) 
                            );
                            
                            if ( $distance < $min_distance ) {
                                $min_distance = $distance;
                                $best_match = $new_size_data['file'];
                            }
                        }
                        
                        if ( $best_match ) {
                            $matched_new_file = $best_match;
                        }
                    }
                }
                
                // Only include this pair if we found a valid AND reasonable match
                // Skip matches where dimensions are too different (low confidence)
                if ( $matched_new_file ) {
                    $should_include = false;
                    
                    // Always include if exact size name match
                    if ( isset( $new_metadata['sizes'][$size_name] ) ) {
                        $should_include = true;
                    } else {
                        // For dimensional matches, check if they're reasonably close
                        // Find the matched size's dimensions
                        $matched_width = 0;
                        $matched_height = 0;
                        foreach ( $new_metadata['sizes'] as $new_size_data ) {
                            if ( $new_size_data['file'] === $matched_new_file ) {
                                $matched_width = isset( $new_size_data['width'] ) ? $new_size_data['width'] : 0;
                                $matched_height = isset( $new_size_data['height'] ) ? $new_size_data['height'] : 0;
                                break;
                            }
                        }
                        
                        // Calculate dimensional difference as percentage
                        $old_width = isset( $old_size_data['width'] ) ? $old_size_data['width'] : 0;
                        $old_height = isset( $old_size_data['height'] ) ? $old_size_data['height'] : 0;
                        
                        if ( $old_width > 0 && $old_height > 0 && $matched_width > 0 && $matched_height > 0 ) {
                            $width_diff_percent = abs( $matched_width - $old_width ) / $old_width;
                            $height_diff_percent = abs( $matched_height - $old_height ) / $old_height;
                            
                            // Include if dimensions are within 30% of each other
                            if ( $width_diff_percent <= 0.3 && $height_diff_percent <= 0.3 ) {
                                $should_include = true;
                            }
                        }
                    }
                    
                    if ( $should_include ) {
                        $pairs[ $old_filename ] = $matched_new_file;
                    }
                }
            }
        }
        
        return $pairs;
    }
    
    /**
     * Build paired file lists (Pro only)
     * Only includes files that exist in both old and new and can be properly matched
     * 
     * @since 8.0.5
     */
    private function build_file_pairs__premium_only( $old_attachment_id, $new_attachment_id, $old_file_path, $new_file_path ) {
        $old_files = array();
        $new_files = array();
        
        $old_metadata = wp_get_attachment_metadata( $old_attachment_id );
        $new_metadata = wp_get_attachment_metadata( $new_attachment_id );
        
        $old_file_info = pathinfo( $old_file_path );
        $new_file_info = pathinfo( $new_file_path );
        
        $old_extension = $old_file_info['extension'];
        $new_extension = $new_file_info['extension'];
        $file_basename_no_ext = $old_file_info['filename'];
        
        // Get upload directory info for building file paths
        $upload_dir = wp_upload_dir();
        $old_dir = dirname( $old_file_path );
        $new_dir = dirname( $new_file_path );
        
        // 1. Always include main file (this is the -scaled version if image was scaled)
        $old_main_filesize = file_exists( $old_file_path ) ? size_format( filesize( $old_file_path ), 2 ) : '';
        $new_main_filesize = file_exists( $new_file_path ) ? size_format( filesize( $new_file_path ), 2 ) : '';
        
        $old_files[] = array(
            'file' => basename( $old_file_path ),
            'size' => 'full',
            'filesize' => $old_main_filesize
        );
        $new_files[] = array(
            'file' => basename( $new_file_path ),
            'size' => 'full',
            'filesize' => $new_main_filesize
        );
        
        // 2. Include original file (unscaled full-size) only if both have it
        // This comes AFTER the main file, matching the order from get_files_to_replace__premium_only()
        $old_original = wp_get_original_image_path( $old_attachment_id );
        $new_original = wp_get_original_image_path( $new_attachment_id );
        
        if ( $old_original && $old_original !== $old_file_path && 
             $new_original && $new_original !== $new_file_path ) {
            $old_original_filesize = file_exists( $old_original ) ? size_format( filesize( $old_original ), 2 ) : '';
            $new_original_filesize = file_exists( $new_original ) ? size_format( filesize( $new_original ), 2 ) : '';
            
            $old_files[] = array(
                'file' => basename( $old_original ),
                'size' => 'original',
                'filesize' => $old_original_filesize
            );
            $new_files[] = array(
                'file' => basename( $new_original ),
                'size' => 'original',
                'filesize' => $new_original_filesize
            );
        }
        
        // Process intermediate sizes
        if ( isset( $old_metadata['sizes'] ) && is_array( $old_metadata['sizes'] ) && 
             isset( $new_metadata['sizes'] ) && is_array( $new_metadata['sizes'] ) ) {
            
            foreach ( $old_metadata['sizes'] as $size_name => $old_size_data ) {
                // Try to find the best match for this old size in the new sizes
                $matched_new_file = null;
                $matched_new_size_name = null;
                
                // Strategy 1: Look for exact size name match
                if ( isset( $new_metadata['sizes'][$size_name] ) ) {
                    $matched_new_file = $new_metadata['sizes'][$size_name]['file'];
                    $matched_new_size_name = $size_name;
                } else {
                    // Strategy 2: For 2048px sizes, look for 2048px size in new image
                    $old_width = isset( $old_size_data['width'] ) ? $old_size_data['width'] : 0;
                    $old_height = isset( $old_size_data['height'] ) ? $old_size_data['height'] : 0;
                    $is_2048_size = ( $old_width === 2048 || $old_height === 2048 );
                    
                    if ( $is_2048_size ) {
                        foreach ( $new_metadata['sizes'] as $new_size_name => $new_size_data ) {
                            $new_width = isset( $new_size_data['width'] ) ? $new_size_data['width'] : 0;
                            $new_height = isset( $new_size_data['height'] ) ? $new_size_data['height'] : 0;
                            
                            if ( $new_width === 2048 || $new_height === 2048 ) {
                                $matched_new_file = $new_size_data['file'];
                                $matched_new_size_name = $new_size_name;
                                break;
                            }
                        }
                    }
                    
                    // Strategy 3: Find closest by dimensions
                    if ( ! $matched_new_file ) {
                        $min_distance = PHP_FLOAT_MAX;
                        $best_match = null;
                        $best_match_name = null;
                        
                        foreach ( $new_metadata['sizes'] as $new_size_name => $new_size_data ) {
                            $new_width = isset( $new_size_data['width'] ) ? $new_size_data['width'] : 0;
                            $new_height = isset( $new_size_data['height'] ) ? $new_size_data['height'] : 0;
                            
                            // Calculate Euclidean distance
                            $distance = sqrt( 
                                pow( $old_width - $new_width, 2 ) + 
                                pow( $old_height - $new_height, 2 ) 
                            );
                            
                            if ( $distance < $min_distance ) {
                                $min_distance = $distance;
                                $best_match = $new_size_data['file'];
                                $best_match_name = $new_size_name;
                            }
                        }
                        
                        if ( $best_match ) {
                            $matched_new_file = $best_match;
                            $matched_new_size_name = $best_match_name;
                        }
                    }
                }
                
                // Only include this pair if we found a valid AND reasonable match
                // Skip matches where dimensions are too different (low confidence)
                if ( $matched_new_file ) {
                    $should_include = false;
                    
                    // Always include if exact size name match
                    if ( isset( $new_metadata['sizes'][$size_name] ) ) {
                        $should_include = true;
                    } else {
                        // For dimensional matches, check if they're reasonably close
                        // Find the matched size's dimensions
                        $matched_width = 0;
                        $matched_height = 0;
                        foreach ( $new_metadata['sizes'] as $new_size_data ) {
                            if ( $new_size_data['file'] === $matched_new_file ) {
                                $matched_width = isset( $new_size_data['width'] ) ? $new_size_data['width'] : 0;
                                $matched_height = isset( $new_size_data['height'] ) ? $new_size_data['height'] : 0;
                                break;
                            }
                        }
                        
                        // Calculate dimensional difference as percentage
                        $old_width = isset( $old_size_data['width'] ) ? $old_size_data['width'] : 0;
                        $old_height = isset( $old_size_data['height'] ) ? $old_size_data['height'] : 0;
                        
                        if ( $old_width > 0 && $old_height > 0 && $matched_width > 0 && $matched_height > 0 ) {
                            $width_diff_percent = abs( $matched_width - $old_width ) / $old_width;
                            $height_diff_percent = abs( $matched_height - $old_height ) / $old_height;
                            
                            // Include if dimensions are within 30% of each other
                            if ( $width_diff_percent <= 0.3 && $height_diff_percent <= 0.3 ) {
                                $should_include = true;
                            }
                        }
                    }
                    
                    if ( $should_include ) {
                        // Get file sizes for intermediate sizes
                        $old_intermediate_path = $old_dir . '/' . $old_size_data['file'];
                        $old_intermediate_filesize = file_exists( $old_intermediate_path ) ? size_format( filesize( $old_intermediate_path ), 2 ) : '';
                        
                        $new_intermediate_path = $new_dir . '/' . $matched_new_file;
                        $new_intermediate_filesize = file_exists( $new_intermediate_path ) ? size_format( filesize( $new_intermediate_path ), 2 ) : '';
                        
                        $old_files[] = array(
                            'file' => $old_size_data['file'],
                            'size' => $size_name,
                            'filesize' => $old_intermediate_filesize
                        );
                        $new_files[] = array(
                            'file' => $matched_new_file,
                            'size' => $matched_new_size_name,
                            'filesize' => $new_intermediate_filesize
                        );
                    }
                }
            }
        }
        
        return array(
            'old_files' => $old_files,
            'new_files' => $new_files
        );
    }
    
    /**
     * Get list of files to be replaced (Pro only)
     * 
     * @since 8.0.5
     */
    private function get_files_to_replace__premium_only( $attachment_id ) {
        $files = array();
        
        // Get main file
        $main_file = get_attached_file( $attachment_id );
        if ( $main_file ) {
            $files[] = basename( $main_file );
        }
        
        // Get original file if exists (for images > 2560px)
        $original_file = wp_get_original_image_path( $attachment_id );
        if ( $original_file && $original_file !== $main_file ) {
            $files[] = basename( $original_file );
        }
        
        // Get intermediate sizes
        $attachment_meta = wp_get_attachment_metadata( $attachment_id );
        if ( isset( $attachment_meta['sizes'] ) && is_array( $attachment_meta['sizes'] ) ) {
            foreach ( $attachment_meta['sizes'] as $size => $size_info ) {
                if ( isset( $size_info['file'] ) ) {
                    $files[] = $size_info['file'];
                }
            }
        }
        
        return $files;
    }
    
    /**
     * Get posts using the attachment (Pro only)
     * 
     * @since 8.0.5
     */
    private function get_posts_using_attachment__premium_only( $attachment_id, $file_path ) {
        global $wpdb;
        
        $affected_posts = array();
        $upload_dir = wp_upload_dir();
        $file_url = str_replace( $upload_dir['basedir'], $upload_dir['baseurl'], $file_path );
        $file_basename = basename( $file_path );
        $file_basename_no_ext = pathinfo( $file_basename, PATHINFO_FILENAME );
        
        // Search in post_content and post_excerpt across all relevant post statuses
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $posts = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DISTINCT ID, post_title, post_type, post_status 
                FROM {$wpdb->posts} 
                WHERE post_status IN ('publish', 'draft', 'pending', 'private', 'future')
                AND (post_content LIKE %s OR post_excerpt LIKE %s)
                LIMIT 50",
                '%' . $wpdb->esc_like( $file_basename_no_ext ) . '%',
                '%' . $wpdb->esc_like( $file_basename_no_ext ) . '%'
            )
        );
        
        if ( $posts ) {
            foreach ( $posts as $post ) {
                // Get human-readable post type label
                $post_type_object = get_post_type_object( $post->post_type );
                $post_type_label = $post_type_object ? $post_type_object->labels->singular_name : ucfirst( $post->post_type );
                
                // Get human-readable status label
                $status_labels = array(
                    'publish' => __( 'Published', 'admin-site-enhancements' ),
                    'draft'   => __( 'Draft', 'admin-site-enhancements' ),
                    'pending' => __( 'Pending', 'admin-site-enhancements' ),
                    'private' => __( 'Private', 'admin-site-enhancements' ),
                    'future'  => __( 'Scheduled', 'admin-site-enhancements' ),
                );
                $status_label = isset( $status_labels[ $post->post_status ] ) ? $status_labels[ $post->post_status ] : ucfirst( $post->post_status );
                
                $affected_posts[] = array(
                    'id'          => $post->ID,
                    'title'       => $post->post_title ? $post->post_title : __( '(no title)', 'admin-site-enhancements' ),
                    'permalink'   => get_permalink( $post->ID ),
                    'edit_url'    => get_edit_post_link( $post->ID ),
                    'type'        => $post->post_type,
                    'type_label'  => $post_type_label,
                    'status'      => $post->post_status,
                    'status_label'=> $status_label,
                );
            }
        }
        
        // Also check for posts where this is the featured image
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $featured_posts = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT p.ID, p.post_title, p.post_type, p.post_status 
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                WHERE pm.meta_key = '_thumbnail_id'
                AND pm.meta_value = %d
                AND p.post_status IN ('publish', 'draft', 'pending', 'private', 'future')",
                $attachment_id
            )
        );
        
        if ( $featured_posts ) {
            foreach ( $featured_posts as $post ) {
                // Check if not already in the list
                $already_added = false;
                foreach ( $affected_posts as $existing_post ) {
                    if ( $existing_post['id'] === $post->ID ) {
                        $already_added = true;
                        break;
                    }
                }
                
                if ( ! $already_added ) {
                    // Get human-readable post type label
                    $post_type_object = get_post_type_object( $post->post_type );
                    $post_type_label = $post_type_object ? $post_type_object->labels->singular_name : ucfirst( $post->post_type );
                    
                    // Get human-readable status label
                    $status_labels = array(
                        'publish' => __( 'Published', 'admin-site-enhancements' ),
                        'draft'   => __( 'Draft', 'admin-site-enhancements' ),
                        'pending' => __( 'Pending', 'admin-site-enhancements' ),
                        'private' => __( 'Private', 'admin-site-enhancements' ),
                        'future'  => __( 'Scheduled', 'admin-site-enhancements' ),
                    );
                    $status_label = isset( $status_labels[ $post->post_status ] ) ? $status_labels[ $post->post_status ] : ucfirst( $post->post_status );
                    
                    $affected_posts[] = array(
                        'id'          => $post->ID,
                        'title'       => $post->post_title ? $post->post_title : __( '(no title)', 'admin-site-enhancements' ),
                        'permalink'   => get_permalink( $post->ID ),
                        'edit_url'    => get_edit_post_link( $post->ID ),
                        'type'        => $post->post_type,
                        'type_label'  => $post_type_label,
                        'status'      => $post->post_status,
                        'status_label'=> $status_label,
                    );
                }
            }
        }
        
        return $affected_posts;
    }
    
    /**
     * Check for special usage of attachment (Pro only)
     * 
     * @since 8.0.5
     */
    private function check_special_usage__premium_only( $attachment_id, $file_path ) {
        global $wpdb;
        
        $warnings = array();
        $file_basename = basename( $file_path );
        $file_basename_no_ext = pathinfo( $file_basename, PATHINFO_FILENAME );
        
        // Check widgets
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $widget_count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) 
                FROM {$wpdb->options} 
                WHERE option_name LIKE 'widget_%'
                AND option_value LIKE %s",
                '%' . $wpdb->esc_like( $file_basename_no_ext ) . '%'
            )
        );
        
        if ( $widget_count > 0 ) {
            $warnings[] = sprintf(
                /* translators: %d: number of widgets */
                __( 'This media is used in %d widget(s).', 'admin-site-enhancements' ),
                $widget_count
            );
        }
        
        // Check nav menus
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $menu_count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) 
                FROM {$wpdb->posts} 
                WHERE post_type = 'nav_menu_item'
                AND post_content LIKE %s",
                '%' . $wpdb->esc_like( $file_basename_no_ext ) . '%'
            )
        );
        
        if ( $menu_count > 0 ) {
            $warnings[] = sprintf(
                /* translators: %d: number of menu items */
                __( 'This media is used in %d menu item(s).', 'admin-site-enhancements' ),
                $menu_count
            );
        }
        
        // Check customizer settings
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $customizer_count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) 
                FROM {$wpdb->options} 
                WHERE option_name LIKE 'theme_mods_%'
                AND option_value LIKE %s",
                '%' . $wpdb->esc_like( $file_basename_no_ext ) . '%'
            )
        );
        
        if ( $customizer_count > 0 ) {
            $warnings[] = __( 'This media may be used in theme customizer settings.', 'admin-site-enhancements' );
        }
        
        return $warnings;
    }
    
    /**
     * Check dimension differences between old and new images (Pro only)
     * 
     * @since 8.0.5
     */
    private function check_dimension_differences__premium_only( $old_attachment_id, $new_attachment_id ) {
        $old_meta = wp_get_attachment_metadata( $old_attachment_id );
        $new_meta = wp_get_attachment_metadata( $new_attachment_id );
        
        if ( ! isset( $old_meta['width'] ) || ! isset( $old_meta['height'] ) ||
             ! isset( $new_meta['width'] ) || ! isset( $new_meta['height'] ) ) {
            return '';
        }
        
        $old_width = $old_meta['width'];
        $old_height = $old_meta['height'];
        $new_width = $new_meta['width'];
        $new_height = $new_meta['height'];
        
        // Calculate aspect ratios
        $old_ratio = $old_width / $old_height;
        $new_ratio = $new_width / $new_height;
        
        // If aspect ratios differ by more than 5%
        if ( abs( $old_ratio - $new_ratio ) / $old_ratio > 0.05 ) {
            return sprintf(
                /* translators: 1: old dimensions, 2: new dimensions */
                __( 'Aspect ratio change detected: %1$s → %2$s. Thumbnails will be regenerated with the new aspect ratio.', 'admin-site-enhancements' ),
                $old_width . 'x' . $old_height,
                $new_width . 'x' . $new_height
            );
        }
        
        // If dimensions significantly different (more than 20% change in either dimension)
        $width_change = abs( $new_width - $old_width ) / $old_width;
        $height_change = abs( $new_height - $old_height ) / $old_height;
        
        if ( $width_change > 0.2 || $height_change > 0.2 ) {
            return sprintf(
                /* translators: 1: old dimensions, 2: new dimensions */
                __( 'Significant dimension change: %1$s → %2$s', 'admin-site-enhancements' ),
                $old_width . 'x' . $old_height,
                $new_width . 'x' . $new_height
            );
        }
        
        return '';
    }
    
    /**
     * Perform advanced media replacement (Pro only)
     * Works for both same-type and different-type replacements
     * 
     * @since 8.0.5
     */
    private function perform_advanced_replacement__premium_only( $old_attachment_id, $new_attachment_id, $old_post_mime, $new_post_mime ) {
        $upload_dir = wp_upload_dir();
        
        // Get file paths
        $old_file_path = get_attached_file( $old_attachment_id );
        $new_file_path = get_attached_file( $new_attachment_id );
        
        // Get file info
        $old_file_info = pathinfo( $old_file_path );
        $new_file_info = pathinfo( $new_file_path );
        
        // Store old file information for database updates
        $old_filename = basename( $old_file_path );
        $old_extension = $old_file_info['extension'];
        $new_extension = $new_file_info['extension'];
        
        // Store old metadata before deleting files (needed for intelligent size mapping)
        $old_metadata = wp_get_attachment_metadata( $old_attachment_id );
        
        // Check if old file has -scaled suffix (for images > 2560px)
        $old_basename = $old_file_info['filename'];
        $has_scaled_suffix = ( substr( $old_basename, -7 ) === '-scaled' );
        
        // If the old file had -scaled suffix, remove it for the new file
        // WordPress will add it back if the new image is large enough
        if ( $has_scaled_suffix ) {
            $old_basename_without_scaled = substr( $old_basename, 0, -7 );
        } else {
            $old_basename_without_scaled = $old_basename;
        }
        
        // Determine target filename based on preserve_filename flag
        // Check if we should preserve the old filename (only applicable for same mime type)
        $preserve_filename = isset( $_POST['asenha_preserve_filename'] ) && sanitize_text_field( wp_unslash( $_POST['asenha_preserve_filename'] ) ) === '1';
        $same_mime_type = ( $old_post_mime === $new_post_mime );
        
        if ( $preserve_filename && $same_mime_type ) {
            // Preserve old filename completely (basename + extension)
            $target_basename = $old_basename_without_scaled;
            $target_extension = $old_extension;
        } else {
            // Use new filename (default for Pro version)
            $new_basename = $new_file_info['filename'];
            // Remove -scaled suffix from new file if present
            if ( substr( $new_basename, -7 ) === '-scaled' ) {
                $target_basename = substr( $new_basename, 0, -7 );
            } else {
                $target_basename = $new_basename;
            }
            $target_extension = $new_extension;
        }
        
        // Build final filename with target basename and extension
        $final_filename = $target_basename . '.' . $target_extension;
        $new_file_path_renamed = $old_file_info['dirname'] . '/' . $final_filename;
        
        // Check if directory exists
        if ( ! file_exists( $old_file_info['dirname'] ) ) {
            mkdir( $old_file_info['dirname'], 0755, true );
        }
        
        // Verify new file exists before we start
        if ( ! file_exists( $new_file_path ) ) {
            return;
        }
        
        // CRITICAL: Use temporary file approach (inspired by Enable Media Replace)
        // Copy new file to a safe temporary location FIRST
        $temp_file = $new_file_info['dirname'] . '/asenha_temp_' . time() . '_' . wp_generate_password( 8, false ) . '.' . $new_extension;
        if ( ! copy( $new_file_path, $temp_file ) ) {
            // Temp copy failed - abort
            return;
        }
        
        // Immediately delete the new attachment to prevent any interference
        // This is the key: remove it from WordPress completely before file operations
        wp_delete_attachment( $new_attachment_id, true );
        
        // Clear WordPress object cache to ensure no stale references
        wp_cache_flush();
        
        // Now delete the old media files
        $this->delete_media_files( $old_attachment_id );
        
        // Copy from temp file to final location
        if ( ! copy( $temp_file, $new_file_path_renamed ) ) {
            // Copy failed - try to restore from temp
            copy( $temp_file, $new_file_path_renamed );
            wp_delete_file( $temp_file );
            return;
        }
        
        // Clean up temp file
        wp_delete_file( $temp_file );
        
        // Verify the file is in place before proceeding
        if ( ! file_exists( $new_file_path_renamed ) ) {
            // File is missing - critical error
            return;
        }
        
        // Update _wp_attached_file to point to the new file
        // This should be a relative path from uploads directory
        $old_attached_file = get_post_meta( $old_attachment_id, '_wp_attached_file', true );
        if ( $old_attached_file ) {
            $old_attached_file_info = pathinfo( $old_attached_file );
            $new_attached_file = $old_attached_file_info['dirname'] . '/' . $final_filename;
        } else {
            // Fallback: calculate relative path from uploads directory
            $new_attached_file = str_replace( trailingslashit( $upload_dir['basedir'] ), '', $new_file_path_renamed );
        }
        update_post_meta( $old_attachment_id, '_wp_attached_file', $new_attached_file );
        
        // Update post_mime_type
        wp_update_post( array(
            'ID' => $old_attachment_id,
            'post_mime_type' => $new_post_mime,
        ) );
        
        // Check if we should update post_title and post_name based on replacement filename
        $update_post_title_name = isset( $_POST['asenha_update_post_title_name'] ) && sanitize_text_field( wp_unslash( $_POST['asenha_update_post_title_name'] ) ) === '1';
        
        if ( $update_post_title_name ) {
            // Get the NEW file's basename (from the uploaded/selected replacement file)
            // Remove -scaled suffix if present to get the actual uploaded filename
            $new_file_basename = $new_file_info['filename'];
            if ( substr( $new_file_basename, -7 ) === '-scaled' ) {
                $new_file_basename = substr( $new_file_basename, 0, -7 );
            }
            
            // Derive new post_title (filename without extension, as-is)
            $new_post_title = $new_file_basename;
            
            // Derive new post_name using sanitize_title()
            $new_post_name = sanitize_title( $new_file_basename );
            
            // Update post_title and post_name
            wp_update_post( array(
                'ID' => $old_attachment_id,
                'post_title' => $new_post_title,
                'post_name' => $new_post_name,
            ) );
        }
        
        // Regenerate attachment metadata with new file
        // WordPress will create a -scaled version if the image is > 2560px
        // and update _wp_attached_file automatically
        $new_metadata = wp_generate_attachment_metadata( $old_attachment_id, $new_file_path_renamed );
        wp_update_attachment_metadata( $old_attachment_id, $new_metadata );
        
        // Build file pairs for database updates (must be done after regenerating metadata)
        // Pass both old and target basenames for proper mapping
        $file_pairs_for_db = $this->build_file_pairs_for_database__premium_only( 
            $old_metadata,
            $new_metadata,
            $old_extension,
            $target_extension,
            $old_basename_without_scaled,
            $target_basename
        );
        
        // Update database references using pre-built file pairs
        $affected_posts = $this->update_database_references__premium_only( 
            $old_attachment_id, 
            $file_pairs_for_db
        );
        
        // Note: New attachment was already deleted early (before file operations)
        // to prevent any WordPress interference with our file manipulations
        
        // Store data for post-replacement notice
        $user_id = get_current_user_id();
        $transient_key = 'asenha_media_replacement_notice_' . $user_id;
        set_transient( $transient_key, array(
            'old_filename' => $old_filename,
            'new_filename' => $final_filename,
            'affected_posts' => $affected_posts,
        ), 60 );
        
        // Add to cache busting list
        $options_extra = get_option( ASENHA_SLUG_U . '_extra', array() );
        $recently_replaced_media = isset( $options_extra['recently_replaced_media'] ) ? $options_extra['recently_replaced_media'] : array();
        $max_media_number_to_cache_bust = 5;
        if ( count( $recently_replaced_media ) >= $max_media_number_to_cache_bust ) {
            array_shift( $recently_replaced_media );
        }
        $recently_replaced_media[] = $old_attachment_id;
        $recently_replaced_media = array_unique( $recently_replaced_media );
        $options_extra['recently_replaced_media'] = $recently_replaced_media;
        update_option( ASENHA_SLUG_U . '_extra', $options_extra, true );
    }
    
    /**
     * Update database references for advanced replacement (Pro only)
     * Works for both same-type and different-type replacements
     * 
     * @since 8.0.5
     */
    private function update_database_references__premium_only( $attachment_id, $replacements ) {
        global $wpdb;
        
        $affected_posts = array();
        
        // Update post_content and post_excerpt
        foreach ( $replacements as $old_filename => $new_filename ) {
            // Search for posts containing this filename
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $posts = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT ID, post_title, post_content, post_excerpt, post_type, post_status 
                    FROM {$wpdb->posts} 
                    WHERE (post_content LIKE %s OR post_excerpt LIKE %s)
                    AND post_status != 'trash'",
                    '%' . $wpdb->esc_like( $old_filename ) . '%',
                    '%' . $wpdb->esc_like( $old_filename ) . '%'
                )
            );
            
            if ( $posts ) {
                foreach ( $posts as $post ) {
                    $updated = false;
                    $new_content = $post->post_content;
                    $new_excerpt = $post->post_excerpt;
                    
                    // Replace in content
                    if ( strpos( $post->post_content, $old_filename ) !== false ) {
                        $new_content = str_replace( $old_filename, $new_filename, $post->post_content );
                        $updated = true;
                    }
                    
                    // Replace in excerpt
                    if ( strpos( $post->post_excerpt, $old_filename ) !== false ) {
                        $new_excerpt = str_replace( $old_filename, $new_filename, $post->post_excerpt );
                        $updated = true;
                    }
                    
                    if ( $updated ) {
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                        $wpdb->update(
                            $wpdb->posts,
                            array(
                                'post_content' => $new_content,
                                'post_excerpt' => $new_excerpt,
                            ),
                            array( 'ID' => $post->ID ),
                            array( '%s', '%s' ),
                            array( '%d' )
                        );
                        
                        // Add to affected posts list using post ID as key to prevent duplicates
                        if ( ! isset( $affected_posts[ $post->ID ] ) ) {
                            $permalink = get_permalink( $post->ID );
                            
                            // Skip posts with '?p=' parameter (usually drafts or permalink issues)
                            if ( strpos( $permalink, '?p=' ) !== false ) {
                                continue;
                            }
                            
                            // Get human-readable post type label
                            $post_type_object = get_post_type_object( $post->post_type );
                            $post_type_label = $post_type_object ? $post_type_object->labels->singular_name : ucfirst( $post->post_type );
                            
                            // Get human-readable status label
                            $status_labels = array(
                                'publish' => __( 'Published', 'admin-site-enhancements' ),
                                'draft'   => __( 'Draft', 'admin-site-enhancements' ),
                                'pending' => __( 'Pending', 'admin-site-enhancements' ),
                                'private' => __( 'Private', 'admin-site-enhancements' ),
                                'future'  => __( 'Scheduled', 'admin-site-enhancements' ),
                            );
                            $status_label = isset( $status_labels[ $post->post_status ] ) ? $status_labels[ $post->post_status ] : ucfirst( $post->post_status );
                            
                            $affected_posts[ $post->ID ] = array(
                                'id'          => $post->ID,
                                'title'       => $post->post_title ? $post->post_title : __( '(no title)', 'admin-site-enhancements' ),
                                'permalink'   => $permalink,
                                'edit_url'    => get_edit_post_link( $post->ID ),
                                'type'        => $post->post_type,
                                'type_label'  => $post_type_label,
                                'status'      => $post->post_status,
                                'status_label'=> $status_label,
                            );
                        }
                    }
                }
            }
        }
        
        // Update postmeta (custom fields)
        foreach ( $replacements as $old_filename => $new_filename ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $postmeta = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT meta_id, post_id, meta_value 
                    FROM {$wpdb->postmeta} 
                    WHERE meta_value LIKE %s",
                    '%' . $wpdb->esc_like( $old_filename ) . '%'
                )
            );
            
            if ( $postmeta ) {
                foreach ( $postmeta as $meta ) {
                    if ( strpos( $meta->meta_value, $old_filename ) !== false ) {
                        $new_meta_value = str_replace( $old_filename, $new_filename, $meta->meta_value );
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                        $wpdb->update(
                            $wpdb->postmeta,
                            array( 'meta_value' => $new_meta_value ),
                            array( 'meta_id' => $meta->meta_id ),
                            array( '%s' ),
                            array( '%d' )
                        );
                    }
                }
            }
        }
        
        // Update options (widgets, customizer, etc.)
        foreach ( $replacements as $old_filename => $new_filename ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $options = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT option_id, option_name, option_value 
                    FROM {$wpdb->options} 
                    WHERE option_value LIKE %s
                    AND (option_name LIKE 'widget_%' OR option_name LIKE 'theme_mods_%')",
                    '%' . $wpdb->esc_like( $old_filename ) . '%'
                )
            );
            
            if ( $options ) {
                foreach ( $options as $option ) {
                    if ( strpos( $option->option_value, $old_filename ) !== false ) {
                        $new_option_value = str_replace( $old_filename, $new_filename, $option->option_value );
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                        $wpdb->update(
                            $wpdb->options,
                            array( 'option_value' => $new_option_value ),
                            array( 'option_id' => $option->option_id ),
                            array( '%s' ),
                            array( '%d' )
                        );
                    }
                }
            }
        }
        
        // Convert associative array to indexed array (remove post ID keys)
        $affected_posts = array_values( $affected_posts );
        
        // Sort affected posts by post type label
        if ( ! empty( $affected_posts ) ) {
            usort( $affected_posts, function( $a, $b ) {
                return strcmp( $a['type_label'], $b['type_label'] );
            });
        }
        
        return $affected_posts;
    }
    
    /**
     * Show post-replacement notice (Pro only)
     * 
     * @since 8.0.5
     */
    public function show_replacement_notice__premium_only() {
        $user_id = get_current_user_id();
        $transient_key = 'asenha_media_replacement_notice_' . $user_id;
        $notice_data = get_transient( $transient_key );
        
        if ( ! $notice_data ) {
            return;
        }
        
        // Delete transient
        delete_transient( $transient_key );
        
        $old_filename = isset( $notice_data['old_filename'] ) ? $notice_data['old_filename'] : '';
        $new_filename = isset( $notice_data['new_filename'] ) ? $notice_data['new_filename'] : '';
        $affected_posts = isset( $notice_data['affected_posts'] ) ? $notice_data['affected_posts'] : array();
        
        ?>
        <div class="notice notice-success is-dismissible asenha-media-replacement-notice">
            <p><strong><?php esc_html_e( 'Media file replaced successfully!', 'admin-site-enhancements' ); ?></strong></p>
            <p>
                <code><?php echo esc_html( $old_filename ); ?></code> 
                → 
                <code><?php echo esc_html( $new_filename ); ?></code>
            </p>
            <?php if ( ! empty( $affected_posts ) ) : ?>
                <p><strong><?php esc_html_e( 'The following posts were updated:', 'admin-site-enhancements' ); ?></strong></p>
                <ul style="list-style: disc; margin-left: 20px;">
                    <?php foreach ( $affected_posts as $post ) : ?>
                        <li>
                            <strong>[<?php echo esc_html( $post['type_label'] ); ?>]</strong>
                            <a href="<?php echo esc_url( $post['permalink'] ); ?>" target="_blank">
                                <?php echo esc_html( $post['title'] ); ?>
                            </a>
                            <em>(<?php echo esc_html( $post['status_label'] ); ?>)</em>
                            | <a href="<?php echo esc_url( $post['edit_url'] ); ?>" style="text-decoration: none;">
                                <?php esc_html_e( 'Edit', 'admin-site-enhancements' ); ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else : ?>
                <p><?php esc_html_e( 'No posts were affected by this replacement.', 'admin-site-enhancements' ); ?></p>
            <?php endif; ?>
        </div>
        <?php
    }
    
}