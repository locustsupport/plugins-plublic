<?php

namespace ASENHA\Classes;

use WP_Error;

/**
 * Class for Disable REST API module
 *
 * @since 6.9.5
 */
class Disable_REST_API {

    /**
     * REST API access gate (runs after core authentication handlers).
     *
     * Role checks use the logged-in auth cookie when core has cleared the current user
     * for requests without an X-WP-Nonce (see rest_cookie_check_errors at priority 100).
     *
     * @since 2.9.0
     *
     * @param WP_Error|null|true $errors Prior filter value from rest_authentication_errors.
     * @return WP_Error|null|true
     */
    public function disable_rest_api( $errors ) {

        // Respect prior filter callbacks — e.g. core incorrect_password or rest_cookie_invalid_nonce.
        if ( is_wp_error( $errors ) ) {
            return $errors;
        }

        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            $options = get_option( ASENHA_SLUG_U, array() );

            // Get roles allowed to access REST API while logged-in
            if ( ! function_exists( 'get_editable_roles' ) ) {
                require_once ABSPATH . 'wp-admin/includes/user.php';
            }
            
            $for_roles_all = array();
            $all_roles = get_editable_roles();
            $all_roles = array_keys( $all_roles ); // single dimensional array of all role slugs
            foreach ( $all_roles as $role ) {
                $for_roles_all[$role] = true;
            }
            
            $for_roles = isset( $options['enable_rest_api_for'] ) ? $options['enable_rest_api_for'] : $for_roles_all;
            $roles_rest_api_access_enabled = array();

            // Assemble single-dimensional array of roles for which duplication would be enabled
            if ( is_array( $for_roles ) && ( count( $for_roles ) > 0 ) ) {
                foreach( $for_roles as $role_slug => $rest_api_access_enabled ) {
                    if ( $rest_api_access_enabled ) {
                        $roles_rest_api_access_enabled[] = $role_slug;
                    }
                }
            }

            // Get REST API routes excluded from access blockage.
            // Normalize to internal rest_route format (no URL prefix, no trailing slash).
            $excluded_api_routes_raw = ( isset( $options['disable_rest_api_excluded_routes'] ) ) ? explode( PHP_EOL, $options['disable_rest_api_excluded_routes'] ) : array();
            $excluded_api_routes = array();
            if ( ! empty( $excluded_api_routes_raw ) ) {
                $rest_url_prefix = rest_get_url_prefix() . '/';
                foreach ( $excluded_api_routes_raw as $excluded_api_route ) {
                    $cleaned = trim( $excluded_api_route );
                    if ( '' === $cleaned ) {
                        continue;
                    }
                    $cleaned = ltrim( $cleaned, '/' );
                    if ( 0 === strpos( $cleaned, $rest_url_prefix ) ) {
                        $cleaned = substr( $cleaned, strlen( $rest_url_prefix ) );
                    }
                    $cleaned = rtrim( $cleaned, '/' );
                    if ( '' === $cleaned ) {
                        continue;
                    }
                    $excluded_api_routes[] = $cleaned;
                }
            }
        }
        
        $allow_rest_api_access = false;
        
        // Get the REST API route being requested,e.g. wp/v2/posts | altcha/v1/challenge (without preceding slash /)
        // Ref: https://developer.wordpress.org/reference/hooks/rest_authentication_errors/#comment-6463
        $route = ltrim( $GLOBALS['wp']->query_vars['rest_route'], '/' );
        $route = rtrim( $route, '/' );
        
        if ( empty( $route ) ) {
            // This is when visiting /wp-json root
            $allow_rest_api_access = false;;
        } elseif (
            false !== strpos( $route, 'altcha/v1' )
            || false !== strpos( $route, 'two-factor/1.0' )
            || (  in_array( 'contact-form-7/wp-contact-form-7.php', get_option( 'active_plugins', array() ) )
                    && false !== strpos( $route, 'contact-form-7/' ) )
            || (  in_array( 'the-events-calendar/the-events-calendar.php', get_option( 'active_plugins', array() ) )
                    && false !== strpos( $route, 'tribe/' ) ) // Route used to AJAX load past events in the calendar
        ) {
            $allow_rest_api_access = true;
        } else {
            if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
                if ( $this->is_allowed_site_backup_storage_rest_route__premium_only( $route ) ) {
                    $allow_rest_api_access = true;
                }
                if ( ! $allow_rest_api_access && ! empty( $excluded_api_routes ) ) {
                    foreach ( $excluded_api_routes as $excluded_route ) {
                        if ( ! empty( $route ) 
                            && ! empty( $excluded_route )
                            && false !== strpos( $route, $excluded_route ) 
                        ) {
                            $allow_rest_api_access = true;
                            break;
                        }
                    }
                }
            }
        }

        $user = $this->get_user_for_rest_access_check();

        if ( $user->exists() ) {
            if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
                if ( count( $roles_rest_api_access_enabled ) > 0 ) {
                    $user_roles = (array) $user->roles;

                    foreach ( $user_roles as $role ) {
                        if ( in_array( $role, $roles_rest_api_access_enabled, true ) ) {
                            $allow_rest_api_access = true;
                            break;
                        }
                    }
                }
            } else {
                $allow_rest_api_access = true;
            }
        }

        if ( ! $allow_rest_api_access ) {
            return new WP_Error(
                'rest_api_authentication_required', 
                __( 'The REST API has been restricted to authenticated users.', 'admin-site-enhancements' ), 
                array( 
                    'status' => rest_authorization_required_code() 
                ) 
            );            
        }

        // Allow path: pass through unchanged so core's `true` is preserved.
        return $errors;
    }

    /**
     * Whether a REST route is an allowed Site Backup WP-site storage endpoint.
     *
     * Server-to-server storage operations authenticate via origin_secret_key in each
     * route permission_callback. Disable REST API must not block them first.
     *
     * @since 8.8.8
     *
     * @param string $route REST route without leading or trailing slash.
     * @return bool
     */
    private function is_allowed_site_backup_storage_rest_route__premium_only( $route ) {
        $route = (string) $route;
        if ( '' === $route ) {
            return false;
        }

        if ( false === strpos( $route, 'asenha/v1/storage' ) ) {
            return false;
        }

        $options = get_option( ASENHA_SLUG_U, array() );
        if ( ! is_array( $options ) ) {
            return false;
        }

        if ( ! array_key_exists( 'site_backup_migration', $options ) ) {
            return false;
        }

        if ( empty( $options['site_backup_migration'] ) ) {
            return false;
        }

        return true;
    }

    /**
     * User to evaluate for REST role allowlist.
     *
     * rest_cookie_check_errors (priority 100) may clear the current user when no REST nonce
     * is sent, so fall back to the logged-in auth cookie for role checks at priority 200.
     *
     * @since 8.8.2
     *
     * @return \WP_User
     */
    private function get_user_for_rest_access_check() {
        $user = wp_get_current_user();

        if ( $user->exists() ) {
            return $user;
        }

        $user_id = wp_validate_auth_cookie( '', 'logged_in' );

        if ( $user_id ) {
            $user = get_userdata( $user_id );

            if ( $user instanceof \WP_User ) {
                return $user;
            }
        }

        return new \WP_User( 0 );
    }
    
}