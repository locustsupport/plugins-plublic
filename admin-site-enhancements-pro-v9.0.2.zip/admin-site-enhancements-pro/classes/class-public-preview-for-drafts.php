<?php

namespace ASENHA\Classes;

/**
 * Class for Public Preview for Drafts
 *
 * @since 6.9.5
 */
class Public_Preview_For_Drafts {

    const META_TOKEN   = '_asenha_public_preview_token';
    const META_EXPIRES = '_asenha_public_preview_expires';

    /**
     * Whether a post status may use public preview: always draft; scheduled (future) when the setting is enabled.
     *
     * @since 8.7.0
     *
     * @param string $status Post status slug.
     * @return bool
     */
    private static function is_public_preview_eligible_post_status( $status ) {
        if ( 'draft' === $status ) {
            return true;
        }
        if ( 'future' === $status ) {
            $options = get_option( ASENHA_SLUG_U, array() );
            return ! empty( $options['public_preview_include_scheduled'] );
        }
        return false;
    }

    /**
     * Post types enabled for public preview in module settings.
     *
     * @since 8.9.0
     *
     * @return string[]
     */
    private static function get_enabled_post_types() {
        $options                   = get_option( ASENHA_SLUG_U, array() );
        $public_drafts_preview_for = isset( $options['public_drafts_preview_for'] ) ? $options['public_drafts_preview_for'] : array();
        $enabled                   = array();

        if ( is_array( $public_drafts_preview_for ) && count( $public_drafts_preview_for ) > 0 ) {
            foreach ( $public_drafts_preview_for as $post_type_slug => $is_enabled ) {
                if ( $is_enabled ) {
                    $enabled[] = $post_type_slug;
                }
            }
        }

        return $enabled;
    }

    /**
     * Whether public preview is enabled for the post's type.
     *
     * @since 8.9.0
     *
     * @param WP_Post $post Post object.
     * @return bool
     */
    private static function is_post_type_preview_enabled( $post ) {
        $enabled = self::get_enabled_post_types();

        return ! empty( $enabled ) && in_array( $post->post_type, $enabled, true );
    }

    /**
     * Maximum preview link lifetime in seconds from module settings.
     *
     * @since 8.9.0
     *
     * @return int
     */
    private static function get_max_life_seconds() {
        $options                 = get_option( ASENHA_SLUG_U, array() );
        $public_preview_max_days = isset( $options['public_preview_max_days'] ) ? (int) $options['public_preview_max_days'] : 3;

        if ( $public_preview_max_days < 1 ) {
            $public_preview_max_days = 3;
        }

        return $public_preview_max_days * DAY_IN_SECONDS;
    }

    /**
     * Create preview token and expiry meta if missing.
     *
     * @since 8.9.0
     *
     * @param int $post_id Post ID.
     * @return void
     */
    private static function ensure_preview_credentials( $post_id ) {
        $token   = get_post_meta( $post_id, self::META_TOKEN, true );
        $expires = (int) get_post_meta( $post_id, self::META_EXPIRES, true );

        if ( ! empty( $token ) && $expires > 0 ) {
            return;
        }

        self::reset_preview_credentials( $post_id );
    }

    /**
     * Generate a new preview token and expiry (invalidates previous links).
     *
     * @since 8.9.0
     *
     * @param int $post_id Post ID.
     * @return void
     */
    private static function reset_preview_credentials( $post_id ) {
        $token   = wp_generate_password( 10, false );
        $expires = time() + self::get_max_life_seconds();

        update_post_meta( $post_id, self::META_TOKEN, $token );
        update_post_meta( $post_id, self::META_EXPIRES, $expires );
    }

    /**
     * Delete preview credentials meta.
     *
     * @since 8.9.0
     *
     * @param int $post_id Post ID.
     * @return void
     */
    private static function delete_preview_credentials( $post_id ) {
        delete_post_meta( $post_id, self::META_TOKEN );
        delete_post_meta( $post_id, self::META_EXPIRES );
    }

    /**
     * Seconds until the preview link expires (0 if expired).
     *
     * @since 8.9.0
     *
     * @param int $post_id Post ID.
     * @return int
     */
    private static function get_remaining_seconds( $post_id ) {
        $expires = (int) get_post_meta( $post_id, self::META_EXPIRES, true );

        if ( $expires <= 0 ) {
            return 0;
        }

        return max( 0, $expires - time() );
    }

    /**
     * Human-readable remaining time label for admin UI.
     *
     * @since 8.9.0
     *
     * @param int $remaining_seconds Seconds remaining.
     * @return string
     */
    public static function format_remaining_time( $remaining_seconds ) {
        if ( $remaining_seconds <= 0 ) {
            return __( 'Expired — reset to generate a new link', 'admin-site-enhancements' );
        }

        $days    = (int) floor( $remaining_seconds / DAY_IN_SECONDS );
        $hours   = (int) floor( ( $remaining_seconds % DAY_IN_SECONDS ) / HOUR_IN_SECONDS );
        $minutes = (int) floor( ( $remaining_seconds % HOUR_IN_SECONDS ) / MINUTE_IN_SECONDS );

        if ( $days > 0 ) {
            $duration = sprintf(
                /* translators: 1: number of days, 2: number of hours */
                _n( '%1$d day, %2$d hours', '%1$d days, %2$d hours', $days, 'admin-site-enhancements' ),
                $days,
                $hours
            );
        } elseif ( $hours > 0 ) {
            $duration = sprintf(
                /* translators: 1: number of hours, 2: number of minutes */
                _n( '%1$d hour, %2$d minutes', '%1$d hours, %2$d minutes', $hours, 'admin-site-enhancements' ),
                $hours,
                $minutes
            );
        } else {
            $duration = sprintf(
                /* translators: %d: number of minutes */
                _n( '%d minute', '%d minutes', max( 1, $minutes ), 'admin-site-enhancements' ),
                max( 1, $minutes )
            );
        }

        /* translators: %s: duration until the preview link expires */
        return sprintf( __( 'Expires in %s', 'admin-site-enhancements' ), $duration );
    }

    /**
     * Data for admin UI (link, expiry, nonces).
     *
     * @since 8.9.0
     *
     * @param WP_Post $post Post object.
     * @return array
     */
    public static function get_preview_admin_data( $post ) {
        self::ensure_preview_credentials( $post->ID );

        $expires_at         = (int) get_post_meta( $post->ID, self::META_EXPIRES, true );
        $remaining_seconds  = self::get_remaining_seconds( $post->ID );
        $remaining_label    = self::format_remaining_time( $remaining_seconds );

        return array(
            'link'              => self::get_preview_link( $post ),
            'expires_at'        => $expires_at,
            'remaining_seconds' => $remaining_seconds,
            'remaining_label'   => $remaining_label,
            'post_id'           => $post->ID,
            'nonce'             => wp_create_nonce( 'asenha-reset-public-preview-' . $post->ID ),
        );
    }

    /**
     * Verify the pp query arg against stored post meta.
     *
     * @since 8.9.0
     *
     * @param int    $post_id Post ID.
     * @param string $pp      Token from the URL.
     * @return bool
     */
    private static function verify_preview_token( $post_id, $pp ) {
        if ( ! is_string( $pp ) || '' === $pp ) {
            return false;
        }

        $stored_token = get_post_meta( $post_id, self::META_TOKEN, true );
        $expires      = (int) get_post_meta( $post_id, self::META_EXPIRES, true );

        if ( empty( $stored_token ) || $expires <= 0 ) {
            return false;
        }

        if ( time() >= $expires ) {
            return false;
        }

        return hash_equals( $stored_token, $pp );
    }

    /**
     * Localized strings and config for admin scripts.
     *
     * @since 8.9.0
     *
     * @param WP_Post $post Post object.
     * @return array
     */
    private function get_admin_script_vars( $post ) {
        $admin_data = self::get_preview_admin_data( $post );

        return array(
            'ajaxUrl'           => admin_url( 'admin-ajax.php' ),
            'action'            => 'asenha_reset_public_preview',
            'postId'            => $admin_data['post_id'],
            'nonce'             => $admin_data['nonce'],
            'link'              => $admin_data['link'],
            'expiresAt'         => $admin_data['expires_at'],
            'remainingSeconds'  => $admin_data['remaining_seconds'],
            'remainingLabel'    => $admin_data['remaining_label'],
            'ppPostText'        => __( 'Public Preview', 'admin-site-enhancements' ),
            'ppPostTitle'       => __( 'Link to preview this draft publicly', 'admin-site-enhancements' ),
            'resetLabel'        => __( 'Reset public preview link', 'admin-site-enhancements' ),
            'confirmReset'      => __( 'This will invalidate the current public preview link and generate a new one. Continue?', 'admin-site-enhancements' ),
            'resetting'         => __( 'Resetting…', 'admin-site-enhancements' ),
            'resetError'        => __( 'Could not reset the preview link. Please try again.', 'admin-site-enhancements' ),
            'expiresInFormat'   => __( 'Expires in %s', 'admin-site-enhancements' ),
            'expiredLabel'      => __( 'Expired — reset to generate a new link', 'admin-site-enhancements' ),
            'copyLabel'         => __( 'Copy public preview link', 'admin-site-enhancements' ),
            'copyCopiedLabel'   => __( 'Link copied!', 'admin-site-enhancements' ),
            'copyError'         => __( 'Could not copy the link to the clipboard.', 'admin-site-enhancements' ),
        );
    }

    /**
     * SVG markup for the copy icon (Ion copy-outline, currentColor stroke).
     *
     * @since 8.9.1
     * @link https://icon-sets.iconify.design/ion/copy-outline/
     *
     * @return string
     */
    private static function get_copy_icon_svg() {
        return '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 512 512" aria-hidden="true"><rect width="336" height="336" x="128" y="128" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32" rx="57" ry="57"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="m383.5 128l.5-24a56.16 56.16 0 0 0-56-56H112a64.19 64.19 0 0 0-64 64v216a56.16 56.16 0 0 0 56 56h24"/></svg>';
    }

    /**
     * Copy-to-clipboard button markup for classic editor.
     *
     * @since 8.9.1
     *
     * @param string $clipboard_text Preview URL to copy.
     * @return string
     */
    private static function get_copy_icon_markup( $clipboard_text ) {
        $copy_aria = esc_attr__( 'Copy public preview link', 'admin-site-enhancements' );

        return '<button type="button" class="button-link asenha-copy-preview-link-button" data-clipboard-text="' . esc_attr( $clipboard_text ) . '" aria-label="' . $copy_aria . '" title="' . $copy_aria . '">'
            . self::get_copy_icon_svg()
            . '</button>';
    }

    /**
     * Allowed HTML for classic publish box public preview markup.
     *
     * @since 8.9.1
     *
     * @param string $html Markup.
     * @return string
     */
    private static function kses_public_preview_submitbox( $html ) {
        $allowed = array(
            'div'    => array(
                'class' => true,
                'id'    => true,
            ),
            'span'   => array(
                'id'    => true,
                'class' => true,
            ),
            'a'      => array(
                'href'  => true,
                'title' => true,
            ),
            'button' => array(
                'type'                => true,
                'class'               => true,
                'data-post-id'        => true,
                'data-clipboard-text' => true,
                'aria-label'          => true,
                'title'               => true,
            ),
            'p'      => array(
                'class'           => true,
                'data-expires-at' => true,
            ),
            'svg'    => array(
                'xmlns'       => true,
                'width'       => true,
                'height'      => true,
                'viewbox'     => true,
                'viewBox'     => true,
                'aria-hidden' => true,
            ),
            'g'      => array(
                'fill'              => true,
                'stroke'            => true,
                'stroke-linecap'    => true,
                'stroke-linejoin'   => true,
                'stroke-width'      => true,
            ),
            'rect'   => array(
                'x'               => true,
                'y'               => true,
                'width'           => true,
                'height'          => true,
                'rx'              => true,
                'ry'              => true,
                'fill'            => true,
                'stroke'          => true,
                'stroke-linecap'  => true,
                'stroke-linejoin' => true,
                'stroke-width'    => true,
            ),
            'path'   => array(
                'd'               => true,
                'fill'            => true,
                'stroke'          => true,
                'stroke-linecap'  => true,
                'stroke-linejoin' => true,
                'stroke-width'    => true,
            ),
        );

        return wp_kses( $html, $allowed );
    }

    /**
     * Enqueue ClipboardJS and Tippy for copy feedback on the post edit screen.
     *
     * @since 8.9.1
     */
    private function enqueue_public_preview_clipboard_assets() {
        wp_enqueue_script( 'asenha-popper', ASENHA_URL . 'assets/premium/js/popper.min.js', array(), ASENHA_VERSION, true );
        wp_enqueue_script( 'asenha-tippy', ASENHA_URL . 'assets/premium/js/tippy-bundle.umd.min.js', array( 'asenha-popper' ), ASENHA_VERSION, true );
        wp_enqueue_script( 'asenha-clipboard-js', ASENHA_URL . 'assets/premium/js/clipboard.min.js', array( 'jquery', 'asenha-tippy' ), ASENHA_VERSION, true );
    }

    /**
     * Enqueue admin assets on the post edit screen when preview is available.
     *
     * @since 8.9.0
     *
     * @param WP_Post $post Post object.
     * @return void
     */
    private function enqueue_public_preview_admin_assets( $post ) {
        if ( ! self::is_post_type_preview_enabled( $post ) ) {
            return;
        }

        if ( ! self::is_public_preview_eligible_post_status( $post->post_status ) ) {
            return;
        }

        $script_vars    = $this->get_admin_script_vars( $post );
        $common_methods = new Common_Methods;

        $this->enqueue_public_preview_clipboard_assets();

        wp_enqueue_style( 'asenha-gutenberg-public-preview', ASENHA_URL . 'assets/premium/css/gutenberg-public-preview.css', array(), ASENHA_VERSION );

        if ( $common_methods->is_in_block_editor() ) {
            wp_register_script(
                'asenha-gutenberg-public-preview',
                ASENHA_URL . 'assets/premium/js/gutenberg-public-preview.js',
                array( 'wp-edit-post', 'wp-plugins', 'wp-i18n', 'wp-element', 'wp-components', 'wp-data', 'asenha-tippy' ),
                ASENHA_VERSION,
                true
            );
            wp_localize_script( 'asenha-gutenberg-public-preview', 'pp_params', $script_vars );
            wp_enqueue_script( 'asenha-gutenberg-public-preview' );
        } else {
            wp_enqueue_script(
                'asenha-public-preview-admin',
                ASENHA_URL . 'assets/premium/js/public-preview-admin.js',
                array( 'jquery', 'asenha-clipboard-js' ),
                ASENHA_VERSION,
                true
            );
            wp_localize_script( 'asenha-public-preview-admin', 'ppAdmin', $script_vars );
        }
    }

    /**
     * Add public preview link on draft posts of post types where it is enabled
     *
     * @since 7.5.0
     *
     * @param array   $actions Row actions.
     * @param WP_Post $post    Post object.
     * @return array
     */
    public function add__action_row_public_preview_link( $actions, $post ) {
        $enabled_post_types = self::get_enabled_post_types();

        if ( ! empty( $enabled_post_types ) ) {
            if ( in_array( $post->post_type, $enabled_post_types, true )
                && self::is_public_preview_eligible_post_status( $post->post_status )
            ) {
                $public_preview_link = esc_url( self::get_preview_link( $post ) );
                $actions['asenha-public-preview'] = '<a href="' . $public_preview_link . '" title="' . esc_attr__( 'Link to preview this draft publicly', 'admin-site-enhancements' ) . '">' . esc_html__( 'Public Preview', 'admin-site-enhancements' ) . '</a>';
            }
        }

        return $actions;
    }

    /**
     * Add public preview button in post submit/update box in classic editor
     *
     * @since 7.5.0
     */
    public function add_submitbox_public_preview_button() {
        global $post;

        if ( ! is_object( $post ) ) {
            return;
        }

        if ( ! self::is_post_type_preview_enabled( $post ) ) {
            return;
        }

        if ( ! self::is_public_preview_eligible_post_status( $post->post_status ) ) {
            return;
        }

        echo self::kses_public_preview_submitbox( self::get_submitbox_public_preview_markup( $post ) );
    }

    /**
     * Markup for classic editor publish box public preview row.
     *
     * @since 8.9.0
     *
     * @param WP_Post $post Post object.
     * @return string
     */
    private static function get_submitbox_public_preview_markup( $post ) {
        $admin_data = self::get_preview_admin_data( $post );
        $link       = esc_url( $admin_data['link'] );
        $title      = esc_attr__( 'Link to preview this draft publicly', 'admin-site-enhancements' );
        $label      = esc_html__( 'Public Preview', 'admin-site-enhancements' );
        $reset_aria = esc_attr__( 'Reset public preview link', 'admin-site-enhancements' );
        $expiry     = esc_html( $admin_data['remaining_label'] );
        $expires_at = (int) $admin_data['expires_at'];

        return '<div class="additional-actions asenha-public-preview-row">'
            . '<span id="public-preview"><a href="' . $link . '" title="' . $title . '">' . $label . '</a></span>'
            . '<span class="asenha-public-preview-icon-group">'
            . self::get_copy_icon_markup( $admin_data['link'] )
            . '<button type="button" class="button-link asenha-public-preview-reset" data-post-id="' . (int) $post->ID . '" aria-label="' . $reset_aria . '" title="' . $reset_aria . '">'
            . '<span class="dashicons dashicons-update" aria-hidden="true"></span>'
            . '</button>'
            . '</span>'
            . '</div>'
            . '<p class="asenha-public-preview-expiry" data-expires-at="' . $expires_at . '">' . $expiry . '</p>';
    }

    /**
     * Enqueue block editor assets on post edit screen.
     *
     * @since 7.5.1
     */
    public function enqueue_public_preview_edit_screen_assets( $hook_suffix ) {
        if ( 'post.php' !== $hook_suffix ) {
            return;
        }

        $post_id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;

        if ( ! $post_id ) {
            return;
        }

        $post = get_post( $post_id );

        if ( ! $post instanceof \WP_Post ) {
            return;
        }

        if ( ! self::is_public_preview_eligible_post_status( $post->post_status ) ) {
            return;
        }

        $this->enqueue_public_preview_admin_assets( $post );
    }

    /**
     * @deprecated 8.9.0 Use enqueue_public_preview_edit_screen_assets().
     */
    public function add_gutenberg_public_preview_button() {
        $this->enqueue_public_preview_edit_screen_assets();
    }

    /**
     * AJAX: reset public preview link for a post.
     *
     * @since 8.9.0
     */
    public function ajax_reset_public_preview() {
        if ( ! isset( $_POST['post_id'] ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid request.', 'admin-site-enhancements' ) ) );
        }

        $post_id = (int) $_POST['post_id'];

        if ( ! check_ajax_referer( 'asenha-reset-public-preview-' . $post_id, 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid security token.', 'admin-site-enhancements' ) ) );
        }

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            wp_send_json_error( array( 'message' => __( 'You are not allowed to reset this preview link.', 'admin-site-enhancements' ) ) );
        }

        $post = get_post( $post_id );

        if ( ! $post ) {
            wp_send_json_error( array( 'message' => __( 'Post not found.', 'admin-site-enhancements' ) ) );
        }

        if ( ! self::is_post_type_preview_enabled( $post ) ) {
            wp_send_json_error( array( 'message' => __( 'Public preview is not enabled for this post type.', 'admin-site-enhancements' ) ) );
        }

        if ( ! self::is_public_preview_eligible_post_status( $post->post_status ) ) {
            wp_send_json_error( array( 'message' => __( 'Public preview is not available for this post status.', 'admin-site-enhancements' ) ) );
        }

        self::reset_preview_credentials( $post_id );

        $admin_data = self::get_preview_admin_data( $post );

        wp_send_json_success(
            array(
                'link'              => $admin_data['link'],
                'expires_at'        => $admin_data['expires_at'],
                'remaining_seconds' => $admin_data['remaining_seconds'],
                'remaining_label'   => $admin_data['remaining_label'],
            )
        );
    }

    /**
     * Remove preview meta when a post is published or privatized.
     *
     * @since 8.9.0
     *
     * @param string  $new_status New post status.
     * @param string  $old_status Old post status.
     * @param WP_Post $post       Post object.
     */
    public function cleanup_preview_meta_on_publish( $new_status, $old_status, $post ) {
        if ( ! $post instanceof \WP_Post ) {
            return;
        }

        if ( in_array( $new_status, array( 'publish', 'private' ), true ) ) {
            self::delete_preview_credentials( $post->ID );
        }
    }

    /**
     * Registers the new query var `pp`.
     *
     * @since 7.5.0
     *
     * @param  array $qv Existing list of query variables.
     * @return array List of query variables.
     */
    public static function add_query_var( $qv ) {
        $qv[] = 'pp';

        return $qv;
    }

    /**
     * Registers the filter to handle a public preview.
     *
     * @since 7.5.0
     *
     * @param object $query The WP_Query object.
     */
    public static function show_public_preview( $query ) {
        if (
            $query->is_main_query() &&
            $query->is_preview() &&
            $query->is_singular() &&
            $query->get( 'pp' )
        ) {
            if ( ! headers_sent() ) {
                nocache_headers();
                header( 'X-Robots-Tag: noindex' );
            }
            if ( function_exists( 'wp_robots_no_robots' ) ) {
                add_filter( 'wp_robots', 'wp_robots_no_robots' );
            } else {
                add_action( 'wp_head', 'wp_no_robots' );
            }

            add_filter( 'posts_results', array( __CLASS__, 'set_post_to_publish' ), 10, 2 );
        }
    }

    /**
     * Sets the post status of the first post to publish for preview display.
     *
     * @since 7.5.0
     *
     * @param  array $posts The post to preview.
     * @return array The post that is being previewed.
     */
    public static function set_post_to_publish( $posts ) {
        remove_filter( 'posts_results', array( __CLASS__, 'set_post_to_publish' ), 10 );

        if ( empty( $posts ) ) {
            return $posts;
        }

        $post_id = (int) $posts[0]->ID;

        self::maybe_redirect_to_published_post( $post_id );

        if ( ! self::verify_preview_token( $post_id, get_query_var( 'pp' ) ) ) {
            wp_die( esc_html__( 'This link has expired or is invalid!', 'admin-site-enhancements' ), esc_html__( 'Preview unavailable', 'admin-site-enhancements' ), array( 'response' => 403 ) );
        }

        $preview_status = $posts[0]->post_status;

        if ( self::is_public_preview_eligible_post_status( $preview_status ) ) {
            $posts[0]->post_status = 'publish';

            add_filter( 'comments_open', '__return_false' );
            add_filter( 'pings_open', '__return_false' );
            add_filter( 'wp_link_pages_link', array( __CLASS__, 'filter_wp_link_pages_link' ), 10, 2 );
        } elseif ( 'future' === $preview_status ) {
            wp_die( esc_html__( 'This link has expired or is invalid!', 'admin-site-enhancements' ), esc_html__( 'Preview unavailable', 'admin-site-enhancements' ), array( 'response' => 403 ) );
        }

        return $posts;
    }

    /**
     * Filters paginated page links to use the preview link.
     *
     * @since 7.5.0
     *
     * @param string $link        The page number HTML output.
     * @param int    $page_number Page number for paginated posts' page links.
     * @return string The filtered HTML output.
     */
    public static function filter_wp_link_pages_link( $link, $page_number ) {
        $post = get_post();
        if ( ! $post ) {
            return $link;
        }

        $preview_link = self::get_preview_link( $post );
        $preview_link = add_query_arg( 'page', $page_number, $preview_link );

        return preg_replace( '~href=(["|\'])(.+?)\1~', 'href=$1' . esc_url( $preview_link ) . '$1', $link );
    }

    /**
     * Redirects to post's proper permalink, if it has gone live.
     *
     * @since 7.5.0
     *
     * @param int $post_id The post id.
     * @return false False if post status is not a published status.
     */
    private static function maybe_redirect_to_published_post( $post_id ) {
        if ( ! in_array( get_post_status( $post_id ), array( 'publish', 'private' ), true ) ) {
            return false;
        }

        wp_safe_redirect( get_permalink( $post_id ), 301 );
        exit;
    }

    /**
     * Returns the public preview link.
     *
     * @since 7.5.0
     *
     * @param WP_Post $post The post object.
     * @return string The generated public preview link.
     */
    public static function get_preview_link( $post ) {
        self::ensure_preview_credentials( $post->ID );

        $token = get_post_meta( $post->ID, self::META_TOKEN, true );

        if ( 'page' === $post->post_type ) {
            $args = array(
                'page_id' => $post->ID,
            );
        } elseif ( 'post' === $post->post_type ) {
            $args = array(
                'p' => $post->ID,
            );
        } else {
            $args = array(
                'p'         => $post->ID,
                'post_type' => $post->post_type,
            );
        }

        $args['preview'] = 'true';
        $args['pp']      = $token;

        return add_query_arg( $args, home_url( '/' ) );
    }

}
