<?php

namespace ASENHA\Classes;

use WP_Error;
use ASENHA\EmailDelivery\Email_Log_Table;

/**
 * Class for Email Delivery module
 *
 * @since 6.9.5
 */
class Email_Delivery {
    const SMTP_PASSWORD_PREFIX = 'asenha_encrypted::smtp_password::v1::';
    const SMTP_PASSWORD_PREFIX_V2 = 'asenha_encrypted::smtp_password::v2::';
    const SMTP_PASSWORD_UNAVAILABLE_TRANSIENT = 'asenha_smtp_password_unavailable';
    const SMTP_PASSWORD_NOTICE_DISMISSED_META = 'asenha_smtp_password_notice_dismissed';
    const SMTP_PASSWORD_STATUS_EMPTY = 'empty';
    const SMTP_PASSWORD_STATUS_LEGACY_PLAINTEXT = 'legacy_plaintext';
    const SMTP_PASSWORD_STATUS_ENCRYPTED_VALID = 'encrypted_valid';
    const SMTP_PASSWORD_STATUS_ENCRYPTED_INVALID = 'encrypted_invalid';

    private $log_entry_id;

    /**
     * Runtime Email_Delivery instance registered from bootstrap.php.
     *
     * @since 8.8.5
     *
     * @var Email_Delivery|null
     */
    private static $runtime_instance = null;

    /**
     * Pending fallback log error when wp_mail_failed fires before a log row exists.
     *
     * @since 8.8.5
     *
     * @var string
     */
    private $pending_fallback_log_error = '';

    /**
     * Max length for subject column in asenha_email_delivery.
     *
     * @since 8.8.5
     */
    private const LOG_SUBJECT_MAX_LENGTH = 250;

    /**
     * Max length for send_to column in asenha_email_delivery.
     *
     * @since 8.8.5
     */
    private const LOG_SEND_TO_MAX_LENGTH = 256;

    /**
     * Max length for error column in asenha_email_delivery.
     *
     * @since 8.8.5
     */
    private const LOG_ERROR_MAX_LENGTH = 250;

    /**
     * Register the runtime Email_Delivery instance used by hooked callbacks.
     *
     * @since 8.8.5
     *
     * @param Email_Delivery $instance Email Delivery instance.
     * @return void
     */
    public static function set_runtime_instance( Email_Delivery $instance ) {
        self::$runtime_instance = $instance;
    }

    /**
     * Get the runtime Email_Delivery instance registered from bootstrap.php.
     *
     * @since 8.8.5
     *
     * @return Email_Delivery|null
     */
    public static function get_runtime_instance() {
        return self::$runtime_instance;
    }

    /**
     * Pending email-log error when SMTP auth cannot use the stored password.
     *
     * @since 8.8.5
     *
     * @var string
     */
    private $pending_smtp_password_log_error = '';

    /**
     * Transient lifetime for surfacing SMTP password failures to administrators.
     *
     * @since 8.8.5
     *
     * @return int
     */
    public function get_smtp_password_unavailable_transient_ttl() {
        return 90 * DAY_IN_SECONDS;
    }

    /**
     * Derive the v1 encryption key from WordPress salts.
     *
     * @since 8.4.3
     *
     * @return string
     */
    private function get_smtp_password_encryption_key_v1() {
        return hash(
            'sha256',
            \wp_salt( 'auth' ) . \wp_salt( 'secure_auth' ) . 'asenha_smtp_password',
            true
        );
    }

    /**
     * Load admin_site_enhancements_extra as an array.
     *
     * @since 8.8.5
     *
     * @return array
     */
    private function get_options_extra_array() {
        $options_extra = get_option( ASENHA_SLUG_U . '_extra', array() );

        return is_array( $options_extra ) ? $options_extra : array();
    }

    /**
     * Get the stored v2 secret key without creating one.
     *
     * @since 8.8.5
     *
     * @return string|false
     */
    private function get_stored_smtp_secret_key_v2() {
        $options_extra = $this->get_options_extra_array();

        if ( empty( $options_extra['smtp_secret_key'] ) || ! is_string( $options_extra['smtp_secret_key'] ) ) {
            return false;
        }

        $decoded = base64_decode( $options_extra['smtp_secret_key'], true );

        if ( false === $decoded || 32 !== strlen( $decoded ) ) {
            return false;
        }

        return $decoded;
    }

    /**
     * Get or create the per-site v2 SMTP secret key.
     *
     * @since 8.8.5
     *
     * @return string|false
     */
    private function get_or_create_smtp_secret_key_v2() {
        $stored_key = $this->get_stored_smtp_secret_key_v2();

        if ( false !== $stored_key ) {
            return $stored_key;
        }

        if ( ! $this->can_handle_smtp_password_encryption() ) {
            return false;
        }

        try {
            $key = random_bytes( 32 );
        } catch ( \Exception $exception ) {
            return false;
        }

        $options_extra                      = $this->get_options_extra_array();
        $options_extra['smtp_secret_key']   = base64_encode( $key );
        update_option( ASENHA_SLUG_U . '_extra', $options_extra, true );

        return $key;
    }

    /**
     * Persist a non-secret fingerprint of the active encryption key.
     *
     * @since 8.8.5
     *
     * @param string $encryption_key Raw encryption key.
     * @return void
     */
    private function persist_smtp_password_key_fingerprint( $encryption_key ) {
        $options_extra = $this->get_options_extra_array();
        $options_extra['smtp_password_key_fingerprint'] = hash( 'sha256', $encryption_key );
        update_option( ASENHA_SLUG_U . '_extra', $options_extra, true );
    }

    /**
     * Check whether the current environment can encrypt/decrypt the SMTP password.
     *
     * @since 8.4.3
     *
     * @return bool
     */
    private function can_handle_smtp_password_encryption() {
        return function_exists( 'openssl_encrypt' )
            && function_exists( 'openssl_decrypt' )
            && function_exists( 'openssl_cipher_iv_length' )
            && function_exists( 'random_bytes' );
    }

    /**
     * Check whether the stored SMTP password uses the v1 encrypted format.
     *
     * @since 8.8.5
     *
     * @param string $stored_password Stored option value.
     * @return bool
     */
    public function is_smtp_password_v1_encrypted( $stored_password ) {
        return is_string( $stored_password )
            && 0 === strpos( $stored_password, self::SMTP_PASSWORD_PREFIX );
    }

    /**
     * Check whether the stored SMTP password uses the v2 encrypted format.
     *
     * @since 8.8.5
     *
     * @param string $stored_password Stored option value.
     * @return bool
     */
    public function is_smtp_password_v2_encrypted( $stored_password ) {
        return is_string( $stored_password )
            && 0 === strpos( $stored_password, self::SMTP_PASSWORD_PREFIX_V2 );
    }

    /**
     * Check whether the stored SMTP password value is encrypted.
     *
     * @since 8.4.3
     *
     * @param string $stored_password Stored option value.
     * @return bool
     */
    public function is_smtp_password_encrypted( $stored_password ) {
        return $this->is_smtp_password_v1_encrypted( $stored_password )
            || $this->is_smtp_password_v2_encrypted( $stored_password );
    }

    /**
     * Check whether a value looks like stored SMTP ciphertext rather than plaintext.
     *
     * @since 8.8.6
     *
     * @param string $value Candidate value.
     * @return bool
     */
    public function is_probable_smtp_ciphertext( $value ) {
        return is_string( $value ) && (
            $this->is_smtp_password_v1_encrypted( $value )
            || $this->is_smtp_password_v2_encrypted( $value )
            || 0 === strpos( $value, 'asenha_encrypted::smtp_password::' )
        );
    }

    /**
     * Whether SMTP password storage has been upgraded to the v2 format.
     *
     * @since 8.8.6
     *
     * @return bool
     */
    public function is_smtp_password_storage_version_v2() {
        $options_extra = $this->get_options_extra_array();

        return isset( $options_extra['smtp_password_storage_version'] )
            && 2 === (int) $options_extra['smtp_password_storage_version'];
    }

    /**
     * Mark SMTP password storage as upgraded to v2.
     *
     * @since 8.8.6
     *
     * @return void
     */
    public function mark_smtp_password_storage_version_v2() {
        $options_extra = $this->get_options_extra_array();
        $options_extra['smtp_password_storage_version'] = 2;
        update_option( ASENHA_SLUG_U . '_extra', $options_extra, true );
    }

    /**
     * Unwrap nested SMTP ciphertext layers down to plaintext.
     *
     * @since 8.8.6
     *
     * @param string $stored_password Stored option value.
     * @param int    $max_depth       Maximum unwrap attempts.
     * @return string|false Plaintext password or false when unusable.
     */
    public function unwrap_smtp_password_to_plaintext( $stored_password, $max_depth = 5 ) {
        if ( ! is_string( $stored_password ) || '' === $stored_password ) {
            return false;
        }

        if ( ! $this->is_probable_smtp_ciphertext( $stored_password ) ) {
            return $stored_password;
        }

        $current = $stored_password;
        $depth   = 0;

        while ( $depth < $max_depth && $this->is_probable_smtp_ciphertext( $current ) ) {
            $decrypted = $this->decrypt_smtp_password( $current );

            if ( false === $decrypted ) {
                return false;
            }

            $current = $decrypted;
            $depth++;
        }

        if ( $this->is_probable_smtp_ciphertext( $current ) ) {
            return false;
        }

        return $current;
    }

    /**
     * Encrypt a payload with AES-256-CBC and an authenticated HMAC.
     *
     * @since 8.8.5
     *
     * @param string $password Plaintext password.
     * @param string $key      Encryption key.
     * @param string $prefix   Stored-value prefix.
     * @return string
     */
    private function encrypt_smtp_password_with_key( $password, $key, $prefix ) {
        if ( '' === $password || ! $this->can_handle_smtp_password_encryption() ) {
            return '';
        }

        $cipher = 'AES-256-CBC';
        $iv_len = openssl_cipher_iv_length( $cipher );

        if ( false === $iv_len ) {
            return '';
        }

        try {
            $iv = random_bytes( $iv_len );
        } catch ( \Exception $exception ) {
            return '';
        }

        $ciphertext_raw = openssl_encrypt( $password, $cipher, $key, OPENSSL_RAW_DATA, $iv );

        if ( false === $ciphertext_raw ) {
            return '';
        }

        $hmac = hash_hmac( 'sha256', $ciphertext_raw, $key, true );

        return $prefix . base64_encode( $iv . $hmac . $ciphertext_raw );
    }

    /**
     * Decrypt a stored SMTP password payload.
     *
     * @since 8.8.5
     *
     * @param string $stored_password Stored option value.
     * @param string $key             Encryption key.
     * @param string $prefix          Stored-value prefix.
     * @return string|false
     */
    private function decrypt_smtp_password_with_key( $stored_password, $key, $prefix ) {
        if ( ! is_string( $stored_password ) || 0 !== strpos( $stored_password, $prefix ) ) {
            return false;
        }

        if ( ! $this->can_handle_smtp_password_encryption() ) {
            return false;
        }

        $payload = substr( $stored_password, strlen( $prefix ) );
        $decoded = base64_decode( $payload, true );

        if ( false === $decoded ) {
            return false;
        }

        $cipher = 'AES-256-CBC';
        $iv_len = openssl_cipher_iv_length( $cipher );

        if ( false === $iv_len || strlen( $decoded ) <= ( $iv_len + 32 ) ) {
            return false;
        }

        $iv             = substr( $decoded, 0, $iv_len );
        $stored_hmac    = substr( $decoded, $iv_len, 32 );
        $ciphertext_raw = substr( $decoded, $iv_len + 32 );
        $calc_hmac      = hash_hmac( 'sha256', $ciphertext_raw, $key, true );

        if ( ! hash_equals( $stored_hmac, $calc_hmac ) ) {
            return false;
        }

        return openssl_decrypt( $ciphertext_raw, $cipher, $key, OPENSSL_RAW_DATA, $iv );
    }

    /**
     * Encrypt SMTP password for storage in options (always v2).
     *
     * @since 8.4.3
     *
     * @param string $password SMTP password.
     * @return string Encrypted payload or empty string on failure.
     */
    public function encrypt_smtp_password( $password ) {
        if ( '' === $password ) {
            return '';
        }

        if ( $this->is_probable_smtp_ciphertext( $password ) ) {
            return '';
        }

        $key = $this->get_or_create_smtp_secret_key_v2();

        if ( false === $key ) {
            return '';
        }

        $encrypted_password = $this->encrypt_smtp_password_with_key(
            $password,
            $key,
            self::SMTP_PASSWORD_PREFIX_V2
        );

        if ( ! empty( $encrypted_password ) ) {
            $this->persist_smtp_password_key_fingerprint( $key );
            $this->mark_smtp_password_storage_version_v2();
            $this->clear_smtp_password_unavailable_flag();
            $this->clear_smtp_password_notice_dismissals();
        }

        return $encrypted_password;
    }

    /**
     * Decrypt stored SMTP password.
     *
     * @since 8.4.3
     *
     * @param string $stored_password Stored option value.
     * @return string|false
     */
    public function decrypt_smtp_password( $stored_password ) {
        if ( $this->is_smtp_password_v2_encrypted( $stored_password ) ) {
            $key = $this->get_stored_smtp_secret_key_v2();

            if ( false === $key ) {
                return false;
            }

            return $this->decrypt_smtp_password_with_key(
                $stored_password,
                $key,
                self::SMTP_PASSWORD_PREFIX_V2
            );
        }

        if ( $this->is_smtp_password_v1_encrypted( $stored_password ) ) {
            return $this->decrypt_smtp_password_with_key(
                $stored_password,
                $this->get_smtp_password_encryption_key_v1(),
                self::SMTP_PASSWORD_PREFIX
            );
        }

        return false;
    }

    /**
     * Get the current storage status of the SMTP password.
     *
     * @since 8.4.3
     *
     * @param string|null $stored_password Stored option value.
     * @return string
     */
    public function get_smtp_password_status( $stored_password = null ) {
        if ( null === $stored_password ) {
            $options         = get_option( ASENHA_SLUG_U, array() );
            $stored_password = isset( $options['smtp_password'] ) ? $options['smtp_password'] : '';
        }

        if ( empty( $stored_password ) ) {
            return self::SMTP_PASSWORD_STATUS_EMPTY;
        }

        if ( $this->is_smtp_password_encrypted( $stored_password ) ) {
            $plaintext_password = $this->unwrap_smtp_password_to_plaintext( $stored_password );

            if ( false === $plaintext_password || $this->is_probable_smtp_ciphertext( $plaintext_password ) ) {
                return self::SMTP_PASSWORD_STATUS_ENCRYPTED_INVALID;
            }

            return self::SMTP_PASSWORD_STATUS_ENCRYPTED_VALID;
        }

        if ( $this->is_probable_smtp_ciphertext( $stored_password ) ) {
            return self::SMTP_PASSWORD_STATUS_ENCRYPTED_INVALID;
        }

        return self::SMTP_PASSWORD_STATUS_LEGACY_PLAINTEXT;
    }

    /**
     * Human-readable SMTP password status label for the settings UI.
     *
     * @since 8.8.5
     *
     * @param string|null $stored_password Stored option value.
     * @return string
     */
    public function get_smtp_password_status_label( $stored_password = null ) {
        $status = $this->get_smtp_password_status( $stored_password );

        switch ( $status ) {
            case self::SMTP_PASSWORD_STATUS_ENCRYPTED_VALID:
            case self::SMTP_PASSWORD_STATUS_LEGACY_PLAINTEXT:
                return __( 'Saved', 'admin-site-enhancements' );

            case self::SMTP_PASSWORD_STATUS_ENCRYPTED_INVALID:
                return __( 'Re-entry required', 'admin-site-enhancements' );

            default:
                return __( 'Not set', 'admin-site-enhancements' );
        }
    }

    /**
     * Get SMTP password UI state for the settings screen and AJAX responses.
     *
     * Side-effect free: does not set transients or modify stored credentials.
     *
     * @since 8.8.7
     *
     * @param array|null $options ASE options array.
     * @return array {
     *     @type string $status                 Storage status constant value.
     *     @type string $label                  Human-readable status label.
     *     @type string $description            Full field description for the password row.
     *     @type bool   $show_warning           Whether to show the inline re-entry warning.
     *     @type string $warning_message        Warning notice text.
     *     @type bool   $authentication_enabled Whether SMTP auth is enabled.
     * }
     */
    public function get_smtp_password_ui_state( $options = null ) {
        if ( null === $options ) {
            if ( function_exists( '\asenha_get_option_array' ) ) {
                $options = \asenha_get_option_array( ASENHA_SLUG_U, true );
            } else {
                $options = get_option( ASENHA_SLUG_U, array() );
            }
        }

        if ( ! is_array( $options ) ) {
            $options = array();
        }

        $authentication_enabled = ! isset( $options['smtp_authentication'] ) || 'enable' === $options['smtp_authentication'];
        $stored_password        = isset( $options['smtp_password'] ) ? $options['smtp_password'] : '';
        $status                 = $this->get_smtp_password_status( $stored_password );
        $label                  = $authentication_enabled ? $this->get_smtp_password_status_label( $stored_password ) : '';

        $description = __( 'Leave blank to keep the current password.', 'admin-site-enhancements' );

        if ( $authentication_enabled && '' !== $label ) {
            $description .= ' ' . sprintf(
                /* translators: %s: password storage status label */
                __( 'Status: %s.', 'admin-site-enhancements' ),
                $label
            );
        }

        $show_warning    = false;
        $warning_message = '';

        if ( $authentication_enabled && self::SMTP_PASSWORD_STATUS_ENCRYPTED_INVALID === $status ) {
            $description = __( 'Enter and save a new password to restore SMTP authentication.', 'admin-site-enhancements' );

            if ( '' !== $label ) {
                $description .= ' ' . sprintf(
                    /* translators: %s: password storage status label */
                    __( 'Status: %s.', 'admin-site-enhancements' ),
                    $label
                );
            }

            $show_warning    = true;
            $warning_message = __( 'The stored SMTP password can no longer be decrypted. Please enter it again above and save changes.', 'admin-site-enhancements' );
        }

        return array(
            'status'                 => $status,
            'label'                  => $label,
            'description'            => $description,
            'show_warning'           => $show_warning,
            'warning_message'        => $warning_message,
            'authentication_enabled' => $authentication_enabled,
        );
    }

    /**
     * Map SMTP password UI state to AJAX response fields.
     *
     * @since 8.8.7
     *
     * @param array|null $options ASE options array.
     * @return array
     */
    public function get_smtp_password_ajax_ui_fields( $options = null ) {
        $ui_state = $this->get_smtp_password_ui_state( $options );

        return array(
            'smtp_password_status'       => $ui_state['status'],
            'smtp_password_status_label' => $ui_state['label'],
            'smtp_password_description'  => $ui_state['description'],
            'smtp_password_warning'      => $ui_state['show_warning'] ? $ui_state['warning_message'] : '',
        );
    }

    /**
     * Whether SMTP authentication is required but no usable password is available.
     *
     * @since 8.8.5
     *
     * @param array|null $options ASE options array.
     * @return bool
     */
    public function is_smtp_password_unavailable_for_delivery( $options = null ) {
        if ( null === $options ) {
            $options = get_option( ASENHA_SLUG_U, array() );
        }

        if ( ! is_array( $options ) || empty( $options['smtp_email_delivery'] ) ) {
            return false;
        }

        $smtp_authentication = isset( $options['smtp_authentication'] ) ? $options['smtp_authentication'] : 'enable';

        if ( 'enable' !== $smtp_authentication ) {
            return false;
        }

        $smtp_host     = isset( $options['smtp_host'] ) ? $options['smtp_host'] : '';
        $smtp_port     = isset( $options['smtp_port'] ) ? $options['smtp_port'] : '';
        $smtp_security = isset( $options['smtp_security'] ) ? $options['smtp_security'] : '';

        if ( empty( $smtp_host ) || empty( $smtp_port ) || empty( $smtp_security ) ) {
            return false;
        }

        $stored_password = isset( $options['smtp_password'] ) ? $options['smtp_password'] : '';
        $status          = $this->get_smtp_password_status( $stored_password );

        if ( self::SMTP_PASSWORD_STATUS_ENCRYPTED_INVALID === $status ) {
            return true;
        }

        if ( self::SMTP_PASSWORD_STATUS_EMPTY === $status ) {
            return true;
        }

        return '' === $this->get_smtp_password_for_runtime( $stored_password );
    }

    /**
     * Flag that SMTP password delivery is unavailable for administrator follow-up.
     *
     * @since 8.8.5
     *
     * @return void
     */
    public function set_smtp_password_unavailable_flag() {
        set_transient(
            self::SMTP_PASSWORD_UNAVAILABLE_TRANSIENT,
            1,
            $this->get_smtp_password_unavailable_transient_ttl()
        );
    }

    /**
     * Clear the SMTP password unavailable flag.
     *
     * @since 8.8.5
     *
     * @return void
     */
    public function clear_smtp_password_unavailable_flag() {
        delete_transient( self::SMTP_PASSWORD_UNAVAILABLE_TRANSIENT );
    }

    /**
     * Whether the SMTP password unavailable flag is currently set.
     *
     * @since 8.8.5
     *
     * @return bool
     */
    public function is_smtp_password_unavailable_flagged() {
        return (bool) get_transient( self::SMTP_PASSWORD_UNAVAILABLE_TRANSIENT );
    }

    /**
     * Clear per-user SMTP password notice dismissals.
     *
     * @since 8.8.5
     *
     * @return void
     */
    public function clear_smtp_password_notice_dismissals() {
        delete_metadata( 'user', 0, self::SMTP_PASSWORD_NOTICE_DISMISSED_META, '', true );
    }

    /**
     * Check SMTP password health after a Site Backup restore.
     *
     * @since 8.8.5
     *
     * @return string Warning message or empty string when healthy.
     */
    public function check_smtp_password_after_restore() {
        if ( ! $this->is_smtp_password_unavailable_for_delivery() ) {
            return '';
        }

        $this->set_smtp_password_unavailable_flag();

        return __( 'SMTP password could not be decrypted after restore. Re-enter it under ASE → Email Delivery.', 'admin-site-enhancements' );
    }

    /**
     * Repair nested SMTP password storage by rewriting a clean single-layer v2 value.
     *
     * @since 8.8.6
     *
     * @return bool Whether storage was repaired or already healthy.
     */
    public function repair_nested_smtp_password_storage() {
        $options = get_option( ASENHA_SLUG_U, array() );

        if ( ! is_array( $options ) || empty( $options['smtp_password'] ) ) {
            return false;
        }

        $stored_password = $options['smtp_password'];

        if ( $this->is_smtp_password_storage_version_v2()
            && $this->is_smtp_password_v2_encrypted( $stored_password )
        ) {
            $outer_plaintext = $this->decrypt_smtp_password( $stored_password );

            if ( false !== $outer_plaintext && ! $this->is_probable_smtp_ciphertext( $outer_plaintext ) ) {
                return true;
            }
        }

        $plaintext_password = $this->unwrap_smtp_password_to_plaintext( $stored_password );

        if ( false === $plaintext_password || $this->is_probable_smtp_ciphertext( $plaintext_password ) ) {
            $this->set_smtp_password_unavailable_flag();

            return false;
        }

        if ( $this->is_smtp_password_v2_encrypted( $stored_password ) ) {
            $outer_plaintext = $this->decrypt_smtp_password( $stored_password );

            if ( false !== $outer_plaintext
                && ! $this->is_probable_smtp_ciphertext( $outer_plaintext )
                && $outer_plaintext === $plaintext_password
            ) {
                $this->mark_smtp_password_storage_version_v2();
                $this->clear_smtp_password_unavailable_flag();

                return true;
            }
        }

        $encrypted_password = $this->encrypt_smtp_password( $plaintext_password );

        if ( empty( $encrypted_password ) ) {
            $this->set_smtp_password_unavailable_flag();

            return false;
        }

        $options['smtp_password'] = $encrypted_password;
        update_option( ASENHA_SLUG_U, $options, true );
        $this->clear_smtp_password_unavailable_flag();

        return true;
    }

    /**
     * Output a global admin notice when SMTP authentication cannot use the stored password.
     *
     * @since 8.8.5
     *
     * @return void
     */
    public function maybe_show_smtp_password_admin_notice() {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $options = get_option( ASENHA_SLUG_U, array() );

        if ( ! is_array( $options ) || empty( $options['smtp_email_delivery'] ) ) {
            return;
        }

        $should_warn = $this->is_smtp_password_unavailable_for_delivery( $options )
            || $this->is_smtp_password_unavailable_flagged();

        if ( ! $should_warn ) {
            return;
        }

        if ( get_user_meta( get_current_user_id(), self::SMTP_PASSWORD_NOTICE_DISMISSED_META, true )
            && ! $this->is_smtp_password_unavailable_flagged()
        ) {
            return;
        }

        $settings_url = admin_url( 'tools.php?page=' . ASENHA_SLUG . '#utilities' );
        $message      = $this->get_smtp_password_reentry_message();
        ?>
        <div class="notice notice-warning is-dismissible asenha-smtp-password-notice" id="asenha-smtp-password-notice">
            <p>
                <?php echo esc_html( $message ); ?>
                <a href="<?php echo esc_url( $settings_url ); ?>"><?php esc_html_e( 'Open Email Delivery settings', 'admin-site-enhancements' ); ?></a>
            </p>
        </div>
        <?php
    }

    /**
     * Dismiss the global SMTP password admin notice for the current administrator.
     *
     * @since 8.8.5
     *
     * @return void
     */
    public function dismiss_smtp_password_admin_notice() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error(
                array(
                    'message' => __( 'Insufficient permissions.', 'admin-site-enhancements' ),
                ),
                403
            );
        }

        check_ajax_referer( 'asenha-dismiss-smtp-password-notice', 'nonce' );

        update_user_meta( get_current_user_id(), self::SMTP_PASSWORD_NOTICE_DISMISSED_META, true );

        wp_send_json_success();
    }

    /**
     * Enqueue the dismiss handler for the global SMTP password notice.
     *
     * @since 8.8.5
     *
     * @return void
     */
    public function enqueue_smtp_password_notice_script() {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $options = get_option( ASENHA_SLUG_U, array() );

        if ( ! is_array( $options ) || empty( $options['smtp_email_delivery'] ) ) {
            return;
        }

        if ( ! $this->is_smtp_password_unavailable_for_delivery( $options ) && ! $this->is_smtp_password_unavailable_flagged() ) {
            return;
        }

        if ( get_user_meta( get_current_user_id(), self::SMTP_PASSWORD_NOTICE_DISMISSED_META, true )
            && ! $this->is_smtp_password_unavailable_flagged()
        ) {
            return;
        }

        wp_enqueue_script( 'jquery' );
        wp_add_inline_script(
            'jquery',
            'jQuery(function($){$(document).on("click","#asenha-smtp-password-notice .notice-dismiss",function(){$.post(ajaxurl,{action:"asenha_dismiss_smtp_password_notice",nonce:' . wp_json_encode( wp_create_nonce( 'asenha-dismiss-smtp-password-notice' ) ) . '});});});'
        );
    }

    /**
     * Resolve SMTP password for runtime delivery use.
     *
     * Legacy plaintext remains supported as a migration fallback until the
     * settings are re-saved and rewritten to the encrypted format.
     *
     * @since 8.4.3
     *
     * @param string|null $stored_password Stored option value.
     * @return string
     */
    public function get_smtp_password_for_runtime( $stored_password = null ) {
        if ( null === $stored_password ) {
            $options         = get_option( ASENHA_SLUG_U, array() );
            $stored_password = isset( $options['smtp_password'] ) ? $options['smtp_password'] : '';
        }

        switch ( $this->get_smtp_password_status( $stored_password ) ) {
            case self::SMTP_PASSWORD_STATUS_ENCRYPTED_VALID:
                $plaintext_password = $this->unwrap_smtp_password_to_plaintext( $stored_password );

                if ( false === $plaintext_password || $this->is_probable_smtp_ciphertext( $plaintext_password ) ) {
                    $this->set_smtp_password_unavailable_flag();

                    return '';
                }

                return $plaintext_password;

            case self::SMTP_PASSWORD_STATUS_LEGACY_PLAINTEXT:
                if ( $this->is_probable_smtp_ciphertext( $stored_password ) ) {
                    $this->set_smtp_password_unavailable_flag();

                    return '';
                }

                return (string) $stored_password;

            default:
                return '';
        }
    }

    /**
     * Get message shown when the stored SMTP password can no longer be used.
     *
     * @since 8.4.3
     *
     * @return string
     */
    public function get_smtp_password_reentry_message() {
        return __( 'The stored SMTP password can no longer be decrypted. Please enter it again and save changes.', 'admin-site-enhancements' );
    }

    /**
     * Send emails using external SMTP service
     *
     * @since 4.6.0
     */
    public function deliver_email_via_smtp( $phpmailer ) {

        $options                    = get_option( ASENHA_SLUG_U, array() );
        $smtp_host                  = $options['smtp_host'];
        $smtp_port                  = $options['smtp_port'];
        $smtp_security              = $options['smtp_security'];
        $smtp_authentication        = isset( $options['smtp_authentication'] ) ? $options['smtp_authentication'] : 'enable';
        $smtp_username              = $options['smtp_username'];
        $smtp_password              = isset( $options['smtp_password'] ) ? $options['smtp_password'] : '';
        $smtp_default_from_name     = $options['smtp_default_from_name'];
        $smtp_default_from_email    = $options['smtp_default_from_email'];
        $smtp_force_from            = $options['smtp_force_from'];
        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            $smtp_replyto_name      = isset( $options['smtp_replyto_name'] ) ? $options['smtp_replyto_name'] : '';
            $smtp_replyto_email     = isset( $options['smtp_replyto_email'] ) ? $options['smtp_replyto_email'] : '';
            $smtp_bcc_emails        = isset( $options['smtp_bcc_emails'] ) ? $options['smtp_bcc_emails'] : '';
        }
        $smtp_bypass_ssl_verification   = $options['smtp_bypass_ssl_verification'];
        $smtp_debug                 = $options['smtp_debug'];

        // Do nothing if host or password is empty
        // if ( empty( $smtp_host ) || empty( $smtp_password ) ) {
        //  return;
        // }

        // Maybe override FROM email and/or name if the sender is "WordPress <wordpress@sitedomain.com>", the default from WordPress core and not yet overridden by another plugin.

        $from_name = $phpmailer->FromName;
        $from_email_beginning = substr( $phpmailer->From, 0, 9 ); // Get the first 9 characters of the current FROM email

        if ( $smtp_force_from ) {
            $phpmailer->FromName    = $smtp_default_from_name;
            $phpmailer->From        = $smtp_default_from_email;
            // WP 6.9: set SMTP envelope (MAIL FROM) using PHPMailer::Sender only.
            // PHPMailer maintainers treat envelope bounce handling as **Sender**, not a separate ReturnPath property; 
            // receiving MTAs derive Return-Path from the envelope sender. 
            // Ref: https://make.wordpress.org/core/2025/11/18/more-reliable-email-in-wordpress-6-9/
            $phpmailer->Sender      = $smtp_default_from_email;
        } else {
            if ( ( 'WordPress' === $from_name ) && ! empty( $smtp_default_from_name ) ) {
                $phpmailer->FromName = $smtp_default_from_name;
            }

            if ( ( 'wordpress' === $from_email_beginning ) && ! empty( $smtp_default_from_email ) ) {
                $phpmailer->From = $smtp_default_from_email;
                // WP 6.9: set SMTP envelope (MAIL FROM) using PHPMailer::Sender only.
                // PHPMailer maintainers treat envelope bounce handling as **Sender**, not a separate ReturnPath property; 
                // receiving MTAs derive Return-Path from the envelope sender. 
                // Ref: https://make.wordpress.org/core/2025/11/18/more-reliable-email-in-wordpress-6-9/
                $phpmailer->Sender      = $smtp_default_from_email;
            }
        }
        
        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            if ( ! empty( $smtp_replyto_email ) ) {
                $phpmailer->clearReplyTos();

                // Support one or more comma-separated Reply-To addresses, mirroring
                // how Bcc is handled below. RFC 5322 defines Reply-To as an
                // address-list, so multiple addresses are valid.
                $smtp_replyto_emails = explode( ',', $smtp_replyto_email );
                $is_first_replyto    = true;

                foreach ( $smtp_replyto_emails as $replyto_email ) {
                    $replyto_email = trim( $replyto_email );

                    if ( empty( $replyto_email ) ) {
                        continue;
                    }

                    if ( ! is_email( $replyto_email ) ) {
                        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                        error_log(
                            'ASE: skipped invalid Reply-To address "' . $replyto_email . '"'
                        );
                        continue;
                    }

                    try {
                        // Only the first address carries the configured Reply-to name,
                        // so additional addresses aren't all labelled with it.
                        $phpmailer->addReplyTo(
                            $replyto_email,
                            $is_first_replyto ? $smtp_replyto_name : ''
                        );
                        $is_first_replyto = false;
                    } catch ( \Exception $e ) {
                        // WordPress core instantiates PHPMailer with exceptions enabled
                        // (new PHPMailer( true ) in wp-includes/pluggable.php), so an
                        // invalid address here would otherwise throw an uncaught
                        // exception and fatal every wp_mail() call. Skip and log instead.
                        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                        error_log(
                            'ASE: skipped invalid Reply-To address "' . $replyto_email
                            . '" - ' . $e->getMessage()
                        );
                    }
                }
            }

            if ( ! empty( $smtp_bcc_emails ) ) {
                $smtp_bcc_emails = explode( ',', $smtp_bcc_emails );
                foreach ( $smtp_bcc_emails as $bcc_email ) {
                    $bcc_email = trim( $bcc_email );

                    if ( empty( $bcc_email ) ) {
                        continue;
                    }

                    if ( ! is_email( $bcc_email ) ) {
                        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                        error_log(
                            'ASE: skipped invalid Bcc address "' . $bcc_email . '"'
                        );
                        continue;
                    }

                    try {
                        $phpmailer->addBcc( $bcc_email );
                    } catch ( \Exception $e ) {
                        // Same rationale as Reply-To above: never let a bad settings
                        // value become a fatal error.
                        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                        error_log(
                            'ASE: skipped invalid Bcc address "' . $bcc_email
                            . '" - ' . $e->getMessage()
                        );
                    }
                }
            }
        }

        $smtp_password = $this->get_smtp_password_for_runtime( $smtp_password );

        if ( 'enable' === $smtp_authentication
            && ! empty( $smtp_host )
            && ! empty( $smtp_port )
            && ! empty( $smtp_security )
            && '' === trim( $smtp_password )
        ) {
            $this->set_smtp_password_unavailable_flag();
            $this->pending_smtp_password_log_error = __( 'SMTP password unavailable (decryption failed or not configured).', 'admin-site-enhancements' );
        }

        // Only attempt to send via SMTP if all the required info is present. Otherwise, use default PHP Mailer settings as set by wp_mail()
        if ( ! empty( $smtp_host ) && ! empty( $smtp_port ) && ! empty( $smtp_security ) ) {

            // Send using SMTP
            $phpmailer->isSMTP(); // phpcs:ignore

            if ( 'enable' == $smtp_authentication ) {
                $phpmailer->SMTPAuth = true; // phpcs:ignore
            } else {
                $phpmailer->SMTPAuth = false; // phpcs:ignore
            }

            // Set some other defaults
            // $phpmailer->CharSet  = 'utf-8'; // phpcs:ignore
            $phpmailer->XMailer     = 'Admin and Site Enhancements v' . ASENHA_VERSION . ' - a WordPress plugin'; // phpcs:ignore

            $phpmailer->Host        = $smtp_host;       // phpcs:ignore
            $phpmailer->Port        = $smtp_port;       // phpcs:ignore
            $phpmailer->SMTPSecure  = $smtp_security;   // phpcs:ignore

            if ( 'enable' == $smtp_authentication ) {
                $phpmailer->Username    = trim( $smtp_username );   // phpcs:ignore
                $phpmailer->Password    = trim( $smtp_password );   // phpcs:ignore                
            }

        }
        
        // If verification of SSL certificate is bypassed
        // Reference: https://www.php.net/manual/en/context.ssl.php & https://stackoverflow.com/a/30803024

        if ( $smtp_bypass_ssl_verification ) {
            $phpmailer->SMTPOptions = [
                'ssl' => [
                    'verify_peer'       => false,
                    'verify_peer_name'  => false,
                    'allow_self_signed' => true
                ]
            ];
        }

        // If debug mode is enabled, send debug info (SMTP::DEBUG_CONNECTION) to WordPress debug.log file set in wp-config.php
        // Reference: https://github.com/PHPMailer/PHPMailer/wiki/SMTP-Debugging

        if ( $smtp_debug ) {
            $phpmailer->SMTPDebug   = 4;            //phpcs:ignore
            $phpmailer->Debugoutput = 'error_log';  //phpcs:ignore
        }

    }
    
    /**
     * Send a test email and use SMTP host if defined in settings
     * 
     * @since 5.3.0
     */
    public function send_test_email() {
        
        if ( isset( $_REQUEST['email_to'] ) 
            && isset( $_REQUEST['nonce'] ) 
            && current_user_can( 'manage_options' )
        ) {
            if ( wp_verify_nonce( sanitize_text_field( $_REQUEST['nonce'] ), 'send-test-email-nonce_' . get_current_user_id() ) ) {
                $options               = get_option( ASENHA_SLUG_U, array() );
                $smtp_host             = isset( $options['smtp_host'] ) ? $options['smtp_host'] : '';
                $smtp_port             = isset( $options['smtp_port'] ) ? $options['smtp_port'] : '';
                $smtp_security         = isset( $options['smtp_security'] ) ? $options['smtp_security'] : '';
                $smtp_authentication   = isset( $options['smtp_authentication'] ) ? $options['smtp_authentication'] : 'enable';
                $smtp_password         = isset( $options['smtp_password'] ) ? $options['smtp_password'] : '';
                $smtp_password_status  = $this->get_smtp_password_status( $smtp_password );
                $smtp_is_configured    = ! empty( $smtp_host ) && ! empty( $smtp_port ) && ! empty( $smtp_security );

                $runtime_smtp_password = $this->get_smtp_password_for_runtime( $smtp_password );

                if ( $smtp_is_configured
                    && 'enable' === $smtp_authentication
                    && (
                        self::SMTP_PASSWORD_STATUS_ENCRYPTED_INVALID === $smtp_password_status
                        || '' === $runtime_smtp_password
                        || $this->is_probable_smtp_ciphertext( $runtime_smtp_password )
                    )
                ) {
                    wp_send_json(
                        array_merge(
                            array(
                                'status'  => 'failed',
                                'message' => $this->get_smtp_password_reentry_message(),
                            ),
                            $this->get_smtp_password_ajax_ui_fields( $options )
                        )
                    );
                }

                $content = array(
                    array(
                        'title' => 'Hey... are you getting this?',
                        'body'  => '<p><strong>Looks like you did!</strong></p>',
                    ),
                    array(
                        'title' => 'There\'s a message for you...',
                        'body'  => '<p><strong>Here it is:</strong></p>',
                    ),
                    array(
                        'title' => 'Is it working?',
                        'body'  => '<p><strong>Yes, it\'s working!</strong></p>',
                    ),
                    array(
                        'title' => 'Hope you\'re getting this...',
                        'body'  => '<p><strong>Looks like this was sent out just fine and you got it.</strong></p>',
                    ),
                    array(
                        'title' => 'Testing delivery configuration...',
                        'body'  => '<p><strong>Everything looks good!</strong></p>',
                    ),
                    array(
                        'title' => 'Testing email delivery',
                        'body'  => '<p><strong>Looks good!</strong></p>',
                    ),
                    array(
                        'title' => 'Config is looking good',
                        'body'  => '<p><strong>Seems like everything has been set up properly!</strong></p>',
                    ),
                    array(
                        'title' => 'All set up',
                        'body'  => '<p><strong>Your configuration is working properly.</strong></p>',
                    ),
                    array(
                        'title' => 'Good to go',
                        'body'  => '<p><strong>Config is working great.</strong></p>',
                    ),
                    array(
                        'title' => 'Good job',
                        'body'  => '<p><strong>Everything is set.</strong></p>',
                    ),
                );
                
                $random_number = rand( 0, count( $content ) - 1 );

                $to = sanitize_email( wp_unslash( $_REQUEST['email_to'] ) );
                $title = $content[$random_number]['title'];
                $body  = $content[$random_number]['body'] . '<p>This message was sent from <a href="' . get_bloginfo( 'url' ) . '">' . get_bloginfo( 'url' ) . '</a> on ' . wp_date( 'F j, Y' ) . ' at '  . wp_date( 'H:i:s' ) . ' via ASE.</p>';
                $headers = array('Content-Type: text/html; charset=UTF-8');

                $success = wp_mail( $to, $title, $body, $headers );

                $ui_fields = $this->get_smtp_password_ajax_ui_fields( $options );
                
                if ( $success ) {
                    $response = array_merge(
                        array(
                            'status' => 'success',
                        ),
                        $ui_fields
                    );
                } else {
                    $response = array_merge(
                        array(
                            'status' => 'failed',
                        ),
                        $ui_fields
                    );
                }

                wp_send_json( $response );
            }
        }
        
    }
    
    /**
     * Whether Email Delivery logging is enabled for the current site.
     *
     * @since 8.8.5
     *
     * @return bool
     */
    public function is_email_delivery_log_enabled__premium_only() {
        if ( ! bwasenha_fs()->can_use_premium_code__premium_only() ) {
            return false;
        }

        $options = get_option( ASENHA_SLUG_U, array() );
        if ( ! is_array( $options ) ) {
            return false;
        }

        if ( empty( $options['smtp_email_delivery'] ) ) {
            return false;
        }

        if ( empty( $options['smtp_email_log'] ) ) {
            return false;
        }

        return true;
    }

    /**
     * Reset request-scoped email log state after a send completes.
     *
     * @since 8.8.5
     *
     * @return void
     */
    private function reset_request_log_state__premium_only() {
        $this->log_entry_id              = 0;
        $this->pending_fallback_log_error = '';
    }

    /**
     * Truncate a log field to fit the database schema.
     *
     * @since 8.8.5
     *
     * @param string $value      Value to truncate.
     * @param int    $max_length Maximum allowed length.
     * @return string
     */
    private function truncate_log_field__premium_only( $value, $max_length ) {
        $value = (string) $value;

        if ( function_exists( 'mb_strlen' ) && function_exists( 'mb_substr' ) ) {
            if ( mb_strlen( $value ) > $max_length ) {
                return mb_substr( $value, 0, $max_length );
            }

            return $value;
        }

        if ( strlen( $value ) > $max_length ) {
            return substr( $value, 0, $max_length );
        }

        return $value;
    }

    /**
     * Truncate an error message for the log table.
     *
     * @since 8.8.5
     *
     * @param string $error_message Error message.
     * @return string
     */
    private function truncate_log_error_message__premium_only( $error_message ) {
        $error_message = (string) $error_message;

        if ( strlen( $error_message ) > self::LOG_ERROR_MAX_LENGTH ) {
            return substr( $error_message, 0, self::LOG_ERROR_MAX_LENGTH - 3 ) . '...';
        }

        return $error_message;
    }

    /**
     * Ensure the email delivery log table exists.
     *
     * @since 8.8.5
     *
     * @return string Table name including prefix.
     */
    private function ensure_email_log_table_exists__premium_only() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'asenha_email_delivery';
        $query      = $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table_name ) );

        if ( $wpdb->get_var( $query ) !== $table_name ) {
            $activation = new Activation();
            $activation->create_email_delivery_log_table();
        }

        return $table_name;
    }

    /**
     * Emit a low-noise diagnostic when a log insert/update fails.
     *
     * @since 8.8.5
     *
     * @param string $context Context label.
     * @return void
     */
    private function log_email_delivery_db_failure__premium_only( $context ) {
        global $wpdb;

        if ( defined( 'WP_DEBUG' ) && WP_DEBUG && ! empty( $wpdb->last_error ) ) {
            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
            error_log( 'ASE Email Delivery log DB failure (' . $context . '): ' . $wpdb->last_error );
        }
    }

    /**
     * Normalize wp_mail args for logging.
     *
     * @since 8.8.5
     *
     * @param array<string,mixed> $mail wp_mail args.
     * @return array<string,mixed>
     */
    private function normalize_wp_mail_args_for_logging__premium_only( $mail ) {
        $mail = is_array( $mail ) ? $mail : array();

        // Normalize the list of recipients.
        // Reference: https://plugins.trac.wordpress.org/browser/mailarchiver/tags/4.0.0/includes/listeners/class-corelistener.php#L139
        $recipients = null;

        if ( isset( $mail['to'] ) ) {
            if ( is_string( $mail['to'] ) ) {
                foreach ( array( ',', ';' ) as $separator ) {
                    if ( false !== strpos( $mail['to'], $separator ) ) {
                        $recipients = explode( $separator, $mail['to'] );
                        break;
                    }
                }
                if ( ! isset( $recipients ) ) {
                    $recipients = $mail['to'];
                }
            } elseif ( isset( $mail['to'] ) ) {
                $recipients = $mail['to'];
            } else {
                $recipients = array( 'nobody@nowhere.com' );
            }
        }

        $send_to_array = array();
        $this->get_all_emails__premium_only( $recipients, $send_to_array );
        natcasesort( $send_to_array );

        $send_to = is_array( $send_to_array ) ? implode( ', ', $send_to_array ) : (string) $send_to_array;
        $send_to = sanitize_text_field( str_replace( array( '<', '>' ), array( '(', ')' ), $send_to ) );
        $send_to = $this->truncate_log_field__premium_only( $send_to, self::LOG_SEND_TO_MAX_LENGTH );

        $subject = isset( $mail['subject'] ) ? sanitize_text_field( (string) $mail['subject'] ) : '';
        $subject = $this->truncate_log_field__premium_only( $subject, self::LOG_SUBJECT_MAX_LENGTH );

        $message = isset( $mail['message'] ) ? wp_kses_post( (string) $mail['message'] ) : '';

        $mail_attachments = isset( $mail['attachments'] ) ? $mail['attachments'] : array();
        if ( ! is_array( $mail_attachments ) ) {
            $attachments = explode( "\n", str_replace( "\r\n", "\n", (string) $mail_attachments ) );
        } else {
            $attachments = $mail_attachments;
        }

        return array(
            'to_array'    => $send_to_array,
            'send_to'     => $send_to,
            'subject'     => $subject,
            'message'     => $message,
            'attachments' => $attachments,
        );
    }

    /**
     * Insert a row into the email delivery log table.
     *
     * @since 8.8.5
     *
     * @param array<string,mixed> $args Log row args.
     * @return int Inserted row ID, or 0 on failure.
     */
    private function insert_email_delivery_log_entry__premium_only( $args ) {
        global $wpdb;

        $args = is_array( $args ) ? $args : array();

        $table_name = $this->ensure_email_log_table_exists__premium_only();

        $unixtime = time();
        if ( function_exists( 'wp_date' ) ) {
            $datetime_wp = wp_date( 'Y-m-d H:i:s', $unixtime );
        } else {
            $datetime_wp = date_i18n( 'Y-m-d H:i:s', $unixtime );
        }

        $status    = isset( $args['status'] ) ? sanitize_key( (string) $args['status'] ) : 'unknown';
        $error     = isset( $args['error'] ) ? (string) $args['error'] : 'None';
        $error     = sanitize_text_field( $this->truncate_log_error_message__premium_only( $error ) );
        $subject   = isset( $args['subject'] ) ? (string) $args['subject'] : '';
        $subject   = sanitize_text_field( $this->truncate_log_field__premium_only( $subject, self::LOG_SUBJECT_MAX_LENGTH ) );
        $message   = isset( $args['message'] ) ? wp_kses_post( (string) $args['message'] ) : '';
        $send_to   = isset( $args['send_to'] ) ? (string) $args['send_to'] : '';
        $send_to   = sanitize_text_field( $this->truncate_log_field__premium_only( $send_to, self::LOG_SEND_TO_MAX_LENGTH ) );
        $processor = isset( $args['processor'] ) ? sanitize_text_field( (string) $args['processor'] ) : 'wp_mail';

        $attachments = isset( $args['attachments'] ) ? $args['attachments'] : array();
        if ( ! is_array( $attachments ) ) {
            $attachments = array();
        }

        $backtrace_source = isset( $args['backtrace_source'] ) ? sanitize_key( (string) $args['backtrace_source'] ) : 'wp_mail';

        $options         = get_option( ASENHA_SLUG_U, array() );
        $smtp_bcc_emails = isset( $options['smtp_bcc_emails'] ) ? $options['smtp_bcc_emails'] : '';
        $smtp_bcc_emails = str_replace( array( ', ', ',  ' ), ',', trim( (string) $smtp_bcc_emails ) );

        $extra_array = array(
            'bcc' => $smtp_bcc_emails,
        );

        $data = array(
            'status'           => $status,
            'error'            => $error,
            'subject'          => $subject,
            'message'          => $message,
            'send_to'          => $send_to,
            'sender'           => '',
            'headers'          => '',
            'attachments'      => serialize( $attachments ),
            'backtrace'        => wp_json_encode( $this->get_backtrace__premium_only( $backtrace_source ) ),
            'processor'        => $processor,
            'sent_on'          => $datetime_wp,
            'sent_on_unixtime' => $unixtime,
            'extra'            => serialize( $extra_array ),
        );

        $data_format = array(
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%d',
            '%s',
        );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $result = $wpdb->insert(
            $table_name,
            $data,
            $data_format
        );

        if ( false === $result ) {
            $this->log_email_delivery_db_failure__premium_only( 'insert' );
            return 0;
        }

        return (int) $wpdb->insert_id;
    }

    /**
     * Update an existing log row with a failure status and message.
     *
     * @since 8.8.5
     *
     * @param int    $log_entry_id  Log row ID.
     * @param string $error_message Error message.
     * @return bool
     */
    private function update_log_entry_failure__premium_only( $log_entry_id, $error_message ) {
        global $wpdb;

        $log_entry_id = (int) $log_entry_id;
        if ( $log_entry_id <= 0 ) {
            return false;
        }

        $error_message = sanitize_text_field( $this->truncate_log_error_message__premium_only( $error_message ) );
        if ( '' === $error_message ) {
            $error_message = 'Unknown error.';
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $wpdb->update(
            $wpdb->prefix . 'asenha_email_delivery',
            array(
                'status' => 'failed',
                'error'  => $error_message,
            ),
            array(
                'id' => $log_entry_id,
            ),
            array(
                '%s',
                '%s',
            ),
            array(
                '%d',
            )
        );

        if ( false === $result ) {
            $this->log_email_delivery_db_failure__premium_only( 'update_failure' );
            return false;
        }

        return true;
    }

    /**
     * Ensure a log row exists after wp_mail() completes.
     *
     * @since 8.8.5
     *
     * @param array<string,mixed> $mail_args      wp_mail args used for the send.
     * @param bool                $sent           Whether wp_mail() returned true.
     * @param string              $error_message  Optional error message when send failed.
     * @param string              $processor      Processor label for fallback inserts.
     * @return void
     */
    public function ensure_email_delivery_logged_after_send__premium_only( $mail_args, $sent, $error_message = '', $processor = 'site_backup_policy' ) {
        if ( ! $this->is_email_delivery_log_enabled__premium_only() ) {
            return;
        }

        $existing_log_entry_id = (int) $this->log_entry_id;

        if ( $existing_log_entry_id > 0 ) {
            if ( ! $sent ) {
                if ( '' === $error_message && '' !== $this->pending_fallback_log_error ) {
                    $error_message = $this->pending_fallback_log_error;
                }

                if ( '' !== $error_message ) {
                    $this->update_log_entry_failure__premium_only( $existing_log_entry_id, $error_message );
                }
            }

            $this->reset_request_log_state__premium_only();
            return;
        }

        if ( '' === $error_message && '' !== $this->pending_fallback_log_error ) {
            $error_message = $this->pending_fallback_log_error;
        }

        $normalized = $this->normalize_wp_mail_args_for_logging__premium_only( $mail_args );
        $status     = $sent ? 'successful' : 'failed';
        $error      = $sent ? 'None' : ( '' !== $error_message ? $error_message : 'Unknown error.' );

        $this->insert_email_delivery_log_entry__premium_only(
            array(
                'status'           => $status,
                'error'            => $error,
                'subject'          => $normalized['subject'],
                'message'          => $normalized['message'],
                'send_to'          => $normalized['send_to'],
                'attachments'      => $normalized['attachments'],
                'processor'        => sanitize_text_field( (string) $processor ),
                'backtrace_source' => 'wp_mail',
            )
        );

        $this->reset_request_log_state__premium_only();
    }

    /**
     * Process mail and log to database
     * 
     * @since v7.1.0
     */
    public function log_via_wp_mail__premium_only( $mail ) {
        // We keep the original mail for later.
        $original_mail = $mail;

        if ( ! $this->is_email_delivery_log_enabled__premium_only() ) {
            return $original_mail;
        }

        $this->reset_request_log_state__premium_only();

        $normalized = $this->normalize_wp_mail_args_for_logging__premium_only( $mail );

        $entry_id = $this->insert_email_delivery_log_entry__premium_only(
            array(
                'status'           => 'successful',
                'error'            => 'None',
                'subject'          => $normalized['subject'],
                'message'          => $normalized['message'],
                'send_to'          => $normalized['send_to'],
                'attachments'      => $normalized['attachments'],
                'processor'        => 'wp_mail',
                'backtrace_source' => 'wp_mail',
            )
        );

        $this->log_entry_id = $entry_id;

        // We return the original email for sending.
        return $original_mail;
    }
    
    /**
     * Process delivery error and log it to the database
     * 
     * @since 7.1.0
     */
    public function process_error__premium_only( $error ) {
        if ( ! ( $error instanceof \WP_Error ) ) {
            return;
        }

        if ( '' !== $this->pending_smtp_password_log_error ) {
            $error_message = $this->pending_smtp_password_log_error;
            $this->pending_smtp_password_log_error = '';
        } else {
            $error_message = $error->get_error_message();
        }

        if ( '' === $error_message ) {
            $error_message = 'Unknown error.';
        }

        $error_message = $this->truncate_log_error_message__premium_only( $error_message );

        if ( (int) $this->log_entry_id <= 0 ) {
            $this->pending_fallback_log_error = $error_message;
            return;
        }

        $updated = $this->update_log_entry_failure__premium_only( $this->log_entry_id, $error_message );

        if ( ! $updated ) {
            $this->pending_fallback_log_error = $error_message;
        }
    }
    
    /**
     * Perform additional logging for data that are not properly logged via wp_mail hook
     * 
     * @since 7.1.0
     */
    public function additional_logging__premium_only( $phpmailer ) {
        if ( (int) $this->log_entry_id <= 0 ) {
            return;
        }

        // Set custom Message-ID header, e.g. // e.g. <message-3@subdomain.domain.com>>
        // The number here is the ID of the message in the email delivery log table
        $message_id = '<message-' . $this->log_entry_id . '@' . parse_url( get_site_url(), PHP_URL_HOST ) . '>';
        $phpmailer->MessageID = $message_id;

        // Get headers
        // Reference: https://plugins.trac.wordpress.org/browser/mailarchiver/tags/4.0.0/includes/listeners/class-corelistener.php#L216
        if ( method_exists( $phpmailer, 'createHeader' ) ) {
            $headers = $phpmailer->createHeader();

            if ( ! is_array( $headers ) ) {
                $headers = explode( "\n", str_replace( "\r\n", "\n", $headers ) );
            }
            
            // Remove empty elements and get sender info (name and email)
            $sender = '';
            $headers_array = array();
            $sender = '';
            $reply_to = '';
            $content_type = '';
            if ( ! empty( $headers ) ) {
                foreach( $headers as $header ) {
                    if ( '' !== $header ) {
                        $headers_array[] = $header;
                    }
                    if ( false !== strpos( $header, 'From:' ) ) {
                        $sender_array = explode( ': ', $header );
                        $sender = isset( $sender_array[1] ) ? $sender_array[1] : '';
                    }
                    if ( false !== strpos( $header, 'Reply-To:' ) ) {
                        $reply_to_array = explode( ': ', $header );
                        $reply_to = isset( $reply_to_array[1] ) ? $reply_to_array[1] : '';
                    }
                    if ( false !== strpos( $header, 'Content-Type:' ) ) {
                        $content_type_array = explode( ': ', $header );
                        $content_type_maybe_with_charset = isset( $content_type_array[1] ) ? $content_type_array[1] : ''; // e.g. text/html; charset=UTF-8
                        if ( false !== strpos( $content_type_maybe_with_charset, 'charset' ) ) {
                            $content_type_parts = explode( '; ', $content_type_maybe_with_charset );
                            $content_type = isset( $content_type_parts[0] ) ? $content_type_parts[0] : '';
                        } else {
                            $content_type = trim( $content_type_maybe_with_charset );
                        }
                    }
                }
            }
            
            // Add sender and headers info to the existing log entry for the mail
            // https://developer.wordpress.org/reference/classes/wpdb/update/
            global $wpdb;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $result = $wpdb->update(
                $wpdb->prefix . 'asenha_email_delivery', // Log table name  
                array( 
                    'sender'        => sanitize_text_field( str_replace( array( '<', '>' ), array( '(', ')' ), $sender ) ),
                    'reply_to'      => sanitize_text_field( str_replace( array( '<', '>' ), array( '(', ')' ), $reply_to ) ),
                    'content_type'  => sanitize_text_field( $content_type ),
                    'headers'       => serialize( $headers_array ),
                ), 
                array( 
                    'id' => $this->log_entry_id,
                ),
                array(
                    '%s', // string - sender
                    '%s', // string - reply_to
                    '%s', // string - content_type
                    '%s', // string - headers
                ),
                array(
                    '%d', // integer - id        
                )
            );

            if ( false === $result ) {
                $this->log_email_delivery_db_failure__premium_only( 'additional_logging' );
            }
        }
    }

    /**
     * Recursively get all "to" email adresses
     *
     * @link https://plugins.trac.wordpress.org/browser/mailarchiver/tags/4.0.0/includes/listeners/class-corelistener.php#L116
     * @since    7.1.0
     */
    public function get_all_emails__premium_only( $a, &$result ) {
        if ( is_array( $a ) ) {
            foreach ( $a as $item ) {
                $this->get_all_emails__premium_only( $item, $result );
            }
        }
        if ( is_object( $a ) ) {
            foreach ( (array) $a as $item ) {
                $this->get_all_emails__premium_only( $item, $result );
            }
        }
        if ( is_string( $a ) && false !== strpos( $a, '@' ) ) {
            $result[] = trim( $a) ;
        }
    }
    
    /**
     * Get backtrace info for debugging
     * 
     * @link https://plugins.trac.wordpress.org/browser/wp-mail-catcher/tags/2.1.9/src/Loggers/LogHelper.php#L181
     * @since 7.1.0
     */
    public function get_backtrace__premium_only( $function_name = 'wp_mail' ) {
        $backtrace_segment = null;
        $backtrace = debug_backtrace();
        
        foreach ( $backtrace as $segment ) {
            if ( $function_name == $segment['function'] ) {
                $backtrace_segment = $segment;
                $backtrace_segment['file'] = '/' . str_replace( ABSPATH, '', $backtrace_segment['file'] );
                unset( $backtrace_segment['args'] ); // This contains email to, subject, message, header. Not needed.
            }
        }
        
        return $backtrace_segment; // array
    }

    /**
     * Add submenu item and admin page for the email delivery log
     * 
     * @since 7.1.0
     */
    public function add_email_log_submenu__premium_only() {
        add_submenu_page(
            'tools.php', // Parent page/menu
            __( 'Email Delivery Log', 'admin-site-enhancements' ), // Browser tab/window title
            __( 'Email Log', 'admin-site-enhancements' ), // Sube menu title
            'manage_options', // Minimal user capabililty
            'email-delivery-log', // Page slug. Shows up in URL.
            array( $this, 'add_email_log_page__premium_only' )
        );
    }
    
    /**
     * Output the email delivery log page
     * 
     * @since 7.1.0
     */
    public function add_email_log_page__premium_only() {
        $list_table = new Email_Log_Table();
        $list_table->prepare_items();
        $clear_log_nonce = wp_create_nonce( 'asenha-clear-log-' . get_current_user_id() );
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline"><?php echo esc_html( get_admin_page_title() ); ?></h2>
            <a href="admin.php?action=clear_log&amp;nonce=<?php echo wp_kses_post( $clear_log_nonce ); ?>" class="page-title-action clear-log-button"><?php echo __( 'Clear Log', 'admin-site-enhancements' ); ?></a>
            <hr class="wp-header-end">
            <?php $list_table->views(); ?>
            <form method="get">
                <?php $list_table->search_box( __( 'Search', 'admin-site-enhancements' ) , 'search'); ?>
                <?php $list_table->display(); ?>
            </form>
        </div>
        <div class="log-more-info">
            <div class="popup">
                <div class="modal-content">
                    <div class="modal-header">
                        <span class="close">×</span>
                        <h2 class="modal-title"><?php echo esc_html__( 'Email Delivery Log', 'admin-site-enhancements' ); ?></h2>
                        <div class="modal-message"></div>
                    </div>
                    <div class="modal-body">
                        <div class="loader"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="#2271b1" d="M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm0,19a8,8,0,1,1,8-8A8,8,0,0,1,12,20Z" opacity=".25"/><path fill="#2271b1" d="M12,4a8,8,0,0,1,7.89,6.7A1.53,1.53,0,0,0,21.38,12h0a1.5,1.5,0,0,0,1.48-1.75,11,11,0,0,0-21.72,0A1.5,1.5,0,0,0,2.62,12h0a1.53,1.53,0,0,0,1.49-1.3A8,8,0,0,1,12,4Z"><animateTransform attributeName="transform" dur="0.75s" repeatCount="indefinite" type="rotate" values="0 12 12;360 12 12"/></path></svg></div>
                        <div class="data"></div>
                    </div>
                    <div class="modal-footer">
                        <label id="resend-to-label" for="resend-to" style="display:none;"><?php echo esc_html__( 'Resend to', 'admin-site-enhancements' ); ?></label>
                        <input type="text" id="resend-to" name="resend-to" class="resend-to" placeholder="" value="" style="display:none;">
                        <div class="primary-action-wrapper">
                            <button type="button" class="button button-default footer-close primary-action"><?php echo esc_html__( 'Close', 'admin-site-enhancements' ); ?></button>
                            <div class="resend-loader" style="display:none;"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="#2271b1" d="M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm0,19a8,8,0,1,1,8-8A8,8,0,0,1,12,20Z" opacity=".25"/><path fill="#2271b1" d="M12,4a8,8,0,0,1,7.89,6.7A1.53,1.53,0,0,0,21.38,12h0a1.5,1.5,0,0,0,1.48-1.75,11,11,0,0,0-21.72,0A1.5,1.5,0,0,0,2.62,12h0a1.53,1.53,0,0,0,1.49-1.3A8,8,0,0,1,12,4Z"><animateTransform attributeName="transform" dur="0.75s" repeatCount="indefinite" type="rotate" values="0 12 12;360 12 12"/></path></svg></div>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Get the log entry data by the table row id
     * 
     * @since 7.1.0
     */
    public function get_ed_log_data__premium_only() {
        if ( current_user_can( 'manage_options' )
             && wp_verify_nonce( sanitize_text_field( $_POST['nonce'] ), 'email-delivery-log' . get_current_user_id() ) 
        ) {
            global $wpdb;
            $table_name  = $wpdb->prefix.'asenha_email_delivery';
            $table_row_id = isset( $_POST['db_row_id'] ) ? intval( $_POST['db_row_id'] ) : 0;
            $db_row_data = $wpdb->get_row( "SELECT * FROM $table_name WHERE id = '$table_row_id' LIMIT 1 ", ARRAY_A );
            
            $purpose = sanitize_text_field( $_POST['purpose'] );
            
            switch ( $purpose ) {
                case 'view':
                    $popup_html = $this->assemble_log_details_popup_html__premium_only( $db_row_data );
                    break;

                case 'resend':
                    $popup_html = $this->assemble_resend_email_popup_html__premium_only( $db_row_data );
                    break;
            }
            echo $popup_html;
            die();            
        } else {
            echo '';
            die();
        }
    }
    
    /**
     * Assemble email log entry's popup HTML from raw database data
     * 
     * @since 7.1.0
     */
    public function assemble_log_details_popup_html__premium_only( $db_row_data ) {
        $status = sanitize_text_field( $db_row_data['status'] );
        switch ( $status ) {
            case 'successful':
                $status_message = '<div class="delivery-status"><span class="status-indicator status-successful"></span>' . __( 'Successful', 'admin-site-enhancements' ) . '</div>';
                break;
            case 'failed':
                $status_message = '<div class="delivery-status"><span class="status-indicator status-failed"></span>' . __( 'Failed', 'admin-site-enhancements' ) . '</div>';
                break;
            case '':
                $status_message = '<div class="delivery-status"><span class="status-indicator status-unknown"></span>' . __( 'Unknown', 'admin-site-enhancements' ) . '</div>';
                break;
        }
        $error = sanitize_text_field( $db_row_data['error'] );
        $subject = sanitize_text_field( $db_row_data['subject'] );

        // Get message text
        preg_match("/<body[^>]*>(.*?)<\/body>/is", $db_row_data['message'], $matches);
        $message_source = $db_row_data['message'];
        $message_text = isset( $matches[1] ) ? $matches[1] : $message_source;
        $message_text = preg_replace_callback('/\<[\w.]+@[\w.]+\>/', function( $arr ) {
            return esc_html( $arr[0] );
        }, $message_text);

        $content_type = $db_row_data['content_type'];
        if ( 'text/plain' == $content_type ) {
            $message_text = nl2br( $message_text );
        }
        if ( 'text/html' == $content_type ) {
            $message_text = str_replace( array( '\r\n','\n' ), PHP_EOL, $message_text );
        }
        $message = stripslashes( $message_text );

        $send_to = str_replace( array( '(', ')' ), array( '<', '>' ), $db_row_data['send_to'] );
        $sender = str_replace( array( '(', ')' ), array( '<', '>' ), $db_row_data['sender'] );
        $reply_to = str_replace( array( '(', ')' ), array( '<', '>' ), $db_row_data['reply_to'] );

        $headers_raw = unserialize( $db_row_data['headers'] );
        
        $attachment_urls = '';
        $attachments = unserialize( $db_row_data['attachments'] );
        if ( is_array( $attachments ) & ! empty( $attachments ) ) {
            foreach ( $attachments as $attachment ) {
                $attachment_url = str_replace( ABSPATH, get_site_url() . '/', $attachment );
                $attachment_filename_parts = explode( '/', $attachment );
                $attachment_filename = end( $attachment_filename_parts );
                $attachment_urls .= '<a href="' . $attachment_url . '" target="_blank">' . $attachment_filename . '</a>'; 
            }
        }

        $processor = sanitize_text_field( $db_row_data['processor'] );
        $backtrace = json_decode( $db_row_data['backtrace'], true );
        $backtrace_file = '';
        $backtrace_line = '';
        $backtrace_function = '';
        if ( is_array( $backtrace ) && ! empty( $backtrace ) ) {
            $backtrace_file = isset( $backtrace['file'] ) ? $backtrace['file'] : '';
            $backtrace_line = isset( $backtrace['line'] ) ? $backtrace['line'] : '';
            $backtrace_function = isset( $backtrace['function'] ) ? $backtrace['function'] : '';
        }
        
        $sent_datetime = \DateTime::createFromFormat( 'Y-m-d H:i:s', $db_row_data['sent_on'] );
        $sent_on    = sprintf( '%1$s %2$s %3$s', 
                            $sent_datetime->format( 'F d, Y'),
                            __('at','postbox-email-logs'),
                            $sent_datetime->format('g:i a')
                        );

        $extra = unserialize( $db_row_data['extra'] );
        $bcc = str_replace( ',', ', ', $extra['bcc'] );

        ob_start();
        ?>
        <div id="log-more-info-tabs">
            <ul>
                <li><a href="#tab-info"><?php echo esc_html__('Info','admin-site-enhancements') ?></a></li>
                <li><a href="#tab-message"><?php echo esc_html__('Message','admin-site-enhancements') ?></a></li>
                <li><a href="#tab-source"><?php echo esc_html__('Source','admin-site-enhancements') ?></a></li>
            </ul>

            <div id="tab-info">
                <div class="email-info">
                    <div class="subject">
                        <div class="info-heading"><?php echo esc_html__( 'Subject', 'admin-site-enhancements' ); ?></div>
                        <div class="info-content"><?php echo esc_html( $subject ); ?></div>
                    </div>
                    <div class="send-to">
                        <div class="info-heading"><?php echo esc_html__( 'To', 'admin-site-enhancements' ); ?></div>
                        <div class="info-content"><?php echo esc_html( $send_to ); ?></div>
                    </div>
                    <div class="sender">
                        <div class="info-heading"><?php echo esc_html__( 'Sender', 'admin-site-enhancements' ); ?></div>
                        <div class="info-content"><?php echo esc_html( $sender ); ?></div>
                    </div>
                    <div class="reply-to">
                        <div class="info-heading"><?php echo esc_html__( 'Reply to', 'admin-site-enhancements' ); ?></div>
                        <div class="info-content"><?php echo esc_html( $reply_to ); ?></div>
                    </div>
                    <?php if ( ! empty( $bcc ) ) : ?>
                    <div class="bcc">
                        <div class="info-heading"><?php echo esc_html__( 'Bcc', 'admin-site-enhancements' ); ?></div>
                        <div class="info-content"><?php echo esc_html( $bcc ); ?></div>
                    </div>
                    <?php endif; ?>
                    <div class="delivery-status">
                        <div class="info-heading"><?php echo esc_html__( 'Delivery status', 'admin-site-enhancements' ); ?></div>
                        <div class="info-content"><?php echo wp_kses_post( $status_message ); ?></div>
                    </div>
                    <?php
                    if ( 'failed' == $status ) {
                        ?>
                        <div class="delivery-error">
                            <div class="info-heading"><?php echo esc_html__( 'Error', 'admin-site-enhancements' ); ?></div>
                            <div class="info-content"><?php echo wp_kses_post( $error ); ?></div>
                        </div>
                        <?php
                    }
                    ?>
                    <div class="headers">
                        <div class="info-heading"><?php echo esc_html__( 'Headers', 'admin-site-enhancements' ); ?></div>
                        <div class="info-content">
                        <?php
                        $headers = '';
                        if ( is_array( $headers_raw ) && ! empty( $headers_raw ) ) {
                            foreach ( $headers_raw as $header ) {
                                echo esc_html( $header ) . '<br />';
                            }
                        }
                        ?>
                        </div>
                    </div>
                    <div class="attachments">
                        <div class="info-heading"><?php echo esc_html__( 'Attachments', 'admin-site-enhancements' ); ?></div>
                        <div class="info-content">
                            <?php echo wp_kses_post( $attachment_urls ); ?>
                        </div>
                    </div>
                    <div class="debug">
                        <div class="info-heading"><?php echo esc_html__( 'Debug', 'admin-site-enhancements' ); ?></div>
                        <div class="info-content">
                            <?php echo esc_html__( 'Triggered from:', 'admin-site-enhancements' ) . ' ' . wp_kses_post( $backtrace_file ) . '<br />'; ?>
                            <?php echo esc_html__( 'On line:', 'admin-site-enhancements' ) . ' ' . wp_kses_post( $backtrace_line ) . '<br />'; ?>
                            <?php echo esc_html__( 'Function:', 'admin-site-enhancements' ) . ' ' . wp_kses_post( $backtrace_function ) . '<br />'; ?>
                        </div>
                    </div>
                    <div class="delivery-processor">
                        <div class="info-heading"><?php echo esc_html__( 'Processor', 'admin-site-enhancements' ); ?></div>
                        <div class="info-content"><?php echo wp_kses_post( $processor ); ?></div>
                    </div>
                </div>
            </div>
            <div id="tab-message">
                <?php echo wp_kses( $message, $this->allowed_html__premium_only() ); ?>
            </div>
            <div id="tab-source">
                <div class="source-wrap">
                    <?php echo $this->esc_message_html__premium_only( $message_source ); ?>
                </div>
            </div>
        </div>
        <?php
        // return ob_get_clean();
        $data = ob_get_clean();

        $response = array(
            'modal_message'     => '',
            'data'              => $data,
            'button_label'      => __( 'Close', 'admin-site-enhancements' ),
        );
        
        return json_encode( $response );
    }

    /**
     * Assemble email log entry's popup HTML from raw database data
     * 
     * @since 7.1.3
     */
    public function assemble_resend_email_popup_html__premium_only( $db_row_data ) {
        $subject = sanitize_text_field( $db_row_data['subject'] );

        // Get message text
        preg_match("/<body[^>]*>(.*?)<\/body>/is", $db_row_data['message'], $matches);
        $message_source = $db_row_data['message'];
        $message_text = isset( $matches[1] ) ? $matches[1] : $message_source;
        $message_text = preg_replace_callback('/\<[\w.]+@[\w.]+\>/', function( $arr ) {
            return esc_html( $arr[0] );
        }, $message_text);

        $content_type = $db_row_data['content_type'];
        if ( 'text/plain' == $content_type ) {
            $message_text = nl2br( $message_text );
        }
        if ( 'text/html' == $content_type ) {
            $message_text = str_replace( array( '\r\n','\n' ), PHP_EOL, $message_text );
        }
        $message = stripslashes( $message_text );

        $send_to = str_replace( array( '(', ')' ), array( '<', '>' ), $db_row_data['send_to'] );

        ob_start();
        ?>
        <div id="log-more-info-tabs">
            <ul>
                <li><a href="#tab-info"><?php echo esc_html__('Info','admin-site-enhancements') ?></a></li>
                <li><a href="#tab-message"><?php echo esc_html__('Message','admin-site-enhancements') ?></a></li>
                <li><a href="#tab-source"><?php echo esc_html__('Source','admin-site-enhancements') ?></a></li>
            </ul>

            <div id="tab-info">
                <div class="email-info">
                    <div class="subject flex-column">
                        <div class="info-heading"><?php echo esc_html__( 'Subject', 'admin-site-enhancements' ); ?></div>
                        <div class="info-content"><?php echo esc_html( $subject ); ?></div>
                    </div>
                    <div class="message-content flex-column">
                        <div class="info-heading"><?php echo esc_html__( 'Message', 'admin-site-enhancements' ); ?></div>
                        <div class="info-content"><?php echo wp_kses( $message, $this->allowed_html__premium_only() ); ?></div>
                    </div>
                </div>
            </div>
            <div id="tab-message">
            </div>
            <div id="tab-source">
            </div>
        </div>
        <?php
        $data = ob_get_clean();

        $response = array(
            'modal_message'     => __( 'You can resend the following message to the same destination or to a different one.', 'admin-site-enhancements' ),
            'db_row_id'         => $db_row_data['id'],
            'data'              => $data,
            'send_to'           => $send_to,
            'button_label'      => __( 'Resend Now', 'admin-site-enhancements' ),
        );
        
        return json_encode( $response );
    }
    
    /**
     * Escape HTML for email message
     * 
     * @link https://plugins.trac.wordpress.org/browser/postbox-email-logs/trunk/inc/utility.php#L151
     * @since 7.1.0
     */
    public function allowed_html__premium_only() {
        $allowed_tags = wp_kses_allowed_html('post');
        $allowed_tags['link'] = array(
            'rel'   => true,
            'href'  => true,
            'type'  => true,
            'media' => true,
        );
        return $allowed_tags;
    }

    /**
     * Special HTMl escaping for message source
     * 
     * @link https://plugins.trac.wordpress.org/browser/postbox-email-logs/trunk/inc/utility.php#L143
     * @since 7.1.0
     */
    public function esc_message_html__premium_only( $html ) {
        $html        = \esc_html( $html );
        $html        = str_replace( array('\r\n', '\n'), '<br/>', $html );
        $html        = nl2br( $html );
        $html        = stripslashes( $html );
        return $html;
    }

    /**
     * Trigger scheduling of email delivery log clean up event
     * 
     * @since 7.1.1
     */
    public function trigger_clear_or_schedule_log_clean_up_by_amount__premium_only( $option_name ) {
        if ( 'smtp_email_log_schedule_cleanup_by_amount' == $option_name ) {
            $this->clear_or_schedule_log_clean_up_by_amount__premium_only();        
        }
    }
    
    /**
     * Schedule email delivery log clean up event
     * 
     * @link https://plugins.trac.wordpress.org/browser/lana-email-logger/tags/1.1.0/lana-email-logger.php#L750
     * @since 7.1.1
     */
    public function clear_or_schedule_log_clean_up_by_amount__premium_only() {
        $options = get_option( ASENHA_SLUG_U, array() );
        $smtp_email_log_schedule_cleanup_by_amount = isset( $options['smtp_email_log_schedule_cleanup_by_amount'] ) ? $options['smtp_email_log_schedule_cleanup_by_amount'] : false;
        
        // If scheduled clean up is not enabled, let's clear the schedule
        if ( ! $smtp_email_log_schedule_cleanup_by_amount ) {
            wp_clear_scheduled_hook( 'asenha_email_log_cleanup_by_amount' );
            return;            
        }
        
        // If there's no next scheduled clean up event, let's schedule one
        if ( ! wp_next_scheduled( 'asenha_email_log_cleanup_by_amount' ) ) {
            wp_schedule_event( time(), 'hourly', 'asenha_email_log_cleanup_by_amount' );
        }
    }
    
    /**
     * Perform clean up of email delivery log by the amount of entries to keep
     * 
     * @link https://plugins.trac.wordpress.org/browser/lana-email-logger/tags/1.1.0/lana-email-logger.php#L768
     * @since 7.1.1
     */
    public function perform_email_log_clean_up_by_amount__premium_only() {
        global $wpdb;
        
        $options = get_option( ASENHA_SLUG_U, array() );
        $smtp_email_log_schedule_cleanup_by_amount = isset( $options['smtp_email_log_schedule_cleanup_by_amount'] ) ? $options['smtp_email_log_schedule_cleanup_by_amount'] : false;
        $smtp_email_log_entries_amount_to_keep = isset( $options['smtp_email_log_entries_amount_to_keep'] ) ? $options['smtp_email_log_entries_amount_to_keep'] : 1000;
        
        // Bail if scheduled clean up by amount is not enabled
        if ( ! $smtp_email_log_schedule_cleanup_by_amount ) {
            return;
        }
                
        $table_name  = $wpdb->prefix.'asenha_email_delivery';
        
        $wpdb->query( "DELETE email_log_entries FROM " . $table_name . " 
                        AS email_log_entries JOIN ( SELECT id FROM " . $table_name . " ORDER BY id DESC LIMIT 1 OFFSET " . $smtp_email_log_entries_amount_to_keep . " ) 
                        AS email_log_entries_limit ON email_log_entries.id <= email_log_entries_limit.id;" );
    }
    
    /**
     * Resend email that failed on the first attempt and marked as such
     * 
     * @since 7.1.3
     */
    public function resend_email__premium_only() {
        if ( isset( $_REQUEST['action'] ) 
            && 'resend_email' == $_REQUEST['action'] 
            && isset( $_REQUEST['message_id'] ) 
            && ! empty( $_REQUEST['message_id'] )
            && is_numeric( $_REQUEST['message_id'] )
            && isset( $_REQUEST['resend_to'] ) 
            && ! empty( $_REQUEST['resend_to'] )
            && isset( $_REQUEST['nonce'] ) 
            && ! empty( $_REQUEST['nonce'] )
        ) {
            $db_row_id = intval( sanitize_text_field( $_REQUEST['message_id'] ) );
            $send_to = sanitize_text_field( $_REQUEST['resend_to'] );
            $nonce = sanitize_text_field( $_REQUEST['nonce'] );
            // $nonce_check = wp_verify_nonce( $nonce, 'email-delivery-log' . get_current_user_id() );

            if ( wp_verify_nonce( $nonce, 'email-delivery-log' . get_current_user_id() ) ) {
                global $wpdb;
                $table_name  = $wpdb->prefix.'asenha_email_delivery';
        
                $email = $wpdb->get_row(
                    'SELECT * FROM ' . $table_name . '
                    WHERE id = "' . $db_row_id . '"', ARRAY_A
                );

                // Set conte type to text/html. Default is text/plain.
                add_filter( 'wp_mail_content_type', array( $this, 'return_html_email_type__premium_only' ) );
                
                // $email_sent = true; // For testing
                $email_sent = wp_mail(
                    $send_to,
                    $email['subject'],
                    $email['message'],
                    '',
                    $email['attachments']
                );
                
                // Reset content-type to avoid conflicts -- https://core.trac.wordpress.org/ticket/23578
                remove_filter( 'wp_mail_content_type', array( $this, 'return_html_email_type__premium_only' ) );
                
                if ( $email_sent ) {
                    $response = array(
                        'resend_status'     => 'successful',
                        'send_to'           => $send_to,
                        'notice_message'    => '<span class="dashicons dashicons-yes-alt"></span>' . __( 'Email was sent. This page will reload now...', 'admin-site-enhancements' ),
                    );
                    
                    echo json_encode( $response );                    
                } else {
                    $response = array(
                        'resend_status'     => 'failed',
                        'send_to'           => $send_to,
                        'notice_message'    => '<span class="dashicons dashicons-warning"></span>' . __( 'Something went wrong. Please check the latest log entry for details. This page will reload now...', 'admin-site-enhancements' ),
                    );
                    
                    echo json_encode( $response );
                }
            }
        }
    }

    /**
     * Return 'text/html' email content type for wp_mail_content_type filter hook
     * 
     * @since 7.1.3
     */
    public function return_html_email_type__premium_only() {
        return 'text/html';
    }

    /**
     * Delete individual email archive
     * 
     * @since 7.1.4
     */
    public function delete_email__premium_only() {
        if ( isset( $_REQUEST['action'] ) 
            && 'delete_email' == $_REQUEST['action'] 
            && isset( $_REQUEST['message-id'] ) 
            && ! empty( $_REQUEST['message-id'] )
            && is_numeric( $_REQUEST['message-id'] )
            && isset( $_REQUEST['nonce'] ) 
            && ! empty( $_REQUEST['nonce'] )
        ) {
            $db_row_id = intval( sanitize_text_field( $_REQUEST['message-id'] ) );
            $nonce = sanitize_text_field( $_REQUEST['nonce'] );

            if ( wp_verify_nonce( $nonce, 'asenha-delete-email-' . $db_row_id ) ) {
                global $wpdb;
                $table_name  = $wpdb->prefix.'asenha_email_delivery';

                // https://developer.wordpress.org/reference/classes/wpdb/delete/
                $result = $wpdb->delete(
                    $table_name,
                    array( 
                        'id' => $db_row_id,
                    ),
                    array(
                        '%d', // integer - id        
                    )
                );
                
                if ( 1 === $result ) {
                    wp_redirect( admin_url( 'tools.php?page=email-delivery-log&email-deletion=successful&message-id=' . $db_row_id ) );                    
                } else {
                    wp_redirect( admin_url( 'tools.php?page=email-delivery-log&email-deletion=failed&message-id=' . $db_row_id ) );
                }
                
            }
        }
    }
    
    /**
     * Show email deletion notice on deletion success
     * 
     * @since 7.1.4
     */
    public function maybe_show_email_deletion_notice__premium_only() {
        $screen = get_current_screen();
        
        if ( 'tools_page_email-delivery-log' === $screen->id ) {
            if ( isset( $_REQUEST['email-deletion'] ) 
                && in_array( $_REQUEST['email-deletion'], array( 'successful', 'failed' ) )
                && isset( $_REQUEST['message-id'] )
                && is_numeric( intval( $_REQUEST['message-id'] ) )
            ) {
                if ( 'successful' == sanitize_text_field( $_REQUEST['email-deletion'] ) ) {
                    ?>
                    <div class="notice notice-success is-dismissible">
                        <p><?php printf(
                                    /* translators: %s: email message ID */
                                    __( 'Email delivery log entry with the ID %s was successfully deleted.', 'admin-site-enhancements' ),
                                    intval( $_REQUEST['message-id'] )
                                )
                            ?>
                        </p>
                    </div>
                    <?php
                } else if ( 'failed' == sanitize_text_field( $_REQUEST['email-deletion'] ) ) {
                    ?>
                    <div class="notice notice-error is-dismissible">
                        <p><?php printf(
                                    /* translators: %s: email message ID */
                                    __( 'Something went wrong. Unable to delete email delivery log entry with the ID %s.', 'admin-site-enhancements' ),
                                    intval( $_REQUEST['message-id'] )
                                )
                            ?>
                        </p>
                    </div>
                    <?php
                }
            }
        }
        
    }

    /**
     * Clear the email delivery log. This will delete all data.
     * 
     * @since 7.1.4
     */
    public function clear_log__premium_only() {
        if ( isset( $_REQUEST['action'] ) 
            && 'clear_log' == $_REQUEST['action'] 
            && isset( $_REQUEST['nonce'] ) 
            && ! empty( $_REQUEST['nonce'] )
        ) {
            $nonce = sanitize_text_field( $_REQUEST['nonce'] );
            if ( wp_verify_nonce( $nonce, 'asenha-clear-log-' . get_current_user_id() ) ) {
                global $wpdb;
                $table_name  = $wpdb->prefix.'asenha_email_delivery';
                
                // https://developer.wordpress.org/reference/classes/wpdb/query/
                $result = $wpdb->query( "TRUNCATE {$table_name}" );

                if ( $result ) {
                    wp_redirect( admin_url( 'tools.php?page=email-delivery-log&clear-log=successful' ) );                    
                } else {
                    wp_redirect( admin_url( 'tools.php?page=email-delivery-log&clear-log=failed' ) );
                }
            }
        }
    }

    /**
     * Show clear log notice on clearing success
     * 
     * @since 7.1.4
     */
    public function maybe_show_clear_log_notice__premium_only() {
        $screen = get_current_screen();
        
        if ( 'tools_page_email-delivery-log' === $screen->id ) {
            if ( isset( $_REQUEST['clear-log'] ) 
                && in_array( $_REQUEST['clear-log'], array( 'successful', 'failed' ) )
            ) {
                if ( 'successful' == sanitize_text_field( $_REQUEST['clear-log'] ) ) {
                    ?>
                    <div class="notice notice-success is-dismissible">
                        <p><?php echo __( 'Log has been successfully cleared.', 'admin-site-enhancements' ); ?></p>
                    </div>
                    <?php
                } else if ( 'failed' == sanitize_text_field( $_REQUEST['clear-log'] ) ) {
                    ?>
                    <div class="notice notice-error is-dismissible">
                        <p><?php echo __( 'Something went wrong. Log was not cleared.', 'admin-site-enhancements' ); ?></p>
                    </div>
                    <?php
                }
            }
        }
        
    }
}