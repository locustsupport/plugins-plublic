<?php
/**
 * Code Snippets Manager
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Code_Snippets_Manager_Install 
 */
class Code_Snippets_Manager_Install {

    public static function install() {
        self::create_roles();
        self::register_post_type();
        flush_rewrite_rules();
    }  

    /**
     * List of capability names for the code_snippets post type (see register_post_type()).
     *
     * @return string[]
     */
    private static function get_snippet_capability_names() {
        $capability_types = array( 'code_snippets' );
        $names            = array();

        foreach ( $capability_types as $capability_type ) {
            $names = array_merge(
                $names,
                array(
                    "edit_{$capability_type}",
                    "read_{$capability_type}",
                    "delete_{$capability_type}",
                    "edit_{$capability_type}s",
                    "edit_others_{$capability_type}s",
                    "publish_{$capability_type}s",
                    "delete_{$capability_type}s",
                    "delete_published_{$capability_type}s",
                    "delete_others_{$capability_type}s",
                    "edit_published_{$capability_type}s",
                )
            );
        }

        return $names;
    }

    /**
     * Whether a role has a single snippet capability granted.
     *
     * @param WP_Roles $wp_roles Roles object.
     * @param string   $role     Role slug.
     * @param string   $cap      Capability name.
     * @return bool
     */
    private static function role_has_snippet_cap( $wp_roles, $role, $cap ) {
        if ( ! isset( $wp_roles->roles[ $role ] ) ) {
            return false;
        }

        return ! empty( $wp_roles->roles[ $role ]['capabilities'][ $cap ] );
    }

    /**
     * Whether a role has every snippet capability granted.
     *
     * @param WP_Roles $wp_roles Roles object.
     * @param string   $role     Role slug.
     * @param string[] $caps     Capability names.
     * @return bool
     */
    private static function role_has_all_snippet_caps( $wp_roles, $role, $caps ) {
        foreach ( $caps as $cap ) {
            if ( ! self::role_has_snippet_cap( $wp_roles, $role, $cap ) ) {
                return false;
            }
        }

        return true;
    }

    /**
     * Whether snippet capabilities or the editor role still need to be synced.
     *
     * @param bool|null $disable_custom_role When non-null, use this instead of the saved option (e.g. during settings sanitization before the option is written).
     * @return bool True when add_cap/add_role should run.
     */
    private static function snippet_capabilities_need_sync( $disable_custom_role = null ) {
        global $wp_roles;

        if ( ! class_exists( 'WP_Roles' ) ) {
            return true;
        }

        if ( ! isset( $wp_roles ) ) {
            $wp_roles = new WP_Roles();
        }

        $caps = self::get_snippet_capability_names();

        if ( ! self::role_has_all_snippet_caps( $wp_roles, 'administrator', $caps ) ) {
            return true;
        }

        if ( null === $disable_custom_role ) {
            $disable_custom_role = self::is_snippet_editor_role_disabled();
        }

        if ( $disable_custom_role ) {
            if ( get_role( 'code_snippets_editor' ) ) {
                return true;
            }

            return false;
        }

        if ( ! isset( $wp_roles->roles['code_snippets_editor'] ) ) {
            return true;
        }

        return ! self::role_has_all_snippet_caps( $wp_roles, 'code_snippets_editor', $caps );
    }

    /**
     * Whether the ASE setting to disable the Code Snippets Editor role is enabled.
     *
     * @return bool
     */
    public static function is_snippet_editor_role_disabled() {
        $options = get_option( ASENHA_SLUG_U, array() );

        return ! empty( $options['code_snippets_disable_custom_role'] );
    }

    /**
     * Remove the code_snippets_editor role when the disable setting is on.
     *
     * @param bool|null $disable_custom_role When non-null, use this instead of the saved option.
     * @return void
     */
    public static function remove_snippet_editor_role_if_disabled( $disable_custom_role = null ) {
        if ( null === $disable_custom_role ) {
            $disable_custom_role = self::is_snippet_editor_role_disabled();
        }

        if ( $disable_custom_role && get_role( 'code_snippets_editor' ) ) {
            remove_role( 'code_snippets_editor' );
        }
    }

    /**
     * Keep legacy CSM add_role extra setting off when ASE disables the editor role.
     *
     * @return void
     */
    public static function sync_legacy_add_role_setting_with_disable_option() {
        if ( ! self::is_snippet_editor_role_disabled() ) {
            return;
        }

        $extra_options = get_option( ASENHA_SLUG_U . '_extra', array() );

        if ( ! is_array( $extra_options ) ) {
            return;
        }

        $settings = isset( $extra_options['code_snippets_manager_settings'] ) ? $extra_options['code_snippets_manager_settings'] : array();

        if ( empty( $settings['add_role'] ) ) {
            return;
        }

        $settings['add_role']                           = false;
        $extra_options['code_snippets_manager_settings'] = $settings;
        update_option( ASENHA_SLUG_U . '_extra', $extra_options, true );
    }

    /**
     * Ensure snippet capabilities exist on the administrator role, and optionally on code_snippets_editor.
     *
     * Re-applies missing caps so stripped caps are repaired on the next admin load. Skips work when
     * caps are already correct (avoids wp_user_roles option churn) and on heartbeat admin-ajax.
     * When "Disable the Code Snippets Editor role" is on, only administrator is updated.
     *
     * @param bool|null $disable_custom_role When non-null, use this instead of the saved option (e.g. during settings sanitization before the option is written).
     * @since ASE Pro (CSM capability sync hardening)
     */
    public static function sync_snippet_capabilities( $disable_custom_role = null ) {
        global $wp_roles;

        if ( wp_doing_ajax() && isset( $_POST['action'] ) && 'heartbeat' === $_POST['action'] ) {
            return;
        }

        if ( null === $disable_custom_role ) {
            $disable_custom_role = self::is_snippet_editor_role_disabled();
        }

        self::remove_snippet_editor_role_if_disabled( $disable_custom_role );

        if ( ! current_user_can( 'update_plugins' ) ) {
            return;
        }

        if ( ! class_exists( 'WP_Roles' ) ) {
            return;
        }

        if ( ! isset( $wp_roles ) ) {
            $wp_roles = new WP_Roles();
        }

        if ( ! self::snippet_capabilities_need_sync( $disable_custom_role ) ) {
            return;
        }

        $caps = self::get_snippet_capability_names();

        foreach ( $caps as $cap ) {
            if ( ! self::role_has_snippet_cap( $wp_roles, 'administrator', $cap ) ) {
                $wp_roles->add_cap( 'administrator', $cap );
            }
        }

        if ( $disable_custom_role || self::is_snippet_editor_role_disabled() ) {
            return;
        }

        if ( ! isset( $wp_roles->roles['code_snippets_editor'] ) ) {
            add_role( 'code_snippets_editor', __( 'Code Snippets Editor', 'admin-site-enhancements' ), array() );
        }

        foreach ( $caps as $cap ) {
            if ( ! self::role_has_snippet_cap( $wp_roles, 'code_snippets_editor', $cap ) ) {
                $wp_roles->add_cap( 'code_snippets_editor', $cap );
            }
        }
    }

    /**
     * Create roles and capabilities.
     *
     * @see sync_snippet_capabilities()
     */
    public static function create_roles() {
        self::sync_snippet_capabilities();
    }

    /**
     * Create the code-snippets-manager post type
     */
    public static function register_post_type() {
        $labels = array(
            'name'                   => _x( 'Code Snippets', 'post type general name', 'admin-site-enhancements'),
            'singular_name'          => _x( 'Code Snippet', 'post type singular name', 'admin-site-enhancements'),
            'menu_name'              => _x( 'Code Snippets', 'admin menu', 'admin-site-enhancements'),
            'name_admin_bar'         => _x( 'Code Snippet', 'add new on admin bar', 'admin-site-enhancements'),
            'add_new'                => _x( 'Add Code Snippet', 'add new', 'admin-site-enhancements'),
            'add_new_item'           => __( 'Add Code Snippet', 'admin-site-enhancements'),
            'new_item'               => __( 'New Code Snippet', 'admin-site-enhancements'),
            'edit_item'              => __( 'Edit Code Snippet', 'admin-site-enhancements'),
            'view_item'              => __( 'View Code Snippet', 'admin-site-enhancements'),
            'all_items'              => __( 'All Code Snippets', 'admin-site-enhancements'),
            'search_items'           => __( 'Search Code Snippets', 'admin-site-enhancements'),
            'parent_item_colon'      => __( 'Parent Code Snippet:', 'admin-site-enhancements'),
            'not_found'              => __( 'No Code Snippets found.', 'admin-site-enhancements'),
            'not_found_in_trash'     => __( 'No Code Snippets found in Trash.', 'admin-site-enhancements')
        );

        $capability_type = 'code_snippets';
        $capabilities = array(
            'edit_post'              => "edit_{$capability_type}",
            'read_post'              => "read_{$capability_type}",
            'delete_post'            => "delete_{$capability_type}",
            'edit_posts'             => "edit_{$capability_type}s",
            'edit_others_posts'      => "edit_others_{$capability_type}s",
            'publish_posts'          => "publish_{$capability_type}s",
            'read'                   => "read_{$capability_type}",
            'delete_posts'           => "delete_{$capability_type}s",
            'delete_published_posts' => "delete_published_{$capability_type}s",
            'delete_others_posts'    => "delete_others_{$capability_type}s",
            'edit_published_posts'   => "edit_published_{$capability_type}s",
            'create_posts'           => "edit_{$capability_type}s",
        );

        $menu_icon = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgdmlld0JveD0iMCAwIDIwIDIwIj48cGF0aCBmaWxsPSJjdXJyZW50Q29sb3IiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTYuMjggNS4yMmEuNzUuNzUgMCAwIDEgMCAxLjA2TDIuNTYgMTBsMy43MiAzLjcyYS43NS43NSAwIDAgMS0xLjA2IDEuMDZMLjk3IDEwLjUzYS43NS43NSAwIDAgMSAwLTEuMDZsNC4yNS00LjI1YS43NS43NSAwIDAgMSAxLjA2IDBabTcuNDQgMGEuNzUuNzUgMCAwIDEgMS4wNiAwbDQuMjUgNC4yNWEuNzUuNzUgMCAwIDEgMCAxLjA2bC00LjI1IDQuMjVhLjc1Ljc1IDAgMCAxLTEuMDYtMS4wNkwxNy40NCAxMGwtMy43Mi0zLjcyYS43NS43NSAwIDAgMSAwLTEuMDZabS0yLjM0My0zLjIwOWEuNzUuNzUgMCAwIDEgLjYxMi44NjdsLTIuNSAxNC41YS43NS43NSAwIDAgMS0xLjQ3OC0uMjU1bDIuNS0xNC41YS43NS43NSAwIDAgMSAuODY2LS42MTJaIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=';
        if ( \ASENHA\Classes\Admin_Menu_Svg_Icon_Mask::is_svg_data_uri( $menu_icon ) ) {
            \ASENHA\Classes\Admin_Menu_Svg_Icon_Mask::register_post_type_svg_icon( 'asenha_code_snippet', $menu_icon );
            $menu_icon = 'dashicons-admin-generic';
        }

        $args = array(
            'labels'                 => $labels,
            'description'            => __( 'CSS, JS, HTML and PHP code snippets', 'admin-site-enhancements' ),
            'public'                 => true,
            'publicly_queryable'     => false,
            'show_ui'                => true,
            'show_in_menu'           => true,
            // https://icon-sets.iconify.design/heroicons/code-bracket-20-solid/
            'menu_icon'              => $menu_icon,
            'query_var'              => false,
            'rewrite'                => array( 'slug' => 'code-snippet' ),
            'capability_type'        => $capability_type,
            'capabilities'           => $capabilities, 
            'has_archive'            => true,
            'hierarchical'           => false,
            'exclude_from_search'    => true,
            'can_export'             => false,
            'supports'               => array( 'title', 'page-attributes', 'revisions' ),
            'taxonomies'             => array( 'asenha_code_snippet_category' ),
        );

        register_post_type( 'asenha_code_snippet', $args );
    }
    
    /**
     * Create snippet category taxonomy
     * 
     * @since 6.3.1
     */
    public static function register_category() {
        $labels = array(
            'name'              => 'Snippet Categories',
            'singular_name'     => 'Snippet Category',
            'menu_name'         => 'Snippet Categories',
            'search_items'      => 'Search Snippet Categories',
            'all_items'         => 'All Categories',
            'edit_item'         => 'Edit Snippet Category',
            'update_item'       => 'Update Snippet Category',
        );
      
        $args = array(
            'public'                => false,
            'publicly_queryable'    => false,
            'hierarchical'          => true,
            'labels'                => $labels,
            'show_ui'               => true,
            'show_in_menu'          => true,
            'show_admin_column'     => true,
            'show_in_quick_edit'    => true,
            'capabilities'          => array(
                                        'manage_terms'      => 'manage_categories',
                                        'edit_terms'        => 'manage_categories',
                                        'delete_terms'      => 'manage_categories',
                                        'assign_terms'      => 'edit_code_snippets',
            ),
            'query_var'             => false,
            'rewrite'               => false,
            'default_term'          => array(
                                        'name'      => 'Uncategorized',
                                        'slug'      => 'uncategorized',
            ),
        );
      
        register_taxonomy( 'asenha_code_snippet_category', 'asenha_code_snippet', $args );
    }
    
}

?>
