<?php
/**
 * CSM storage / snippet-post helpers (Pro).
 *
 * Loaded from settings UI when Code Snippets Manager is inactive, and from code-snippets-manager.php when active.
 *
 * @package Admin_Site_Enhancements
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'asenha_csm_has_at_least_one_snippet_post__premium_only' ) ) {
	/**
	 * Whether the site has at least one Code Snippets Manager post (any status except trash).
	 *
	 * Uses a direct query so it works before `init` / CPT registration.
	 *
	 * @return bool
	 */
	function asenha_csm_has_at_least_one_snippet_post__premium_only() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- single existence check; no API before init.
		$one = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1 FROM {$wpdb->posts} WHERE post_type = %s AND post_status != %s LIMIT 1",
				'asenha_code_snippet',
				'trash'
			)
		);

		return (bool) $one;
	}
}
