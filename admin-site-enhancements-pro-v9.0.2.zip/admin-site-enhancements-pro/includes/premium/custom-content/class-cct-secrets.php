<?php
/**
 * Encrypt/decrypt CCT secrets stored in admin_site_enhancements.
 *
 * Currently used for the Google Maps API key consumed by CFG Map fields.
 *
 * @package ASENHA
 */

namespace ASENHA\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CCT secrets encryption helper.
 */
class CCT_Secrets {

	const GOOGLE_MAPS_API_KEY_PREFIX = 'asenha_encrypted::cct_google_maps_api_key::v1::';

	/**
	 * Whether OpenSSL encryption is available.
	 *
	 * @return bool
	 */
	public function can_encrypt() {
		return function_exists( 'openssl_encrypt' )
			&& function_exists( 'openssl_decrypt' )
			&& function_exists( 'openssl_cipher_iv_length' )
			&& function_exists( 'random_bytes' );
	}

	/**
	 * Whether a value looks like our encrypted Google Maps API key payload.
	 *
	 * @param mixed $value Candidate value.
	 * @return bool
	 */
	public function is_probable_ciphertext( $value ) {
		return is_string( $value )
			&& 0 === strpos( $value, self::GOOGLE_MAPS_API_KEY_PREFIX );
	}

	/**
	 * Encrypt a Google Maps API key for storage.
	 *
	 * @param string $api_key Plaintext API key.
	 * @return string Encrypted payload or empty string on failure.
	 */
	public function encrypt_google_maps_api_key( $api_key ) {
		$api_key = is_string( $api_key ) ? trim( $api_key ) : '';

		if ( '' === $api_key || $this->is_probable_ciphertext( $api_key ) || ! $this->can_encrypt() ) {
			return '';
		}

		$key = $this->get_or_create_secret_key();

		if ( false === $key ) {
			return '';
		}

		return $this->encrypt_with_key( $api_key, $key, self::GOOGLE_MAPS_API_KEY_PREFIX );
	}

	/**
	 * Decrypt a stored Google Maps API key.
	 *
	 * @param string $stored_value Stored option value.
	 * @return string|false Plaintext key or false on failure.
	 */
	public function decrypt_google_maps_api_key( $stored_value ) {
		if ( ! is_string( $stored_value ) || '' === $stored_value ) {
			return false;
		}

		if ( ! $this->is_probable_ciphertext( $stored_value ) ) {
			// Legacy plaintext (should not normally occur after first save).
			return $stored_value;
		}

		$key = $this->get_or_create_secret_key();

		if ( false === $key ) {
			return false;
		}

		return $this->decrypt_with_key( $stored_value, $key, self::GOOGLE_MAPS_API_KEY_PREFIX );
	}

	/**
	 * Get plaintext Google Maps API key from main options, or empty string.
	 *
	 * @return string
	 */
	public function get_google_maps_api_key() {
		$options = get_option( ASENHA_SLUG_U, array() );
		$stored  = isset( $options['cct_google_maps_api_key'] ) ? $options['cct_google_maps_api_key'] : '';

		if ( '' === $stored ) {
			return '';
		}

		$plaintext = $this->decrypt_google_maps_api_key( $stored );

		return ( false !== $plaintext && is_string( $plaintext ) ) ? $plaintext : '';
	}

	/**
	 * UI state for the API key settings field.
	 *
	 * @param array $options Current options array.
	 * @return array{description:string,has_key:bool}
	 */
	public function get_api_key_ui_state( $options ) {
		$stored  = isset( $options['cct_google_maps_api_key'] ) ? $options['cct_google_maps_api_key'] : '';
		$has_key = ( '' !== $stored );

		if ( $has_key ) {
			$description = __( 'A Google Maps API key is saved. Leave blank to keep it, or enter a new key to replace it.', 'admin-site-enhancements' );
		} else {
			$description = __( 'Required for Map fields that use Google Maps. Enable Maps JavaScript API, Places API (New) for address search, and Geocoding API for reverse geocode. Legacy Places API is still supported as a fallback. Restrict the key by HTTP referrer.', 'admin-site-enhancements' );
		}

		return array(
			'description' => $description,
			'has_key'     => $has_key,
		);
	}

	/**
	 * Get or create the per-site encryption key.
	 *
	 * @return string|false Raw 32-byte key or false.
	 */
	private function get_or_create_secret_key() {
		$options_extra = get_option( ASENHA_SLUG_U . '_extra', array() );

		if ( ! is_array( $options_extra ) ) {
			$options_extra = array();
		}

		if ( ! empty( $options_extra['cct_google_maps_secret_key'] ) ) {
			$decoded = base64_decode( $options_extra['cct_google_maps_secret_key'], true );

			if ( false !== $decoded && 32 === strlen( $decoded ) ) {
				return $decoded;
			}
		}

		if ( ! $this->can_encrypt() ) {
			return false;
		}

		try {
			$key = random_bytes( 32 );
		} catch ( \Exception $exception ) {
			return false;
		}

		$options_extra['cct_google_maps_secret_key'] = base64_encode( $key );
		update_option( ASENHA_SLUG_U . '_extra', $options_extra, true );

		return $key;
	}

	/**
	 * Encrypt a string with AES-256-CBC + HMAC-SHA256.
	 *
	 * @param string $plaintext Plaintext.
	 * @param string $key       Encryption key.
	 * @param string $prefix    Storage prefix.
	 * @return string
	 */
	private function encrypt_with_key( $plaintext, $key, $prefix ) {
		$cipher = 'AES-256-CBC';
		$iv_len = openssl_cipher_iv_length( $cipher );

		if ( false === $iv_len ) {
			return '';
		}

		try {
			$iv = random_bytes( $iv_len );
		} catch ( \Exception $exception ) {
			return '';
		}

		$ciphertext_raw = openssl_encrypt( $plaintext, $cipher, $key, OPENSSL_RAW_DATA, $iv );

		if ( false === $ciphertext_raw ) {
			return '';
		}

		$hmac = hash_hmac( 'sha256', $ciphertext_raw, $key, true );

		return $prefix . base64_encode( $iv . $hmac . $ciphertext_raw );
	}

	/**
	 * Decrypt a prefixed ciphertext payload.
	 *
	 * @param string $stored_value Prefixed ciphertext.
	 * @param string $key          Encryption key.
	 * @param string $prefix       Storage prefix.
	 * @return string|false
	 */
	private function decrypt_with_key( $stored_value, $key, $prefix ) {
		if ( 0 !== strpos( $stored_value, $prefix ) || ! $this->can_encrypt() ) {
			return false;
		}

		$payload = substr( $stored_value, strlen( $prefix ) );
		$decoded = base64_decode( $payload, true );

		if ( false === $decoded ) {
			return false;
		}

		$cipher = 'AES-256-CBC';
		$iv_len = openssl_cipher_iv_length( $cipher );

		if ( false === $iv_len || strlen( $decoded ) <= ( $iv_len + 32 ) ) {
			return false;
		}

		$iv             = substr( $decoded, 0, $iv_len );
		$stored_hmac    = substr( $decoded, $iv_len, 32 );
		$ciphertext_raw = substr( $decoded, $iv_len + 32 );
		$calc_hmac      = hash_hmac( 'sha256', $ciphertext_raw, $key, true );

		if ( ! hash_equals( $stored_hmac, $calc_hmac ) ) {
			return false;
		}

		return openssl_decrypt( $ciphertext_raw, $cipher, $key, OPENSSL_RAW_DATA, $iv );
	}
}
