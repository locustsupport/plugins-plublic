<?php
/**
 * Export and import Custom Content Types definitions.
 *
 * Definitions are stored in WordPress posts and post meta. This class keeps
 * the JSON transport explicit so arbitrary post meta and site-specific values
 * are not included in an export.
 *
 * @package Admin and Site Enhancements
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ASENHA_CCT_Definition_Export_Import' ) ) {

	/**
	 * Custom Content Types definition import/export service.
	 */
	class ASENHA_CCT_Definition_Export_Import {

		/**
		 * Export format marker.
		 *
		 * @var string
		 */
		const PAYLOAD_FORMAT = 'asenha_custom_content_types';

		/**
		 * Current export format version.
		 *
		 * @var int
		 */
		const PAYLOAD_VERSION = 1;

		/**
		 * AJAX nonce action.
		 *
		 * @var string
		 */
		const AJAX_NONCE_ACTION = 'asenha_cct_definitions_export_ajax';

		/**
		 * Singleton instance.
		 *
		 * @var ASENHA_CCT_Definition_Export_Import|null
		 */
		private static $instance = null;

		/**
		 * Supported definition entity configuration.
		 *
		 * @var array
		 */
		private $entities = array(
			'custom_post_types'   => array(
				'post_type'   => 'asenha_cpt',
				'stable_meta' => 'cpt_key',
				'meta_prefix' => 'cpt_',
				'label'       => 'Custom Post Types',
			),
			'custom_taxonomies'   => array(
				'post_type'   => 'asenha_ctax',
				'stable_meta' => 'ctax_key',
				'meta_prefix' => 'ctax_',
				'label'       => 'Custom Taxonomies',
			),
			'custom_field_groups' => array(
				'post_type'    => 'asenha_cfgroup',
				'stable_meta'  => '',
				'managed_meta' => array(
					'cfgroup_fields',
					'cfgroup_rules',
					'cfgroup_extras',
				),
				'label'        => 'Custom Field Groups',
			),
			'options_pages'       => array(
				'post_type'   => 'options_page_config',
				'stable_meta' => 'options_page_menu_slug',
				'meta_prefix' => 'options_page_',
				'label'       => 'Options Pages',
			),
		);

		/**
		 * Get the singleton instance.
		 *
		 * @return ASENHA_CCT_Definition_Export_Import
		 */
		public static function get_instance() {
			if ( ! self::$instance instanceof self ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Get supported entity type keys.
		 *
		 * @return array
		 */
		public function get_entity_types() {
			return array_keys( $this->entities );
		}

		/**
		 * Get a configured entity type.
		 *
		 * @param string $entity_type Entity type key.
		 * @return array|false
		 */
		public function get_entity_config( $entity_type ) {
			return isset( $this->entities[ $entity_type ] ) ? $this->entities[ $entity_type ] : false;
		}

		/**
		 * Get definition posts eligible for export/manual selection.
		 *
		 * @param string $entity_type Entity type key.
		 * @return WP_Post[]
		 */
		public function get_definition_posts( $entity_type ) {
			$config = $this->get_entity_config( $entity_type );
			if ( false === $config ) {
				return array();
			}

			return get_posts(
				array(
					'post_type'           => $config['post_type'],
					'post_status'         => array( 'publish', 'draft' ),
					'numberposts'         => -1,
					'orderby'             => 'title',
					'order'               => 'ASC',
					'suppress_filters'    => false,
					'update_post_meta_cache' => true,
					'update_post_term_cache' => false,
				)
			);
		}

		/**
		 * Get safe manual-selection list data for one entity type.
		 *
		 * @param string $entity_type Entity type key.
		 * @return array
		 */
		public function get_selection_items( $entity_type ) {
			if ( false === $this->get_entity_config( $entity_type ) ) {
				return array();
			}

			$items = array();
			foreach ( $this->get_definition_posts( $entity_type ) as $post ) {
				$identity = $this->get_post_identity( $entity_type, $post );
				$edit_url = get_edit_post_link( $post->ID, '' );

				if ( empty( $edit_url ) ) {
					$edit_url = add_query_arg(
						array(
							'post'   => absint( $post->ID ),
							'action' => 'edit',
						),
						admin_url( 'post.php' )
					);
				}

				$items[] = array(
					'id'         => (int) $post->ID,
					'title'      => '' !== $post->post_title ? $post->post_title : __( '(Untitled)', 'admin-site-enhancements' ),
					'slug'       => $post->post_name,
					'identity'   => $identity,
					'status'     => $post->post_status,
					'edit_url'   => esc_url_raw( $edit_url ),
				);
			}

			return $items;
		}

		/**
		 * Build one combined export payload.
		 *
		 * @param array $selectors    Entity type => none/all/manual.
		 * @param array $selected_ids Entity type => comma-separated IDs or IDs.
		 * @return array|WP_Error
		 */
		public function build_export_payload( $selectors, $selected_ids = array() ) {
			$payload = array(
				'format'              => self::PAYLOAD_FORMAT,
				'version'             => self::PAYLOAD_VERSION,
				'custom_post_types'   => array(),
				'custom_taxonomies'   => array(),
				'custom_field_groups' => array(),
				'options_pages'       => array(),
			);

			$exported_count = 0;
			$identities     = array();

			foreach ( $this->get_entity_types() as $entity_type ) {
				$mode = isset( $selectors[ $entity_type ] ) ? sanitize_key( $selectors[ $entity_type ] ) : 'none';
				if ( ! in_array( $mode, array( 'none', 'all', 'manual' ), true ) ) {
					return new WP_Error(
						'invalid_export_type',
						__( 'One or more Custom Content Types export selections are invalid.', 'admin-site-enhancements' )
					);
				}

				if ( 'none' === $mode ) {
					continue;
				}

				if ( 'all' === $mode ) {
					$posts = $this->get_definition_posts( $entity_type );
				} else {
					$ids = isset( $selected_ids[ $entity_type ] ) ? $this->parse_id_list( $selected_ids[ $entity_type ] ) : array();
					if ( empty( $ids ) ) {
						return new WP_Error(
							'empty_manual_selection',
							sprintf(
								/* translators: %s is an entity type label. */
								__( 'Please select at least one %s to export.', 'admin-site-enhancements' ),
								$this->get_entity_label( $entity_type )
							)
						);
					}

					$posts = $this->get_posts_by_ids( $entity_type, $ids );
					if ( count( $posts ) !== count( $ids ) ) {
						return new WP_Error(
							'invalid_manual_selection',
							__( 'One or more selected Custom Content Types definitions are invalid.', 'admin-site-enhancements' )
						);
					}
				}

				foreach ( $posts as $post ) {
					$record = $this->export_definition( $entity_type, $post );
					if ( '' === $record['identity'] ) {
						return new WP_Error(
							'missing_export_identity',
							__( 'A Custom Content Types definition is missing its stable identity and cannot be exported.', 'admin-site-enhancements' )
						);
					}
					if ( isset( $identities[ $entity_type ][ $record['identity'] ] ) ) {
						return new WP_Error(
							'duplicate_export_identity',
							__( 'The local Custom Content Types definitions contain duplicate stable identities.', 'admin-site-enhancements' )
						);
					}

					$identities[ $entity_type ][ $record['identity'] ] = true;
					$payload[ $entity_type ][]                         = $record;
					$exported_count++;
				}
			}

			if ( 0 === $exported_count ) {
				return new WP_Error(
					'empty_export',
					__( 'Select at least one Custom Content Types definition to export.', 'admin-site-enhancements' )
				);
			}

			return $payload;
		}

		/**
		 * Read and decode an uploaded JSON definition file.
		 *
		 * @param array $file Uploaded file array.
		 * @return array|WP_Error
		 */
		public function read_import_file( $file ) {
			if ( ! is_array( $file ) ) {
				return new WP_Error(
					'missing_import_file',
					__( 'Please upload a Custom Content Types JSON file.', 'admin-site-enhancements' )
				);
			}

			$error_code = isset( $file['error'] ) && is_scalar( $file['error'] ) ? (int) $file['error'] : UPLOAD_ERR_NO_FILE;
			if ( UPLOAD_ERR_OK !== $error_code ) {
				return new WP_Error(
					'import_upload_error',
					__( 'The Custom Content Types file upload failed. Please try again.', 'admin-site-enhancements' )
				);
			}

			$file_name = isset( $file['name'] ) && is_scalar( $file['name'] ) ? sanitize_file_name( $file['name'] ) : '';
			$file_size = isset( $file['size'] ) && is_scalar( $file['size'] ) ? (int) $file['size'] : 0;
			$tmp_name  = isset( $file['tmp_name'] ) && is_scalar( $file['tmp_name'] ) ? (string) $file['tmp_name'] : '';

			if ( 'json' !== strtolower( pathinfo( $file_name, PATHINFO_EXTENSION ) ) ) {
				return new WP_Error(
					'invalid_import_extension',
					__( 'Only JSON files can be imported.', 'admin-site-enhancements' )
				);
			}

			if ( $file_size <= 0 || $file_size > wp_max_upload_size() ) {
				return new WP_Error(
					'invalid_import_size',
					__( 'The uploaded Custom Content Types file is empty or too large.', 'admin-site-enhancements' )
				);
			}

			if ( empty( $tmp_name ) || ! is_uploaded_file( $tmp_name ) ) {
				return new WP_Error(
					'invalid_import_upload',
					__( 'The uploaded Custom Content Types file could not be verified.', 'admin-site-enhancements' )
				);
			}

			$file_contents = file_get_contents( $tmp_name ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			if ( false === $file_contents || '' === trim( $file_contents ) ) {
				return new WP_Error(
					'empty_import_file',
					__( 'The uploaded Custom Content Types file is empty.', 'admin-site-enhancements' )
				);
			}

			$payload = json_decode( $file_contents, true );
			if ( ! is_array( $payload ) || JSON_ERROR_NONE !== json_last_error() ) {
				return new WP_Error(
					'invalid_import_json',
					__( 'The uploaded Custom Content Types file contains invalid JSON.', 'admin-site-enhancements' )
				);
			}

			return $payload;
		}

		/**
		 * Import a combined definition payload.
		 *
		 * @param array $payload Raw decoded payload.
		 * @return array|WP_Error
		 */
		public function import_payload( $payload ) {
			$payload = $this->prepare_import_payload( $payload );
			if ( is_wp_error( $payload ) ) {
				return $payload;
			}

			$result = array(
				'imported' => array(),
				'updated'  => array(),
				'warnings' => array(),
			);
			$maps  = array();

			foreach ( array( 'custom_post_types', 'custom_taxonomies', 'options_pages' ) as $entity_type ) {
				$maps[ $entity_type ] = array(
					'by_source_id' => array(),
					'by_identity'  => array(),
				);

				foreach ( $payload[ $entity_type ] as $record ) {
					$imported = $this->import_definition( $entity_type, $record );
					if ( is_wp_error( $imported ) ) {
						return $imported;
					}

					$maps[ $entity_type ]['by_source_id'][ $record['post_id'] ] = $imported['post_id'];
					$maps[ $entity_type ]['by_identity'][ $record['identity'] ]  = $imported['post_id'];
					$this->add_import_result( $result, $imported );
				}
			}

			$option_page_runtime_map = ! empty( $payload['custom_field_groups'] ) ? $this->get_runtime_options_page_map() : array();
			$next_field_id           = ! empty( $payload['custom_field_groups'] ) ? $this->get_next_field_id() : 1;
			$maps['custom_field_groups'] = array(
				'by_source_id' => array(),
				'by_identity'  => array(),
			);

			foreach ( $payload['custom_field_groups'] as $record ) {
				$imported = $this->import_field_group( $record, $option_page_runtime_map, $next_field_id );
				if ( is_wp_error( $imported ) ) {
					return $imported;
				}

				$maps['custom_field_groups']['by_source_id'][ $record['post_id'] ] = $imported['post_id'];
				$maps['custom_field_groups']['by_identity'][ $record['identity'] ]  = $imported['post_id'];
				$this->add_import_result( $result, $imported );
				if ( ! empty( $imported['warnings'] ) ) {
					$result['warnings'] = array_merge( $result['warnings'], $imported['warnings'] );
				}
			}

			if ( ! empty( $payload['custom_field_groups'] ) ) {
				$this->update_next_field_id( $next_field_id );
			}
			$this->collect_dependency_warnings( $payload, $maps, $option_page_runtime_map, $result['warnings'] );

			if ( ! empty( $payload['custom_post_types'] ) || ! empty( $payload['custom_taxonomies'] ) || ! empty( $payload['options_pages'] ) ) {
				$options = get_option( ASENHA_SLUG_U, array() );
				$options = is_array( $options ) ? $options : array();
				$options['custom_content_types_flush_rewrite_rules_needed'] = true;
				update_option( ASENHA_SLUG_U, $options, true );
			}

			return $result;
		}

		/**
		 * Add the Export / Import shortcut to CCT definition list pages.
		 *
		 * @return void
		 */
		public function add_list_page_export_import_button__premium_only() {
			global $pagenow, $typenow;

			$labels = array(
				'asenha_cpt'         => __( 'Custom Post Types', 'admin-site-enhancements' ),
				'asenha_ctax'        => __( 'Custom Taxonomies', 'admin-site-enhancements' ),
				'asenha_cfgroup'     => __( 'Custom Field Groups', 'admin-site-enhancements' ),
				'options_page_config' => __( 'Options Pages', 'admin-site-enhancements' ),
			);

			if ( 'edit.php' !== $pagenow || ! isset( $labels[ $typenow ] ) || ! current_user_can( 'manage_options' ) ) {
				return;
			}

			$export_import_url = add_query_arg(
				array(
					'page'                     => ASENHA_SLUG,
					'asenha_open_export_import' => '1',
					'asenha_scroll_to'         => 'custom_content_types',
				),
				admin_url( 'tools.php' )
			);
			$export_import_url .= '#content-management';
			$button_label = __( 'Export / Import', 'admin-site-enhancements' );
			$aria_label   = sprintf(
				/* translators: %s is the current CCT definition type. */
				__( 'Export or import %s', 'admin-site-enhancements' ),
				$labels[ $typenow ]
			);
			?>
			<script type="text/javascript">
			jQuery(function($) {
				if ( $('.asenha-cct-export-import-shortcut').length ) {
					return;
				}

				var $addNewButton = $('.wrap .page-title-action').first();
				if ( ! $addNewButton.length ) {
					return;
				}

				var $button = $('<a />', {
					href: <?php echo wp_json_encode( $export_import_url ); ?>,
					class: 'page-title-action asenha-cct-export-import-shortcut',
					text: <?php echo wp_json_encode( $button_label ); ?>,
					'aria-label': <?php echo wp_json_encode( $aria_label ); ?>
				});

				$addNewButton.after( $button );
			});
			</script>
			<?php
		}

		/**
		 * Prepare and sanitize a raw import payload.
		 *
		 * @param mixed $payload Raw payload.
		 * @return array|WP_Error
		 */
		private function prepare_import_payload( $payload ) {
			if ( ! is_array( $payload ) ) {
				return new WP_Error(
					'invalid_import_payload',
					__( 'The Custom Content Types import payload is invalid.', 'admin-site-enhancements' )
				);
			}

			$payload_format = isset( $payload['format'] ) && is_scalar( $payload['format'] ) ? sanitize_key( $payload['format'] ) : '';
			$payload_version = isset( $payload['version'] ) && is_scalar( $payload['version'] ) ? absint( $payload['version'] ) : 0;

			if ( self::PAYLOAD_FORMAT !== $payload_format ) {
				return new WP_Error(
					'invalid_import_format',
					__( 'The uploaded file is not a Custom Content Types definition export.', 'admin-site-enhancements' )
				);
			}

			if ( self::PAYLOAD_VERSION !== $payload_version ) {
				return new WP_Error(
					'unsupported_import_version',
					__( 'This Custom Content Types definition export version is not supported.', 'admin-site-enhancements' )
				);
			}

			$prepared       = array(
				'format'              => self::PAYLOAD_FORMAT,
				'version'             => self::PAYLOAD_VERSION,
				'custom_post_types'   => array(),
				'custom_taxonomies'   => array(),
				'custom_field_groups' => array(),
				'options_pages'       => array(),
			);
			$record_count  = 0;
			$identities    = array();

			foreach ( $this->get_entity_types() as $entity_type ) {
				if ( ! isset( $payload[ $entity_type ] ) ) {
					continue;
				}

				if ( ! is_array( $payload[ $entity_type ] ) ) {
					return new WP_Error(
						'invalid_import_entity',
						__( 'One or more Custom Content Types definition collections are invalid.', 'admin-site-enhancements' )
					);
				}

				$identities[ $entity_type ] = array();
				foreach ( $payload[ $entity_type ] as $record ) {
					$record = $this->sanitize_import_record( $entity_type, $record );
					if ( is_wp_error( $record ) ) {
						return $record;
					}

					if ( isset( $identities[ $entity_type ][ $record['identity'] ] ) ) {
						return new WP_Error(
							'duplicate_import_identity',
							__( 'The import file contains duplicate Custom Content Types definitions.', 'admin-site-enhancements' )
						);
					}

					$identities[ $entity_type ][ $record['identity'] ] = true;
					$prepared[ $entity_type ][]                        = $record;
					$record_count++;
				}
			}

			if ( 0 === $record_count ) {
				return new WP_Error(
					'empty_import_payload',
					__( 'The import file does not contain any Custom Content Types definitions.', 'admin-site-enhancements' )
				);
			}

			return $prepared;
		}

		/**
		 * Sanitize one imported definition record.
		 *
		 * @param string $entity_type Entity type.
		 * @param mixed  $record      Raw record.
		 * @return array|WP_Error
		 */
		private function sanitize_import_record( $entity_type, $record ) {
			if ( ! is_array( $record ) ) {
				return new WP_Error(
					'invalid_import_record',
					__( 'A Custom Content Types definition record is invalid.', 'admin-site-enhancements' )
				);
			}

			$config = $this->get_entity_config( $entity_type );
			foreach ( array( 'post_id', 'source_id', 'post_title', 'post_name', 'post_status', 'identity' ) as $scalar_key ) {
				if ( isset( $record[ $scalar_key ] ) && ! is_scalar( $record[ $scalar_key ] ) ) {
					return new WP_Error(
						'invalid_import_record_value',
						__( 'A Custom Content Types definition contains an invalid scalar value.', 'admin-site-enhancements' )
					);
				}
			}

			if ( isset( $record['meta'] ) && ! is_array( $record['meta'] ) ) {
				return new WP_Error(
					'invalid_import_meta',
					__( 'A Custom Content Types definition contains invalid metadata.', 'admin-site-enhancements' )
				);
			}

			$post_id = isset( $record['post_id'] ) ? absint( $record['post_id'] ) : ( isset( $record['source_id'] ) ? absint( $record['source_id'] ) : 0 );
			if ( $post_id <= 0 ) {
				return new WP_Error(
					'invalid_import_record_id',
					__( 'A Custom Content Types definition is missing its source ID.', 'admin-site-enhancements' )
				);
			}

			$post_status = isset( $record['post_status'] ) ? sanitize_key( $record['post_status'] ) : 'publish';
			if ( ! in_array( $post_status, array( 'publish', 'draft' ), true ) ) {
				return new WP_Error(
					'invalid_import_status',
					__( 'A Custom Content Types definition has an unsupported status.', 'admin-site-enhancements' )
				);
			}

			$meta = isset( $record['meta'] ) && is_array( $record['meta'] ) ? $record['meta'] : array();
			if ( 'custom_field_groups' === $entity_type ) {
				$meta = $this->sanitize_field_group_meta( $meta );
			} else {
				$meta = $this->sanitize_definition_meta( $entity_type, $meta );
			}

			if ( is_wp_error( $meta ) ) {
				return $meta;
			}

			$identity = '';
			if ( ! empty( $config['stable_meta'] ) && isset( $meta[ $config['stable_meta'] ] ) ) {
				$identity = $this->sanitize_slug_value( $meta[ $config['stable_meta'] ] );
				$meta[ $config['stable_meta'] ] = $identity;
			} elseif ( 'custom_field_groups' === $entity_type ) {
				$identity = sanitize_title( isset( $record['post_name'] ) ? $record['post_name'] : '' );
			}

			if ( '' === $identity && ! empty( $record['identity'] ) ) {
				$identity = 'custom_field_groups' === $entity_type
					? sanitize_title( $record['identity'] )
					: $this->sanitize_slug_value( $record['identity'] );
				if ( ! empty( $config['stable_meta'] ) ) {
					$meta[ $config['stable_meta'] ] = $identity;
				}
			}

			if ( '' === $identity ) {
				return new WP_Error(
					'missing_import_identity',
					__( 'A Custom Content Types definition is missing its stable identity.', 'admin-site-enhancements' )
				);
			}

			$post_name = sanitize_title( isset( $record['post_name'] ) ? $record['post_name'] : $identity );
			if ( 'custom_field_groups' === $entity_type && '' === $post_name ) {
				$post_name = $identity;
			}

			return array(
				'post_id'     => $post_id,
				'post_title'  => sanitize_text_field( isset( $record['post_title'] ) ? $record['post_title'] : '' ),
				'post_name'   => $post_name,
				'post_status' => $post_status,
				'identity'    => $identity,
				'meta'        => $meta,
			);
		}

		/**
		 * Sanitize CCT/options definition metadata.
		 *
		 * @param string $entity_type Entity type.
		 * @param array  $meta        Raw metadata.
		 * @return array
		 */
		private function sanitize_definition_meta( $entity_type, $meta ) {
			$clean = array();

			foreach ( $meta as $key => $value ) {
				$key = sanitize_key( $key );
				if ( ! $this->is_allowed_meta_key( $entity_type, $key ) ) {
					continue;
				}

				$clean[ $key ] = $this->sanitize_definition_meta_value( $key, $value );
			}

			return $clean;
		}

		/**
		 * Sanitize one CCT/options metadata value.
		 *
		 * @param string $key   Meta key.
		 * @param mixed  $value Meta value.
		 * @return mixed
		 */
		private function sanitize_definition_meta_value( $key, $value ) {
			if ( false !== strpos( $key, '_menu_icon' ) ) {
				return $this->sanitize_menu_icon( $value );
			}

			if ( false !== strpos( $key, '_description' ) ) {
				return sanitize_textarea_field( (string) $value );
			}

			if ( in_array(
				$key,
				array(
					'cpt_key',
					'cpt_capability_type_custom_slug_singular',
					'cpt_capability_type_custom_slug_plural',
					'cpt_query_var_string',
					'cpt_has_archive_custom_slug',
					'cpt_rest_base',
					'ctax_key',
					'ctax_query_var_string',
					'ctax_rest_base',
					'options_page_menu_slug',
				),
				true
			) ) {
				return $this->sanitize_slug_value( $value );
			}

			if ( 'cpt_supports' === $key || 'cpt_taxonomies' === $key || 'ctax_post_types' === $key ) {
				return $this->sanitize_slug_list( $value );
			}

			if ( false !== strpos( $key, '_ep_mask_custom' ) ) {
				return $this->sanitize_endpoint_mask_constant( $value );
			}

			if ( false !== strpos( $key, '_rewrite_custom_slug' ) ) {
				return $this->sanitize_rewrite_slug_path( $value );
			}

			if ( is_array( $value ) ) {
				return $this->sanitize_scalar_array( $value );
			}

			if ( is_bool( $value ) || is_int( $value ) || is_float( $value ) ) {
				return $value;
			}

			return sanitize_text_field( (string) $value );
		}

		/**
		 * Sanitize field-group definition metadata.
		 *
		 * @param array $meta Raw metadata.
		 * @return array|WP_Error
		 */
		private function sanitize_field_group_meta( $meta ) {
			$clean = array(
				'cfgroup_fields' => array(),
				'cfgroup_rules'  => array(),
				'cfgroup_extras' => array(),
			);

			if ( isset( $meta['cfgroup_fields'] ) ) {
				$clean['cfgroup_fields'] = $this->sanitize_field_rows( $meta['cfgroup_fields'] );
				if ( is_wp_error( $clean['cfgroup_fields'] ) ) {
					return $clean['cfgroup_fields'];
				}
			}

			if ( isset( $meta['cfgroup_rules'] ) ) {
				$clean['cfgroup_rules'] = $this->sanitize_field_group_rules( $meta['cfgroup_rules'] );
			}

			if ( isset( $meta['cfgroup_extras'] ) ) {
				$clean['cfgroup_extras'] = $this->sanitize_cfg_value( $meta['cfgroup_extras'] );
			}

			return $clean;
		}

		/**
		 * Sanitize field rows.
		 *
		 * @param mixed $fields Raw fields.
		 * @return array|WP_Error
		 */
		private function sanitize_field_rows( $fields ) {
			if ( ! is_array( $fields ) ) {
				return new WP_Error(
					'invalid_import_fields',
					__( 'A custom field group contains invalid field definitions.', 'admin-site-enhancements' )
				);
			}

			$clean       = array();
			$source_ids  = array();
			$field_names = array();
			$field_types = $this->get_available_field_types();
			if ( empty( $field_types ) ) {
				return new WP_Error(
					'missing_import_field_types',
					__( 'Custom field group field types are not available for import.', 'admin-site-enhancements' )
				);
			}

			foreach ( $fields as $field ) {
				if ( ! is_array( $field ) ) {
					return new WP_Error(
						'invalid_import_field',
						__( 'A custom field group contains an invalid field.', 'admin-site-enhancements' )
					);
				}

				$type = sanitize_key( isset( $field['type'] ) ? $field['type'] : '' );
				if ( '' === $type || ! isset( $field_types[ $type ] ) ) {
					return new WP_Error(
						'unsupported_import_field_type',
						__( 'A custom field group contains an unsupported field type.', 'admin-site-enhancements' )
					);
				}

				$id = absint( isset( $field['id'] ) ? $field['id'] : 0 );
				if ( $id > 0 ) {
					if ( isset( $source_ids[ $id ] ) ) {
						return new WP_Error(
							'duplicate_import_field_id',
							__( 'A custom field group contains duplicate field IDs.', 'admin-site-enhancements' )
						);
					}
					$source_ids[ $id ] = true;
				}

				$name = sanitize_key( isset( $field['name'] ) ? $field['name'] : '' );
				if ( '' === $name ) {
					return new WP_Error(
						'missing_import_field_name',
						__( 'A custom field group contains a field without a name.', 'admin-site-enhancements' )
					);
				}
				if ( isset( $field_names[ $name ] ) ) {
					return new WP_Error(
						'duplicate_import_field_name',
						__( 'A custom field group contains duplicate field names.', 'admin-site-enhancements' )
					);
				}
				$field_names[ $name ] = true;

				$clean[] = array(
					'id'                => $id,
					'name'              => $name,
					'label'             => sanitize_text_field( isset( $field['label'] ) ? $field['label'] : '' ),
					'type'              => $type,
					'notes'             => wp_kses_post( isset( $field['notes'] ) ? $field['notes'] : '' ),
					'parent_id'         => absint( isset( $field['parent_id'] ) ? $field['parent_id'] : 0 ),
					'weight'            => absint( isset( $field['weight'] ) ? $field['weight'] : 0 ),
					'options'           => $this->sanitize_cfg_value( isset( $field['options'] ) ? $field['options'] : array() ),
					'column_width'      => $this->sanitize_column_width( isset( $field['column_width'] ) ? $field['column_width'] : 'full' ),
					'option_pages'      => $this->sanitize_option_page_map( isset( $field['option_pages'] ) ? $field['option_pages'] : array() ),
					'conditional_logic' => $this->sanitize_conditional_logic( isset( $field['conditional_logic'] ) ? $field['conditional_logic'] : array() ),
				);
			}

			foreach ( $clean as $field ) {
				$parent_id = isset( $field['parent_id'] ) ? absint( $field['parent_id'] ) : 0;
				if ( $parent_id > 0 && ! isset( $source_ids[ $parent_id ] ) ) {
					return new WP_Error(
						'invalid_import_parent_field',
						__( 'A custom field group contains a field with an invalid parent reference.', 'admin-site-enhancements' )
					);
				}

				if ( empty( $field['conditional_logic']['groups'] ) ) {
					continue;
				}
				foreach ( $field['conditional_logic']['groups'] as $rules ) {
					if ( ! is_array( $rules ) ) {
						continue;
					}
					foreach ( $rules as $rule ) {
						$dependency_id = isset( $rule['field_id'] ) ? absint( $rule['field_id'] ) : 0;
						if ( $dependency_id > 0 && ! isset( $source_ids[ $dependency_id ] ) ) {
							return new WP_Error(
								'invalid_import_conditional_field',
								__( 'A custom field group contains a conditional-logic reference to an unknown field.', 'admin-site-enhancements' )
							);
						}
					}
				}
			}

			return $clean;
		}

		/**
		 * Sanitize CFG placement rules.
		 *
		 * @param mixed $rules Raw rules.
		 * @return array
		 */
		private function sanitize_field_group_rules( $rules ) {
			if ( ! is_array( $rules ) ) {
				return array();
			}

			$clean       = array();
			$rule_types  = array( 'placement', 'post_types', 'post_formats', 'user_roles', 'post_ids', 'term_ids', 'page_templates', 'options_pages', 'taxonomies' );

			foreach ( $rule_types as $rule_type ) {
				if ( empty( $rules[ $rule_type ] ) || ! is_array( $rules[ $rule_type ] ) ) {
					continue;
				}

				$operator = isset( $rules[ $rule_type ]['operator'] ) ? trim( (string) $rules[ $rule_type ]['operator'] ) : '==';
				$operator = in_array( $operator, array( '==', '!=' ), true ) ? $operator : '==';
				$values   = isset( $rules[ $rule_type ]['values'] ) ? $rules[ $rule_type ]['values'] : array();

				if ( 'placement' === $rule_type ) {
					$values = sanitize_key( $values );
				} elseif ( 'post_ids' === $rule_type || 'term_ids' === $rule_type ) {
					$values = $this->sanitize_id_list_value( $values );
				} elseif ( in_array( $rule_type, array( 'post_types', 'post_formats', 'user_roles', 'options_pages', 'taxonomies' ), true ) ) {
					$values = $this->sanitize_slug_list( $values );
				} else {
					$values = $this->sanitize_scalar_array( $values );
				}

				$clean[ $rule_type ] = array(
					'operator' => $operator,
					'values'   => $values,
				);
			}

			return $clean;
		}

		/**
		 * Sanitize conditional logic structure before field IDs are remapped.
		 *
		 * @param mixed $conditional_logic Raw conditional logic.
		 * @return array
		 */
		private function sanitize_conditional_logic( $conditional_logic ) {
			$clean = array(
				'enabled' => 0,
				'groups'  => array(),
			);

			if ( ! is_array( $conditional_logic ) ) {
				return $clean;
			}

			$clean['enabled'] = ! empty( $conditional_logic['enabled'] ) ? 1 : 0;
			if ( empty( $conditional_logic['groups'] ) || ! is_array( $conditional_logic['groups'] ) ) {
				$clean['enabled'] = 0;
				return $clean;
			}

			$or_index = 0;
			foreach ( $conditional_logic['groups'] as $and_rules ) {
				if ( $or_index >= 20 || ! is_array( $and_rules ) ) {
					break;
				}

				$clean_and = array();
				$and_index = 0;
				foreach ( $and_rules as $rule ) {
					if ( $and_index >= 20 || ! is_array( $rule ) ) {
						break;
					}

					$operator = isset( $rule['operator'] ) ? (string) $rule['operator'] : '==';
					$operator = preg_replace( '/[^a-zA-Z0-9_!<>= ]/', '', $operator );
					$clean_and[] = array(
						'field_id' => absint( isset( $rule['field_id'] ) ? $rule['field_id'] : 0 ),
						'operator' => $operator,
						'value'    => $this->sanitize_cfg_value( isset( $rule['value'] ) ? $rule['value'] : '' ),
					);
					$and_index++;
				}

				if ( ! empty( $clean_and ) ) {
					$clean['groups'][] = $clean_and;
					$or_index++;
				}
			}

			if ( empty( $clean['groups'] ) ) {
				$clean['enabled'] = 0;
			}

			return $clean;
		}

		/**
		 * Remap conditional logic when the CFG conditional-logic class is not loaded.
		 *
		 * @param array $conditional_logic Conditional logic.
		 * @param array $field_id_map      Source ID => local ID map.
		 * @return array
		 */
		private function remap_conditional_logic_fallback( $conditional_logic, $field_id_map ) {
			if ( ! is_array( $conditional_logic ) || empty( $conditional_logic['groups'] ) || ! is_array( $conditional_logic['groups'] ) ) {
				return is_array( $conditional_logic ) ? $conditional_logic : array();
			}

			foreach ( $conditional_logic['groups'] as $group_index => $rules ) {
				if ( ! is_array( $rules ) ) {
					continue;
				}
				foreach ( $rules as $rule_index => $rule ) {
					$source_id = isset( $rule['field_id'] ) ? absint( $rule['field_id'] ) : 0;
					if ( $source_id > 0 && isset( $field_id_map[ $source_id ] ) ) {
						$conditional_logic['groups'][ $group_index ][ $rule_index ]['field_id'] = $field_id_map[ $source_id ];
					}
				}
			}

			return $conditional_logic;
		}

		/**
		 * Import a normal CCT/options definition.
		 *
		 * @param string $entity_type Entity type.
		 * @param array  $record      Prepared record.
		 * @return array|WP_Error
		 */
		private function import_definition( $entity_type, $record ) {
			$config  = $this->get_entity_config( $entity_type );
			$existing = $this->find_existing_definition( $entity_type, $record['identity'], $record['post_id'] );
			$post_data = array(
				'post_title'  => '' !== $record['post_title'] ? $record['post_title'] : $record['identity'],
				'post_name'   => $record['post_name'],
				'post_status' => $record['post_status'],
				'post_type'   => $config['post_type'],
			);

			if ( $existing instanceof WP_Post ) {
				$post_data['ID'] = (int) $existing->ID;
				$post_id        = wp_update_post( $post_data, true );
				$was_updated    = true;
			} else {
				if ( ! get_post( $record['post_id'] ) ) {
					$post_data['import_id'] = $record['post_id'];
				}
				$post_id     = wp_insert_post( $post_data, true );
				$was_updated = false;
			}

			if ( is_wp_error( $post_id ) || ! $post_id ) {
				return new WP_Error(
					'import_definition_failed',
					sprintf(
						/* translators: %s is an entity type label. */
						__( 'Could not import the %s definition.', 'admin-site-enhancements' ),
						$this->get_entity_label( $entity_type )
					)
				);
			}

			$this->replace_managed_meta( $entity_type, $post_id, $record['meta'] );
			$this->register_wpml_definition( $post_id );

			return array(
				'post_id'    => (int) $post_id,
				'identity'   => $record['identity'],
				'title'      => $post_data['post_title'],
				'was_updated' => $was_updated,
			);
		}

		/**
		 * Import a field group and remap local field IDs.
		 *
		 * @param array $record                  Prepared record.
		 * @param array $option_page_runtime_map  Local options-page map.
		 * @param int   $next_field_id            Next global field ID, by reference.
		 * @return array|WP_Error
		 */
		private function import_field_group( $record, $option_page_runtime_map, &$next_field_id ) {
			$entity_type = 'custom_field_groups';
			$existing    = $this->find_existing_definition( $entity_type, $record['identity'], $record['post_id'] );
			$old_fields  = $existing instanceof WP_Post ? get_post_meta( $existing->ID, 'cfgroup_fields', true ) : array();
			$old_fields  = is_array( $old_fields ) ? $old_fields : array();

			$existing_field_ids_by_name = array();
			foreach ( $old_fields as $old_field ) {
				$name = isset( $old_field['name'] ) ? sanitize_key( $old_field['name'] ) : '';
				$id   = isset( $old_field['id'] ) ? absint( $old_field['id'] ) : 0;
				if ( '' !== $name && $id > 0 && ! isset( $existing_field_ids_by_name[ $name ] ) ) {
					$existing_field_ids_by_name[ $name ] = array(
						'id'   => $id,
						'type' => isset( $old_field['type'] ) ? sanitize_key( $old_field['type'] ) : '',
					);
				}
			}

			$source_fields = isset( $record['meta']['cfgroup_fields'] ) ? $record['meta']['cfgroup_fields'] : array();
			$field_id_map  = array();
			$used_ids      = array();
			$prepared_rows = array();

			foreach ( $source_fields as $field ) {
				$source_id = isset( $field['id'] ) ? absint( $field['id'] ) : 0;
				$name      = isset( $field['name'] ) ? sanitize_key( $field['name'] ) : '';
				$local_id  = 0;
				if ( isset( $existing_field_ids_by_name[ $name ] )
					&& isset( $field['type'] )
					&& $existing_field_ids_by_name[ $name ]['type'] === sanitize_key( $field['type'] )
				) {
					$local_id = $existing_field_ids_by_name[ $name ]['id'];
				}

				if ( $local_id <= 0 || isset( $used_ids[ $local_id ] ) ) {
					$local_id = $this->allocate_field_id( $next_field_id, $used_ids );
				}

				if ( $source_id > 0 ) {
					$field_id_map[ $source_id ] = $local_id;
				}
				$used_ids[ $local_id ] = true;
				$prepared_rows[]       = array(
					'source'   => $field,
					'local_id' => $local_id,
				);
			}

			$siblings_by_id = array();
			foreach ( $prepared_rows as $prepared_row ) {
				$field       = $prepared_row['source'];
				$local_id    = $prepared_row['local_id'];
				$source_parent = isset( $field['parent_id'] ) ? absint( $field['parent_id'] ) : 0;
				$local_parent  = isset( $field_id_map[ $source_parent ] ) ? $field_id_map[ $source_parent ] : 0;
				$siblings_by_id[ $local_id ] = array(
					'id'        => $local_id,
					'type'      => isset( $field['type'] ) ? $field['type'] : '',
					'parent_id' => $local_parent,
				);
			}

			$new_fields = array();
			$rules      = isset( $record['meta']['cfgroup_rules'] ) && is_array( $record['meta']['cfgroup_rules'] ) ? $record['meta']['cfgroup_rules'] : array();
			foreach ( $prepared_rows as $prepared_row ) {
				$field          = $prepared_row['source'];
				$local_id       = $prepared_row['local_id'];
				$source_parent  = isset( $field['parent_id'] ) ? absint( $field['parent_id'] ) : 0;
				$local_parent   = isset( $field_id_map[ $source_parent ] ) ? $field_id_map[ $source_parent ] : 0;
				$conditional    = isset( $field['conditional_logic'] ) ? $field['conditional_logic'] : array();
				$option_pages   = $this->remap_option_page_map(
					isset( $field['option_pages'] ) ? $field['option_pages'] : array(),
					$option_page_runtime_map,
					$rules
				);

				if ( class_exists( 'cfgroup_conditional_logic' ) ) {
					$conditional = cfgroup_conditional_logic::remap_import_field_ids( $conditional, $field_id_map );
					$conditional = cfgroup_conditional_logic::sanitize_from_post( $conditional, $local_id, $local_parent, $siblings_by_id );
				} else {
					$conditional = $this->remap_conditional_logic_fallback( $conditional, $field_id_map );
				}

				$new_fields[] = array(
					'id'                => $local_id,
					'name'              => isset( $field['name'] ) ? sanitize_key( $field['name'] ) : '',
					'label'             => isset( $field['label'] ) ? sanitize_text_field( $field['label'] ) : '',
					'type'              => isset( $field['type'] ) ? sanitize_key( $field['type'] ) : 'text',
					'notes'             => isset( $field['notes'] ) ? wp_kses_post( $field['notes'] ) : '',
					'parent_id'         => $local_parent,
					'weight'            => isset( $field['weight'] ) ? absint( $field['weight'] ) : count( $new_fields ),
					'options'           => isset( $field['options'] ) ? $field['options'] : array(),
					'column_width'      => $this->sanitize_column_width( isset( $field['column_width'] ) ? $field['column_width'] : 'full' ),
					'option_pages'      => $option_pages,
					'conditional_logic' => $conditional,
				);
			}

			$record['meta']['cfgroup_fields'] = $new_fields;
			$field_warnings = array();
			if ( $existing instanceof WP_Post ) {
				$old_names = array();
				$old_types = array();
				foreach ( $old_fields as $old_field ) {
					if ( ! empty( $old_field['name'] ) ) {
						$old_name               = sanitize_key( $old_field['name'] );
						$old_names[]            = $old_name;
						$old_types[ $old_name ] = isset( $old_field['type'] ) ? sanitize_key( $old_field['type'] ) : '';
					}
				}
				$new_names = array();
				$new_types = array();
				foreach ( $new_fields as $new_field ) {
					if ( ! empty( $new_field['name'] ) ) {
						$new_name               = sanitize_key( $new_field['name'] );
						$new_names[]            = $new_name;
						$new_types[ $new_name ] = isset( $new_field['type'] ) ? sanitize_key( $new_field['type'] ) : '';
					}
				}
				$type_changed = false;
				foreach ( $new_types as $field_name => $field_type ) {
					if ( isset( $old_types[ $field_name ] ) && $old_types[ $field_name ] !== $field_type ) {
						$type_changed = true;
						break;
					}
				}
				if ( array_diff( $old_names, $new_names ) || array_diff( $new_names, $old_names ) || $type_changed ) {
					$field_warnings[] = sprintf(
						/* translators: %s is a field group identity. */
						__( 'Existing values for removed, renamed, or type-changed fields in field group "%s" were not migrated.', 'admin-site-enhancements' ),
						$record['identity']
					);
				}
			}
			$existing = $existing instanceof WP_Post ? $existing : null;
			$post_data = array(
				'post_title'  => '' !== $record['post_title'] ? $record['post_title'] : $record['identity'],
				'post_name'   => $record['post_name'],
				'post_status' => $record['post_status'],
				'post_type'   => 'asenha_cfgroup',
			);

			if ( $existing ) {
				$post_data['ID'] = (int) $existing->ID;
				$post_id        = wp_update_post( $post_data, true );
				$was_updated    = true;
			} else {
				if ( ! get_post( $record['post_id'] ) ) {
					$post_data['import_id'] = $record['post_id'];
				}
				$post_id     = wp_insert_post( $post_data, true );
				$was_updated = false;
			}

			if ( is_wp_error( $post_id ) || ! $post_id ) {
				return new WP_Error(
					'import_field_group_failed',
					__( 'Could not import a custom field group definition.', 'admin-site-enhancements' )
				);
			}

			$this->replace_managed_meta( $entity_type, $post_id, $record['meta'] );
			$this->register_wpml_definition( $post_id );

			return array(
				'post_id'     => (int) $post_id,
				'identity'    => $record['identity'],
				'title'       => $post_data['post_title'],
				'was_updated' => $was_updated,
				'warnings'    => $field_warnings,
			);
		}

		/**
		 * Find an existing definition by stable identity, then source ID.
		 *
		 * @param string $entity_type Entity type.
		 * @param string $identity    Stable identity.
		 * @param int    $source_id   Source definition ID.
		 * @return WP_Post|null
		 */
		private function find_existing_definition( $entity_type, $identity, $source_id ) {
			$config = $this->get_entity_config( $entity_type );
			$posts  = array();

			if ( ! empty( $config['stable_meta'] ) ) {
				$posts = get_posts(
					array(
						'post_type'      => $config['post_type'],
						'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
						'numberposts'    => 1,
						'meta_key'       => $config['stable_meta'],
						'meta_value'     => $identity,
						'suppress_filters' => false,
					)
				);
			} else {
				foreach ( get_posts(
					array(
						'post_type'      => $config['post_type'],
						'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
						'numberposts'    => -1,
						'suppress_filters' => false,
					)
				) as $post ) {
					if ( $identity === $post->post_name ) {
						$posts[] = $post;
						break;
					}
				}
			}

			if ( ! empty( $posts ) && $posts[0] instanceof WP_Post ) {
				return $posts[0];
			}

			$source_post = $source_id > 0 ? get_post( $source_id ) : null;
			if ( $source_post instanceof WP_Post && $source_post->post_type === $config['post_type'] && 'trash' !== $source_post->post_status ) {
				return $source_post;
			}

			return null;
		}

		/**
		 * Replace only managed definition metadata.
		 *
		 * @param string $entity_type Entity type.
		 * @param int    $post_id     Local post ID.
		 * @param array  $meta        New metadata.
		 * @return void
		 */
		private function replace_managed_meta( $entity_type, $post_id, $meta ) {
			$existing_meta = get_post_meta( $post_id );
			foreach ( $existing_meta as $key => $values ) {
				if ( $this->is_allowed_meta_key( $entity_type, $key ) ) {
					delete_post_meta( $post_id, $key );
				}
			}

			foreach ( $meta as $key => $value ) {
				if ( $this->is_allowed_meta_key( $entity_type, $key ) ) {
					update_post_meta( $post_id, $key, $value );
				}
			}
		}

		/**
		 * Get current options-page runtime posts keyed by menu slug.
		 *
		 * @return array<string,int>
		 */
		private function get_runtime_options_page_map() {
			$map = array();
			$configs = get_posts(
				array(
					'post_type'      => 'options_page_config',
					'post_status'    => 'publish',
					'numberposts'    => -1,
					'suppress_filters' => false,
				)
			);

			foreach ( $configs as $config ) {
				$slug  = $this->sanitize_slug_value( get_post_meta( $config->ID, 'options_page_menu_slug', true ) );
				$title = sanitize_text_field( get_post_meta( $config->ID, 'options_page_title', true ) );
				if ( '' === $slug || '' === $title ) {
					continue;
				}

				$runtime_posts = get_posts(
					array(
						'post_type'      => 'asenha_options_page',
						'post_status'    => 'any',
						'title'          => $title,
						'numberposts'    => 1,
						'orderby'        => 'ID',
						'order'          => 'ASC',
						'suppress_filters' => false,
					)
				);

				if ( ! empty( $runtime_posts ) ) {
					$map[ $slug ] = (int) $runtime_posts[0]->ID;
					continue;
				}

				$runtime_id = wp_insert_post(
					array(
						'post_title'  => $title,
						'post_type'   => 'asenha_options_page',
						'post_status' => 'publish',
					),
					true
				);

				if ( ! is_wp_error( $runtime_id ) && $runtime_id ) {
					$map[ $slug ] = (int) $runtime_id;
				}
			}

			return $map;
		}

		/**
		 * Rebuild the derived field option-pages map using local runtime IDs.
		 *
		 * @param array $source_map Source runtime ID => menu slug map.
		 * @param array $runtime_map Local menu slug => runtime post ID.
		 * @param array $rules       Field group placement rules.
		 * @return array
		 */
		private function remap_option_page_map( $source_map, $runtime_map, $rules ) {
			$remapped = array();

			if ( is_array( $source_map ) ) {
				foreach ( $source_map as $source_slug ) {
					$slug = $this->sanitize_slug_value( $source_slug );
					if ( '' !== $slug && isset( $runtime_map[ $slug ] ) ) {
						$remapped[ $runtime_map[ $slug ] ] = $slug;
					}
				}
			}

			if ( empty( $remapped )
				&& isset( $rules['placement']['values'], $rules['options_pages']['values'] )
				&& 'options-pages' === $rules['placement']['values']
			) {
				$operator = isset( $rules['options_pages']['operator'] ) ? $rules['options_pages']['operator'] : '==';
				$values   = is_array( $rules['options_pages']['values'] ) ? $rules['options_pages']['values'] : array( $rules['options_pages']['values'] );
				$values   = array_map( array( $this, 'sanitize_slug_value' ), $values );

				foreach ( $runtime_map as $slug => $runtime_id ) {
					$matches = in_array( $slug, $values, true );
					if ( ( '==' === $operator && $matches ) || ( '!=' === $operator && ! $matches ) ) {
						$remapped[ $runtime_id ] = $slug;
					}
				}
			}

			return $remapped;
		}

		/**
		 * Get a safe next global CFG field ID.
		 *
		 * @return int
		 */
		private function get_next_field_id() {
			$options = get_option( ASENHA_SLUG_U . '_extra', array() );
			$next    = isset( $options['cfgroup_next_field_id'] ) ? absint( $options['cfgroup_next_field_id'] ) : 1;
			$max_id  = 0;

			foreach ( get_posts(
				array(
					'post_type'      => 'asenha_cfgroup',
					'post_status'    => 'any',
					'numberposts'    => -1,
					'fields'         => 'ids',
					'suppress_filters' => false,
				)
			) as $group_id ) {
				$fields = get_post_meta( $group_id, 'cfgroup_fields', true );
				if ( ! is_array( $fields ) ) {
					continue;
				}
				foreach ( $fields as $field ) {
					$max_id = max( $max_id, isset( $field['id'] ) ? absint( $field['id'] ) : 0 );
				}
			}

			return max( 1, $next, $max_id + 1 );
		}

		/**
		 * Allocate a field ID without colliding with IDs used in this import.
		 *
		 * @param int   $next_field_id Next ID, by reference.
		 * @param array $used_ids      Used IDs, by reference.
		 * @return int
		 */
		private function allocate_field_id( &$next_field_id, &$used_ids ) {
			while ( isset( $used_ids[ $next_field_id ] ) ) {
				$next_field_id++;
			}

			$local_id = $next_field_id;
			$next_field_id++;
			return $local_id;
		}

		/**
		 * Persist the next CFG field ID.
		 *
		 * @param int $next_field_id Next ID.
		 * @return void
		 */
		private function update_next_field_id( $next_field_id ) {
			$options = get_option( ASENHA_SLUG_U . '_extra', array() );
			$options = is_array( $options ) ? $options : array();
			$options['cfgroup_next_field_id'] = max( 1, absint( $next_field_id ) );
			update_option( ASENHA_SLUG_U . '_extra', $options, true );
		}

		/**
		 * Collect dependency and source-local reference warnings.
		 *
		 * @param array $payload          Prepared payload.
		 * @param array $maps             Import maps.
		 * @param array $runtime_map      Options-page runtime map.
		 * @param array $warnings         Warnings, by reference.
		 * @return void
		 */
		private function collect_dependency_warnings( $payload, $maps, $runtime_map, &$warnings ) {
			$known_post_types = get_post_types( array(), 'names' );
			$known_taxonomies = get_taxonomies( array(), 'names' );

			foreach ( $maps['custom_post_types']['by_identity'] as $identity => $post_id ) {
				$known_post_types[] = $identity;
			}
			foreach ( $maps['custom_taxonomies']['by_identity'] as $identity => $post_id ) {
				$known_taxonomies[] = $identity;
			}

			$known_post_types = array_unique( $known_post_types );
			$known_taxonomies = array_unique( $known_taxonomies );

			foreach ( $payload['custom_field_groups'] as $record ) {
				$rules = isset( $record['meta']['cfgroup_rules'] ) ? $record['meta']['cfgroup_rules'] : array();
				if ( ! empty( $rules['post_types']['values'] ) ) {
					$values = is_array( $rules['post_types']['values'] ) ? $rules['post_types']['values'] : array( $rules['post_types']['values'] );
					foreach ( $values as $post_type ) {
						if ( ! in_array( $post_type, $known_post_types, true ) ) {
							$warnings[] = sprintf(
								/* translators: 1: field group identity, 2: post type slug. */
								__( 'Field group "%1$s" references unavailable post type "%2$s".', 'admin-site-enhancements' ),
								$record['identity'],
								$post_type
							);
						}
					}
				}

				if ( ! empty( $rules['taxonomies']['values'] ) ) {
					$values = is_array( $rules['taxonomies']['values'] ) ? $rules['taxonomies']['values'] : array( $rules['taxonomies']['values'] );
					foreach ( $values as $taxonomy ) {
						if ( ! in_array( $taxonomy, $known_taxonomies, true ) ) {
							$warnings[] = sprintf(
								/* translators: 1: field group identity, 2: taxonomy slug. */
								__( 'Field group "%1$s" references unavailable taxonomy "%2$s".', 'admin-site-enhancements' ),
								$record['identity'],
								$taxonomy
							);
						}
					}
				}

				if ( ! empty( $rules['options_pages']['values'] ) ) {
					$values = is_array( $rules['options_pages']['values'] ) ? $rules['options_pages']['values'] : array( $rules['options_pages']['values'] );
					foreach ( $values as $options_page ) {
						if ( ! isset( $runtime_map[ $options_page ] ) ) {
							$warnings[] = sprintf(
								/* translators: 1: field group identity, 2: options page slug. */
								__( 'Field group "%1$s" references unavailable options page "%2$s".', 'admin-site-enhancements' ),
								$record['identity'],
								$options_page
							);
						}
					}
				}

				if ( ! empty( $rules['post_ids']['values'] ) || ! empty( $rules['term_ids']['values'] ) ) {
					$warnings[] = sprintf(
						/* translators: %s is a field group identity. */
						__( 'Field group "%s" contains post or term ID placement rules that were kept as source-local references.', 'admin-site-enhancements' ),
						$record['identity']
					);
				}
			}

			$warnings = array_values( array_unique( $warnings ) );
		}

		/**
		 * Add an import result entry.
		 *
		 * @param array $result   Result, by reference.
		 * @param array $imported Imported record result.
		 * @return void
		 */
		private function add_import_result( &$result, $imported ) {
			$key = ! empty( $imported['was_updated'] ) ? 'updated' : 'imported';
			$result[ $key ][] = $imported['title'];
		}

		/**
		 * Register WPML definition strings after direct metadata import.
		 *
		 * @param int $post_id Local definition post ID.
		 * @return void
		 */
		private function register_wpml_definition( $post_id ) {
			if ( ! defined( 'WPML_ST_VERSION' ) || ! class_exists( 'ASENHA_CCT_WPML' ) ) {
				return;
			}

			$post = get_post( $post_id );
			if ( ! $post instanceof WP_Post ) {
				return;
			}

			$bridge = ASENHA_CCT_WPML::get_instance();
			if ( is_object( $bridge ) && method_exists( $bridge, 'register_definition_strings_for_post_if_ready' ) ) {
				$bridge->register_definition_strings_for_post_if_ready( $post );
			}
		}

		/**
		 * Get posts by a validated ID list.
		 *
		 * @param string $entity_type Entity type.
		 * @param array  $ids         IDs.
		 * @return array
		 */
		private function get_posts_by_ids( $entity_type, $ids ) {
			$config = $this->get_entity_config( $entity_type );
			$posts  = get_posts(
				array(
					'post_type'      => $config['post_type'],
					'post_status'    => array( 'publish', 'draft' ),
					'post__in'       => $ids,
					'numberposts'    => -1,
					'orderby'        => 'post__in',
					'suppress_filters' => false,
				)
			);

			$posts_by_id = array();
			foreach ( $posts as $post ) {
				$posts_by_id[ $post->ID ] = $post;
			}

			$ordered = array();
			foreach ( $ids as $id ) {
				if ( isset( $posts_by_id[ $id ] ) ) {
					$ordered[] = $posts_by_id[ $id ];
				}
			}

			return $ordered;
		}

		/**
		 * Export one definition post.
		 *
		 * @param string  $entity_type Entity type.
		 * @param WP_Post $post        Definition post.
		 * @return array
		 */
		private function export_definition( $entity_type, $post ) {
			$meta = array();
			foreach ( get_post_meta( $post->ID ) as $key => $values ) {
				if ( $this->is_allowed_meta_key( $entity_type, $key ) ) {
					$meta[ $key ] = get_post_meta( $post->ID, $key, true );
				}
			}

			return array(
				'post_id'     => (int) $post->ID,
				'post_title'  => $post->post_title,
				'post_name'   => $post->post_name,
				'post_status' => $post->post_status,
				'identity'    => $this->get_post_identity( $entity_type, $post ),
				'meta'        => $meta,
			);
		}

		/**
		 * Get a post's stable identity.
		 *
		 * @param string  $entity_type Entity type.
		 * @param WP_Post $post        Definition post.
		 * @return string
		 */
		private function get_post_identity( $entity_type, $post ) {
			$config = $this->get_entity_config( $entity_type );
			if ( ! empty( $config['stable_meta'] ) ) {
				return (string) get_post_meta( $post->ID, $config['stable_meta'], true );
			}

			return (string) $post->post_name;
		}

		/**
		 * Determine whether a meta key belongs to an entity definition.
		 *
		 * @param string $entity_type Entity type.
		 * @param string $key         Meta key.
		 * @return bool
		 */
		private function is_allowed_meta_key( $entity_type, $key ) {
			$config = $this->get_entity_config( $entity_type );
			if ( false === $config ) {
				return false;
			}

			if ( ! empty( $config['meta_prefix'] ) ) {
				return 0 === strpos( $key, $config['meta_prefix'] );
			}

			return in_array( $key, $config['managed_meta'], true );
		}

		/**
		 * Get a translated entity label.
		 *
		 * @param string $entity_type Entity type.
		 * @return string
		 */
		private function get_entity_label( $entity_type ) {
			$labels = array(
				'custom_post_types'   => __( 'Custom Post Types', 'admin-site-enhancements' ),
				'custom_taxonomies'   => __( 'Custom Taxonomies', 'admin-site-enhancements' ),
				'custom_field_groups' => __( 'Custom Field Groups', 'admin-site-enhancements' ),
				'options_pages'       => __( 'Options Pages', 'admin-site-enhancements' ),
			);

			return isset( $labels[ $entity_type ] ) ? $labels[ $entity_type ] : __( 'definitions', 'admin-site-enhancements' );
		}

		/**
		 * Parse a comma/space-separated ID list.
		 *
		 * @param mixed $value Raw IDs.
		 * @return array
		 */
		private function parse_id_list( $value ) {
			if ( ! is_array( $value ) ) {
				$value = preg_split( '/[\s,]+/', (string) $value );
			}

			$ids = array();
			foreach ( $value as $id ) {
				$id = absint( $id );
				if ( $id > 0 ) {
					$ids[ $id ] = $id;
				}
			}

			return array_values( $ids );
		}

		/**
		 * Sanitize an array of IDs while preserving scalar input.
		 *
		 * @param mixed $value Raw IDs.
		 * @return array|int
		 */
		private function sanitize_id_list_value( $value ) {
			$ids = $this->parse_id_list( $value );
			return is_array( $value ) ? $ids : ( ! empty( $ids ) ? $ids[0] : 0 );
		}

		/**
		 * Sanitize a slug list.
		 *
		 * @param mixed $value Raw list.
		 * @return array|string
		 */
		private function sanitize_slug_list( $value ) {
			$is_array = is_array( $value );
			$values   = $is_array ? $value : array( $value );
			$clean    = array();

			foreach ( $values as $item ) {
				$item = $this->sanitize_slug_value( $item );
				if ( '' !== $item ) {
					$clean[] = $item;
				}
			}

			return $is_array ? array_values( array_unique( $clean ) ) : ( ! empty( $clean ) ? $clean[0] : '' );
		}

		/**
		 * Sanitize an option-page runtime map.
		 *
		 * @param mixed $value Source runtime ID => slug map.
		 * @return array
		 */
		private function sanitize_option_page_map( $value ) {
			if ( ! is_array( $value ) ) {
				return array();
			}

			$clean = array();
			foreach ( $value as $source_id => $slug ) {
				$source_id = absint( $source_id );
				$slug      = $this->sanitize_slug_value( $slug );
				if ( $source_id > 0 && '' !== $slug ) {
					$clean[ $source_id ] = $slug;
				}
			}

			return $clean;
		}

		/**
		 * Recursively sanitize scalar CFG values.
		 *
		 * @param mixed $value Raw value.
		 * @param int   $depth Recursion depth.
		 * @return mixed
		 */
		private function sanitize_cfg_value( $value, $depth = 0 ) {
			if ( $depth > 12 ) {
				return '';
			}

			if ( is_array( $value ) ) {
				$clean = array();
				foreach ( $value as $key => $item ) {
					$clean[ is_int( $key ) ? $key : sanitize_key( $key ) ] = $this->sanitize_cfg_value( $item, $depth + 1 );
				}
				return $clean;
			}

			if ( is_bool( $value ) || is_int( $value ) || is_float( $value ) || null === $value ) {
				return $value;
			}

			return wp_kses_post( (string) $value );
		}

		/**
		 * Sanitize an array of scalar values.
		 *
		 * @param mixed $value Raw value.
		 * @return array|string
		 */
		private function sanitize_scalar_array( $value ) {
			if ( ! is_array( $value ) ) {
				return sanitize_text_field( (string) $value );
			}

			$clean = array();
			foreach ( $value as $key => $item ) {
				if ( is_array( $item ) ) {
					$clean[ $key ] = $this->sanitize_scalar_array( $item );
				} elseif ( is_bool( $item ) || is_int( $item ) || is_float( $item ) ) {
					$clean[ $key ] = $item;
				} else {
					$clean[ $key ] = sanitize_text_field( (string) $item );
				}
			}

			return $clean;
		}

		/**
		 * Sanitize a slug value.
		 *
		 * @param mixed $value Raw slug.
		 * @return string
		 */
		private function sanitize_slug_value( $value ) {
			$value = strtolower( str_replace( ' ', '_', trim( (string) $value ) ) );
			return sanitize_title( $value );
		}

		/**
		 * Sanitize a CFG column-width slug.
		 *
		 * CFG stores widths as slugs, not numeric percentages. Keep the
		 * allowlist in sync with the existing CFG editor when it is loaded.
		 *
		 * @param mixed $value Raw column-width value.
		 * @return string
		 */
		private function sanitize_column_width( $value ) {
			$allowed_widths = array( 'full', 'three-quarters', 'two-thirds', 'half', 'third', 'quarter' );

			if ( function_exists( 'cfgroup_get_column_width_choices' ) ) {
				$choices = cfgroup_get_column_width_choices();
				if ( is_array( $choices ) && ! empty( $choices ) ) {
					$allowed_widths = array_keys( $choices );
				}
			}

			$value = is_scalar( $value ) ? sanitize_key( (string) $value ) : '';
			return in_array( $value, $allowed_widths, true ) ? $value : 'full';
		}

		/**
		 * Sanitize a rewrite path.
		 *
		 * @param mixed $value Raw path.
		 * @return string
		 */
		private function sanitize_rewrite_slug_path( $value ) {
			$value = trim( (string) $value );
			$value = preg_replace( '#[^a-zA-Z0-9/_-]#', '', $value );
			return trim( $value, '/' );
		}

		/**
		 * Sanitize an endpoint mask constant.
		 *
		 * @param mixed $value Raw constant name.
		 * @return string
		 */
		private function sanitize_endpoint_mask_constant( $value ) {
			$value = strtoupper( str_replace( array( ' ', '-' ), '_', trim( (string) $value ) ) );
			$value = preg_replace( '/[^A-Z0-9_]/', '', $value );
			return 0 === strpos( $value, 'EP_' ) ? $value : '';
		}

		/**
		 * Sanitize a menu icon value.
		 *
		 * @param mixed $value Raw icon.
		 * @return string
		 */
		private function sanitize_menu_icon( $value ) {
			$value = trim( (string) $value );
			if ( 0 === strpos( $value, 'data:image/svg+xml;base64,' ) ) {
				$encoded = substr( $value, strlen( 'data:image/svg+xml;base64,' ) );
				$decoded = base64_decode( $encoded, true );
				if ( false === $decoded ) {
					return '';
				}

				$rules = function_exists( 'get_kses_with_svg_ruleset' ) ? get_kses_with_svg_ruleset() : wp_kses_allowed_html( 'post' );
				$decoded = wp_kses( $decoded, $rules );
				return 'data:image/svg+xml;base64,' . base64_encode( $decoded );
			}

			if ( 0 === strpos( $value, 'dashicons-' ) ) {
				return sanitize_key( $value );
			}

			if ( false !== filter_var( $value, FILTER_VALIDATE_URL ) ) {
				return esc_url_raw( $value );
			}

			return '';
		}

		/**
		 * Get available CFG field types.
		 *
		 * @return array
		 */
		private function get_available_field_types() {
			if ( ! function_exists( 'CFG' ) ) {
				return array();
			}

			$cfg = CFG();
			return is_object( $cfg ) && isset( $cfg->fields ) && is_array( $cfg->fields ) ? $cfg->fields : array();
		}
	}
}
