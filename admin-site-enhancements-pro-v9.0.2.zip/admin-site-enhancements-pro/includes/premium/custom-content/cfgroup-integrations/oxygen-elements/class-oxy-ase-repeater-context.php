<?php
/**
 * Row context stack for ASE Repeater inside Oxygen Classic.
 *
 * Mirrors Meta Box's $meta_box_current_group_fields pattern: while an ASE
 * Repeater loops rows, nested ASE Dynamic Data / ASE Map read the current row.
 *
 * @since 8.9.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stack of active ASE Repeater row frames.
 *
 * @since 8.9.1
 */
class Oxy_Ase_Repeater_Context {

	/**
	 * Nested frames: repeater_name, row (assoc), index.
	 *
	 * @since 8.9.1
	 * @var array<int, array{repeater_name: string, row: array, index: int}>
	 */
	private static $stack = array();

	/**
	 * Push a row frame onto the stack.
	 *
	 * @since 8.9.1
	 * @param string $repeater_name Repeater field name.
	 * @param array  $row           Current row (sub_field_name => value).
	 * @param int    $index         Zero-based row index.
	 * @return void
	 */
	public static function push( $repeater_name, $row, $index ) {
		self::$stack[] = array(
			'repeater_name' => (string) $repeater_name,
			'row'           => is_array( $row ) ? $row : array(),
			'index'         => (int) $index,
		);
	}

	/**
	 * Pop the top frame.
	 *
	 * @since 8.9.1
	 * @return void
	 */
	public static function pop() {
		array_pop( self::$stack );
	}

	/**
	 * Whether any ASE Repeater loop is active.
	 *
	 * @since 8.9.1
	 * @return bool
	 */
	public static function is_active() {
		return ! empty( self::$stack );
	}

	/**
	 * Top frame, or null.
	 *
	 * @since 8.9.1
	 * @return array{repeater_name: string, row: array, index: int}|null
	 */
	public static function current() {
		if ( empty( self::$stack ) ) {
			return null;
		}

		return self::$stack[ count( self::$stack ) - 1 ];
	}

	/**
	 * Current row array.
	 *
	 * @since 8.9.1
	 * @return array
	 */
	public static function current_row() {
		$frame = self::current();
		return ( null !== $frame && isset( $frame['row'] ) && is_array( $frame['row'] ) )
			? $frame['row']
			: array();
	}

	/**
	 * Current zero-based row index, or -1.
	 *
	 * @since 8.9.1
	 * @return int
	 */
	public static function current_index() {
		$frame = self::current();
		return ( null !== $frame ) ? (int) $frame['index'] : -1;
	}

	/**
	 * Current repeater field name, or empty string.
	 *
	 * @since 8.9.1
	 * @return string
	 */
	public static function current_repeater() {
		$frame = self::current();
		return ( null !== $frame && isset( $frame['repeater_name'] ) )
			? (string) $frame['repeater_name']
			: '';
	}

	/**
	 * Sub-field value from the current row, or null if missing.
	 *
	 * @since 8.9.1
	 * @param string $name Sub-field name.
	 * @return mixed|null
	 */
	public static function get_sub_field( $name ) {
		$name = (string) $name;
		if ( '' === $name || ! self::is_active() ) {
			return null;
		}

		$row = self::current_row();
		if ( ! array_key_exists( $name, $row ) ) {
			return null;
		}

		return $row[ $name ];
	}
}
