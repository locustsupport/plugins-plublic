<?php
/**
 * Oxygen Classic element: ASE Repeater.
 *
 * Nestable element that loops CFG repeater rows and re-renders child Oxygen
 * elements with Oxy_Ase_Repeater_Context set for ASE Dynamic Data / ASE Map.
 *
 * @since 8.9.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ASE Repeater OxyEl for Oxygen Classic.
 *
 * @since 8.9.1
 */
class Oxy_Ase_Repeater extends OxyEl {

	/**
	 * Sentinel value for CFG group header rows in the Field Name dropdown.
	 *
	 * @since 8.9.1
	 */
	const REPEATER_GROUP_HEADER_VALUE = '__ase_repeater_group__';

	/**
	 * Builder AJAX placeholder when children are not passed to PHPCallback.
	 *
	 * @since 8.9.1
	 */
	const BUILDER_EMPTY_CONTENT = '[oxy-empty-shortcode]';

	/**
	 * Element display name.
	 *
	 * @since 8.9.1
	 * @return string
	 */
	public function name() {
		return __( 'ASE Repeater', 'admin-site-enhancements' );
	}

	/**
	 * Stable element slug / shortcode tag base.
	 *
	 * @since 8.9.1
	 * @return string
	 */
	public function slug() {
		return 'oxy-ase-repeater';
	}

	/**
	 * Place under Add → Helpers → Dynamic (beside native Repeater).
	 *
	 * @since 8.9.1
	 * @return string
	 */
	public function button_place() {
		return 'helpers::dynamic';
	}

	/**
	 * Element keywords for Add panel search.
	 *
	 * @since 8.9.1
	 * @return string
	 */
	public function keywords() {
		return 'ase,repeater,loop,custom field,cfg';
	}

	/**
	 * Wrapper class names.
	 *
	 * @since 8.9.1
	 * @return array
	 */
	public function class_names() {
		return array( 'oxy-ase-repeater' );
	}

	/**
	 * Element options.
	 *
	 * @since 8.9.1
	 * @return array
	 */
	public function options() {
		return array(
			'server_side_render' => true,
		);
	}

	/**
	 * Init: enable nesting so children can be placed inside this element.
	 *
	 * @since 8.9.1
	 * @return void
	 */
	public function init() {
		$this->enableNesting();
		add_filter( 'oxy_allowed_empty_options_list', array( $this, 'allowed_empty_options' ) );
	}

	/**
	 * Allow empty Field Name option.
	 *
	 * @since 8.9.1
	 * @param array $options Allowed empty option names.
	 * @return array
	 */
	public function allowed_empty_options( $options ) {
		$options[] = 'oxy-ase-repeater_field_name';
		return $options;
	}

	/**
	 * Default CSS for the repeater wrapper.
	 *
	 * @since 8.9.1
	 * @return string
	 */
	public function defaultCSS() {
		return '
.oxy-ase-repeater {
	max-width: 100%;
	width: 100%;
}
';
	}

	/**
	 * Build Repeater Field dropdown values (stored_value => display_label).
	 *
	 * @since 8.9.1
	 * @return array<string, string>
	 */
	public static function get_repeater_field_dropdown_values() {
		$values = array(
			'' => __( '— Select repeater field —', 'admin-site-enhancements' ),
		);

		if ( ! function_exists( 'CFG' ) ) {
			return $values;
		}

		$repeater_fields = CFG()->find_fields( array( 'field_type' => 'repeater' ) );

		if ( ! is_array( $repeater_fields ) || empty( $repeater_fields ) ) {
			return $values;
		}

		$all_fields = CFG()->find_fields();
		$by_id      = array();

		if ( is_array( $all_fields ) ) {
			foreach ( $all_fields as $f ) {
				if ( is_array( $f ) && isset( $f['id'] ) ) {
					$by_id[ (int) $f['id'] ] = $f;
				}
			}
		}

		$grouped = array();

		foreach ( $repeater_fields as $field ) {
			if ( ! is_array( $field ) || empty( $field['name'] ) ) {
				continue;
			}

			$field_name = (string) $field['name'];
			$label      = isset( $field['label'] ) && '' !== (string) $field['label']
				? (string) $field['label']
				: $field_name;

			$text = $label . ' (' . $field_name . ')';

			if ( ! empty( $field['parent_id'] ) && (int) $field['parent_id'] > 0 ) {
				$parent_id = (int) $field['parent_id'];
				if ( isset( $by_id[ $parent_id ]['label'] ) && '' !== (string) $by_id[ $parent_id ]['label'] ) {
					$text .= ' — ' . sprintf(
						/* translators: %s: parent repeater field label */
						__( 'inside %s', 'admin-site-enhancements' ),
						(string) $by_id[ $parent_id ]['label']
					);
				}
			}

			$group_id    = isset( $field['group_id'] ) ? (int) $field['group_id'] : 0;
			$group_title = '';

			if ( $group_id > 0 ) {
				$group_title = get_the_title( $group_id );
			}

			if ( ! is_string( $group_title ) || '' === $group_title ) {
				$group_title = __( 'Field Group', 'admin-site-enhancements' );
			}

			if ( ! isset( $grouped[ $group_title ] ) ) {
				$grouped[ $group_title ] = array();
			}

			$grouped[ $group_title ][] = array(
				'text'  => $text,
				'value' => $field_name,
				'label' => $label,
			);
		}

		if ( empty( $grouped ) ) {
			return $values;
		}

		ksort( $grouped, SORT_NATURAL | SORT_FLAG_CASE );

		$header_index = 0;
		foreach ( $grouped as $group_title => $group_fields ) {
			usort(
				$group_fields,
				static function ( $a, $b ) {
					return strnatcasecmp( (string) $a['label'], (string) $b['label'] );
				}
			);

			++$header_index;
			$values[ self::REPEATER_GROUP_HEADER_VALUE . '_' . $header_index ] = '── ' . $group_title . ' ──';

			foreach ( $group_fields as $group_field ) {
				$values[ $group_field['value'] ] = $group_field['text'];
			}
		}

		return $values;
	}

	/**
	 * Register builder controls.
	 *
	 * @since 8.9.1
	 * @return void
	 */
	public function controls() {
		$this->flex( '' );

		$field_control = $this->addOptionControl(
			array(
				'type' => 'dropdown',
				'name' => __( 'Repeater Field', 'admin-site-enhancements' ),
				'slug' => 'field_name',
			)
		);
		$field_control->setValue( self::get_repeater_field_dropdown_values() );
		$field_control->rebuildElementOnChange();
	}

	/**
	 * Normalize Field Name option to a CFG field name.
	 *
	 * @since 8.9.1
	 * @param string $raw Raw option value from Oxygen.
	 * @return string Field name or empty string.
	 */
	protected function normalize_field_name( $raw ) {
		$raw = is_string( $raw ) ? trim( $raw ) : '';

		if ( '' === $raw || 0 === strpos( $raw, self::REPEATER_GROUP_HEADER_VALUE ) ) {
			return '';
		}

		if ( function_exists( 'find_cf' ) ) {
			$found = find_cf( array( 'field_name' => $raw ) );
			if ( is_array( $found ) && isset( $found[ $raw ] ) && is_array( $found[ $raw ] ) ) {
				return $raw;
			}
		}

		if ( preg_match( '/\(([^)]+)\)/', $raw, $matches ) ) {
			$maybe = trim( (string) $matches[1] );
			if ( '' !== $maybe && function_exists( 'find_cf' ) ) {
				$found = find_cf( array( 'field_name' => $maybe ) );
				if ( is_array( $found ) && isset( $found[ $maybe ] ) && is_array( $found[ $maybe ] ) ) {
					return $maybe;
				}
			}
		}

		return $raw;
	}

	/**
	 * Resolve current post/term ID for get_cf().
	 *
	 * @since 8.9.1
	 * @return int|string
	 */
	protected function resolve_object_id() {
		$queried_object = get_queried_object();

		if ( is_a( $queried_object, 'WP_Term' ) ) {
			return $queried_object->taxonomy . '_' . $queried_object->term_id;
		}

		$post_id = (int) get_the_ID();
		if ( $post_id > 0 ) {
			return $post_id;
		}

		global $post;
		if ( isset( $post->ID ) ) {
			return (int) $post->ID;
		}

		return 0;
	}

	/**
	 * Resolve repeater rows for the selected field.
	 *
	 * Top-level: get_cf( name, raw ). Nested: from parent row context when active.
	 *
	 * @since 8.9.1
	 * @param string $field_name Repeater field name.
	 * @return array<int, array>
	 */
	protected function resolve_rows( $field_name ) {
		if ( '' === $field_name || ! function_exists( 'get_cf' ) || ! function_exists( 'find_cf' ) ) {
			return array();
		}

		$found = find_cf( array( 'field_name' => $field_name ) );
		$field = ( is_array( $found ) && isset( $found[ $field_name ] ) && is_array( $found[ $field_name ] ) )
			? $found[ $field_name ]
			: array();

		$parent_id = isset( $field['parent_id'] ) ? (int) $field['parent_id'] : 0;

		// Nested repeater: prefer parent ASE Repeater row context.
		if ( $parent_id > 0 && class_exists( 'Oxy_Ase_Repeater_Context' ) && Oxy_Ase_Repeater_Context::is_active() ) {
			$from_parent = Oxy_Ase_Repeater_Context::get_sub_field( $field_name );
			if ( is_array( $from_parent ) ) {
				return $this->normalize_rows( $from_parent );
			}
			return array();
		}

		$object_id = $this->resolve_object_id();
		if ( empty( $object_id ) ) {
			return array();
		}

		$rows = get_cf( $field_name, 'raw', $object_id );
		return $this->normalize_rows( $rows );
	}

	/**
	 * Ensure rows is a list of associative row arrays.
	 *
	 * @since 8.9.1
	 * @param mixed $rows Raw get_cf repeater value.
	 * @return array<int, array>
	 */
	protected function normalize_rows( $rows ) {
		if ( ! is_array( $rows ) || empty( $rows ) ) {
			return array();
		}

		$normalized = array();
		foreach ( $rows as $row ) {
			if ( is_array( $row ) ) {
				$normalized[] = $row;
			}
		}

		return $normalized;
	}

	/**
	 * Whether $content is usable for looping (not builder placeholder / empty).
	 *
	 * Oxygen's JSON render path passes nestable children as an array of nodes;
	 * the shortcode path passes a string of nested shortcodes.
	 *
	 * @since 8.9.1
	 * @param mixed $content Nested Oxygen children (array) or shortcode string.
	 * @return bool
	 */
	protected function has_loopable_content( $content ) {
		if ( null === $content || false === $content ) {
			return false;
		}

		// JSON tree path: do_oxygen_elements() accepts an array of child nodes.
		if ( is_array( $content ) ) {
			return ! empty( $content );
		}

		if ( ! is_string( $content ) ) {
			return false;
		}

		$content = trim( $content );
		if ( '' === $content ) {
			return false;
		}

		if ( self::BUILDER_EMPTY_CONTENT === $content ) {
			return false;
		}

		return true;
	}

	/**
	 * Server-side render: loop rows and render children.
	 *
	 * @since 8.9.1
	 * @param array        $options  Unprefixed element options.
	 * @param array        $defaults Defaults.
	 * @param array|string $content  Nested Oxygen children (JSON array) or shortcodes.
	 * @return void
	 */
	public function render( $options, $defaults, $content ) {
		$raw_field_name = isset( $options['field_name'] ) ? (string) $options['field_name'] : '';
		$field_name     = $this->normalize_field_name( $raw_field_name );

		if ( '' === $field_name || ! $this->has_loopable_content( $content ) ) {
			return;
		}

		if ( ! class_exists( 'Oxy_Ase_Repeater_Context' ) || ! function_exists( 'do_oxygen_elements' ) ) {
			return;
		}

		$rows = $this->resolve_rows( $field_name );
		if ( empty( $rows ) ) {
			return;
		}

		foreach ( $rows as $index => $row ) {
			Oxy_Ase_Repeater_Context::push( $field_name, $row, (int) $index );
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Oxygen child shortcodes render HTML.
			echo do_oxygen_elements( $content );
			Oxy_Ase_Repeater_Context::pop();
		}
	}
}

new Oxy_Ase_Repeater();
