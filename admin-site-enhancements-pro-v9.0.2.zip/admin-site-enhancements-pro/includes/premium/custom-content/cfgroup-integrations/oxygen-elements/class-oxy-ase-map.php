<?php
/**
 * Oxygen Classic element: ASE Map.
 *
 * Renders a CFG map field embed (Google iframe or OSM Leaflet) via get_cf_map().
 *
 * @since 8.9.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ASE Map OxyEl for Oxygen Classic.
 *
 * @since 8.9.1
 */
class Oxy_Ase_Map extends OxyEl {

	/**
	 * Sentinel value for CFG group header rows in the Field Name dropdown.
	 *
	 * @since 8.9.1
	 */
	const MAP_GROUP_HEADER_VALUE = '__ase_map_group__';

	/**
	 * Element display name.
	 *
	 * @since 8.9.1
	 * @return string
	 */
	public function name() {
		return __( 'ASE Map', 'admin-site-enhancements' );
	}

	/**
	 * Stable element slug / shortcode tag base.
	 *
	 * @since 8.9.1
	 * @return string
	 */
	public function slug() {
		return 'oxy-ase-map';
	}

	/**
	 * Place under Add → Helpers → External (with Google Maps).
	 *
	 * @since 8.9.1
	 * @return string
	 */
	public function button_place() {
		return 'helpers::external';
	}

	/**
	 * Element keywords for Add panel search.
	 *
	 * @since 8.9.1
	 * @return string
	 */
	public function keywords() {
		return 'ase,map,location,google,openstreetmap,osm,leaflet';
	}

	/**
	 * Wrapper class names.
	 *
	 * @since 8.9.1
	 * @return array
	 */
	public function class_names() {
		return array( 'oxy-ase-map' );
	}

	/**
	 * Element options.
	 *
	 * @since 8.9.1
	 * @return array
	 */
	public function options() {
		return array(
			'server_side_render' => true,
		);
	}

	/**
	 * Init hooks.
	 *
	 * @since 8.9.1
	 * @return void
	 */
	public function init() {
		add_filter( 'oxy_allowed_empty_options_list', array( $this, 'allowed_empty_options' ) );
	}

	/**
	 * Allow empty Height / Zoom so field defaults apply.
	 *
	 * @since 8.9.1
	 * @param array $options Allowed empty option names.
	 * @return array
	 */
	public function allowed_empty_options( $options ) {
		$options[] = 'oxy-ase-map_field_name';
		$options[] = 'oxy-ase-map_address_position';
		$options[] = 'oxy-ase-map_height';
		$options[] = 'oxy-ase-map_zoom';

		return $options;
	}

	/**
	 * Default CSS: wrapper auto height; map media gets fixed height.
	 *
	 * @since 8.9.1
	 * @return string
	 */
	public function defaultCSS() {
		return '
.oxy-ase-map {
	max-width: 100%;
	width: 100%;
	height: auto;
}
.oxy-ase-map .asenha-cfgroup-map-osm,
.oxy-ase-map iframe {
	width: 100%;
	height: 400px;
	border: 0;
}
';
	}

	/**
	 * Build Field Name dropdown values for Oxygen (stored_value => display_label).
	 *
	 * Oxygen ctDropDownTemplate uses ng-repeat="(value, name) in data.pairs".
	 *
	 * @since 8.9.1
	 * @return array<string, string>
	 */
	public static function get_map_field_dropdown_values() {
		$values = array(
			'' => __( '— Select map field —', 'admin-site-enhancements' ),
		);

		if ( ! function_exists( 'CFG' ) ) {
			return $values;
		}

		$map_fields = CFG()->find_fields( array( 'field_type' => 'map' ) );

		if ( ! is_array( $map_fields ) || empty( $map_fields ) ) {
			return $values;
		}

		$all_fields = CFG()->find_fields();
		$by_id      = array();

		if ( is_array( $all_fields ) ) {
			foreach ( $all_fields as $f ) {
				if ( is_array( $f ) && isset( $f['id'] ) ) {
					$by_id[ (int) $f['id'] ] = $f;
				}
			}
		}

		$grouped = array();

		foreach ( $map_fields as $field ) {
			if ( ! is_array( $field ) || empty( $field['name'] ) ) {
				continue;
			}

			$field_name = (string) $field['name'];
			$label      = isset( $field['label'] ) && '' !== (string) $field['label']
				? (string) $field['label']
				: $field_name;

			// Oxygen display: "Field Label (field_name)".
			$text = $label . ' (' . $field_name . ')';

			if ( ! empty( $field['parent_id'] ) && (int) $field['parent_id'] > 0 ) {
				$parent_id = (int) $field['parent_id'];
				if ( isset( $by_id[ $parent_id ]['label'] ) && '' !== (string) $by_id[ $parent_id ]['label'] ) {
					$text .= ' — ' . (string) $by_id[ $parent_id ]['label'];
				}
			}

			$group_id    = isset( $field['group_id'] ) ? (int) $field['group_id'] : 0;
			$group_title = '';

			if ( $group_id > 0 ) {
				$group_title = get_the_title( $group_id );
			}

			if ( ! is_string( $group_title ) || '' === $group_title ) {
				$group_title = __( 'Field Group', 'admin-site-enhancements' );
			}

			if ( ! isset( $grouped[ $group_title ] ) ) {
				$grouped[ $group_title ] = array();
			}

			$grouped[ $group_title ][] = array(
				'text'  => $text,
				'value' => $field_name,
				'label' => $label,
			);
		}

		if ( empty( $grouped ) ) {
			return $values;
		}

		ksort( $grouped, SORT_NATURAL | SORT_FLAG_CASE );

		$header_index = 0;
		foreach ( $grouped as $group_title => $group_fields ) {
			usort(
				$group_fields,
				static function ( $a, $b ) {
					return strnatcasecmp( (string) $a['label'], (string) $b['label'] );
				}
			);

			// Unique sentinel per header (fake optgroup); ignored in render.
			++$header_index;
			$values[ self::MAP_GROUP_HEADER_VALUE . '_' . $header_index ] = '── ' . $group_title . ' ──';

			foreach ( $group_fields as $group_field ) {
				$values[ $group_field['value'] ] = $group_field['text'];
			}
		}

		return $values;
	}

	/**
	 * Register builder controls.
	 *
	 * @since 8.9.1
	 * @return void
	 */
	public function controls() {
		$field_control = $this->addOptionControl(
			array(
				'type' => 'dropdown',
				'name' => __( 'Field Name', 'admin-site-enhancements' ),
				'slug' => 'field_name',
			)
		);
		$field_control->setValue( self::get_map_field_dropdown_values() );
		$field_control->rebuildElementOnChange();

		$address_control = $this->addOptionControl(
			array(
				'type'    => 'dropdown',
				'name'    => __( 'Address Position', 'admin-site-enhancements' ),
				'slug'    => 'address_position',
				'default' => 'none',
			)
		);
		$address_control->setValue(
			array(
				'none'  => __( 'None (map only)', 'admin-site-enhancements' ),
				'above' => __( 'Above map', 'admin-site-enhancements' ),
				'below' => __( 'Below map', 'admin-site-enhancements' ),
			)
		);
		$address_control->setDefaultValue( 'none' );
		$address_control->rebuildElementOnChange();

		$height_control = $this->addOptionControl(
			array(
				'type' => 'textfield',
				'name' => __( 'Height (px)', 'admin-site-enhancements' ),
				'slug' => 'height',
			)
		);
		$height_control->rebuildElementOnChange();

		$zoom_control = $this->addOptionControl(
			array(
				'type' => 'textfield',
				'name' => __( 'Zoom', 'admin-site-enhancements' ),
				'slug' => 'zoom',
			)
		);
		$zoom_control->rebuildElementOnChange();
	}

	/**
	 * Normalize Field Name option to a CFG field name.
	 *
	 * Handles legacy inverted dropdown saves that stored the display label
	 * (e.g. "Location (movie_location_gmaps) [map · Google Maps]").
	 *
	 * @since 8.9.1
	 * @param string $raw Raw option value from Oxygen.
	 * @return string Field name or empty string.
	 */
	protected function normalize_field_name( $raw ) {
		$raw = is_string( $raw ) ? trim( $raw ) : '';

		if ( '' === $raw || 0 === strpos( $raw, self::MAP_GROUP_HEADER_VALUE ) ) {
			return '';
		}

		if ( function_exists( 'find_cf' ) ) {
			$found = find_cf( array( 'field_name' => $raw ) );
			if ( is_array( $found ) && isset( $found[ $raw ] ) && is_array( $found[ $raw ] ) ) {
				return $raw;
			}
		}

		// Legacy: display label containing "(field_name)".
		if ( preg_match( '/\(([^)]+)\)/', $raw, $matches ) ) {
			$maybe = trim( (string) $matches[1] );
			if ( '' !== $maybe && function_exists( 'find_cf' ) ) {
				$found = find_cf( array( 'field_name' => $maybe ) );
				if ( is_array( $found ) && isset( $found[ $maybe ] ) && is_array( $found[ $maybe ] ) ) {
					return $maybe;
				}
			}
			if ( '' !== $maybe && function_exists( 'CFG' ) ) {
				$map_fields = CFG()->find_fields( array( 'field_type' => 'map' ) );
				if ( is_array( $map_fields ) ) {
					foreach ( $map_fields as $field ) {
						if ( is_array( $field ) && isset( $field['name'] ) && (string) $field['name'] === $maybe ) {
							return $maybe;
						}
					}
				}
			}
		}

		return $raw;
	}

	/**
	 * Resolve map field options for a field name.
	 *
	 * @since 8.9.1
	 * @param string $field_name Field name.
	 * @return array
	 */
	protected function get_map_field_options( $field_name ) {
		if ( function_exists( 'find_cf' ) ) {
			$field = find_cf( array( 'field_name' => $field_name ) );
			if ( is_array( $field ) && isset( $field[ $field_name ]['options'] ) && is_array( $field[ $field_name ]['options'] ) ) {
				return $field[ $field_name ]['options'];
			}
		}

		$cf_info = function_exists( 'get_cf_info' ) ? get_cf_info( $field_name ) : array();
		if ( is_array( $cf_info ) && isset( $cf_info['options'] ) && is_array( $cf_info['options'] ) ) {
			return $cf_info['options'];
		}

		return array();
	}

	/**
	 * Resolve map value: ASE Repeater loop context, top-level get_cf, or first-row fallback.
	 *
	 * @since 8.9.1
	 * @param string $field_name Map field name.
	 * @return array
	 */
	protected function resolve_map_value( $field_name ) {
		if ( empty( $field_name ) || ! function_exists( 'get_cf' ) ) {
			return array();
		}

		// Prefer current ASE Repeater row when looping.
		if ( class_exists( 'Oxy_Ase_Repeater_Context' ) && Oxy_Ase_Repeater_Context::is_active() ) {
			$from_row = Oxy_Ase_Repeater_Context::get_sub_field( $field_name );
			if ( is_array( $from_row ) && ! empty( $from_row['latitude'] ) && ! empty( $from_row['longitude'] ) ) {
				return $from_row;
			}
		}

		$raw = get_cf( $field_name, 'raw' );
		if ( is_array( $raw ) && ! empty( $raw['latitude'] ) && ! empty( $raw['longitude'] ) ) {
			return $raw;
		}

		// Repeater sub-field outside a working loop: first-row fallback.
		if ( ! function_exists( 'get_parent_repeater_cf' ) ) {
			return is_array( $raw ) ? $raw : array();
		}

		$parent = get_parent_repeater_cf( $field_name );
		if ( ! is_array( $parent ) || empty( $parent['name'] ) ) {
			return is_array( $raw ) ? $raw : array();
		}

		$post_id = (int) get_the_ID();
		if ( $post_id <= 0 ) {
			global $post;
			$post_id = ( isset( $post->ID ) ) ? (int) $post->ID : 0;
		}

		if ( $post_id <= 0 ) {
			return array();
		}

		$rows = get_cf( (string) $parent['name'], 'raw', $post_id );
		if ( ! is_array( $rows ) || ! isset( $rows[0] ) || ! is_array( $rows[0] ) ) {
			return array();
		}

		if ( ! isset( $rows[0][ $field_name ] ) || ! is_array( $rows[0][ $field_name ] ) ) {
			return array();
		}

		$value = $rows[0][ $field_name ];
		if ( empty( $value['latitude'] ) || empty( $value['longitude'] ) ) {
			return array();
		}

		return $value;
	}

	/**
	 * Server-side render.
	 *
	 * @since 8.9.1
	 * @param array  $options  Unprefixed element options.
	 * @param array  $defaults Defaults.
	 * @param string $content  Nested content.
	 * @return void
	 */
	public function render( $options, $defaults, $content ) {
		$raw_field_name = isset( $options['field_name'] ) ? (string) $options['field_name'] : '';
		$field_name     = $this->normalize_field_name( $raw_field_name );

		if ( '' === $field_name || ! function_exists( 'get_cf_map' ) ) {
			return;
		}

		$map_value = $this->resolve_map_value( $field_name );

		if ( ! is_array( $map_value ) || empty( $map_value['latitude'] ) || empty( $map_value['longitude'] ) ) {
			return;
		}

		$field_options = $this->get_map_field_options( $field_name );

		$address_position = isset( $options['address_position'] ) ? (string) $options['address_position'] : 'none';
		// Legacy inverted dropdown may have stored the display label.
		$legacy_address = array(
			'None (map only)' => 'none',
			'Above map'       => 'above',
			'Below map'       => 'below',
		);
		if ( isset( $legacy_address[ $address_position ] ) ) {
			$address_position = $legacy_address[ $address_position ];
		}
		$address_position = in_array( $address_position, array( 'none', 'above', 'below' ), true )
			? $address_position
			: 'none';

		$overrides = array();

		if ( isset( $options['height'] ) && '' !== $options['height'] && null !== $options['height'] ) {
			$height = absint( $options['height'] );
			if ( $height > 0 ) {
				$overrides['height'] = $height . 'px';
			}
		}

		if ( isset( $options['zoom'] ) && '' !== $options['zoom'] && null !== $options['zoom'] ) {
			$zoom = absint( $options['zoom'] );
			if ( $zoom >= 1 && $zoom <= 21 ) {
				$overrides['zoom'] = $zoom;
			}
		}

		$provider = isset( $field_options['map_provider'] ) ? (string) $field_options['map_provider'] : 'openstreetmap';
		if ( 'openstreetmap' === $provider && function_exists( 'asenha_cfgroup_enqueue_map_osm_frontend' ) ) {
			asenha_cfgroup_enqueue_map_osm_frontend();
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- get_cf_map() returns escaped HTML.
		echo get_cf_map( $map_value, $field_options, $address_position, $overrides );
	}
}

new Oxy_Ase_Map();
