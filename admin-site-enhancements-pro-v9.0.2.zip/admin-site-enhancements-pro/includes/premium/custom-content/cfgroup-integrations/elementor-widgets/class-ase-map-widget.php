<?php
namespace ASENHA\Integrations\Elementor;

use ASENHA\Integrations\Elementor\Ase_Elementor_Integration;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor widget that renders a CFG map field embed (Google iframe or OSM Leaflet).
 *
 * Supports top-level map fields and ASE Loop Item repeater map sub-fields.
 *
 * @since 8.9.1
 */
class Ase_Map_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * @since 8.9.1
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'ase-map';
	}

	/**
	 * Get widget title.
	 *
	 * @since 8.9.1
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'ASE Map', 'admin-site-enhancements' );
	}

	/**
	 * Get widget icon.
	 *
	 * @since 8.9.1
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-google-maps';
	}

	/**
	 * Get widget categories.
	 *
	 * @since 8.9.1
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'ase', 'basic' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * @since 8.9.1
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'ase', 'map', 'location', 'google', 'openstreetmap', 'osm', 'leaflet' ];
	}

	/**
	 * Style dependencies (Leaflet + OSM frontend) for Elementor preview/editor.
	 *
	 * @since 8.9.1
	 * @access public
	 * @return array Style handle names.
	 */
	public function get_style_depends() {
		if ( function_exists( 'asenha_cfgroup_register_map_osm_frontend' ) ) {
			asenha_cfgroup_register_map_osm_frontend();
		}

		return array( 'asenha-cfgroup-leaflet', 'asenha-cfgroup-map-frontend' );
	}

	/**
	 * Script dependencies (Leaflet + OSM frontend) for Elementor preview/editor.
	 *
	 * @since 8.9.1
	 * @access public
	 * @return array Script handle names.
	 */
	public function get_script_depends() {
		if ( function_exists( 'asenha_cfgroup_register_map_osm_frontend' ) ) {
			asenha_cfgroup_register_map_osm_frontend();
		}

		return array( 'asenha-cfgroup-leaflet', 'asenha-cfgroup-map-frontend' );
	}

	/**
	 * Whether the widget content depends on the current post/query.
	 *
	 * @since 8.9.1
	 * @access protected
	 * @return bool
	 */
	protected function is_dynamic_content(): bool {
		return true;
	}

	/**
	 * Build Field Name SELECT groups (top-level maps + Loop Item repeater map sub-fields).
	 *
	 * @since 8.9.1
	 * @access protected
	 * @return array
	 */
	protected function get_map_field_control_groups() {
		$ase_elementor_integration = new Ase_Elementor_Integration();
		$result                    = $ase_elementor_integration->get_ase_map_widget_field_groups();

		return ( is_array( $result ) && isset( $result['groups'] ) && is_array( $result['groups'] ) )
			? $result['groups']
			: array();
	}

	/**
	 * Register widget controls.
	 *
	 * @since 8.9.1
	 * @access protected
	 * @return void
	 */
	protected function register_controls() {
		$cf_groups = $this->get_map_field_control_groups();

		$this->start_controls_section(
			'section_map',
			[
				'label' => esc_html__( 'Map', 'admin-site-enhancements' ),
			]
		);

		$this->add_control(
			'key',
			[
				'label'       => esc_html__( 'Field Name', 'admin-site-enhancements' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'groups'      => $cf_groups,
				'description' => esc_html__( 'Map provider (Google Maps or OpenStreetMap) comes from the field definition. In ASE Loop Item templates, repeater map sub-fields are also listed.', 'admin-site-enhancements' ),
			]
		);

		$this->add_control(
			'address_position',
			[
				'label'   => esc_html__( 'Address Position', 'admin-site-enhancements' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [
					'none'  => esc_html__( 'None (map only)', 'admin-site-enhancements' ),
					'above' => esc_html__( 'Above map', 'admin-site-enhancements' ),
					'below' => esc_html__( 'Below map', 'admin-site-enhancements' ),
				],
			]
		);

		$this->add_control(
			'height',
			[
				'label'       => esc_html__( 'Height (px)', 'admin-site-enhancements' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'min'         => 100,
				'max'         => 1200,
				'step'        => 10,
				'placeholder' => esc_html__( 'Field default', 'admin-site-enhancements' ),
				'description' => esc_html__( 'Leave empty to use the height from the field definition.', 'admin-site-enhancements' ),
			]
		);

		$this->add_control(
			'zoom',
			[
				'label'       => esc_html__( 'Zoom', 'admin-site-enhancements' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'min'         => 1,
				'max'         => 21,
				'step'        => 1,
				'placeholder' => esc_html__( 'Saved zoom', 'admin-site-enhancements' ),
				'description' => esc_html__( 'Leave empty to use the zoom saved with the location.', 'admin-site-enhancements' ),
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Resolve field options for a map field (top-level or repeater sub-field).
	 *
	 * @since 8.9.1
	 * @param string $field_name Field name.
	 * @return array
	 */
	protected function get_map_field_options( $field_name ) {
		if ( function_exists( 'find_cf' ) ) {
			$field = find_cf( array( 'field_name' => $field_name ) );
			if ( is_array( $field ) && isset( $field[ $field_name ]['options'] ) && is_array( $field[ $field_name ]['options'] ) ) {
				return $field[ $field_name ]['options'];
			}
		}

		$cf_info = function_exists( 'get_cf_info' ) ? get_cf_info( $field_name ) : array();
		if ( is_array( $cf_info ) && isset( $cf_info['options'] ) && is_array( $cf_info['options'] ) ) {
			return $cf_info['options'];
		}

		return array();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 8.9.1
	 * @access protected
	 * @return void
	 */
	protected function render() {
		$settings  = $this->get_settings_for_display();
		$field_key = isset( $settings['key'] ) ? $settings['key'] : '';

		if ( empty( $field_key ) ) {
			return;
		}

		$field_key_parts = explode( '__', $field_key );
		$field_name      = isset( $field_key_parts[0] ) ? $field_key_parts[0] : '';
		$field_type      = isset( $field_key_parts[1] ) ? $field_key_parts[1] : '';

		if ( empty( $field_name ) || 'map' !== $field_type ) {
			return;
		}

		if ( ! function_exists( 'get_cf_map' ) ) {
			return;
		}

		$map_value = function_exists( 'asenha_get_cf_map_value_for_context' )
			? asenha_get_cf_map_value_for_context( $field_name )
			: ( function_exists( 'get_cf' ) ? get_cf( $field_name, 'raw' ) : array() );

		if ( ! is_array( $map_value ) || empty( $map_value['latitude'] ) || empty( $map_value['longitude'] ) ) {
			return;
		}

		$options = $this->get_map_field_options( $field_name );

		$address_position = isset( $settings['address_position'] ) ? $settings['address_position'] : 'none';
		$address_position = in_array( $address_position, array( 'none', 'above', 'below' ), true )
			? $address_position
			: 'none';

		$overrides = array();

		if ( isset( $settings['height'] ) && '' !== $settings['height'] && null !== $settings['height'] ) {
			$height = absint( $settings['height'] );
			if ( $height > 0 ) {
				$overrides['height'] = $height . 'px';
			}
		}

		if ( isset( $settings['zoom'] ) && '' !== $settings['zoom'] && null !== $settings['zoom'] ) {
			$zoom = absint( $settings['zoom'] );
			if ( $zoom >= 1 && $zoom <= 21 ) {
				$overrides['zoom'] = $zoom;
			}
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- get_cf_map() returns escaped HTML.
		echo get_cf_map( $map_value, $options, $address_position, $overrides );
	}

}
