<?php
namespace ASENHA\Integrations\Elementor;

use ASENHA\Integrations\Elementor\Ase_Elementor_Integration;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor Dynamic Tag - ASE CFG map fields (text parts + Google Maps Location).
 *
 * Categories include TEXT (Heading/Text widgets) and POST_META (Elementor Google Maps Location).
 *
 * @since 8.9.1
 */
class Ase_Map extends \Elementor\Core\DynamicTags\Tag {

	/**
	 * Get dynamic tag name.
	 *
	 * @since 8.9.1
	 * @access public
	 * @return string Dynamic tag name.
	 */
	public function get_name() {
		return 'ase-map';
	}

	/**
	 * Get dynamic tag title.
	 *
	 * @since 8.9.1
	 * @access public
	 * @return string Dynamic tag title.
	 */
	public function get_title() {
		return 'ASE Map Field';
	}

	/**
	 * Get dynamic tag groups.
	 *
	 * @since 8.9.1
	 * @access public
	 * @return array Dynamic tag groups.
	 */
	public function get_group() {
		return [ 'ase' ];
	}

	/**
	 * Get dynamic tag categories.
	 *
	 * TEXT for Heading/Text widgets; POST_META for Elementor Google Maps Location control.
	 *
	 * @since 8.9.1
	 * @access public
	 * @return array Dynamic tag categories.
	 */
	public function get_categories() {
		return [
			\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY,
			\Elementor\Modules\DynamicTags\Module::POST_META_CATEGORY,
		];
	}

	/**
	 * Register dynamic tag controls.
	 *
	 * @since 8.9.1
	 * @access protected
	 * @return void
	 */
	protected function register_controls() {
		$ase_elementor_integration = new Ase_Elementor_Integration();
		$cf_groups                 = $ase_elementor_integration->get_control_options( 'map', array( 'map' ) );

		$this->add_control(
			'key',
			[
				'label'  => __( 'Field Name', 'admin-site-enhancements' ),
				'type'   => \Elementor\Controls_Manager::SELECT,
				'groups' => $cf_groups,
			]
		);

		$this->add_control(
			'map_output',
			[
				'label'   => __( 'Output', 'admin-site-enhancements' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'address',
				'options' => [
					'address'                      => __( 'Address', 'admin-site-enhancements' ),
					'address_no_place_name'        => __( 'Address (no place name)', 'admin-site-enhancements' ),
					'address_linked'               => __( 'Linked address', 'admin-site-enhancements' ),
					'address_no_place_name_linked' => __( 'Linked address (no place name)', 'admin-site-enhancements' ),
					'place_name'                   => __( 'Place name', 'admin-site-enhancements' ),
					'street_number'                => __( 'Street number', 'admin-site-enhancements' ),
					'street_name'                  => __( 'Street name', 'admin-site-enhancements' ),
					'city_block'                   => __( 'City block', 'admin-site-enhancements' ),
					'sublocality'                  => __( 'Neighbourhood / Sublocality', 'admin-site-enhancements' ),
					'city'                         => __( 'City', 'admin-site-enhancements' ),
					'state'                        => __( 'State', 'admin-site-enhancements' ),
					'post_code'                    => __( 'Post code', 'admin-site-enhancements' ),
					'country'                      => __( 'Country', 'admin-site-enhancements' ),
					'latitude'                     => __( 'Latitude', 'admin-site-enhancements' ),
					'longitude'                    => __( 'Longitude', 'admin-site-enhancements' ),
					'zoom'                         => __( 'Zoom', 'admin-site-enhancements' ),
					'lat_lng'                      => __( 'Latitude, Longitude', 'admin-site-enhancements' ),
					'map'                          => __( 'Map embed', 'admin-site-enhancements' ),
					'map_with_address_above'       => __( 'Map with address above', 'admin-site-enhancements' ),
					'map_with_address_below'       => __( 'Map with address below', 'admin-site-enhancements' ),
				],
			]
		);
	}

	/**
	 * Render tag output on the frontend.
	 *
	 * @since 8.9.1
	 * @access public
	 * @return void
	 */
	public function render() {
		$field_key = $this->get_settings( 'key' );

		if ( empty( $field_key ) ) {
			echo '';
			return;
		}

		$field_key_parts = explode( '__', $field_key );
		$field_name      = isset( $field_key_parts[0] ) ? $field_key_parts[0] : '';
		$field_type      = isset( $field_key_parts[1] ) ? $field_key_parts[1] : '';

		if ( empty( $field_name ) || 'map' !== $field_type ) {
			echo '';
			return;
		}

		$output_format = $this->get_settings( 'map_output' );
		$output_format = ! empty( $output_format ) ? $output_format : 'address';

		$raw_value = get_cf( $field_name, 'raw' );
		if ( ! is_array( $raw_value ) || empty( $raw_value ) ) {
			echo '';
			return;
		}

		$cf_info = function_exists( 'get_cf_info' ) ? get_cf_info( $field_name ) : array();
		$options = ( is_array( $cf_info ) && isset( $cf_info['options'] ) && is_array( $cf_info['options'] ) )
			? $cf_info['options']
			: array();

		$field_value = function_exists( 'asenha_format_cf_map_output' )
			? asenha_format_cf_map_output( $raw_value, $output_format, $options )
			: '';

		if ( '' === $field_value || null === $field_value ) {
			echo '';
			return;
		}

		$html_outputs = array(
			'address_linked',
			'address_no_place_name_linked',
			'map',
			'map_with_address_above',
			'map_with_address_below',
			'default',
			'option',
		);

		if ( in_array( $output_format, $html_outputs, true ) ) {
			echo wp_kses( $field_value, get_kses_with_style_src_svg_ruleset() );
			return;
		}

		echo esc_html( $field_value );
	}

}
