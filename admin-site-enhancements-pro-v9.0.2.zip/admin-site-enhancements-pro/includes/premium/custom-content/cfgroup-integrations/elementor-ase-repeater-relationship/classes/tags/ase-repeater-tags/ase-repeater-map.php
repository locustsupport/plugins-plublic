<?php

namespace ElementorAseRepeaterRelationship\DynamicTags;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor Dynamic Tag - ASE CFG map sub-fields inside a Loop repeater.
 *
 * @since 8.9.1
 */
class AseRepeaterMap extends AseRepeaterTagBase {

	/**
	 * Get dynamic tag name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'ase-repeater-map';
	}

	/**
	 * Get dynamic tag title.
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'ASE Repeater Map', 'admin-site-enhancements' );
	}

	/**
	 * Get dynamic tag group.
	 *
	 * @return string
	 */
	public function get_group() {
		return 'ase';
	}

	/**
	 * Get dynamic tag categories.
	 *
	 * TEXT for Heading/Text; POST_META for Elementor Google Maps Location.
	 *
	 * @return array
	 */
	public function get_categories() {
		return array(
			\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY,
			\Elementor\Modules\DynamicTags\Module::POST_META_CATEGORY,
		);
	}

	/**
	 * CFG sub-field types shown in the picker.
	 *
	 * @return array
	 */
	public function get_supported_fields() {
		return array( 'map' );
	}

	/**
	 * Additional controls beyond the shared repeater_field SELECT.
	 *
	 * Called from DynamicTagControls::register_controls() before end_controls_section().
	 *
	 * @return void
	 */
	public function register_additional_controls() {
		$this->add_control(
			'map_output',
			array(
				'label'   => __( 'Output', 'admin-site-enhancements' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'address',
				'options' => array(
					'address'                      => __( 'Address', 'admin-site-enhancements' ),
					'address_no_place_name'        => __( 'Address (no place name)', 'admin-site-enhancements' ),
					'address_linked'               => __( 'Linked address', 'admin-site-enhancements' ),
					'address_no_place_name_linked' => __( 'Linked address (no place name)', 'admin-site-enhancements' ),
					'place_name'                   => __( 'Place name', 'admin-site-enhancements' ),
					'street_number'                => __( 'Street number', 'admin-site-enhancements' ),
					'street_name'                  => __( 'Street name', 'admin-site-enhancements' ),
					'city_block'                   => __( 'City block', 'admin-site-enhancements' ),
					'sublocality'                  => __( 'Neighbourhood / Sublocality', 'admin-site-enhancements' ),
					'city'                         => __( 'City', 'admin-site-enhancements' ),
					'state'                        => __( 'State', 'admin-site-enhancements' ),
					'post_code'                    => __( 'Post code', 'admin-site-enhancements' ),
					'country'                      => __( 'Country', 'admin-site-enhancements' ),
					'latitude'                     => __( 'Latitude', 'admin-site-enhancements' ),
					'longitude'                    => __( 'Longitude', 'admin-site-enhancements' ),
					'zoom'                         => __( 'Zoom', 'admin-site-enhancements' ),
					'lat_lng'                      => __( 'Latitude, Longitude', 'admin-site-enhancements' ),
					'map'                          => __( 'Map embed', 'admin-site-enhancements' ),
					'map_with_address_above'       => __( 'Map with address above', 'admin-site-enhancements' ),
					'map_with_address_below'       => __( 'Map with address below', 'admin-site-enhancements' ),
				),
			)
		);
	}

	/**
	 * Return formatted map value for the current Loop repeater row.
	 *
	 * @param array $options Elementor options (unused).
	 * @return string
	 */
	public function get_value( array $options = [] ) {
		$field_name = $this->get_settings( 'repeater_field' );

		if ( empty( $field_name ) ) {
			return '';
		}

		$raw_value = $this->get_repeater_value( $field_name, 'raw' );

		if ( ! is_array( $raw_value ) || empty( $raw_value ) ) {
			return '';
		}

		$field     = find_cf( array( 'field_name' => $field_name ) );
		$cf_options = ( is_array( $field ) && isset( $field[ $field_name ]['options'] ) && is_array( $field[ $field_name ]['options'] ) )
			? $field[ $field_name ]['options']
			: array();

		$output_format = $this->get_settings( 'map_output' );
		$output_format = ! empty( $output_format ) ? $output_format : 'address';

		if ( ! function_exists( 'asenha_format_cf_map_output' ) ) {
			return '';
		}

		return asenha_format_cf_map_output( $raw_value, $output_format, $cf_options );
	}
}
