<?php
namespace ASENHA\Integrations\Elementor;

// use ElementorPro\Plugin;
// use ElementorPro\Modules\LoopBuilder\Module as LoopBuilderModule;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Ase_Elementor_Integration {

	/**
	 * Class constructor
	 * 
	 * @since 6.8.3
	 */
	public function __construct() {
		add_action( 'elementor/dynamic_tags/register', [ $this, 'register_request_variables_dynamic_tag_group' ] );
		add_action( 'elementor/dynamic_tags/register', [ $this, 'register_ase_dynamic_tags' ] );
		add_action( 'elementor/elements/categories_registered', [ $this, 'register_widget_category' ] );
		add_action( 'elementor/widgets/register', [ $this, 'register_ase_widgets' ] );
		// Ensure Leaflet handles exist before ASE Map widget get_*_depends() runs in preview.
		add_action( 'elementor/frontend/after_register_scripts', [ $this, 'register_map_osm_assets' ] );
		add_action( 'elementor/preview/enqueue_scripts', [ $this, 'enqueue_map_osm_assets_for_preview' ] );
	}

	/**
	 * Register OSM Leaflet script/style handles for Elementor frontend.
	 *
	 * @since 8.9.1
	 * @return void
	 */
	public function register_map_osm_assets() {
		if ( function_exists( 'asenha_cfgroup_register_map_osm_frontend' ) ) {
			asenha_cfgroup_register_map_osm_frontend();
		}
	}

	/**
	 * Enqueue OSM Leaflet assets in the Elementor preview iframe.
	 *
	 * @since 8.9.1
	 * @return void
	 */
	public function enqueue_map_osm_assets_for_preview() {
		if ( function_exists( 'asenha_cfgroup_enqueue_map_osm_frontend' ) ) {
			asenha_cfgroup_enqueue_map_osm_frontend();
		}
	}

	/**
	 * Register Request Variables Dynamic Tag Group.
	 *
	 * Register new dynamic tag group for Request Variables.
	 *
	 * @since 6.8.3
	 * @param \Elementor\Core\DynamicTags\Manager $dynamic_tags_manager Elementor dynamic tags manager.
	 * @return void
	 */
	public function register_request_variables_dynamic_tag_group( $dynamic_tags_manager ) {
		$dynamic_tags_manager->register_group(
			'ase',
			[
				'title' => 'ASE'
			]
		);
	}

	/**
	 * Register the various field types as dynamic data source
	 *
	 * @since 6.8.3
	 */
	public function register_ase_dynamic_tags( $dynamic_tags_manager ) {
		// $document = Plugin::elementor()->documents->get_current(); // the Elementor template
		// $main_id = $document->main_id; // Template post ID
		// $main_post = $document->get_main_post(); // Template WP_Post_Object
		// $location = $document->get_location(); // e.g. 'single'
		// $template_type = $document->get_template_type(); e.g. 'wp-page' or 'single-post'
		// $elementor_conditions = $document->get_meta( '_elementor_conditions' ); e.g. array( 0 => 'include/singular/acf-movie' )
		// $elementor_page_settings = $document->get_meta( '_elementor_page_settings' ); e.g. array( 'preview_type' => 'single/acf-movie', 'preview_id' => '6801' )

		// Register dynamic data that can return text (including HTML)
		require_once ASENHA_PATH . 'includes/premium/custom-content/cfgroup-integrations/elementor-dynamic-tags/ase-text.php';
		$dynamic_tags_manager->register( new \ASENHA\Integrations\Elementor\Ase_Text );

		// Register dynamic data that can return URL
		require_once ASENHA_PATH . 'includes/premium/custom-content/cfgroup-integrations/elementor-dynamic-tags/ase-url.php';
		$dynamic_tags_manager->register( new \ASENHA\Integrations\Elementor\Ase_Url );

		// Register dynamic data that can return image data
		require_once ASENHA_PATH . 'includes/premium/custom-content/cfgroup-integrations/elementor-dynamic-tags/ase-image.php';
		$dynamic_tags_manager->register( new \ASENHA\Integrations\Elementor\Ase_Image );

		// Register dynamic data that can return gallery data
		require_once ASENHA_PATH . 'includes/premium/custom-content/cfgroup-integrations/elementor-dynamic-tags/ase-gallery.php';
		$dynamic_tags_manager->register( new \ASENHA\Integrations\Elementor\Ase_Gallery );

		// Register dynamic data that can return file data
		require_once ASENHA_PATH . 'includes/premium/custom-content/cfgroup-integrations/elementor-dynamic-tags/ase-file.php';
		$dynamic_tags_manager->register( new \ASENHA\Integrations\Elementor\Ase_File );

		// Register dynamic data that can return number data
		require_once ASENHA_PATH . 'includes/premium/custom-content/cfgroup-integrations/elementor-dynamic-tags/ase-number.php';
		$dynamic_tags_manager->register( new \ASENHA\Integrations\Elementor\Ase_Number );

		// Register dynamic data that can return color data
		require_once ASENHA_PATH . 'includes/premium/custom-content/cfgroup-integrations/elementor-dynamic-tags/ase-color.php';
		$dynamic_tags_manager->register( new \ASENHA\Integrations\Elementor\Ase_Color );

		// Register dynamic data for CFG map fields (text parts + Google Maps Location)
		require_once ASENHA_PATH . 'includes/premium/custom-content/cfgroup-integrations/elementor-dynamic-tags/ase-map.php';
		$dynamic_tags_manager->register( new \ASENHA\Integrations\Elementor\Ase_Map );
	}

	/**
	 * Register the ASE widget category in the Elementor panel.
	 *
	 * @since 8.9.1
	 * @param \Elementor\Elements_Manager $elements_manager Elementor elements manager.
	 * @return void
	 */
	public function register_widget_category( $elements_manager ) {
		$elements_manager->add_category(
			'ase',
			[
				'title' => 'ASE',
				'icon'  => 'fa fa-plug',
			]
		);
	}

	/**
	 * Register ASE Elementor widgets.
	 *
	 * @since 8.9.1
	 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
	 * @return void
	 */
	public function register_ase_widgets( $widgets_manager ) {
		require_once ASENHA_PATH . 'includes/premium/custom-content/cfgroup-integrations/elementor-widgets/class-ase-map-widget.php';
		$widgets_manager->register( new \ASENHA\Integrations\Elementor\Ase_Map_Widget() );
	}

	/**
	 * Get key value pairs for the select element/control used so select which custom field to use as dynamic data source
	 * @param  string $return_type 	the return type of the custom fields
	 * @return array              	array of custom field name - custom field label
	 */
	public function get_control_options( $return_type = 'text', $applicable_field_types = array() ) {
		
		// Get all published custom field groups
		$cf_groups = array();
		$cf_group_fields = array();

		// We don't use WP_Query and wp_reset_postdata() at the end to prevent messing with the main query
		$args = array(
		    'post_type' => 'asenha_cfgroup',
		    'post_status' => 'publish',
		    'numberposts' => -1,
		);

	    $cfgroups = get_posts( $args );

		if ( ! empty( $cfgroups ) ) {
			foreach ( $cfgroups as $cfgroup ) {
				// setup_postdata( $cfgroup ); // Not currently needed to access ID and title
				
		        $cf_group_id = $cfgroup->ID;
		        $fields = CFG()->find_fields( array( 'group_id' => $cf_group_id ) );
		        $cf_group_fields = array();

		        if ( is_array( $fields ) && ! empty( $fields ) ) {
			        foreach ( $fields as $field ) {
			        	// We exclude repeater fields and their sub-fields
			        	if ( 'repeater'	!= $field['type'] && 0 === $field['parent_id'] && 'tab' != $field['type'] ) {
			        		if ( in_array( $field['type'], $applicable_field_types ) ) {
			        			$sub_type = 'none';
			        			switch ( $field['type'] ) {
			        				case 'text':
				        				$sub_type = isset( $field['options']['text_type'] ) ? $field['options']['text_type'] : 'any';
			        					break;
			        				case 'select':
				        				$sub_type = ( 1 == $field['options']['multiple'] ) ? 'multiple' : 'single';
			        					break;
			        				case 'file':
				        				$sub_type = ( 'file' == $field['options']['file_type'] ) ? 'any' : $field['options']['file_type'];
			        					break;
			        			}

			        			$field_key = $field['name'] . '__' . $field['type'] . '__' . $sub_type;
			        			
			        			$should_add_field_to_cf_groups = false;
			        			
			        			// Only include applicable field types and sub-types for each return types
			        			switch ( $return_type ) {
			        				case 'text':
					        			$should_add_field_to_cf_groups = true;
			        					break;

			        				case 'url':
			        					if ( 'text' != $field['type'] ) {
						        			$should_add_field_to_cf_groups = true;
			        					} elseif ( 'text' == $field['type'] 
			        						&& isset( $field['options']['text_type'] ) 
			        						&& 'url' == $field['options']['text_type'] 
			        					) {
						        			$should_add_field_to_cf_groups = true;
			        					} else {}
			        					break;

			        				case 'image':
			        					if ( 'file' == $field['type'] 
			        						&& isset( $field['options']['file_type'] ) 
			        						&& 'image' == $field['options']['file_type'] 
			        					) {
						        			$should_add_field_to_cf_groups = true;
			        					}
			        					break;

			        				case 'gallery':
					        			$should_add_field_to_cf_groups = true;
			        					break;

			        				case 'file':
			        					if ( 'file' == $field['type'] ) {
						        			$should_add_field_to_cf_groups = true;
			        					}
			        					break;

			        				case 'number':
			        					if ( 'text' == $field['type'] 
			        						&& isset( $field['options']['text_type'] ) 
			        						&& 'number' == $field['options']['text_type'] 
			        					) {
						        			$should_add_field_to_cf_groups = true;
			        					} elseif ( 'number' == $field['type'] ) {
						        			$should_add_field_to_cf_groups = true;
			        					}
			        					break;

			        				case 'color':
			        					if ( 'color' == $field['type'] ) {
						        			$should_add_field_to_cf_groups = true;
			        					}
			        					break;

			        				case 'map':
			        					if ( 'map' == $field['type'] ) {
						        			$should_add_field_to_cf_groups = true;
			        					}
			        					break;
			        			}
			        			
			        			if ( $should_add_field_to_cf_groups ) {
						        	$field_label = $field['label'];

						        	// Map fields: include provider in the label (Google Maps vs OpenStreetMap).
						        	if ( 'map' === $field['type'] ) {
						        		$provider       = isset( $field['options']['map_provider'] ) ? $field['options']['map_provider'] : 'openstreetmap';
						        		$provider_label = ( 'google_maps' === $provider ) ? 'Google Maps' : 'OpenStreetMap';
						        		$field_label    = $field['label'] . ' [map · ' . $provider_label . ']';
						        	}

						        	$cf_group_fields[ $field_key ] = $field_label;
			        			}
			        		}
				        }
			        }
		        }

		        $post_title = $cfgroup->post_title;
		        $cf_groups[] = array(
		        	'label'		=> $post_title,
		        	'options'	=> $cf_group_fields,
		        );
		    }
		    // wp_reset_postdata(); // this breaks the main query, so, we comment out
		}
		// vi( $cf_groups );
		
		return $cf_groups;
	}

	/**
	 * Build SELECT groups for map sub-fields of a CFG repeater.
	 *
	 * @since 8.9.1
	 * @param string $repeater_name Repeater field name (e.g. movie_locations).
	 * @return array Elementor SELECT groups array (empty when none).
	 */
	public function get_map_field_groups_for_repeater( $repeater_name ) {
		if ( empty( $repeater_name ) || ! is_string( $repeater_name ) || ! function_exists( 'find_cf' ) ) {
			return array();
		}

		$field = find_cf( array( 'field_name' => $repeater_name ) );

		if (
			! is_array( $field )
			|| ! isset( $field[ $repeater_name ] )
			|| 'repeater' !== $field[ $repeater_name ]['type']
		) {
			return array();
		}

		$sub_fields = find_cf( array( 'parent_id' => $field[ $repeater_name ]['id'] ) );
		if ( ! is_array( $sub_fields ) || empty( $sub_fields ) ) {
			return array();
		}

		$options = array();

		foreach ( $sub_fields as $sub_field_info ) {
			if ( ! isset( $sub_field_info['type'] ) || 'map' !== $sub_field_info['type'] ) {
				continue;
			}

			$name  = $sub_field_info['name'];
			$label = isset( $sub_field_info['label'] ) ? $sub_field_info['label'] : $name;

			$provider       = isset( $sub_field_info['options']['map_provider'] ) ? $sub_field_info['options']['map_provider'] : 'openstreetmap';
			$provider_label = ( 'google_maps' === $provider ) ? 'Google Maps' : 'OpenStreetMap';
			$label         .= ' [map · ' . $provider_label . ']';

			$field_key             = $name . '__map__none';
			$options[ $field_key ] = $label . ' (' . $name . ') | map';
		}

		if ( empty( $options ) ) {
			return array();
		}

		$repeater_label = isset( $field[ $repeater_name ]['label'] )
			? $field[ $repeater_name ]['label']
			: $repeater_name;

		return array(
			array(
				'label'   => $repeater_label . ' (' . $repeater_name . ')',
				'options' => $options,
			),
		);
	}

	/**
	 * Resolve the Loop Item / editor document post ID for ASE Map widget field groups.
	 *
	 * @since 8.9.1
	 * @return int 0 when unknown.
	 */
	public function resolve_loop_item_document_id() {
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return 0;
		}

		$plugin = \Elementor\Plugin::$instance;

		if ( isset( $plugin->documents ) ) {
			$document = $plugin->documents->get_current();
			if ( $document && method_exists( $document, 'get_main_id' ) ) {
				$main_id = absint( $document->get_main_id() );
				if ( $main_id > 0 ) {
					return $main_id;
				}
			}
		}

		if ( isset( $plugin->editor ) && method_exists( $plugin->editor, 'get_post_id' ) ) {
			$editor_id = absint( $plugin->editor->get_post_id() );
			if ( $editor_id > 0 ) {
				return $editor_id;
			}
		}

		return 0;
	}

	/**
	 * Build ASE Map widget Field Name groups (repeater map sub-fields + top-level maps).
	 *
	 * @since 8.9.1
	 * @param int|null    $post_id           Loop Item document ID (optional).
	 * @param string|null $selected_repeater Repeater field name (optional; falls back to post meta).
	 * @return array{
	 *     groups: array,
	 *     selected_repeater: string
	 * }
	 */
	public function get_ase_map_widget_field_groups( $post_id = null, $selected_repeater = null ) {
		$top_level = $this->get_control_options( 'map', array( 'map' ) );
		if ( ! is_array( $top_level ) ) {
			$top_level = array();
		}

		$post_id = null !== $post_id ? absint( $post_id ) : $this->resolve_loop_item_document_id();

		if ( empty( $selected_repeater ) || ! is_string( $selected_repeater ) ) {
			$selected_repeater = '';
			if ( $post_id > 0 ) {
				$selected_repeater = get_post_meta( $post_id, 'asenha_loop_repeater_field', true );
				$selected_repeater = is_string( $selected_repeater ) ? $selected_repeater : '';
			}
		} else {
			$selected_repeater = sanitize_text_field( $selected_repeater );
		}

		$repeater_groups = array();
		if ( ! empty( $selected_repeater ) ) {
			$repeater_groups = $this->get_map_field_groups_for_repeater( $selected_repeater );
		}

		$groups = ! empty( $repeater_groups )
			? array_merge( $repeater_groups, $top_level )
			: $top_level;

		return array(
			'groups'            => $groups,
			'selected_repeater' => $selected_repeater,
		);
	}

}

$ase_elementor_integration = new Ase_Elementor_Integration();