<?php

namespace Ase\Integrations\Breakdance;

use Breakdance\DynamicData\DynamicDataController;
use Breakdance\DynamicData\ImageData;
use Breakdance\DynamicData\LoopController;
use function Breakdance\isRequestFromBuilderDynamicDataGet;
use function Breakdance\isRequestFromBuilderSsr;
use DateTimeZone;

class Breakdance_Ase_Field {

    /**
     * @var Post ID
     */
    public int $post_id;

    /**
     * @var ASE Field
     */
    public array $field;

    /**
     * @var Output type in Breakdance: string, url, image, video
     */
    public string $bd_output_type;

    /**
     * @param AseString $field
     */
    public function __construct( $post_id, $field, $bd_output_type ) {
        $this->post_id = $post_id;
        $this->field = $field;
        $this->bd_output_type = $bd_output_type;
    }
    
    /**
     * Get raw field value for top-level fields and repeater sub-fields (LoopController-aware).
     *
     * Does not apply formatting. Returns null when the value is unavailable.
     *
     * On Breakdance builder SSR / Dynamic Data Get (Global Block alone, no active loop),
     * falls back to the first repeater row from the last-previewed / sample post.
     *
     * @return mixed
     */
    public function get_raw_value() {
        if ( ! empty( $this->field['parent_name'] ) ) {
            $parent_field      = $this->field['parent_name'];
            $parent_field_data = $this->get_repeater_parent_field_data( $parent_field );

            if ( empty( $parent_field_data ) || empty( $parent_field_data['id'] ) || empty( $parent_field_data['name'] ) ) {
                return null;
            }

            $breakdance_loop = LoopController::getInstance( $parent_field_data['id'] . '_' . $parent_field_data['name'] );

            if ( ! isset( $breakdance_loop->field['field'] ) || ! isset( $breakdance_loop->field['index'] ) ) {
                // Global Block / builder has no Repeater Field loop — sample first row for preview.
                if ( $this->is_builder_preview_request() ) {
                    return $this->get_builder_first_repeater_row_value();
                }

                return null;
            }

            $loop_field = $breakdance_loop->field['field'];
            $loop_index = $breakdance_loop->field['index'];

            if ( $parent_field !== $loop_field['name'] ) {
                return null;
            }

            $parent_field_value = get_cf( $this->field['parent_name'], 'raw' );

            if ( ! is_array( $parent_field_value ) || ! isset( $parent_field_value[ $loop_index ] ) ) {
                return null;
            }

            $row = $parent_field_value[ $loop_index ];

            if ( ! is_array( $row ) || ! array_key_exists( $this->field['name'], $row ) ) {
                return null;
            }

            return $row[ $this->field['name'] ];
        }

        if ( $this->is_builder_preview_request() ) {
            $preview_post_id = $this->get_builder_preview_post_id();
            if ( $preview_post_id > 0 ) {
                return get_cf( $this->field['name'], 'raw', $preview_post_id );
            }
        }

        return get_cf( $this->field['name'], 'raw' );
    }

    /**
     * Whether the current request is Breakdance builder SSR or Dynamic Data Get.
     *
     * @return bool
     */
    private function is_builder_preview_request() {
        return isRequestFromBuilderSsr() || isRequestFromBuilderDynamicDataGet();
    }

    /**
     * Resolve content post ID for Global Block / template builder preview.
     *
     * Prefers `_breakdance_template_last_previewed_item` on Breakdance documents,
     * otherwise returns a normal content post ID from request/context candidates.
     *
     * @return int
     */
    private function get_builder_preview_post_id() {
        $candidates = array();

        if ( $this->post_id > 0 ) {
            $candidates[] = $this->post_id;
        }

        $current_id = (int) get_the_ID();
        if ( $current_id > 0 ) {
            $candidates[] = $current_id;
        }

        $request_id = filter_input( INPUT_POST, 'id', FILTER_VALIDATE_INT );
        if ( is_int( $request_id ) && $request_id > 0 ) {
            $candidates[] = $request_id;
        }

        $triggering_document = filter_input( INPUT_POST, 'triggeringDocument', FILTER_VALIDATE_INT );
        if ( is_int( $triggering_document ) && $triggering_document > 0 ) {
            $candidates[] = $triggering_document;
        }

        $candidates = array_values( array_unique( array_filter( array_map( 'absint', $candidates ) ) ) );

        foreach ( $candidates as $pid ) {
            $post_type = get_post_type( $pid );
            if ( ! is_string( $post_type ) || '' === $post_type ) {
                continue;
            }

            if ( $this->is_breakdance_document_post_type( $post_type ) ) {
                $from_meta = $this->resolve_last_previewed_post_id( $pid );
                if ( $from_meta > 0 ) {
                    return $from_meta;
                }
                continue;
            }

            return (int) $pid;
        }

        return 0;
    }

    /**
     * Whether a post type is a Breakdance/Oxygen builder document (not content).
     *
     * @param string $post_type Post type slug.
     * @return bool
     */
    private function is_breakdance_document_post_type( $post_type ) {
        $post_type = (string) $post_type;

        if ( defined( 'BREAKDANCE_DYNAMIC_DATA_PREVIEW_POST_TYPES' )
            && in_array( $post_type, (array) BREAKDANCE_DYNAMIC_DATA_PREVIEW_POST_TYPES, true )
        ) {
            return true;
        }

        if ( defined( 'BREAKDANCE_ALL_TEMPLATE_POST_TYPES' )
            && in_array( $post_type, (array) BREAKDANCE_ALL_TEMPLATE_POST_TYPES, true )
        ) {
            return true;
        }

        return in_array(
            $post_type,
            array(
                'breakdance_block',
                'breakdance_template',
                'breakdance_header',
                'breakdance_footer',
                'breakdance_popup',
                'breakdance_part',
                'breakdance_acf_block',
                'oxygen_block',
                'oxygen_template',
                'oxygen_header',
                'oxygen_footer',
                'oxygen_part',
            ),
            true
        );
    }

    /**
     * Resolve post ID from Breakdance last-previewed item meta on a document.
     *
     * @param int $document_id Global Block / template post ID.
     * @return int
     */
    private function resolve_last_previewed_post_id( $document_id ) {
        $document_id = (int) $document_id;
        if ( $document_id <= 0 ) {
            return 0;
        }

        $meta = get_post_meta( $document_id, '_breakdance_template_last_previewed_item', true );

        if ( is_string( $meta ) && '' !== $meta ) {
            $decoded = json_decode( $meta, true );
            if ( is_array( $decoded ) ) {
                $meta = $decoded;
            }
        }

        if ( ! is_array( $meta ) || empty( $meta['url'] ) || ! is_string( $meta['url'] ) ) {
            return 0;
        }

        $pid = (int) url_to_postid( $meta['url'] );

        return $pid > 0 ? $pid : 0;
    }

    /**
     * Resolve repeater parent field definition for LoopController keying.
     *
     * Prefers get_field_info( name, post_id ). Falls back to find_fields by name and picks
     * type === repeater (CFG field IDs can collide across groups).
     *
     * @param string $parent_field_name Parent repeater field name.
     * @return array<string, mixed>
     */
    private function get_repeater_parent_field_data( $parent_field_name ) {
        $parent_field_name = (string) $parent_field_name;

        if ( '' === $parent_field_name || ! function_exists( 'CFG' ) ) {
            return array();
        }

        $parent_field_data = array();

        $info_post_id = $this->post_id > 0 ? $this->post_id : 0;
        if ( $info_post_id <= 0 && $this->is_builder_preview_request() ) {
            $info_post_id = $this->get_builder_preview_post_id();
        }

        if ( $info_post_id > 0 ) {
            $info = CFG()->get_field_info( $parent_field_name, $info_post_id );
            if ( is_array( $info ) && ! empty( $info['name'] ) && ! empty( $info['id'] ) ) {
                $parent_field_data = $info;
            }
        }

        if ( empty( $parent_field_data ) ) {
            $candidates = CFG()->find_fields( array( 'field_name' => $parent_field_name ) );
            if ( is_array( $candidates ) ) {
                foreach ( $candidates as $candidate ) {
                    if (
                        is_array( $candidate )
                        && isset( $candidate['type'] )
                        && 'repeater' === $candidate['type']
                        && isset( $candidate['name'] )
                        && $parent_field_name === (string) $candidate['name']
                    ) {
                        $parent_field_data = $candidate;
                        break;
                    }
                }
            }
        }

        return is_array( $parent_field_data ) ? $parent_field_data : array();
    }

    /**
     * First repeater-row sub-field value for Breakdance builder preview (SSR + DD Get).
     *
     * Tries last-previewed / context posts, then posts from the field's for_post_types.
     *
     * @return mixed|null
     */
    private function get_builder_first_repeater_row_value() {
        $parent_name = isset( $this->field['parent_name'] ) ? (string) $this->field['parent_name'] : '';
        $field_name  = isset( $this->field['name'] ) ? (string) $this->field['name'] : '';

        if ( '' === $parent_name || '' === $field_name || ! function_exists( 'get_cf' ) ) {
            return null;
        }

        $post_ids = array();

        $preview_post_id = $this->get_builder_preview_post_id();
        if ( $preview_post_id > 0 ) {
            $post_ids[] = $preview_post_id;
        }

        if ( $this->post_id > 0 ) {
            $post_ids[] = $this->post_id;
        }

        $current_id = (int) get_the_ID();
        if ( $current_id > 0 ) {
            $post_ids[] = $current_id;
        }

        $triggering_document = filter_input( INPUT_POST, 'triggeringDocument', FILTER_VALIDATE_INT );
        if ( is_int( $triggering_document ) && $triggering_document > 0 ) {
            $post_ids[] = $triggering_document;
        }

        $post_ids = array_values( array_unique( array_filter( array_map( 'absint', $post_ids ) ) ) );

        foreach ( $post_ids as $pid ) {
            if ( $this->is_breakdance_document_post_type( (string) get_post_type( $pid ) ) ) {
                continue;
            }

            $value = $this->get_first_repeater_sub_field_value_for_post( $pid, $parent_name, $field_name );
            if ( null !== $value ) {
                return $value;
            }
        }

        $post_types = array( 'any' );
        if ( ! empty( $this->field['for_post_types'] ) && is_array( $this->field['for_post_types'] ) ) {
            $post_types = array_values( array_filter( $this->field['for_post_types'] ) );
            if ( empty( $post_types ) ) {
                $post_types = array( 'any' );
            }
        }

        $query = new \WP_Query(
            array(
                'post_type'              => $post_types,
                'post_status'            => 'publish',
                'posts_per_page'         => 15,
                'fields'                 => 'ids',
                'no_found_rows'          => true,
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
                'orderby'                => 'date',
                'order'                  => 'DESC',
            )
        );

        if ( empty( $query->posts ) || ! is_array( $query->posts ) ) {
            return null;
        }

        foreach ( $query->posts as $pid ) {
            $pid = (int) $pid;
            if ( $pid <= 0 || in_array( $pid, $post_ids, true ) ) {
                continue;
            }

            $value = $this->get_first_repeater_sub_field_value_for_post( $pid, $parent_name, $field_name );
            if ( null !== $value ) {
                return $value;
            }
        }

        return null;
    }

    /**
     * Load repeater rows for builder preview when LoopController is inactive.
     *
     * @param string $parent_name Repeater field name.
     * @return array<int, array<string, mixed>>
     */
    private function get_builder_preview_repeater_rows( $parent_name ) {
        $parent_name = (string) $parent_name;
        if ( '' === $parent_name || ! function_exists( 'get_cf' ) ) {
            return array();
        }

        $post_ids = array();

        $preview_post_id = $this->get_builder_preview_post_id();
        if ( $preview_post_id > 0 ) {
            $post_ids[] = $preview_post_id;
        }

        $post_ids = array_values( array_unique( array_filter( array_map( 'absint', $post_ids ) ) ) );

        foreach ( $post_ids as $pid ) {
            $rows = get_cf( $parent_name, 'raw', $pid );
            if ( is_array( $rows ) && isset( $rows[0] ) && is_array( $rows[0] ) ) {
                return $rows;
            }
        }

        $post_types = array( 'any' );
        if ( ! empty( $this->field['for_post_types'] ) && is_array( $this->field['for_post_types'] ) ) {
            $post_types = array_values( array_filter( $this->field['for_post_types'] ) );
            if ( empty( $post_types ) ) {
                $post_types = array( 'any' );
            }
        }

        $query = new \WP_Query(
            array(
                'post_type'              => $post_types,
                'post_status'            => 'publish',
                'posts_per_page'         => 15,
                'fields'                 => 'ids',
                'no_found_rows'          => true,
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
                'orderby'                => 'date',
                'order'                  => 'DESC',
            )
        );

        if ( empty( $query->posts ) || ! is_array( $query->posts ) ) {
            return array();
        }

        foreach ( $query->posts as $pid ) {
            $pid = (int) $pid;
            if ( $pid <= 0 || in_array( $pid, $post_ids, true ) ) {
                continue;
            }

            $rows = get_cf( $parent_name, 'raw', $pid );
            if ( is_array( $rows ) && isset( $rows[0] ) && is_array( $rows[0] ) ) {
                return $rows;
            }
        }

        return array();
    }

    /**
     * Read first repeater row sub-field value for a post, when lat/lng present for maps.
     *
     * @param int    $post_id      Post ID.
     * @param string $parent_name  Repeater field name.
     * @param string $field_name   Sub-field name.
     * @return mixed|null
     */
    private function get_first_repeater_sub_field_value_for_post( $post_id, $parent_name, $field_name ) {
        $rows = get_cf( $parent_name, 'raw', $post_id );

        if ( ! is_array( $rows ) || ! isset( $rows[0] ) || ! is_array( $rows[0] ) ) {
            return null;
        }

        if ( ! array_key_exists( $field_name, $rows[0] ) ) {
            return null;
        }

        $value = $rows[0][ $field_name ];

        // Map fields: require coordinates so ASE Map SSR can embed.
        if ( isset( $this->field['type'] ) && 'map' === $this->field['type'] ) {
            if ( ! is_array( $value ) || empty( $value['latitude'] ) || empty( $value['longitude'] ) ) {
                return null;
            }
        }

        return $value;
    }

    /**
     * Get value for regular fields and repeater sub-fields
     */
    public function get_field_value() {
    	
    	// Let's layout the foundation here. 
    	// Check if there's a parent field and whether the returned value should be a regular field, or a repeater's sub-field
    	
    	if ( ! empty( $this->field['parent_name'] ) ) {
    		// Field is a sub-field
    		$should_return_sub_field_value = true;
	        $parent_field = $this->field['parent_name'];
	        $parent_field_data = $this->get_repeater_parent_field_data( $parent_field );

	        $parent_field_value = '';
	        $sub_field_value = '';
	        $loopIndex = 0;
	        $sub_field_value_placeholder = 'Placeholder for <span style="font-weight:600;">' . $this->field['label'] . '</span> field.';

	        if ( ! empty( $parent_field_data ) && ! empty( $parent_field_data['id'] ) && ! empty( $parent_field_data['name'] ) ) {
	            $breakdanceLoop = LoopController::getInstance( $parent_field_data['id'] . '_' . $parent_field_data['name'] );

	            if ( isset( $breakdanceLoop->field['field'] ) && isset( $breakdanceLoop->field['index'] ) ) {
	                $loopField = $breakdanceLoop->field['field'];
	                $loopIndex = $breakdanceLoop->field['index'];

	                if ( $parent_field == $loopField['name'] ) {
	                    $parent_field_value = get_cf( $this->field['parent_name'], 'raw' );
	                }
	            }
	        }

	        // Global Block / builder preview: no active loop — seed first row from last-previewed post.
	        if ( empty( $parent_field_value ) && $this->is_builder_preview_request() ) {
	            $preview_rows = $this->get_builder_preview_repeater_rows( $parent_field );
	            if ( ! empty( $preview_rows ) ) {
	                $parent_field_value = $preview_rows;
	                $loopIndex         = 0;
	            }
	        }
    	} else {
    		// Field is a regular field
    		$should_return_sub_field_value = false;
    		$cf_post_id                    = false;

    		if ( $this->is_builder_preview_request() ) {
    			$preview_post_id = $this->get_builder_preview_post_id();
    			if ( $preview_post_id > 0 ) {
    				$cf_post_id = $preview_post_id;
    			}
    		}

    		if ( $cf_post_id ) {
    			$raw_value = get_cf( $this->field['name'], 'raw', $cf_post_id );
    			$value     = get_cf( $this->field['name'], 'default', $cf_post_id );
    		} else {
    			$raw_value = get_cf( $this->field['name'], 'raw' );
    			$value     = get_cf( $this->field['name'] );
    		}
    	}
    	
    	// Common variables
    	$class_name = str_replace( '_', '-', $this->field['name'] );

    	// ============================================================
    	// For fields with string return type in Breakdance
    	// ============================================================

    	if ( 'string' == $this->bd_output_type ) {
    		$field_options = $this->field['options'];

    		switch ( $this->field['type'] ) {

	        	case 'text':
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field = CFG()->get_field_info( $this->field['name'] );
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']];
		        			if ( ! empty( $sub_field_value ) ) {
				        		switch ( $sub_field['options']['text_type'] ) {
				        			case 'url':
				        				if ( false !== strpos( $sub_field_value, 'x.com' ) ) {
				        					$sub_field_value = str_replace( 'x.com', 'twitter.com', $sub_field_value );
				        				}
				        				return (string) wp_oembed_get( $sub_field_value );
				        				break;

				        			case 'email':
				        				return (string) '<a href="mailto:' . $sub_field_value . '">' . $sub_field_value . '</a>';
				        				break;

				        			case 'phone':
				        				return (string) '<a href="tel:' . $sub_field_value . '">' . $sub_field_value . '</a>';
				        				break;

				        			case 'shortcode':
				        				return (string) do_shortcode( $sub_field_value );
				        				break;
				        				
				        			default:
				        				return (string) $sub_field_value;
			        			}
		        			} else {
		        				return (string) '';
		        			}
		        		} else {
				            return (string) $sub_field_value_placeholder;
		        		}
    	    		} else {
		        		// Empty/null values must not reach wp_oembed_get() (PHP 8.1+ deprecation → Breakdance 500).
		        		if ( empty( $value ) ) {
		        			return (string) '';
		        		}

		        		switch ( $this->field['options']['text_type'] ) {
		        			case 'url':
		        				if ( false !== strpos( $value, 'x.com' ) ) {
		        					$value = str_replace( 'x.com', 'twitter.com', $value );
		        				}
		        				return (string) wp_oembed_get( $value );
		        				break;

		        			case 'email':
		        				return (string) '<a href="mailto:' . $value . '">' . $value . '</a>';
		        				break;

		        			case 'phone':
		        				return (string) '<a href="tel:' . $value . '">' . $value . '</a>';
		        				break;

		        			case 'shortcode':
		        				return (string) do_shortcode( $value );
		        				break;

		        			default:
		        				return (string) $value;
		        		}
	        		}	        	
	        		break;
	        		
	        	case 'textarea':
	        	case 'wysiwyg':
	        	case 'number':
	        	case 'color':
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			if ( 'wysiwyg' == $this->field['type'] ) {
			                    $sub_field_value = wpautop( $parent_field_value[$loopIndex][$this->field['name']] );
		        			} else {
			                    $sub_field_value = $parent_field_value[$loopIndex][$this->field['name']];
		        			}
		                    return (string) ( ! empty( $sub_field_value ) ) ? $sub_field_value : '';
		    				break;
		        		} else {
				            return (string) $sub_field_value_placeholder;		        				
		        		}	        			
	        		} else {
	        			if ( 'wysiwyg' == $this->field['type'] ) {
	        				if ( is_string( $value ) ) {
			        			return (string) wpautop( $value );
	        				} else {
	        					return (string) '';
	        				}
	        			} else {
		        			return (string) $value;
	        			}
	        		}
	        		break;

	        	case 'date':
	        		$frontend_display_format = isset( $field_options['frontend_display_format'] ) ? $field_options['frontend_display_format'] : 'F j, Y';
	        		
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
			                    $sub_field_value = date( $frontend_display_format, strtotime( (string) $parent_field_value[$loopIndex][$this->field['name']] ) );
			                    return (string) ( ! empty( $sub_field_value ) ) ? $sub_field_value : '';
			        		} else {
					            return (string) $sub_field_value_placeholder;	        			
			        		}
	        		} else {
	        			if ( ! empty( $value ) ) {
		                    return (string) date( $frontend_display_format, strtotime( (string) $value ) );        				
	        			} else {
	        				return (string) '';	
	        			}
	        		}
		        	break;

	        	case 'time':
	        		if ( $should_return_sub_field_value ) {
		        		$frontend_display_format = isset( $this->field['options']['frontend_display_format'] ) ? $this->field['options']['frontend_display_format'] : 'G:i';
		        		if ( ! empty( $parent_field_value ) ) {
		        				$raw_sub_field_value = (string) $parent_field_value[$loopIndex][$this->field['name']];
		        				$sub_field_value = get_cf_time( $raw_sub_field_value, $frontend_display_format );
			                    return (string) ( ! empty( $sub_field_value ) ) ? $sub_field_value : '';
			        		} else {
					            return (string) $sub_field_value_placeholder;
			        		}
	        		} else {
	        			if ( ! empty( $value ) ) {
		                    return (string) $value; // Already formatted
	        			} else {
	        				return (string) '';	
	        			}
	        		}
		        	break;

	        	case 'datetime':
		            $datetime_output_format = get_cf_datetime_output_format( $field_options );
		            $timezone_object = new DateTimeZone( 'UTC' );
	        		
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
			                    $sub_field_value = wp_date( $datetime_output_format, strtotime( (string) $parent_field_value[$loopIndex][$this->field['name']] ), $timezone_object );
			                    return (string) ( ! empty( $sub_field_value ) ) ? $sub_field_value : '';
			        		} else {
					            return (string) $sub_field_value_placeholder;	        			
			        		}
	        		} else {
	        			// Let's use the raw cf_value to ensure it works with strtotime()
	        			if ( ! empty( $raw_value ) ) {
		                    return (string) wp_date( $datetime_output_format, strtotime( (string) $raw_value ), $timezone_object );
	        			} else {
	        				return (string) '';	
	        			}
	        		}
		        	break;
		        	
        		case 'hyperlink':
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']]; // array of url, text, target
		        			return (string) get_cf_hyperlink( $sub_field_value );
		        		} else {
				            return (string) $sub_field_value_placeholder;	        			
		        		}	        			
	        			break;
    	    		} else {
		        		if ( isset( $this->field['options']['format'] ) ) {
		        			switch ( $this->field['options']['format'] ) {
		        				case 'html':
				        			return (string) $value;
				        			break;
				        			
				        		case 'php':
				        			return (string) get_cf_hyperlink( $value );
				        			break;
		        			}
		        		}
	        		}
        		break;

        		case 'true_false':
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']];

			        		if ( '1' === $sub_field_value ) {
			        			return (string) 'Yes';
			        		} else {
			        			return (string) 'No';
			        		}
		        		} else {
				            return (string) $sub_field_value_placeholder;	        			
		        		}
    	    		} else {
		        		if ( true === $value ) {
		        			return (string) 'Yes';
		        		} else {
		        			return (string) 'No';
		        		}
	        		}
        		break;


        		case 'radio':
        		case 'select':
        		case 'checkbox':
	        		$new_value = array();
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
							$sub_field = CFG()->get_field_info( $this->field['name'] );
							$sub_field_choices = $sub_field['options']['choices'];
							$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']]; // indexed array of values

			        		if ( is_array( $sub_field_value ) && ! empty( $sub_field_value ) ) {
			        			foreach ( $sub_field_value as $value ) {
			        				foreach ( $sub_field_choices as $choice_value => $choice_label ) {
			        					if ( $choice_value == $value ) {
					        				$new_value[] = $choice_label;		        					
			        					}
			        				}
			        			}
			        			return (string) implode( ', ', $new_value );
			        		} else {
			        			return (string) '';
			        		}
		        		} else {
				            return (string) $sub_field_value_placeholder;
		        		}
    	    		} else {
		        		if ( is_array( $value ) && ! empty( $value ) ) {
		        			foreach ( $value as $key => $val ) {
		        				$new_value[] = $val;
		        			}
		        			return (string) implode( ', ', $new_value );
		        		} else {
		        			return (string) $value;
		        		}
	        		}
        		break;

        		case 'file':
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field = CFG()->get_field_info( $this->field['name'] );
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']];
		        			if ( ! empty( $sub_field_value ) && is_numeric( $sub_field_value ) ) {
		        				$file_url = wp_get_attachment_url( $sub_field_value );
				        		switch ( $sub_field['options']['file_type'] ) {
				        			case 'image':
				        				return (string) get_cf_image_view( $sub_field_value, 'medium_large', $class_name );
				        				break;
				        			case 'video':
				        				return (string) get_cf_video_player( $file_url );
				        				break;
				        			case 'audio':
				        				return (string) get_cf_audio_player( $file_url );
					                    // return (string) do_shortcode( '[audio src="' . $file_url . '"]' );
				        				break;
				        			case 'pdf':
				        				return (string) get_cf_pdf_viewer( $file_url );
				        				break;
				        			case 'file': // File type is 'Any'
				        				return (string) get_cf_file_link( $file_url );
				        				break;
			        			}
		        			} else {
		        				return (string) '';
		        			}
		        		} else {
				            return (string) $sub_field_value_placeholder;
		        		}
    	    		} else {
		        		switch ( $this->field['options']['file_type'] ) {
		        			case 'image':
					        	return (string) get_cf( $this->field['name'], 'image_view__medium_large' );
		        				break;
		        			case 'video':
					        	return (string) get_cf( $this->field['name'], 'video_player' );
		        				break;
		        			case 'audio':
					        	return (string) get_cf( $this->field['name'], 'audio_player' );
		        				break;
		        			case 'pdf':
					        	return (string) get_cf( $this->field['name'], 'pdf_viewer' );
		        				break;
		        			case 'file': // File type is 'Any'
		        				return (string) get_cf( $this->field['name'], 'file_link' );
		        				break;
		        		}
	        		}
        		break;
        		
        		case 'gallery':
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']]; // Comma-separated attachment IDs
		        			$sub_field_value = explode( ',', $sub_field_value );
		        			return (string) get_cf_gallery_justified( $sub_field_value, 'medium' );
		        		} else {
				            return (string) $sub_field_value_placeholder;
		        		}	        			
	        		} else {
	        			return (string) get_cf( $this->field['name'], 'gallery_justified__medium' );
	        		}
        			break;

        		case 'relationship':
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']];
		        			return (string) cf_titles_only_v( $class_name, 'cf_titles_only_v__ul', $sub_field_value );
		        		} else {
				            return (string) $sub_field_value_placeholder;
		        		}
    	    		} else {
						return (string) get_cf_related_to( $this->field['name'], 'cf_titles_only_v__ul' );
	        		}
        		break;

        		case 'term':
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']];
		        			return (string) get_cf_terms( $sub_field_value, 'names_archive_links' );
		        		} else {
				            return (string) $sub_field_value_placeholder;
		        		}
    	    		} else {
    	    			return (string) get_cf( $this->field['name'], 'names_archive_links' );
	        		}
        		break;

        		case 'user':
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']];
		        			return get_cf_users( $sub_field_value, 'display_names' );
		        		} else {
				            return (string) $sub_field_value_placeholder;
		        		}
    	    		} else {
    	    			return (string) get_cf( $this->field['name'], 'display_names' );
	        		}
        		break;

    		}
    	}

    	// ============================================================
    	// For fields with URL return type in Breakdance
    	// ============================================================

    	if ( 'url' == $this->bd_output_type ) {
    		switch ( $this->field['type'] ) {

	        	case 'text':
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']];
							if ( filter_var( $sub_field_value, FILTER_VALIDATE_URL ) && false !== strpos( $sub_field_value, 'http' ) ) {
			        			return (string) $sub_field_value;
			        		} else {
			        			return (string) '?';
			        		}
		        		} else {
				            return (string) $sub_field_value_placeholder;
		        		}
    	    		} else {
			    		$raw_value = get_cf( $this->field['name'], 'raw' );
						if ( filter_var( $raw_value, FILTER_VALIDATE_URL ) && false !== strpos( $raw_value, 'http' ) ) {
							return (string) $raw_value;
						} else {
							return (string) get_the_permalink();
						}
	        		}
	        		break;

	        	case 'hyperlink':
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']];
			        		if ( is_array( $sub_field_value ) && ! empty( $sub_field_value ) && isset( $sub_field_value['url'] ) ) {
			        			return (string) $sub_field_value['url'];
			        		}
		        		} else {
				            return (string) $sub_field_value_placeholder;
		        		}
    	    		} else {
			    		$raw_value = get_cf( $this->field['name'], 'raw' );
		        		if ( is_array( $raw_value ) && ! empty( $raw_value ) && isset( $raw_value['url'] ) ) {
		        			return (string) $raw_value['url'];
		        		}
	        		}
	        		break;

	        	case 'file':
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']];
			        		return (string) wp_get_attachment_url( $sub_field_value );
		        		} else {
				            return (string) $sub_field_value_placeholder;
		        		}
    	    		} else {
			    		$raw_value = get_cf( $this->field['name'], 'raw' );
		        		if ( ! empty( $raw_value ) && is_numeric( $raw_value ) ) {
			        		return (string) wp_get_attachment_url( $raw_value );
		        		}
	        		}
	        		break;

	        	case 'relationship':
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']];
							if ( is_array( $sub_field_value ) && count( $sub_field_value ) > 0 ) {
								$first_related_item_id = $sub_field_value[0];
								return (string) get_the_permalink( $first_related_item_id );
							}
		        		} else {
				            return (string) $sub_field_value_placeholder;
		        		}
    	    		} else {
			    		$raw_value = get_cf( $this->field['name'], 'raw' );
						if ( is_array( $raw_value ) && count( $raw_value ) > 0 ) {
							$first_related_item_id = $raw_value[0];
							return (string) get_the_permalink( $first_related_item_id );
						}
	        		}
	        		break;

	        	case 'map':
	        		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field_value = $parent_field_value[ $loopIndex ][ $this->field['name'] ];
		        			$field_options   = isset( $this->field['options'] ) && is_array( $this->field['options'] )
		        				? $this->field['options']
		        				: array();
		        			$url = function_exists( 'get_cf_map_url' )
		        				? get_cf_map_url( is_array( $sub_field_value ) ? $sub_field_value : array(), $field_options )
		        				: '';
		        			return (string) ( $url ? $url : '' );
		        		} else {
				            return (string) '';
		        		}
    	    		} else {
			    		$raw_value     = get_cf( $this->field['name'], 'raw' );
		        		$field_options = isset( $this->field['options'] ) && is_array( $this->field['options'] )
		        			? $this->field['options']
		        			: array();
		        		$url = function_exists( 'get_cf_map_url' )
		        			? get_cf_map_url( is_array( $raw_value ) ? $raw_value : array(), $field_options )
		        			: '';
		        		return (string) ( $url ? $url : '' );
	        		}
	        		break;
	        		
	        }
	    }

    	// ============================================================
    	// For fields with image return type in Breakdance
    	// ============================================================

    	if ( 'image' == $this->bd_output_type ) {
			// Return attachment ID
    		if ( $should_return_sub_field_value ) {
        		if ( ! empty( $parent_field_value ) ) {
        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']];
        			return $sub_field_value;
        		} else {
        			return (string) 0;
        		}
    		} else {
    			return get_cf( $this->field['name'], 'raw' );
    		}
	    }

    	// ============================================================
    	// For fields with gallery return type in Breakdance
    	// ============================================================

    	if ( 'gallery' == $this->bd_output_type ) {
			// Return attachment ID
    		if ( $should_return_sub_field_value ) {
        		if ( ! empty( $parent_field_value ) ) {
        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']];
        			return $sub_field_value;
        		} else {
        			return (string) 0;
        		}
    		} else {
    			return get_cf( $this->field['name'], 'raw' );
    		}
	    }

    	// ============================================================
    	// For fields with video return type in Breakdance
    	// ============================================================

    	if ( 'video' == $this->bd_output_type ) {
    		// Return URL to video online or local file
    		switch ( $this->field['type'] ) {

	        	case 'text':
		    		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']]; // URL
		        			return (string) $sub_field_value;
		        		} else {
		        			return (string) '';
		        		}
		        	} else {
		    			return (string) get_cf( $this->field['name'], 'raw' );
		        	}
	        		break;

	        	case 'hyperlink':
		    		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']]; // array of url, text, target
		        			if ( is_array( $sub_field_value ) && ! empty( $sub_field_value ) && isset( $sub_field_value['url'] ) ) {
		        				return (string) $sub_field_value['url'];
		        			}
		        		} else {
		        			return (string) '';
		        		}
		        	} else {
		    			$raw_value = get_cf( $this->field['name'], 'raw' );
		    			if ( isset( $raw_value['url'] ) 
		    				&& filter_var( $raw_value['url'], FILTER_VALIDATE_URL ) 
		    				&& false !== strpos( $raw_value['url'], 'http' ) 
		    			) {
		    				return (string) $raw_value['url'];
		    			}
		        	}
	        		break;

	        	case 'file':
		    		if ( $should_return_sub_field_value ) {
		        		if ( ! empty( $parent_field_value ) ) {
		        			$sub_field_value = $parent_field_value[$loopIndex][$this->field['name']]; // attachment ID
		        			return wp_get_attachment_url( $sub_field_value );
		        		} else {
		        			return (string) '';
		        		}
		        	} else {
				    	// Use wp_get_attachment_url() — not wp_prepare_attachment_for_js() —
				    	// so unregistered parent CPTs (e.g. acf-movie) do not trigger
				    	// map_meta_cap _doing_it_wrong → Breakdance Ajax 500.
				    	$attachment_id = get_cf( $this->field['name'], 'raw' );
				    	if ( empty( $attachment_id ) || ! is_numeric( $attachment_id ) ) {
				    		return (string) '';
				    	}
				    	$url = wp_get_attachment_url( $attachment_id );
				    	return (string) ( $url ? $url : '' );
		        	}
	        		break;
	        		
	        }
	    }

    }

    /**
     * Build Breakdance ImageData from an attachment ID without fatalling when the
     * attachment parent CPT is unregistered (e.g. leftover mb-note posts).
     *
     * Breakdance Whoops converts map_meta_cap _doing_it_wrong notices (from
     * wp_prepare_attachment_for_js capability checks) into Ajax 500s.
     *
     * @param int|string $attachment_id Attachment ID.
     * @return ImageData
     */
    public static function image_data_from_attachment_id( $attachment_id ): ImageData {
        $attachment_id = (int) $attachment_id;

        if ( $attachment_id <= 0 || 'attachment' !== get_post_type( $attachment_id ) ) {
            return ImageData::emptyImage();
        }

        $needs_suppress = false;
        $attachment     = get_post( $attachment_id );

        if ( $attachment && ! empty( $attachment->post_parent ) ) {
            $parent_type = get_post_type( $attachment->post_parent );
            if ( is_string( $parent_type ) && '' !== $parent_type && ! post_type_exists( $parent_type ) ) {
                $needs_suppress = true;
            }
        }

        $callback = null;
        if ( $needs_suppress ) {
            $callback = static function ( $trigger, $function_name ) {
                if ( 'map_meta_cap' === $function_name ) {
                    return false;
                }
                return $trigger;
            };
            add_filter( 'doing_it_wrong_trigger_error', $callback, 10, 2 );
        }

        $image = ImageData::fromAttachmentId( $attachment_id );

        if ( null !== $callback ) {
            remove_filter( 'doing_it_wrong_trigger_error', $callback, 10 );
        }

        return $image;
    }

}