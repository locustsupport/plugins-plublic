<?php

use Ase\Integrations\Breakdance\Breakdance_Ase_Field;
use Breakdance\DynamicData\StringField;
use Breakdance\DynamicData\StringData;

/**
 * Breakdance Dynamic Data field for ASE CFG map fields.
 *
 * Return types include string (Text / Google Map Address) and google_map (ACF parity).
 *
 * @since 8.9.1
 */
class Ase_Map extends StringField {

	/**
	 * @var array ASE CFG field definition.
	 */
	public array $field;

	/**
	 * @param array $field ASE CFG field.
	 */
	public function __construct( $field ) {
		$this->field = $field;
	}

	/**
	 * @inheritDoc
	 */
	public function label() {
		$label    = isset( $this->field['label'] ) ? (string) $this->field['label'] : '';
		$provider = isset( $this->field['options']['map_provider'] )
			? (string) $this->field['options']['map_provider']
			: 'openstreetmap';
		$provider_label = ( 'google_maps' === $provider )
			? __( 'Google Maps', 'admin-site-enhancements' )
			: __( 'OpenStreetMap', 'admin-site-enhancements' );

		return $label . ' [map · ' . $provider_label . ']';
	}

	/**
	 * @inheritDoc
	 */
	public function category() {
		return 'ASE';
	}

	/**
	 * @inheritDoc
	 */
	public function subcategory() {
		if ( ! empty( $this->field['is_repeater_sub_field'] ) ) {
			return $this->field['parent_repeater'];
		}

		return $this->field['field_group'];
	}

	/**
	 * @inheritDoc
	 */
	public function returnTypes() {
		return [ 'string', 'google_map' ];
	}

	/**
	 * @inheritDoc
	 */
	public function slug() {
		return 'ase_field_map_return_' . $this->field['name'];
	}

	/**
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	public function availableForPostType( $post_type ) {
		if ( isset( $this->field['for_post_types'] ) && in_array( $post_type, $this->field['for_post_types'], true ) ) {
			return true;
		}

		if ( isset( $this->field['is_for_an_option_page'] ) && $this->field['is_for_an_option_page'] ) {
			return true;
		}

		return false;
	}

	/**
	 * @return array
	 */
	public function controls() {
		return [
			\Breakdance\Elements\control(
				'ase_map_output',
				__( 'Output', 'admin-site-enhancements' ),
				[
					'type'  => 'dropdown',
					'items' => [
						[ 'text' => __( 'Address', 'admin-site-enhancements' ), 'value' => 'address' ],
						[ 'text' => __( 'Address (no place name)', 'admin-site-enhancements' ), 'value' => 'address_no_place_name' ],
						[ 'text' => __( 'Linked address', 'admin-site-enhancements' ), 'value' => 'address_linked' ],
						[ 'text' => __( 'Linked address (no place name)', 'admin-site-enhancements' ), 'value' => 'address_no_place_name_linked' ],
						[ 'text' => __( 'Place name', 'admin-site-enhancements' ), 'value' => 'place_name' ],
						[ 'text' => __( 'Street number', 'admin-site-enhancements' ), 'value' => 'street_number' ],
						[ 'text' => __( 'Street name', 'admin-site-enhancements' ), 'value' => 'street_name' ],
						[ 'text' => __( 'City block', 'admin-site-enhancements' ), 'value' => 'city_block' ],
						[ 'text' => __( 'Neighbourhood / Sublocality', 'admin-site-enhancements' ), 'value' => 'sublocality' ],
						[ 'text' => __( 'City', 'admin-site-enhancements' ), 'value' => 'city' ],
						[ 'text' => __( 'State', 'admin-site-enhancements' ), 'value' => 'state' ],
						[ 'text' => __( 'Post code', 'admin-site-enhancements' ), 'value' => 'post_code' ],
						[ 'text' => __( 'Country', 'admin-site-enhancements' ), 'value' => 'country' ],
						[ 'text' => __( 'Latitude', 'admin-site-enhancements' ), 'value' => 'latitude' ],
						[ 'text' => __( 'Longitude', 'admin-site-enhancements' ), 'value' => 'longitude' ],
						[ 'text' => __( 'Zoom', 'admin-site-enhancements' ), 'value' => 'zoom' ],
						[ 'text' => __( 'Latitude, Longitude', 'admin-site-enhancements' ), 'value' => 'lat_lng' ],
						[ 'text' => __( 'Coordinates (lat,lng)', 'admin-site-enhancements' ), 'value' => 'coordinates' ],
						[ 'text' => __( 'Map embed', 'admin-site-enhancements' ), 'value' => 'map' ],
						[ 'text' => __( 'Map with address above', 'admin-site-enhancements' ), 'value' => 'map_with_address_above' ],
						[ 'text' => __( 'Map with address below', 'admin-site-enhancements' ), 'value' => 'map_with_address_below' ],
					],
				]
			),
		];
	}

	/**
	 * @return string[]
	 */
	public function defaultAttributes() {
		return [
			'ase_map_output' => 'address',
		];
	}

	/**
	 * @inheritDoc
	 */
	public function handler( $attributes ): StringData {
		$post_id = get_the_ID();

		$breakdance_ase_field = new Breakdance_Ase_Field( (int) $post_id, $this->field, 'map' );
		$raw_value            = $breakdance_ase_field->get_raw_value();

		if ( ! is_array( $raw_value ) || empty( $raw_value ) ) {
			return StringData::fromString( '' );
		}

		$output = 'address';
		if ( is_array( $attributes ) && isset( $attributes['ase_map_output'] ) && is_string( $attributes['ase_map_output'] ) && '' !== $attributes['ase_map_output'] ) {
			$output = $attributes['ase_map_output'];
		}

		// ACF-style alias used by Breakdance AcfGoogleMapsField.
		if ( 'coordinates' === $output ) {
			$output = 'lat_lng';
		}

		$field_options = isset( $this->field['options'] ) && is_array( $this->field['options'] )
			? $this->field['options']
			: array();

		$value = function_exists( 'asenha_format_cf_map_output' )
			? asenha_format_cf_map_output( $raw_value, $output, $field_options )
			: '';

		if ( null === $value ) {
			$value = '';
		}

		return StringData::fromString( (string) $value );
	}

}
