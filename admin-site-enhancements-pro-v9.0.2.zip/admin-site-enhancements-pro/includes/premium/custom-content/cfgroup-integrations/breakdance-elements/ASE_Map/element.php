<?php

namespace AseElements;

use function Breakdance\Elements\c;
use function Breakdance\Elements\PresetSections\getPresetSection;

\Breakdance\ElementStudio\registerElementForEditing(
	'AseElements\\AseMap',
	\Breakdance\Util\getDirectoryPathRelativeToPluginFolder( __DIR__ )
);

/**
 * Breakdance element that renders an ASE CFG map field embed.
 *
 * @since 8.9.1
 */
class AseMap extends \Breakdance\Elements\Element {

	/**
	 * Sentinel value for CFG group header rows in the Field Name dropdown.
	 *
	 * Breakdance dropdowns are flat (no optgroups); headers simulate grouping.
	 *
	 * @since 8.9.1
	 */
	const MAP_GROUP_HEADER_VALUE = '__ase_map_group__';

	/**
	 * Build dropdown items for CFG map fields, grouped by field group.
	 *
	 * Format: `{Label} ({field_name}) [map · {Provider}]`
	 * Repeater sub-fields: `{Label} ({field_name}) — {RepeaterLabel} [map · {Provider}]`
	 * Group headers: `── {Group Title} ──` with value `__ase_map_group__`.
	 *
	 * @since 8.9.1
	 * @return array<int, array{text: string, value: string}>
	 */
	public static function get_map_field_dropdown_items() {
		$items = array();

		if ( ! function_exists( 'CFG' ) ) {
			return $items;
		}

		$map_fields = CFG()->find_fields( array( 'field_type' => 'map' ) );

		if ( ! is_array( $map_fields ) || empty( $map_fields ) ) {
			return $items;
		}

		// Index all fields by ID for parent repeater labels.
		$all_fields = CFG()->find_fields();
		$by_id      = array();

		if ( is_array( $all_fields ) ) {
			foreach ( $all_fields as $f ) {
				if ( is_array( $f ) && isset( $f['id'] ) ) {
					$by_id[ (int) $f['id'] ] = $f;
				}
			}
		}

		$grouped = array();

		foreach ( $map_fields as $field ) {
			if ( ! is_array( $field ) || empty( $field['name'] ) ) {
				continue;
			}

			$field_name = (string) $field['name'];
			$label      = isset( $field['label'] ) && '' !== (string) $field['label']
				? (string) $field['label']
				: $field_name;

			$provider = isset( $field['options']['map_provider'] ) ? (string) $field['options']['map_provider'] : 'openstreetmap';
			$provider_label = ( 'google_maps' === $provider )
				? __( 'Google Maps', 'admin-site-enhancements' )
				: __( 'OpenStreetMap', 'admin-site-enhancements' );

			$text = $label . ' (' . $field_name . ')';

			if ( ! empty( $field['parent_id'] ) && (int) $field['parent_id'] > 0 ) {
				$parent_id = (int) $field['parent_id'];
				if ( isset( $by_id[ $parent_id ]['label'] ) && '' !== (string) $by_id[ $parent_id ]['label'] ) {
					$text .= ' — ' . (string) $by_id[ $parent_id ]['label'];
				}
			}

			$text .= ' [map · ' . $provider_label . ']';

			$group_id    = isset( $field['group_id'] ) ? (int) $field['group_id'] : 0;
			$group_title = '';

			if ( $group_id > 0 ) {
				$group_title = get_the_title( $group_id );
			}

			if ( ! is_string( $group_title ) || '' === $group_title ) {
				$group_title = __( 'Field Group', 'admin-site-enhancements' );
			}

			if ( ! isset( $grouped[ $group_title ] ) ) {
				$grouped[ $group_title ] = array();
			}

			$grouped[ $group_title ][] = array(
				'text'  => $text,
				'value' => $field_name,
				'label' => $label,
			);
		}

		if ( empty( $grouped ) ) {
			return $items;
		}

		ksort( $grouped, SORT_NATURAL | SORT_FLAG_CASE );

		foreach ( $grouped as $group_title => $group_fields ) {
			usort(
				$group_fields,
				static function ( $a, $b ) {
					return strnatcasecmp( (string) $a['label'], (string) $b['label'] );
				}
			);

			$items[] = array(
				'text'  => '── ' . $group_title . ' ──',
				'value' => self::MAP_GROUP_HEADER_VALUE,
			);

			foreach ( $group_fields as $group_field ) {
				$items[] = array(
					'text'  => $group_field['text'],
					'value' => $group_field['value'],
				);
			}
		}

		return $items;
	}

	/**
	 * @inheritDoc
	 */
	static function uiIcon() {
		return '<svg aria-hidden="true" focusable="false" class="svg-inline--fa fa-map-pin" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path fill="currentColor" d="M160-.0002c-79.53 0-144 64.47-144 144c0 74.05 56.1 134.3 128 142.4V496c0 8.844 7.156 16 16 16s16-7.156 16-16V286.4c71.9-8.055 128-68.34 128-142.4C304 64.47 239.5-.0002 160-.0002zM160 256C98.24 256 48 205.8 48 144S98.24 32 160 32s112 50.24 112 112S221.8 256 160 256zM160 64C115.9 64 80 99.88 80 144C80 152.8 87.16 160 96 160s16-7.156 16-16C112 117.5 133.5 96 160 96c8.844 0 16-7.156 16-16S168.8 64 160 64z"></path></svg>';
	}

	/**
	 * @inheritDoc
	 */
	static function availableIn() {
		return array( 'breakdance', 'oxygen' );
	}

	/**
	 * @inheritDoc
	 */
	static function tag() {
		return 'div';
	}

	/**
	 * @inheritDoc
	 */
	static function tagOptions() {
		return array();
	}

	/**
	 * @inheritDoc
	 */
	static function tagControlPath() {
		return false;
	}

	/**
	 * @inheritDoc
	 */
	static function name() {
		return 'ASE Map';
	}

	/**
	 * @inheritDoc
	 */
	static function className() {
		return 'bde-ase-map';
	}

	/**
	 * @inheritDoc
	 */
	static function category() {
		return 'blocks';
	}

	/**
	 * @inheritDoc
	 */
	static function badge() {
		return false;
	}

	/**
	 * @inheritDoc
	 */
	static function slug() {
		return __CLASS__;
	}

	/**
	 * @inheritDoc
	 */
	static function template() {
		return file_get_contents( __DIR__ . '/html.twig' );
	}

	/**
	 * @inheritDoc
	 */
	static function defaultCss() {
		return file_get_contents( __DIR__ . '/default.css' );
	}

	/**
	 * @inheritDoc
	 */
	static function defaultProperties() {
		return array(
			'content' => array(
				'content' => array(
					'field_name'       => '',
					'address_position' => 'none',
				),
			),
			'design'  => array(
				'spacing' => array(
					'margin_bottom' => null,
				),
				'size'    => array(
					'width'  => array(
						'breakpoint_base' => array(
							'number' => 600,
							'unit'   => 'px',
							'style'  => '600px',
						),
					),
					'height' => array(
						'breakpoint_base' => array(
							'number' => 400,
							'unit'   => 'px',
							'style'  => '400px',
						),
					),
				),
			),
		);
	}

	/**
	 * @inheritDoc
	 */
	static function defaultChildren() {
		return false;
	}

	/**
	 * @inheritDoc
	 */
	static function cssTemplate() {
		return file_get_contents( __DIR__ . '/css.twig' );
	}

	/**
	 * @inheritDoc
	 */
	static function designControls() {
		return array(
			c(
				'size',
				'Size',
				array(
					c(
						'width',
						'Width',
						array(),
						array( 'type' => 'unit', 'layout' => 'inline' ),
						true,
						false,
						array()
					),
					c(
						'height',
						'Height',
						array(),
						array( 'type' => 'unit', 'layout' => 'inline' ),
						true,
						false,
						array()
					),
				),
				array( 'type' => 'section' ),
				false,
				false,
				array()
			),
			getPresetSection(
				'EssentialElements\\spacing_margin_y',
				'Spacing',
				'spacing',
				array( 'type' => 'popout' )
			),
		);
	}

	/**
	 * @inheritDoc
	 */
	static function contentControls() {
		$map_items = self::get_map_field_dropdown_items();

		return array(
			c(
				'content',
				'Content',
				array(
					c(
						'field_name',
						__( 'Field Name', 'admin-site-enhancements' ),
						array(),
						array(
							'type'   => 'dropdown',
							'layout' => 'vertical',
							'items'  => $map_items,
						),
						false,
						false,
						array()
					),
					c(
						'address_position',
						__( 'Address Position', 'admin-site-enhancements' ),
						array(),
						array(
							'type'  => 'dropdown',
							'layout' => 'vertical',
							'items' => array(
								array( 'text' => __( 'None (map only)', 'admin-site-enhancements' ), 'value' => 'none' ),
								array( 'text' => __( 'Above map', 'admin-site-enhancements' ), 'value' => 'above' ),
								array( 'text' => __( 'Below map', 'admin-site-enhancements' ), 'value' => 'below' ),
							),
						),
						false,
						false,
						array()
					),
					c(
						'height',
						__( 'Height (px)', 'admin-site-enhancements' ),
						array(),
						array(
							'type'        => 'number',
							'layout'      => 'inline',
							'rangeOptions' => array(
								'min'  => 100,
								'max'  => 1200,
								'step' => 10,
							),
						),
						false,
						false,
						array()
					),
					c(
						'zoom',
						__( 'Zoom', 'admin-site-enhancements' ),
						array(),
						array(
							'type'         => 'number',
							'layout'       => 'inline',
							'rangeOptions' => array(
								'min'  => 1,
								'max'  => 21,
								'step' => 1,
							),
						),
						false,
						false,
						array()
					),
				),
				array( 'type' => 'section', 'layout' => 'vertical' ),
				false,
				false,
				array()
			),
		);
	}

	/**
	 * @inheritDoc
	 */
	static function settingsControls() {
		return array();
	}

	/**
	 * Leaflet + OSM frontend assets (safe for Google Maps fields too).
	 *
	 * @inheritDoc
	 */
	static function dependencies() {
		if ( ! defined( 'CFG_URL' ) ) {
			return false;
		}

		$version = defined( 'ASENHA_VERSION' ) ? ASENHA_VERSION : '1.0.0';

		return array(
			array(
				'title'   => 'ASE CFG Leaflet',
				'styles'  => array( CFG_URL . '/assets/vendor/leaflet/leaflet.css?ver=1.9.4' ),
				'scripts' => array( CFG_URL . '/assets/vendor/leaflet/leaflet.js?ver=1.9.4' ),
			),
			array(
				'title'   => 'ASE CFG Map Frontend',
				'styles'  => array( CFG_URL . '/assets/css/cfg-map-frontend.css?ver=' . rawurlencode( $version ) ),
				'scripts' => array( CFG_URL . '/assets/js/cfg-map-frontend.js?ver=' . rawurlencode( $version ) ),
			),
		);
	}

	/**
	 * @inheritDoc
	 */
	static function settings() {
		return array(
			'bypassPointerEvents' => true,
			'proOnly'             => true,
		);
	}

	/**
	 * @inheritDoc
	 */
	static function addPanelRules() {
		return false;
	}

	/**
	 * @inheritDoc
	 */
	static public function actions() {
		return false;
	}

	/**
	 * @inheritDoc
	 */
	static function nestingRule() {
		return array( 'type' => 'final' );
	}

	/**
	 * @inheritDoc
	 */
	static function spacingBars() {
		return array(
			'0' => array(
				'location'             => 'outside-top',
				'cssProperty'          => 'margin-top',
				'affectedPropertyPath' => 'design.spacing.margin_top.%%BREAKPOINT%%',
			),
			'1' => array(
				'location'             => 'outside-bottom',
				'cssProperty'          => 'margin-bottom',
				'affectedPropertyPath' => 'design.spacing.margin_bottom.%%BREAKPOINT%%',
			),
		);
	}

	/**
	 * @inheritDoc
	 */
	static function attributes() {
		return false;
	}

	/**
	 * @inheritDoc
	 */
	static function experimental() {
		return false;
	}

	/**
	 * @inheritDoc
	 */
	static function order() {
		return 5100;
	}

	/**
	 * @inheritDoc
	 */
	static function dynamicPropertyPaths() {
		return false;
	}

	/**
	 * @inheritDoc
	 */
	static function additionalClasses() {
		return false;
	}

	/**
	 * @inheritDoc
	 */
	static function projectManagement() {
		return array(
			'looksGood'            => 'yes',
			'optionsGood'          => 'yes',
			'optionsWork'          => 'yes',
			'dynamicBehaviorWorks' => 'yes',
		);
	}

	/**
	 * @inheritDoc
	 */
	static function propertyPathsToWhitelistInFlatProps() {
		return false;
	}

	/**
	 * @inheritDoc
	 */
	static function propertyPathsToSsrElementWhenValueChanges() {
		return array( 'content.content' );
	}
}
