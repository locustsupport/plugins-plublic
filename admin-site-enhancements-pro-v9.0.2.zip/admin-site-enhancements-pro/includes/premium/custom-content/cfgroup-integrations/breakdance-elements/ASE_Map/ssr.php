<?php
/**
 * ASE Map Breakdance element SSR.
 *
 * Renders CFG map embeds (Google iframe or OSM Leaflet) via get_cf_map().
 *
 * Do not use bare `return;` / `return null` / `return false` at file scope.
 * Breakdance includes this file and treats a falsy include result as
 * "This element doesn't have a ssr.php file".
 *
 * @var array $propertiesData
 * @since 8.9.1
 */

if ( ! class_exists( '\Ase\Integrations\Breakdance\Breakdance_Ase_Field' ) ) {
	require_once ASENHA_PATH . 'includes/premium/custom-content/cfgroup-integrations/breakdance-fields/ase-field.php';
}

$field_name = isset( $propertiesData['content']['content']['field_name'] )
	? (string) $propertiesData['content']['content']['field_name']
	: '';

$group_header_value = class_exists( '\AseElements\AseMap' )
	? \AseElements\AseMap::MAP_GROUP_HEADER_VALUE
	: '__ase_map_group__';

// Ignore empty selection and CFG group header sentinel from the Field Name dropdown.
// Fall through with no output (include must return truthy / 1).
if (
	'' !== $field_name
	&& $group_header_value !== $field_name
	&& function_exists( 'get_cf_map' )
	&& function_exists( 'CFG' )
) {
	$field = array();

	// Prefer the registered Ase_Map Dynamic Data field (already enriched like Text DD).
	if ( class_exists( '\Breakdance\DynamicData\DynamicDataController' ) && class_exists( 'Ase_Map' ) ) {
		$dd = \Breakdance\DynamicData\DynamicDataController::getInstance()->getField( 'ase_field_map_return_' . $field_name );
		if ( $dd instanceof \Ase_Map && ! empty( $dd->field ) && is_array( $dd->field ) ) {
			$field = $dd->field;
		}
	}

	// Fallback: CFG lookup + repeater-typed parent (CFG field IDs can collide across groups).
	if ( empty( $field ) || ! isset( $field['type'] ) || 'map' !== $field['type'] ) {
		$fields = CFG()->find_fields( array( 'field_name' => $field_name ) );
		$field  = ( is_array( $fields ) && ! empty( $fields[0] ) && is_array( $fields[0] ) ) ? $fields[0] : array();

		if ( ! empty( $field ) && isset( $field['type'] ) && 'map' === $field['type'] ) {
			$field['parent_name']           = '';
			$field['is_repeater_sub_field'] = false;
			$field['parent_repeater']       = '';
			$field['parent_type']           = '';

			if ( ! empty( $field['parent_id'] ) && (int) $field['parent_id'] > 0 ) {
				$parent_id      = (int) $field['parent_id'];
				$parent_fields  = CFG()->find_fields( array( 'field_id' => $parent_id ) );
				$parent_field   = array();

				if ( is_array( $parent_fields ) ) {
					foreach ( $parent_fields as $candidate ) {
						if (
							is_array( $candidate )
							&& isset( $candidate['type'] )
							&& 'repeater' === $candidate['type']
							&& (int) ( $candidate['id'] ?? 0 ) === $parent_id
						) {
							$parent_field = $candidate;
							break;
						}
					}
				}

				if ( ! empty( $parent_field ) ) {
					$field['is_repeater_sub_field'] = true;
					$field['parent_repeater']       = isset( $parent_field['label'] ) ? (string) $parent_field['label'] : '';
					$field['parent_type']           = 'repeater';
					$field['parent_name']           = isset( $parent_field['name'] ) ? (string) $parent_field['name'] : '';
				}
			}
		}
	}

	if ( ! empty( $field ) && isset( $field['type'] ) && 'map' === $field['type'] ) {
		$breakdance_ase_field = new \Ase\Integrations\Breakdance\Breakdance_Ase_Field( (int) get_the_ID(), $field, 'map' );
		$map_value            = $breakdance_ase_field->get_raw_value();

		if ( is_array( $map_value ) && ! empty( $map_value['latitude'] ) && ! empty( $map_value['longitude'] ) ) {
			$options = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();

			$address_position = isset( $propertiesData['content']['content']['address_position'] )
				? (string) $propertiesData['content']['content']['address_position']
				: 'none';
			$address_position = in_array( $address_position, array( 'none', 'above', 'below' ), true )
				? $address_position
				: 'none';

			$overrides = array();

			if ( isset( $propertiesData['content']['content']['height'] )
				&& '' !== $propertiesData['content']['content']['height']
				&& null !== $propertiesData['content']['content']['height']
			) {
				$height = absint( $propertiesData['content']['content']['height'] );
				if ( $height > 0 ) {
					$overrides['height'] = $height . 'px';
				}
			}

			if ( isset( $propertiesData['content']['content']['zoom'] )
				&& '' !== $propertiesData['content']['content']['zoom']
				&& null !== $propertiesData['content']['content']['zoom']
			) {
				$zoom = absint( $propertiesData['content']['content']['zoom'] );
				if ( $zoom >= 1 && $zoom <= 21 ) {
					$overrides['zoom'] = $zoom;
				}
			}

			$provider = isset( $options['map_provider'] ) ? $options['map_provider'] : 'openstreetmap';
			if ( 'openstreetmap' === $provider && function_exists( 'asenha_cfgroup_enqueue_map_osm_frontend' ) ) {
				asenha_cfgroup_enqueue_map_osm_frontend();
			}

			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- get_cf_map() returns escaped HTML.
			echo get_cf_map( $map_value, $options, $address_position, $overrides );
		}
	}
}
