<?php
/**
 * Bootstrap the ASE Custom Content Types WPML bridge.
 *
 * @package Admin and Site Enhancements
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-cct-wpml-package.php';
require_once __DIR__ . '/class-cct-wpml.php';
require_once __DIR__ . '/class-cct-wpml-admin-ui.php';

ASENHA_CCT_WPML::get_instance();
ASENHA_CCT_WPML_Admin_UI::get_instance();
