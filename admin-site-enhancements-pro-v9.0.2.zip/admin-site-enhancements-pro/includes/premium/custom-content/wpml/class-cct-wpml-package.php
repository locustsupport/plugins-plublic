<?php
/**
 * WPML string package helper for ASE Custom Content Types.
 *
 * @package Admin and Site Enhancements
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ASENHA_CCT_WPML_Package {

	const KIND_FIELD_GROUP  = 'asenha-cfgroup-labels';
	const KIND_POST_TYPE    = 'asenha-cpt-labels';
	const KIND_TAXONOMY     = 'asenha-taxonomy-labels';
	const KIND_OPTIONS_PAGE = 'asenha-options-page-labels';
	const STATUS_ST_INACTIVE         = 'st_inactive';
	const STATUS_NOT_REGISTERED      = 'not_registered';
	const STATUS_NOT_TRANSLATED      = 'not_translated';
	const STATUS_PARTIALLY_TRANSLATED = 'partially_translated';
	const STATUS_FULLY_TRANSLATED    = 'fully_translated';

	/**
	 * Package identifier.
	 *
	 * @var string
	 */
	private $package_id;

	/**
	 * Package kind.
	 *
	 * @var string
	 */
	private $package_kind;

	/**
	 * Number of strings registered in the current pass.
	 *
	 * @var int
	 */
	private $registered_strings_count = 0;

	/**
	 * Constructor.
	 *
	 * @param string $package_id   Stable package ID.
	 * @param string $package_kind Package kind.
	 */
	public function __construct( $package_id, $package_kind ) {
		$this->package_id   = (string) $package_id;
		$this->package_kind = (string) $package_kind;
	}

	/**
	 * Register a string inside this package.
	 *
	 * @param string $value String value.
	 * @param array  $meta  String metadata.
	 * @return void
	 */
	public function register_string( $value, $meta ) {
		if ( ! defined( 'WPML_ST_VERSION' ) || '' === (string) $value ) {
			return;
		}

		do_action(
			'wpml_register_string',
			$value,
			$this->get_string_name( $value, $meta ),
			$this->get_package_data(),
			isset( $meta['title'] ) ? $meta['title'] : '',
			isset( $meta['type'] ) ? $meta['type'] : 'LINE'
		);

		++$this->registered_strings_count;
	}

	/**
	 * Translate a string from this package.
	 *
	 * @param string $value String value.
	 * @param array  $meta  String metadata.
	 * @return string
	 */
	public function translate_string( $value, $meta ) {
		if ( ! defined( 'WPML_ST_VERSION' ) || '' === (string) $value ) {
			return $value;
		}

		return apply_filters(
			'wpml_translate_string',
			$value,
			$this->get_string_name( $value, $meta ),
			$this->get_package_data()
		);
	}

	/**
	 * Get the stored WPML context for this package.
	 *
	 * @return string
	 */
	public function get_string_context() {
		$package_data = $this->get_package_data();

		return $package_data['kind_slug'] . '-' . $package_data['name'];
	}

	/**
	 * Build the WPML string name for a package entry.
	 *
	 * @param string $value String value.
	 * @param array  $meta  String metadata.
	 * @return string
	 */
	public function get_string_name_for_meta( $value, $meta ) {
		return $this->get_string_name( $value, $meta );
	}

	/**
	 * Mark the start of a registration run.
	 *
	 * @return void
	 */
	public function start_registration() {
		$this->registered_strings_count = 0;

		if ( defined( 'WPML_ST_VERSION' ) ) {
			do_action( 'wpml_start_string_package_registration', $this->get_package_data() );
		}
	}

	/**
	 * Clean up package strings not re-registered on the current run.
	 *
	 * @return void
	 */
	public function cleanup_unused_strings() {
		if ( defined( 'WPML_ST_VERSION' ) && $this->has_registered_strings() ) {
			do_action( 'wpml_delete_unused_package_strings', $this->get_package_data() );
		}
	}

	/**
	 * Check whether the current pass registered any strings.
	 *
	 * @return bool
	 */
	public function has_registered_strings() {
		return $this->registered_strings_count > 0;
	}

	/**
	 * Get active package kinds as expected by WPML.
	 *
	 * @return array<string,array<string,string>>
	 */
	public static function get_active_package_kinds() {
		$definitions = array();

		foreach ( self::get_package_kind_configurations() as $kind_slug => $config ) {
			$definitions[ $kind_slug ] = array(
				'title'  => $config['kind'],
				'plural' => $config['plural'],
				'slug'   => $kind_slug,
			);
		}

		return $definitions;
	}

	/**
	 * Get the current translation status for this package.
	 *
	 * @return string
	 */
	public function get_status() {
		$package = $this->get_wpml_package();
		if ( ! $package ) {
			return self::STATUS_ST_INACTIVE;
		}

		$strings = $package->get_package_strings();
		if ( ! is_array( $strings ) || empty( $strings ) ) {
			return self::STATUS_NOT_REGISTERED;
		}

		$translated_strings = $package->get_translated_strings( array() );
		if ( ! is_array( $translated_strings ) || empty( $translated_strings ) ) {
			return self::STATUS_NOT_TRANSLATED;
		}

		$secondary_languages_count = $this->get_secondary_languages_count();
		$is_partial                = count( $translated_strings ) < count( $strings );

		if ( $secondary_languages_count > 0 ) {
			foreach ( $strings as $string ) {
				$string_name = isset( $string->name ) ? (string) $string->name : '';
				if ( '' === $string_name ) {
					$is_partial = true;
					continue;
				}

				$string_translations = isset( $translated_strings[ $string_name ] ) && is_array( $translated_strings[ $string_name ] )
					? $translated_strings[ $string_name ]
					: array();

				if ( count( $string_translations ) < $secondary_languages_count ) {
					$is_partial = true;
					break;
				}
			}
		}

		return $is_partial ? self::STATUS_PARTIALLY_TRANSLATED : self::STATUS_FULLY_TRANSLATED;
	}

	/**
	 * Get a user-facing status label.
	 *
	 * @return string
	 */
	public function get_status_label() {
		return self::get_status_label_for( $this->get_status() );
	}

	/**
	 * Map a package status code to label text.
	 *
	 * @param string $status Internal status code.
	 * @return string
	 */
	public static function get_status_label_for( $status ) {
		switch ( $status ) {
			case self::STATUS_FULLY_TRANSLATED:
				return __( 'Complete', 'admin-site-enhancements' );

			case self::STATUS_PARTIALLY_TRANSLATED:
				return __( 'In progress', 'admin-site-enhancements' );

			case self::STATUS_ST_INACTIVE:
				return __( 'WPML String Translation required', 'admin-site-enhancements' );

			case self::STATUS_NOT_REGISTERED:
			case self::STATUS_NOT_TRANSLATED:
			default:
				return __( 'Not translated', 'admin-site-enhancements' );
		}
	}

	/**
	 * Get the WPML dashboard URL for this package kind.
	 *
	 * @return string
	 */
	public function get_translation_dashboard_url() {
		$dashboard_url = '';

		if ( class_exists( 'WPML\\UIPage' ) && method_exists( 'WPML\\UIPage', 'getTMDashboard' ) ) {
			$dashboard_url = admin_url( \WPML\UIPage::getTMDashboard() );
		} elseif ( defined( 'WPML_TM_FOLDER' ) ) {
			$dashboard_url = admin_url( 'admin.php?page=' . trim( WPML_TM_FOLDER, '/' ) . '/menu/main.php' );
		}

		if ( '' === $dashboard_url ) {
			return '';
		}

		return add_query_arg(
			array(
				'sections' => sprintf( 'stringPackage/%s', $this->package_kind ),
			),
			$dashboard_url
		);
	}

	/**
	 * Get package metadata as expected by WPML.
	 *
	 * @return array
	 */
	private function get_package_data() {
		$config = self::get_package_kind_configuration( $this->package_kind );

		$package_data = array(
			'kind'      => $config['kind'],
			'kind_slug' => $this->package_kind,
			'name'      => $this->package_id,
			'title'     => $this->get_package_title( $config ),
		);

		$edit_link = $this->get_package_edit_link();
		if ( '' !== $edit_link ) {
			$package_data['edit_link'] = $edit_link;
		}

		return $package_data;
	}

	/**
	 * Get the user-facing package title.
	 *
	 * @param array<string,string> $config Package-kind configuration.
	 * @return string
	 */
	private function get_package_title( $config ) {
		if ( self::KIND_FIELD_GROUP === $this->package_kind ) {
			$field_group_title = $this->get_field_group_post_title();
			if ( '' !== $field_group_title ) {
				return sprintf( $config['title_tpl'], $field_group_title, $this->package_id );
			}

			return $this->package_id;
		}

		if ( self::KIND_POST_TYPE === $this->package_kind ) {
			$plural_name = $this->get_post_type_plural_name();
			if ( '' !== $plural_name ) {
				return sprintf( $config['title_tpl'], $plural_name, $this->package_id );
			}

			return $this->package_id;
		}

		if ( self::KIND_TAXONOMY === $this->package_kind ) {
			$plural_name = $this->get_taxonomy_plural_name();
			if ( '' !== $plural_name ) {
				return sprintf( $config['title_tpl'], $plural_name, $this->package_id );
			}

			return $this->package_id;
		}

		if ( self::KIND_OPTIONS_PAGE === $this->package_kind ) {
			$menu_title = $this->get_options_page_menu_title();
			if ( '' !== $menu_title ) {
				return sprintf( $config['title_tpl'], $menu_title, $this->package_id );
			}

			return $this->package_id;
		}

		return sprintf( $config['title_tpl'], $this->package_id );
	}

	/**
	 * Get the field-group post title for package display.
	 *
	 * @return string
	 */
	private function get_field_group_post_title() {
		if ( ! preg_match( '/^cfgroup-(\d+)$/', $this->package_id, $matches ) ) {
			return '';
		}

		$field_group_id = absint( $matches[1] );
		if ( $field_group_id <= 0 ) {
			return '';
		}

		$field_group = get_post( $field_group_id );
		if ( ! $field_group instanceof WP_Post ) {
			return '';
		}

		return trim( (string) $field_group->post_title );
	}

	/**
	 * Get the custom post type plural name for package display.
	 *
	 * @return string
	 */
	private function get_post_type_plural_name() {
		if ( ! preg_match( '/^cpt-(.+)$/', $this->package_id, $matches ) ) {
			return '';
		}

		$cpt_key = (string) $matches[1];
		if ( '' === $cpt_key || ! function_exists( 'get_posts' ) ) {
			return '';
		}

		$matching_posts = get_posts(
			array(
				'post_type'              => 'asenha_cpt',
				'post_status'            => 'any',
				'numberposts'            => 1,
				'fields'                 => 'ids',
				'meta_key'               => 'cpt_key',
				'meta_value'             => $cpt_key,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		if ( empty( $matching_posts ) ) {
			return '';
		}

		$plural_name = get_post_meta( absint( $matching_posts[0] ), 'cpt_plural_name', true );

		return trim( (string) $plural_name );
	}

	/**
	 * Get the custom taxonomy plural name for package display.
	 *
	 * @return string
	 */
	private function get_taxonomy_plural_name() {
		if ( ! preg_match( '/^taxonomy-(.+)$/', $this->package_id, $matches ) ) {
			return '';
		}

		$ctax_key = (string) $matches[1];
		if ( '' === $ctax_key || ! function_exists( 'get_posts' ) ) {
			return '';
		}

		$matching_posts = get_posts(
			array(
				'post_type'              => 'asenha_ctax',
				'post_status'            => 'any',
				'numberposts'            => 1,
				'fields'                 => 'ids',
				'meta_key'               => 'ctax_key',
				'meta_value'             => $ctax_key,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		if ( empty( $matching_posts ) ) {
			return '';
		}

		$plural_name = get_post_meta( absint( $matching_posts[0] ), 'ctax_plural_name', true );

		return trim( (string) $plural_name );
	}

	/**
	 * Get the options page menu title for package display.
	 *
	 * @return string
	 */
	private function get_options_page_menu_title() {
		if ( ! preg_match( '/^options-page-(.+)$/', $this->package_id, $matches ) ) {
			return '';
		}

		$menu_slug = (string) $matches[1];
		if ( '' === $menu_slug || ! function_exists( 'get_posts' ) ) {
			return '';
		}

		$matching_posts = get_posts(
			array(
				'post_type'              => 'options_page_config',
				'post_status'            => 'any',
				'numberposts'            => 1,
				'fields'                 => 'ids',
				'meta_key'               => 'options_page_menu_slug',
				'meta_value'             => $menu_slug,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		if ( empty( $matching_posts ) ) {
			return '';
		}

		$menu_title = get_post_meta( absint( $matching_posts[0] ), 'options_page_menu_title', true );

		return trim( (string) $menu_title );
	}

	/**
	 * Build a stable string name for a package entry.
	 *
	 * @param string $value String value.
	 * @param array  $meta  String metadata.
	 * @return string
	 */
	private function get_string_name( $value, $meta ) {
		$namespace = isset( $meta['namespace'] ) ? sanitize_key( $meta['namespace'] ) : 'ase';
		$id        = isset( $meta['id'] ) ? sanitize_key( (string) $meta['id'] ) : 'item';
		$key       = isset( $meta['key'] ) ? sanitize_key( (string) $meta['key'] ) : 'string';

		return $namespace . '-' . $id . '-' . $key . '-' . md5( $value );
	}

	/**
	 * Instantiate the underlying WPML package helper.
	 *
	 * @return WPML_Package|null
	 */
	private function get_wpml_package() {
		if ( ! defined( 'WPML_ST_VERSION' ) || ! class_exists( 'WPML_Package' ) ) {
			return null;
		}

		return new WPML_Package( $this->get_package_data() );
	}

	/**
	 * Get package kind configuration.
	 *
	 * @param string $package_kind Package kind slug.
	 * @return array<string,string>
	 */
	private static function get_package_kind_configuration( $package_kind ) {
		$configurations = self::get_package_kind_configurations();

		if ( isset( $configurations[ $package_kind ] ) ) {
			return $configurations[ $package_kind ];
		}

		return $configurations[ self::KIND_FIELD_GROUP ];
	}

	/**
	 * Get all supported package kind configurations.
	 *
	 * @return array<string,array<string,string>>
	 */
	private static function get_package_kind_configurations() {
		return array(
			self::KIND_FIELD_GROUP  => array(
				'kind'      => 'ASE Field Group Labels',
				'plural'    => 'ASE Field Group Labels',
				'title_tpl' => '%s (%s)',
			),
			self::KIND_POST_TYPE    => array(
				'kind'      => 'ASE Custom Post Type Labels',
				'plural'    => 'ASE Custom Post Type Labels',
				'title_tpl' => '%s (%s)',
			),
			self::KIND_TAXONOMY     => array(
				'kind'      => 'ASE Custom Taxonomy Labels',
				'plural'    => 'ASE Custom Taxonomy Labels',
				'title_tpl' => '%s (%s)',
			),
			self::KIND_OPTIONS_PAGE => array(
				'kind'      => 'ASE Options Page Labels',
				'plural'    => 'ASE Options Page Labels',
				'title_tpl' => '%s (%s)',
			),
		);
	}

	/**
	 * Resolve an edit link for this package when possible.
	 *
	 * @return string
	 */
	private function get_package_edit_link() {
		if ( ! function_exists( 'admin_url' ) ) {
			return '';
		}

		switch ( $this->package_kind ) {
			case self::KIND_FIELD_GROUP:
				if ( preg_match( '/^cfgroup-(\d+)$/', $this->package_id, $matches ) ) {
					return admin_url( 'post.php?post=' . absint( $matches[1] ) . '&action=edit' );
				}
				break;

			case self::KIND_POST_TYPE:
				return $this->get_definition_edit_link_by_meta( 'asenha_cpt', 'cpt_key', preg_replace( '/^cpt-/', '', $this->package_id ) );

			case self::KIND_TAXONOMY:
				return $this->get_definition_edit_link_by_meta( 'asenha_ctax', 'ctax_key', preg_replace( '/^taxonomy-/', '', $this->package_id ) );

			case self::KIND_OPTIONS_PAGE:
				return $this->get_definition_edit_link_by_meta( 'options_page_config', 'options_page_menu_slug', preg_replace( '/^options-page-/', '', $this->package_id ) );
		}

		return '';
	}

	/**
	 * Resolve an ASE definition edit link from post meta.
	 *
	 * @param string $post_type Definition post type.
	 * @param string $meta_key  Lookup meta key.
	 * @param string $meta_value Lookup meta value.
	 * @return string
	 */
	private function get_definition_edit_link_by_meta( $post_type, $meta_key, $meta_value ) {
		if ( '' === (string) $meta_value || ! function_exists( 'get_posts' ) ) {
			return '';
		}

		$matching_posts = get_posts(
			array(
				'post_type'              => $post_type,
				'post_status'            => 'any',
				'numberposts'            => 1,
				'fields'                 => 'ids',
				'meta_key'               => $meta_key,
				'meta_value'             => $meta_value,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		if ( empty( $matching_posts ) ) {
			return '';
		}

		return admin_url( 'post.php?post=' . absint( $matching_posts[0] ) . '&action=edit' );
	}

	/**
	 * Count secondary WPML languages.
	 *
	 * @return int
	 */
	private function get_secondary_languages_count() {
		$languages = apply_filters(
			'wpml_active_languages',
			null,
			array(
				'skip_missing' => 0,
				'orderby'      => 'code',
			)
		);

		if ( ! is_array( $languages ) || empty( $languages ) ) {
			return 0;
		}

		$default_language = apply_filters( 'wpml_default_language', null );
		$count            = 0;

		foreach ( $languages as $language_code => $language_data ) {
			unset( $language_data );

			if ( (string) $language_code === (string) $default_language ) {
				continue;
			}

			++$count;
		}

		return $count;
	}
}
