<?php
/**
 * ASE Custom Content Types WPML admin UX.
 *
 * @package Admin and Site Enhancements
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ASENHA_CCT_WPML_Admin_UI {

	/**
	 * Singleton instance.
	 *
	 * @var ASENHA_CCT_WPML_Admin_UI|null
	 */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @return ASENHA_CCT_WPML_Admin_UI
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->add_hooks();
	}

	/**
	 * Register admin UI hooks.
	 *
	 * @return void
	 */
	private function add_hooks() {
		add_action( 'add_meta_boxes_asenha_cfgroup', array( $this, 'add_field_group_meta_box' ) );
		add_action( 'add_meta_boxes_asenha_cpt', array( $this, 'add_post_type_meta_box' ) );
		add_action( 'add_meta_boxes_asenha_ctax', array( $this, 'add_taxonomy_meta_box' ) );
		add_action( 'add_meta_boxes_options_page_config', array( $this, 'add_options_page_meta_box' ) );

		add_filter( 'manage_asenha_cfgroup_posts_columns', array( $this, 'inject_label_status_column' ), 20 );
		add_action( 'manage_asenha_cfgroup_posts_custom_column', array( $this, 'render_label_status_column' ), 10, 2 );
		add_filter( 'manage_asenha_cpt_posts_columns', array( $this, 'inject_label_status_column' ), 20 );
		add_action( 'manage_asenha_cpt_posts_custom_column', array( $this, 'render_label_status_column' ), 10, 2 );
		add_filter( 'manage_asenha_ctax_posts_columns', array( $this, 'inject_label_status_column' ), 20 );
		add_action( 'manage_asenha_ctax_posts_custom_column', array( $this, 'render_label_status_column' ), 10, 2 );
		add_filter( 'manage_options_page_config_posts_columns', array( $this, 'inject_label_status_column' ), 20 );
		add_action( 'manage_options_page_config_posts_custom_column', array( $this, 'render_label_status_column' ), 10, 2 );

		add_action( 'asenha_cct_cfgroup_fields_tab_intro', array( $this, 'render_field_group_intro_affordance' ) );
		add_action( 'asenha_cct_cpt_basic_label_affordance', array( $this, 'render_post_type_basic_affordance' ) );
		add_action( 'asenha_cct_cpt_labels_tab_intro', array( $this, 'render_post_type_labels_affordance' ) );
		add_action( 'asenha_cct_ctax_basic_label_affordance', array( $this, 'render_taxonomy_basic_affordance' ) );
		add_action( 'asenha_cct_ctax_labels_tab_intro', array( $this, 'render_taxonomy_labels_affordance' ) );
		add_action( 'asenha_cct_options_page_basic_label_affordance', array( $this, 'render_options_page_basic_affordance' ) );

		add_action( 'admin_head', array( $this, 'print_admin_styles' ) );
	}

	/**
	 * Add the field-group label translation metabox.
	 *
	 * @return void
	 */
	public function add_field_group_meta_box() {
		add_meta_box(
			'asenha-cct-wpml-label-setup',
			__( 'Label Translation', 'admin-site-enhancements' ),
			array( $this, 'render_multilingual_setup_meta_box' ),
			'asenha_cfgroup',
			'side',
			'default'
		);
	}

	/**
	 * Add the custom post type label translation metabox.
	 *
	 * @return void
	 */
	public function add_post_type_meta_box() {
		add_meta_box(
			'asenha-cct-wpml-label-setup',
			__( 'Label Translation', 'admin-site-enhancements' ),
			array( $this, 'render_multilingual_setup_meta_box' ),
			'asenha_cpt',
			'side',
			'default'
		);
	}

	/**
	 * Add the custom taxonomy label translation metabox.
	 *
	 * @return void
	 */
	public function add_taxonomy_meta_box() {
		add_meta_box(
			'asenha-cct-wpml-label-setup',
			__( 'Label Translation', 'admin-site-enhancements' ),
			array( $this, 'render_multilingual_setup_meta_box' ),
			'asenha_ctax',
			'side',
			'default'
		);
	}

	/**
	 * Add the options-page label translation metabox.
	 *
	 * @return void
	 */
	public function add_options_page_meta_box() {
		add_meta_box(
			'asenha-cct-wpml-label-setup',
			__( 'Label Translation', 'admin-site-enhancements' ),
			array( $this, 'render_multilingual_setup_meta_box' ),
			'options_page_config',
			'side',
			'default'
		);
	}

	/**
	 * Render the shared label translation metabox.
	 *
	 * @param WP_Post $post Current definition post.
	 * @return void
	 */
	public function render_multilingual_setup_meta_box( $post ) {
		$context = $this->get_package_context( $post );
		if ( empty( $context ) ) {
			return;
		}
		?>
		<div class="asenha-cct-wpml-panel">
			<p>
				<?php
				printf(
					/* translators: %s: label translation status, e.g. Not translated, Complete */
					esc_html__( 'Status: %s', 'admin-site-enhancements' ),
					esc_html( ASENHA_CCT_WPML_Package::get_status_label_for( $context['status'] ) )
				);
				?>
			</p>

			<?php if ( ASENHA_CCT_WPML_Package::STATUS_ST_INACTIVE === $context['status'] ) : ?>
				<p class="description">
					<?php esc_html_e( 'WPML String Translation is required before ASE can register and translate these labels.', 'admin-site-enhancements' ); ?>
				</p>
			<?php elseif ( ! empty( $context['not_registered_message'] ) ) : ?>
				<p class="description">
					<?php echo esc_html( $context['not_registered_message'] ); ?>
				</p>
			<?php elseif ( ! empty( $context['dashboard_url'] ) ) : ?>
				<p>
					<a class="button button-secondary" href="<?php echo esc_url( $context['dashboard_url'] ); ?>">
						<?php esc_html_e( 'Translate labels', 'admin-site-enhancements' ); ?>
					</a>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Inject the label-status column into ASE definition list tables.
	 *
	 * @param array $columns Current columns.
	 * @return array
	 */
	public function inject_label_status_column( $columns ) {
		if ( isset( $columns['asenha_wpml_label_status'] ) ) {
			return $columns;
		}

		$new_columns    = array();
		$inserted       = false;
		$preferred_keys = array( 'title', 'basic', 'placement' );

		foreach ( $columns as $key => $label ) {
			$new_columns[ $key ] = $label;

			if ( ! $inserted && in_array( $key, $preferred_keys, true ) ) {
				$new_columns['asenha_wpml_label_status'] = __( 'Label translation', 'admin-site-enhancements' );
				$inserted                                = true;
			}
		}

		if ( ! $inserted ) {
			if ( isset( $new_columns['date'] ) ) {
				$date_column = $new_columns['date'];
				unset( $new_columns['date'] );
				$new_columns['asenha_wpml_label_status'] = __( 'Label translation', 'admin-site-enhancements' );
				$new_columns['date']                     = $date_column;
			} else {
				$new_columns['asenha_wpml_label_status'] = __( 'Label translation', 'admin-site-enhancements' );
			}
		}

		return $new_columns;
	}

	/**
	 * Render label-status column content.
	 *
	 * @param string $column_name Current column.
	 * @param int    $post_id     Current row ID.
	 * @return void
	 */
	public function render_label_status_column( $column_name, $post_id ) {
		if ( 'asenha_wpml_label_status' !== $column_name ) {
			return;
		}

		$context = $this->get_package_context( get_post( $post_id ) );
		if ( empty( $context ) ) {
			echo '&mdash;';
			return;
		}

		$this->render_status_label( $context['status'] );

		if (
			ASENHA_CCT_WPML_Package::STATUS_NOT_REGISTERED === $context['status'] &&
			! empty( $context['column_help_text'] )
		) {
			?>
			<span
				class="dashicons dashicons-editor-help asenha-cct-wpml-help"
				title="<?php echo esc_attr( $context['column_help_text'] ); ?>"
				aria-hidden="true"
			></span>
			<span class="screen-reader-text">
				<?php echo esc_html( $context['column_help_text'] ); ?>
			</span>
			<?php
		}
	}

	/**
	 * Render an intro note for the field-group builder.
	 *
	 * @return void
	 */
	public function render_field_group_intro_affordance() {
		$this->render_current_post_inline_affordance(
			__( 'Field group titles, field labels, instructions, and choice labels are translated in WPML.', 'admin-site-enhancements' ),
			array(
				'show_status' => true,
				'block'       => true,
			)
		);
	}

	/**
	 * Render an inline note for the CPT basic fields.
	 *
	 * @return void
	 */
	public function render_post_type_basic_affordance() {
		$this->render_current_post_inline_affordance(
			__( 'The singular and plural names here are translated in WPML.', 'admin-site-enhancements' ),
			array(
				'show_status' => true,
				'block'       => true,
			)
		);
	}

	/**
	 * Render an inline note for the CPT labels tab.
	 *
	 * @return void
	 */
	public function render_post_type_labels_affordance() {
		$this->render_current_post_inline_affordance(
			__( 'All post type labels in this tab are managed as WPML string-package labels.', 'admin-site-enhancements' ),
			array(
				'show_status' => true,
				'block'       => true,
			)
		);
	}

	/**
	 * Render an inline note for the taxonomy basic fields.
	 *
	 * @return void
	 */
	public function render_taxonomy_basic_affordance() {
		$this->render_current_post_inline_affordance(
			__( 'The singular and plural names here are translated in WPML.', 'admin-site-enhancements' ),
			array(
				'show_status' => true,
				'block'       => true,
			)
		);
	}

	/**
	 * Render an inline note for the taxonomy labels tab.
	 *
	 * @return void
	 */
	public function render_taxonomy_labels_affordance() {
		$this->render_current_post_inline_affordance(
			__( 'All taxonomy labels in this tab are managed as WPML string-package labels.', 'admin-site-enhancements' ),
			array(
				'show_status' => true,
				'block'       => true,
			)
		);
	}

	/**
	 * Render an inline note for options-page labels.
	 *
	 * @return void
	 */
	public function render_options_page_basic_affordance() {
		$this->render_current_post_inline_affordance(
			__( 'Page title and menu title are translated in WPML.', 'admin-site-enhancements' ),
			array(
				'show_status' => true,
				'block'       => true,
			)
		);
	}

	/**
	 * Print lightweight admin styles for the WPML UX.
	 *
	 * @return void
	 */
	public function print_admin_styles() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( empty( $screen ) || ! in_array( $screen->post_type, array( 'asenha_cfgroup', 'asenha_cpt', 'asenha_ctax', 'options_page_config' ), true ) ) {
			return;
		}
		?>
		<style>
			.asenha-cct-wpml-panel p:last-child,
			.asenha-cct-wpml-inline-note:last-child {
				margin-bottom: 0;
			}

			.asenha-cct-wpml-help {
				color: #646970;
				font-size: 16px;
				line-height: 1.3;
				margin-left: 4px;
				vertical-align: text-top;
			}

			.asenha-cct-wpml-inline-note {
				margin: 8px 0 0;
			}

			#poststuff .postbox .inside p.asenha-cct-wpml-inline-note.asenha-cct-wpml-inline-note--block {
				margin: 8px 0;
				padding: 10px 12px;
				border-left: 4px solid #72aee6;
				background: #f0f6fc;
			}

			.cct-form-input .asenha-cct-wpml-inline-note--block {
				align-self: stretch;
				box-sizing: border-box;
			}

			.column-asenha_wpml_label_status {
				width: 150px;
			}
		</style>
		<?php
	}

	/**
	 * Render an inline affordance for the current edit screen.
	 *
	 * @param string $message Intro message.
	 * @param array  $args    Display arguments.
	 * @return void
	 */
	private function render_current_post_inline_affordance( $message, $args = array() ) {
		$post = get_post();
		if ( ! $post instanceof WP_Post ) {
			return;
		}

		$context = $this->get_package_context( $post );
		if ( empty( $context ) ) {
			return;
		}

		$defaults = array(
			'show_status'                 => false,
			'block'                       => false,
			'suppress_not_registered'     => false,
			'suppress_st_inactive_notice' => false,
		);
		$args     = wp_parse_args( $args, $defaults );

		if (
			$args['suppress_not_registered'] &&
			ASENHA_CCT_WPML_Package::STATUS_NOT_REGISTERED === $context['status']
		) {
			return;
		}

		$classes = 'asenha-cct-wpml-inline-note';
		if ( $args['block'] ) {
			$classes .= ' asenha-cct-wpml-inline-note--block';
		}
		?>
		<p class="<?php echo esc_attr( $classes ); ?>">
			<?php echo esc_html( $message ); ?>

			<?php if (
				! $args['suppress_st_inactive_notice'] &&
				ASENHA_CCT_WPML_Package::STATUS_ST_INACTIVE === $context['status']
			) : ?>
				<?php esc_html_e( ' WPML String Translation is required to translate these labels.', 'admin-site-enhancements' ); ?>
			<?php elseif ( ASENHA_CCT_WPML_Package::STATUS_NOT_REGISTERED === $context['status'] ) : ?>
				<?php echo esc_html( $context['inline_not_registered_message'] ); ?>
			<?php elseif ( ! empty( $context['dashboard_url'] ) ) : ?>
				<a href="<?php echo esc_url( $context['dashboard_url'] ); ?>">
					<?php esc_html_e( 'Translate now', 'admin-site-enhancements' ); ?>
				</a>
				<?php if ( $args['show_status'] ) : ?>
					<?php
					printf(
						/* translators: %s: label translation status, e.g. Status: Complete, Status: Not translated */
						' <span class="asenha-cct-wpml-inline-status">(%s)</span>',
						esc_html(
							sprintf(
								/* translators: %s: label translation status, e.g. Not translated, Complete */
								__( 'Status: %s', 'admin-site-enhancements' ),
								ASENHA_CCT_WPML_Package::get_status_label_for( $context['status'] )
							)
						)
					);
					?>
				<?php endif; ?>
			<?php endif; ?>
		</p>
		<?php
	}

	/**
	 * Build package metadata for a definition post.
	 *
	 * @param WP_Post|null $post Definition post.
	 * @return array
	 */
	private function get_package_context( $post ) {
		if ( ! $post instanceof WP_Post ) {
			return array();
		}

		$package          = null;
		$missing_identity = false;

		switch ( $post->post_type ) {
			case 'asenha_cfgroup':
				$package = new ASENHA_CCT_WPML_Package(
					'cfgroup-' . $post->ID,
					ASENHA_CCT_WPML_Package::KIND_FIELD_GROUP
				);
				break;

			case 'asenha_cpt':
				$slug = get_post_meta( $post->ID, 'cpt_key', true );
				if ( '' !== (string) $slug ) {
					$package = new ASENHA_CCT_WPML_Package(
						'cpt-' . $slug,
						ASENHA_CCT_WPML_Package::KIND_POST_TYPE
					);
				} else {
					$missing_identity = true;
				}
				break;

			case 'asenha_ctax':
				$slug = get_post_meta( $post->ID, 'ctax_key', true );
				if ( '' !== (string) $slug ) {
					$package = new ASENHA_CCT_WPML_Package(
						'taxonomy-' . $slug,
						ASENHA_CCT_WPML_Package::KIND_TAXONOMY
					);
				} else {
					$missing_identity = true;
				}
				break;

			case 'options_page_config':
				$slug = get_post_meta( $post->ID, 'options_page_menu_slug', true );
				if ( '' !== (string) $slug ) {
					$package = new ASENHA_CCT_WPML_Package(
						'options-page-' . $slug,
						ASENHA_CCT_WPML_Package::KIND_OPTIONS_PAGE
					);
				} else {
					$missing_identity = true;
				}
				break;

			default:
				return array();
		}

		$status                    = $package ? $package->get_status() : ASENHA_CCT_WPML_Package::STATUS_NOT_REGISTERED;
		$backfill_complete         = ASENHA_CCT_WPML::is_package_backfill_complete();
		$requires_save             = ASENHA_CCT_WPML_Package::STATUS_NOT_REGISTERED === $status && ( $missing_identity || 'auto-draft' === $post->post_status );
		$not_registered_message    = '';
		$inline_not_registered_message = '';
		$column_help_text          = '';

		if ( ASENHA_CCT_WPML_Package::STATUS_NOT_REGISTERED === $status ) {
			if ( $requires_save ) {
				$not_registered_message        = __( 'Save this definition first to register its label strings in WPML.', 'admin-site-enhancements' );
				$inline_not_registered_message = __( ' Save this definition first so ASE can register its labels.', 'admin-site-enhancements' );
				$column_help_text              = __( 'Save this item first so ASE can register its labels in WPML.', 'admin-site-enhancements' );
			} elseif ( $backfill_complete ) {
				$not_registered_message        = __( 'ASE could not find a registered WPML label package for this definition yet. Update it once to retry registration.', 'admin-site-enhancements' );
				$inline_not_registered_message = __( ' Update this definition once to retry label registration in WPML.', 'admin-site-enhancements' );
				$column_help_text              = __( 'Update this item once to retry label registration in WPML.', 'admin-site-enhancements' );
			} else {
				$not_registered_message        = __( 'ASE is preparing WPML label packages for existing definitions. Refresh in a moment, or update this definition once to retry immediately.', 'admin-site-enhancements' );
				$inline_not_registered_message = __( ' ASE is preparing its WPML label package. Refresh shortly, or update this definition once to retry immediately.', 'admin-site-enhancements' );
				$column_help_text              = __( 'ASE is preparing this item for WPML label registration.', 'admin-site-enhancements' );
			}
		}

		return array(
			'package'                      => $package,
			'status'                       => $status,
			'dashboard_url'                => $package ? $package->get_translation_dashboard_url() : '',
			'requires_save'                => $requires_save,
			'not_registered_message'       => $not_registered_message,
			'inline_not_registered_message' => $inline_not_registered_message,
			'column_help_text'             => $column_help_text,
		);
	}

	/**
	 * Render a plain-text status label.
	 *
	 * @param string $status Internal status.
	 * @return void
	 */
	private function render_status_label( $status ) {
		echo esc_html( ASENHA_CCT_WPML_Package::get_status_label_for( $status ) );
	}
}
