<?php
/**
 * ASE Custom Content Types WPML bridge.
 *
 * @package Admin and Site Enhancements
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ASENHA_CCT_WPML {

	/**
	 * Option used to track the one-time package backfill migration.
	 *
	 * @var string
	 */
	const PACKAGE_BACKFILL_OPTION = 'asenha_cct_wpml_package_backfill_version';

	/**
	 * Current package backfill migration version.
	 *
	 * @var string
	 */
	const PACKAGE_BACKFILL_VERSION = '4';

	/**
	 * Option used to track the one-time CFG index backfill migration.
	 *
	 * @var string
	 */
	const CFG_INDEX_BACKFILL_OPTION = 'asenha_cct_wpml_cfg_index_backfill_version';

	/**
	 * Current CFG index backfill migration version.
	 *
	 * @var string
	 */
	const CFG_INDEX_BACKFILL_VERSION = '11';

	/**
	 * Transient used to retain stale WPML repeater-job diagnostics after a source save.
	 *
	 * @var string
	 */
	const STALE_WPML_JOB_DIAGNOSTICS_TRANSIENT = 'asenha_cct_wpml_stale_job_diagnostics';

	/**
	 * Top-level translation editor group ID for ASE package strings.
	 *
	 * @var string
	 */
	const TM_GROUP_ID_ASE = 'asenha';

	/**
	 * Translation editor subgroup ID for ASE field-group title strings.
	 *
	 * @var string
	 */
	const TM_GROUP_ID_FIELD_GROUP_TITLE = 'asenha-field-group-title';

	/**
	 * Translation editor subgroup ID for ASE field-group field-label strings.
	 *
	 * @var string
	 */
	const TM_GROUP_ID_CUSTOM_FIELDS = 'asenha-custom-fields';

	/**
	 * Start marker for auto-generated CFG post field metadata in wpml-config.xml.
	 *
	 * @var string
	 */
	const WPML_CONFIG_DYNAMIC_CUSTOM_FIELDS_START = '<!-- ASE dynamic CFG custom fields: start -->';

	/**
	 * End marker for auto-generated CFG post field metadata in wpml-config.xml.
	 *
	 * @var string
	 */
	const WPML_CONFIG_DYNAMIC_CUSTOM_FIELDS_END = '<!-- ASE dynamic CFG custom fields: end -->';

	/**
	 * Start marker for auto-generated CFG term field metadata in wpml-config.xml.
	 *
	 * @var string
	 */
	const WPML_CONFIG_DYNAMIC_CUSTOM_TERM_FIELDS_START = '<!-- ASE dynamic CFG custom term fields: start -->';

	/**
	 * End marker for auto-generated CFG term field metadata in wpml-config.xml.
	 *
	 * @var string
	 */
	const WPML_CONFIG_DYNAMIC_CUSTOM_TERM_FIELDS_END = '<!-- ASE dynamic CFG custom term fields: end -->';

	/**
	 * Start marker for auto-generated CCT post-type metadata in the site wpml-config.xml.
	 *
	 * @var string
	 */
	const WPML_CONFIG_DYNAMIC_CCT_CUSTOM_TYPES_START = '<!-- ASE dynamic CCT custom types: start -->';

	/**
	 * End marker for auto-generated CCT post-type metadata in the site wpml-config.xml.
	 *
	 * @var string
	 */
	const WPML_CONFIG_DYNAMIC_CCT_CUSTOM_TYPES_END = '<!-- ASE dynamic CCT custom types: end -->';

	/**
	 * Start marker for auto-generated CCT taxonomy metadata in the site wpml-config.xml.
	 *
	 * @var string
	 */
	const WPML_CONFIG_DYNAMIC_CCT_TAXONOMIES_START = '<!-- ASE dynamic CCT taxonomies: start -->';

	/**
	 * End marker for auto-generated CCT taxonomy metadata in the site wpml-config.xml.
	 *
	 * @var string
	 */
	const WPML_CONFIG_DYNAMIC_CCT_TAXONOMIES_END = '<!-- ASE dynamic CCT taxonomies: end -->';

	/**
	 * Option used to track the one-time translated-post taxonomy backfill migration.
	 *
	 * @var string
	 */
	const TAXONOMY_SYNC_BACKFILL_OPTION = 'asenha_cct_wpml_taxonomy_sync_backfill_version';

	/**
	 * Current translated-post taxonomy backfill migration version.
	 *
	 * @var string
	 */
	const TAXONOMY_SYNC_BACKFILL_VERSION = '1';

	/**
	 * Singleton instance.
	 *
	 * @var ASENHA_CCT_WPML|null
	 */
	private static $instance = null;

	/**
	 * Guard duplicate rebuilds per request.
	 *
	 * @var array<string,bool>
	 */
	private $processed_duplicates = array();

	/**
	 * Track whether ST-dependent hooks were registered.
	 *
	 * @var bool
	 */
	private $string_translation_hooks_registered = false;

	/**
	 * Guard duplicate backfill runs per request.
	 *
	 * @var bool
	 */
	private $package_backfill_ran = false;

	/**
	 * Guard duplicate field-group title refresh runs per request.
	 *
	 * @var bool
	 */
	private $field_group_title_refresh_ran = false;

	/**
	 * Definition post IDs whose WPML strings were registered during this request.
	 *
	 * @var array<int,bool>
	 */
	private $registered_definition_strings_post_ids = array();

	/**
	 * Guard duplicate wpml-config sync runs per request.
	 *
	 * @var bool
	 */
	private $wpml_config_sync_ran = false;

	/**
	 * Cached CFG field lookup keyed by field name.
	 *
	 * @var array<string,array>|null
	 */
	private $cfg_field_lookup = null;

	/**
	 * Guard CFG index rebuild re-entrancy during CFG()->save().
	 *
	 * @var bool
	 */
	private $rebuilding_cfg_index = false;

	/**
	 * Posts or terms queued for CFG index rebuild on shutdown.
	 *
	 * @var array<string,array{object_type:string,object_id:int}>
	 */
	private $posts_pending_cfg_rebuild = array();

	/**
	 * Request-scoped CFG index integrity check results.
	 *
	 * Keys: "{check}:{object_type}:{object_id}" => bool.
	 *
	 * @var array<string,bool>
	 */
	private $cfg_index_integrity_cache = array();

	/**
	 * Request-scoped completed TM job translate coverage keyed by post ID.
	 *
	 * Null means no completed job (skip growth trim). Otherwise field_id => count.
	 *
	 * @var array<int,array<int,int>|null>
	 */
	private $completed_job_translate_coverage_cache = array();

	/**
	 * Guard duplicate CFG index backfill runs per request.
	 *
	 * @var bool
	 */
	private $cfg_index_backfill_ran = false;

	/**
	 * Guard duplicate translated-post taxonomy backfill runs per request.
	 *
	 * @var bool
	 */
	private $taxonomy_sync_backfill_ran = false;

	/**
	 * Preferred meta values from a WPML translation job, keyed by post ID then meta key.
	 *
	 * @var array<int,array<string,array<int,array{value:mixed,ordinal:int|null,field_type:string}>>>
	 */
	private $wpml_translation_field_overrides = array();

	/**
	 * Whether the current repeater rebuild has an unsafe/ambiguous mapping.
	 *
	 * A rebuild must not delete the existing CFG rows when the source, target,
	 * and WPML candidates cannot be aligned with confidence.
	 *
	 * @var bool
	 */
	private $repeater_mapping_ambiguous = false;

	/**
	 * Repeater mapping warnings collected during the current rebuild.
	 *
	 * @var array<int,string>
	 */
	private $repeater_mapping_warnings = array();

	/**
	 * Cached parsed site wpml-config.xml payload.
	 *
	 * @var array<string,mixed>|null
	 */
	private $parsed_site_wpml_config = null;

	/**
	 * Get singleton instance.
	 *
	 * @return ASENHA_CCT_WPML
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->add_hooks();
	}

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	private function add_hooks() {
		add_filter( 'asenha_cct_wpml_duplicate_post_fields', array( $this, 'duplicate_post_fields' ), 10, 5 );
		add_action( 'wpml_after_copy_custom_field', array( $this, 'after_copy_custom_field' ), 10, 3 );
		add_action( 'wpml_after_copy_term_field', array( $this, 'after_copy_term_field' ), 10, 3 );
		add_filter( 'wpml_duplicate_generic_string', array( $this, 'duplicate_generic_string' ), 10, 3 );
		add_filter( 'wpml_active_string_package_kinds', array( $this, 'register_active_package_kinds' ) );

		add_filter( 'asenha_cfgroup_save_field_group_fields', array( $this, 'inject_wpml_field_settings' ), 10, 4 );
		add_filter( 'asenha_cfgroup_save_field_group_extras', array( $this, 'inject_wpml_mode_into_extras' ), 10, 4 );
		add_filter( 'cfgroup_get_input_fields', array( $this, 'translate_input_fields' ), 10, 2 );
		add_filter( 'asenha_cfgroup_loaded_group', array( $this, 'translate_loaded_field_group' ), 10, 2 );
		add_filter( 'asenha_cfgroup_read_fields', array( $this, 'translate_read_fields' ), 10, 5 );

		add_action( 'add_meta_boxes_asenha_cfgroup', array( $this, 'add_field_group_meta_box' ) );
		add_action( 'asenha_cfgroup_field_settings_rows', array( $this, 'render_field_setting_row' ) );
		add_action( 'admin_print_footer_scripts', array( $this, 'print_cfgroup_admin_assets' ) );
		add_action( 'save_post', array( $this, 'sync_field_group_settings' ), 30, 3 );

		add_action( 'add_meta_boxes_asenha_cpt', array( $this, 'add_post_type_translation_meta_box' ) );
		add_action( 'add_meta_boxes_asenha_ctax', array( $this, 'add_taxonomy_translation_meta_box' ) );
		add_action( 'save_post', array( $this, 'save_post_type_translation_mode' ), 30, 3 );
		add_action( 'save_post', array( $this, 'save_taxonomy_translation_mode' ), 30, 3 );

		add_filter( 'asenha_cct_registered_post_type_labels', array( $this, 'translate_post_type_labels' ), 10, 4 );
		add_filter( 'asenha_cct_registered_post_type_args', array( $this, 'filter_post_type_args' ), 10, 4 );
		add_filter( 'asenha_cct_registered_taxonomy_labels', array( $this, 'translate_taxonomy_labels' ), 10, 4 );
		add_filter( 'asenha_cct_registered_taxonomy_args', array( $this, 'filter_taxonomy_args' ), 10, 4 );

		add_filter( 'asenha_cct_options_page_screen_meta', array( $this, 'translate_options_page_screen_meta' ), 10, 2 );
		add_filter( 'asenha_cct_options_page_runtime_screen', array( $this, 'resolve_options_page_runtime_screen' ) );
		add_filter( 'asenha_cct_options_page_ids', array( $this, 'filter_runtime_options_page_ids' ) );

		add_action( 'admin_notices', array( $this, 'maybe_render_definition_notice' ) );
		add_action( 'admin_notices', array( $this, 'maybe_render_stale_wpml_job_notice' ), 20 );
		add_action( 'plugins_loaded', array( $this, 'maybe_register_string_translation_hooks' ), 20 );
		add_action( 'admin_init', array( $this, 'maybe_backfill_existing_packages' ), 20 );
		add_action( 'admin_init', array( $this, 'maybe_refresh_field_group_package_titles' ), 25 );
		add_action( 'admin_init', array( $this, 'maybe_sync_dynamic_wpml_config' ), 30 );
		add_action( 'admin_init', array( $this, 'maybe_backfill_orphaned_cfg_indexes' ), 35 );
		add_action( 'admin_init', array( $this, 'maybe_backfill_missing_translated_post_taxonomies' ), 36 );

		add_filter( 'wpml_config_array', array( $this, 'merge_content_wpml_config' ), 10, 1 );

		add_action( 'cfgroup_after_save_input', array( $this, 'maybe_schedule_cfg_rebuilds_after_cfgroup_save' ), 10, 1 );
		add_action( 'wpml_pro_translation_completed', array( $this, 'rebuild_cfg_index_after_wpml_translation' ), 10, 3 );
		add_action( 'wpml_tm_job_saved', array( $this, 'rebuild_cfg_index_after_tm_job_saved' ), 10, 1 );
		add_action( 'added_post_meta', array( $this, 'maybe_schedule_cfg_index_rebuild_on_meta_change' ), 10, 4 );
		add_action( 'updated_post_meta', array( $this, 'maybe_schedule_cfg_index_rebuild_on_meta_change' ), 10, 4 );
		add_action( 'deleted_post_meta', array( $this, 'maybe_schedule_cfg_index_rebuild_on_meta_delete' ), 10, 4 );
		add_action( 'added_term_meta', array( $this, 'maybe_schedule_cfg_index_rebuild_on_term_meta_change' ), 10, 4 );
		add_action( 'updated_term_meta', array( $this, 'maybe_schedule_cfg_index_rebuild_on_term_meta_change' ), 10, 4 );
		add_action( 'deleted_term_meta', array( $this, 'maybe_schedule_cfg_index_rebuild_on_term_meta_delete' ), 10, 4 );
		add_action( 'shutdown', array( $this, 'process_pending_cfg_index_rebuilds' ), 1 );
		add_filter( 'asenha_cfgroup_maybe_reindex_from_meta', array( $this, 'maybe_reindex_cfg_from_meta_on_read' ), 10, 5 );

		add_filter( 'wpml_editor_cf_to_display', array( $this, 'normalize_hyperlink_field_for_editor' ), 10, 2 );
		add_filter( 'wpml_tm_save_translation_cf', array( $this, 'restore_hyperlink_field_after_editor_save' ), 10, 3 );
		add_filter( 'wpml_tm_job_field_is_translatable', array( $this, 'allow_numeric_cfg_field_translation' ), 10, 2 );
		add_filter( 'wpml_tm_adjust_translation_fields', array( $this, 'adjust_translation_editor_fields' ), 10, 2 );
		add_filter( 'wpml_tm_adjust_translation_job', array( $this, 'reorder_translation_editor_fields' ), 10, 2 );

		$this->maybe_register_string_translation_hooks();
	}

	/**
	 * Register ASE package kinds with WPML.
	 *
	 * @param array $kinds Declared package kinds.
	 * @return array
	 */
	public function register_active_package_kinds( $kinds ) {
		return array_merge( $kinds, ASENHA_CCT_WPML_Package::get_active_package_kinds() );
	}

	/**
	 * Register ST-dependent hooks once WPML String Translation is available.
	 *
	 * @return void
	 */
	public function maybe_register_string_translation_hooks() {
		if ( $this->string_translation_hooks_registered || ! defined( 'WPML_ST_VERSION' ) ) {
			return;
		}

		add_action( 'save_post', array( $this, 'register_field_group_strings' ), 20, 3 );
		add_action( 'save_post', array( $this, 'register_post_type_strings' ), 20, 3 );
		add_action( 'save_post', array( $this, 'register_taxonomy_strings' ), 20, 3 );
		add_action( 'save_post', array( $this, 'register_options_page_strings' ), 20, 3 );

		$this->string_translation_hooks_registered = true;
	}

	/**
	 * Check whether the one-time package backfill already ran.
	 *
	 * @return bool
	 */
	public static function is_package_backfill_complete() {
		return self::PACKAGE_BACKFILL_VERSION === (string) get_option( self::PACKAGE_BACKFILL_OPTION, '' );
	}

	/**
	 * Backfill packages for existing ASE definitions once WPML is ready.
	 *
	 * @return void
	 */
	public function maybe_backfill_existing_packages() {
		if ( $this->package_backfill_ran || ! defined( 'WPML_ST_VERSION' ) ) {
			return;
		}

		$this->package_backfill_ran = true;

		if ( ! current_user_can( 'manage_options' ) || self::is_package_backfill_complete() ) {
			return;
		}

		$repaired_any = false;

		foreach ( $this->get_definition_post_types_for_backfill() as $post_type ) {
			if ( $this->backfill_definition_post_type_packages( $post_type ) ) {
				$repaired_any = true;
			}
		}

		if ( $repaired_any ) {
			$this->maybe_refresh_wpml_package_cache();
		}

		update_option( self::PACKAGE_BACKFILL_OPTION, self::PACKAGE_BACKFILL_VERSION, true );
	}

	/**
	 * Refresh stored field-group package titles on relevant WPML admin pages.
	 *
	 * @return void
	 */
	public function maybe_refresh_field_group_package_titles() {
		if (
			$this->field_group_title_refresh_ran ||
			! defined( 'WPML_ST_VERSION' ) ||
			! is_admin() ||
			wp_doing_ajax() ||
			! current_user_can( 'manage_options' ) ||
			! $this->is_wpml_field_group_package_refresh_request()
		) {
			return;
		}

		$this->field_group_title_refresh_ran = true;

		$repaired_any = false;

		foreach ( $this->get_definition_post_types_for_backfill() as $post_type ) {
			if ( $this->backfill_definition_post_type_packages( $post_type ) ) {
				$repaired_any = true;
			}
		}

		if ( $repaired_any ) {
			$this->maybe_refresh_wpml_package_cache();
		}
	}

	/**
	 * Register the field-group translation mode metabox.
	 *
	 * @return void
	 */
	public function add_field_group_meta_box() {
		add_meta_box(
			'asenha-cct-wpml-field-group-mode',
			__( 'Translation Mode', 'admin-site-enhancements' ),
			array( $this, 'render_field_group_meta_box' ),
			'asenha_cfgroup',
			'side',
			'high'
		);
	}

	/**
	 * Render the field-group translation mode metabox.
	 *
	 * @param WP_Post $post Current post.
	 * @return void
	 */
	public function render_field_group_meta_box( $post ) {
		$extras       = get_post_meta( $post->ID, 'cfgroup_extras', true );
		$mode         = $this->get_field_group_mode( $extras );
		$descriptions = $this->get_field_group_mode_descriptions();

		wp_nonce_field( 'asenha_cct_wpml_field_group_mode', 'asenha_cct_wpml_field_group_mode_nonce' );
		?>
		<select id="asenha-cct-wpml-field-group-mode-select" name="cfgroup[extras][cfgroup_wpml_mode]" class="widefat">
			<?php foreach ( $this->get_field_group_modes() as $value => $label ) : ?>
				<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $mode, $value ); ?>>
					<?php echo esc_html( $label ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<p class="description asenha-cfgroup-wpml-mode-description">
			<?php echo esc_html( isset( $descriptions[ $mode ] ) ? $descriptions[ $mode ] : '' ); ?>
		</p>
		<?php
	}

	/**
	 * Render per-field WPML settings row.
	 *
	 * @param object $field Field object from CFG.
	 * @return void
	 */
	public function render_field_setting_row( $field ) {
		if ( ! is_object( $field ) || $this->is_layout_field_type( $field->type ) ) {
			return;
		}

		$preference = isset( $field->wpml_cf_preferences )
			? (int) $field->wpml_cf_preferences
			: (int) $this->get_default_preference_for_field( $field, 'advanced' );
		?>
		<tr class="field_wpml asenha-cfgroup-wpml-field-setting">
			<td class="label">
				<label>
					<?php esc_html_e( 'Translation Preference', 'admin-site-enhancements' ); ?>
					<div class="cfgroup_tooltip">?
						<div class="tooltip_inner">
							<?php esc_html_e( 'How this field value should behave when WPML copies or translates content.', 'admin-site-enhancements' ); ?>
						</div>
					</div>
				</label>
			</td>
			<td>
				<select name="cfgroup[fields][<?php echo esc_attr( $field->weight ); ?>][wpml_cf_preferences]" class="widefat">
					<?php foreach ( $this->get_field_preference_labels() as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $preference, $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</td>
		</tr>
		<?php
	}

	/**
	 * Print admin assets for the CFG builder.
	 *
	 * @return void
	 */
	public function print_cfgroup_admin_assets() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( empty( $screen ) || 'asenha_cfgroup' !== $screen->post_type || 'post' !== $screen->base ) {
			return;
		}
		?>
		<style>
			.asenha-cfgroup-wpml-field-setting { display: none; }
			.asenha-cfgroup-wpml-field-setting select { max-width: 260px; }
		</style>
		<script>
		(function($) {
			var modeDescriptions = <?php echo wp_json_encode( $this->get_field_group_mode_descriptions() ); ?>;

			function aseToggleWpmlFieldRows() {
				var mode = $('#asenha-cct-wpml-field-group-mode-select').val();
				if ('advanced' === mode) {
					$('.asenha-cfgroup-wpml-field-setting').show();
				} else {
					$('.asenha-cfgroup-wpml-field-setting').hide();
				}
			}

			function aseUpdateWpmlModeDescription() {
				var mode = $('#asenha-cct-wpml-field-group-mode-select').val();
				var description = modeDescriptions[mode] || '';

				$('.asenha-cfgroup-wpml-mode-description').text(description);
			}

			function aseSyncWpmlFieldGroupModeUi() {
				aseToggleWpmlFieldRows();
				aseUpdateWpmlModeDescription();
			}

			$(function() {
				aseSyncWpmlFieldGroupModeUi();
				$(document).on('change', '#asenha-cct-wpml-field-group-mode-select', aseSyncWpmlFieldGroupModeUi);
				$(document).on('click', '.cfgroup_add_field', function() {
					setTimeout(aseSyncWpmlFieldGroupModeUi, 20);
				});
			});
		})(jQuery);
		</script>
		<?php
	}

	/**
	 * Save field-group defaults into the CFG payload.
	 *
	 * @param array $new_fields       Normalized field definitions.
	 * @param int   $post_id          Field-group post ID.
	 * @param array $params           Raw save params.
	 * @param array $prepared_fields  Prepared field rows before final normalization.
	 * @return array
	 */
	public function inject_wpml_field_settings( $new_fields, $post_id, $params, $prepared_fields ) {
		unset( $post_id );

		$mode              = $this->get_field_group_mode( isset( $params['extras'] ) ? $params['extras'] : array() );
		$prepared_by_id    = array();
		$preference_labels = $this->get_field_preference_labels();

		foreach ( (array) $prepared_fields as $prepared_field ) {
			if ( isset( $prepared_field['id'] ) ) {
				$prepared_by_id[ (int) $prepared_field['id'] ] = $prepared_field;
			}
		}

		foreach ( $new_fields as $index => $field ) {
			if ( empty( $field['id'] ) || $this->is_layout_field_type( $field['type'] ) ) {
				continue;
			}

			$submitted = isset( $prepared_by_id[ (int) $field['id'] ]['wpml_cf_preferences'] )
				? (int) $prepared_by_id[ (int) $field['id'] ]['wpml_cf_preferences']
				: null;

			$preference = ( 'advanced' === $mode && isset( $preference_labels[ $submitted ] ) )
				? $submitted
				: $this->get_default_preference_for_field( $field, $mode );

			$new_fields[ $index ]['wpml_cf_preferences'] = (int) $preference;
		}

		return $new_fields;
	}

	/**
	 * Save field-group-level WPML mode.
	 *
	 * @param array  $extras    Field-group extras.
	 * @param int    $post_id   Field-group post ID.
	 * @param array  $params    Raw save params.
	 * @param string $placement CFG placement.
	 * @return array
	 */
	public function inject_wpml_mode_into_extras( $extras, $post_id, $params, $placement ) {
		unset( $post_id, $placement );

		$mode = $this->get_field_group_mode( isset( $params['extras'] ) ? $params['extras'] : array() );

		$extras['cfgroup_wpml_mode'] = $mode;

		return $extras;
	}

	/**
	 * Sync ASE field preferences into WPML TM settings.
	 *
	 * @param int     $post_id Field-group post ID.
	 * @param WP_Post $post    Current post.
	 * @param bool    $update  Whether this is an update.
	 * @return void
	 */
	public function sync_field_group_settings( $post_id, $post, $update ) {
		unset( $update );

		if ( ! $this->is_expected_definition_post_type( $post, 'asenha_cfgroup' ) ) {
			return;
		}

		if ( ! $this->is_valid_admin_save( $post_id, $post ) ) {
			return;
		}

		if (
			! isset( $_POST['asenha_cct_wpml_field_group_mode_nonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['asenha_cct_wpml_field_group_mode_nonce'] ) ), 'asenha_cct_wpml_field_group_mode' )
		) {
			return;
		}

		$fields = get_post_meta( $post_id, 'cfgroup_fields', true );
		if ( ! is_array( $fields ) ) {
			return;
		}

		$settings = $this->get_wpml_setting( 'translation-management', array() );
		$changed  = false;

		foreach ( array( 'custom_fields_translation', 'custom_term_fields_translation' ) as $setting_key ) {
			if ( ! isset( $settings[ $setting_key ] ) || ! is_array( $settings[ $setting_key ] ) ) {
				$settings[ $setting_key ] = array();
			}

			foreach ( $fields as $field ) {
				if ( empty( $field['name'] ) || $this->is_layout_field_type( $field['type'] ) ) {
					continue;
				}

				$preference = isset( $field['wpml_cf_preferences'] ) ? (int) $field['wpml_cf_preferences'] : $this->get_default_preference_for_field( $field );
				if (
					! isset( $settings[ $setting_key ][ $field['name'] ] ) ||
					(int) $settings[ $setting_key ][ $field['name'] ] !== (int) $preference
				) {
					$settings[ $setting_key ][ $field['name'] ] = (int) $preference;
					$changed                                     = true;
				}
			}
		}

		if ( $changed ) {
			$this->set_wpml_setting( 'translation-management', $settings );
		}

		$this->cfg_field_lookup = null;
		$this->sync_dynamic_wpml_config( true );
	}

	/**
	 * Keep the generated site wpml-config.xml in sync on admin requests.
	 *
	 * @return void
	 */
	public function maybe_sync_dynamic_wpml_config() {
		if ( ! is_admin() || wp_doing_ajax() || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$this->sync_dynamic_wpml_config();
	}

	/**
	 * Synchronize site-specific WPML config into wp-content/ase/wpml-config.xml.
	 *
	 * @param bool $force Whether to bypass the per-request guard.
	 * @return void
	 */
	private function sync_dynamic_wpml_config( $force = false ) {
		if ( $this->wpml_config_sync_ran && ! $force ) {
			return;
		}

		$this->wpml_config_sync_ran = true;

		$file_path = $this->get_site_wpml_config_file_path();
		$directory = dirname( $file_path );

		if ( ! wp_mkdir_p( $directory ) ) {
			return;
		}

		$new_xml     = $this->build_site_wpml_config_xml();
		$current_xml = file_exists( $file_path ) ? file_get_contents( $file_path ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- ASE reads its generated site WPML config for change detection.

		if ( false === $current_xml ) {
			$current_xml = '';
		}

		if ( $new_xml === $current_xml ) {
			return;
		}

		if ( $this->write_site_wpml_config_file( $new_xml ) ) {
			$this->parsed_site_wpml_config = null;
		}
	}

	/**
	 * Build the full site-specific wpml-config.xml document.
	 *
	 * @return string
	 */
	private function build_site_wpml_config_xml() {
		$cct_sections = $this->build_cct_wpml_config_sections();
		$cfg_sections = $this->build_dynamic_wpml_config_sections();

		$lines = array(
			'<?xml version="1.0"?>',
			'<wpml-config>',
			'  <!-- Auto-generated by Admin and Site Enhancements. Do not edit manually. -->',
			'  ' . self::WPML_CONFIG_DYNAMIC_CCT_CUSTOM_TYPES_START,
			$this->render_cct_custom_types_xml( $cct_sections['custom_types'] ),
			'  ' . self::WPML_CONFIG_DYNAMIC_CCT_CUSTOM_TYPES_END,
			'  ' . self::WPML_CONFIG_DYNAMIC_CCT_TAXONOMIES_START,
			$this->render_cct_taxonomies_xml( $cct_sections['taxonomies'] ),
			'  ' . self::WPML_CONFIG_DYNAMIC_CCT_TAXONOMIES_END,
			'  ' . self::WPML_CONFIG_DYNAMIC_CUSTOM_FIELDS_START,
			$this->render_dynamic_wpml_config_section_xml( 'custom-fields', 'custom-field', $cfg_sections['custom-fields'] ),
			'  ' . self::WPML_CONFIG_DYNAMIC_CUSTOM_FIELDS_END,
			'  ' . self::WPML_CONFIG_DYNAMIC_CUSTOM_TERM_FIELDS_START,
			$this->render_dynamic_wpml_config_section_xml( 'custom-term-fields', 'custom-term-field', $cfg_sections['custom-term-fields'] ),
			'  ' . self::WPML_CONFIG_DYNAMIC_CUSTOM_TERM_FIELDS_END,
			'</wpml-config>',
			'',
		);

		return implode( "\n", $lines );
	}

	/**
	 * Build CCT post-type and taxonomy sections for the site wpml-config.xml.
	 *
	 * @return array{custom_types:array<int,array{slug:string,mode:string}>,taxonomies:array<int,array{slug:string,mode:string}>}
	 */
	private function build_cct_wpml_config_sections() {
		$custom_types = array();
		$taxonomies   = array();

		$cpt_posts = get_posts(
			array(
				'post_type'              => 'asenha_cpt',
				'post_status'            => 'publish',
				'numberposts'            => -1,
				'orderby'                => 'ID',
				'order'                  => 'ASC',
				'update_post_meta_cache' => true,
				'update_post_term_cache' => false,
				'suppress_filters'       => true,
				'fields'                 => 'ids',
			)
		);

		foreach ( $cpt_posts as $cpt_id ) {
			$slug = (string) get_post_meta( (int) $cpt_id, 'cpt_key', true );
			if ( '' === $slug ) {
				continue;
			}

			$mode = $this->get_object_translation_mode( $slug, 'custom_posts_sync_option' );
			if ( 'do_not_translate' === $mode ) {
				continue;
			}

			$custom_types[] = array(
				'slug' => $slug,
				'mode' => $mode,
			);
		}

		$ctax_posts = get_posts(
			array(
				'post_type'              => 'asenha_ctax',
				'post_status'            => 'publish',
				'numberposts'            => -1,
				'orderby'                => 'ID',
				'order'                  => 'ASC',
				'update_post_meta_cache' => true,
				'update_post_term_cache' => false,
				'suppress_filters'       => true,
				'fields'                 => 'ids',
			)
		);

		foreach ( $ctax_posts as $ctax_id ) {
			$slug = (string) get_post_meta( (int) $ctax_id, 'ctax_key', true );
			if ( '' === $slug ) {
				continue;
			}

			$mode = $this->get_object_translation_mode( $slug, 'taxonomies_sync_option' );
			if ( 'do_not_translate' === $mode ) {
				continue;
			}

			$taxonomies[] = array(
				'slug' => $slug,
				'mode' => $mode,
			);
		}

		usort(
			$custom_types,
			static function ( $left, $right ) {
				return strcmp( $left['slug'], $right['slug'] );
			}
		);
		usort(
			$taxonomies,
			static function ( $left, $right ) {
				return strcmp( $left['slug'], $right['slug'] );
			}
		);

		return array(
			'custom_types' => $custom_types,
			'taxonomies'   => $taxonomies,
		);
	}

	/**
	 * Render generated custom post type entries for the site wpml-config.xml.
	 *
	 * @param array<int,array{slug:string,mode:string}> $custom_types Generated CPT entries.
	 * @return string
	 */
	private function render_cct_custom_types_xml( $custom_types ) {
		if ( empty( $custom_types ) ) {
			return '  <!-- No ASE custom post types -->';
		}

		$lines   = array(
			'  <custom-types>',
			'    <!-- Auto-synced from published ASE Custom Post Types -->',
		);
		$lines[] = $this->render_cct_wpml_config_entries_xml( 'custom-type', $custom_types );
		$lines[] = '  </custom-types>';

		return implode( "\n", $lines );
	}

	/**
	 * Render generated taxonomy entries for the site wpml-config.xml.
	 *
	 * @param array<int,array{slug:string,mode:string}> $taxonomies Generated taxonomy entries.
	 * @return string
	 */
	private function render_cct_taxonomies_xml( $taxonomies ) {
		if ( empty( $taxonomies ) ) {
			return '  <!-- No ASE custom taxonomies -->';
		}

		$lines   = array(
			'  <taxonomies>',
			'    <!-- Auto-synced from published ASE Custom Taxonomies -->',
		);
		$lines[] = $this->render_cct_wpml_config_entries_xml( 'taxonomy', $taxonomies );
		$lines[] = '  </taxonomies>';

		return implode( "\n", $lines );
	}

	/**
	 * Render one list of generated CCT wpml-config entries.
	 *
	 * @param string                                     $entry_tag Entry tag name.
	 * @param array<int,array{slug:string,mode:string}> $entries   Generated entries.
	 * @return string
	 */
	private function render_cct_wpml_config_entries_xml( $entry_tag, $entries ) {
		$lines = array();

		foreach ( $entries as $entry ) {
			$attribute_xml = $this->render_wpml_translation_mode_attributes_xml( $entry['mode'] );

			$lines[] = sprintf(
				'    <%1$s%2$s>%3$s</%1$s>',
				$entry_tag,
				$attribute_xml,
				esc_xml( $entry['slug'] )
			);
		}

		return implode( "\n", $lines );
	}

	/**
	 * Render translate/display-as-translated attributes for wpml-config.xml.
	 *
	 * @param string $mode Translation mode slug.
	 * @return string
	 */
	private function render_wpml_translation_mode_attributes_xml( $mode ) {
		if ( 'display_as_translated' === $mode ) {
			return ' display-as-translated="1"';
		}

		return ' translate="1"';
	}

	/**
	 * Write the generated site wpml-config.xml atomically.
	 *
	 * @param string $xml Generated XML document.
	 * @return bool
	 */
	private function write_site_wpml_config_file( $xml ) {
		$file_path = $this->get_site_wpml_config_file_path();
		$temp_path = $file_path . '.tmp';

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- ASE must persist generated site WPML config outside the plugin package.
		if ( false === file_put_contents( $temp_path, $xml ) ) {
			return false;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- Atomic replace for generated site WPML config.
		return rename( $temp_path, $file_path );
	}

	/**
	 * Merge ASE site wpml-config.xml into WPML's parsed config array.
	 *
	 * @param array<string,mixed> $config_all WPML config array.
	 * @return array<string,mixed>
	 */
	public function merge_content_wpml_config( $config_all ) {
		$site_config = $this->get_parsed_site_wpml_config();
		if ( empty( $site_config ) ) {
			return $config_all;
		}

		if ( ! isset( $config_all['wpml-config'] ) || ! is_array( $config_all['wpml-config'] ) ) {
			$config_all['wpml-config'] = array();
		}

		$config_all['wpml-config'] = $this->merge_wpml_config_sections(
			$config_all['wpml-config'],
			$site_config,
			array(
				'custom-types',
				'taxonomies',
				'custom-fields',
				'custom-term-fields',
			)
		);

		return $config_all;
	}

	/**
	 * Merge selected wpml-config sections from the site overlay into WPML's base config.
	 *
	 * @param array<string,mixed> $base_config    Existing WPML config section.
	 * @param array<string,mixed> $overlay_config Site-specific overlay config.
	 * @param array<int,string>   $section_names  Section names to merge.
	 * @return array<string,mixed>
	 */
	private function merge_wpml_config_sections( $base_config, $overlay_config, $section_names ) {
		foreach ( $section_names as $section_name ) {
			if ( empty( $overlay_config[ $section_name ] ) || ! is_array( $overlay_config[ $section_name ] ) ) {
				continue;
			}

			$entry_tag = $this->get_wpml_config_entry_tag_for_section( $section_name );
			if ( '' === $entry_tag ) {
				continue;
			}

			$base_section = isset( $base_config[ $section_name ] ) && is_array( $base_config[ $section_name ] )
				? $base_config[ $section_name ]
				: array();

			$base_config[ $section_name ] = $this->merge_wpml_config_section_entries(
				$base_section,
				$overlay_config[ $section_name ],
				$entry_tag
			);
		}

		return $base_config;
	}

	/**
	 * Map a wpml-config section name to its entry tag.
	 *
	 * @param string $section_name Section name.
	 * @return string
	 */
	private function get_wpml_config_entry_tag_for_section( $section_name ) {
		$map = array(
			'custom-types'       => 'custom-type',
			'taxonomies'         => 'taxonomy',
			'custom-fields'      => 'custom-field',
			'custom-term-fields' => 'custom-term-field',
		);

		return isset( $map[ $section_name ] ) ? $map[ $section_name ] : '';
	}

	/**
	 * Append unique wpml-config entries from an overlay section.
	 *
	 * @param array<string,mixed> $base_section    Existing section config.
	 * @param array<string,mixed> $overlay_section Overlay section config.
	 * @param string              $entry_tag       Entry tag name.
	 * @return array<string,mixed>
	 */
	private function merge_wpml_config_section_entries( $base_section, $overlay_section, $entry_tag ) {
		if ( empty( $overlay_section[ $entry_tag ] ) ) {
			return $base_section;
		}

		$overlay_entries = $this->normalize_wpml_config_entries( $overlay_section[ $entry_tag ] );
		if ( empty( $overlay_entries ) ) {
			return $base_section;
		}

		$base_entries = array();
		if ( ! empty( $base_section[ $entry_tag ] ) ) {
			$base_entries = $this->normalize_wpml_config_entries( $base_section[ $entry_tag ] );
		}

		$existing_values = array();
		foreach ( $base_entries as $entry ) {
			if ( ! empty( $entry['value'] ) ) {
				$existing_values[ (string) $entry['value'] ] = true;
			}
		}

		foreach ( $overlay_entries as $entry ) {
			if ( empty( $entry['value'] ) || isset( $existing_values[ (string) $entry['value'] ] ) ) {
				continue;
			}

			$base_entries[] = $entry;
			$existing_values[ (string) $entry['value'] ] = true;
		}

		$base_section[ $entry_tag ] = $base_entries;

		return $base_section;
	}

	/**
	 * Normalize a wpml-config entry list to a numeric array.
	 *
	 * @param mixed $entries Raw entry list.
	 * @return array<int,array<string,mixed>>
	 */
	private function normalize_wpml_config_entries( $entries ) {
		if ( ! is_array( $entries ) ) {
			return array();
		}

		if ( isset( $entries['value'] ) || isset( $entries['attr'] ) ) {
			return array( $entries );
		}

		$normalized = array();
		foreach ( $entries as $entry ) {
			if ( is_array( $entry ) ) {
				$normalized[] = $entry;
			}
		}

		return $normalized;
	}

	/**
	 * Parse the generated site wpml-config.xml into WPML's config-array shape.
	 *
	 * @return array<string,mixed>
	 */
	private function get_parsed_site_wpml_config() {
		if ( null !== $this->parsed_site_wpml_config ) {
			return $this->parsed_site_wpml_config;
		}

		$this->parsed_site_wpml_config = array();
		$file_path                     = $this->get_site_wpml_config_file_path();

		if ( ! file_exists( $file_path ) ) {
			return $this->parsed_site_wpml_config;
		}

		if ( class_exists( 'WPML_XML2Array' ) && class_exists( 'WPML_XML_Config_Read_File' ) ) {
			$validate  = new WPML_XML_Config_Validate();
			$transform = new WPML_XML2Array();
			$reader    = new WPML_XML_Config_Read_File( $file_path, $validate, $transform );
			$config    = $reader->get();

			if ( is_array( $config ) && isset( $config['wpml-config'] ) && is_array( $config['wpml-config'] ) ) {
				$this->parsed_site_wpml_config = $config['wpml-config'];
			}
		}

		return $this->parsed_site_wpml_config;
	}

	/**
	 * Get the site-specific wpml-config.xml path.
	 *
	 * @return string
	 */
	private function get_site_wpml_config_file_path() {
		return trailingslashit( WP_CONTENT_DIR ) . 'ase/wpml-config.xml';
	}

	/**
	 * Build dynamic wpml-config.xml sections for post and term field metadata.
	 *
	 * @return array<string,array<string,array>>
	 */
	private function build_dynamic_wpml_config_sections() {
		$sections = array(
			'custom-fields'      => array(),
			'custom-term-fields' => array(),
		);

		foreach ( $this->get_cfg_field_groups_for_wpml_config() as $group ) {
			$section_name = $this->get_wpml_config_section_name_for_group( $group );
			if ( empty( $section_name ) ) {
				continue;
			}

			$group_title = ! empty( $group['title'] ) ? wp_strip_all_tags( $group['title'] ) : '';

			foreach ( (array) $group['fields'] as $field ) {
				$entry = $this->build_dynamic_wpml_config_entry( $field, $group_title );
				if ( empty( $entry['name'] ) ) {
					continue;
				}

				$field_name = $entry['name'];
				unset( $entry['name'] );

				if ( isset( $sections[ $section_name ][ $field_name ] ) ) {
					$sections[ $section_name ][ $field_name ] = $this->merge_dynamic_wpml_config_entry(
						$sections[ $section_name ][ $field_name ],
						$entry
					);
				} else {
					$sections[ $section_name ][ $field_name ] = $entry;
				}
			}
		}

		foreach ( $sections as $section_name => $entries ) {
			ksort( $entries );
			$sections[ $section_name ] = $entries;
		}

		return $sections;
	}

	/**
	 * Load raw published CFG field groups without WPML string translation overlays.
	 *
	 * @return array<int,array>
	 */
	private function get_cfg_field_groups_for_wpml_config() {
		$group_ids = get_posts(
			array(
				'post_type'              => 'asenha_cfgroup',
				'post_status'            => 'publish',
				'numberposts'            => -1,
				'fields'                 => 'ids',
				'orderby'                => 'ID',
				'order'                  => 'ASC',
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				'suppress_filters'       => true,
			)
		);

		$groups = array();

		foreach ( $group_ids as $group_id ) {
			$fields = get_post_meta( $group_id, 'cfgroup_fields', true );
			$rules  = get_post_meta( $group_id, 'cfgroup_rules', true );

			if ( ! is_array( $fields ) || ! is_array( $rules ) ) {
				continue;
			}

			$groups[ (int) $group_id ] = array(
				'id'     => (int) $group_id,
				'title'  => get_the_title( $group_id ),
				'fields' => $fields,
				'rules'  => $rules,
			);
		}

		return $groups;
	}

	/**
	 * Determine which wpml-config.xml section a CFG field group belongs to.
	 *
	 * @param array $group Field-group payload.
	 * @return string
	 */
	private function get_wpml_config_section_name_for_group( $group ) {
		if ( empty( $group['rules']['placement']['values'] ) ) {
			return '';
		}

		$placement = $group['rules']['placement']['values'];
		if ( is_array( $placement ) ) {
			$placement = reset( $placement );
		}

		switch ( $placement ) {
			case 'posts':
			case 'options-pages':
				return 'custom-fields';

			case 'taxonomy-terms':
				return 'custom-term-fields';

			default:
				return '';
		}
	}

	/**
	 * Build one dynamic wpml-config.xml entry from a CFG field definition.
	 *
	 * @param array  $field       CFG field definition.
	 * @param string $group_title Human group title.
	 * @return array<string,string>
	 */
	private function build_dynamic_wpml_config_entry( $field, $group_title ) {
		if (
			empty( $field['name'] ) ||
			empty( $field['type'] ) ||
			$this->is_layout_field_type( $field['type'] )
		) {
			return array();
		}

		$action = $this->get_wpml_action_for_preference(
			isset( $field['wpml_cf_preferences'] ) ? (int) $field['wpml_cf_preferences'] : $this->get_default_preference_for_field( $field )
		);

		return array(
			'name'   => (string) $field['name'],
			'action' => $action,
			'label'  => ! empty( $field['label'] ) ? wp_strip_all_tags( $field['label'] ) : (string) $field['name'],
			'group'  => $group_title,
			'style'  => ( 'translate' === $action ) ? $this->get_wpml_editor_style_for_field_type( $field['type'] ) : '',
		);
	}

	/**
	 * Merge duplicate dynamic wpml-config entries for a shared field name.
	 *
	 * @param array $existing Existing config.
	 * @param array $candidate Candidate config.
	 * @return array
	 */
	private function merge_dynamic_wpml_config_entry( $existing, $candidate ) {
		if ( $this->get_wpml_action_priority( $candidate['action'] ) > $this->get_wpml_action_priority( $existing['action'] ) ) {
			$existing['action'] = $candidate['action'];

			if ( ! empty( $candidate['style'] ) ) {
				$existing['style'] = $candidate['style'];
			}
		}

		if ( empty( $existing['label'] ) && ! empty( $candidate['label'] ) ) {
			$existing['label'] = $candidate['label'];
		}

		if ( empty( $existing['group'] ) && ! empty( $candidate['group'] ) ) {
			$existing['group'] = $candidate['group'];
		}

		if ( empty( $existing['style'] ) && ! empty( $candidate['style'] ) ) {
			$existing['style'] = $candidate['style'];
		}

		return $existing;
	}

	/**
	 * Render one generated wpml-config.xml section.
	 *
	 * @param string $section_name Section tag name.
	 * @param string $entry_tag    Entry tag name.
	 * @param array  $entries      Generated entries keyed by field name.
	 * @return string
	 */
	private function render_dynamic_wpml_config_section_xml( $section_name, $entry_tag, $entries ) {
		if ( empty( $entries ) ) {
			return '  <!-- No dynamic CFG metadata -->';
		}

		$lines   = array( '  <' . $section_name . '>' );
		$lines[] = '    <!-- Auto-synced from published ASE Custom Field Groups -->';

		foreach ( $entries as $field_name => $entry ) {
			$lines[] = '    ' . $this->render_dynamic_wpml_config_entry_xml( $entry_tag, $field_name, $entry );
		}

		$lines[] = '  </' . $section_name . '>';

		return implode( "\n", $lines );
	}

	/**
	 * Render one generated wpml-config.xml entry.
	 *
	 * @param string $entry_tag  Entry tag name.
	 * @param string $field_name CFG meta key.
	 * @param array  $entry      Entry config.
	 * @return string
	 */
	private function render_dynamic_wpml_config_entry_xml( $entry_tag, $field_name, $entry ) {
		$attributes = array(
			'action' => $entry['action'],
		);

		if ( 'custom-field' === $entry_tag ) {
			if ( ! empty( $entry['style'] ) ) {
				$attributes['style'] = $entry['style'];
			}

			if ( ! empty( $entry['label'] ) ) {
				$attributes['label'] = $entry['label'];
			}

			if ( ! empty( $entry['group'] ) ) {
				$attributes['group'] = $entry['group'];
			}
		}

		$attribute_xml = '';

		foreach ( $attributes as $attribute_name => $attribute_value ) {
			$attribute_xml .= sprintf(
				' %s="%s"',
				$attribute_name,
				esc_xml( (string) $attribute_value )
			);
		}

		return sprintf(
			'<%1$s%2$s>%3$s</%1$s>',
			$entry_tag,
			$attribute_xml,
			esc_xml( $field_name )
		);
	}

	/**
	 * Replace a marked dynamic section inside wpml-config.xml.
	 *
	 * @param string $xml          Current file contents.
	 * @param string $start_marker Section start marker.
	 * @param string $end_marker   Section end marker.
	 * @param string $replacement  Replacement XML.
	 * @return string
	 */
	private function replace_dynamic_wpml_config_section( $xml, $start_marker, $end_marker, $replacement ) {
		$start = strpos( $xml, $start_marker );
		$end   = strpos( $xml, $end_marker );

		if ( false === $start || false === $end || $end < $start ) {
			return $xml;
		}

		$end += strlen( $end_marker );

		return substr_replace(
			$xml,
			$start_marker . "\n" . $replacement . "\n  " . $end_marker,
			$start,
			$end - $start
		);
	}

	/**
	 * Normalize serialized hyperlink fields for WPML's translation editor.
	 *
	 * @param object $element WPML job element.
	 * @param object $job     WPML job object.
	 * @return object
	 */
	public function normalize_hyperlink_field_for_editor( $element, $job ) {
		unset( $job );

		if (
			! is_object( $element ) ||
			empty( $element->field_type ) ||
			! isset( $element->field_data )
		) {
			return $element;
		}

		$field_definition = $this->get_cfg_field_definition_by_name( (string) $element->field_type );
		if ( empty( $field_definition ) || 'hyperlink' !== $field_definition['type'] ) {
			return $element;
		}

		$decoded_value = $this->decode_wpml_job_field_data(
			$element->field_data,
			isset( $element->field_format ) ? $element->field_format : ''
		);

		$normalized_value = $this->normalize_hyperlink_editor_value( $decoded_value );
		if ( null !== $normalized_value ) {
			$element->field_data = $normalized_value;
		}

		return $element;
	}

	/**
	 * Re-serialize hyperlink fields after WPML saves translated content.
	 *
	 * @param array  $field     Current field payload.
	 * @param string $fieldname Custom field name.
	 * @param array  $data      Full WPML save payload.
	 * @return array
	 */
	public function restore_hyperlink_field_after_editor_save( $field, $fieldname, $data ) {
		unset( $data );

		if ( ! is_array( $field ) || ! isset( $field['data'] ) ) {
			return $field;
		}

		$field_definition = $this->get_cfg_field_definition_by_name( (string) $fieldname );
		if ( empty( $field_definition ) || 'hyperlink' !== $field_definition['type'] ) {
			return $field;
		}

		$parsed_value = $this->parse_hyperlink_editor_value( $field['data'] );
		if ( null !== $parsed_value ) {
			$field['data'] = maybe_serialize( $parsed_value );
		}

		return $field;
	}

	/**
	 * Allow translated ASE number fields into WPML jobs even when the value is numeric-only.
	 *
	 * @param bool  $is_translatable Existing translatable flag.
	 * @param array $job_translate   WPML job row data.
	 * @return bool
	 */
	public function allow_numeric_cfg_field_translation( $is_translatable, $job_translate ) {
		if ( $is_translatable || empty( $job_translate['field_type'] ) ) {
			return $is_translatable;
		}

		$field_definition = $this->get_cfg_field_definition_by_name( (string) $job_translate['field_type'] );
		if (
			empty( $field_definition ) ||
			'number' !== $field_definition['type'] ||
			(int) WPML_TRANSLATE_CUSTOM_FIELD !== (int) ( isset( $field_definition['wpml_cf_preferences'] ) ? $field_definition['wpml_cf_preferences'] : $this->get_default_preference_for_type( 'number' ) )
		) {
			return $is_translatable;
		}

		$field_value = $this->decode_wpml_job_field_data(
			isset( $job_translate['field_data'] ) ? $job_translate['field_data'] : '',
			isset( $job_translate['field_format'] ) ? $job_translate['field_format'] : ''
		);

		return is_scalar( $field_value ) && is_numeric( trim( (string) $field_value ) );
	}

	/**
	 * Decode a WPML job field value (base64 and/or gzcompressed).
	 *
	 * @param mixed  $value  Raw value.
	 * @param string $format Field format hint (e.g. base64). Optional.
	 * @return mixed
	 */
	private function decode_wpml_job_field_data( $value, $format = '' ) {
		if ( ! is_string( $value ) || '' === $value ) {
			return $value;
		}

		$data = $value;

		if ( 'base64' === $format || ( '' === $format && false !== base64_decode( $value, true ) && preg_match( '/^[A-Za-z0-9\/\r\n+]*={0,2}$/', $value ) ) ) {
			$decoded = base64_decode( $value, true );
			if ( false !== $decoded ) {
				$data = $decoded;
			}
		}

		$uncompressed = $this->maybe_gzuncompress_string( $data );
		if ( is_string( $uncompressed ) && $uncompressed !== $data ) {
			return $uncompressed;
		}

		// If format was base64 and decompress failed, return base64-decoded bytes/string.
		if ( $data !== $value ) {
			return $data;
		}

		return $value;
	}

	/**
	 * Attempt gzuncompress / gzdecode / gzinflate on a binary string.
	 *
	 * @param string $data Binary or plain string.
	 * @return string
	 */
	private function maybe_gzuncompress_string( $data ) {
		if ( ! is_string( $data ) || '' === $data ) {
			return $data;
		}

		if ( function_exists( 'gzuncompress' ) ) {
			$out = @gzuncompress( $data ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( false !== $out && is_string( $out ) ) {
				return $out;
			}
		}

		if ( function_exists( 'gzdecode' ) ) {
			$out = @gzdecode( $data ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( false !== $out && is_string( $out ) ) {
				return $out;
			}
		}

		if ( function_exists( 'gzinflate' ) ) {
			$out = @gzinflate( $data ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( false !== $out && is_string( $out ) ) {
				return $out;
			}
			if ( strlen( $data ) > 2 ) {
				$out = @gzinflate( substr( $data, 2 ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				if ( false !== $out && is_string( $out ) ) {
					return $out;
				}
			}
		}

		return $data;
	}

	/**
	 * Convert a stored hyperlink value into translator-friendly JSON.
	 *
	 * @param mixed $value Stored hyperlink value.
	 * @return string|null
	 */
	private function normalize_hyperlink_editor_value( $value ) {
		$value = maybe_unserialize( $value );

		if ( ! is_array( $value ) ) {
			return null;
		}

		return wp_json_encode( $this->normalize_hyperlink_value_array( $value ), JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT );
	}

	/**
	 * Parse translator-edited hyperlink JSON back into the stored array shape.
	 *
	 * @param mixed $value Submitted translator value.
	 * @return array|null
	 */
	private function parse_hyperlink_editor_value( $value ) {
		if ( is_array( $value ) ) {
			return $this->normalize_hyperlink_value_array( $value );
		}

		if ( ! is_string( $value ) ) {
			return null;
		}

		$decoded = json_decode( trim( $value ), true );
		if ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded ) ) {
			return $this->normalize_hyperlink_value_array( $decoded );
		}

		$maybe_unserialized = maybe_unserialize( $value );
		if ( is_array( $maybe_unserialized ) ) {
			return $this->normalize_hyperlink_value_array( $maybe_unserialized );
		}

		return null;
	}

	/**
	 * Normalize hyperlink arrays to the stored key set.
	 *
	 * @param array $value Raw hyperlink array.
	 * @return array
	 */
	private function normalize_hyperlink_value_array( $value ) {
		return array(
			'url'    => isset( $value['url'] ) ? (string) $value['url'] : '',
			'text'   => isset( $value['text'] ) ? (string) $value['text'] : '',
			'target' => isset( $value['target'] ) ? (string) $value['target'] : '',
		);
	}

	/**
	 * Get one CFG field definition by field name.
	 *
	 * @param string $field_name CFG field name/meta key.
	 * @return array
	 */
	private function get_cfg_field_definition_by_name( $field_name ) {
		if ( null === $this->cfg_field_lookup ) {
			$this->cfg_field_lookup = $this->build_cfg_field_lookup();
		}

		return isset( $this->cfg_field_lookup[ $field_name ] ) ? $this->cfg_field_lookup[ $field_name ] : array();
	}

	/**
	 * Build a cached CFG field lookup keyed by field name.
	 *
	 * @return array<string,array>
	 */
	private function build_cfg_field_lookup() {
		$lookup = array();

		foreach ( $this->get_cfg_field_groups_for_wpml_config() as $group ) {
			foreach ( (array) $group['fields'] as $field ) {
				if (
					empty( $field['name'] ) ||
					empty( $field['type'] ) ||
					$this->is_layout_field_type( $field['type'] )
				) {
					continue;
				}

				if ( isset( $lookup[ $field['name'] ] ) ) {
					$lookup[ $field['name'] ] = $this->merge_cfg_field_lookup_entry( $lookup[ $field['name'] ], $field );
				} else {
					$lookup[ $field['name'] ] = $field;
				}
			}
		}

		return $lookup;
	}

	/**
	 * Merge duplicate CFG field definitions for one field name.
	 *
	 * @param array $existing Existing definition.
	 * @param array $candidate Candidate definition.
	 * @return array
	 */
	private function merge_cfg_field_lookup_entry( $existing, $candidate ) {
		$existing_pref = isset( $existing['wpml_cf_preferences'] ) ? (int) $existing['wpml_cf_preferences'] : $this->get_default_preference_for_field( $existing );
		$candidate_pref = isset( $candidate['wpml_cf_preferences'] ) ? (int) $candidate['wpml_cf_preferences'] : $this->get_default_preference_for_field( $candidate );

		if ( $this->get_wpml_action_priority( $this->get_wpml_action_for_preference( $candidate_pref ) ) > $this->get_wpml_action_priority( $this->get_wpml_action_for_preference( $existing_pref ) ) ) {
			return $candidate;
		}

		return $existing;
	}

	/**
	 * Map WPML preference constants to wpml-config.xml action strings.
	 *
	 * @param int $preference WPML custom-field preference.
	 * @return string
	 */
	private function get_wpml_action_for_preference( $preference ) {
		switch ( (int) $preference ) {
			case WPML_TRANSLATE_CUSTOM_FIELD:
				return 'translate';

			case WPML_COPY_ONCE_CUSTOM_FIELD:
				return 'copy-once';

			case WPML_IGNORE_CUSTOM_FIELD:
				return 'ignore';

			case WPML_COPY_CUSTOM_FIELD:
			default:
				return 'copy';
		}
	}

	/**
	 * Priority used to merge duplicate action definitions.
	 *
	 * @param string $action wpml-config.xml action.
	 * @return int
	 */
	private function get_wpml_action_priority( $action ) {
		switch ( $action ) {
			case 'translate':
				return 3;

			case 'copy-once':
				return 2;

			case 'copy':
				return 1;

			default:
				return 0;
		}
	}

	/**
	 * Map CFG field types to WPML editor styles.
	 *
	 * @param string $field_type CFG field type.
	 * @return string
	 */
	private function get_wpml_editor_style_for_field_type( $field_type ) {
		switch ( $field_type ) {
			case 'text':
			case 'number':
			case 'date':
			case 'time':
			case 'datetime':
			case 'color':
			case 'select':
			case 'radio':
			case 'true_false':
				return 'line';

			case 'textarea':
			case 'hyperlink':
			case 'checkbox':
				return 'textarea';

			case 'wysiwyg':
				return 'visual';

			default:
				return '';
		}
	}

	/**
	 * Add slug translation metabox for generated post types.
	 *
	 * @return void
	 */
	public function add_post_type_translation_meta_box() {
		add_meta_box(
			'asenha-cct-wpml-post-type-mode',
			__( 'Slug Translation', 'admin-site-enhancements' ),
			array( $this, 'render_post_type_translation_meta_box' ),
			'asenha_cpt',
			'side',
			'default'
		);
	}

	/**
	 * Add slug translation metabox for generated taxonomies.
	 *
	 * @return void
	 */
	public function add_taxonomy_translation_meta_box() {
		add_meta_box(
			'asenha-cct-wpml-taxonomy-mode',
			__( 'Slug Translation', 'admin-site-enhancements' ),
			array( $this, 'render_taxonomy_translation_meta_box' ),
			'asenha_ctax',
			'side',
			'default'
		);
	}

	/**
	 * Render post-type translation metabox.
	 *
	 * @param WP_Post $post Current post.
	 * @return void
	 */
	public function render_post_type_translation_meta_box( $post ) {
		$slug = get_post_meta( $post->ID, 'cpt_key', true );
		$mode = $this->get_object_translation_mode( $slug, 'custom_posts_sync_option' );

		$this->render_object_translation_mode_control(
			'post_type',
			$mode,
			$slug
		);
	}

	/**
	 * Render taxonomy translation metabox.
	 *
	 * @param WP_Post $post Current post.
	 * @return void
	 */
	public function render_taxonomy_translation_meta_box( $post ) {
		$slug = get_post_meta( $post->ID, 'ctax_key', true );
		$mode = $this->get_object_translation_mode( $slug, 'taxonomies_sync_option' );

		$this->render_object_translation_mode_control(
			'taxonomy',
			$mode,
			$slug
		);
	}

	/**
	 * Shared translation-mode control renderer.
	 *
	 * @param string $object_type Either post_type or taxonomy.
	 * @param string $mode        Current mode slug.
	 * @param string $slug        Generated object slug.
	 * @return void
	 */
	private function render_object_translation_mode_control( $object_type, $mode, $slug ) {
		wp_nonce_field( 'asenha_cct_wpml_translation_mode', 'asenha_cct_wpml_translation_mode_nonce' );
		?>
		<?php if ( empty( $slug ) ) : ?>
			<p class="description"><?php esc_html_e( 'Save this definition first so ASE can determine the generated slug.', 'admin-site-enhancements' ); ?></p>
		<?php else : ?>
			<p><code><?php echo esc_html( $slug ); ?></code></p>
		<?php endif; ?>
		<input type="hidden" name="asenha_cct_wpml_object_type" value="<?php echo esc_attr( $object_type ); ?>" />
		<select class="widefat asenha-cct-wpml-translation-mode" name="asenha_cct_wpml_translation_mode">
			<option value="do_not_translate" <?php selected( $mode, 'do_not_translate' ); ?>>
				<?php esc_html_e( 'Not translatable', 'admin-site-enhancements' ); ?>
			</option>
			<option value="translate" <?php selected( $mode, 'translate' ); ?>>
				<?php esc_html_e( 'Translatable', 'admin-site-enhancements' ); ?>
			</option>
			<option value="display_as_translated" <?php selected( $mode, 'display_as_translated' ); ?>>
				<?php esc_html_e( 'Translatable, use fallback if missing', 'admin-site-enhancements' ); ?>
			</option>
		</select>
		<?php if ( ! empty( $slug ) ) : ?>
			<?php
			$settings_anchor   = 'post_type' === $object_type ? 'ml-content-setup-sec-7' : 'ml-content-setup-sec-8';
			$settings_url      = admin_url( 'admin.php?page=tm/menu/settings#' . $settings_anchor );
			$show_slug_button = in_array( $mode, array( 'translate', 'display_as_translated' ), true );
			?>
			<p class="asenha-cct-wpml-translate-slug-wrap"<?php if ( ! $show_slug_button ) : ?> style="display:none;"<?php endif; ?>>
				<a class="button button-secondary" href="<?php echo esc_url( $settings_url ); ?>">
					<?php esc_html_e( 'Translate slug', 'admin-site-enhancements' ); ?>
				</a>
			</p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Save generated post-type translation mode.
	 *
	 * @param int     $post_id Field definition post ID.
	 * @param WP_Post $post    Current post.
	 * @param bool    $update  Whether this is an update.
	 * @return void
	 */
	public function save_post_type_translation_mode( $post_id, $post, $update ) {
		unset( $update );

		if ( ! $this->is_expected_definition_post_type( $post, 'asenha_cpt' ) ) {
			return;
		}

		if ( ! $this->is_valid_admin_save( $post_id, $post ) ) {
			return;
		}

		$slug = get_post_meta( $post_id, 'cpt_key', true );
		if ( empty( $slug ) ) {
			return;
		}

		$this->save_translation_mode_for_object( $slug, 'custom_posts_sync_option' );
		$this->sync_dynamic_wpml_config( true );
	}

	/**
	 * Save generated taxonomy translation mode.
	 *
	 * @param int     $post_id Field definition post ID.
	 * @param WP_Post $post    Current post.
	 * @param bool    $update  Whether this is an update.
	 * @return void
	 */
	public function save_taxonomy_translation_mode( $post_id, $post, $update ) {
		unset( $update );

		if ( ! $this->is_expected_definition_post_type( $post, 'asenha_ctax' ) ) {
			return;
		}

		if ( ! $this->is_valid_admin_save( $post_id, $post ) ) {
			return;
		}

		$slug = get_post_meta( $post_id, 'ctax_key', true );
		if ( empty( $slug ) ) {
			return;
		}

		$this->save_translation_mode_for_object( $slug, 'taxonomies_sync_option' );
		$this->sync_dynamic_wpml_config( true );
	}

	/**
	 * Persist translation mode to WPML settings.
	 *
	 * @param string $slug        Generated object slug.
	 * @param string $setting_key WPML setting key.
	 * @return void
	 */
	private function save_translation_mode_for_object( $slug, $setting_key ) {
		if (
			! isset( $_POST['asenha_cct_wpml_translation_mode_nonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['asenha_cct_wpml_translation_mode_nonce'] ) ), 'asenha_cct_wpml_translation_mode' )
		) {
			return;
		}

		$mode = isset( $_POST['asenha_cct_wpml_translation_mode'] )
			? sanitize_key( wp_unslash( $_POST['asenha_cct_wpml_translation_mode'] ) )
			: 'do_not_translate';

		if ( 'custom_posts_sync_option' === $setting_key ) {
			$this->apply_post_type_translation_mode( $slug, $mode );
		} else {
			$this->apply_taxonomy_translation_mode( $slug, $mode );
		}
	}

	/**
	 * Translate runtime post-type labels.
	 *
	 * @param array   $labels        Runtime labels.
	 * @param array   $args          Runtime args.
	 * @param int     $definition_id ASE definition post ID.
	 * @param string  $post_type_key Generated post type slug.
	 * @return array
	 */
	public function translate_post_type_labels( $labels, $args, $definition_id, $post_type_key ) {
		unset( $args );

		if ( ! defined( 'WPML_ST_VERSION' ) ) {
			return $labels;
		}

		return $this->translate_label_array(
			$labels,
			new ASENHA_CCT_WPML_Package( 'cpt-' . $post_type_key, ASENHA_CCT_WPML_Package::KIND_POST_TYPE ),
			'cpt',
			$post_type_key,
			(int) $definition_id,
			'post_type'
		);
	}

	/**
	 * Filter runtime post-type args.
	 *
	 * @param array  $args          Runtime args.
	 * @param array  $labels        Runtime labels.
	 * @param int    $definition_id ASE definition post ID.
	 * @param string $post_type_key Generated post type slug.
	 * @return array
	 */
	public function filter_post_type_args( $args, $labels, $definition_id, $post_type_key ) {
		$args['labels'] = $this->translate_post_type_labels( $labels, $args, (int) $definition_id, $post_type_key );

		return $args;
	}

	/**
	 * Translate runtime taxonomy labels.
	 *
	 * @param array   $labels         Runtime labels.
	 * @param array   $args           Runtime args.
	 * @param int     $definition_id  ASE definition post ID.
	 * @param string  $taxonomy_key   Generated taxonomy slug.
	 * @return array
	 */
	public function translate_taxonomy_labels( $labels, $args, $definition_id, $taxonomy_key ) {
		unset( $args );

		if ( ! defined( 'WPML_ST_VERSION' ) ) {
			return $labels;
		}

		return $this->translate_label_array(
			$labels,
			new ASENHA_CCT_WPML_Package( 'taxonomy-' . $taxonomy_key, ASENHA_CCT_WPML_Package::KIND_TAXONOMY ),
			'taxonomy',
			$taxonomy_key,
			(int) $definition_id,
			'taxonomy'
		);
	}

	/**
	 * Filter runtime taxonomy args.
	 *
	 * @param array  $args          Runtime args.
	 * @param array  $labels        Runtime labels.
	 * @param int    $definition_id ASE definition post ID.
	 * @param string $taxonomy_key  Generated taxonomy slug.
	 * @return array
	 */
	public function filter_taxonomy_args( $args, $labels, $definition_id, $taxonomy_key ) {
		$args['labels'] = $this->translate_taxonomy_labels( $labels, $args, (int) $definition_id, $taxonomy_key );

		return $args;
	}

	/**
	 * Translate options-page labels during screen registration.
	 *
	 * @param array $screen_meta Options page screen metadata.
	 * @param int   $config_id   Options page config post ID.
	 * @return array
	 */
	public function translate_options_page_screen_meta( $screen_meta, $config_id ) {
		$screen_meta['config_id'] = (int) $config_id;

		if ( ! defined( 'WPML_ST_VERSION' ) || empty( $screen_meta['name'] ) ) {
			return $screen_meta;
		}

		$package = new ASENHA_CCT_WPML_Package(
			'options-page-' . $screen_meta['name'],
			ASENHA_CCT_WPML_Package::KIND_OPTIONS_PAGE
		);

		$map = $this->get_options_page_label_runtime_to_meta_map();

		if ( ! empty( $screen_meta['page_title'] ) ) {
			$screen_meta['page_title'] = $this->translate_options_page_package_string(
				$package,
				$screen_meta['page_title'],
				$screen_meta['name'],
				$map['page_title'],
				'page-title',
				__( 'Page Title', 'admin-site-enhancements' )
			);
		}

		if ( ! empty( $screen_meta['menu_title'] ) ) {
			$screen_meta['menu_title'] = $this->translate_options_page_package_string(
				$package,
				$screen_meta['menu_title'],
				$screen_meta['name'],
				$map['menu_title'],
				'menu-title',
				__( 'Menu Title', 'admin-site-enhancements' )
			);
		}

		return $screen_meta;
	}

	/**
	 * Translate one options-page package string with meta-key and legacy fallback.
	 *
	 * @param ASENHA_CCT_WPML_Package $package     Package helper.
	 * @param string                  $value        String value.
	 * @param string                  $slug         Options page menu slug.
	 * @param string                  $meta_key     Registered WPML string key.
	 * @param string                  $legacy_key   Legacy WPML string key.
	 * @param string                  $title        Optional string title.
	 * @return string
	 */
	private function translate_options_page_package_string( $package, $value, $slug, $meta_key, $legacy_key, $title = '' ) {
		$string_meta = array(
			'namespace' => 'options-page',
			'id'        => $slug,
			'key'       => $meta_key,
		);

		if ( '' !== $title ) {
			$string_meta['title'] = $title;
		}

		$translated = $package->translate_string( $value, $string_meta );

		if ( $translated === $value && $meta_key !== $legacy_key ) {
			$string_meta['key'] = $legacy_key;
			$translated           = $package->translate_string( $value, $string_meta );
		}

		return $translated;
	}

	/**
	 * Resolve the runtime storage target for multilingual options pages.
	 *
	 * @param array $screen_meta Runtime screen metadata.
	 * @return array
	 */
	public function resolve_options_page_runtime_screen( $screen_meta ) {
		$current_language = $this->get_current_language();
		$default_language = $this->get_default_language();

		if ( empty( $screen_meta['id'] ) || empty( $screen_meta['config_id'] ) || empty( $current_language ) || $current_language === $default_language ) {
			return $screen_meta;
		}

		$companion_id = $this->get_or_create_options_page_companion( $screen_meta, $current_language );
		if ( $companion_id > 0 ) {
			$default_screen_id  = (int) $screen_meta['id'];
			$screen_meta['id']  = $companion_id;
			$screen_meta['base_options_page_id'] = $default_screen_id;

			if ( ! metadata_exists( 'post', $companion_id, '_asenha_wpml_seeded' ) ) {
				$this->perform_object_duplication(
					'post',
					$default_screen_id,
					$companion_id,
					$current_language,
					array(
						'field_groups' => isset( $screen_meta['field_groups'] ) ? $screen_meta['field_groups'] : array(),
					)
				);
				update_post_meta( $companion_id, '_asenha_wpml_seeded', 1 );
			}
		}

		return $screen_meta;
	}

	/**
	 * Return runtime options-page IDs for the current language.
	 *
	 * @param array $ids Existing IDs.
	 * @return array
	 */
	public function filter_runtime_options_page_ids( $ids ) {
		global $options_pages_screens;

		if ( is_array( $options_pages_screens ) && ! empty( $options_pages_screens ) ) {
			$ids = array();
			foreach ( $options_pages_screens as $screen_meta ) {
				if ( ! empty( $screen_meta['id'] ) ) {
					$ids[] = (int) $screen_meta['id'];
				}
			}
		}

		return array_values( array_unique( array_map( 'absint', (array) $ids ) ) );
	}

	/**
	 * Register field-group label strings.
	 *
	 * @param int     $post_id Field-group post ID.
	 * @param WP_Post $post    Current post.
	 * @param bool    $update  Whether this is an update.
	 * @return void
	 */
	public function register_field_group_strings( $post_id, $post, $update ) {
		unset( $update );

		if ( ! $this->is_expected_definition_post_type( $post, 'asenha_cfgroup' ) ) {
			return;
		}

		if ( ! $this->is_valid_admin_save( $post_id, $post ) ) {
			return;
		}

		if ( ! $this->is_valid_definition_form_save() ) {
			return;
		}

		$this->register_field_group_strings_for_definition( $post );
	}

	/**
	 * Register field-group label strings for one definition.
	 *
	 * @param WP_Post $post Field-group definition post.
	 * @return bool
	 */
	private function register_field_group_strings_for_definition( $post ) {
		$fields = get_post_meta( $post->ID, 'cfgroup_fields', true );
		if ( ! is_array( $fields ) ) {
			$fields = array();
		}

		$entries = $this->get_field_group_label_package_entries( $post, $fields );
		if ( empty( $entries ) ) {
			return false;
		}

		$package = new ASENHA_CCT_WPML_Package( 'cfgroup-' . $post->ID, ASENHA_CCT_WPML_Package::KIND_FIELD_GROUP );
		$package->start_registration();

		foreach ( $entries as $entry ) {
			$this->register_field_group_label_package_entry( $package, $entry );
		}

		$package->cleanup_unused_strings();

		return $package->has_registered_strings();
	}

	/**
	 * Register custom post type label strings.
	 *
	 * @param int     $post_id Field-group post ID.
	 * @param WP_Post $post    Current post.
	 * @param bool    $update  Whether this is an update.
	 * @return void
	 */
	public function register_post_type_strings( $post_id, $post, $update ) {
		unset( $update );

		if ( ! $this->is_expected_definition_post_type( $post, 'asenha_cpt' ) ) {
			return;
		}

		if ( ! $this->is_valid_admin_save( $post_id, $post ) ) {
			return;
		}

		$this->register_definition_strings_for_post_if_ready( $post );
	}

	/**
	 * Register custom post type label strings for one definition.
	 *
	 * @param WP_Post $post Custom post type definition post.
	 * @return bool
	 */
	private function register_post_type_strings_for_definition( $post ) {
		$slug = get_post_meta( $post->ID, 'cpt_key', true );
		if ( empty( $slug ) ) {
			return false;
		}

		$strings = $this->collect_post_type_strings_for_definition( $post );
		if ( empty( $strings ) ) {
			return false;
		}

		$package = new ASENHA_CCT_WPML_Package( 'cpt-' . $slug, ASENHA_CCT_WPML_Package::KIND_POST_TYPE );

		return $this->register_collected_package_strings( $package, $slug, 'cpt', $strings );
	}

	/**
	 * Register taxonomy label strings.
	 *
	 * @param int     $post_id Field-group post ID.
	 * @param WP_Post $post    Current post.
	 * @param bool    $update  Whether this is an update.
	 * @return void
	 */
	public function register_taxonomy_strings( $post_id, $post, $update ) {
		unset( $update );

		if ( ! $this->is_expected_definition_post_type( $post, 'asenha_ctax' ) ) {
			return;
		}

		if ( ! $this->is_valid_admin_save( $post_id, $post ) ) {
			return;
		}

		$this->register_definition_strings_for_post_if_ready( $post );
	}

	/**
	 * Register taxonomy label strings for one definition.
	 *
	 * @param WP_Post $post Taxonomy definition post.
	 * @return bool
	 */
	private function register_taxonomy_strings_for_definition( $post ) {
		$slug = get_post_meta( $post->ID, 'ctax_key', true );
		if ( empty( $slug ) ) {
			return false;
		}

		$strings = $this->collect_taxonomy_strings_for_definition( $post );
		if ( empty( $strings ) ) {
			return false;
		}

		$package = new ASENHA_CCT_WPML_Package( 'taxonomy-' . $slug, ASENHA_CCT_WPML_Package::KIND_TAXONOMY );

		return $this->register_collected_package_strings( $package, $slug, 'taxonomy', $strings );
	}

	/**
	 * Register options-page label strings.
	 *
	 * @param int     $post_id Field-group post ID.
	 * @param WP_Post $post    Current post.
	 * @param bool    $update  Whether this is an update.
	 * @return void
	 */
	public function register_options_page_strings( $post_id, $post, $update ) {
		unset( $update );

		if ( ! $this->is_expected_definition_post_type( $post, 'options_page_config' ) ) {
			return;
		}

		if ( ! $this->is_valid_admin_save( $post_id, $post ) ) {
			return;
		}

		$this->register_definition_strings_for_post_if_ready( $post );
	}

	/**
	 * Register options-page label strings for one definition.
	 *
	 * @param WP_Post $post Options-page definition post.
	 * @return bool
	 */
	private function register_options_page_strings_for_definition( $post ) {
		$slug = get_post_meta( $post->ID, 'options_page_menu_slug', true );
		if ( empty( $slug ) ) {
			return false;
		}

		$strings = $this->collect_options_page_strings_for_definition( $post );
		if ( empty( $strings ) ) {
			return false;
		}

		$package = new ASENHA_CCT_WPML_Package( 'options-page-' . $slug, ASENHA_CCT_WPML_Package::KIND_OPTIONS_PAGE );

		return $this->register_collected_package_strings( $package, $slug, 'options-page', $strings );
	}

	/**
	 * Translate loaded field-group data.
	 *
	 * @param array $group   Field-group data.
	 * @param int   $post_id Field-group ID.
	 * @return array
	 */
	public function translate_loaded_field_group( $group, $post_id ) {
		if ( ! defined( 'WPML_ST_VERSION' ) || ! is_array( $group ) ) {
			return $group;
		}

		$package = new ASENHA_CCT_WPML_Package( 'cfgroup-' . $post_id, ASENHA_CCT_WPML_Package::KIND_FIELD_GROUP );

		if ( ! empty( $group['title'] ) ) {
			$group['title'] = $this->translate_field_group_label_package_entry(
				$package,
				$this->get_field_group_title_package_entry( $post_id, $group['title'] )
			);
		}

		if ( ! empty( $group['fields'] ) && is_array( $group['fields'] ) ) {
			foreach ( $group['fields'] as $index => $field ) {
				$group['fields'][ $index ] = $this->translate_field_definition( $field, $package );
			}
		}

		return $group;
	}

	/**
	 * Translate runtime input fields.
	 *
	 * @param array $fields Input fields keyed by field ID.
	 * @param array $params Query params.
	 * @return array
	 */
	public function translate_input_fields( $fields, $params ) {
		unset( $params );

		if ( ! defined( 'WPML_ST_VERSION' ) || ! is_array( $fields ) ) {
			return $fields;
		}

		foreach ( $fields as $field_id => $field ) {
			if ( ! is_object( $field ) || empty( $field->group_id ) ) {
				continue;
			}

			$package         = new ASENHA_CCT_WPML_Package( 'cfgroup-' . $field->group_id, ASENHA_CCT_WPML_Package::KIND_FIELD_GROUP );
			$translated      = $this->translate_field_definition( (array) $field, $package );
			$fields[ $field_id ] = (object) $translated;
		}

		return $fields;
	}

	/**
	 * Translate field definitions used during reads.
	 *
	 * @param array       $fields      Field definitions keyed by field ID.
	 * @param int         $object_id   Current object ID.
	 * @param string      $object_type post or term.
	 * @param array       $options     CFG read options.
	 * @param array|false $group_ids   Matching field-group IDs.
	 * @return array
	 */
	public function translate_read_fields( $fields, $object_id, $object_type, $options, $group_ids ) {
		unset( $object_id, $object_type, $options, $group_ids );

		if ( ! defined( 'WPML_ST_VERSION' ) || ! is_array( $fields ) ) {
			return $fields;
		}

		foreach ( $fields as $field_id => $field ) {
			if ( ! is_object( $field ) || empty( $field->group_id ) ) {
				continue;
			}

			$package = new ASENHA_CCT_WPML_Package( 'cfgroup-' . $field->group_id, ASENHA_CCT_WPML_Package::KIND_FIELD_GROUP );
			$fields[ $field_id ] = (object) $this->translate_field_definition( (array) $field, $package );
		}

		return $fields;
	}

	/**
	 * Translate a single CFG field definition.
	 *
	 * @param array                    $field   Field definition.
	 * @param ASENHA_CCT_WPML_Package  $package Package helper.
	 * @return array
	 */
	private function translate_field_definition( $field, $package ) {
		if ( empty( $field['id'] ) ) {
			return $field;
		}

		if ( ! empty( $field['label'] ) ) {
			$field['label'] = $this->translate_field_group_label_package_entry(
				$package,
				$this->build_field_group_label_package_entry(
					$field['label'],
					$this->get_field_group_label_string_meta( $field ),
					0
				)
			);
		}

		if ( ! empty( $field['notes'] ) ) {
			$field['notes'] = $this->translate_field_group_label_package_entry(
				$package,
				$this->build_field_group_label_package_entry(
					$field['notes'],
					$this->get_field_group_notes_string_meta( $field ),
					0
				)
			);
		}

		if (
			isset( $field['options']['choices'] ) &&
			is_array( $field['options']['choices'] ) &&
			in_array( $field['type'], array( 'select', 'radio', 'checkbox' ), true )
		) {
			$choice_position = 1;
			foreach ( $field['options']['choices'] as $choice_key => $choice_label ) {
				$field['options']['choices'][ $choice_key ] = $this->translate_field_group_label_package_entry(
					$package,
					$this->build_field_group_label_package_entry(
						$choice_label,
						$this->get_field_group_choice_string_meta( $field, $choice_key, $choice_position ),
						0,
						array(
							$this->get_legacy_field_group_choice_string_meta( $field, $choice_key ),
						)
					)
				);

				++$choice_position;
			}
		}

		foreach ( $this->get_translatable_field_option_strings( $field ) as $option_key => $option_config ) {
			$field['options'][ $option_key ] = $this->translate_field_group_label_package_entry(
				$package,
				$this->build_field_group_label_package_entry(
					$option_config['value'],
					$this->get_field_group_option_string_meta( $field, $option_key ),
					0,
					array(
						$this->get_legacy_field_group_option_string_meta( $field, $option_key ),
					)
				)
			);
		}

		return $field;
	}

	/**
	 * Build the ordered list of field-group label package strings.
	 *
	 * @param WP_Post $post   Field-group definition post.
	 * @param array   $fields Saved field definitions.
	 * @return array<int,array<string,mixed>>
	 */
	private function get_field_group_label_package_entries( $post, $fields ) {
		$entries  = array();
		$location = 1;

		if ( ! empty( $post->post_title ) ) {
			$entries[] = $this->get_field_group_title_package_entry( $post->ID, $post->post_title, $location );

			++$location;
		}

		foreach ( $this->sort_field_group_definition_fields( $fields ) as $field ) {
			if ( empty( $field['id'] ) ) {
				continue;
			}

			if ( ! empty( $field['label'] ) ) {
				$entries[] = $this->build_field_group_label_package_entry(
					$field['label'],
					$this->get_field_group_label_string_meta( $field ),
					$location
				);

				++$location;
			}

			if ( ! empty( $field['notes'] ) ) {
				$entries[] = $this->build_field_group_label_package_entry(
					$field['notes'],
					$this->get_field_group_notes_string_meta( $field ),
					$location
				);

				++$location;
			}

			if (
				isset( $field['options']['choices'] ) &&
				is_array( $field['options']['choices'] ) &&
				in_array( $field['type'], array( 'select', 'radio', 'checkbox' ), true )
			) {
				$choice_position = 1;

				foreach ( $field['options']['choices'] as $choice_key => $choice_label ) {
					$entries[] = $this->build_field_group_label_package_entry(
						$choice_label,
						$this->get_field_group_choice_string_meta( $field, $choice_key, $choice_position ),
						$location,
						array(
							$this->get_legacy_field_group_choice_string_meta( $field, $choice_key ),
						)
					);

					++$choice_position;
					++$location;
				}
			}

			foreach ( $this->get_translatable_field_option_strings( $field ) as $option_key => $option_config ) {
				$entries[] = $this->build_field_group_label_package_entry(
					$option_config['value'],
					$this->get_field_group_option_string_meta( $field, $option_key ),
					$location,
					array(
						$this->get_legacy_field_group_option_string_meta( $field, $option_key ),
					)
				);

				++$location;
			}
		}

		return $entries;
	}

	/**
	 * Sort field definitions by builder weight.
	 *
	 * @param array $fields Saved field definitions.
	 * @return array<int,array>
	 */
	private function sort_field_group_definition_fields( $fields ) {
		if ( ! is_array( $fields ) ) {
			return array();
		}

		$sorted_fields = array_values( $fields );

		usort(
			$sorted_fields,
			static function( $field_a, $field_b ) {
				$weight_a = isset( $field_a['weight'] ) ? (int) $field_a['weight'] : PHP_INT_MAX;
				$weight_b = isset( $field_b['weight'] ) ? (int) $field_b['weight'] : PHP_INT_MAX;

				if ( $weight_a === $weight_b ) {
					$id_a = isset( $field_a['id'] ) ? (int) $field_a['id'] : 0;
					$id_b = isset( $field_b['id'] ) ? (int) $field_b['id'] : 0;

					return $id_a <=> $id_b;
				}

				return $weight_a <=> $weight_b;
			}
		);

		return $sorted_fields;
	}

	/**
	 * Build one field-group label package entry.
	 *
	 * @param string $value       String value.
	 * @param array  $meta        String metadata.
	 * @param int    $location    Package row order.
	 * @param array  $legacy_meta Legacy metadata variants.
	 * @return array<string,mixed>
	 */
	private function build_field_group_label_package_entry( $value, $meta, $location, $legacy_meta = array() ) {
		return array(
			'value'       => (string) $value,
			'meta'        => $meta,
			'location'    => (int) $location,
			'legacy_meta' => array_values( array_filter( $legacy_meta ) ),
		);
	}

	/**
	 * Build the package entry for a field-group title string.
	 *
	 * @param int    $post_id  Field-group post ID.
	 * @param string $value    Current title value.
	 * @param int    $location Package row order.
	 * @return array<string,mixed>
	 */
	private function get_field_group_title_package_entry( $post_id, $value, $location = 0 ) {
		return $this->build_field_group_label_package_entry(
			$value,
			$this->get_field_group_title_string_meta( $post_id ),
			$location,
			array(
				$this->get_legacy_field_group_title_string_meta( $post_id ),
			)
		);
	}

	/**
	 * Build metadata for a field-group title string.
	 *
	 * @param int $post_id Field-group post ID.
	 * @return array<string,string>
	 */
	private function get_field_group_title_string_meta( $post_id ) {
		return array(
			'namespace' => 'group',
			'id'        => $post_id,
			'key'       => 'title',
			'title'     => __( 'Field group title', 'admin-site-enhancements' ),
		);
	}

	/**
	 * Build legacy metadata for a field-group title string.
	 *
	 * @param int $post_id Field-group post ID.
	 * @return array<string,string>
	 */
	private function get_legacy_field_group_title_string_meta( $post_id ) {
		return array(
			'namespace' => 'field-group',
			'id'        => $post_id,
			'key'       => 'title',
		);
	}

	/**
	 * Build metadata for a field label string.
	 *
	 * @param array $field Field definition.
	 * @return array<string,string>
	 */
	private function get_field_group_label_string_meta( $field ) {
		return array(
			'namespace' => 'field',
			'id'        => $field['id'],
			'key'       => 'label',
			'title'     => __( 'Field label', 'admin-site-enhancements' ),
		);
	}

	/**
	 * Build metadata for a field notes string.
	 *
	 * @param array $field Field definition.
	 * @return array<string,string>
	 */
	private function get_field_group_notes_string_meta( $field ) {
		return array(
			'namespace' => 'field',
			'id'        => $field['id'],
			'key'       => 'notes',
			'title'     => __( 'Field instructions', 'admin-site-enhancements' ),
			'type'      => 'AREA',
		);
	}

	/**
	 * Build metadata for one field choice string.
	 *
	 * @param array  $field           Field definition.
	 * @param string $choice_key      Choice storage key.
	 * @param int    $choice_position Position inside the field.
	 * @return array<string,string>
	 */
	private function get_field_group_choice_string_meta( $field, $choice_key, $choice_position ) {
		return array(
			'namespace' => 'field',
			'id'        => $field['id'],
			'key'       => $this->get_field_group_choice_meta_key( $choice_key, $choice_position ),
			'title'     => __( 'Field choices', 'admin-site-enhancements' ),
		);
	}

	/**
	 * Build legacy metadata for one field choice string.
	 *
	 * @param array  $field      Field definition.
	 * @param string $choice_key Choice storage key.
	 * @return array<string,string>
	 */
	private function get_legacy_field_group_choice_string_meta( $field, $choice_key ) {
		return array(
			'namespace' => 'choice',
			'id'        => $field['id'],
			'key'       => 'choice-' . sanitize_key( (string) $choice_key ),
		);
	}

	/**
	 * Build metadata for one field option string.
	 *
	 * @param array  $field      Field definition.
	 * @param string $option_key Option key.
	 * @return array<string,string>
	 */
	private function get_field_group_option_string_meta( $field, $option_key ) {
		$title = __( 'Field option', 'admin-site-enhancements' );

		switch ( $option_key ) {
			case 'message':
				$title = __( 'Field message', 'admin-site-enhancements' );
				break;

			case 'button_label':
				$title = __( 'Repeater field button label', 'admin-site-enhancements' );
				break;

			case 'row_label':
				$title = __( 'Repeater field row label', 'admin-site-enhancements' );
				break;
		}

		return array(
			'namespace' => 'field',
			'id'        => $field['id'],
			'key'       => sanitize_key( (string) $option_key ),
			'title'     => $title,
		);
	}

	/**
	 * Build legacy metadata for one field option string.
	 *
	 * @param array  $field      Field definition.
	 * @param string $option_key Option key.
	 * @return array<string,string>
	 */
	private function get_legacy_field_group_option_string_meta( $field, $option_key ) {
		return array(
			'namespace' => 'field-option',
			'id'        => $field['id'],
			'key'       => sanitize_key( (string) $option_key ),
		);
	}

	/**
	 * Build the stable key used for a choice string.
	 *
	 * @param string $choice_key      Choice storage key.
	 * @param int    $choice_position Position inside the field.
	 * @return string
	 */
	private function get_field_group_choice_meta_key( $choice_key, $choice_position ) {
		$sanitized_choice_key = sanitize_key( (string) $choice_key );

		if ( '' === $sanitized_choice_key ) {
			$sanitized_choice_key = 'item-' . (int) $choice_position;
		}

		return 'choices-' . $sanitized_choice_key;
	}

	/**
	 * Adjust WPML translation-editor fields for ASE field-group label packages.
	 *
	 * @param array    $fields Translation editor fields.
	 * @param stdClass $job    WPML translation job.
	 * @return array
	 */
	public function adjust_translation_editor_fields( $fields, $job ) {
		if ( ! $this->is_field_group_label_translation_job( $job ) || ! is_array( $fields ) ) {
			return $fields;
		}

		foreach ( $fields as $index => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$parsed_string = $this->parse_field_group_label_translation_editor_string( $field );
			if ( empty( $parsed_string ) ) {
				continue;
			}

			$fields[ $index ]['_asenha_wpml_string_name'] = $field['title'];
			$fields[ $index ]['title'] = $this->get_field_group_label_translation_editor_title( $parsed_string );
			$fields[ $index ]['group'] = $this->get_field_group_label_translation_editor_group( $parsed_string );
		}

		return $fields;
	}

	/**
	 * Keep the field-group title row first in ASE package jobs.
	 *
	 * @param array    $job_fields Translation editor fields.
	 * @param stdClass $job        WPML translation job.
	 * @return array
	 */
	public function reorder_translation_editor_fields( $job_fields, $job ) {
		if ( ! $this->is_field_group_label_translation_job( $job ) || ! is_array( $job_fields ) ) {
			return $job_fields;
		}

		$ase_fields    = array();
		$ase_positions = array();

		foreach ( $job_fields as $index => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$parsed_string = $this->parse_field_group_label_translation_editor_string( $field );
			if ( empty( $parsed_string ) ) {
				continue;
			}

			$ase_fields[]    = array(
				'field'          => $field,
				'original_index' => $index,
				'order_rank'     => $this->is_field_group_title_translation_editor_string( $parsed_string ) ? 0 : 1,
			);
			$ase_positions[] = $index;
		}

		if ( count( $ase_fields ) < 2 ) {
			return $job_fields;
		}

		usort(
			$ase_fields,
			static function( $field_a, $field_b ) {
				if ( $field_a['order_rank'] === $field_b['order_rank'] ) {
					return $field_a['original_index'] <=> $field_b['original_index'];
				}

				return $field_a['order_rank'] <=> $field_b['order_rank'];
			}
		);

		$ordered_fields = $job_fields;
		$ase_index      = 0;

		foreach ( $ase_positions as $position ) {
			$ordered_fields[ $position ] = $ase_fields[ $ase_index ]['field'];
			++$ase_index;
		}

		return array_values( $ordered_fields );
	}

	/**
	 * Check whether the translation job belongs to ASE field-group labels.
	 *
	 * @param stdClass $job WPML translation job.
	 * @return bool
	 */
	private function is_field_group_label_translation_job( $job ) {
		if ( ! is_object( $job ) || empty( $job->original_post_type ) ) {
			return false;
		}

		$original_post_type = (string) $job->original_post_type;

		return 0 === strpos( $original_post_type, 'package_' ) && false !== strpos( $original_post_type, ASENHA_CCT_WPML_Package::KIND_FIELD_GROUP );
	}

	/**
	 * Parse one ASE field-group label string from the translation editor payload.
	 *
	 * @param array $field Translation editor field.
	 * @return array<string,string>
	 */
	private function parse_field_group_label_translation_editor_string( $field ) {
		$string_name = '';

		if ( ! empty( $field['_asenha_wpml_string_name'] ) && is_string( $field['_asenha_wpml_string_name'] ) ) {
			$string_name = $field['_asenha_wpml_string_name'];
		} elseif ( ! empty( $field['title'] ) && is_string( $field['title'] ) ) {
			$string_name = $field['title'];
		}

		if ( '' === $string_name ) {
			return array();
		}

		if ( ! preg_match( '/-[0-9a-f]{32}$/', $string_name ) ) {
			return array();
		}

		$string_base = substr( $string_name, 0, -33 );

		if ( 0 === strpos( $string_base, 'field-group-' ) ) {
			$parts = explode( '-', $string_base, 4 );

			if ( 4 !== count( $parts ) ) {
				return array();
			}

			return array(
				'namespace' => 'group',
				'id'        => $parts[2],
				'key'       => $parts[3],
			);
		}

		if ( 0 === strpos( $string_base, 'group-' ) ) {
			$parts = explode( '-', $string_base, 3 );

			if ( 3 !== count( $parts ) ) {
				return array();
			}

			return array(
				'namespace' => 'group',
				'id'        => $parts[1],
				'key'       => $parts[2],
			);
		}

		if ( 0 === strpos( $string_base, 'field-option-' ) ) {
			$parts = explode( '-', $string_base, 4 );

			if ( 4 !== count( $parts ) ) {
				return array();
			}

			return array(
				'namespace' => 'field',
				'id'        => $parts[2],
				'key'       => $parts[3],
			);
		}

		if ( 0 === strpos( $string_base, 'choice-' ) ) {
			$parts = explode( '-', $string_base, 4 );

			if ( 4 !== count( $parts ) ) {
				return array();
			}

			return array(
				'namespace' => 'field',
				'id'        => $parts[1],
				'key'       => 'choices-' . $parts[3],
			);
		}

		if ( 0 !== strpos( $string_base, 'field-' ) ) {
			return array();
		}

		$parts = explode( '-', $string_base, 3 );
		if ( 3 !== count( $parts ) ) {
			return array();
		}

		return array(
			'namespace' => 'field',
			'id'        => $parts[1],
			'key'       => $parts[2],
		);
	}

	/**
	 * Get the translation-editor title for one ASE field-group label string.
	 *
	 * @param array $parsed_string Parsed string metadata.
	 * @return string
	 */
	private function get_field_group_label_translation_editor_title( $parsed_string ) {
		if ( $this->is_field_group_title_translation_editor_string( $parsed_string ) ) {
			return __( 'Field group title', 'admin-site-enhancements' );
		}

		if ( empty( $parsed_string['key'] ) ) {
			return '';
		}

		if ( 0 === strpos( $parsed_string['key'], 'choices-' ) ) {
			return __( 'Field choices', 'admin-site-enhancements' );
		}

		switch ( $parsed_string['key'] ) {
			case 'label':
				return __( 'Field label', 'admin-site-enhancements' );

			case 'notes':
				return __( 'Field instructions', 'admin-site-enhancements' );

			case 'message':
				return __( 'Field message', 'admin-site-enhancements' );

			case 'button_label':
				return __( 'Repeater field button label', 'admin-site-enhancements' );

			case 'row_label':
				return __( 'Repeater field row label', 'admin-site-enhancements' );

			default:
				return ucwords( str_replace( array( '-', '_' ), ' ', $parsed_string['key'] ) );
		}
	}

	/**
	 * Get the translation-editor group hierarchy for one ASE field-group label string.
	 *
	 * @param array $parsed_string Parsed string metadata.
	 * @return array<string,string>
	 */
	private function get_field_group_label_translation_editor_group( $parsed_string ) {
		$group = array(
			self::TM_GROUP_ID_ASE => __( 'Admin and Site Enhancements (ASE)', 'admin-site-enhancements' ),
		);

		if ( $this->is_field_group_title_translation_editor_string( $parsed_string ) ) {
			$group[ self::TM_GROUP_ID_FIELD_GROUP_TITLE ] = __( 'Field Group Title', 'admin-site-enhancements' );
		} else {
			$group[ self::TM_GROUP_ID_CUSTOM_FIELDS ] = __( 'Custom Fields', 'admin-site-enhancements' );
		}

		return $group;
	}

	/**
	 * Check whether a parsed editor string is the field-group title row.
	 *
	 * @param array $parsed_string Parsed string metadata.
	 * @return bool
	 */
	private function is_field_group_title_translation_editor_string( $parsed_string ) {
		return isset( $parsed_string['namespace'], $parsed_string['key'] )
			&& 'group' === $parsed_string['namespace']
			&& 'title' === $parsed_string['key'];
	}

	/**
	 * Register one ordered field-group label package entry.
	 *
	 * @param ASENHA_CCT_WPML_Package $package Package helper.
	 * @param array                   $entry   Ordered string entry.
	 * @return void
	 */
	private function register_field_group_label_package_entry( $package, $entry ) {
		$legacy_string_ids = array();

		foreach ( $entry['legacy_meta'] as $legacy_meta ) {
			$legacy_string_id = $this->get_package_string_id_for_meta( $package, $entry['value'], $legacy_meta );
			if ( $legacy_string_id > 0 ) {
				$legacy_string_ids[ $legacy_string_id ] = $legacy_string_id;
			}
		}

		$package->register_string( $entry['value'], $entry['meta'] );

		$current_string_id = $this->get_package_string_id_for_meta( $package, $entry['value'], $entry['meta'] );
		if ( $current_string_id <= 0 ) {
			return;
		}

		foreach ( $legacy_string_ids as $legacy_string_id ) {
			if ( $legacy_string_id === $current_string_id ) {
				continue;
			}

			$this->migrate_package_string_translations( $legacy_string_id, $current_string_id );
		}

		$this->update_package_string_location( $current_string_id, $entry['location'] );
	}

	/**
	 * Translate one field-group label package entry.
	 *
	 * @param ASENHA_CCT_WPML_Package $package Package helper.
	 * @param array                   $entry   Ordered string entry.
	 * @return string
	 */
	private function translate_field_group_label_package_entry( $package, $entry ) {
		$translated = $package->translate_string( $entry['value'], $entry['meta'] );

		if (
			$translated !== $entry['value'] ||
			empty( $entry['legacy_meta'] ) ||
			$this->get_package_string_id_for_meta( $package, $entry['value'], $entry['meta'] ) > 0
		) {
			return $translated;
		}

		foreach ( $entry['legacy_meta'] as $legacy_meta ) {
			$legacy_translation = $package->translate_string( $entry['value'], $legacy_meta );

			if ( $legacy_translation !== $entry['value'] ) {
				return $legacy_translation;
			}
		}

		return $translated;
	}

	/**
	 * Resolve the WPML string ID for one package entry.
	 *
	 * @param ASENHA_CCT_WPML_Package $package Package helper.
	 * @param string                  $value   String value.
	 * @param array                   $meta    String metadata.
	 * @return int
	 */
	private function get_package_string_id_for_meta( $package, $value, $meta ) {
		$string_id = apply_filters(
			'wpml_string_id',
			null,
			array(
				'context' => $package->get_string_context(),
				'name'    => $package->get_string_name_for_meta( $value, $meta ),
			)
		);

		return $string_id ? (int) $string_id : 0;
	}

	/**
	 * Copy existing translations from a legacy package string onto the current string.
	 *
	 * @param int $source_string_id Legacy string ID.
	 * @param int $target_string_id Current string ID.
	 * @return void
	 */
	private function migrate_package_string_translations( $source_string_id, $target_string_id ) {
		global $wpdb;

		if ( $source_string_id <= 0 || $target_string_id <= 0 || $source_string_id === $target_string_id ) {
			return;
		}

		$target_translations = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT language, value
				FROM {$wpdb->prefix}icl_string_translations
				WHERE string_id = %d",
				$target_string_id
			),
			ARRAY_A
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- WPML package-string migration needs direct access to WPML string translation rows.

		$target_translations_by_language = array();
		foreach ( (array) $target_translations as $translation_row ) {
			$target_translations_by_language[ $translation_row['language'] ] = $translation_row;
		}

		$source_translations = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT language, status, value, mo_string, translator_id, translation_service, batch_id, translation_date
				FROM {$wpdb->prefix}icl_string_translations
				WHERE string_id = %d",
				$source_string_id
			),
			ARRAY_A
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- WPML package-string migration needs direct access to WPML string translation rows.

		foreach ( (array) $source_translations as $translation_row ) {
			$language_code = $translation_row['language'];

			if (
				isset( $target_translations_by_language[ $language_code ] ) &&
				'' !== (string) $target_translations_by_language[ $language_code ]['value']
			) {
				continue;
			}

			$translation_row['string_id'] = $target_string_id;

			$wpdb->replace(
				$wpdb->prefix . 'icl_string_translations',
				$translation_row
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- WPML package-string migration needs direct access to WPML string translation rows.
		}

		$source_status = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT status
				FROM {$wpdb->prefix}icl_strings
				WHERE id = %d",
				$source_string_id
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- WPML package-string migration needs direct access to WPML string rows.

		if ( $source_status > 0 ) {
			$wpdb->update(
				$wpdb->prefix . 'icl_strings',
				array(
					'status' => $source_status,
				),
				array(
					'id' => $target_string_id,
				),
				array( '%d' ),
				array( '%d' )
			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- WPML package-string migration needs direct access to WPML string rows.
		}
	}

	/**
	 * Persist the desired package-string ordering for WPML package screens.
	 *
	 * @param int $string_id String ID.
	 * @param int $location  Desired package row location.
	 * @return void
	 */
	private function update_package_string_location( $string_id, $location ) {
		global $wpdb;

		if ( $string_id <= 0 ) {
			return;
		}

		$wpdb->update(
			$wpdb->prefix . 'icl_strings',
			array(
				'location' => (int) $location,
			),
			array(
				'id' => (int) $string_id,
			),
			array( '%d' ),
			array( '%d' )
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- WPML package-string ordering needs direct access to WPML string rows.
	}

	/**
	 * Collect additional translatable field-option strings.
	 *
	 * @param array $field Field definition.
	 * @return array
	 */
	private function get_translatable_field_option_strings( $field ) {
		if ( empty( $field['options'] ) || ! is_array( $field['options'] ) || empty( $field['name'] ) ) {
			return array();
		}

		$strings = array();

		if ( 'true_false' === $field['type'] && ! empty( $field['options']['message'] ) ) {
			$strings['message'] = array(
				'value' => $field['options']['message'],
				/* translators: %s: CFG field name. */
				'title' => sprintf( __( '%s message', 'admin-site-enhancements' ), $field['name'] ),
			);
		}

		if ( 'repeater' === $field['type'] ) {
			if ( ! empty( $field['options']['button_label'] ) ) {
				$strings['button_label'] = array(
					'value' => $field['options']['button_label'],
					/* translators: %s: CFG field name. */
					'title' => sprintf( __( '%s button label', 'admin-site-enhancements' ), $field['name'] ),
				);
			}

			if ( ! empty( $field['options']['row_label'] ) ) {
				$strings['row_label'] = array(
					'value' => $field['options']['row_label'],
					/* translators: %s: CFG field name. */
					'title' => sprintf( __( '%s row label', 'admin-site-enhancements' ), $field['name'] ),
				);
			}
		}

		return $strings;
	}

	/**
	 * Rebuild copied post meta and CFG index tables for WPML duplication.
	 *
	 * @param bool   $handled        Previous callback result.
	 * @param int    $source_post_id Source post ID.
	 * @param int    $target_post_id Target post ID.
	 * @param string $language_code  Target language.
	 * @param array  $post_data      Target post payload.
	 * @return bool
	 */
	public function duplicate_post_fields( $handled, $source_post_id, $target_post_id, $language_code, $post_data ) {
		if ( $handled ) {
			return true;
		}

		unset( $post_data );

		return $this->perform_object_duplication( 'post', (int) $source_post_id, (int) $target_post_id, (string) $language_code );
	}

	/**
	 * Handle copied post fields when WPML copied individual meta rows.
	 *
	 * @param int    $post_id_from Source post ID.
	 * @param int    $post_id_to   Target post ID.
	 * @param string $meta_key     Copied meta key.
	 * @return void
	 */
	public function after_copy_custom_field( $post_id_from, $post_id_to, $meta_key ) {
		if ( ! $this->is_cfg_field_name( $meta_key, $post_id_from, 'post' ) ) {
			return;
		}

		$process_key = 'post:' . (int) $post_id_to;
		if ( isset( $this->processed_duplicates[ $process_key ] ) ) {
			return;
		}

		// Target already has a CFG index: do not re-seed translate fields from the
		// source post. Rebuild from the target's own postmeta instead.
		if ( $this->object_has_cfg_index_rows( 'post', (int) $post_id_to ) ) {
			$this->schedule_cfg_index_rebuild( (int) $post_id_to, 'post' );
			return;
		}

		$target_lang = $this->get_element_language_code( (int) $post_id_to, get_post_type( $post_id_to ) );
		$this->perform_object_duplication( 'post', (int) $post_id_from, (int) $post_id_to, $target_lang );
	}

	/**
	 * Handle copied term fields when WPML copied individual meta rows.
	 *
	 * @param int    $term_id_from Source term ID.
	 * @param int    $term_id_to   Target term ID.
	 * @param string $meta_key     Copied meta key.
	 * @return void
	 */
	public function after_copy_term_field( $term_id_from, $term_id_to, $meta_key ) {
		$target_term = get_term( (int) $term_id_to );
		if ( ! $target_term || is_wp_error( $target_term ) ) {
			return;
		}

		if ( ! $this->is_cfg_field_name( $meta_key, (int) $term_id_from, 'term', $target_term->taxonomy ) ) {
			return;
		}

		$process_key = 'term:' . (int) $term_id_to;
		if ( isset( $this->processed_duplicates[ $process_key ] ) ) {
			return;
		}

		if ( $this->object_has_cfg_index_rows( 'term', (int) $term_id_to ) ) {
			$this->schedule_cfg_index_rebuild( (int) $term_id_to, 'term' );
			return;
		}

		$target_lang = $this->get_element_language_code( (int) $term_id_to, $target_term->taxonomy );
		$this->perform_object_duplication(
			'term',
			(int) $term_id_from,
			(int) $term_id_to,
			$target_lang,
			array(
				'taxonomy' => $target_term->taxonomy,
			)
		);
	}

	/**
	 * Translate serialized hyperlink values during WPML duplication when possible.
	 *
	 * @param mixed  $value      Current value.
	 * @param string $target_lang Target language.
	 * @param array  $meta_data  WPML metadata.
	 * @return mixed
	 */
	public function duplicate_generic_string( $value, $target_lang, $meta_data ) {
		if ( empty( $meta_data['key'] ) || empty( $meta_data['type'] ) || 'hyperlink' !== $meta_data['type'] ) {
			return $value;
		}

		$maybe_unserialized = maybe_unserialize( $value );
		if ( ! is_array( $maybe_unserialized ) || empty( $maybe_unserialized['url'] ) ) {
			return $value;
		}

		$maybe_unserialized['url'] = $this->translate_internal_url( $maybe_unserialized['url'], $target_lang );

		return maybe_serialize( $maybe_unserialized );
	}

	/**
	 * Perform an ASE-aware duplication rebuild.
	 *
	 * @param string $object_type   post or term.
	 * @param int    $source_id     Source object ID.
	 * @param int    $target_id     Target object ID.
	 * @param string $target_lang   Target language code.
	 * @param array  $args          Extra args.
	 * @return bool
	 */
	private function perform_object_duplication( $object_type, $source_id, $target_id, $target_lang, $args = array() ) {
		$process_key = $object_type . ':' . $target_id;
		if ( isset( $this->processed_duplicates[ $process_key ] ) ) {
			return true;
		}

		$this->reset_repeater_mapping_state();
		$this->rebuilding_cfg_index = true;

		$field_groups = ! empty( $args['field_groups'] ) ? (array) $args['field_groups'] : array();
		$taxonomy     = isset( $args['taxonomy'] ) ? $args['taxonomy'] : '';

		if ( 'post' === $object_type ) {
			if ( empty( $field_groups ) ) {
				$field_groups = array_keys( (array) CFG()->api->get_matching_groups( $source_id, true ) );
			}
			$field_data = CFG()->get( false, $source_id, array( 'format' => 'input' ) );
		} else {
			if ( empty( $taxonomy ) ) {
				$term = get_term( $source_id );
				if ( $term && ! is_wp_error( $term ) ) {
					$taxonomy = $term->taxonomy;
				}
			}
			if ( empty( $taxonomy ) ) {
				$this->rebuilding_cfg_index = false;
				return false;
			}
			if ( empty( $field_groups ) ) {
				$field_groups = CFG()->api->get_matching_groups_for_taxonomy( $taxonomy );
			}
			$field_data = CFG()->get( false, $taxonomy . '_' . $source_id, array( 'format' => 'input' ) );
		}

		if ( empty( $field_groups ) || ! is_array( $field_data ) ) {
			$this->rebuilding_cfg_index = false;
			return false;
		}

		$field_defs = CFG()->api->find_input_fields( array( 'group_id' => $field_groups ) );
		if ( empty( $field_defs ) ) {
			$this->rebuilding_cfg_index = false;
			return false;
		}

		$fields_by_id = array();
		foreach ( $field_defs as $field ) {
			$fields_by_id[ (int) $field['id'] ] = $field;
		}

		$field_data = $this->remap_input_field_data( $field_data, $fields_by_id, $target_lang );

		// Preserve already-translated leaf values on the target when re-duplicating.
		if ( 'post' === $object_type ) {
			$existing_target = CFG()->get( false, $target_id, array( 'format' => 'input' ) );
		} else {
			$existing_target = CFG()->get( false, $taxonomy . '_' . $target_id, array( 'format' => 'input' ) );
		}

		if ( is_array( $existing_target ) && ! empty( $existing_target ) ) {
			$field_data = $this->merge_preserving_translated_input_fields( $field_data, $existing_target, $fields_by_id );
		}

		if ( $this->repeater_mapping_ambiguous ) {
			$this->log_repeater_mapping_warnings( $object_type, $target_id );
			$this->rebuilding_cfg_index = false;
			return false;
		}

		$this->delete_cfg_object_values( $object_type, $target_id, $field_groups );

		if ( 'post' === $object_type ) {
			CFG()->save(
				$field_data,
				array( 'ID' => $target_id ),
				array(
					'format'       => 'input',
					'field_groups' => $field_groups,
				)
			);
		} else {
			CFG()->save_for_term(
				$field_data,
				array( 'ID' => $target_id ),
				array(
					'format'       => 'input',
					'field_groups' => $field_groups,
				)
			);
		}

		$this->cleanup_unindexed_cfg_object_meta( $object_type, $target_id, $field_defs );
		$this->processed_duplicates[ $process_key ] = true;
		$this->rebuilding_cfg_index = false;

		return true;
	}

	/**
	 * Rebuild the CFG index for a post from its current postmeta values.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	public function rebuild_post_cfg_index_from_postmeta( $post_id ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 || $this->rebuilding_cfg_index ) {
			return false;
		}

		$process_key = 'rebuild:post:' . $post_id;
		if ( isset( $this->processed_duplicates[ $process_key ] ) ) {
			return true;
		}

		$field_groups = array_keys( (array) CFG()->api->get_matching_groups( $post_id, true ) );
		if ( empty( $field_groups ) ) {
			return false;
		}

		$field_defs = CFG()->api->find_input_fields( array( 'group_id' => $field_groups ) );
		if ( empty( $field_defs ) ) {
			return false;
		}

		$this->reset_repeater_mapping_state();
		$this->rebuilding_cfg_index = true;

		try {
			// When postmeta translate leaves were wiped, recover values from the latest ATE job.
			$this->maybe_load_ate_job_overrides_for_post( $post_id );

			$field_data = $this->build_input_field_data_from_postmeta( $post_id, $field_defs );
			if ( empty( $field_data ) ) {
				return false;
			}

			$fields_by_id = array();
			foreach ( $field_defs as $field ) {
				$fields_by_id[ (int) $field['id'] ] = $field;
			}

			$post           = get_post( $post_id );
			$source_post_id = 0;
			if ( $post && ! empty( $post->post_type ) ) {
				$source_post_id = $this->get_source_post_id_for_translation( $post_id, $post->post_type );
				if ( (int) $source_post_id === $post_id ) {
					$source_post_id = 0;
				}
			}

			// Guard: never destructively save a sparse tree that dropped translate leaves.
			if ( $source_post_id > 0 ) {
				$field_data = $this->ensure_field_data_has_source_translate_leaves(
					$field_data,
					$source_post_id,
					$fields_by_id,
					'post',
					$post_id
				);
			}

			$structure_valid = true;
			if ( $source_post_id > 0 ) {
				$structure_valid = $this->validate_repeater_input_structure( $field_data, $source_post_id, $fields_by_id, $post_id );
			}

			if ( ! $structure_valid ) {
				$this->log_repeater_mapping_warnings( 'post', $post_id );
				return false;
			}

			// Non-unique copy-field values (typical floor/surface duplicates) must
			// not block a rebuild that already has a valid source-shaped tree.
			if ( $this->repeater_mapping_ambiguous && $source_post_id <= 0 ) {
				$this->log_repeater_mapping_warnings( 'post', $post_id );
				return false;
			}

			$this->delete_cfg_object_values( 'post', $post_id, $field_groups );
			CFG()->save(
				$field_data,
				array( 'ID' => $post_id ),
				array(
					'format'       => 'input',
					'field_groups' => $field_groups,
				)
			);

			$this->cleanup_unindexed_cfg_object_meta( 'post', $post_id, $field_defs );

			$this->processed_duplicates[ $process_key ] = true;
			$this->clear_cfg_index_integrity_cache( 'post', $post_id );

			return true;
		} finally {
			$this->rebuilding_cfg_index = false;
		}
	}

	/**
	 * Rebuild the CFG index for a term from its current termmeta values.
	 *
	 * @param int $term_id Term ID.
	 * @return bool
	 */
	public function rebuild_term_cfg_index_from_termmeta( $term_id ) {
		$term_id = (int) $term_id;
		if ( $term_id <= 0 || $this->rebuilding_cfg_index ) {
			return false;
		}

		$term = get_term( $term_id );
		if ( ! $term || is_wp_error( $term ) ) {
			return false;
		}

		$process_key = 'rebuild:term:' . $term_id;
		if ( isset( $this->processed_duplicates[ $process_key ] ) ) {
			return true;
		}

		$field_groups = CFG()->api->get_matching_groups_for_taxonomy( $term->taxonomy );
		if ( empty( $field_groups ) ) {
			return false;
		}

		$field_defs = CFG()->api->find_input_fields( array( 'group_id' => $field_groups ) );
		if ( empty( $field_defs ) ) {
			return false;
		}

		$this->reset_repeater_mapping_state();
		$this->rebuilding_cfg_index = true;

		try {
			$field_data = $this->build_input_field_data_from_termmeta( $term_id, $field_defs );
			if ( empty( $field_data ) ) {
				return false;
			}

			if ( $this->repeater_mapping_ambiguous ) {
				$this->log_repeater_mapping_warnings( 'term', $term_id );
				return false;
			}

			$this->delete_cfg_object_values( 'term', $term_id, $field_groups );
			CFG()->save_for_term(
				$field_data,
				array( 'ID' => $term_id ),
				array(
					'format'       => 'input',
					'field_groups' => $field_groups,
				)
			);

			$this->cleanup_unindexed_cfg_object_meta( 'term', $term_id, $field_defs );

			$this->processed_duplicates[ $process_key ] = true;
			$this->clear_cfg_index_integrity_cache( 'term', $term_id );

			return true;
		} finally {
			$this->rebuilding_cfg_index = false;
		}
	}

	/**
	 * Rebuild the CFG index during a read when postmeta exists but the index is stale.
	 *
	 * @param bool   $reindexed   Whether a reindex already ran.
	 * @param int    $object_id   Post or term ID.
	 * @param string $object_type post or term.
	 * @param array  $fields      Field definitions keyed by field ID.
	 * @param int    $index_rows  Number of rows returned by the CFG index query.
	 * @return bool
	 */
	public function maybe_reindex_cfg_from_meta_on_read( $reindexed, $object_id, $object_type, $fields, $index_rows = 0 ) {
		if ( $reindexed || $this->rebuilding_cfg_index ) {
			return (bool) $reindexed;
		}

		$object_type = ( 'term' === $object_type ) ? 'term' : 'post';
		$pending_key = $object_type . ':' . (int) $object_id;
		if ( isset( $this->posts_pending_cfg_rebuild[ $pending_key ] ) ) {
			return false;
		}

		if ( ! $this->object_needs_cfg_index_rebuild_on_read( $object_type, (int) $object_id, $fields, (int) $index_rows ) ) {
			return false;
		}

		if ( 'term' === $object_type ) {
			return $this->rebuild_term_cfg_index_from_termmeta( (int) $object_id );
		}

		return $this->rebuild_post_cfg_index_from_postmeta( (int) $object_id );
	}

	/**
	 * Determine whether a CFG read should trigger an index rebuild from stored meta.
	 *
	 * @param string $object_type post or term.
	 * @param int    $object_id   Post or term ID.
	 * @param array  $fields      Field definitions keyed by field ID.
	 * @param int    $index_rows  Number of rows returned by the CFG index query.
	 * @return bool
	 */
	private function object_needs_cfg_index_rebuild_on_read( $object_type, $object_id, $fields, $index_rows ) {
		if ( $object_id <= 0 || empty( $fields ) ) {
			return false;
		}

		// Orphaned index rows break get_cf() (INNER JOIN on deleted meta_ids).
		// Unindexed duplicate meta is handled on write/meta-change hooks only —
		// skipping it here avoids expensive correlated EXISTS scans on every CFG read.
		if ( $this->object_has_orphaned_cfg_index_rows( $object_type, $object_id ) ) {
			return true;
		}

		if ( $index_rows > 0 ) {
			return false;
		}

		foreach ( $fields as $field ) {
			$field = (object) $field;

			if ( ! empty( $field->parent_id ) ) {
				continue;
			}

			if ( 'term' === $object_type ) {
				if ( metadata_exists( 'term', $object_id, $field->name ) ) {
					return true;
				}
			} elseif ( metadata_exists( 'post', $object_id, $field->name ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Queue a CFG index rebuild after WPML finishes a professional translation.
	 *
	 * @param int        $new_post_id Translated post ID.
	 * @param array|null $fields      WPML field payload.
	 * @param mixed      $job         WPML job object.
	 * @return void
	 */
	public function rebuild_cfg_index_after_wpml_translation( $new_post_id, $fields = null, $job = null ) {
		unset( $job );

		$new_post_id = (int) $new_post_id;
		$this->sync_translated_post_taxonomies( $new_post_id );

		if ( is_array( $fields ) && ! empty( $fields ) ) {
			$parsed = $this->parse_wpml_job_fields_to_meta_map( $fields );
			if ( ! empty( $parsed ) ) {
				$this->wpml_translation_field_overrides[ $new_post_id ] = $parsed;
			}
		}

		$this->schedule_cfg_index_rebuild( $new_post_id, 'post' );
	}

	/**
	 * Check whether the one-time translated-post taxonomy backfill already ran.
	 *
	 * @return bool
	 */
	public static function is_taxonomy_sync_backfill_complete() {
		return self::TAXONOMY_SYNC_BACKFILL_VERSION === (string) get_option( self::TAXONOMY_SYNC_BACKFILL_OPTION, '' );
	}

	/**
	 * Backfill missing taxonomy relationships on translated ASE posts once WPML is ready.
	 *
	 * @return void
	 */
	public function maybe_backfill_missing_translated_post_taxonomies() {
		if ( $this->taxonomy_sync_backfill_ran || ! defined( 'ICL_SITEPRESS_VERSION' ) ) {
			return;
		}

		$this->taxonomy_sync_backfill_ran = true;

		if ( ! current_user_can( 'manage_options' ) || self::is_taxonomy_sync_backfill_complete() ) {
			return;
		}

		$repaired_any = false;

		foreach ( $this->get_asenha_generated_post_type_slugs() as $post_type ) {
			if ( $this->backfill_translated_post_taxonomies_for_post_type( $post_type ) ) {
				$repaired_any = true;
			}
		}

		if ( $repaired_any ) {
			$this->sync_dynamic_wpml_config( true );
		}

		update_option( self::TAXONOMY_SYNC_BACKFILL_OPTION, self::TAXONOMY_SYNC_BACKFILL_VERSION, true );
	}

	/**
	 * Copy mapped taxonomy terms from a source post onto its translated post.
	 *
	 * @param int      $translated_post_id Translated post ID.
	 * @param int|null $source_post_id     Optional source post ID.
	 * @return bool Whether any taxonomy assignment changed.
	 */
	private function sync_translated_post_taxonomies( $translated_post_id, $source_post_id = null ) {
		$translated_post_id = (int) $translated_post_id;
		$post               = get_post( $translated_post_id );

		if ( ! $post || empty( $post->post_type ) ) {
			return false;
		}

		if ( ! $this->is_asenha_generated_post_type( $post->post_type ) ) {
			return false;
		}

		if ( null === $source_post_id ) {
			$source_post_id = $this->get_source_post_id_for_translation( $translated_post_id, $post->post_type );
		} else {
			$source_post_id = (int) $source_post_id;
		}

		if ( $source_post_id <= 0 || $source_post_id === $translated_post_id ) {
			return false;
		}

		$target_lang = $this->get_element_language_code( $translated_post_id, $post->post_type );
		if ( '' === $target_lang ) {
			return false;
		}

		$changed = false;

		foreach ( get_object_taxonomies( $post->post_type ) as $taxonomy ) {
			if ( ! apply_filters( 'wpml_is_translated_taxonomy', null, $taxonomy ) ) {
				continue;
			}

			$existing_terms = wp_get_object_terms(
				$translated_post_id,
				$taxonomy,
				array(
					'fields' => 'ids',
				)
			);

			if ( ! empty( $existing_terms ) && ! is_wp_error( $existing_terms ) ) {
				continue;
			}

			$source_terms = wp_get_object_terms(
				$source_post_id,
				$taxonomy,
				array(
					'fields' => 'ids',
				)
			);

			if ( empty( $source_terms ) || is_wp_error( $source_terms ) ) {
				continue;
			}

			$mapped_term_ids = array();

			foreach ( $source_terms as $source_term_id ) {
				$mapped_term_id = $this->map_term_id_to_language( (int) $source_term_id, $taxonomy, $target_lang );
				if ( $mapped_term_id > 0 ) {
					$mapped_term_ids[] = $mapped_term_id;
				}
			}

			$mapped_term_ids = array_values( array_unique( $mapped_term_ids ) );
			if ( empty( $mapped_term_ids ) ) {
				continue;
			}

			$result = wp_set_object_terms( $translated_post_id, $mapped_term_ids, $taxonomy, false );
			if ( ! is_wp_error( $result ) ) {
				$changed = true;
			}
		}

		return $changed;
	}

	/**
	 * Backfill translated posts for one ASE-generated post type.
	 *
	 * @param string $post_type Generated post type slug.
	 * @return bool Whether any post was repaired.
	 */
	private function backfill_translated_post_taxonomies_for_post_type( $post_type ) {
		global $wpdb;

		$element_type = 'post_' . $post_type;
		$rows         = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT element_id, trid, source_language_code
				FROM {$wpdb->prefix}icl_translations
				WHERE element_type = %s
				AND source_language_code IS NOT NULL
				AND source_language_code != ''",
				$element_type
			)
		);

		if ( empty( $rows ) ) {
			return false;
		}

		$changed = false;

		foreach ( $rows as $row ) {
			$translated_post_id = (int) $row->element_id;
			$source_post_id     = $this->get_source_post_id_for_translation( $translated_post_id, $post_type, (int) $row->trid );

			if ( $this->sync_translated_post_taxonomies( $translated_post_id, $source_post_id ) ) {
				$changed = true;
			}
		}

		return $changed;
	}

	/**
	 * Resolve the source post ID for a translated ASE post.
	 *
	 * @param int      $translated_post_id Translated post ID.
	 * @param string   $post_type          Post type slug.
	 * @param int|null $trid               Optional translation group ID.
	 * @return int
	 */
	private function get_source_post_id_for_translation( $translated_post_id, $post_type, $trid = null ) {
		global $sitepress;

		$element_type = 'post_' . $post_type;

		if ( null === $trid && is_object( $sitepress ) && method_exists( $sitepress, 'get_element_language_details' ) ) {
			$details = $sitepress->get_element_language_details( (int) $translated_post_id, $element_type );
			if ( is_object( $details ) && ! empty( $details->trid ) ) {
				$trid = (int) $details->trid;
			}
		}

		if ( empty( $trid ) ) {
			$trid = (int) apply_filters( 'wpml_element_trid', null, (int) $translated_post_id, $element_type );
		}

		if ( $trid <= 0 ) {
			return 0;
		}

		if ( is_object( $sitepress ) && method_exists( $sitepress, 'get_element_translations' ) ) {
			$translations = $sitepress->get_element_translations( $trid, $element_type );
			if ( is_array( $translations ) ) {
				foreach ( $translations as $translation ) {
					if ( is_object( $translation ) && empty( $translation->source_language_code ) && ! empty( $translation->element_id ) ) {
						return (int) $translation->element_id;
					}
				}
			}
		}

		$translations = apply_filters( 'wpml_get_element_translations', null, $trid, $element_type );
		if ( is_array( $translations ) ) {
			foreach ( $translations as $translation ) {
				if ( is_object( $translation ) && empty( $translation->source_language_code ) && ! empty( $translation->element_id ) ) {
					return (int) $translation->element_id;
				}
			}
		}

		return 0;
	}

	/**
	 * Resolve the source term ID for a translated term.
	 *
	 * @param int    $translated_term_id Translated term ID.
	 * @param string $taxonomy           Taxonomy slug.
	 * @return int
	 */
	private function get_source_term_id_for_translation( $translated_term_id, $taxonomy ) {
		global $sitepress;

		$translated_term_id = (int) $translated_term_id;
		$taxonomy           = (string) $taxonomy;
		$element_type       = 'tax_' . $taxonomy;

		if ( $translated_term_id <= 0 || '' === $taxonomy ) {
			return 0;
		}

		$trid = (int) apply_filters( 'wpml_element_trid', null, $translated_term_id, $element_type );
		if ( $trid <= 0 && is_object( $sitepress ) && method_exists( $sitepress, 'get_element_language_details' ) ) {
			$details = $sitepress->get_element_language_details( $translated_term_id, $element_type );
			if ( is_object( $details ) && ! empty( $details->trid ) ) {
				$trid = (int) $details->trid;
			}
		}

		if ( $trid <= 0 ) {
			return 0;
		}

		if ( is_object( $sitepress ) && method_exists( $sitepress, 'get_element_translations' ) ) {
			$translations = $sitepress->get_element_translations( $trid, $element_type );
		} else {
			$translations = apply_filters( 'wpml_get_element_translations', null, $trid, $element_type );
		}

		foreach ( (array) $translations as $translation ) {
			if (
				is_object( $translation )
				&& empty( $translation->source_language_code )
				&& ! empty( $translation->element_id )
				&& (int) $translation->element_id !== $translated_term_id
			) {
				return (int) $translation->element_id;
			}
		}

		return 0;
	}

	/**
	 * Map a taxonomy term ID to its equivalent in another language.
	 *
	 * @param int    $term_id     Source term ID.
	 * @param string $taxonomy    Taxonomy slug.
	 * @param string $target_lang Target language code.
	 * @return int
	 */
	private function map_term_id_to_language( $term_id, $taxonomy, $target_lang ) {
		$term_id     = (int) $term_id;
		$target_lang = (string) $target_lang;

		if ( $term_id <= 0 || '' === $taxonomy || '' === $target_lang ) {
			return 0;
		}

		$mapped_id = apply_filters( 'wpml_object_id', $term_id, $taxonomy, false, $target_lang );
		if ( ! empty( $mapped_id ) ) {
			return (int) $mapped_id;
		}

		global $sitepress;

		if ( ! is_object( $sitepress ) || ! method_exists( $sitepress, 'get_element_language_details' ) ) {
			return 0;
		}

		$element_type = 'tax_' . $taxonomy;
		$details      = $sitepress->get_element_language_details( $term_id, $element_type );
		if ( ! is_object( $details ) || empty( $details->trid ) ) {
			return 0;
		}

		if ( method_exists( $sitepress, 'get_element_translations' ) ) {
			$translations = $sitepress->get_element_translations( (int) $details->trid, $element_type );
			if ( is_array( $translations ) ) {
				foreach ( $translations as $language_code => $translation ) {
					$translation_lang = is_object( $translation ) && ! empty( $translation->language_code )
						? (string) $translation->language_code
						: (string) $language_code;

					if ( $translation_lang === $target_lang ) {
						$element_id = is_object( $translation ) ? (int) $translation->element_id : (int) $translation;
						if ( $element_id > 0 ) {
							return $element_id;
						}
					}
				}
			}
		}

		return 0;
	}

	/**
	 * Get published ASE-generated post type slugs.
	 *
	 * @return array<int,string>
	 */
	private function get_asenha_generated_post_type_slugs() {
		$slugs     = array();
		$cpt_posts = get_posts(
			array(
				'post_type'              => 'asenha_cpt',
				'post_status'            => 'publish',
				'numberposts'            => -1,
				'fields'                 => 'ids',
				'update_post_meta_cache' => true,
				'update_post_term_cache' => false,
				'suppress_filters'       => true,
			)
		);

		foreach ( $cpt_posts as $cpt_id ) {
			$slug = (string) get_post_meta( (int) $cpt_id, 'cpt_key', true );
			if ( '' !== $slug ) {
				$slugs[] = $slug;
			}
		}

		return array_values( array_unique( $slugs ) );
	}

	/**
	 * Check whether a post type slug was generated by ASE.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function is_asenha_generated_post_type( $post_type ) {
		$post_type = (string) $post_type;
		if ( '' === $post_type ) {
			return false;
		}

		return in_array( $post_type, $this->get_asenha_generated_post_type_slugs(), true );
	}

	/**
	 * Schedule translated CFG rebuilds after a source CFG form save.
	 *
	 * WPML creates translation-job field occurrences from the source snapshot
	 * at job creation/update time. This hook handles the separate local CFG
	 * structure gap: translated posts must receive the newly appended source
	 * rows before the next translation completion can hydrate them.
	 *
	 * @param array $hook_params CFG form after-save parameters.
	 * @return void
	 */
	public function maybe_schedule_cfg_rebuilds_after_cfgroup_save( $hook_params ) {
		if ( $this->rebuilding_cfg_index || ! is_array( $hook_params ) || empty( $hook_params['post_data'] ) ) {
			return;
		}

		$post_id = ! empty( $hook_params['post_data']['ID'] ) ? (int) $hook_params['post_data']['ID'] : 0;
		if ( $post_id <= 0 || wp_is_post_revision( $post_id ) ) {
			return;
		}

		$post = get_post( $post_id );
		if ( ! $post || empty( $post->post_type ) || ! $this->is_asenha_generated_post_type( $post->post_type ) ) {
			return;
		}

		$source_post_id = $this->get_source_post_id_for_translation( $post_id, $post->post_type );
		if ( $source_post_id > 0 && (int) $source_post_id !== $post_id ) {
			return;
		}

		$stale_job_diagnostics = array();
		$this->clear_stale_wpml_job_diagnostics_for_source( $post_id );

		foreach ( $this->get_translated_post_ids_for_source( $post_id, $post->post_type ) as $translated_post_id ) {
			if (
				$this->translated_post_missing_translate_leaves( $translated_post_id, $post_id )
				|| $this->translated_post_has_surplus_translate_leaves( $translated_post_id, $post_id )
			) {
				$this->schedule_cfg_index_rebuild( $translated_post_id, 'post' );
			}

			$diagnostic = $this->get_stale_wpml_repeater_job_diagnostic(
				$post_id,
				$translated_post_id,
				$post->post_type
			);

			if ( ! empty( $diagnostic ) ) {
				$stale_job_diagnostics[] = $diagnostic;

				// Completed translations stay on the pencil icon unless WPML is
				// told the source repeater structure no longer matches the last job.
				if ( ! empty( $diagnostic['mode'] ) && 'completed' === $diagnostic['mode'] ) {
					$this->maybe_mark_wpml_translation_needs_update(
						$translated_post_id,
						$post->post_type
					);
				}
			}
		}

		if ( ! empty( $stale_job_diagnostics ) ) {
			$this->record_stale_wpml_job_diagnostics( $stale_job_diagnostics );
		}
	}

	/**
	 * Get translated post IDs in the source post's WPML translation group.
	 *
	 * @param int    $source_post_id Source-language post ID.
	 * @param string $post_type      Post type slug.
	 * @return array<int,int>
	 */
	private function get_translated_post_ids_for_source( $source_post_id, $post_type ) {
		global $wpdb;

		$source_post_id = (int) $source_post_id;
		$post_type      = (string) $post_type;
		if ( $source_post_id <= 0 || '' === $post_type ) {
			return array();
		}

		$translations_table = $wpdb->prefix . 'icl_translations';
		$element_type       = 'post_' . $post_type;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$translated_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT translated.element_id
				FROM {$translations_table} source
				INNER JOIN {$translations_table} translated ON translated.trid = source.trid
				WHERE source.element_id = %d
					AND source.element_type = %s
					AND translated.element_type = %s
					AND translated.element_id <> %d
					AND translated.source_language_code IS NOT NULL
					AND translated.source_language_code <> ''",
				$source_post_id,
				$element_type,
				$element_type,
				$source_post_id
			)
		);

		return array_values( array_unique( array_map( 'intval', (array) $translated_ids ) ) );
	}

	/**
	 * Detect a WPML job whose repeater occurrence set lags the source.
	 *
	 * Prefers an unfinished job; falls back to the latest completed job so
	 * source repeater growth after a finished translation still surfaces a
	 * warning. This diagnostic does not invent ATE rows — WPML owns job
	 * cardinality via Update translation / resend.
	 *
	 * @param int    $source_post_id     Source-language post ID.
	 * @param int    $translated_post_id Translated post ID.
	 * @param string $post_type          Post type slug.
	 * @return array<string,mixed>
	 */
	private function get_stale_wpml_repeater_job_diagnostic( $source_post_id, $translated_post_id, $post_type ) {
		$source_post_id     = (int) $source_post_id;
		$translated_post_id = (int) $translated_post_id;
		$post_type          = (string) $post_type;

		if ( $source_post_id <= 0 || $translated_post_id <= 0 || '' === $post_type ) {
			return array();
		}

		$translated_post = get_post( $translated_post_id );
		if ( ! $translated_post || $post_type !== (string) $translated_post->post_type ) {
			return array();
		}

		$field_groups = array_keys( (array) CFG()->api->get_matching_groups( $translated_post_id, true ) );
		if ( empty( $field_groups ) ) {
			return array();
		}

		$field_defs = CFG()->api->find_input_fields( array( 'group_id' => $field_groups ) );
		if ( empty( $field_defs ) ) {
			return array();
		}

		$fields_by_id = array();
		foreach ( $field_defs as $field ) {
			$fields_by_id[ (int) $field['id'] ] = $field;
		}

		$source_counts = $this->get_repeater_translate_leaf_occurrence_counts( $source_post_id, $fields_by_id, true );

		$job_info = $this->get_wpml_tm_job_for_stale_diagnostic( $translated_post_id, $post_type );
		if ( empty( $job_info['job_id'] ) ) {
			return array();
		}

		$job_id       = (int) $job_info['job_id'];
		$job_mode     = ! empty( $job_info['mode'] ) ? (string) $job_info['mode'] : 'in_progress';
		$job_counts   = $this->get_wpml_tm_job_field_occurrence_counts( $job_id );
		$stale_fields = $this->get_stale_wpml_repeater_fields( $source_counts, $job_counts, $fields_by_id );
		if ( empty( $stale_fields ) ) {
			return array();
		}

		return array(
			'source_post_id'     => $source_post_id,
			'translated_post_id' => $translated_post_id,
			'post_type'          => $post_type,
			'job_id'             => $job_id,
			'mode'               => $job_mode,
			'fields'             => $stale_fields,
		);
	}

	/**
	 * Resolve the TM job used for stale repeater diagnostics.
	 *
	 * Prefers an unfinished job; falls back to the latest job (including completed).
	 *
	 * @param int    $post_id   Translated post ID.
	 * @param string $post_type Post type slug.
	 * @return array{job_id?:int,mode?:string}
	 */
	private function get_wpml_tm_job_for_stale_diagnostic( $post_id, $post_type ) {
		$active_job_id = $this->get_active_wpml_tm_job_id_for_post( $post_id, $post_type );
		if ( $active_job_id > 0 ) {
			return array(
				'job_id' => $active_job_id,
				'mode'   => 'in_progress',
			);
		}

		$latest_job_id = $this->get_latest_wpml_tm_job_id_for_post( $post_id, $post_type );
		if ( $latest_job_id > 0 ) {
			return array(
				'job_id' => $latest_job_id,
				'mode'   => 'completed',
			);
		}

		return array();
	}

	/**
	 * Count translate-preference leaves in the source's repeater input tree.
	 *
	 * @param int   $post_id         Post ID.
	 * @param array $fields_by_id    Field definitions keyed by field ID.
	 * @param bool  $only_non_empty  When true, skip empty leaf values (WPML omits them from jobs).
	 * @return array<int,int>
	 */
	private function get_repeater_translate_leaf_occurrence_counts( $post_id, $fields_by_id, $only_non_empty = false ) {
		$input = CFG()->get( false, (int) $post_id, array( 'format' => 'input' ) );
		if ( ! is_array( $input ) || empty( $input ) ) {
			return array();
		}

		$all_counts = array();
		foreach ( $fields_by_id as $field_id => $field ) {
			if ( (int) $field['parent_id'] !== 0 || 'repeater' !== $field['type'] ) {
				continue;
			}

			$field_id = (int) $field_id;
			if ( isset( $input[ $field_id ] ) && is_array( $input[ $field_id ] ) ) {
				$this->count_input_tree_field_occurrences( $input[ $field_id ], $fields_by_id, $all_counts, $only_non_empty );
			}
		}

		$translate_counts = array();
		foreach ( $all_counts as $field_id => $count ) {
			$field_id = (int) $field_id;
			if ( ! empty( $fields_by_id[ $field_id ] ) && $this->is_wpml_translate_preference_field( $fields_by_id[ $field_id ] ) ) {
				$translate_counts[ $field_id ] = (int) $count;
			}
		}

		return $translate_counts;
	}

	/**
	 * Get the latest non-completed TM job for a translated post.
	 *
	 * @param int    $post_id   Translated post ID.
	 * @param string $post_type Post type slug.
	 * @return int
	 */
	private function get_active_wpml_tm_job_id_for_post( $post_id, $post_type ) {
		global $wpdb;

		$post_id   = (int) $post_id;
		$post_type = (string) $post_type;
		if ( $post_id <= 0 || '' === $post_type ) {
			return 0;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$job_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT j.job_id
				FROM {$wpdb->prefix}icl_translate_job j
				INNER JOIN {$wpdb->prefix}icl_translation_status st ON st.rid = j.rid
				INNER JOIN {$wpdb->prefix}icl_translations t ON t.translation_id = st.translation_id
				WHERE t.element_id = %d
					AND t.element_type = %s
					AND t.source_language_code IS NOT NULL
					AND t.source_language_code <> ''
					AND j.translated = 0
				ORDER BY j.job_id DESC
				LIMIT 1",
				$post_id,
				'post_' . $post_type
			)
		);

		return (int) $job_id;
	}

	/**
	 * Get the latest TM job for a translated post, including completed jobs.
	 *
	 * @param int    $post_id   Translated post ID.
	 * @param string $post_type Post type slug.
	 * @return int
	 */
	private function get_latest_wpml_tm_job_id_for_post( $post_id, $post_type ) {
		global $wpdb;

		$post_id   = (int) $post_id;
		$post_type = (string) $post_type;
		if ( $post_id <= 0 || '' === $post_type ) {
			return 0;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$job_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT j.job_id
				FROM {$wpdb->prefix}icl_translate_job j
				INNER JOIN {$wpdb->prefix}icl_translation_status st ON st.rid = j.rid
				INNER JOIN {$wpdb->prefix}icl_translations t ON t.translation_id = st.translation_id
				WHERE t.element_id = %d
					AND t.element_type = %s
					AND t.source_language_code IS NOT NULL
					AND t.source_language_code <> ''
				ORDER BY j.job_id DESC
				LIMIT 1",
				$post_id,
				'post_' . $post_type
			)
		);

		return (int) $job_id;
	}

	/**
	 * Flag a translated post as needing a WPML update after repeater growth.
	 *
	 * Uses WPML's TranslationManagement updater so the language box shows the
	 * update arrow. Does not invent ATE occurrences.
	 *
	 * @param int    $translated_post_id Translated post ID.
	 * @param string $post_type          Post type slug.
	 * @return bool True when needs_update was set (or already set).
	 */
	private function maybe_mark_wpml_translation_needs_update( $translated_post_id, $post_type ) {
		$translated_post_id = (int) $translated_post_id;
		$post_type          = (string) $post_type;

		if ( $translated_post_id <= 0 || '' === $post_type ) {
			return false;
		}

		$translation_id = $this->get_wpml_translation_id_for_post( $translated_post_id, $post_type );
		if ( $translation_id <= 0 ) {
			return false;
		}

		if ( $this->wpml_translation_needs_update( $translation_id ) ) {
			return true;
		}

		if ( ! function_exists( 'wpml_load_core_tm' ) ) {
			return false;
		}

		$tm = wpml_load_core_tm();
		if ( ! is_object( $tm ) || ! method_exists( $tm, 'update_translation_status' ) ) {
			return false;
		}

		$tm->update_translation_status(
			array(
				'translation_id' => $translation_id,
				'needs_update'   => 1,
			)
		);

		return true;
	}

	/**
	 * Resolve the WPML translation_id for a translated post element.
	 *
	 * @param int    $post_id   Translated post ID.
	 * @param string $post_type Post type slug.
	 * @return int
	 */
	private function get_wpml_translation_id_for_post( $post_id, $post_type ) {
		global $wpdb;

		$post_id   = (int) $post_id;
		$post_type = (string) $post_type;
		if ( $post_id <= 0 || '' === $post_type ) {
			return 0;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$translation_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT translation_id
				FROM {$wpdb->prefix}icl_translations
				WHERE element_id = %d
					AND element_type = %s
					AND source_language_code IS NOT NULL
					AND source_language_code <> ''
				LIMIT 1",
				$post_id,
				'post_' . $post_type
			)
		);

		return (int) $translation_id;
	}

	/**
	 * Whether WPML already marks the translation as needing an update.
	 *
	 * @param int $translation_id WPML translation_id.
	 * @return bool
	 */
	private function wpml_translation_needs_update( $translation_id ) {
		global $wpdb;

		$translation_id = (int) $translation_id;
		if ( $translation_id <= 0 ) {
			return false;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$needs_update = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT needs_update
				FROM {$wpdb->prefix}icl_translation_status
				WHERE translation_id = %d
				ORDER BY rid DESC
				LIMIT 1",
				$translation_id
			)
		);

		return (int) $needs_update === 1;
	}

	/**
	 * Count real field occurrences in a WPML TM job.
	 *
	 * @param int $job_id WPML TM job ID.
	 * @return array<string,int>
	 */
	private function get_wpml_tm_job_field_occurrence_counts( $job_id ) {
		global $wpdb;

		$job_id = (int) $job_id;
		if ( $job_id <= 0 ) {
			return array();
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$field_types = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT field_type
				FROM {$wpdb->prefix}icl_translate
				WHERE job_id = %d
				ORDER BY tid ASC",
				$job_id
			)
		);

		$counts = array();
		foreach ( (array) $field_types as $field_type ) {
			$field_type = (string) $field_type;
			if ( ! preg_match( '/^field-([a-zA-Z0-9_]+)(?:-\d+)?$/', $field_type, $matches ) ) {
				continue;
			}

			$meta_key = $matches[1];
			if ( ! isset( $counts[ $meta_key ] ) ) {
				$counts[ $meta_key ] = 0;
			}
			++$counts[ $meta_key ];
		}

		return $counts;
	}

	/**
	 * Compare source leaf counts with a WPML job's field occurrence counts.
	 *
	 * Flags both missing occurrences (job lagging source growth) and surplus
	 * occurrences (job still carrying deleted source repeater rows).
	 *
	 * @param array<int,int>    $source_counts Source counts keyed by field ID.
	 * @param array<string,int> $job_counts    Job counts keyed by meta key.
	 * @param array<int,array>  $fields_by_id  Field definitions keyed by field ID.
	 * @return array<int,array{meta_key:string,source_count:int,job_count:int}>
	 */
	private function get_stale_wpml_repeater_fields( $source_counts, $job_counts, $fields_by_id ) {
		$stale_fields = array();
		$seen_keys    = array();

		foreach ( (array) $fields_by_id as $field_id => $field ) {
			$field_id = (int) $field_id;
			if (
				empty( $field['name'] )
				|| ! $this->is_wpml_translate_preference_field( $field )
				|| $this->is_layout_field_type( $field['type'] )
				|| ! $this->field_is_under_repeater( $field_id, $fields_by_id )
			) {
				continue;
			}

			$meta_key = (string) $field['name'];
			if ( isset( $seen_keys[ $meta_key ] ) ) {
				continue;
			}
			$seen_keys[ $meta_key ] = true;

			$source_count = isset( $source_counts[ $field_id ] ) ? (int) $source_counts[ $field_id ] : 0;
			$job_count    = isset( $job_counts[ $meta_key ] ) ? (int) $job_counts[ $meta_key ] : 0;

			if ( $job_count !== $source_count ) {
				$stale_fields[] = array(
					'meta_key'     => $meta_key,
					'source_count' => $source_count,
					'job_count'    => $job_count,
				);
			}
		}

		return $stale_fields;
	}

	/**
	 * Whether a field sits under a repeater (directly or nested).
	 *
	 * @param int   $field_id     Field ID.
	 * @param array $fields_by_id Field definitions keyed by ID.
	 * @return bool
	 */
	private function field_is_under_repeater( $field_id, $fields_by_id ) {
		$field_id = (int) $field_id;
		$guard    = 0;

		while ( $field_id > 0 && $guard < 50 ) {
			++$guard;
			if ( empty( $fields_by_id[ $field_id ] ) ) {
				return false;
			}

			$parent_id = isset( $fields_by_id[ $field_id ]['parent_id'] ) ? (int) $fields_by_id[ $field_id ]['parent_id'] : 0;
			if ( $parent_id <= 0 ) {
				return false;
			}

			if ( ! empty( $fields_by_id[ $parent_id ] ) && 'repeater' === $fields_by_id[ $parent_id ]['type'] ) {
				return true;
			}

			$field_id = $parent_id;
		}

		return false;
	}

	/**
	 * Clear stale-job diagnostics for one source post before rescanning it.
	 *
	 * @param int $source_post_id Source-language post ID.
	 * @return void
	 */
	private function clear_stale_wpml_job_diagnostics_for_source( $source_post_id ) {
		$source_post_id = (int) $source_post_id;
		if ( $source_post_id <= 0 ) {
			return;
		}

		$stored = get_transient( self::STALE_WPML_JOB_DIAGNOSTICS_TRANSIENT );
		if ( ! is_array( $stored ) || empty( $stored ) ) {
			return;
		}

		foreach ( $stored as $key => $diagnostic ) {
			if ( ! empty( $diagnostic['source_post_id'] ) && $source_post_id === (int) $diagnostic['source_post_id'] ) {
				unset( $stored[ $key ] );
			}
		}

		if ( empty( $stored ) ) {
			delete_transient( self::STALE_WPML_JOB_DIAGNOSTICS_TRANSIENT );
			return;
		}

		set_transient(
			self::STALE_WPML_JOB_DIAGNOSTICS_TRANSIENT,
			$stored,
			defined( 'DAY_IN_SECONDS' ) ? DAY_IN_SECONDS : 86400
		);
	}

	/**
	 * Retain stale-job diagnostics for the next relevant admin request.
	 *
	 * @param array<int,array<string,mixed>> $diagnostics Diagnostics to record.
	 * @return void
	 */
	private function record_stale_wpml_job_diagnostics( $diagnostics ) {
		if ( empty( $diagnostics ) || empty( $diagnostics[0]['source_post_id'] ) ) {
			return;
		}

		$stored = get_transient( self::STALE_WPML_JOB_DIAGNOSTICS_TRANSIENT );
		$stored = is_array( $stored ) ? $stored : array();

		foreach ( $stored as $key => $diagnostic ) {
			if ( ! empty( $diagnostic['source_post_id'] ) && (int) $diagnostic['source_post_id'] === (int) $diagnostics[0]['source_post_id'] ) {
				unset( $stored[ $key ] );
			}
		}

		foreach ( $diagnostics as $diagnostic ) {
			if ( empty( $diagnostic['source_post_id'] ) || empty( $diagnostic['translated_post_id'] ) || empty( $diagnostic['job_id'] ) ) {
				continue;
			}

			$key            = implode( ':', array( (int) $diagnostic['source_post_id'], (int) $diagnostic['translated_post_id'], (int) $diagnostic['job_id'] ) );
			$stored[ $key ] = $diagnostic;
		}

		$stored = array_slice( $stored, -50, 50, true );
		if ( empty( $stored ) ) {
			delete_transient( self::STALE_WPML_JOB_DIAGNOSTICS_TRANSIENT );
			return;
		}

		set_transient(
			self::STALE_WPML_JOB_DIAGNOSTICS_TRANSIENT,
			$stored,
			defined( 'DAY_IN_SECONDS' ) ? DAY_IN_SECONDS : 86400
		);
	}

	/**
	 * Queue a CFG index rebuild after WPML TM saves a translation job.
	 *
	 * @param int $job_id Translation job ID.
	 * @return void
	 */
	public function rebuild_cfg_index_after_tm_job_saved( $job_id ) {
		$job_id  = (int) $job_id;
		$post_id = $this->get_translated_post_id_from_tm_job( $job_id );
		if ( $post_id > 0 ) {
			$map = $this->load_tm_job_fields_as_meta_map( $job_id );
			if ( ! empty( $map ) ) {
				$this->wpml_translation_field_overrides[ $post_id ] = $map;
			}

			$this->schedule_cfg_index_rebuild( $post_id, 'post' );
		}
	}

	/**
	 * Queue a post CFG index rebuild when external code updates ASE postmeta.
	 *
	 * @param int    $meta_id    Meta ID.
	 * @param int    $object_id  Post ID.
	 * @param string $meta_key   Meta key.
	 * @param mixed  $meta_value Meta value.
	 * @return void
	 */
	public function maybe_schedule_cfg_index_rebuild_on_meta_change( $meta_id, $object_id, $meta_key, $meta_value ) {
		unset( $meta_id, $meta_value );

		if ( $this->rebuilding_cfg_index ) {
			return;
		}

		if ( ! $this->is_cfg_field_name( $meta_key, (int) $object_id, 'post' ) ) {
			return;
		}

		if (
			! $this->object_has_orphaned_cfg_index_rows( 'post', (int) $object_id )
			&& ! $this->object_has_unindexed_cfg_meta_rows( 'post', (int) $object_id )
		) {
			return;
		}

		$this->schedule_cfg_index_rebuild( (int) $object_id, 'post' );
	}

	/**
	 * Queue a post CFG index rebuild when external code deletes ASE postmeta.
	 *
	 * @param array  $meta_ids   Deleted meta IDs.
	 * @param int    $object_id  Post ID.
	 * @param string $meta_key   Meta key.
	 * @param mixed  $meta_value Meta value.
	 * @return void
	 */
	public function maybe_schedule_cfg_index_rebuild_on_meta_delete( $meta_ids, $object_id, $meta_key, $meta_value ) {
		unset( $meta_ids, $meta_value );

		if ( $this->rebuilding_cfg_index ) {
			return;
		}

		if ( wp_is_post_revision( (int) $object_id ) ) {
			return;
		}

		if ( ! $this->is_cfg_field_name( $meta_key, (int) $object_id, 'post' ) ) {
			return;
		}

		$this->schedule_cfg_index_rebuild( (int) $object_id, 'post' );
	}

	/**
	 * Queue a term CFG index rebuild when external code updates ASE termmeta.
	 *
	 * @param int    $meta_id    Meta ID.
	 * @param int    $object_id  Term ID.
	 * @param string $meta_key   Meta key.
	 * @param mixed  $meta_value Meta value.
	 * @return void
	 */
	public function maybe_schedule_cfg_index_rebuild_on_term_meta_change( $meta_id, $object_id, $meta_key, $meta_value ) {
		unset( $meta_id, $meta_value );

		if ( $this->rebuilding_cfg_index ) {
			return;
		}

		$term = get_term( (int) $object_id );
		if ( ! $term || is_wp_error( $term ) ) {
			return;
		}

		if ( ! $this->is_cfg_field_name( $meta_key, (int) $object_id, 'term', $term->taxonomy ) ) {
			return;
		}

		if (
			! $this->object_has_orphaned_cfg_index_rows( 'term', (int) $object_id )
			&& ! $this->object_has_unindexed_cfg_meta_rows( 'term', (int) $object_id )
		) {
			return;
		}

		$this->schedule_cfg_index_rebuild( (int) $object_id, 'term' );
	}

	/**
	 * Queue a term CFG index rebuild when external code deletes ASE termmeta.
	 *
	 * @param array  $meta_ids   Deleted meta IDs.
	 * @param int    $object_id  Term ID.
	 * @param string $meta_key   Meta key.
	 * @param mixed  $meta_value Meta value.
	 * @return void
	 */
	public function maybe_schedule_cfg_index_rebuild_on_term_meta_delete( $meta_ids, $object_id, $meta_key, $meta_value ) {
		unset( $meta_ids, $meta_value );

		if ( $this->rebuilding_cfg_index ) {
			return;
		}

		$term = get_term( (int) $object_id );
		if ( ! $term || is_wp_error( $term ) ) {
			return;
		}

		if ( ! $this->is_cfg_field_name( $meta_key, (int) $object_id, 'term', $term->taxonomy ) ) {
			return;
		}

		$this->schedule_cfg_index_rebuild( (int) $object_id, 'term' );
	}

	/**
	 * Process queued CFG index rebuilds once per request.
	 *
	 * @return void
	 */
	public function process_pending_cfg_index_rebuilds() {
		if ( empty( $this->posts_pending_cfg_rebuild ) || $this->rebuilding_cfg_index ) {
			return;
		}

		$pending = $this->posts_pending_cfg_rebuild;
		$this->posts_pending_cfg_rebuild = array();

		foreach ( $pending as $item ) {
			if ( 'term' === $item['object_type'] ) {
				$this->rebuild_term_cfg_index_from_termmeta( $item['object_id'] );
			} else {
				$this->rebuild_post_cfg_index_from_postmeta( $item['object_id'] );
			}
		}
	}

	/**
	 * Backfill posts and terms whose CFG index rows point to missing meta rows.
	 *
	 * @return void
	 */
	public function maybe_backfill_orphaned_cfg_indexes() {
		if ( $this->cfg_index_backfill_ran || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$this->cfg_index_backfill_ran = true;

		if ( self::CFG_INDEX_BACKFILL_VERSION === (string) get_option( self::CFG_INDEX_BACKFILL_OPTION, '' ) ) {
			return;
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$orphaned_post_ids = $wpdb->get_col(
			"SELECT DISTINCT v.post_id
			FROM {$wpdb->prefix}asenha_cfgroup_values v
			LEFT JOIN {$wpdb->postmeta} m ON m.meta_id = v.meta_id
			WHERE m.meta_id IS NULL"
		);

		foreach ( (array) $orphaned_post_ids as $post_id ) {
			$this->rebuild_post_cfg_index_from_postmeta( (int) $post_id );
		}

		// Posts with duplicate CFG meta rows that are not linked from the index
		// (typical after WPML ATE writes translations, then EN values are re-copied).
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$unindexed_post_ids = $wpdb->get_col(
			"SELECT DISTINCT pm.post_id
			FROM {$wpdb->postmeta} pm
			WHERE EXISTS (
				SELECT 1 FROM {$wpdb->prefix}asenha_cfgroup_values v WHERE v.post_id = pm.post_id
			)
			AND EXISTS (
				SELECT 1
				FROM {$wpdb->prefix}asenha_cfgroup_values v2
				INNER JOIN {$wpdb->postmeta} pm2 ON pm2.meta_id = v2.meta_id
				WHERE v2.post_id = pm.post_id AND pm2.meta_key = pm.meta_key
			)
			AND NOT EXISTS (
				SELECT 1 FROM {$wpdb->prefix}asenha_cfgroup_values v3 WHERE v3.meta_id = pm.meta_id
			)"
		);

		foreach ( (array) $unindexed_post_ids as $post_id ) {
			$this->rebuild_post_cfg_index_from_postmeta( (int) $post_id );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$orphaned_term_ids = $wpdb->get_col(
			"SELECT DISTINCT v.term_id
			FROM {$wpdb->prefix}asenha_cfgroup_values_for_terms v
			LEFT JOIN {$wpdb->termmeta} m ON m.meta_id = v.meta_id
			WHERE m.meta_id IS NULL"
		);

		foreach ( (array) $orphaned_term_ids as $term_id ) {
			$this->rebuild_term_cfg_index_from_termmeta( (int) $term_id );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$unindexed_term_ids = $wpdb->get_col(
			"SELECT DISTINCT tm.term_id
			FROM {$wpdb->termmeta} tm
			WHERE EXISTS (
				SELECT 1 FROM {$wpdb->prefix}asenha_cfgroup_values_for_terms v WHERE v.term_id = tm.term_id
			)
			AND EXISTS (
				SELECT 1
				FROM {$wpdb->prefix}asenha_cfgroup_values_for_terms v2
				INNER JOIN {$wpdb->termmeta} tm2 ON tm2.meta_id = v2.meta_id
				WHERE v2.term_id = tm.term_id AND tm2.meta_key = tm.meta_key
			)
			AND NOT EXISTS (
				SELECT 1 FROM {$wpdb->prefix}asenha_cfgroup_values_for_terms v3 WHERE v3.meta_id = tm.meta_id
			)"
		);

		foreach ( (array) $unindexed_term_ids as $term_id ) {
			$this->rebuild_term_cfg_index_from_termmeta( (int) $term_id );
		}

		// v11: last-resort flat meta must not overwrite a pinned empty
		// source leaf (WPML FIFO 7 km on Casa Karla vs Chianni).
		// v10: pin omitted empty source leaves so WPML's write of
		// location_value-0 onto Casa Karla cannot survive hydrate.
		// v9: map ATE job ordinals onto non-empty source slots so an omitted
		// empty location_value does not shift 7 km onto Casa Karla.
		// v8: keep mixed-count completed ATE jobs (12 location labels / 11
		// values) so Extra room 8 rebuilds do not abort on sibling repeaters.
		// v7: drop English source-growth repeater rows that a completed TM/ATE
		// job does not yet cover (Extra room 7 appearing on NL before translation).
		// v6: re-run translated repeater rebuilds after ATE completion left
		// orphaned index rows (deleted meta_ids) and unindexed translate-preference
		// values because duplicate copy-field anchors aborted the previous save.
		// v5: rebuild translated posts containing repeaters even when their
		// counts look correct. A flat FIFO rebuild can swap equal-sized rows
		// without leaving an orphaned index or a missing leaf to detect. Include
		// translated posts without CFG index rows so a sparse legacy save can be
		// repaired from the source tree.
		$repeater_post_ids = $this->find_translated_posts_with_repeater_mappings();
		foreach ( $repeater_post_ids as $post_id ) {
			unset( $this->processed_duplicates[ 'rebuild:post:' . (int) $post_id ] );
			$this->rebuild_post_cfg_index_from_postmeta( (int) $post_id );
		}

		// v3: translated posts whose CFG trees lost translate-preference repeater leaves
		// relative to the source-language post (blank Indeling titles after sparse rebuild).
		$sparse_post_ids = $this->find_translated_posts_with_missing_translate_leaves();
		foreach ( $sparse_post_ids as $post_id ) {
			unset( $this->processed_duplicates[ 'rebuild:post:' . (int) $post_id ] );
			$this->rebuild_post_cfg_index_from_postmeta( (int) $post_id );
		}

		update_option( self::CFG_INDEX_BACKFILL_OPTION, self::CFG_INDEX_BACKFILL_VERSION, true );
	}

	/**
	 * Find translated posts whose source contains a repeater field.
	 *
	 * The path-aware rebuild is intentionally run for all such posts during
	 * the v5 migration because equal row counts do not prove that values still
	 * belong to the correct parent row. The candidate list also includes
	 * translated ASE-generated posts with no CFG index rows at all.
	 *
	 * @return array<int,int>
	 */
	private function find_translated_posts_with_repeater_mappings() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$post_ids = $wpdb->get_col(
			"SELECT DISTINCT post_id FROM {$wpdb->prefix}asenha_cfgroup_values"
		);

		$generated_post_types = $this->get_asenha_generated_post_type_slugs();
		if ( ! empty( $generated_post_types ) ) {
			$post_type_placeholders = implode( ', ', array_fill( 0, count( $generated_post_types ), '%s' ) );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$translated_generated_post_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT t.element_id
					FROM {$wpdb->prefix}icl_translations t
					INNER JOIN {$wpdb->posts} p ON p.ID = t.element_id
					WHERE t.element_id > 0
					AND t.element_type LIKE 'post-%%'
					AND p.post_type IN ({$post_type_placeholders})",
					$generated_post_types
				)
			);

			$post_ids = array_merge( (array) $post_ids, (array) $translated_generated_post_ids );
		}

		$post_ids = array_values( array_unique( array_map( 'intval', $post_ids ) ) );
		$matching = array();

		foreach ( (array) $post_ids as $post_id ) {
			$post = get_post( (int) $post_id );
			if ( ! $post || empty( $post->post_type ) ) {
				continue;
			}

			$source_id = $this->get_source_post_id_for_translation( (int) $post_id, $post->post_type );
			if ( $source_id <= 0 || $source_id === (int) $post_id ) {
				continue;
			}

			$group_ids = array_keys( (array) CFG()->api->get_matching_groups( (int) $post_id, true ) );
			if ( empty( $group_ids ) ) {
				continue;
			}

			$field_defs = CFG()->api->find_input_fields( array( 'group_id' => $group_ids ) );
			$fields_by_id = array();
			foreach ( (array) $field_defs as $field ) {
				$fields_by_id[ (int) $field['id'] ] = $field;
			}

			$source_input = CFG()->get( false, (int) $source_id, array( 'format' => 'input' ) );
			if ( ! is_array( $source_input ) ) {
				continue;
			}

			foreach ( $source_input as $field_id => $value ) {
				if (
					isset( $fields_by_id[ (int) $field_id ] )
					&& 'repeater' === $fields_by_id[ (int) $field_id ]['type']
					&& is_array( $value )
				) {
					$matching[] = (int) $post_id;
					break;
				}
			}
		}

		return array_values( array_unique( $matching ) );
	}

	/**
	 * Find translated posts whose CFG input is missing translate leaves present on the source.
	 *
	 * @return array<int,int>
	 */
	private function find_translated_posts_with_missing_translate_leaves() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$post_ids = $wpdb->get_col(
			"SELECT DISTINCT post_id FROM {$wpdb->prefix}asenha_cfgroup_values"
		);

		$missing = array();

		foreach ( (array) $post_ids as $post_id ) {
			$post_id = (int) $post_id;
			$post    = get_post( $post_id );
			if ( ! $post || empty( $post->post_type ) ) {
				continue;
			}

			$source_id = $this->get_source_post_id_for_translation( $post_id, $post->post_type );
			if ( $source_id <= 0 || $source_id === $post_id ) {
				continue;
			}

			if ( $this->translated_post_missing_translate_leaves( $post_id, $source_id ) ) {
				$missing[] = $post_id;
			}
		}

		return array_values( array_unique( $missing ) );
	}

	/**
	 * Whether a translated post's CFG input lacks translate-preference leaves vs source.
	 *
	 * @param int $post_id   Translated post ID.
	 * @param int $source_id Source-language post ID.
	 * @return bool
	 */
	private function translated_post_missing_translate_leaves( $post_id, $source_id ) {
		$field_groups = array_keys( (array) CFG()->api->get_matching_groups( $post_id, true ) );
		if ( empty( $field_groups ) ) {
			return false;
		}

		$field_defs = CFG()->api->find_input_fields( array( 'group_id' => $field_groups ) );
		if ( empty( $field_defs ) ) {
			return false;
		}

		$fields_by_id = array();
		foreach ( $field_defs as $field ) {
			$fields_by_id[ (int) $field['id'] ] = $field;
		}

		$target_input = CFG()->get( false, $post_id, array( 'format' => 'input' ) );
		$source_input = CFG()->get( false, $source_id, array( 'format' => 'input' ) );
		if ( ! is_array( $target_input ) ) {
			$target_input = array();
		}
		if ( ! is_array( $source_input ) || empty( $source_input ) ) {
			return false;
		}

		$target_counts = array();
		$source_counts = array();
		foreach ( $source_input as $field_id => $value ) {
			$field_id = (int) $field_id;
			if ( empty( $fields_by_id[ $field_id ] ) || 'repeater' !== $fields_by_id[ $field_id ]['type'] ) {
				continue;
			}
			if ( is_array( $value ) ) {
				$this->count_input_tree_field_occurrences( $value, $fields_by_id, $source_counts );
			}
			if ( isset( $target_input[ $field_id ] ) && is_array( $target_input[ $field_id ] ) ) {
				$this->count_input_tree_field_occurrences( $target_input[ $field_id ], $fields_by_id, $target_counts );
			}
		}

		foreach ( $source_counts as $field_id => $source_count ) {
			if ( empty( $fields_by_id[ $field_id ] ) || ! $this->is_wpml_translate_preference_field( $fields_by_id[ $field_id ] ) ) {
				continue;
			}
			$target_count = isset( $target_counts[ $field_id ] ) ? (int) $target_counts[ $field_id ] : 0;
			if ( $target_count < (int) $source_count ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether a translated post's CFG input has surplus translate leaves vs source.
	 *
	 * @param int $post_id   Translated post ID.
	 * @param int $source_id Source-language post ID.
	 * @return bool
	 */
	private function translated_post_has_surplus_translate_leaves( $post_id, $source_id ) {
		$field_groups = array_keys( (array) CFG()->api->get_matching_groups( $post_id, true ) );
		if ( empty( $field_groups ) ) {
			return false;
		}

		$field_defs = CFG()->api->find_input_fields( array( 'group_id' => $field_groups ) );
		if ( empty( $field_defs ) ) {
			return false;
		}

		$fields_by_id = array();
		foreach ( $field_defs as $field ) {
			$fields_by_id[ (int) $field['id'] ] = $field;
		}

		$target_input = CFG()->get( false, $post_id, array( 'format' => 'input' ) );
		$source_input = CFG()->get( false, $source_id, array( 'format' => 'input' ) );
		if ( ! is_array( $target_input ) ) {
			$target_input = array();
		}
		if ( ! is_array( $source_input ) ) {
			$source_input = array();
		}

		$target_counts = array();
		$source_counts = array();

		foreach ( $fields_by_id as $field_id => $field ) {
			$field_id = (int) $field_id;
			if ( (int) $field['parent_id'] !== 0 || 'repeater' !== $field['type'] ) {
				continue;
			}

			if ( isset( $source_input[ $field_id ] ) && is_array( $source_input[ $field_id ] ) ) {
				$this->count_input_tree_field_occurrences( $source_input[ $field_id ], $fields_by_id, $source_counts );
			}
			if ( isset( $target_input[ $field_id ] ) && is_array( $target_input[ $field_id ] ) ) {
				$this->count_input_tree_field_occurrences( $target_input[ $field_id ], $fields_by_id, $target_counts );
			}
		}

		foreach ( $target_counts as $field_id => $target_count ) {
			if ( empty( $fields_by_id[ $field_id ] ) || ! $this->is_wpml_translate_preference_field( $fields_by_id[ $field_id ] ) ) {
				continue;
			}
			$source_count = isset( $source_counts[ $field_id ] ) ? (int) $source_counts[ $field_id ] : 0;
			if ( (int) $target_count > $source_count ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check whether an object has CFG index rows pointing to missing meta rows.
	 *
	 * @param string $object_type post or term.
	 * @param int    $object_id   Post or term ID.
	 * @return bool
	 */
	private function object_has_orphaned_cfg_index_rows( $object_type, $object_id ) {
		global $wpdb;

		$object_id = (int) $object_id;
		if ( $object_id <= 0 ) {
			return false;
		}

		$object_type = ( 'term' === $object_type ) ? 'term' : 'post';
		$cache_key   = 'orphaned:' . $object_type . ':' . $object_id;
		if ( array_key_exists( $cache_key, $this->cfg_index_integrity_cache ) ) {
			return $this->cfg_index_integrity_cache[ $cache_key ];
		}

		if ( 'term' === $object_type ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$found = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT 1
					FROM {$wpdb->prefix}asenha_cfgroup_values_for_terms v
					LEFT JOIN {$wpdb->termmeta} m ON m.meta_id = v.meta_id
					WHERE v.term_id = %d AND m.meta_id IS NULL
					LIMIT 1",
					$object_id
				)
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$found = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT 1
					FROM {$wpdb->prefix}asenha_cfgroup_values v
					LEFT JOIN {$wpdb->postmeta} m ON m.meta_id = v.meta_id
					WHERE v.post_id = %d AND m.meta_id IS NULL
					LIMIT 1",
					$object_id
				)
			);
		}

		$result = null !== $found;
		$this->cfg_index_integrity_cache[ $cache_key ] = $result;

		return $result;
	}

	/**
	 * Queue one object for CFG index rebuild on shutdown.
	 *
	 * @param int    $object_id   Post or term ID.
	 * @param string $object_type post or term.
	 * @return void
	 */
	private function schedule_cfg_index_rebuild( $object_id, $object_type = 'post' ) {
		$object_id = (int) $object_id;
		if ( $object_id <= 0 ) {
			return;
		}

		$object_type = ( 'term' === $object_type ) ? 'term' : 'post';
		$key         = $object_type . ':' . $object_id;

		$this->clear_cfg_index_integrity_cache( $object_type, $object_id );

		$this->posts_pending_cfg_rebuild[ $key ] = array(
			'object_type' => $object_type,
			'object_id'   => $object_id,
		);
	}

	/**
	 * Clear request-scoped CFG integrity memoization for one object.
	 *
	 * @param string $object_type post or term.
	 * @param int    $object_id   Post or term ID.
	 * @return void
	 */
	private function clear_cfg_index_integrity_cache( $object_type, $object_id ) {
		$object_type = ( 'term' === $object_type ) ? 'term' : 'post';
		$object_id   = (int) $object_id;
		$suffix      = $object_type . ':' . $object_id;

		unset(
			$this->cfg_index_integrity_cache[ 'has_index:' . $suffix ],
			$this->cfg_index_integrity_cache[ 'orphaned:' . $suffix ],
			$this->cfg_index_integrity_cache[ 'unindexed:' . $suffix ]
		);
	}

	/**
	 * Resolve the translated post ID from a WPML TM job ID.
	 *
	 * @param int $job_id Translation job ID.
	 * @return int
	 */
	private function get_translated_post_id_from_tm_job( $job_id ) {
		global $wpdb;

		$job_id = (int) $job_id;
		if ( $job_id <= 0 ) {
			return 0;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rid = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT rid FROM {$wpdb->prefix}icl_translate_job WHERE job_id = %d",
				$job_id
			)
		);

		if ( empty( $rid ) ) {
			return 0;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$post_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT t.element_id
				FROM {$wpdb->prefix}icl_translation_status st
				INNER JOIN {$wpdb->prefix}icl_translations t ON t.translation_id = st.translation_id
				WHERE st.rid = %d
					AND t.element_type LIKE %s
					AND t.source_language_code IS NOT NULL
					AND t.source_language_code <> ''
				ORDER BY t.element_id ASC
				LIMIT 1",
				(int) $rid,
				$wpdb->esc_like( 'post_' ) . '%'
			)
		);

		$post_id = (int) $post_id;
		if ( $post_id <= 0 || ! get_post( $post_id ) ) {
			return 0;
		}

		return $post_id;
	}

	/**
	 * Reset per-request repeater mapping state.
	 *
	 * @return void
	 */
	private function reset_repeater_mapping_state() {
		$this->repeater_mapping_ambiguous = false;
		$this->repeater_mapping_warnings  = array();
	}

	/**
	 * Mark the current repeater mapping as unsafe.
	 *
	 * @param string $message Mapping warning.
	 * @return void
	 */
	private function mark_repeater_mapping_ambiguous( $message ) {
		$this->repeater_mapping_ambiguous = true;

		if ( '' !== (string) $message ) {
			$this->repeater_mapping_warnings[] = (string) $message;
		}
	}

	/**
	 * Log mapping warnings when WordPress debugging is enabled.
	 *
	 * @param string $object_type post or term.
	 * @param int    $object_id   Object ID.
	 * @return void
	 */
	private function log_repeater_mapping_warnings( $object_type, $object_id ) {
		if ( empty( $this->repeater_mapping_warnings ) || ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
			return;
		}

		$message = sprintf(
			'ASE WPML repeater rebuild skipped for %1$s %2$d: %3$s',
			(string) $object_type,
			(int) $object_id,
			implode( '; ', array_unique( $this->repeater_mapping_warnings ) )
		);

		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( $message );
	}

	/**
	 * Snapshot CFG index rows and their currently referenced meta values.
	 *
	 * The hierarchy column is the only durable parent/row relationship once
	 * repeated values have been flattened into postmeta or termmeta.
	 *
	 * @param string $object_type post or term.
	 * @param int    $object_id   Post or term ID.
	 * @return array{rows:array,by_path:array,by_field:array}
	 */
	private function get_cfg_hierarchy_snapshot( $object_type, $object_id ) {
		global $wpdb;

		$object_id = (int) $object_id;
		$snapshot  = array(
			'rows'     => array(),
			'by_path'  => array(),
			'by_field' => array(),
		);

		if ( $object_id <= 0 ) {
			return $snapshot;
		}

		if ( 'term' === $object_type ) {
			$values_table = $wpdb->prefix . 'asenha_cfgroup_values_for_terms';
			$meta_table   = $wpdb->termmeta;
			$where        = 'v.term_id = %d';
		} else {
			$values_table = $wpdb->prefix . 'asenha_cfgroup_values';
			$meta_table   = $wpdb->postmeta;
			$where        = 'v.post_id = %d';
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT v.id, v.field_id, v.hierarchy, v.meta_id, m.meta_key, m.meta_value
				FROM {$values_table} v
				LEFT JOIN {$meta_table} m ON m.meta_id = v.meta_id
				WHERE {$where}
				ORDER BY v.id ASC",
				$object_id
			),
			ARRAY_A
		);

		foreach ( (array) $rows as $row ) {
			$row['field_id'] = (int) $row['field_id'];
			$row['meta_id']  = (int) $row['meta_id'];
			$row['hierarchy'] = trim( (string) $row['hierarchy'] );

			$snapshot['rows'][] = $row;
			$snapshot['by_field'][ $row['field_id'] ][] = $row;

			if ( '' !== $row['hierarchy'] ) {
				$snapshot['by_path'][ $row['hierarchy'] ][] = $row;
			}
		}

		return $snapshot;
	}

	/**
	 * Build a depth-first list of translatable repeater leaf slots.
	 *
	 * Each slot contains the complete field/row path, not only the leaf field
	 * ID. This makes a nested feature slot belonging to room 0 distinct from
	 * the same field belonging to room 1.
	 *
	 * @param array $repeater_rows Repeater input rows.
	 * @param array $fields_by_id  Field definitions keyed by ID.
	 * @param int   $root_field_id Root repeater field ID.
	 * @return array<int,array<string,mixed>>
	 */
	private function get_repeater_leaf_slots( $repeater_rows, $fields_by_id, $root_field_id ) {
		$slots = array();
		$root_field_id = (int) $root_field_id;

		if ( $root_field_id <= 0 || ! is_array( $repeater_rows ) ) {
			return $slots;
		}

		$this->collect_repeater_leaf_slots(
			$repeater_rows,
			$fields_by_id,
			array( $root_field_id ),
			$slots
		);

		$ordinals = array();
		foreach ( $slots as $index => $slot ) {
			$field_id = (int) $slot['field_id'];
			if ( ! isset( $ordinals[ $field_id ] ) ) {
				$ordinals[ $field_id ] = 0;
			}

			$slots[ $index ]['ordinal'] = $ordinals[ $field_id ];
			++$ordinals[ $field_id ];
		}

		return $slots;
	}

	/**
	 * Recursively collect repeater leaf slots.
	 *
	 * @param mixed $node         Current input node.
	 * @param array $fields_by_id Field definitions keyed by ID.
	 * @param array $prefix       Current hierarchy segments.
	 * @param array $slots        Collected slots, passed by reference.
	 * @return void
	 */
	private function collect_repeater_leaf_slots( $node, $fields_by_id, $prefix, &$slots ) {
		if ( ! is_array( $node ) ) {
			return;
		}

		if ( $this->is_input_rows_list( $node ) ) {
			foreach ( $node as $row_index => $row ) {
				$row_prefix = array_merge( $prefix, array( (int) $row_index ) );
				$this->collect_repeater_leaf_slots( $row, $fields_by_id, $row_prefix, $slots );
			}
			return;
		}

		foreach ( $node as $field_id => $value ) {
			$field_id = (int) $field_id;
			if ( empty( $fields_by_id[ $field_id ] ) ) {
				continue;
			}

			$field      = $fields_by_id[ $field_id ];
			$field_path = array_merge( $prefix, array( $field_id ) );

			if ( 'repeater' === $field['type'] && is_array( $value ) ) {
				$this->collect_repeater_leaf_slots( $value, $fields_by_id, $field_path, $slots );
				continue;
			}

			if ( ! $this->is_wpml_translate_preference_field( $field ) || $this->is_layout_field_type( $field['type'] ) ) {
				continue;
			}

			$slots[] = array(
				'field_id' => $field_id,
				'field_name' => (string) $field['name'],
				'path'     => implode( ':', $field_path ),
				'row_path' => implode( ':', $prefix ),
				'value'    => $value,
			);
		}
	}

	/**
	 * Group leaf slots by field ID.
	 *
	 * @param array $slots Leaf slots.
	 * @return array<int,array<int,array<string,mixed>>>
	 */
	private function group_repeater_slots_by_field( $slots ) {
		$grouped = array();

		foreach ( (array) $slots as $slot ) {
			$field_id = (int) $slot['field_id'];
			$grouped[ $field_id ][] = $slot;
		}

		return $grouped;
	}

	/**
	 * Slot list WPML job ordinals should address.
	 *
	 * WPML omits empty translate leaves from field-{key}-{n}. When the job
	 * entry count matches the non-empty slot count, ordinal n is the nth
	 * non-empty source leaf (Casa Karla empty Value, then Chianni 7 km as
	 * location_value-0). When counts match all slots, the job packaged
	 * empties and ordinals stay dense including empty leaves.
	 *
	 * @param array $slots   Slots for one field in occurrence order.
	 * @param array $entries Job override entries for that field.
	 * @return array
	 */
	private function get_wpml_job_occurrence_slots( $slots, $entries ) {
		$all = array_values( (array) $slots );
		if ( empty( $all ) ) {
			return array();
		}

		$nonempty = array();
		foreach ( $all as $slot ) {
			$value = isset( $slot['value'] ) ? $slot['value'] : null;
			if ( $this->is_empty_input_leaf_value( $value ) ) {
				continue;
			}
			$nonempty[] = $slot;
		}

		if ( count( $entries ) === count( $all ) ) {
			return $all;
		}

		return $nonempty;
	}

	/**
	 * Check whether a complete path exists in a slot list.
	 *
	 * @param array  $slots Leaf slots.
	 * @param string $path  Hierarchy path.
	 * @return bool
	 */
	private function repeater_path_exists( $slots, $path ) {
		foreach ( (array) $slots as $slot ) {
			if ( isset( $slot['path'] ) && (string) $slot['path'] === (string) $path ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Align source and target repeater row keys.
	 *
	 * Copy-preference fields provide stable anchors for parent rows. When no
	 * anchor exists, equal-size lists can safely use their preserved ordinal;
	 * unmatched rows are left unmapped so an appended row cannot consume an
	 * older row's translation.
	 *
	 * @param array $source_rows   Source repeater rows.
	 * @param array $target_rows   Target repeater rows.
	 * @param int   $repeater_id   Repeater field ID.
	 * @param array $fields_by_id  Field definitions keyed by ID.
	 * @return array<int,int>
	 */
	private function align_repeater_row_keys( $source_rows, $target_rows, $repeater_id, $fields_by_id ) {
		$source_keys = array_keys( (array) $source_rows );
		$target_keys = array_keys( (array) $target_rows );
		$row_map     = array();
		$used_target = array();
		$source_anchor_keys = array();
		$target_anchor_keys = array();

		foreach ( $source_keys as $source_key ) {
			$anchor = $this->get_repeater_row_anchor( $source_rows[ $source_key ], $repeater_id, $fields_by_id );
			if ( '' === $anchor ) {
				continue;
			}

			$source_anchor_keys[ $anchor ][] = $source_key;
		}

		foreach ( $target_keys as $target_key ) {
			$anchor = $this->get_repeater_row_anchor( $target_rows[ $target_key ], $repeater_id, $fields_by_id );
			if ( '' === $anchor ) {
				continue;
			}

			$target_anchor_keys[ $anchor ][] = $target_key;
		}

		foreach ( $source_anchor_keys as $anchor => $source_matches ) {
			if ( count( $source_matches ) !== 1 ) {
				continue;
			}

			if ( empty( $target_anchor_keys[ $anchor ] ) || count( $target_anchor_keys[ $anchor ] ) !== 1 ) {
				continue;
			}

			$source_key = $source_matches[0];
			$target_key = $target_anchor_keys[ $anchor ][0];

			if ( isset( $row_map[ $source_key ] ) || isset( $used_target[ $target_key ] ) ) {
				$this->mark_repeater_mapping_ambiguous(
					sprintf( 'Unique anchor collision for repeater %d.', (int) $repeater_id )
				);
				continue;
			}

			$row_map[ $source_key ]        = $target_key;
			$used_target[ $target_key ]    = true;
		}

		// Preserve the numeric row path for rows without a usable unique anchor.
		foreach ( $source_keys as $source_key ) {
			if ( isset( $row_map[ $source_key ] ) ) {
				continue;
			}

			if ( array_key_exists( $source_key, $target_rows ) && ! isset( $used_target[ $source_key ] ) ) {
				$row_map[ $source_key ]     = $source_key;
				$used_target[ $source_key ] = true;
			}
		}

		// Pair leftover rows by list ordinal only when both sides have the same
		// number of rows (reindexed equal-size lists). When counts differ, a
		// gapped new source key (e.g. Extra room 3 at 12 after deleting 10–11)
		// must stay unmapped so graft creates a fresh row instead of stealing
		// a leftover deleted slot.
		if ( count( $source_keys ) === count( $target_keys ) ) {
			$remaining_source = array_values( array_diff( $source_keys, array_keys( $row_map ) ) );
			$remaining_target = array_values( array_diff( $target_keys, array_keys( $used_target ) ) );

			foreach ( $remaining_source as $index => $source_key ) {
				if ( isset( $remaining_target[ $index ] ) ) {
					$row_map[ $source_key ]                     = $remaining_target[ $index ];
					$used_target[ $remaining_target[ $index ] ] = true;
				}
			}
		}

		return $row_map;
	}

	/**
	 * Whether copy-preference row hashes are duplicated on source or target.
	 *
	 * Duplicate floors/surfaces are normal and must not abort a rebuild. They
	 * only make surplus deletion unsafe because the extra row cannot be identified.
	 *
	 * @param array $source_rows  Source repeater rows.
	 * @param array $target_rows  Target repeater rows.
	 * @param int   $repeater_id  Repeater field ID.
	 * @param array $fields_by_id Field definitions keyed by ID.
	 * @return bool
	 */
	private function repeater_copy_anchors_are_non_unique( $source_rows, $target_rows, $repeater_id, $fields_by_id ) {
		foreach ( array( $source_rows, $target_rows ) as $rows ) {
			$seen = array();

			foreach ( array_keys( (array) $rows ) as $row_key ) {
				$anchor = $this->get_repeater_row_anchor( $rows[ $row_key ], $repeater_id, $fields_by_id );
				if ( '' === $anchor ) {
					continue;
				}

				if ( isset( $seen[ $anchor ] ) ) {
					return true;
				}

				$seen[ $anchor ] = true;
			}
		}

		return false;
	}

	/**
	 * Whether a repeater row contains any non-empty translate-preference leaves.
	 *
	 * Copy-only remnants (floor/surface with no room_name or nested feature_label)
	 * become blank frontend cards and must not be kept during surplus prune.
	 *
	 * @param array $row          Repeater row.
	 * @param array $fields_by_id Field definitions keyed by ID.
	 * @param int   $repeater_id  Current repeater field ID.
	 * @return bool
	 */
	private function repeater_row_has_translate_leaves( $row, $fields_by_id, $repeater_id ) {
		if ( ! is_array( $row ) ) {
			return false;
		}

		foreach ( $row as $field_id => $value ) {
			$field_id = (int) $field_id;
			if ( empty( $fields_by_id[ $field_id ] ) ) {
				continue;
			}

			$field = $fields_by_id[ $field_id ];
			if ( (int) $field['parent_id'] !== (int) $repeater_id ) {
				continue;
			}

			if ( 'repeater' === $field['type'] && is_array( $value ) ) {
				foreach ( $value as $child_row ) {
					if ( $this->repeater_row_has_translate_leaves( $child_row, $fields_by_id, $field_id ) ) {
						return true;
					}
				}
				continue;
			}

			if ( $this->is_wpml_translate_preference_field( $field ) && ! $this->is_empty_input_leaf_value( $value ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether a target repeater has fewer rows or translate leaves than the source.
	 *
	 * @param array $target_rows  Target repeater rows.
	 * @param array $source_rows  Source repeater rows.
	 * @param array $fields_by_id Field definitions keyed by ID.
	 * @param int   $repeater_id  Repeater field ID.
	 * @return bool
	 */
	private function repeater_target_lags_source( $target_rows, $source_rows, $fields_by_id, $repeater_id ) {
		if ( ! is_array( $source_rows ) || empty( $source_rows ) ) {
			return false;
		}

		if ( ! is_array( $target_rows ) || count( $target_rows ) < count( $source_rows ) ) {
			return true;
		}

		$source_slots  = $this->get_repeater_leaf_slots( $source_rows, $fields_by_id, $repeater_id );
		$target_slots  = $this->get_repeater_leaf_slots( $target_rows, $fields_by_id, $repeater_id );
		$source_counts = array();
		$target_counts = array();

		foreach ( $source_slots as $slot ) {
			$field_id = (int) $slot['field_id'];
			if ( ! isset( $source_counts[ $field_id ] ) ) {
				$source_counts[ $field_id ] = 0;
			}
			++$source_counts[ $field_id ];
		}

		foreach ( $target_slots as $slot ) {
			$field_id = (int) $slot['field_id'];
			if ( ! isset( $target_counts[ $field_id ] ) ) {
				$target_counts[ $field_id ] = 0;
			}
			++$target_counts[ $field_id ];
		}

		foreach ( $source_counts as $field_id => $source_count ) {
			$target_count = isset( $target_counts[ $field_id ] ) ? (int) $target_counts[ $field_id ] : 0;
			if ( $target_count < (int) $source_count ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Build an anchor from copy-preference fields in one repeater row.
	 *
	 * @param mixed $row          Repeater row.
	 * @param int   $repeater_id  Repeater field ID.
	 * @param array $fields_by_id Field definitions keyed by ID.
	 * @return string
	 */
	private function get_repeater_row_anchor( $row, $repeater_id, $fields_by_id ) {
		if ( ! is_array( $row ) ) {
			return '';
		}

		$anchor_values = array();
		foreach ( $fields_by_id as $field_id => $field ) {
			if ( (int) $field['parent_id'] !== (int) $repeater_id || 'repeater' === $field['type'] || $this->is_layout_field_type( $field['type'] ) ) {
				continue;
			}

			if ( $this->is_wpml_translate_preference_field( $field ) || ! array_key_exists( (int) $field_id, $row ) ) {
				continue;
			}

			$value = $this->normalize_input_leaf_value( $row[ (int) $field_id ] );
			if ( is_array( $value ) || is_object( $value ) ) {
				$value = wp_json_encode( $value );
			}

			if ( null === $value || '' === (string) $value ) {
				continue;
			}

			$anchor_values[ (int) $field_id ] = (string) $value;
		}

		if ( empty( $anchor_values ) ) {
			return '';
		}

		return md5( wp_json_encode( $anchor_values ) );
	}

	/**
	 * Map source repeater leaf paths to target repeater leaf paths.
	 *
	 * @param array $source_rows   Source repeater rows.
	 * @param array $target_rows   Target repeater rows.
	 * @param int   $repeater_id   Root/current repeater field ID.
	 * @param array $fields_by_id  Field definitions keyed by ID.
	 * @param array $source_prefix Source path prefix.
	 * @param array $target_prefix Target path prefix.
	 * @param array $path_map      Source-to-target map, passed by reference.
	 * @return void
	 */
	private function build_repeater_path_alignment( $source_rows, $target_rows, $repeater_id, $fields_by_id, $source_prefix, $target_prefix, &$path_map ) {
		if ( ! is_array( $source_rows ) || ! is_array( $target_rows ) ) {
			return;
		}

		$row_map = $this->align_repeater_row_keys( $source_rows, $target_rows, $repeater_id, $fields_by_id );

		foreach ( $row_map as $source_row_key => $target_row_key ) {
			if ( ! array_key_exists( $source_row_key, $source_rows ) || ! array_key_exists( $target_row_key, $target_rows ) ) {
				continue;
			}

			$source_row = is_array( $source_rows[ $source_row_key ] ) ? $source_rows[ $source_row_key ] : array();
			$target_row = is_array( $target_rows[ $target_row_key ] ) ? $target_rows[ $target_row_key ] : array();
			$source_row_prefix = array_merge( $source_prefix, array( (int) $source_row_key ) );
			$target_row_prefix = array_merge( $target_prefix, array( (int) $target_row_key ) );

			foreach ( $source_row as $field_id => $source_value ) {
				$field_id = (int) $field_id;
				if ( empty( $fields_by_id[ $field_id ] ) || ! array_key_exists( $field_id, $target_row ) ) {
					continue;
				}

				$field = $fields_by_id[ $field_id ];
				if ( 'repeater' === $field['type'] && is_array( $source_value ) && is_array( $target_row[ $field_id ] ) ) {
					$this->build_repeater_path_alignment(
						$source_value,
						$target_row[ $field_id ],
						$field_id,
						$fields_by_id,
						array_merge( $source_row_prefix, array( $field_id ) ),
						array_merge( $target_row_prefix, array( $field_id ) ),
						$path_map
					);
					continue;
				}

				if ( ! $this->is_wpml_translate_preference_field( $field ) || $this->is_layout_field_type( $field['type'] ) ) {
					continue;
				}

				$source_path = implode( ':', array_merge( $source_row_prefix, array( $field_id ) ) );
				$target_path = implode( ':', array_merge( $target_row_prefix, array( $field_id ) ) );
				$path_map[ $source_path ] = $target_path;
			}
		}
	}

	/**
	 * Apply values keyed by complete hierarchy path to an input tree.
	 *
	 * @param mixed $node         Current input node.
	 * @param array $fields_by_id Field definitions keyed by ID.
	 * @param array $prefix       Current path prefix.
	 * @param array $path_values  Values keyed by hierarchy path, by reference.
	 * @return mixed
	 */
	private function apply_repeater_path_values_to_input_tree( $node, $fields_by_id, $prefix, &$path_values ) {
		if ( ! is_array( $node ) ) {
			return $node;
		}

		if ( $this->is_input_rows_list( $node ) ) {
			foreach ( $node as $row_index => $row ) {
				$node[ $row_index ] = $this->apply_repeater_path_values_to_input_tree(
					$row,
					$fields_by_id,
					array_merge( $prefix, array( (int) $row_index ) ),
					$path_values
				);
			}

			return $node;
		}

		foreach ( $node as $field_id => $value ) {
			$field_id = (int) $field_id;
			if ( empty( $fields_by_id[ $field_id ] ) ) {
				continue;
			}

			$field = $fields_by_id[ $field_id ];
			if ( 'repeater' === $field['type'] && is_array( $value ) ) {
				$node[ $field_id ] = $this->apply_repeater_path_values_to_input_tree(
					$value,
					$fields_by_id,
					array_merge( $prefix, array( $field_id ) ),
					$path_values
				);
				continue;
			}

			$path = implode( ':', array_merge( $prefix, array( $field_id ) ) );
			if ( ! array_key_exists( $path, $path_values ) ) {
				continue;
			}

			$next = $path_values[ $path ];
			if ( is_array( $value ) && array_key_exists( 'value', $value ) ) {
				$value['value'] = $next;
				$node[ $field_id ] = $value;
			} else {
				$node[ $field_id ] = $next;
			}
		}

		return $node;
	}

	/**
	 * Normalize the stored WPML override list for one field.
	 *
	 * Older in-request data may still be a plain value list, so accept both
	 * formats while the new parser preserves the original occurrence number.
	 *
	 * @param int    $object_id Post ID.
	 * @param string $meta_key  CFG meta key.
	 * @return array<int,array{value:mixed,ordinal:int|null,field_type:string,sequence:int}>
	 */
	private function get_wpml_override_entries( $object_id, $meta_key ) {
		$raw_entries = isset( $this->wpml_translation_field_overrides[ $object_id ][ $meta_key ] )
			? (array) $this->wpml_translation_field_overrides[ $object_id ][ $meta_key ]
			: array();
		$entries = array();

		foreach ( $raw_entries as $sequence => $entry ) {
			if ( is_array( $entry ) && array_key_exists( 'value', $entry ) && array_key_exists( 'ordinal', $entry ) ) {
				$entries[] = array(
					'value'     => $entry['value'],
					'ordinal'   => null === $entry['ordinal'] ? null : (int) $entry['ordinal'],
					'field_type' => isset( $entry['field_type'] ) ? (string) $entry['field_type'] : '',
					'sequence'  => (int) $sequence,
				);
			} else {
				$entries[] = array(
					'value'     => $entry,
					'ordinal'   => (int) $sequence,
					'field_type' => '',
					'sequence'  => (int) $sequence,
				);
			}
		}

		usort(
			$entries,
			static function( $left, $right ) {
				$left_ordinal  = null === $left['ordinal'] ? PHP_INT_MAX : (int) $left['ordinal'];
				$right_ordinal = null === $right['ordinal'] ? PHP_INT_MAX : (int) $right['ordinal'];

				if ( $left_ordinal === $right_ordinal ) {
					return (int) $left['sequence'] <=> (int) $right['sequence'];
				}

				return $left_ordinal <=> $right_ordinal;
			}
		);

		return $entries;
	}

	/**
	 * Build CFG input-format data from current postmeta values.
	 *
	 * @param int   $post_id    Post ID.
	 * @param array $field_defs Field definitions from find_input_fields().
	 * @return array<int,mixed>
	 */
	private function build_input_field_data_from_postmeta( $post_id, $field_defs ) {
		$fields_by_id = array();
		foreach ( $field_defs as $field ) {
			$fields_by_id[ (int) $field['id'] ] = $field;
		}

		$source_post_id = 0;
		$post           = get_post( $post_id );
		if ( $post && ! empty( $post->post_type ) ) {
			$source_post_id = $this->get_source_post_id_for_translation( (int) $post_id, $post->post_type );
			if ( (int) $source_post_id === (int) $post_id ) {
				$source_post_id = 0;
			}
		}

		$existing_input = CFG()->get( false, $post_id, array( 'format' => 'input' ) );
		if ( ! is_array( $existing_input ) ) {
			$existing_input = array();
		}

		$source_input = array();
		if ( $source_post_id > 0 ) {
			$source_input = CFG()->get( false, $source_post_id, array( 'format' => 'input' ) );
			if ( ! is_array( $source_input ) ) {
				$source_input = array();
			}
		}

		$field_data = array();

		foreach ( $field_defs as $field ) {
			if ( (int) $field['parent_id'] !== 0 ) {
				continue;
			}

			$field_id = (int) $field['id'];

			if ( 'repeater' === $field['type'] ) {
				$repeater_rows = array();
				if ( isset( $existing_input[ $field_id ] ) && is_array( $existing_input[ $field_id ] ) ) {
					$repeater_rows = $existing_input[ $field_id ];
				} elseif ( isset( $source_input[ $field_id ] ) && is_array( $source_input[ $field_id ] ) ) {
					// Target index lost the repeater entirely — seed from source structure.
					$repeater_rows = $source_input[ $field_id ];
				}

				if ( ! empty( $repeater_rows ) ) {
					if ( isset( $source_input[ $field_id ] ) && is_array( $source_input[ $field_id ] ) ) {
						$repeater_rows = $this->graft_missing_repeater_structure_from_source(
							$repeater_rows,
							$source_input[ $field_id ],
							$fields_by_id,
							$field_id,
							true
						);
					}

					$repeater_rows = $this->hydrate_repeater_from_object_meta(
						$repeater_rows,
						$fields_by_id,
						'post',
						(int) $post_id,
						(int) $source_post_id,
						$field_id,
						isset( $source_input[ $field_id ] ) && is_array( $source_input[ $field_id ] ) ? $source_input[ $field_id ] : array()
					);

					if ( $source_post_id > 0 && isset( $source_input[ $field_id ] ) && is_array( $source_input[ $field_id ] ) ) {
						$repeater_rows = $this->maybe_trim_untranslated_source_growth(
							$repeater_rows,
							$source_input[ $field_id ],
							$fields_by_id,
							$field_id,
							(int) $post_id
						);
					}

					$field_data[ $field_id ] = $repeater_rows;
				}
				continue;
			}

			if ( metadata_exists( 'post', $post_id, $field['name'] ) ) {
				$field_data[ $field_id ] = $this->read_meta_value_for_field( $post_id, $field, 'post', $source_post_id );
				continue;
			}

			if ( isset( $existing_input[ $field_id ] ) ) {
				$field_data[ $field_id ] = $existing_input[ $field_id ];
			}
		}

		return $field_data;
	}

	/**
	 * Build CFG input-format data from current termmeta values.
	 *
	 * @param int   $term_id    Term ID.
	 * @param array $field_defs Field definitions from find_input_fields().
	 * @return array<int,mixed>
	 */
	private function build_input_field_data_from_termmeta( $term_id, $field_defs ) {
		$term = get_term( $term_id );
		if ( ! $term || is_wp_error( $term ) ) {
			return array();
		}

		$fields_by_id = array();
		foreach ( $field_defs as $field ) {
			$fields_by_id[ (int) $field['id'] ] = $field;
		}

		$object_id      = $term->taxonomy . '_' . $term_id;
		$existing_input = CFG()->get( false, $object_id, array( 'format' => 'input' ) );
		if ( ! is_array( $existing_input ) ) {
			$existing_input = array();
		}

		$source_term_id = $this->get_source_term_id_for_translation( (int) $term_id, $term->taxonomy );
		$source_input   = array();
		if ( $source_term_id > 0 ) {
			$source_input = CFG()->get(
				false,
				$term->taxonomy . '_' . $source_term_id,
				array( 'format' => 'input' )
			);
			if ( ! is_array( $source_input ) ) {
				$source_input = array();
			}
		}

		$field_data = array();

		foreach ( $field_defs as $field ) {
			if ( (int) $field['parent_id'] !== 0 ) {
				continue;
			}

			$field_id = (int) $field['id'];

			if ( 'repeater' === $field['type'] ) {
				$repeater_rows = array();
				if ( isset( $existing_input[ $field_id ] ) && is_array( $existing_input[ $field_id ] ) ) {
					$repeater_rows = $existing_input[ $field_id ];
				} elseif ( isset( $source_input[ $field_id ] ) && is_array( $source_input[ $field_id ] ) ) {
					$repeater_rows = $source_input[ $field_id ];
				}

				if ( ! empty( $repeater_rows ) ) {
					if ( isset( $source_input[ $field_id ] ) && is_array( $source_input[ $field_id ] ) ) {
						$repeater_rows = $this->graft_missing_repeater_structure_from_source(
							$repeater_rows,
							$source_input[ $field_id ],
							$fields_by_id,
							$field_id,
							true
						);
					}

					$field_data[ $field_id ] = $this->hydrate_repeater_from_object_meta(
						$repeater_rows,
						$fields_by_id,
						'term',
						(int) $term_id,
						(int) $source_term_id,
						$field_id,
						isset( $source_input[ $field_id ] ) && is_array( $source_input[ $field_id ] ) ? $source_input[ $field_id ] : array()
					);
				}
				continue;
			}

			if ( metadata_exists( 'term', $term_id, $field['name'] ) ) {
				$field_data[ $field_id ] = $this->read_meta_value_for_field( $term_id, $field, 'term' );
				continue;
			}

			if ( isset( $existing_input[ $field_id ] ) ) {
				$field_data[ $field_id ] = $existing_input[ $field_id ];
			}
		}

		return $field_data;
	}

	/**
	 * Graft missing repeater field keys from the source-language input tree.
	 *
	 * Prevents sparse translated trees (copy fields only) from being saved without
	 * translate-preference leaves such as room_name / nested feature_label.
	 * When $drop_surplus is true, unmapped target-only rows are discarded so
	 * source deletions (e.g. removing a room) prune the translation.
	 *
	 * @param array $target_rows   Target repeater rows.
	 * @param array $source_rows   Source-language repeater rows.
	 * @param array $fields_by_id  Field definitions keyed by ID.
	 * @param int   $repeater_id   Current repeater field ID.
	 * @param bool  $drop_surplus  Whether to drop target rows with no source match.
	 * @return array
	 */
	private function graft_missing_repeater_structure_from_source( $target_rows, $source_rows, $fields_by_id, $repeater_id = 0, $drop_surplus = false ) {
		if ( ! is_array( $target_rows ) ) {
			$target_rows = array();
		}
		if ( ! is_array( $source_rows ) ) {
			return $target_rows;
		}

		if ( empty( $source_rows ) ) {
			return $drop_surplus ? array() : $target_rows;
		}

		$repeater_id = (int) $repeater_id;
		$had_duplicate_anchors = $this->repeater_copy_anchors_are_non_unique(
			$source_rows,
			$target_rows,
			$repeater_id,
			$fields_by_id
		);
		$row_map = $this->align_repeater_row_keys( $source_rows, $target_rows, $repeater_id, $fields_by_id );

		// Duplicate copy-field values make surplus deletion unsafe, but the
		// source-shaped tree must still be emitted so missing translate keys
		// and newly appended source rows are restored.
		$prune_unsafe = $drop_surplus && $had_duplicate_anchors;

		$used_target = array();
		$out         = array();

		foreach ( $source_rows as $source_key => $source_row ) {
			$source_row = is_array( $source_row ) ? $source_row : array();
			$target_key = isset( $row_map[ $source_key ] ) ? $row_map[ $source_key ] : null;
			$target_row = ( null !== $target_key && isset( $target_rows[ $target_key ] ) && is_array( $target_rows[ $target_key ] ) )
				? $target_rows[ $target_key ]
				: array();

			if ( null !== $target_key ) {
				$used_target[ $target_key ] = true;
			}

			foreach ( $source_row as $field_id => $source_value ) {
				$field_id = (int) $field_id;
				if ( empty( $fields_by_id[ $field_id ] ) ) {
					continue;
				}

				$field = $fields_by_id[ $field_id ];

				if ( array_key_exists( $field_id, $target_row ) ) {
					if ( 'repeater' === $field['type'] && is_array( $source_value ) && is_array( $target_row[ $field_id ] ) ) {
						$target_row[ $field_id ] = $this->graft_missing_repeater_structure_from_source(
							$target_row[ $field_id ],
							$source_value,
							$fields_by_id,
							$field_id,
							$drop_surplus
						);
					}
					continue;
				}

				// Missing key on target — graft source structure/value so save cannot drop it.
				if ( 'repeater' === $field['type'] && is_array( $source_value ) ) {
					$target_row[ $field_id ] = $source_value;
				} else {
					$target_row[ $field_id ] = $source_value;
				}
			}

			$out[] = $target_row;
		}

		$has_unmapped_source = false;
		foreach ( array_keys( $source_rows ) as $source_key ) {
			if ( ! isset( $row_map[ $source_key ] ) ) {
				$has_unmapped_source = true;
				break;
			}
		}

		if ( ! $drop_surplus ) {
			foreach ( $target_rows as $target_key => $target_row ) {
				if ( isset( $used_target[ $target_key ] ) ) {
					continue;
				}

				$out[] = is_array( $target_row ) ? $target_row : array();
			}
		} elseif ( $prune_unsafe && ! $has_unmapped_source ) {
			// Pure shrink with duplicate copy-field hashes: keep named extras
			// rather than guessing which translated room to delete. Never keep
			// copy-only remnants (blank frontend cards).
			foreach ( $target_rows as $target_key => $target_row ) {
				if ( isset( $used_target[ $target_key ] ) ) {
					continue;
				}

				$target_row = is_array( $target_row ) ? $target_row : array();
				if ( ! $this->repeater_row_has_translate_leaves( $target_row, $fields_by_id, $repeater_id ) ) {
					continue;
				}

				$out[] = $target_row;
			}
		}

		return $out;
	}

	/**
	 * Ensure field data about to be saved still has source translate-preference leaves.
	 *
	 * @param array  $field_data     Target field data (input format).
	 * @param int    $source_post_id Source-language post ID.
	 * @param array  $fields_by_id   Field definitions keyed by ID.
	 * @param string $object_type    post or term.
	 * @param int    $object_id      Target object ID.
	 * @return array
	 */
	private function ensure_field_data_has_source_translate_leaves( $field_data, $source_post_id, $fields_by_id, $object_type, $object_id ) {
		$source_input = CFG()->get( false, (int) $source_post_id, array( 'format' => 'input' ) );
		if ( ! is_array( $source_input ) || empty( $source_input ) ) {
			return $field_data;
		}

		foreach ( $source_input as $field_id => $source_value ) {
			$field_id = (int) $field_id;
			if ( empty( $fields_by_id[ $field_id ] ) || 'repeater' !== $fields_by_id[ $field_id ]['type'] || ! is_array( $source_value ) ) {
				continue;
			}

			$target_rows = ( isset( $field_data[ $field_id ] ) && is_array( $field_data[ $field_id ] ) )
				? $field_data[ $field_id ]
				: array();

			$grafted = $this->graft_missing_repeater_structure_from_source(
				$target_rows,
				$source_value,
				$fields_by_id,
				$field_id,
				true
			);

			// Re-hydrate after graft so ATE overrides / postmeta replace EN seeds.
			$hydrated = $this->hydrate_repeater_from_object_meta(
				$grafted,
				$fields_by_id,
				$object_type,
				(int) $object_id,
				(int) $source_post_id,
				$field_id,
				$source_value
			);

			if ( 'post' === $object_type ) {
				$hydrated = $this->maybe_trim_untranslated_source_growth(
					$hydrated,
					$source_value,
					$fields_by_id,
					$field_id,
					(int) $object_id
				);
			}

			$field_data[ $field_id ] = $hydrated;
		}

		return $field_data;
	}

	/**
	 * Completed-job translate occurrence counts keyed by field ID.
	 *
	 * Returns null when no completed TM job exists so first-time copies are not trimmed.
	 *
	 * @param int   $post_id      Translated post ID.
	 * @param array $fields_by_id Field definitions keyed by ID.
	 * @return array<int,int>|null
	 */
	private function get_completed_tm_job_translate_coverage( $post_id, $fields_by_id ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return null;
		}

		if ( array_key_exists( $post_id, $this->completed_job_translate_coverage_cache ) ) {
			return $this->completed_job_translate_coverage_cache[ $post_id ];
		}

		$job_id = $this->get_latest_completed_tm_job_id_for_post( $post_id );
		if ( $job_id <= 0 ) {
			$this->completed_job_translate_coverage_cache[ $post_id ] = null;
			return null;
		}

		$job_counts = $this->get_wpml_tm_job_field_occurrence_counts( $job_id );
		$coverage   = array();

		foreach ( $fields_by_id as $field_id => $field ) {
			$field_id = (int) $field_id;
			if ( empty( $field['name'] ) || ! $this->is_wpml_translate_preference_field( $field ) ) {
				continue;
			}

			$meta_key = (string) $field['name'];
			$coverage[ $field_id ] = isset( $job_counts[ $meta_key ] ) ? (int) $job_counts[ $meta_key ] : 0;
		}

		$this->completed_job_translate_coverage_cache[ $post_id ] = $coverage;

		return $coverage;
	}

	/**
	 * Drop source-growth repeater rows that a completed TM job does not cover.
	 *
	 * @param array $hydrated_rows Hydrated target rows (source walk order).
	 * @param array $source_rows   Source-language rows.
	 * @param array $fields_by_id  Field definitions keyed by ID.
	 * @param int   $repeater_id   Current repeater field ID.
	 * @param int   $post_id       Translated post ID.
	 * @return array
	 */
	private function maybe_trim_untranslated_source_growth( $hydrated_rows, $source_rows, $fields_by_id, $repeater_id, $post_id ) {
		$coverage = $this->get_completed_tm_job_translate_coverage( (int) $post_id, $fields_by_id );
		if ( null === $coverage ) {
			return $hydrated_rows;
		}

		$cursors = array();

		return $this->trim_untranslated_source_growth_rows(
			$hydrated_rows,
			$source_rows,
			$fields_by_id,
			$repeater_id,
			$coverage,
			$cursors
		);
	}

	/**
	 * Trim source-walk rows whose translate ordinals exceed completed-job coverage.
	 *
	 * Unmapped English clones and already-mapped English copies of uncovered
	 * growth are dropped. Mapped rows with real translations are kept; nested
	 * uncovered growth inside those rows is trimmed recursively.
	 *
	 * A row is uncovered only when every translate field that the completed job
	 * actually contains (coverage > 0) is past its limit. Coverage-0 siblings
	 * are ignored so mixed job counts (12 labels / 11 values) keep the row.
	 *
	 * @param array      $hydrated_rows Hydrated target rows.
	 * @param array      $source_rows   Source-language rows.
	 * @param array      $fields_by_id  Field definitions keyed by ID.
	 * @param int        $repeater_id   Current repeater field ID.
	 * @param array      $coverage      Translate occurrence limits keyed by field ID.
	 * @param array      $cursors       Walk cursors keyed by field ID, passed by reference.
	 * @return array
	 */
	private function trim_untranslated_source_growth_rows( $hydrated_rows, $source_rows, $fields_by_id, $repeater_id, $coverage, &$cursors ) {
		if ( ! is_array( $source_rows ) || empty( $source_rows ) ) {
			return is_array( $hydrated_rows ) ? $hydrated_rows : array();
		}

		if ( ! is_array( $cursors ) ) {
			$cursors = array();
		}

		$hydrated_list = array_values( is_array( $hydrated_rows ) ? $hydrated_rows : array() );
		$out           = array();
		$index         = 0;

		foreach ( $source_rows as $source_row ) {
			$source_row   = is_array( $source_row ) ? $source_row : array();
			$hydrated_row = ( isset( $hydrated_list[ $index ] ) && is_array( $hydrated_list[ $index ] ) )
				? $hydrated_list[ $index ]
				: array();
			++$index;

			$row_counts = array();
			$this->count_input_tree_field_occurrences( $source_row, $fields_by_id, $row_counts );

			$any_in_job_field = false;
			$any_covered      = false;
			foreach ( $row_counts as $field_id => $count ) {
				$field_id = (int) $field_id;
				if ( empty( $fields_by_id[ $field_id ] ) || ! $this->is_wpml_translate_preference_field( $fields_by_id[ $field_id ] ) ) {
					continue;
				}

				$start = isset( $cursors[ $field_id ] ) ? (int) $cursors[ $field_id ] : 0;
				$limit = isset( $coverage[ $field_id ] ) ? (int) $coverage[ $field_id ] : 0;
				if ( $limit <= 0 ) {
					continue;
				}

				$any_in_job_field = true;
				if ( $start + (int) $count <= $limit ) {
					$any_covered = true;
					break;
				}
			}

			$uncovered = $any_in_job_field && ! $any_covered;

			$matches_source = $this->repeater_row_translate_leaves_match_source(
				$hydrated_row,
				$source_row,
				$fields_by_id,
				$repeater_id
			);

			if ( $uncovered && $matches_source ) {
				$this->advance_translate_occurrence_cursors( $cursors, $row_counts, $fields_by_id );
				continue;
			}

			foreach ( $source_row as $field_id => $source_value ) {
				$field_id = (int) $field_id;
				if ( empty( $fields_by_id[ $field_id ] ) || 'repeater' !== $fields_by_id[ $field_id ]['type'] || ! is_array( $source_value ) ) {
					continue;
				}

				$nested_hydrated = ( isset( $hydrated_row[ $field_id ] ) && is_array( $hydrated_row[ $field_id ] ) )
					? $hydrated_row[ $field_id ]
					: array();

				$hydrated_row[ $field_id ] = $this->trim_untranslated_source_growth_rows(
					$nested_hydrated,
					$source_value,
					$fields_by_id,
					$field_id,
					$coverage,
					$cursors
				);
			}

			$this->advance_direct_translate_occurrence_cursors( $cursors, $source_row, $fields_by_id, $repeater_id );
			$out[] = $hydrated_row;
		}

		return $out;
	}

	/**
	 * Whether every translate-preference leaf on the target row still equals source.
	 *
	 * @param array $target_row   Hydrated target row.
	 * @param array $source_row   Source-language row.
	 * @param array $fields_by_id Field definitions keyed by ID.
	 * @param int   $repeater_id  Current repeater field ID.
	 * @return bool
	 */
	private function repeater_row_translate_leaves_match_source( $target_row, $source_row, $fields_by_id, $repeater_id ) {
		if ( ! is_array( $source_row ) ) {
			return true;
		}

		$target_row = is_array( $target_row ) ? $target_row : array();

		foreach ( $source_row as $field_id => $source_value ) {
			$field_id = (int) $field_id;
			if ( empty( $fields_by_id[ $field_id ] ) ) {
				continue;
			}

			$field = $fields_by_id[ $field_id ];
			if ( (int) $field['parent_id'] !== (int) $repeater_id ) {
				continue;
			}

			if ( 'repeater' === $field['type'] && is_array( $source_value ) ) {
				$target_nested = ( isset( $target_row[ $field_id ] ) && is_array( $target_row[ $field_id ] ) )
					? array_values( $target_row[ $field_id ] )
					: array();
				$source_nested = array_values( $source_value );

				foreach ( $source_nested as $nested_index => $source_child ) {
					$target_child = isset( $target_nested[ $nested_index ] ) ? $target_nested[ $nested_index ] : array();
					if ( ! $this->repeater_row_translate_leaves_match_source( $target_child, $source_child, $fields_by_id, $field_id ) ) {
						return false;
					}
				}
				continue;
			}

			if ( ! $this->is_wpml_translate_preference_field( $field ) ) {
				continue;
			}

			$target_value = array_key_exists( $field_id, $target_row ) ? $target_row[ $field_id ] : $source_value;
			if ( $this->input_leaf_values_differ( $target_value, $source_value ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Advance translate-field walk cursors by a row's full occurrence counts.
	 *
	 * @param array $cursors      Walk cursors keyed by field ID.
	 * @param array $row_counts   Occurrence counts keyed by field ID.
	 * @param array $fields_by_id Field definitions keyed by ID.
	 * @return void
	 */
	private function advance_translate_occurrence_cursors( &$cursors, $row_counts, $fields_by_id ) {
		foreach ( $row_counts as $field_id => $count ) {
			$field_id = (int) $field_id;
			if ( empty( $fields_by_id[ $field_id ] ) || ! $this->is_wpml_translate_preference_field( $fields_by_id[ $field_id ] ) ) {
				continue;
			}

			if ( ! isset( $cursors[ $field_id ] ) ) {
				$cursors[ $field_id ] = 0;
			}
			$cursors[ $field_id ] += (int) $count;
		}
	}

	/**
	 * Advance walk cursors for direct (non-nested) translate children of a row.
	 *
	 * Nested repeater cursors are advanced by the recursive trim.
	 *
	 * @param array $cursors      Walk cursors keyed by field ID.
	 * @param array $source_row   Source-language row.
	 * @param array $fields_by_id Field definitions keyed by ID.
	 * @param int   $repeater_id  Current repeater field ID.
	 * @return void
	 */
	private function advance_direct_translate_occurrence_cursors( &$cursors, $source_row, $fields_by_id, $repeater_id ) {
		if ( ! is_array( $source_row ) ) {
			return;
		}

		foreach ( $source_row as $field_id => $value ) {
			$field_id = (int) $field_id;
			if ( empty( $fields_by_id[ $field_id ] ) ) {
				continue;
			}

			$field = $fields_by_id[ $field_id ];
			if ( (int) $field['parent_id'] !== (int) $repeater_id || 'repeater' === $field['type'] ) {
				continue;
			}

			if ( ! $this->is_wpml_translate_preference_field( $field ) ) {
				continue;
			}

			if ( ! isset( $cursors[ $field_id ] ) ) {
				$cursors[ $field_id ] = 0;
			}
			++$cursors[ $field_id ];
		}
	}

	/**
	 * Ensure a rebuild still contains every required translate leaf occurrence.
	 *
	 * When a completed job lags source growth, the target may omit those extra
	 * ordinals. The rebuild must still keep every leaf the completed job (or
	 * the source, when no job exists) already covers.
	 *
	 * @param array      $field_data          Target input-format field data.
	 * @param int        $source_post_id      Source-language post ID.
	 * @param array      $fields_by_id        Field definitions keyed by ID.
	 * @param int        $translated_post_id  Translated post ID.
	 * @param array|null $source_input        Optional source input tree.
	 * @param array|null $coverage            Optional completed-job coverage.
	 * @return bool
	 */
	private function validate_repeater_input_structure( $field_data, $source_post_id, $fields_by_id, $translated_post_id = 0, $source_input = null, $coverage = null ) {
		if ( ! is_array( $source_input ) ) {
			$source_input = CFG()->get( false, (int) $source_post_id, array( 'format' => 'input' ) );
		}
		if ( ! is_array( $source_input ) || empty( $source_input ) ) {
			return true;
		}

		if ( null === $coverage && (int) $translated_post_id > 0 ) {
			$coverage = $this->get_completed_tm_job_translate_coverage( (int) $translated_post_id, $fields_by_id );
		}

		foreach ( $source_input as $field_id => $source_rows ) {
			$field_id = (int) $field_id;
			if (
				empty( $fields_by_id[ $field_id ] )
				|| 'repeater' !== $fields_by_id[ $field_id ]['type']
				|| ! is_array( $source_rows )
			) {
				continue;
			}

			$target_rows = isset( $field_data[ $field_id ] ) && is_array( $field_data[ $field_id ] )
				? $field_data[ $field_id ]
				: array();
			$source_slots  = $this->get_repeater_leaf_slots( $source_rows, $fields_by_id, $field_id );
			$target_slots  = $this->get_repeater_leaf_slots( $target_rows, $fields_by_id, $field_id );
			$source_counts = array();
			$target_counts = array();

			foreach ( $source_slots as $slot ) {
				$leaf_field_id = (int) $slot['field_id'];
				if ( ! isset( $source_counts[ $leaf_field_id ] ) ) {
					$source_counts[ $leaf_field_id ] = 0;
				}
				++$source_counts[ $leaf_field_id ];
			}
			foreach ( $target_slots as $slot ) {
				$leaf_field_id = (int) $slot['field_id'];
				if ( ! isset( $target_counts[ $leaf_field_id ] ) ) {
					$target_counts[ $leaf_field_id ] = 0;
				}
				++$target_counts[ $leaf_field_id ];
			}

			foreach ( $source_counts as $leaf_field_id => $source_count ) {
				$target_count = isset( $target_counts[ $leaf_field_id ] ) ? (int) $target_counts[ $leaf_field_id ] : 0;
				$required     = (int) $source_count;
				if ( is_array( $coverage ) && isset( $coverage[ $leaf_field_id ] ) && (int) $coverage[ $leaf_field_id ] > 0 ) {
					$required = min( (int) $source_count, (int) $coverage[ $leaf_field_id ] );
				}

				if ( $target_count < $required ) {
					$this->mark_repeater_mapping_ambiguous(
						sprintf( 'Target repeater %d lost translate leaf %d before save.', $field_id, $leaf_field_id )
					);
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Load the latest completed ATE/TM job field values into overrides when needed.
	 *
	 * Used to recover wiped translate leaves from icl_translate.
	 *
	 * @param int $post_id Translated post ID.
	 * @return void
	 */
	private function maybe_load_ate_job_overrides_for_post( $post_id ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return;
		}

		if ( ! empty( $this->wpml_translation_field_overrides[ $post_id ] ) ) {
			return;
		}

		$job_id = $this->get_latest_completed_tm_job_id_for_post( $post_id );
		if ( $job_id <= 0 ) {
			return;
		}

		$map = $this->load_tm_job_fields_as_meta_map( $job_id );
		if ( ! empty( $map ) ) {
			$this->wpml_translation_field_overrides[ $post_id ] = $map;
		}
	}

	/**
	 * Get the latest completed WPML TM job ID for a translated post.
	 *
	 * @param int $post_id Translated post ID.
	 * @return int
	 */
	private function get_latest_completed_tm_job_id_for_post( $post_id ) {
		global $wpdb;

		$post = get_post( $post_id );
		if ( ! $post || empty( $post->post_type ) ) {
			return 0;
		}

		$element_type = 'post_' . $post->post_type;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$job_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT j.job_id
				FROM {$wpdb->prefix}icl_translate_job j
				INNER JOIN {$wpdb->prefix}icl_translation_status st ON st.rid = j.rid
				INNER JOIN {$wpdb->prefix}icl_translations t ON t.translation_id = st.translation_id
				WHERE t.element_id = %d
					AND t.element_type = %s
					AND j.translated = 1
				ORDER BY j.job_id DESC
				LIMIT 1",
				$post_id,
				$element_type
			)
		);

		return (int) $job_id;
	}

	/**
	 * Load icl_translate rows for a job into meta_key => values map.
	 *
	 * @param int $job_id WPML TM job ID.
	 * @return array<string,array<int,array{value:mixed,ordinal:int|null,field_type:string}>>
	 */
	private function load_tm_job_fields_as_meta_map( $job_id ) {
		global $wpdb;

		$job_id = (int) $job_id;
		if ( $job_id <= 0 ) {
			return array();
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT field_type, field_data_translated, field_format
				FROM {$wpdb->prefix}icl_translate
				WHERE job_id = %d
				ORDER BY tid ASC",
				$job_id
			),
			ARRAY_A
		);

		if ( empty( $rows ) ) {
			return array();
		}

		$fields = array();
		foreach ( $rows as $row ) {
			$fields[] = array(
				'field_type'            => $row['field_type'],
				'field_data_translated' => $row['field_data_translated'],
				'field_format'          => isset( $row['field_format'] ) ? $row['field_format'] : 'base64',
			);
		}

		return $this->parse_wpml_job_fields_to_meta_map( $fields );
	}

	/**
	 * Apply current object meta values onto a repeater input tree.
	 *
	 * @param array $repeater_rows    Existing repeater rows keyed by field ID.
	 * @param array $fields_by_id     Field definitions keyed by ID.
	 * @param string $object_type     post or term.
	 * @param int    $object_id       Post or term ID.
	 * @param int    $source_object_id Source-language object ID when translating.
	 * @param int    $root_field_id   Root repeater field ID.
	 * @param array $source_rows     Source-language repeater rows.
	 * @return array
	 */
	private function hydrate_repeater_from_object_meta( $repeater_rows, $fields_by_id, $object_type, $object_id, $source_object_id = 0, $root_field_id = 0, $source_rows = array() ) {
		if ( ! is_array( $repeater_rows ) || empty( $repeater_rows ) ) {
			return $repeater_rows;
		}

		$root_field_id = (int) $root_field_id;
		if ( $root_field_id <= 0 ) {
			return $repeater_rows;
		}

		$target_slots = $this->get_repeater_leaf_slots( $repeater_rows, $fields_by_id, $root_field_id );
		if ( empty( $target_slots ) ) {
			return $repeater_rows;
		}

		$source_slots = is_array( $source_rows ) && ! empty( $source_rows )
			? $this->get_repeater_leaf_slots( $source_rows, $fields_by_id, $root_field_id )
			: array();
		$target_by_field = $this->group_repeater_slots_by_field( $target_slots );
		$source_by_field = $this->group_repeater_slots_by_field( $source_slots );
		$path_map        = array();
		$path_values     = array();
		$override_paths  = array();
		$source_values_by_target_path = array();

		if ( ! empty( $source_rows ) ) {
			$this->build_repeater_path_alignment(
				$source_rows,
				$repeater_rows,
				$root_field_id,
				$fields_by_id,
				array( $root_field_id ),
				array( $root_field_id ),
				$path_map
			);
		}

		$snapshot         = $this->get_cfg_hierarchy_snapshot( $object_type, $object_id );
		$indexed_meta_ids = $this->get_indexed_meta_id_lookup( $object_type, $object_id );

		// ATE values are authoritative for translated leaves. Map their
		// occurrence number to a source slot, then through the source/target
		// path alignment, instead of assigning them to a global field queue.
		$override_field_ids = array_unique(
			array_merge(
				array_keys( $target_by_field ),
				array_keys( $source_by_field )
			)
		);

		foreach ( $override_field_ids as $field_id ) {
			$field_id = (int) $field_id;
			if ( empty( $fields_by_id[ $field_id ] ) ) {
				continue;
			}

			$meta_key     = (string) $fields_by_id[ $field_id ]['name'];
			$field_slots  = isset( $target_by_field[ $field_id ] ) ? $target_by_field[ $field_id ] : array();
			$entries      = ( 'post' === $object_type )
				? $this->get_wpml_override_entries( (int) $object_id, $meta_key )
				: array();
			$source_ordinal_slots = $this->get_wpml_job_occurrence_slots(
				isset( $source_by_field[ $field_id ] ) ? $source_by_field[ $field_id ] : array(),
				$entries
			);
			$target_ordinal_slots = $this->get_wpml_job_occurrence_slots( $field_slots, $entries );

			foreach ( $entries as $sequence => $entry ) {
				$ordinal     = null !== $entry['ordinal'] ? (int) $entry['ordinal'] : (int) $sequence;
				$target_path = '';

				if ( isset( $source_ordinal_slots[ $ordinal ] ) ) {
					$source_path = $source_ordinal_slots[ $ordinal ]['path'];
					$target_path = isset( $path_map[ $source_path ] ) ? $path_map[ $source_path ] : $source_path;
				} elseif ( isset( $target_ordinal_slots[ $ordinal ] ) ) {
					$target_path = $target_ordinal_slots[ $ordinal ]['path'];
				} else {
					// Extra ATE occurrences relative to a still-short target are
					// expected during source growth; do not abort the rebuild.
					continue;
				}

				if ( ! $this->repeater_path_exists( $target_slots, $target_path ) ) {
					continue;
				}

				$path_values[ $target_path ]    = $entry['value'];
				$override_paths[ $target_path ] = true;
			}
		}

		foreach ( $source_slots as $source_slot ) {
			$source_path = $source_slot['path'];
			if ( ! isset( $path_map[ $source_path ] ) ) {
				continue;
			}

			$target_path = $path_map[ $source_path ];
			$normalized  = $this->normalize_input_leaf_value( $source_slot['value'] );
			$source_values_by_target_path[ $target_path ] = $normalized;

			// WPML writes omitted-empty job ordinal 0 onto the first CFG slot.
			// Pin those empty source leaves so index/target meta cannot keep 7 km.
			if ( $this->is_empty_input_leaf_value( $source_slot['value'] ) && empty( $override_paths[ $target_path ] ) ) {
				$path_values[ $target_path ] = $normalized;
			}
		}

		// Existing indexed rows are the next safest source. The complete path
		// protects equal leaf field IDs from crossing parent repeater rows.
		foreach ( $target_slots as $slot ) {
			$path = $slot['path'];
			if ( array_key_exists( $path, $path_values ) || empty( $snapshot['by_path'][ $path ] ) ) {
				continue;
			}

			foreach ( $snapshot['by_path'][ $path ] as $indexed_row ) {
				if (
					(int) $indexed_row['field_id'] === (int) $slot['field_id']
					&& (string) $indexed_row['meta_key'] === (string) $slot['field_name']
					&& (int) $indexed_row['meta_id'] > 0
				) {
					$path_values[ $path ] = $indexed_row['meta_value'];
					break;
				}
			}
		}

		// Last-resort flat meta hydration is only allowed when row counts are
		// exact or form complete duplicate batches. It is never allowed to
		// silently drop a partial batch into a different parent path.
		foreach ( $target_by_field as $field_id => $field_slots ) {
			$field_id = (int) $field_id;
			$field    = $fields_by_id[ $field_id ];
			$meta_key = (string) $field['name'];
			$rows     = $this->get_object_meta_rows( $object_type, $object_id, $meta_key );
			$expected = count( $field_slots );

			if ( empty( $rows ) || $expected <= 0 ) {
				continue;
			}

			if ( count( $rows ) > $expected && 0 !== count( $rows ) % $expected ) {
				$source_expected = isset( $source_by_field[ $field_id ] ) ? count( $source_by_field[ $field_id ] ) : 0;

				// Stale shorter target trees (9 slots vs 12 ATE/source rows) are
				// repaired by graft + ATE ordinals. Do not abort the rebuild.
				if ( $source_expected > 0 ) {
					continue;
				}

				$this->mark_repeater_mapping_ambiguous(
					sprintf( 'Meta row count for %s cannot be partitioned into repeater slots.', $meta_key )
				);
				continue;
			}

			$source_values = array();
			if ( isset( $source_by_field[ $field_id ] ) ) {
				foreach ( $source_by_field[ $field_id ] as $source_slot ) {
					$source_values[] = $this->normalize_input_leaf_value( $source_slot['value'] );
				}
			}

			$selection = $this->select_canonical_meta_chunk(
				$rows,
				$expected,
				$source_values,
				$indexed_meta_ids,
				true
			);

			foreach ( $field_slots as $ordinal => $slot ) {
				if ( ! array_key_exists( $ordinal, $selection['values'] ) ) {
					continue;
				}

				$path = $slot['path'];
				$value = $selection['values'][ $ordinal ];

				if ( isset( $override_paths[ $path ] ) ) {
					continue;
				}

				// If the current index still points at the source-language
				// value while the flat candidate batch is translated, prefer
				// the candidate. This repairs the original stale-index state
				// without overriding a valid translated hierarchy row.
				// Empty source leaves are not stale English: WPML omitted them
				// and FIFO-wrote the next value (7 km) onto Casa Karla.
				if (
					array_key_exists( $path, $path_values )
					&& isset( $source_values_by_target_path[ $path ] )
					&& ! $this->is_empty_input_leaf_value( $source_values_by_target_path[ $path ] )
					&& $this->input_leaf_values_differ( $value, $source_values_by_target_path[ $path ] )
					&& ! $this->input_leaf_values_differ( $path_values[ $path ], $source_values_by_target_path[ $path ] )
				) {
					$path_values[ $path ] = $value;
					continue;
				}

				if ( ! array_key_exists( $path, $path_values ) ) {
					$path_values[ $path ] = $value;
				}
			}
		}

		return $this->apply_repeater_path_values_to_input_tree(
			$repeater_rows,
			$fields_by_id,
			array( $root_field_id ),
			$path_values
		);
	}

	/**
	 * Delete CFG meta rows that are no longer referenced by the index.
	 *
	 * @param string $object_type post or term.
	 * @param int    $object_id   Object ID.
	 * @param array  $field_defs  Field definitions.
	 * @return void
	 */
	private function cleanup_unindexed_cfg_object_meta( $object_type, $object_id, $field_defs ) {
		$object_id = (int) $object_id;
		if ( $object_id <= 0 || empty( $field_defs ) ) {
			return;
		}

		$indexed = $this->get_indexed_meta_id_lookup( $object_type, $object_id );
		$meta_type = ( 'term' === $object_type ) ? 'term' : 'post';

		foreach ( $field_defs as $field ) {
			if ( empty( $field['name'] ) || $this->is_layout_field_type( $field['type'] ) || 'repeater' === $field['type'] ) {
				continue;
			}

			$rows = $this->get_object_meta_rows( $object_type, $object_id, $field['name'] );
			foreach ( $rows as $row ) {
				$meta_id = (int) $row['meta_id'];
				if ( isset( $indexed[ $meta_id ] ) ) {
					continue;
				}
				delete_metadata_by_mid( $meta_type, $meta_id );
			}
		}
	}

	/**
	 * Whether a node is a list of repeater rows (including sparse numeric keys).
	 *
	 * @param mixed $node Input node.
	 * @return bool
	 */
	private function is_input_rows_list( $node ) {
		if ( ! is_array( $node ) || empty( $node ) ) {
			return false;
		}

		foreach ( $node as $key => $value ) {
			if ( ! is_numeric( $key ) || ! is_array( $value ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Count leaf field occurrences inside an input-format tree.
	 *
	 * @param mixed $node            Input node.
	 * @param array $fields_by_id    Field definitions keyed by ID.
	 * @param array $counts          Counts keyed by field ID (by ref).
	 * @param bool  $only_non_empty  When true, skip empty leaf values.
	 * @return void
	 */
	private function count_input_tree_field_occurrences( $node, $fields_by_id, &$counts, $only_non_empty = false ) {
		if ( ! is_array( $node ) ) {
			return;
		}

		if ( $this->is_input_rows_list( $node ) ) {
			foreach ( $node as $child ) {
				$this->count_input_tree_field_occurrences( $child, $fields_by_id, $counts, $only_non_empty );
			}
			return;
		}

		foreach ( $node as $field_id => $value ) {
			$field_id = (int) $field_id;
			if ( empty( $fields_by_id[ $field_id ] ) ) {
				continue;
			}

			$field = $fields_by_id[ $field_id ];

			if ( 'repeater' === $field['type'] && is_array( $value ) ) {
				$this->count_input_tree_field_occurrences( $value, $fields_by_id, $counts, $only_non_empty );
				continue;
			}

			if ( $only_non_empty && $this->is_empty_input_leaf_value( $value ) ) {
				continue;
			}

			if ( ! isset( $counts[ $field_id ] ) ) {
				$counts[ $field_id ] = 0;
			}
			++$counts[ $field_id ];
		}
	}

	/**
	 * Choose one canonical chunk of meta rows when duplicates exist.
	 *
	 * @param array<int,array{meta_id:int|string,meta_value:mixed}> $rows              Meta rows ordered by meta_id ASC.
	 * @param int                                                   $expected          Expected value count.
	 * @param array                                                 $source_values     Source-language values.
	 * @param array<int|string,bool>                                $indexed_meta_ids  Indexed meta_id lookup.
	 * @param bool                                                  $prefer_translated Prefer the chunk that differs from source.
	 * @return array{values:array,meta_ids:array<int,int>}
	 */
	private function select_canonical_meta_chunk( $rows, $expected, $source_values, $indexed_meta_ids, $prefer_translated = true ) {
		$expected = (int) $expected;
		if ( $expected <= 0 || empty( $rows ) ) {
			return array(
				'values'   => array(),
				'meta_ids' => array(),
			);
		}

		$values   = array();
		$meta_ids = array();
		foreach ( $rows as $row ) {
			$values[]   = $row['meta_value'];
			$meta_ids[] = (int) $row['meta_id'];
		}

		if ( count( $values ) <= $expected ) {
			return array(
				'values'   => $values,
				'meta_ids' => $meta_ids,
			);
		}

		$value_chunks   = array_chunk( $values, $expected );
		$meta_id_chunks = array_chunk( $meta_ids, $expected );

		$best_index = 0;
		$best_score = null;

		foreach ( $value_chunks as $index => $chunk ) {
			if ( count( $chunk ) < $expected ) {
				continue;
			}

			$source_matches = 0;
			if ( ! empty( $source_values ) ) {
				foreach ( $chunk as $offset => $value ) {
					if ( ! array_key_exists( $offset, $source_values ) ) {
						continue;
					}
					if ( (string) $value === (string) $source_values[ $offset ] ) {
						++$source_matches;
					}
				}
			}

			$indexed_count = 0;
			foreach ( $meta_id_chunks[ $index ] as $meta_id ) {
				if ( isset( $indexed_meta_ids[ (int) $meta_id ] ) || isset( $indexed_meta_ids[ (string) $meta_id ] ) ) {
					++$indexed_count;
				}
			}

			$empty_count = 0;
			foreach ( $chunk as $value ) {
				if ( null === $value || '' === $value ) {
					++$empty_count;
				}
			}

			// Prefer translated chunks (fewer source matches). Prefer non-empty over empty
			// so blank ATE placeholders never beat real English/Dutch values. Prefer
			// unindexed when tied (ATE orphans). Prefer earlier chunk last.
			if ( $prefer_translated ) {
				$score = ( $empty_count * 100000 ) + ( $source_matches * 1000 ) + ( $indexed_count * 10 ) + $index;
			} else {
				$score = ( $empty_count * 100000 ) + ( ( $expected - $source_matches ) * 1000 ) + ( ( $expected - $indexed_count ) * 10 ) + $index;
			}

			if ( null === $best_score || $score < $best_score ) {
				$best_score = $score;
				$best_index = $index;
			}
		}

		$best_values = $value_chunks[ $best_index ];
		$best_ids    = $meta_id_chunks[ $best_index ];

		// Never keep an all-empty winner when another chunk has non-empty values.
		if ( $this->meta_chunk_is_entirely_empty( $best_values ) ) {
			foreach ( $value_chunks as $index => $chunk ) {
				if ( count( $chunk ) < $expected ) {
					continue;
				}
				if ( ! $this->meta_chunk_is_entirely_empty( $chunk ) ) {
					$best_index  = $index;
					$best_values = $chunk;
					$best_ids    = $meta_id_chunks[ $index ];
					break;
				}
			}
		}

		return array(
			'values'   => $best_values,
			'meta_ids' => $best_ids,
		);
	}

	/**
	 * Whether every value in a meta chunk is empty.
	 *
	 * @param array $chunk Meta values.
	 * @return bool
	 */
	private function meta_chunk_is_entirely_empty( $chunk ) {
		if ( empty( $chunk ) ) {
			return true;
		}

		foreach ( (array) $chunk as $value ) {
			if ( null !== $value && '' !== $value ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Delete meta rows that were not selected as the canonical chunk.
	 *
	 * @param string $object_type      post or term.
	 * @param array  $rows             All meta rows for the key.
	 * @param array  $keep_meta_ids    Meta IDs to keep.
	 * @return void
	 */
	private function delete_surplus_meta_rows( $object_type, $rows, $keep_meta_ids ) {
		$keep = array();
		foreach ( (array) $keep_meta_ids as $meta_id ) {
			$keep[ (int) $meta_id ] = true;
		}

		$meta_type = ( 'term' === $object_type ) ? 'term' : 'post';

		foreach ( (array) $rows as $row ) {
			$meta_id = (int) $row['meta_id'];
			if ( isset( $keep[ $meta_id ] ) ) {
				continue;
			}
			delete_metadata_by_mid( $meta_type, $meta_id );
		}
	}

	/**
	 * Load object meta rows for one key ordered by meta_id ASC.
	 *
	 * @param string $object_type post or term.
	 * @param int    $object_id   Object ID.
	 * @param string $meta_key    Meta key.
	 * @return array<int,array{meta_id:string,meta_value:mixed}>
	 */
	private function get_object_meta_rows( $object_type, $object_id, $meta_key ) {
		global $wpdb;

		$object_id = (int) $object_id;
		$meta_key  = (string) $meta_key;
		if ( $object_id <= 0 || '' === $meta_key ) {
			return array();
		}

		if ( 'term' === $object_type ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			return (array) $wpdb->get_results(
				$wpdb->prepare(
					"SELECT meta_id, meta_value FROM {$wpdb->termmeta} WHERE term_id = %d AND meta_key = %s ORDER BY meta_id ASC",
					$object_id,
					$meta_key
				),
				ARRAY_A
			);
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT meta_id, meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = %s ORDER BY meta_id ASC",
				$object_id,
				$meta_key
			),
			ARRAY_A
		);
	}

	/**
	 * Build a lookup of meta_ids currently referenced by the CFG index.
	 *
	 * @param string $object_type post or term.
	 * @param int    $object_id   Object ID.
	 * @return array<int,bool>
	 */
	private function get_indexed_meta_id_lookup( $object_type, $object_id ) {
		global $wpdb;

		$object_id = (int) $object_id;
		$lookup    = array();
		if ( $object_id <= 0 ) {
			return $lookup;
		}

		if ( 'term' === $object_type ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT meta_id FROM {$wpdb->prefix}asenha_cfgroup_values_for_terms WHERE term_id = %d",
					$object_id
				)
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT meta_id FROM {$wpdb->prefix}asenha_cfgroup_values WHERE post_id = %d",
					$object_id
				)
			);
		}

		foreach ( (array) $ids as $meta_id ) {
			$lookup[ (int) $meta_id ] = true;
		}

		return $lookup;
	}

	/**
	 * Whether an object has any CFG index rows.
	 *
	 * @param string $object_type post or term.
	 * @param int    $object_id   Object ID.
	 * @return bool
	 */
	private function object_has_cfg_index_rows( $object_type, $object_id ) {
		global $wpdb;

		$object_id = (int) $object_id;
		if ( $object_id <= 0 ) {
			return false;
		}

		$object_type = ( 'term' === $object_type ) ? 'term' : 'post';
		$cache_key   = 'has_index:' . $object_type . ':' . $object_id;
		if ( array_key_exists( $cache_key, $this->cfg_index_integrity_cache ) ) {
			return $this->cfg_index_integrity_cache[ $cache_key ];
		}

		if ( 'term' === $object_type ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$found = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT 1 FROM {$wpdb->prefix}asenha_cfgroup_values_for_terms WHERE term_id = %d LIMIT 1",
					$object_id
				)
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$found = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT 1 FROM {$wpdb->prefix}asenha_cfgroup_values WHERE post_id = %d LIMIT 1",
					$object_id
				)
			);
		}

		$result = null !== $found;
		$this->cfg_index_integrity_cache[ $cache_key ] = $result;

		return $result;
	}

	/**
	 * Whether an object has CFG meta rows that are not referenced by the index.
	 *
	 * @param string $object_type post or term.
	 * @param int    $object_id   Object ID.
	 * @return bool
	 */
	private function object_has_unindexed_cfg_meta_rows( $object_type, $object_id ) {
		global $wpdb;

		$object_id = (int) $object_id;
		if ( $object_id <= 0 ) {
			return false;
		}

		$object_type = ( 'term' === $object_type ) ? 'term' : 'post';
		$cache_key   = 'unindexed:' . $object_type . ':' . $object_id;
		if ( array_key_exists( $cache_key, $this->cfg_index_integrity_cache ) ) {
			return $this->cfg_index_integrity_cache[ $cache_key ];
		}

		if ( ! $this->object_has_cfg_index_rows( $object_type, $object_id ) ) {
			$this->cfg_index_integrity_cache[ $cache_key ] = false;
			return false;
		}

		if ( 'term' === $object_type ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$found = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT 1
					FROM {$wpdb->termmeta} tm
					WHERE tm.term_id = %d
					AND EXISTS (
						SELECT 1
						FROM {$wpdb->prefix}asenha_cfgroup_values_for_terms v2
						INNER JOIN {$wpdb->termmeta} tm2 ON tm2.meta_id = v2.meta_id
						WHERE v2.term_id = tm.term_id AND tm2.meta_key = tm.meta_key
					)
					AND NOT EXISTS (
						SELECT 1 FROM {$wpdb->prefix}asenha_cfgroup_values_for_terms v3 WHERE v3.meta_id = tm.meta_id
					)
					LIMIT 1",
					$object_id
				)
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$found = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT 1
					FROM {$wpdb->postmeta} pm
					WHERE pm.post_id = %d
					AND EXISTS (
						SELECT 1
						FROM {$wpdb->prefix}asenha_cfgroup_values v2
						INNER JOIN {$wpdb->postmeta} pm2 ON pm2.meta_id = v2.meta_id
						WHERE v2.post_id = pm.post_id AND pm2.meta_key = pm.meta_key
					)
					AND NOT EXISTS (
						SELECT 1 FROM {$wpdb->prefix}asenha_cfgroup_values v3 WHERE v3.meta_id = pm.meta_id
					)
					LIMIT 1",
					$object_id
				)
			);
		}

		$result = null !== $found;
		$this->cfg_index_integrity_cache[ $cache_key ] = $result;

		return $result;
	}

	/**
	 * Parse WPML TM/ATE job fields while preserving repeater occurrences.
	 *
	 * @param array $fields WPML job fields payload.
	 * @return array<string,array<int,array{value:mixed,ordinal:int|null,field_type:string}>>
	 */
	private function parse_wpml_job_fields_to_meta_map( $fields ) {
		$map = array();

		foreach ( (array) $fields as $key => $field ) {
			$field_type   = '';
			$data         = null;
			$field_format = '';

			if ( is_array( $field ) ) {
				if ( isset( $field['field_type'] ) ) {
					$field_type = (string) $field['field_type'];
				} elseif ( is_string( $key ) ) {
					$field_type = (string) $key;
				}

				if ( array_key_exists( 'data', $field ) ) {
					$data = $field['data'];
				} elseif ( array_key_exists( 'field_data_translated', $field ) ) {
					$data = $field['field_data_translated'];
				} elseif ( array_key_exists( 'field_data', $field ) ) {
					$data = $field['field_data'];
				}

				if ( isset( $field['field_format'] ) ) {
					$field_format = (string) $field['field_format'];
				}
			} elseif ( is_string( $key ) ) {
				$field_type = (string) $key;
				$data       = $field;
			}

			if ( '' === $field_type || null === $data || 0 !== strpos( $field_type, 'field-' ) ) {
				continue;
			}

			// Only real value rows: field-{meta_key} or field-{meta_key}-{n}.
			// Skip WPML auxiliaries like field-room_name-0-name / -type.
			$without_prefix = substr( $field_type, 6 );
			if ( ! preg_match( '/^([a-zA-Z0-9_]+)(?:-(\d+))?$/', $without_prefix, $matches ) ) {
				continue;
			}

			$meta_key = $matches[1];
			if ( '' === $meta_key ) {
				continue;
			}

			if ( ! isset( $map[ $meta_key ] ) ) {
				$map[ $meta_key ] = array();
			}
			$map[ $meta_key ][] = array(
				'value'      => $this->decode_wpml_job_field_data( $data, $field_format ),
				'ordinal'    => isset( $matches[2] ) ? (int) $matches[2] : null,
				'field_type' => $field_type,
			);
		}

		return $map;
	}

	/**
	 * Merge source-duplicated input data while keeping translated leaf values on the target.
	 *
	 * @param array $incoming_from_source Remapped source input data.
	 * @param array $existing_target      Existing target input data.
	 * @param array $fields_by_id         Field definitions keyed by ID.
	 * @return array
	 */
	private function merge_preserving_translated_input_fields( $incoming_from_source, $existing_target, $fields_by_id ) {
		if ( ! is_array( $incoming_from_source ) || ! is_array( $existing_target ) ) {
			return $incoming_from_source;
		}

		foreach ( $incoming_from_source as $field_id => $incoming_value ) {
			$field_id = (int) $field_id;
			if ( empty( $fields_by_id[ $field_id ] ) || ! array_key_exists( $field_id, $existing_target ) ) {
				continue;
			}

			$field          = $fields_by_id[ $field_id ];
			$existing_value = $existing_target[ $field_id ];

			if ( 'repeater' === $field['type'] && is_array( $incoming_value ) && is_array( $existing_value ) ) {
				$incoming_from_source[ $field_id ] = $this->merge_repeater_preserving_translations(
					$incoming_value,
					$existing_value,
					$fields_by_id,
					$field_id
				);
				continue;
			}

			if ( ! $this->is_wpml_translate_preference_field( $field ) ) {
				continue;
			}

			if ( $this->input_leaf_values_differ( $existing_value, $incoming_value ) ) {
				$incoming_from_source[ $field_id ] = $existing_value;
			}
		}

		return $incoming_from_source;
	}

	/**
	 * Merge repeater rows while preserving translated leaf values.
	 *
	 * @param array $incoming_rows Incoming rows from source.
	 * @param array $existing_rows Existing target rows.
	 * @param array $fields_by_id  Field definitions keyed by ID.
	 * @param int   $repeater_id  Repeater field ID.
	 * @return array
	 */
	private function merge_repeater_preserving_translations( $incoming_rows, $existing_rows, $fields_by_id, $repeater_id = 0 ) {
		$row_map = $this->align_repeater_row_keys( $incoming_rows, $existing_rows, (int) $repeater_id, $fields_by_id );

		foreach ( $incoming_rows as $row_index => $row ) {
			if ( ! is_array( $row ) || ! isset( $row_map[ $row_index ] ) ) {
				continue;
			}

			$existing_row_index = $row_map[ $row_index ];
			if ( ! array_key_exists( $existing_row_index, $existing_rows ) || ! is_array( $existing_rows[ $existing_row_index ] ) ) {
				continue;
			}

			$existing_row = $existing_rows[ $existing_row_index ];

			foreach ( $row as $sub_field_id => $sub_value ) {
				$sub_field_id = (int) $sub_field_id;
				if ( empty( $fields_by_id[ $sub_field_id ] ) || ! array_key_exists( $sub_field_id, $existing_row ) ) {
					continue;
				}

				$sub_field      = $fields_by_id[ $sub_field_id ];
				$existing_value = $existing_row[ $sub_field_id ];

				if ( 'repeater' === $sub_field['type'] && is_array( $sub_value ) && is_array( $existing_value ) ) {
					$incoming_rows[ $row_index ][ $sub_field_id ] = $this->merge_repeater_preserving_translations(
						$sub_value,
						$existing_value,
						$fields_by_id,
						$sub_field_id
					);
					continue;
				}

				if ( ! $this->is_wpml_translate_preference_field( $sub_field ) ) {
					continue;
				}

				if ( $this->input_leaf_values_differ( $existing_value, $sub_value ) ) {
					$incoming_rows[ $row_index ][ $sub_field_id ] = $existing_value;
				}
			}
		}

		return $incoming_rows;
	}

	/**
	 * Whether a field uses WPML translate preference.
	 *
	 * @param array|object $field Field definition.
	 * @return bool
	 */
	private function is_wpml_translate_preference_field( $field ) {
		if ( ! defined( 'WPML_TRANSLATE_CUSTOM_FIELD' ) ) {
			return false;
		}

		$preference = null;
		if ( is_object( $field ) && isset( $field->wpml_cf_preferences ) ) {
			$preference = (int) $field->wpml_cf_preferences;
		} elseif ( is_array( $field ) && isset( $field['wpml_cf_preferences'] ) ) {
			$preference = (int) $field['wpml_cf_preferences'];
		} else {
			$preference = $this->get_default_preference_for_field( $field );
		}

		return (int) WPML_TRANSLATE_CUSTOM_FIELD === (int) $preference;
	}

	/**
	 * Compare two input-format leaf values.
	 *
	 * @param mixed $left  Left value.
	 * @param mixed $right Right value.
	 * @return bool
	 */
	private function input_leaf_values_differ( $left, $right ) {
		return (string) $this->normalize_input_leaf_value( $left ) !== (string) $this->normalize_input_leaf_value( $right );
	}

	/**
	 * Whether an input-format leaf value is empty.
	 *
	 * @param mixed $value Value.
	 * @return bool
	 */
	private function is_empty_input_leaf_value( $value ) {
		$normalized = $this->normalize_input_leaf_value( $value );
		return null === $normalized || '' === $normalized;
	}

	/**
	 * Normalize an input-format leaf value for comparison.
	 *
	 * @param mixed $value Value.
	 * @return mixed
	 */
	private function normalize_input_leaf_value( $value ) {
		if ( is_array( $value ) && array_key_exists( 'value', $value ) ) {
			return $value['value'];
		}

		return $value;
	}

	/**
	 * Read a stored meta value for one CFG field definition.
	 *
	 * @param int    $object_id        Post or term ID.
	 * @param array  $field            Field definition.
	 * @param string $object_type      post or term.
	 * @param int    $source_object_id Optional source object ID for translate-aware selection.
	 * @return mixed
	 */
	private function read_meta_value_for_field( $object_id, $field, $object_type = 'post', $source_object_id = 0 ) {
		$multi_value_types = array( 'checkbox', 'gallery', 'relationship', 'term', 'user' );
		$single            = ! in_array( $field['type'], $multi_value_types, true );

		if ( 'term' === $object_type ) {
			if ( $single ) {
				return $this->read_canonical_single_meta_value( 'term', (int) $object_id, $field['name'], $field, 0 );
			}

			return get_term_meta( $object_id, $field['name'], false );
		}

		if ( $single ) {
			return $this->read_canonical_single_meta_value( 'post', (int) $object_id, $field['name'], $field, (int) $source_object_id );
		}

		return get_post_meta( $object_id, $field['name'], false );
	}

	/**
	 * Read the canonical single-value meta row when duplicates exist.
	 *
	 * @param string     $meta_type        post or term.
	 * @param int        $object_id        Post or term ID.
	 * @param string     $meta_key         Meta key.
	 * @param array|null $field            Optional field definition for translate-aware selection.
	 * @param int        $source_object_id Optional source object ID.
	 * @return mixed
	 */
	private function read_canonical_single_meta_value( $meta_type, $object_id, $meta_key, $field = null, $source_object_id = 0 ) {
		if ( $object_id <= 0 || '' === $meta_key ) {
			return null;
		}

		$rows = $this->get_object_meta_rows( $meta_type, $object_id, $meta_key );
		if ( empty( $rows ) ) {
			return null;
		}

		if ( count( $rows ) === 1 || empty( $field ) ) {
			$last = end( $rows );
			return is_array( $last ) ? $last['meta_value'] : null;
		}

		$source_values = array();
		if ( $source_object_id > 0 ) {
			$source_rows   = $this->get_object_meta_rows( $meta_type, $source_object_id, $meta_key );
			$source_values = array_slice( wp_list_pluck( $source_rows, 'meta_value' ), 0, 1 );
		}

		$selection = $this->select_canonical_meta_chunk(
			$rows,
			1,
			$source_values,
			$this->get_indexed_meta_id_lookup( $meta_type, $object_id ),
			$this->is_wpml_translate_preference_field( $field )
		);

		return isset( $selection['values'][0] ) ? $selection['values'][0] : null;
	}

	/**
	 * Remove stale duplicate postmeta rows for CFG fields (root and repeater children).
	 *
	 * @param int   $post_id    Post ID.
	 * @param array $field_defs Field definitions from find_input_fields().
	 * @return void
	 */
	private function cleanup_duplicate_cfg_postmeta( $post_id, $field_defs ) {
		$this->cleanup_duplicate_cfg_object_meta( 'post', (int) $post_id, $field_defs );
	}

	/**
	 * Remove stale duplicate termmeta rows for CFG fields (root and repeater children).
	 *
	 * @param int   $term_id    Term ID.
	 * @param array $field_defs Field definitions from find_input_fields().
	 * @return void
	 */
	private function cleanup_duplicate_cfg_termmeta( $term_id, $field_defs ) {
		$this->cleanup_duplicate_cfg_object_meta( 'term', (int) $term_id, $field_defs );
	}

	/**
	 * Remove surplus duplicate meta rows for CFG fields on a post or term.
	 *
	 * Root single-value fields keep one canonical row. Repeater sub-fields are
	 * deliberately left intact here and are cleaned only after a validated
	 * path-aware CFG save.
	 *
	 * @param string $object_type post or term.
	 * @param int    $object_id   Object ID.
	 * @param array  $field_defs  Field definitions.
	 * @return void
	 */
	private function cleanup_duplicate_cfg_object_meta( $object_type, $object_id, $field_defs ) {
		$object_id = (int) $object_id;
		if ( $object_id <= 0 || empty( $field_defs ) ) {
			return;
		}

		$multi_value_types = array( 'checkbox', 'gallery', 'relationship', 'term', 'user', 'repeater' );
		$fields_by_id      = array();
		foreach ( $field_defs as $field ) {
			$fields_by_id[ (int) $field['id'] ] = $field;
		}

		if ( 'term' === $object_type ) {
			$term = get_term( $object_id );
			if ( ! $term || is_wp_error( $term ) ) {
				return;
			}
			$existing_input = CFG()->get( false, $term->taxonomy . '_' . $object_id, array( 'format' => 'input' ) );
			$source_id      = 0;
		} else {
			$existing_input = CFG()->get( false, $object_id, array( 'format' => 'input' ) );
			$post           = get_post( $object_id );
			$source_id      = ( $post && ! empty( $post->post_type ) )
				? $this->get_source_post_id_for_translation( $object_id, $post->post_type )
				: 0;
			if ( (int) $source_id === $object_id ) {
				$source_id = 0;
			}
		}

		if ( ! is_array( $existing_input ) ) {
			$existing_input = array();
		}

		$expected_counts = array();
		foreach ( $existing_input as $field_id => $value ) {
			$field_id = (int) $field_id;
			if ( empty( $fields_by_id[ $field_id ] ) ) {
				continue;
			}
			$field = $fields_by_id[ $field_id ];
			if ( 'repeater' === $field['type'] && is_array( $value ) ) {
				$this->count_input_tree_field_occurrences( $value, $fields_by_id, $expected_counts );
			} elseif ( (int) $field['parent_id'] === 0 ) {
				$expected_counts[ $field_id ] = 1;
			}
		}

		$indexed_meta_ids = $this->get_indexed_meta_id_lookup( $object_type, $object_id );

		foreach ( $field_defs as $field ) {
			if ( in_array( $field['type'], $multi_value_types, true ) || $this->is_layout_field_type( $field['type'] ) ) {
				continue;
			}

			$field_id = (int) $field['id'];
			$is_child = (int) $field['parent_id'] !== 0;

			// Repeater children are cleaned only after a complete path-aware
			// rebuild. Selecting a flat chunk here can delete a valid child
			// value before its parent row has been resolved.
			if ( $is_child ) {
				continue;
			}

			$expected = isset( $expected_counts[ $field_id ] ) ? (int) $expected_counts[ $field_id ] : ( $is_child ? 0 : 1 );
			if ( $expected <= 0 ) {
				continue;
			}

			$rows = $this->get_object_meta_rows( $object_type, $object_id, $field['name'] );
			if ( count( $rows ) <= $expected ) {
				continue;
			}

			$source_values = array();
			if ( $source_id > 0 ) {
				$source_rows   = $this->get_object_meta_rows( $object_type, $source_id, $field['name'] );
				$source_values = array_slice( wp_list_pluck( $source_rows, 'meta_value' ), 0, $expected );
			}

			$selection = $this->select_canonical_meta_chunk(
				$rows,
				$expected,
				$source_values,
				$indexed_meta_ids,
				$this->is_wpml_translate_preference_field( $field )
			);

			$this->delete_surplus_meta_rows( $object_type, $rows, $selection['meta_ids'] );
		}
	}

	/**
	 * Remap relation/media values in CFG input-format data.
	 *
	 * @param array  $field_data   Input-format data keyed by field IDs.
	 * @param array  $fields_by_id Field definitions keyed by field IDs.
	 * @param string $target_lang  Target language code.
	 * @return array
	 */
	private function remap_input_field_data( $field_data, $fields_by_id, $target_lang ) {
		foreach ( $field_data as $field_id => $field_value ) {
			$field_id              = (int) $field_id;
			$field_data[ $field_id ] = $this->remap_single_input_field( $field_id, $field_value, $fields_by_id, $target_lang );
		}

		return $field_data;
	}

	/**
	 * Remap one input-format field tree.
	 *
	 * @param int    $field_id      Field ID.
	 * @param mixed  $field_value   Input-format field value.
	 * @param array  $fields_by_id  Field definitions keyed by ID.
	 * @param string $target_lang   Target language.
	 * @return mixed
	 */
	private function remap_single_input_field( $field_id, $field_value, $fields_by_id, $target_lang ) {
		if ( empty( $fields_by_id[ $field_id ] ) ) {
			return $field_value;
		}

		$field = $fields_by_id[ $field_id ];

		if ( 'repeater' === $field['type'] && is_array( $field_value ) && ! isset( $field_value['value'] ) ) {
			foreach ( $field_value as $sub_field_id => $sub_field_value ) {
				$field_value[ $sub_field_id ] = $this->remap_single_input_field( (int) $sub_field_id, $sub_field_value, $fields_by_id, $target_lang );
			}

			return $field_value;
		}

		if ( is_array( $field_value ) && isset( $field_value['value'] ) ) {
			$field_value['value'] = $this->remap_runtime_value( $field_value['value'], $field, $target_lang );
			return $field_value;
		}

		return $this->remap_runtime_value( $field_value, $field, $target_lang );
	}

	/**
	 * Remap a field value for the target language.
	 *
	 * @param mixed  $value       Field value.
	 * @param array  $field       Field definition.
	 * @param string $target_lang Target language code.
	 * @return mixed
	 */
	private function remap_runtime_value( $value, $field, $target_lang ) {
		switch ( $field['type'] ) {
			case 'relationship':
				return $this->remap_post_ids( $value, $target_lang );

			case 'term':
				return $this->remap_term_ids( $value, $field, $target_lang );

			case 'file':
				return $this->remap_attachment_ids( $value, false, $target_lang );

			case 'gallery':
				return $this->remap_attachment_ids( $value, true, $target_lang );

			case 'hyperlink':
				return $this->remap_hyperlink_value( $value, $target_lang );

			default:
				return $value;
		}
	}

	/**
	 * Remap relationship field post IDs.
	 *
	 * @param mixed  $value       Current value.
	 * @param string $target_lang Target language.
	 * @return mixed
	 */
	private function remap_post_ids( $value, $target_lang ) {
		$map_callback = function( $id ) use ( $target_lang ) {
			$post_type = get_post_type( (int) $id );
			if ( empty( $post_type ) ) {
				return (int) $id;
			}

			return (int) apply_filters( 'wpml_object_id', (int) $id, $post_type, true, $target_lang );
		};

		return $this->remap_delimited_ids( $value, $map_callback );
	}

	/**
	 * Remap term field IDs.
	 *
	 * @param mixed  $value       Current value.
	 * @param array  $field       Field definition.
	 * @param string $target_lang Target language.
	 * @return mixed
	 */
	private function remap_term_ids( $value, $field, $target_lang ) {
		$map_callback = function( $id ) use ( $field, $target_lang ) {
			$taxonomy = '';

			if ( ! empty( $field['options']['taxonomies'] ) && is_array( $field['options']['taxonomies'] ) ) {
				$taxonomy = (string) reset( $field['options']['taxonomies'] );
			}

			if ( empty( $taxonomy ) ) {
				$term = get_term( (int) $id );
				if ( $term && ! is_wp_error( $term ) ) {
					$taxonomy = $term->taxonomy;
				}
			}

			if ( empty( $taxonomy ) ) {
				return (int) $id;
			}

			return (int) apply_filters( 'wpml_object_id', (int) $id, $taxonomy, true, $target_lang );
		};

		return $this->remap_delimited_ids( $value, $map_callback );
	}

	/**
	 * Remap attachment IDs.
	 *
	 * @param mixed  $value         Current value.
	 * @param bool   $comma_string  Whether the value is stored as a comma string.
	 * @param string $target_lang   Target language.
	 * @return mixed
	 */
	private function remap_attachment_ids( $value, $comma_string, $target_lang ) {
		$map_callback = function( $id ) use ( $target_lang ) {
			return (int) apply_filters( 'wpml_object_id', (int) $id, 'attachment', true, $target_lang );
		};

		return $this->remap_delimited_ids( $value, $map_callback, $comma_string );
	}

	/**
	 * Apply an ID remapping callback to delimited values.
	 *
	 * @param mixed    $value         Current value.
	 * @param callable $map_callback  Mapping callback.
	 * @param bool     $force_string  Whether to always return a comma string.
	 * @return mixed
	 */
	private function remap_delimited_ids( $value, $map_callback, $force_string = false ) {
		$is_array = is_array( $value );
		$items    = $is_array ? $value : explode( ',', (string) $value );
		$items    = array_filter( array_map( 'trim', $items ), 'strlen' );
		$items    = array_map(
			static function( $id ) use ( $map_callback ) {
				return (string) call_user_func( $map_callback, $id );
			},
			$items
		);

		if ( $force_string || ! $is_array ) {
			return implode( ',', $items );
		}

		return $items;
	}

	/**
	 * Remap hyperlink values.
	 *
	 * @param mixed  $value       Current value.
	 * @param string $target_lang Target language.
	 * @return mixed
	 */
	private function remap_hyperlink_value( $value, $target_lang ) {
		if ( is_string( $value ) ) {
			$maybe_array = maybe_unserialize( $value );
			if ( is_array( $maybe_array ) ) {
				$maybe_array['url'] = $this->translate_internal_url(
					isset( $maybe_array['url'] ) ? $maybe_array['url'] : '',
					$target_lang
				);

				return maybe_serialize( $maybe_array );
			}

			return $this->translate_internal_url( $value, $target_lang );
		}

		if ( is_array( $value ) && isset( $value['url'] ) ) {
			$value['url'] = $this->translate_internal_url( $value['url'], $target_lang );
		}

		return $value;
	}

	/**
	 * Translate an internal URL into the target language when possible.
	 *
	 * @param string $url         Current URL.
	 * @param string $target_lang Target language.
	 * @return string
	 */
	private function translate_internal_url( $url, $target_lang ) {
		$url = (string) $url;
		if ( '' === $url ) {
			return $url;
		}

		$site_host = wp_parse_url( home_url(), PHP_URL_HOST );
		$url_host  = wp_parse_url( $url, PHP_URL_HOST );

		if ( empty( $url_host ) || $url_host === $site_host ) {
			$translated = apply_filters( 'wpml_permalink', $url, $target_lang, true );
			if ( is_string( $translated ) && '' !== $translated ) {
				return $translated;
			}
		}

		return $url;
	}

	/**
	 * Delete CFG meta and index rows for one object before a rebuild.
	 *
	 * @param string $object_type post or term.
	 * @param int    $object_id   Object ID.
	 * @param array  $group_ids   Group IDs attached to the object.
	 * @return void
	 */
	private function delete_cfg_object_values( $object_type, $object_id, $group_ids ) {
		global $wpdb;

		$field_defs = CFG()->api->find_input_fields( array( 'group_id' => $group_ids ) );
		if ( empty( $field_defs ) ) {
			return;
		}

		$field_ids = array();
		foreach ( $field_defs as $field ) {
			$field_ids[] = (int) $field['id'];
		}

		$field_ids = implode( ',', array_unique( $field_ids ) );
		if ( '' === $field_ids ) {
			return;
		}

		if ( 'post' === $object_type ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query(
				"DELETE v, m
				FROM {$wpdb->prefix}asenha_cfgroup_values v
				LEFT JOIN {$wpdb->postmeta} m ON m.meta_id = v.meta_id
				WHERE v.post_id = " . (int) $object_id . " AND v.field_id IN ($field_ids)"
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query(
				"DELETE v, m
				FROM {$wpdb->prefix}asenha_cfgroup_values_for_terms v
				LEFT JOIN {$wpdb->termmeta} m ON m.meta_id = v.meta_id
				WHERE v.term_id = " . (int) $object_id . " AND v.field_id IN ($field_ids)"
			);
		}
	}

	/**
	 * Render admin notice if ASE definition post types were made translatable.
	 *
	 * @return void
	 */
	public function maybe_render_definition_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings = $this->get_wpml_setting( 'custom_posts_sync_option', array() );
		$internal = array( 'asenha_cpt', 'asenha_ctax', 'asenha_cfgroup', 'options_page_config', 'asenha_options_page' );
		$invalid  = array();

		foreach ( $internal as $post_type ) {
			if ( ! empty( $settings[ $post_type ] ) ) {
				$invalid[] = $post_type;
			}
		}

		if ( empty( $invalid ) ) {
			return;
		}
		?>
		<div class="notice notice-warning">
			<p>
				<?php
				echo wp_kses_post(
					sprintf(
						/* translators: %s is a comma-separated list of internal ASE post types. */
						__( 'ASE Custom Content Types keeps these internal definition post types non-translatable for WPML compatibility: <code>%s</code>. Please switch them back to "Not translatable" in WPML settings.', 'admin-site-enhancements' ),
						implode( '</code>, <code>', array_map( 'esc_html', $invalid ) )
					)
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Render a warning when a translated repeater job is stale.
	 *
	 * @return void
	 */
	public function maybe_render_stale_wpml_job_notice() {
		if ( ! is_admin() || ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$diagnostics = get_transient( self::STALE_WPML_JOB_DIAGNOSTICS_TRANSIENT );
		$diagnostics = $this->refresh_stale_wpml_job_diagnostics( $diagnostics );
		if ( ! is_array( $diagnostics ) || empty( $diagnostics ) || ! $this->is_stale_wpml_job_notice_context( $diagnostics ) ) {
			return;
		}

		$has_completed_mode = false;
		$has_surplus        = false;
		foreach ( $diagnostics as $diagnostic ) {
			if ( ! empty( $diagnostic['mode'] ) && 'completed' === $diagnostic['mode'] ) {
				$has_completed_mode = true;
			}
			foreach ( (array) ( isset( $diagnostic['fields'] ) ? $diagnostic['fields'] : array() ) as $field ) {
				$source_count = isset( $field['source_count'] ) ? (int) $field['source_count'] : 0;
				$job_count    = isset( $field['job_count'] ) ? (int) $field['job_count'] : 0;
				if ( $job_count > $source_count ) {
					$has_surplus = true;
				}
			}
		}

		?>
		<div class="notice notice-warning asenha-wpml-stale-job-notice" id="asenha-wpml-stale-job-notice">
			<p>
				<strong><?php echo esc_html__( 'WPML translation update required for repeater fields.', 'admin-site-enhancements' ); ?></strong>
			</p>
			<p>
				<?php
				if ( $has_surplus ) {
					echo esc_html__( 'The WPML job contains more repeater occurrences than the English source (deleted rooms or features may still be present). Use WPML’s Update translation or resend workflow before opening, saving, or completing the translation with WPML Translation Editor.', 'admin-site-enhancements' );
				} elseif ( $has_completed_mode ) {
					echo esc_html__( 'The completed translation is out of date: the last WPML job contains fewer repeater occurrences than the English source. Use WPML’s Update translation or resend workflow before opening, saving, or completing the translation with WPML Translation Editor.', 'admin-site-enhancements' );
				} else {
					echo esc_html__( 'The current translation job contains fewer repeater occurrences than the English source. Use WPML’s Update translation or resend workflow before opening, saving, or completing the translation with WPML Translation Editor.', 'admin-site-enhancements' );
				}
				?>
			</p>
			<ul>
				<?php
				foreach ( $diagnostics as $diagnostic ) {
					$source_post_id     = ! empty( $diagnostic['source_post_id'] ) ? (int) $diagnostic['source_post_id'] : 0;
					$translated_post_id = ! empty( $diagnostic['translated_post_id'] ) ? (int) $diagnostic['translated_post_id'] : 0;
					$source_title       = $source_post_id > 0 ? get_the_title( $source_post_id ) : '';
					$translated_title   = $translated_post_id > 0 ? get_the_title( $translated_post_id ) : '';
					$source_title       = '' !== (string) $source_title ? (string) $source_title : sprintf( __( 'Post #%d', 'admin-site-enhancements' ), $source_post_id );
					$translated_title   = '' !== (string) $translated_title ? (string) $translated_title : sprintf( __( 'Post #%d', 'admin-site-enhancements' ), $translated_post_id );
					$field_summaries    = array();

					foreach ( (array) $diagnostic['fields'] as $field ) {
						$field_summaries[] = sprintf(
							'%1$s (%2$d source / %3$d in job)',
							isset( $field['meta_key'] ) ? (string) $field['meta_key'] : '',
							isset( $field['source_count'] ) ? (int) $field['source_count'] : 0,
							isset( $field['job_count'] ) ? (int) $field['job_count'] : 0
						);
					}

					$diagnostic_text = sprintf(
						/* translators: 1: source post title, 2: translated post title, 3: stale field count details. */
						__( '%1$s → %2$s: %3$s.', 'admin-site-enhancements' ),
						$source_title,
						$translated_title,
						implode( ', ', $field_summaries )
					);
					?>
					<li><?php echo esc_html( $diagnostic_text ); ?></li>
					<?php
				}
				?>
			</ul>
			<p>
				<a href="<?php echo esc_url( $this->get_wpml_translation_management_url() ); ?>">
					<?php echo esc_html__( 'Open WPML Translation Management', 'admin-site-enhancements' ); ?>
				</a>
			</p>
		</div>
		<?php
	}

	/**
	 * Recheck retained diagnostics so a refreshed job removes its warning.
	 *
	 * @param mixed $diagnostics Previously retained diagnostics.
	 * @return array<int,array<string,mixed>>
	 */
	private function refresh_stale_wpml_job_diagnostics( $diagnostics ) {
		if ( ! is_array( $diagnostics ) || empty( $diagnostics ) ) {
			return array();
		}

		$current = array();
		foreach ( $diagnostics as $diagnostic ) {
			$source_post_id     = ! empty( $diagnostic['source_post_id'] ) ? (int) $diagnostic['source_post_id'] : 0;
			$translated_post_id = ! empty( $diagnostic['translated_post_id'] ) ? (int) $diagnostic['translated_post_id'] : 0;
			$post_type          = ! empty( $diagnostic['post_type'] ) ? (string) $diagnostic['post_type'] : '';

			if ( $source_post_id <= 0 || $translated_post_id <= 0 || '' === $post_type ) {
				continue;
			}

			$refreshed = $this->get_stale_wpml_repeater_job_diagnostic( $source_post_id, $translated_post_id, $post_type );
			if ( ! empty( $refreshed ) ) {
				$current[] = $refreshed;
			}
		}

		if ( empty( $current ) ) {
			delete_transient( self::STALE_WPML_JOB_DIAGNOSTICS_TRANSIENT );
			return array();
		}

		set_transient(
			self::STALE_WPML_JOB_DIAGNOSTICS_TRANSIENT,
			$current,
			defined( 'DAY_IN_SECONDS' ) ? DAY_IN_SECONDS : 86400
		);

		return $current;
	}

	/**
	 * Whether the current admin screen is relevant to a stale-job warning.
	 *
	 * @param array $diagnostics Stale-job diagnostics.
	 * @return bool
	 */
	private function is_stale_wpml_job_notice_context( $diagnostics ) {
		$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
		if ( 0 === strpos( $page, 'tm/menu/' ) || in_array( $page, array( 'wpml-translation-dashboard', 'wpml-translation-management' ), true ) ) {
			return true;
		}

		$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
		if ( $post_id <= 0 ) {
			return false;
		}

		foreach ( (array) $diagnostics as $diagnostic ) {
			if (
				$post_id === (int) ( isset( $diagnostic['source_post_id'] ) ? $diagnostic['source_post_id'] : 0 )
				|| $post_id === (int) ( isset( $diagnostic['translated_post_id'] ) ? $diagnostic['translated_post_id'] : 0 )
			) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get the WPML Translation Management dashboard URL.
	 *
	 * @return string
	 */
	private function get_wpml_translation_management_url() {
		$page = 'tm/menu/main.php';
		if ( defined( 'WPML_TM_FOLDER' ) && '' !== trim( (string) WPML_TM_FOLDER, '/' ) ) {
			$page = trim( (string) WPML_TM_FOLDER, '/' ) . '/menu/main.php';
		}

		return add_query_arg( 'page', $page, admin_url( 'admin.php' ) );
	}

	/**
	 * Get field-group mode from extras.
	 *
	 * @param array $extras CFG extras.
	 * @return string
	 */
	private function get_field_group_mode( $extras ) {
		$mode  = isset( $extras['cfgroup_wpml_mode'] ) ? sanitize_key( (string) $extras['cfgroup_wpml_mode'] ) : 'translation';
		$modes = $this->get_field_group_modes();

		return isset( $modes[ $mode ] ) ? $mode : 'translation';
	}

	/**
	 * Get supported field-group modes.
	 *
	 * @return array<string,string>
	 */
	private function get_field_group_modes() {
		return array(
			'translation'  => __( 'Translation', 'admin-site-enhancements' ),
			'localization' => __( 'Localization', 'admin-site-enhancements' ),
			'advanced'     => __( 'Advanced', 'admin-site-enhancements' ),
		);
	}

	/**
	 * Get field-group mode descriptions for the admin metabox.
	 *
	 * @return array<string,string>
	 */
	private function get_field_group_mode_descriptions() {
		return array(
			'translation'  => __( 'Apply default WPML preferences: text-like fields are translated, while other fields are copied from the default language.', 'admin-site-enhancements' ),
			'localization' => __( 'Apply default WPML preferences: text-like fields are translated; numbers, choices, dates, and similar fields are copied once; media, relationship, and similar fields are copied from the default language.', 'admin-site-enhancements' ),
			'advanced'     => __( 'Expose per-field WPML translation preferences inside the custom field group builder.', 'admin-site-enhancements' ),
		);
	}

	/**
	 * Get preference labels keyed by WPML constant value.
	 *
	 * @return array<int,string>
	 */
	private function get_field_preference_labels() {
		return array(
			(int) WPML_IGNORE_CUSTOM_FIELD    => __( "Don't translate", 'admin-site-enhancements' ),
			(int) WPML_COPY_CUSTOM_FIELD      => __( 'Copy', 'admin-site-enhancements' ),
			(int) WPML_COPY_ONCE_CUSTOM_FIELD => __( 'Copy once', 'admin-site-enhancements' ),
			(int) WPML_TRANSLATE_CUSTOM_FIELD => __( 'Translate', 'admin-site-enhancements' ),
		);
	}

	/**
	 * Get the default preference for a field definition.
	 *
	 * @param array|object $field Field definition.
	 * @param string       $mode  Field-group mode.
	 * @return int
	 */
	private function get_default_preference_for_field( $field, $mode = 'translation' ) {
		$field_type = '';

		if ( is_object( $field ) && isset( $field->type ) ) {
			$field_type = (string) $field->type;
		} elseif ( is_array( $field ) && isset( $field['type'] ) ) {
			$field_type = (string) $field['type'];
		}

		if ( 'text' === $field_type && ! $this->is_translatable_text_field_subtype( $field ) ) {
			return (int) WPML_COPY_CUSTOM_FIELD;
		}

		return $this->get_default_preference_for_type( $field_type, $mode );
	}

	/**
	 * Determine whether a text field subtype should translate by default.
	 *
	 * @param array|object $field Field definition.
	 * @return bool
	 */
	private function is_translatable_text_field_subtype( $field ) {
		$options = array();

		if ( is_object( $field ) && isset( $field->options ) && is_array( $field->options ) ) {
			$options = $field->options;
		} elseif ( is_array( $field ) && isset( $field['options'] ) && is_array( $field['options'] ) ) {
			$options = $field['options'];
		}

		$text_type = isset( $options['text_type'] ) ? sanitize_key( (string) $options['text_type'] ) : 'any';
		if ( ! in_array( $text_type, array( 'any', 'url', 'email', 'phone', 'shortcode' ), true ) ) {
			$text_type = 'any';
		}

		return 'any' === $text_type;
	}

	/**
	 * Get the default preference for a field type.
	 *
	 * @param string $field_type CFG field type.
	 * @param string $mode       Field-group mode.
	 * @return int
	 */
	private function get_default_preference_for_type( $field_type, $mode = 'translation' ) {
		$translate_fields = array( 'text', 'textarea', 'wysiwyg', 'hyperlink' );
		$copy_fields      = array( 'file', 'gallery', 'relationship', 'term', 'user', 'repeater' );
		$copy_once_fields = array( 'number', 'date', 'time', 'datetime', 'color', 'true_false', 'select', 'radio', 'checkbox' );

		if ( in_array( $field_type, $translate_fields, true ) ) {
			return (int) WPML_TRANSLATE_CUSTOM_FIELD;
		}

		if ( in_array( $field_type, $copy_fields, true ) ) {
			return (int) WPML_COPY_CUSTOM_FIELD;
		}

		if ( 'localization' === $mode && in_array( $field_type, $copy_once_fields, true ) ) {
			return (int) WPML_COPY_ONCE_CUSTOM_FIELD;
		}

		if ( in_array( $field_type, $copy_once_fields, true ) ) {
			return (int) WPML_COPY_CUSTOM_FIELD;
		}

		return (int) WPML_COPY_CUSTOM_FIELD;
	}

	/**
	 * Whether the field type is layout-only.
	 *
	 * @param string $field_type CFG field type.
	 * @return bool
	 */
	private function is_layout_field_type( $field_type ) {
		return in_array( $field_type, array( 'tab', 'heading', 'line_break' ), true );
	}

	/**
	 * Translate a plain label array through a package.
	 *
	 * @param array                   $labels  Labels.
	 * @param ASENHA_CCT_WPML_Package $package Package helper.
	 * @param string                  $prefix  Namespace prefix.
	 * @return array
	 */
	private function translate_label_array( $labels, $package, $prefix, $object_id, $definition_id = 0, $object_type = '' ) {
		$meta_map = array();

		if ( 'post_type' === $object_type ) {
			$meta_map = $this->get_post_type_label_runtime_to_meta_map();
		} elseif ( 'taxonomy' === $object_type ) {
			$meta_map = $this->get_taxonomy_label_runtime_to_meta_map();
		}

		foreach ( $labels as $key => $value ) {
			if ( ! is_string( $value ) || '' === $value ) {
				continue;
			}

			if ( $definition_id > 0 ) {
				if ( 'post_type' === $object_type && ! ASENHA_CCT_Label_Context::is_post_type_label_applicable( $definition_id, $key ) ) {
					continue;
				}

				if ( 'taxonomy' === $object_type && ! ASENHA_CCT_Label_Context::is_taxonomy_label_applicable( $definition_id, $key ) ) {
					continue;
				}
			}

			$lookup_key = isset( $meta_map[ $key ] ) ? $meta_map[ $key ] : $key;
			$string_meta = array(
				'namespace' => $prefix,
				'id'        => $object_id,
				'key'       => $lookup_key,
			);

			$translated = $package->translate_string( $value, $string_meta );

			if ( $translated === $value && $lookup_key !== $key ) {
				$string_meta['key'] = $key;
				$translated           = $package->translate_string( $value, $string_meta );
			}

			$labels[ $key ] = $translated;
		}

		return $labels;
	}

	/**
	 * Get the translation mode for a generated object.
	 *
	 * @param string $slug        Object slug.
	 * @param string $setting_key WPML setting key.
	 * @return string
	 */
	private function get_object_translation_mode( $slug, $setting_key ) {
		if ( empty( $slug ) ) {
			return 'do_not_translate';
		}

		$settings = $this->get_wpml_setting( $setting_key, array() );
		$mode     = isset( $settings[ $slug ] ) ? (int) $settings[ $slug ] : (int) WPML_CONTENT_TYPE_DONT_TRANSLATE;

		switch ( $mode ) {
			case WPML_CONTENT_TYPE_TRANSLATE:
				return 'translate';

			case WPML_CONTENT_TYPE_DISPLAY_AS_IF_TRANSLATED:
				return 'display_as_translated';

			default:
				return 'do_not_translate';
		}
	}

	/**
	 * Apply generated post-type translation mode.
	 *
	 * @param string $slug Object slug.
	 * @param string $mode Mode slug.
	 * @return void
	 */
	private function apply_post_type_translation_mode( $slug, $mode ) {
		switch ( $mode ) {
			case 'translate':
				do_action( 'wpml_set_translation_mode_for_post_type', $slug, 'translate' );
				break;

			case 'display_as_translated':
				do_action( 'wpml_set_translation_mode_for_post_type', $slug, 'display_as_translated' );
				break;

			default:
				do_action( 'wpml_set_translation_mode_for_post_type', $slug, 'do_not_translate' );
				break;
		}
	}

	/**
	 * Apply generated taxonomy translation mode.
	 *
	 * @param string $slug Object slug.
	 * @param string $mode Mode slug.
	 * @return void
	 */
	private function apply_taxonomy_translation_mode( $slug, $mode ) {
		$settings = $this->get_wpml_setting( 'taxonomies_sync_option', array() );

		switch ( $mode ) {
			case 'translate':
				$settings[ $slug ] = (int) WPML_CONTENT_TYPE_TRANSLATE;
				break;

			case 'display_as_translated':
				$settings[ $slug ] = (int) WPML_CONTENT_TYPE_DISPLAY_AS_IF_TRANSLATED;
				break;

			default:
				unset( $settings[ $slug ] );
				break;
		}

		$this->set_wpml_setting( 'taxonomies_sync_option', $settings );
	}

	/**
	 * Get current WPML language.
	 *
	 * @return string
	 */
	private function get_current_language() {
		$language = apply_filters( 'wpml_current_language', null );
		return is_string( $language ) ? $language : '';
	}

	/**
	 * Get default WPML language.
	 *
	 * @return string
	 */
	private function get_default_language() {
		$language = apply_filters( 'wpml_default_language', null );
		return is_string( $language ) ? $language : '';
	}

	/**
	 * Get an element language code.
	 *
	 * @param int    $element_id   Element ID.
	 * @param string $element_type Post type or taxonomy.
	 * @return string
	 */
	private function get_element_language_code( $element_id, $element_type ) {
		$language = apply_filters(
			'wpml_element_language_code',
			null,
			array(
				'element_id'   => $element_id,
				'element_type' => $element_type,
			)
		);

		return is_string( $language ) ? $language : '';
	}

	/**
	 * Read a WPML setting safely.
	 *
	 * @param string $setting_key Setting key.
	 * @param mixed  $default     Default value.
	 * @return mixed
	 */
	private function get_wpml_setting( $setting_key, $default ) {
		global $sitepress;

		if ( is_object( $sitepress ) && method_exists( $sitepress, 'get_setting' ) ) {
			return $sitepress->get_setting( $setting_key, $default );
		}

		if ( function_exists( 'wpml_get_setting' ) ) {
			return wpml_get_setting( $setting_key, $default );
		}

		return $default;
	}

	/**
	 * Save a WPML setting safely.
	 *
	 * @param string $setting_key Setting key.
	 * @param mixed  $value       Setting value.
	 * @return void
	 */
	private function set_wpml_setting( $setting_key, $value ) {
		global $sitepress;

		if ( is_object( $sitepress ) && method_exists( $sitepress, 'set_setting' ) ) {
			$sitepress->set_setting( $setting_key, $value, true );
		}
	}

	/**
	 * Check whether the current save is for the expected ASE definition post type.
	 *
	 * @param WP_Post $post              Current post object.
	 * @param string  $expected_post_type Expected post type slug.
	 * @return bool
	 */
	private function is_expected_definition_post_type( $post, $expected_post_type ) {
		return is_object( $post )
			&& isset( $post->post_type )
			&& $expected_post_type === $post->post_type;
	}

	/**
	 * Check whether a save callback should continue.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Current post.
	 * @return bool
	 */
	private function is_valid_admin_save( $post_id, $post ) {
		if ( ! is_object( $post ) ) {
			return false;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return false;
		}

		if ( false !== wp_is_post_revision( $post_id ) ) {
			return false;
		}

		return current_user_can( 'edit_post', $post_id );
	}

	/**
	 * Check whether the ASE definition settings form was submitted.
	 *
	 * @return bool
	 */
	private function is_valid_definition_form_save() {
		return isset( $_POST['asenha_cpt_ctax_optionp__meta_box_nonce_field'] )
			&& wp_verify_nonce(
				sanitize_text_field( wp_unslash( $_POST['asenha_cpt_ctax_optionp__meta_box_nonce_field'] ) ),
				'asenha_cpt_ctax_optionp_meta_box_nonce_action'
			);
	}

	/**
	 * Register a pre-collected set of package strings with WPML.
	 *
	 * @param ASENHA_CCT_WPML_Package $package   Package helper.
	 * @param string                  $object_id Object slug.
	 * @param string                  $namespace String namespace.
	 * @param array<string,array<string,string>> $strings Collected strings keyed by meta key.
	 * @return bool
	 */
	private function register_collected_package_strings( $package, $object_id, $namespace, $strings ) {
		if ( empty( $strings ) ) {
			return false;
		}

		$package->start_registration();

		foreach ( $strings as $meta_key => $entry ) {
			$package->register_string(
				$entry['value'],
				array(
					'namespace' => $namespace,
					'id'        => $object_id,
					'key'       => $meta_key,
					'title'     => $entry['title'],
				)
			);
		}

		$package->cleanup_unused_strings();

		return $package->has_registered_strings();
	}

	/**
	 * Collect registrable custom post type strings for one definition.
	 *
	 * @param WP_Post $post Custom post type definition post.
	 * @return array<string,array<string,string>>
	 */
	private function collect_post_type_strings_for_definition( $post ) {
		$string_keys = $this->get_post_type_string_keys();
		$strings     = $this->collect_definition_strings_from_meta(
			$post->ID,
			$string_keys,
			array( $this, 'is_post_type_label_applicable_for_collection' )
		);

		$this->ensure_minimum_definition_strings(
			$post,
			$strings,
			$string_keys,
			array( 'cpt_plural_name', 'cpt_singular_name' )
		);

		return $strings;
	}

	/**
	 * Collect registrable taxonomy strings for one definition.
	 *
	 * @param WP_Post $post Taxonomy definition post.
	 * @return array<string,array<string,string>>
	 */
	private function collect_taxonomy_strings_for_definition( $post ) {
		$string_keys = $this->get_taxonomy_string_keys();
		$strings     = $this->collect_definition_strings_from_meta(
			$post->ID,
			$string_keys,
			array( $this, 'is_taxonomy_label_applicable_for_collection' )
		);

		$this->ensure_minimum_definition_strings(
			$post,
			$strings,
			$string_keys,
			array( 'ctax_plural_name', 'ctax_singular_name' )
		);

		return $strings;
	}

	/**
	 * Collect registrable options-page strings for one definition.
	 *
	 * @param WP_Post $post Options-page definition post.
	 * @return array<string,array<string,string>>
	 */
	private function collect_options_page_strings_for_definition( $post ) {
		return $this->collect_definition_strings_from_meta(
			$post->ID,
			$this->get_options_page_string_keys()
		);
	}

	/**
	 * Collect non-empty definition strings from post meta.
	 *
	 * @param int                                 $definition_id Definition post ID.
	 * @param array<string,string>                $string_keys   Meta keys and titles.
	 * @param callable|null                       $is_applicable Optional applicability callback.
	 * @return array<string,array<string,string>>
	 */
	private function collect_definition_strings_from_meta( $definition_id, $string_keys, $is_applicable = null ) {
		$strings = array();

		foreach ( $string_keys as $meta_key => $title ) {
			if ( is_callable( $is_applicable ) && ! call_user_func( $is_applicable, $definition_id, $meta_key ) ) {
				continue;
			}

			$value = trim( (string) get_post_meta( $definition_id, $meta_key, true ) );
			if ( '' === $value ) {
				continue;
			}

			$strings[ $meta_key ] = array(
				'value' => $value,
				'title' => $title,
			);
		}

		return $strings;
	}

	/**
	 * Ensure minimum package strings exist using stored meta or the definition title.
	 *
	 * @param WP_Post                             $post          Definition post.
	 * @param array<string,array<string,string>>  $strings       Collected strings.
	 * @param array<string,string>                $string_keys   Meta keys and titles.
	 * @param string[]                            $minimum_keys  Required meta keys.
	 * @return void
	 */
	private function ensure_minimum_definition_strings( $post, &$strings, $string_keys, $minimum_keys ) {
		foreach ( $minimum_keys as $meta_key ) {
			if ( isset( $strings[ $meta_key ] ) ) {
				continue;
			}

			$value = trim( (string) get_post_meta( $post->ID, $meta_key, true ) );
			if ( '' === $value && isset( $minimum_keys[0] ) && $meta_key === $minimum_keys[0] ) {
				$value = trim( (string) $post->post_title );
			}

			if ( '' === $value ) {
				continue;
			}

			$strings[ $meta_key ] = array(
				'value' => $value,
				'title' => isset( $string_keys[ $meta_key ] ) ? $string_keys[ $meta_key ] : $meta_key,
			);
		}
	}

	/**
	 * Whether a custom post type label should be collected for WPML registration.
	 *
	 * @param int    $definition_id Definition post ID.
	 * @param string $meta_key      Meta key.
	 * @return bool
	 */
	private function is_post_type_label_applicable_for_collection( $definition_id, $meta_key ) {
		return ASENHA_CCT_Label_Context::is_post_type_label_applicable( $definition_id, $meta_key );
	}

	/**
	 * Whether a taxonomy label should be collected for WPML registration.
	 *
	 * @param int    $definition_id Definition post ID.
	 * @param string $meta_key      Meta key.
	 * @return bool
	 */
	private function is_taxonomy_label_applicable_for_collection( $definition_id, $meta_key ) {
		return ASENHA_CCT_Label_Context::is_taxonomy_label_applicable( $definition_id, $meta_key );
	}

	/**
	 * Check whether a meta key belongs to a CFG field.
	 *
	 * @param string $meta_key     Meta key.
	 * @param int    $object_id    Source object ID.
	 * @param string $object_type  post or term.
	 * @param string $taxonomy     Optional taxonomy.
	 * @return bool
	 */
	private function is_cfg_field_name( $meta_key, $object_id, $object_type = 'post', $taxonomy = '' ) {
		if ( '' === $meta_key ) {
			return false;
		}

		if ( 'post' === $object_type ) {
			$field = get_cf_info( $meta_key, $object_id );
		} else {
			$field = get_cf_info( $meta_key, $taxonomy . '_' . $object_id );
		}

		return is_array( $field ) && ! empty( $field['name'] );
	}

	/**
	 * Get or create a companion options-page post for the current language.
	 *
	 * @param array  $screen_meta   Screen metadata.
	 * @param string $language_code Language code.
	 * @return int
	 */
	private function get_or_create_options_page_companion( $screen_meta, $language_code ) {
		$args = array(
			'post_type'              => 'asenha_options_page',
			'post_status'            => 'any',
			'numberposts'            => 1,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'meta_query'             => array(
				array(
					'key'   => '_asenha_wpml_options_config_id',
					'value' => (int) $screen_meta['config_id'],
				),
				array(
					'key'   => '_asenha_wpml_language',
					'value' => $language_code,
				),
			),
		);

		$posts = get_posts( $args );
		if ( ! empty( $posts ) ) {
			return (int) $posts[0]->ID;
		}

		$post_id = wp_insert_post(
			array(
				'post_type'   => 'asenha_options_page',
				'post_status' => 'publish',
				'post_title'  => sanitize_text_field( $screen_meta['page_title'] . ' [' . $language_code . ']' ),
			)
		);

		if ( $post_id > 0 ) {
			update_post_meta( $post_id, '_asenha_wpml_options_config_id', (int) $screen_meta['config_id'] );
			update_post_meta( $post_id, '_asenha_wpml_language', $language_code );
		}

		return (int) $post_id;
	}

	/**
	 * Get ASE definition post types that should be backfilled.
	 *
	 * @return array<int,string>
	 */
	private function get_definition_post_types_for_backfill() {
		return array(
			'asenha_cfgroup',
			'asenha_cpt',
			'asenha_ctax',
			'options_page_config',
		);
	}

	/**
	 * Backfill packages for one ASE definition post type.
	 *
	 * @param string $post_type ASE definition post type.
	 * @return bool Whether any definition package was repaired.
	 */
	private function backfill_definition_post_type_packages( $post_type ) {
		$definition_ids = get_posts(
			array(
				'post_type'              => $post_type,
				'post_status'            => array( 'publish', 'draft', 'pending', 'future', 'private' ),
				'numberposts'            => -1,
				'fields'                 => 'ids',
				'orderby'                => 'ID',
				'order'                  => 'ASC',
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				'suppress_filters'       => true,
			)
		);

		$repaired_any = false;

		foreach ( $definition_ids as $definition_id ) {
			$post = get_post( $definition_id );
			if ( ! $post instanceof WP_Post ) {
				continue;
			}

			if ( ! $this->definition_needs_package_repair( $post ) ) {
				continue;
			}

			if ( $this->register_definition_strings_for_post_if_ready( $post ) ) {
				$repaired_any = true;
			}
		}

		return $repaired_any;
	}

	/**
	 * Register WPML strings for a definition after ASE meta has been saved.
	 *
	 * @param WP_Post $post ASE definition post.
	 * @return bool
	 */
	public function register_definition_strings_for_post_if_ready( $post ) {
		if ( ! defined( 'WPML_ST_VERSION' ) || ! $post instanceof WP_Post ) {
			return false;
		}

		$post_id = (int) $post->ID;
		if ( $post_id <= 0 ) {
			return false;
		}

		if ( isset( $this->registered_definition_strings_post_ids[ $post_id ] ) ) {
			return false;
		}

		$this->registered_definition_strings_post_ids[ $post_id ] = true;

		return $this->register_definition_strings_for_post( $post );
	}

	/**
	 * Whether a definition's WPML package is missing or has no registered strings.
	 *
	 * @param WP_Post $post ASE definition post.
	 * @return bool
	 */
	private function definition_needs_package_repair( $post ) {
		if ( ! $post instanceof WP_Post ) {
			return false;
		}

		$identity = $this->get_expected_package_identity_for_definition( $post );
		if ( null === $identity ) {
			return false;
		}

		return 0 === $this->get_definition_package_string_count( $identity['kind_slug'], $identity['package_name'] );
	}

	/**
	 * Get the expected WPML package identity for one ASE definition.
	 *
	 * @param WP_Post $post ASE definition post.
	 * @return array{kind_slug:string,package_name:string}|null
	 */
	private function get_expected_package_identity_for_definition( $post ) {
		switch ( $post->post_type ) {
			case 'asenha_cfgroup':
				return array(
					'kind_slug'    => ASENHA_CCT_WPML_Package::KIND_FIELD_GROUP,
					'package_name' => 'cfgroup-' . $post->ID,
				);

			case 'asenha_cpt':
				$slug = get_post_meta( $post->ID, 'cpt_key', true );
				if ( '' === (string) $slug ) {
					return null;
				}

				return array(
					'kind_slug'    => ASENHA_CCT_WPML_Package::KIND_POST_TYPE,
					'package_name' => 'cpt-' . $slug,
				);

			case 'asenha_ctax':
				$slug = get_post_meta( $post->ID, 'ctax_key', true );
				if ( '' === (string) $slug ) {
					return null;
				}

				return array(
					'kind_slug'    => ASENHA_CCT_WPML_Package::KIND_TAXONOMY,
					'package_name' => 'taxonomy-' . $slug,
				);

			case 'options_page_config':
				$slug = get_post_meta( $post->ID, 'options_page_menu_slug', true );
				if ( '' === (string) $slug ) {
					return null;
				}

				return array(
					'kind_slug'    => ASENHA_CCT_WPML_Package::KIND_OPTIONS_PAGE,
					'package_name' => 'options-page-' . $slug,
				);
		}

		return null;
	}

	/**
	 * Count WPML strings currently registered for one package identity.
	 *
	 * @param string $kind_slug    Package kind slug.
	 * @param string $package_name Package name.
	 * @return int
	 */
	private function get_definition_package_string_count( $kind_slug, $package_name ) {
		if ( ! defined( 'WPML_ST_VERSION' ) ) {
			return 0;
		}

		global $wpdb;

		$packages_table = $wpdb->prefix . 'icl_string_packages';
		$strings_table  = $wpdb->prefix . 'icl_strings';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT( s.id )
				FROM {$strings_table} s
				INNER JOIN {$packages_table} p ON p.ID = s.string_package_id
				WHERE p.kind_slug = %s AND p.name = %s",
				$kind_slug,
				$package_name
			)
		);

		return (int) $count;
	}

	/**
	 * Ask WPML to refresh cached package data after a repair batch.
	 *
	 * @return void
	 */
	private function maybe_refresh_wpml_package_cache() {
		if ( ! class_exists( 'WPML_Package_Helper' ) ) {
			return;
		}

		$helper = new WPML_Package_Helper();
		if ( method_exists( $helper, 'refresh_packages' ) ) {
			$helper->refresh_packages();
		}
	}

	/**
	 * Register label strings for a supported ASE definition post.
	 *
	 * @param WP_Post $post ASE definition post.
	 * @return bool
	 */
	private function register_definition_strings_for_post( $post ) {
		switch ( $post->post_type ) {
			case 'asenha_cfgroup':
				return $this->register_field_group_strings_for_definition( $post );

			case 'asenha_cpt':
				return $this->register_post_type_strings_for_definition( $post );

			case 'asenha_ctax':
				return $this->register_taxonomy_strings_for_definition( $post );

			case 'options_page_config':
				return $this->register_options_page_strings_for_definition( $post );
		}

		return false;
	}

	/**
	 * Whether the current admin request should refresh field-group package titles.
	 *
	 * @return bool
	 */
	private function is_wpml_field_group_package_refresh_request() {
		global $pagenow;

		if ( 'edit.php' === $pagenow ) {
			$post_type = isset( $_GET['post_type'] ) ? sanitize_key( wp_unslash( $_GET['post_type'] ) ) : 'post';

			if ( in_array( $post_type, $this->get_definition_post_types_for_backfill(), true ) ) {
				return true;
			}
		}

		$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';

		if ( '' === $page ) {
			return false;
		}

		$translation_dashboard_pages = array(
			'wpml-translation-dashboard',
			'tm/menu/main.php',
		);

		if ( defined( 'WPML_TM_FOLDER' ) ) {
			$translation_dashboard_pages[] = trim( WPML_TM_FOLDER, '/' ) . '/menu/main.php';
		}

		if ( in_array( $page, array_filter( $translation_dashboard_pages ), true ) ) {
			return true;
		}

		// Package Management lives under WPML's String Translation page family.
		return false !== strpos( $page, 'string-translation' );
	}

	/**
	 * Map register_post_type() label keys to ASE definition meta keys.
	 *
	 * @return array<string,string>
	 */
	private function get_post_type_label_runtime_to_meta_map() {
		return array(
			'name'                      => 'cpt_plural_name',
			'singular_name'             => 'cpt_singular_name',
			'add_new'                   => 'cpt_label_add_new',
			'add_new_item'              => 'cpt_label_add_new_item',
			'edit_item'                 => 'cpt_label_edit_item',
			'new_item'                  => 'cpt_label_new_item',
			'view_item'                 => 'cpt_label_view_item',
			'view_items'                => 'cpt_label_view_items',
			'search_items'              => 'cpt_label_search_items',
			'not_found'                 => 'cpt_label_not_found',
			'not_found_in_trash'        => 'cpt_label_not_found_in_trash',
			'parent_item_colon'         => 'cpt_label_parent_item_colon',
			'all_items'                 => 'cpt_label_all_items',
			'archives'                  => 'cpt_label_archives',
			'attributes'                => 'cpt_label_attributes',
			'insert_into_item'          => 'cpt_label_insert_into_item',
			'uploaded_to_this_item'     => 'cpt_label_uploaded_to_this_item',
			'featured_image'            => 'cpt_label_featured_image',
			'set_featured_image'        => 'cpt_label_set_featured_image',
			'remove_featured_image'     => 'cpt_label_remove_featured_image',
			'use_featured_image'        => 'cpt_label_use_featured_image',
			'menu_name'                 => 'cpt_label_menu_name',
			'filter_items_list'         => 'cpt_label_filter_items_list',
			'filter_by_date'            => 'cpt_label_filter_by_date',
			'items_list_navigation'     => 'cpt_label_items_list_navigation',
			'items_list'                => 'cpt_label_items_list',
			'item_published'            => 'cpt_label_item_published',
			'item_published_privately'  => 'cpt_label_item_published_privately',
			'item_reverted_to_draft'    => 'cpt_label_item_reverted_to_draft',
			'item_scheduled'            => 'cpt_label_item_scheduled',
			'item_updated'              => 'cpt_label_item_updated',
			'item_link'                 => 'cpt_label_item_link',
			'item_link_description'     => 'cpt_label_item_link_description',
		);
	}

	/**
	 * Map register_taxonomy() label keys to ASE definition meta keys.
	 *
	 * @return array<string,string>
	 */
	private function get_taxonomy_label_runtime_to_meta_map() {
		return array(
			'name'                       => 'ctax_plural_name',
			'singular_name'              => 'ctax_singular_name',
			'menu_name'                  => 'ctax_plural_name',
			'search_items'               => 'ctax_label_search_items',
			'popular_items'              => 'ctax_label_popular_items',
			'all_items'                  => 'ctax_label_all_items',
			'parent_item'                => 'ctax_label_parent_item',
			'parent_item_colon'          => 'ctax_label_parent_item_colon',
			'name_field_description'     => 'ctax_label_name_field_description',
			'slug_field_description'     => 'ctax_label_slug_field_description',
			'parent_field_description'   => 'ctax_label_parent_field_description',
			'desc_field_description'     => 'ctax_label_desc_field_description',
			'edit_item'                  => 'ctax_label_edit_item',
			'view_item'                  => 'ctax_label_view_item',
			'update_item'                => 'ctax_label_update_item',
			'add_new_item'               => 'ctax_label_add_new_item',
			'new_item_name'              => 'ctax_label_new_item_name',
			'separate_items_with_commas' => 'ctax_label_separate_items_with_commas',
			'add_or_remove_items'        => 'ctax_label_add_or_remove_items',
			'choose_from_most_used'      => 'ctax_label_choose_from_most_used',
			'not_found'                  => 'ctax_label_not_found',
			'no_terms'                   => 'ctax_label_no_terms',
			'filter_by_item'             => 'ctax_label_filter_by_item',
			'items_list_navigation'      => 'ctax_label_items_list_navigation',
			'items_list'                 => 'ctax_label_items_list',
			'most_used'                  => 'ctax_label_most_used',
			'back_to_items'              => 'ctax_label_back_to_items',
			'item_link'                  => 'ctax_label_item_link',
			'item_link_description'      => 'ctax_label_item_link_description',
		);
	}

	/**
	 * Post-type string keys.
	 *
	 * @return array<string,string>
	 */
	private function get_post_type_string_keys() {
		return array(
			'cpt_plural_name'                  => __( 'Plural Name', 'admin-site-enhancements' ),
			'cpt_singular_name'                => __( 'Singular Name', 'admin-site-enhancements' ),
			'cpt_label_add_new'                => __( 'Add New', 'admin-site-enhancements' ),
			'cpt_label_add_new_item'           => __( 'Add New Item', 'admin-site-enhancements' ),
			'cpt_label_edit_item'              => __( 'Edit Item', 'admin-site-enhancements' ),
			'cpt_label_new_item'               => __( 'New Item', 'admin-site-enhancements' ),
			'cpt_label_view_item'              => __( 'View Item', 'admin-site-enhancements' ),
			'cpt_label_view_items'             => __( 'View Items', 'admin-site-enhancements' ),
			'cpt_label_search_items'           => __( 'Search Items', 'admin-site-enhancements' ),
			'cpt_label_not_found'              => __( 'Not Found', 'admin-site-enhancements' ),
			'cpt_label_not_found_in_trash'     => __( 'Not Found In Trash', 'admin-site-enhancements' ),
			'cpt_label_parent_item_colon'      => __( 'Parent Item Colon', 'admin-site-enhancements' ),
			'cpt_label_all_items'              => __( 'All Items', 'admin-site-enhancements' ),
			'cpt_label_archives'               => __( 'Archives', 'admin-site-enhancements' ),
			'cpt_label_attributes'             => __( 'Attributes', 'admin-site-enhancements' ),
			'cpt_label_insert_into_item'       => __( 'Insert Into Item', 'admin-site-enhancements' ),
			'cpt_label_uploaded_to_this_item'  => __( 'Uploaded To This Item', 'admin-site-enhancements' ),
			'cpt_label_featured_image'         => __( 'Featured Image', 'admin-site-enhancements' ),
			'cpt_label_set_featured_image'     => __( 'Set Featured Image', 'admin-site-enhancements' ),
			'cpt_label_remove_featured_image'  => __( 'Remove Featured Image', 'admin-site-enhancements' ),
			'cpt_label_use_featured_image'     => __( 'Use Featured Image', 'admin-site-enhancements' ),
			'cpt_label_menu_name'              => __( 'Menu Name', 'admin-site-enhancements' ),
			'cpt_label_filter_items_list'      => __( 'Filter Items List', 'admin-site-enhancements' ),
			'cpt_label_filter_by_date'         => __( 'Filter By Date', 'admin-site-enhancements' ),
			'cpt_label_items_list_navigation'  => __( 'Items List Navigation', 'admin-site-enhancements' ),
			'cpt_label_items_list'             => __( 'Items List', 'admin-site-enhancements' ),
			'cpt_label_item_published'         => __( 'Item Published', 'admin-site-enhancements' ),
			'cpt_label_item_published_privately' => __( 'Item Published Privately', 'admin-site-enhancements' ),
			'cpt_label_item_reverted_to_draft' => __( 'Item Reverted To Draft', 'admin-site-enhancements' ),
			'cpt_label_item_scheduled'         => __( 'Item Scheduled', 'admin-site-enhancements' ),
			'cpt_label_item_updated'           => __( 'Item Updated', 'admin-site-enhancements' ),
			'cpt_label_item_link'              => __( 'Item Link', 'admin-site-enhancements' ),
			'cpt_label_item_link_description'  => __( 'Item Link Description', 'admin-site-enhancements' ),
		);
	}

	/**
	 * Taxonomy string keys.
	 *
	 * @return array<string,string>
	 */
	private function get_taxonomy_string_keys() {
		return array(
			'ctax_plural_name'                     => __( 'Plural Name', 'admin-site-enhancements' ),
			'ctax_singular_name'                   => __( 'Singular Name', 'admin-site-enhancements' ),
			'ctax_label_search_items'              => __( 'Search Items', 'admin-site-enhancements' ),
			'ctax_label_popular_items'             => __( 'Popular Items', 'admin-site-enhancements' ),
			'ctax_label_all_items'                 => __( 'All Items', 'admin-site-enhancements' ),
			'ctax_label_parent_item'               => __( 'Parent Item', 'admin-site-enhancements' ),
			'ctax_label_parent_item_colon'         => __( 'Parent Item Colon', 'admin-site-enhancements' ),
			'ctax_label_name_field_description'    => __( 'Name Field Description', 'admin-site-enhancements' ),
			'ctax_label_slug_field_description'    => __( 'Slug Field Description', 'admin-site-enhancements' ),
			'ctax_label_parent_field_description'  => __( 'Parent Field Description', 'admin-site-enhancements' ),
			'ctax_label_desc_field_description'    => __( 'Description Field Description', 'admin-site-enhancements' ),
			'ctax_label_edit_item'                 => __( 'Edit Item', 'admin-site-enhancements' ),
			'ctax_label_view_item'                 => __( 'View Item', 'admin-site-enhancements' ),
			'ctax_label_update_item'               => __( 'Update Item', 'admin-site-enhancements' ),
			'ctax_label_add_new_item'              => __( 'Add New Item', 'admin-site-enhancements' ),
			'ctax_label_new_item_name'             => __( 'New Item Name', 'admin-site-enhancements' ),
			'ctax_label_separate_items_with_commas' => __( 'Separate Items With Commas', 'admin-site-enhancements' ),
			'ctax_label_add_or_remove_items'       => __( 'Add Or Remove Items', 'admin-site-enhancements' ),
			'ctax_label_choose_from_most_used'     => __( 'Choose From Most Used', 'admin-site-enhancements' ),
			'ctax_label_not_found'                 => __( 'Not Found', 'admin-site-enhancements' ),
			'ctax_label_no_terms'                  => __( 'No Terms', 'admin-site-enhancements' ),
			'ctax_label_filter_by_item'            => __( 'Filter By Item', 'admin-site-enhancements' ),
			'ctax_label_items_list_navigation'     => __( 'Items List Navigation', 'admin-site-enhancements' ),
			'ctax_label_items_list'                => __( 'Items List', 'admin-site-enhancements' ),
			'ctax_label_most_used'                 => __( 'Most Used', 'admin-site-enhancements' ),
			'ctax_label_back_to_items'             => __( 'Back To Items', 'admin-site-enhancements' ),
			'ctax_label_item_link'                 => __( 'Item Link', 'admin-site-enhancements' ),
			'ctax_label_item_link_description'     => __( 'Item Link Description', 'admin-site-enhancements' ),
		);
	}

	/**
	 * Map options-page screen fields to ASE definition meta keys.
	 *
	 * @return array<string,string>
	 */
	private function get_options_page_label_runtime_to_meta_map() {
		return array(
			'page_title' => 'options_page_title',
			'menu_title' => 'options_page_menu_title',
		);
	}

	/**
	 * Options-page string keys.
	 *
	 * @return array<string,string>
	 */
	private function get_options_page_string_keys() {
		return array(
			'options_page_title'      => __( 'Page Title', 'admin-site-enhancements' ),
			'options_page_menu_title' => __( 'Menu Title', 'admin-site-enhancements' ),
		);
	}
}
