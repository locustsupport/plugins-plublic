<?php

// Manually load TinyMCE as load_assets() registration does not reliably run early enough on term screens.
$wp_scripts = wp_scripts();
$wp_scripts->remove( 'wp-tinymce' );
wp_register_tinymce_scripts( $wp_scripts, true );
wp_enqueue_script( 'wp-tinymce' );

CFG()->form->load_assets();
wp_enqueue_script( 'cfgroup-terms', CFG_URL . '/assets/js/terms.js', [ 'jquery' ], CFG_VERSION ); // Has repeater field add/remove row JS

if ( $term ) {
    $term_id = $term->term_id;
} else {
    $term_id = 0;
}

echo CFG()->form( [
    'object_type'   => 'term',
    'term_id'       => $term_id,
    'field_groups'  => $args['group_id'], // never empty, always identifiable
    'front_end'     => false,
] );
