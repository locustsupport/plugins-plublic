<?php
/**
 * Conditional logic UI for the field group editor.
 *
 * @var object $field Field object.
 * @var array  $cfgroup_cl_siblings Sibling fields that can be rule sources (non-layout, same parent).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$cl = array();
if ( isset( $field->conditional_logic ) && is_array( $field->conditional_logic ) ) {
	$cl = $field->conditional_logic;
}

$cl_enabled = ! empty( $cl['enabled'] );
$groups     = isset( $cl['groups'] ) && is_array( $cl['groups'] ) ? $cl['groups'] : array();

if ( empty( $groups ) ) {
	$groups = array(
		array(
			array(
				'field_id' => '',
				'operator' => '==',
				'value'    => '',
			),
		),
	);
}

$weight       = isset( $field->weight ) ? $field->weight : 0;
$self_field_id = isset( $field->id ) ? (int) $field->id : 0;
$base_name     = 'cfgroup[fields][' . esc_attr( $weight ) . '][conditional_logic]';

?>
<tr class="field_conditional_logic">
	<td>
		<label>
			<?php esc_html_e( 'Conditional Logic', 'admin-site-enhancements' ); ?>
			<div class="cfgroup_tooltip">?
				<div class="tooltip_inner">
					<?php
					echo esc_html(
						__( 'Show this field only when the rules match. This is independent of Placement rules (where the group appears).', 'admin-site-enhancements' )
					);
					?>
				</div>
			</div>
		</label>
	</td>
	<td>
		<label class="cfgroup-cl-enable">
			<input type="checkbox" name="<?php echo esc_attr( $base_name ); ?>[enabled]" value="1" <?php checked( $cl_enabled ); ?> class="cfgroup-cl-toggle" />
			<?php esc_html_e( 'Enable conditional logic', 'admin-site-enhancements' ); ?>
		</label>

		<div class="cfgroup-cl-builder" style="<?php echo $cl_enabled ? '' : 'display:none;'; ?>">
			<p class="cfgroup-cl-intro">
				<?php esc_html_e( 'Show this field if', 'admin-site-enhancements' ); ?>
			</p>
			<?php
			foreach ( $groups as $gi => $and_rules ) :
				if ( ! is_array( $and_rules ) ) {
					continue;
				}
				?>
			<div class="cfgroup-cl-or-group" data-or-index="<?php echo (int) $gi; ?>">
				<?php if ( $gi > 0 ) : ?>
					<div class="cfgroup-cl-or-label"><?php esc_html_e( 'or', 'admin-site-enhancements' ); ?></div>
				<?php endif; ?>
				<div class="cfgroup-cl-and-rules">
					<?php
					foreach ( $and_rules as $ri => $rule ) :
						if ( ! is_array( $rule ) ) {
							continue;
						}
						$r_field_id = isset( $rule['field_id'] ) ? (int) $rule['field_id'] : 0;
						$r_operator = isset( $rule['operator'] ) ? $rule['operator'] : '==';
						$r_value    = isset( $rule['value'] ) ? $rule['value'] : '';
						?>
					<div class="cfgroup-cl-rule" data-and-index="<?php echo (int) $ri; ?>">
						<span class="cfgroup-cl-drag-handle" title="<?php esc_attr_e( 'Reorder rule', 'admin-site-enhancements' ); ?>">
							<span class="screen-reader-text"><?php esc_html_e( 'Reorder rule', 'admin-site-enhancements' ); ?></span>
							<span class="dashicons dashicons-menu" aria-hidden="true"></span>
						</span>
						<div class="cfgroup-cl-rule-inputs">
						<select name="<?php echo esc_attr( $base_name ); ?>[groups][<?php echo (int) $gi; ?>][<?php echo (int) $ri; ?>][field_id]" class="cfgroup-cl-field-id" title="<?php esc_attr_e( 'Field', 'admin-site-enhancements' ); ?>">
							<option value=""><?php esc_html_e( 'Select a field', 'admin-site-enhancements' ); ?></option>
							<?php foreach ( $cfgroup_cl_siblings as $sib ) : ?>
								<?php
								if ( (int) $sib['id'] === $self_field_id ) {
									continue;
								}
								$ops = cfgroup_conditional_logic::operators_for_type( $sib['type'] );
								?>
							<option value="<?php echo esc_attr( $sib['id'] ); ?>" data-field-type="<?php echo esc_attr( $sib['type'] ); ?>" data-operators="<?php echo esc_attr( wp_json_encode( $ops ) ); ?>"
								<?php selected( $r_field_id, (int) $sib['id'] ); ?>>
								<?php echo esc_html( $sib['label'] . ' (' . $sib['name'] . ')' ); ?>
							</option>
							<?php endforeach; ?>
						</select>
						<select name="<?php echo esc_attr( $base_name ); ?>[groups][<?php echo (int) $gi; ?>][<?php echo (int) $ri; ?>][operator]" class="cfgroup-cl-operator">
							<?php
							$dep_type = 'text';
							foreach ( $cfgroup_cl_siblings as $sib ) {
								if ( (int) $sib['id'] === $r_field_id ) {
									$dep_type = $sib['type'];
									break;
								}
							}
							$op_opts = cfgroup_conditional_logic::operators_for_type( $dep_type );
							if ( '' !== $r_operator && ! in_array( $r_operator, $op_opts, true ) ) {
								$op_opts[] = $r_operator;
							}
							foreach ( $op_opts as $op ) :
								$labels = array(
									'empty'                  => __( 'has no value', 'admin-site-enhancements' ),
									'not_empty'              => __( 'has any value', 'admin-site-enhancements' ),
									'=='                     => __( 'is equal to', 'admin-site-enhancements' ),
									'!='                     => __( 'is not equal to', 'admin-site-enhancements' ),
									'contains'               => __( 'contains', 'admin-site-enhancements' ),
									'not_contains'           => __( 'does not contain', 'admin-site-enhancements' ),
									'match'                  => __( 'matches pattern', 'admin-site-enhancements' ),
									'<'                      => __( 'less than', 'admin-site-enhancements' ),
									'<='                     => __( 'less than or equal to', 'admin-site-enhancements' ),
									'>'                      => __( 'greater than', 'admin-site-enhancements' ),
									'>='                     => __( 'greater than or equal to', 'admin-site-enhancements' ),
									'date_before'            => __( 'is before', 'admin-site-enhancements' ),
									'date_before_or_equal'   => __( 'is before or equal to', 'admin-site-enhancements' ),
									'date_between'           => __( 'is between', 'admin-site-enhancements' ),
									'date_after_or_equal'    => __( 'is after or equal to', 'admin-site-enhancements' ),
									'date_after'             => __( 'is after', 'admin-site-enhancements' ),
								);
								if ( 'true_false' === $dep_type && '==' === $op ) {
									$lbl = __( 'is checked', 'admin-site-enhancements' );
								} elseif ( 'true_false' === $dep_type && '!=' === $op ) {
									$lbl = __( 'is not checked', 'admin-site-enhancements' );
								} else {
									$lbl = isset( $labels[ $op ] ) ? $labels[ $op ] : $op;
								}
								?>
							<option value="<?php echo esc_attr( $op ); ?>" <?php selected( $r_operator, $op ); ?>><?php echo esc_html( $lbl ); ?></option>
							<?php endforeach; ?>
						</select>
						<?php if ( 'true_false' === $dep_type ) : ?>
						<div class="cfgroup-cl-value-slot">
						<input type="hidden" name="<?php echo esc_attr( $base_name ); ?>[groups][<?php echo (int) $gi; ?>][<?php echo (int) $ri; ?>][value]" value="1" class="cfgroup-cl-value" />
						</div>
						<?php elseif ( 'date' === $dep_type && 'date_between' === $r_operator ) : ?>
							<?php
							$between_start = '';
							$between_end   = '';
							if ( is_array( $r_value ) ) {
								$between_start = isset( $r_value['start'] ) ? $r_value['start'] : '';
								$between_end   = isset( $r_value['end'] ) ? $r_value['end'] : '';
							}
							?>
						<div class="cfgroup-cl-value-slot">
						<div class="cfgroup-cl-date-range">
						<input type="text" name="<?php echo esc_attr( $base_name ); ?>[groups][<?php echo (int) $gi; ?>][<?php echo (int) $ri; ?>][value][start]" value="<?php echo esc_attr( $between_start ); ?>" class="cfgroup-cl-value cfgroup-cl-date-input" autocomplete="off" />
						<span class="cfgroup-cl-date-range-sep" aria-hidden="true">–</span>
						<input type="text" name="<?php echo esc_attr( $base_name ); ?>[groups][<?php echo (int) $gi; ?>][<?php echo (int) $ri; ?>][value][end]" value="<?php echo esc_attr( $between_end ); ?>" class="cfgroup-cl-value cfgroup-cl-date-input" autocomplete="off" />
						</div>
						</div>
						<?php elseif ( 'datetime' === $dep_type && 'date_between' === $r_operator ) : ?>
							<?php
							$dt_between_start = '';
							$dt_between_end   = '';
							if ( is_array( $r_value ) ) {
								$dt_between_start = isset( $r_value['start'] ) ? $r_value['start'] : '';
								$dt_between_end   = isset( $r_value['end'] ) ? $r_value['end'] : '';
							}
							?>
						<div class="cfgroup-cl-value-slot">
						<div class="cfgroup-cl-date-range">
						<input type="text" name="<?php echo esc_attr( $base_name ); ?>[groups][<?php echo (int) $gi; ?>][<?php echo (int) $ri; ?>][value][start]" value="<?php echo esc_attr( $dt_between_start ); ?>" class="cfgroup-cl-value cfgroup-cl-date-input" autocomplete="off" />
						<span class="cfgroup-cl-date-range-sep" aria-hidden="true">–</span>
						<input type="text" name="<?php echo esc_attr( $base_name ); ?>[groups][<?php echo (int) $gi; ?>][<?php echo (int) $ri; ?>][value][end]" value="<?php echo esc_attr( $dt_between_end ); ?>" class="cfgroup-cl-value cfgroup-cl-date-input" autocomplete="off" />
						</div>
						</div>
						<?php elseif ( 'time' === $dep_type && 'date_between' === $r_operator ) : ?>
							<?php
							$time_between_start = '';
							$time_between_end   = '';
							if ( is_array( $r_value ) ) {
								$time_between_start = isset( $r_value['start'] ) ? $r_value['start'] : '';
								$time_between_end   = isset( $r_value['end'] ) ? $r_value['end'] : '';
							}
							?>
						<div class="cfgroup-cl-value-slot">
						<div class="cfgroup-cl-date-range">
						<input type="text" name="<?php echo esc_attr( $base_name ); ?>[groups][<?php echo (int) $gi; ?>][<?php echo (int) $ri; ?>][value][start]" value="<?php echo esc_attr( $time_between_start ); ?>" class="cfgroup-cl-value cfgroup-cl-date-input" autocomplete="off" />
						<span class="cfgroup-cl-date-range-sep" aria-hidden="true">–</span>
						<input type="text" name="<?php echo esc_attr( $base_name ); ?>[groups][<?php echo (int) $gi; ?>][<?php echo (int) $ri; ?>][value][end]" value="<?php echo esc_attr( $time_between_end ); ?>" class="cfgroup-cl-value cfgroup-cl-date-input" autocomplete="off" />
						</div>
						</div>
						<?php else : ?>
						<div class="cfgroup-cl-value-slot">
						<input type="text" name="<?php echo esc_attr( $base_name ); ?>[groups][<?php echo (int) $gi; ?>][<?php echo (int) $ri; ?>][value]" value="<?php echo esc_attr( is_array( $r_value ) ? '' : $r_value ); ?>" class="cfgroup-cl-value" placeholder="<?php esc_attr_e( 'Value', 'admin-site-enhancements' ); ?>" />
						</div>
						<?php endif; ?>
						</div>
						<div class="cfgroup-cl-rule-actions">
							<span class="cfgroup-cl-and-label"><?php esc_html_e( 'and', 'admin-site-enhancements' ); ?></span>
							<button type="button" class="button cfgroup-cl-add-rule-btn" aria-label="<?php esc_attr_e( 'Add rule', 'admin-site-enhancements' ); ?>">
								<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
							</button>
							<button type="button" class="button cfgroup-cl-remove-rule-btn" aria-label="<?php esc_attr_e( 'Remove rule', 'admin-site-enhancements' ); ?>">
								<span class="dashicons dashicons-minus" aria-hidden="true"></span>
							</button>
						</div>
					</div>
						<?php endforeach; ?>
				</div>
			</div>
				<?php endforeach; ?>
			<p class="cfgroup-cl-add-or-wrap">
				<button type="button" class="button cfgroup-cl-add-or"><?php esc_html_e( 'Add rule group', 'admin-site-enhancements' ); ?></button>
			</p>
		</div>
	</td>
</tr>
