<div class="field">
    <div class="field_meta">
        <table class="widefat">
            <tr>
                <td class="field_order">

                </td>
                <td class="field_label">
                    <a class="cfgroup_edit_field row-title"><?php echo esc_html( $field->label ); ?></a>
                    <?php if ( in_array( $field->type, array( 'tab', 'heading', 'line_break' ) ) ) : ?>
                        <span class="field-type-flag"><?php echo esc_html( $field->type ); ?></span>
                    <?php endif; ?>
                </td>
                <td class="field_name">
                    <?php echo esc_html( $field->name ); ?>
                </td>
                <td class="field_type">
                    <?php 
                    if ( $field->type == 'file' ) {
                        $file_type = $field->options['file_type'];
                        if ( 'file' == $file_type ) {
                            $file_type = 'any';
                        }
                        echo esc_html( $field->type . ' (' . $file_type . ')' );
                    } elseif ( $field->type == 'text' ) {
                        $text_type = isset( $field->options['text_type'] ) ? $field->options['text_type'] : 'any';
                        echo esc_html( $field->type . ' (' . $text_type . ')' );
                    } else {
                        echo esc_html( $field->type );                        
                    }
                    ?>
                </td>
                <td class="field_width">
                    <?php echo esc_html( cfgroup_get_column_width_column_label( $field->column_width ) ); ?>
                </td>
                <td class="field_toggle">
                    <a class="cfgroup_edit_field"><svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 256 256"><path fill="currentColor" d="m216.49 104.49l-80 80a12 12 0 0 1-17 0l-80-80a12 12 0 0 1 17-17L128 159l71.51-71.52a12 12 0 0 1 17 17Z"/></svg></a>
                </td>
            </tr>
        </table>
    </div>

    <div class="field_form">
        <table class="widefat">
            <tbody>
                <tr class="field_basics">
                    <td colspan="2">
                        <table>
                            <tr>
                                <td class="field_label">
                                    <label>
                                        <?php _e( 'Field Label', 'admin-site-enhancements' ); ?>
                                        <div class="cfgroup_tooltip">?
                                            <div class="tooltip_inner"><?php _e( 'The field label that editors will see.', 'admin-site-enhancements' ); ?></div>
                                        </div>
                                    </label>
                                    <input type="text" name="cfgroup[fields][<?php echo esc_attr( $field->weight ); ?>][label]" value="<?php echo empty( $field->id ) ? '' : esc_attr( $field->label ); ?>" />
                                </td>
                                <td class="field_name">
                                    <label>
                                        <?php _e( 'Field Name', 'admin-site-enhancements' ); ?>
                                        <div class="cfgroup_tooltip">?
                                            <div class="tooltip_inner">
                                                <?php _e( 'The field name is passed into get_cf() to retrieve values. Use only lowercase letters, numbers, and underscores.', 'admin-site-enhancements' ); ?>
                                            </div>
                                        </div>
                                    </label>
                                    <input type="text" name="cfgroup[fields][<?php echo esc_attr( $field->weight ); ?>][name]" value="<?php echo empty( $field->id ) ? '' : esc_attr( $field->name ); ?>" />
                                </td>
                                <td class="field_type">
                                    <label><?php _e( 'Field Type', 'admin-site-enhancements' ); ?></label>
                                    <?php
                                        $content_fields = array( 'text', 'textarea', 'wysiwyg', 'file', 'gallery' );
                                        $choice_fields = array( 'true_false', 'radio', 'select', 'checkbox' );
                                        $extra_fields = array( 'hyperlink', 'number', 'date', 'time', 'datetime', 'color', 'map' );
                                        $relational_fields = array( 'relationship', 'term', 'user' );
                                        $special_fields = array( 'repeater' );
                                        $layout_fields = array( 'tab', 'heading', 'line_break' );
                                    ?>
                                    <select name="cfgroup[fields][<?php echo esc_attr( $field->weight ); ?>][type]">
                                        <optgroup label="Content">
                                            <?php foreach ( CFG()->fields as $type ) : ?>
                                            <?php $selected = ($type->name == $field->type) ? ' selected' : ''; ?>
                                            <?php if ( in_array( $type->name, $content_fields ) ) { ?>
                                            <option value="<?php echo esc_attr( $type->name ); ?>"<?php echo $selected; ?>><?php echo esc_html( $type->label ); ?></option>
                                            <?php } ?>
                                            <?php endforeach; ?>
                                        <optgroup>
                                        <optgroup label="Choice">
                                            <?php foreach ( CFG()->fields as $type ) : ?>
                                            <?php $selected = ($type->name == $field->type) ? ' selected' : ''; ?>
                                            <?php if ( in_array( $type->name, $choice_fields ) ) { ?>
                                            <option value="<?php echo esc_attr( $type->name ); ?>"<?php echo $selected; ?>><?php echo esc_html( $type->label ); ?></option>
                                            <?php } ?>
                                            <?php endforeach; ?>
                                        <optgroup>
                                        <optgroup label="Extra">
                                            <?php foreach ( CFG()->fields as $type ) : ?>
                                            <?php $selected = ($type->name == $field->type) ? ' selected' : ''; ?>
                                            <?php if ( in_array( $type->name, $extra_fields ) ) { ?>
                                            <option value="<?php echo esc_attr( $type->name ); ?>"<?php echo $selected; ?>><?php echo esc_html( $type->label ); ?></option>
                                            <?php } ?>
                                            <?php endforeach; ?>
                                        <optgroup>
                                        <optgroup label="Relational">
                                            <?php foreach ( CFG()->fields as $type ) : ?>
                                            <?php $selected = ($type->name == $field->type) ? ' selected' : ''; ?>
                                            <?php if ( in_array( $type->name, $relational_fields ) ) { ?>
                                            <option value="<?php echo esc_attr( $type->name ); ?>"<?php echo $selected; ?>><?php echo esc_html( $type->label ); ?></option>
                                            <?php } ?>
                                            <?php endforeach; ?>
                                        <optgroup>
                                        <optgroup label="Special">
                                            <?php foreach ( CFG()->fields as $type ) : ?>
                                            <?php $selected = ($type->name == $field->type) ? ' selected' : ''; ?>
                                            <?php if ( in_array( $type->name, $special_fields ) ) { ?>
                                            <option value="<?php echo esc_attr( $type->name ); ?>"<?php echo $selected; ?>><?php echo esc_html( $type->label ); ?></option>
                                            <?php } ?>
                                            <?php endforeach; ?>
                                        <optgroup>
                                        <optgroup label="Layout">
                                            <?php foreach ( CFG()->fields as $type ) : ?>
                                            <?php $selected = ($type->name == $field->type) ? ' selected' : ''; ?>
                                            <?php if ( in_array( $type->name, $layout_fields ) ) { ?>
                                            <option value="<?php echo esc_attr( $type->name ); ?>"<?php echo $selected; ?>><?php echo esc_html( $type->label ); ?></option>
                                            <?php } ?>
                                            <?php endforeach; ?>
                                        <optgroup>
                                    </select>
                                </td>
                                <td class="field_column_width">
                                    <label>
                                        <?php _e( 'Column Width', 'admin-site-enhancements' ); ?>
                                        <div class="cfgroup_tooltip">?
                                            <div class="tooltip_inner"><?php _e( 'Set column width to allow for more than one field in a row. For example: Three "third" fields will be shown in a single row. ' ); ?></div>
                                        </div>
                                    </label>
                                    <select name="cfgroup[fields][<?php echo esc_attr( $field->weight ); ?>][column_width]">
                                        <?php foreach ( cfgroup_get_column_width_choices() as $column_width_slug => $column_width_labels ) : ?>
                                            <option value="<?php echo esc_attr( $column_width_slug ); ?>" data-column-label="<?php echo esc_attr( $column_width_labels['column'] ); ?>" <?php selected( $field->column_width, $column_width_slug ); ?>>
                                                <?php echo esc_html( $column_width_labels['dropdown'] ); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

                <?php CFG()->fields[ $field->type ]->options_html( $field->weight, $field ); ?>

                <tr class="field_notes">
                    <td class="label">
                        <label>
                            <?php _e( 'Instructions', 'admin-site-enhancements' ); ?>
                            <div class="cfgroup_tooltip">?
                                <div class="tooltip_inner"><?php _e( 'Instructions for editors. Shown when submitting data.', 'admin-site-enhancements' ); ?></div>
                            </div>
                        </label>
                    </td>
                    <td>
                        <?php if ( user_can_richedit() ) : ?>
                        <div class="cfg-field-notes-editor cfg-field-notes-pending">
                            <textarea
                                <?php if ( 'clone' !== $field->weight ) : ?>
                                id="cfgnotes_<?php echo esc_attr( $field->weight ); ?>"
                                <?php endif; ?>
                                name="cfgroup[fields][<?php echo esc_attr( $field->weight ); ?>][notes]"
                                class="cfg-field-notes-textarea"
                                rows="4"
                            ><?php echo esc_textarea( $field->notes ); ?></textarea>
                        </div>
                        <?php else : ?>
                        <textarea name="cfgroup[fields][<?php echo esc_attr( $field->weight ); ?>][notes]" rows="4"><?php echo esc_textarea( $field->notes ); ?></textarea>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php
                $cfgroup_cl_siblings = array();
                global $post;
                if ( isset( $post ) && is_object( $post ) && 'asenha_cfgroup' === get_post_type( $post->ID ) ) {
                    $cfgroup_all = CFG()->api->find_input_fields( array( 'group_id' => $post->ID ) );
                    foreach ( $cfgroup_all as $row ) {
                        $row = (array) $row;
                        if ( (int) $row['parent_id'] !== (int) $field->parent_id ) {
                            continue;
                        }
                        if ( cfgroup_conditional_logic::is_layout_type( $row['type'] ) ) {
                            continue;
                        }
                        if ( (int) $row['id'] === (int) $field->id ) {
                            continue;
                        }
                        $cfgroup_cl_siblings[] = array(
                            'id'    => (int) $row['id'],
                            'name'  => $row['name'],
                            'label' => isset( $row['label'] ) ? $row['label'] : '',
                            'type'  => $row['type'],
                        );
                    }
                }
                require CFG_DIR . '/templates/field_conditional_logic.php';

                $cfgroup_qe_supported_types = class_exists( 'cfgroup_quick_edit' )
                    ? cfgroup_quick_edit::supported_types()
                    : array( 'text', 'textarea', 'number', 'true_false', 'select', 'radio', 'checkbox', 'date', 'time', 'datetime', 'color', 'hyperlink', 'wysiwyg', 'file', 'gallery', 'relationship', 'term', 'user' );
                $cfgroup_qe_show_row = ( 0 === (int) $field->parent_id )
                    && in_array( $field->type, $cfgroup_qe_supported_types, true );
                $cfgroup_qe_value = 0;
                if ( isset( $field->options['show_in_quick_edit'] ) ) {
                    $cfgroup_qe_value = (int) (bool) $field->options['show_in_quick_edit'];
                }
                ?>
                <tr class="field_show_in_quick_edit asenha-cfgroup-quick-edit-setting"<?php echo $cfgroup_qe_show_row ? '' : ' style="display:none;"'; ?> data-cfgroup-qe-supported="<?php echo $cfgroup_qe_show_row ? '1' : '0'; ?>">
                    <td>
                        <label>
                            <?php esc_html_e( 'Quick Edit', 'admin-site-enhancements' ); ?>
                            <div class="cfgroup_tooltip">?
                                <div class="tooltip_inner"><?php esc_html_e( 'Show this field in the post list Quick Edit panel for matching post types.', 'admin-site-enhancements' ); ?></div>
                            </div>
                        </label>
                    </td>
                    <td>
                        <?php
                        CFG()->create_field( [
                            'type'        => 'true_false',
                            'input_name'  => 'cfgroup[fields][' . $field->weight . '][options][show_in_quick_edit]',
                            'input_class' => 'true_false',
                            'value'       => $cfgroup_qe_value,
                            'options'     => [
                                'message' => __( 'Include this field in Quick Edit', 'admin-site-enhancements' ),
                            ],
                        ] );
                        ?>
                    </td>
                </tr>
                <?php
                $cfgroup_be_supported_types = class_exists( 'cfgroup_bulk_edit' )
                    ? cfgroup_bulk_edit::supported_types()
                    : array( 'text', 'textarea', 'number', 'true_false', 'select', 'radio', 'checkbox', 'date', 'time', 'datetime', 'color', 'hyperlink', 'file', 'gallery', 'wysiwyg', 'relationship', 'term', 'user' );
                $cfgroup_be_show_row = ( 0 === (int) $field->parent_id )
                    && in_array( $field->type, $cfgroup_be_supported_types, true );
                $cfgroup_be_value = 0;
                if ( isset( $field->options['show_in_bulk_edit'] ) ) {
                    $cfgroup_be_value = (int) (bool) $field->options['show_in_bulk_edit'];
                }
                ?>
                <tr class="field_show_in_bulk_edit asenha-cfgroup-bulk-edit-setting"<?php echo $cfgroup_be_show_row ? '' : ' style="display:none;"'; ?> data-cfgroup-be-supported="<?php echo $cfgroup_be_show_row ? '1' : '0'; ?>">
                    <td>
                        <label>
                            <?php esc_html_e( 'Bulk Edit', 'admin-site-enhancements' ); ?>
                            <div class="cfgroup_tooltip">?
                                <div class="tooltip_inner"><?php esc_html_e( 'Show this field in the post list Bulk Edit panel for matching post types. Blank or “No Change” leaves existing values untouched.', 'admin-site-enhancements' ); ?></div>
                            </div>
                        </label>
                    </td>
                    <td>
                        <?php
                        CFG()->create_field( [
                            'type'        => 'true_false',
                            'input_name'  => 'cfgroup[fields][' . $field->weight . '][options][show_in_bulk_edit]',
                            'input_class' => 'true_false',
                            'value'       => $cfgroup_be_value,
                            'options'     => [
                                'message' => __( 'Include this field in Bulk Edit', 'admin-site-enhancements' ),
                            ],
                        ] );
                        ?>
                    </td>
                </tr>
                <?php
                do_action( 'asenha_cfgroup_field_settings_rows', $field );
                ?>
                <tr class="field_actions">
                    <td class="label"></td>
                    <td style="vertical-align:middle">
                        <input type="hidden" name="cfgroup[fields][<?php echo esc_attr( $field->weight ); ?>][id]" class="field_id" value="<?php echo esc_attr( $field->id ); ?>" />
                        <input type="hidden" name="cfgroup[fields][<?php echo esc_attr( $field->weight ); ?>][parent_id]" class="parent_id" value="<?php echo esc_attr( $field->parent_id ); ?>" />
                        <span class="cfgroup_delete_field"><?php _e( 'Delete', 'admin-site-enhancements' ); ?></span><input type="button" value="<?php _e( 'Close', 'admin-site-enhancements' ); ?>" class="button-secondary cfgroup_edit_field" />
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>