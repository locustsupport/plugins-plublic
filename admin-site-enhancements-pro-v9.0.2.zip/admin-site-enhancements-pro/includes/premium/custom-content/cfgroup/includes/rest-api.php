<?php
/**
 * Expose ASE custom fields in the WordPress REST API as an `ase` object on post and term responses (GET)
 * and allow updates via the same key on editable requests (e.g. POST to the single post/term route).
 *
 * @package Admin and Site Enhancements
 */

/**
 * Registers REST fields and helpers for post types and taxonomies that support the REST API.
 */
class cfgroup_rest_api {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_rest_fields' ), 20 );
	}

	/**
	 * Register the `ase` field for each REST-enabled post type and taxonomy.
	 */
	public function register_rest_fields() {
		$field_args = $this->get_rest_field_ase_schema();

		$post_types = get_post_types(
			array(
				'show_in_rest' => true,
			),
			'names'
		);

		foreach ( $post_types as $post_type ) {
			register_rest_field(
				$post_type,
				'ase',
				array(
					'schema'          => $field_args,
					'get_callback'    => array( $this, 'get_rest_field_ase' ),
					'update_callback' => array( $this, 'update_rest_field_ase' ),
				)
			);
		}

		$taxonomies = get_taxonomies(
			array(
				'show_in_rest' => true,
			),
			'names'
		);

		foreach ( $taxonomies as $taxonomy ) {
			register_rest_field(
				$taxonomy,
				'ase',
				array(
					'schema'          => $field_args,
					'get_callback'    => array( $this, 'get_rest_field_ase_for_term' ),
					'update_callback' => array( $this, 'update_rest_field_ase_for_term' ),
				)
			);
		}
	}

	/**
	 * Schema for the `ase` REST field.
	 *
	 * @return array
	 */
	protected function get_rest_field_ase_schema() {
		return array(
			'description'          => __( 'Admin and Site Enhancements custom fields (raw values).', 'admin-site-enhancements' ),
			'type'                 => 'object',
			'context'              => array( 'view', 'edit' ),
			'additionalProperties' => true,
		);
	}

	/**
	 * Return `ase` data for the REST response, or null when not exposed.
	 *
	 * @param array|WP_Post $object      Post object or prepared post data.
	 * @param string        $field_name  Field name.
	 * @param WP_REST_Request $request   Request.
	 * @param string        $object_type Object type (post type slug).
	 * @return array|null
	 */
	public function get_rest_field_ase( $object, $field_name, $request, $object_type ) {
		unset( $field_name, $request, $object_type );

		$post_id = $this->get_post_id_from_rest_object( $object );
		if ( $post_id <= 0 ) {
			return null;
		}

		if ( ! $this->should_expose_ase_for_post( $post_id ) ) {
			return null;
		}

		if ( ! function_exists( 'get_cf' ) ) {
			return null;
		}

		$data = get_cf( false, 'raw', $post_id );

		/**
		 * Filter raw custom field values before they are added to the REST response under `ase`.
		 *
		 * @since 8.7.0
		 *
		 * @param array|mixed $data    Value from get_cf( false, 'raw', $post_id ).
		 * @param int         $post_id Post ID.
		 */
		return apply_filters( 'asenha_cfgroup_rest_ase_data', $data, $post_id );
	}

	/**
	 * Return `ase` data for a taxonomy term REST response, or null when not exposed.
	 *
	 * @since 8.7.0
	 *
	 * @param array|WP_Term $object      Term object or prepared term data.
	 * @param string        $field_name  Field name.
	 * @param WP_REST_Request $request   Request.
	 * @param string        $object_type Taxonomy slug.
	 * @return array|null
	 */
	public function get_rest_field_ase_for_term( $object, $field_name, $request, $object_type ) {
		unset( $field_name, $request, $object_type );

		$term = $this->get_term_from_rest_object( $object );
		if ( empty( $term['term_id'] ) || empty( $term['taxonomy'] ) ) {
			return null;
		}

		$term_id      = (int) $term['term_id'];
		$taxonomy     = $term['taxonomy'];
		$cf_object_id = $taxonomy . '_' . $term_id;

		if ( ! $this->should_expose_ase_for_term( $term_id, $taxonomy ) ) {
			return null;
		}

		if ( ! function_exists( 'get_cf' ) ) {
			return null;
		}

		$data = get_cf( false, 'raw', $cf_object_id );

		if ( ! is_array( $data ) ) {
			$data = array();
		}

		/**
		 * Filter raw custom field values before they are added to the REST term response under `ase`.
		 *
		 * @since 8.7.0
		 *
		 * @param array|mixed $data         Value from get_cf( false, 'raw', $cf_object_id ).
		 * @param int         $term_id      Term ID.
		 * @param string      $taxonomy     Taxonomy slug.
		 * @param string      $cf_object_id CFG object ID, e.g. genre_84.
		 */
		return apply_filters( 'asenha_cfgroup_rest_ase_term_data', $data, $term_id, $taxonomy, $cf_object_id );
	}

	/**
	 * Update `ase` from the REST request body via update_cf().
	 *
	 * @param mixed           $value   Decoded `ase` value from the request.
	 * @param WP_Post|array $object  Post object.
	 * @param string          $field_name Field name.
	 * @param WP_REST_Request $request    Request.
	 * @param string          $object_type Object type.
	 * @return bool|WP_Error
	 */
	public function update_rest_field_ase( $value, $object, $field_name, $request, $object_type ) {
		unset( $field_name, $request, $object_type );

		$post_id = $this->get_post_id_from_rest_object( $object );
		if ( $post_id <= 0 ) {
			return new WP_Error(
				'rest_invalid_post',
				__( 'Invalid post for ASE field update.', 'admin-site-enhancements' ),
				array( 'status' => 400 )
			);
		}

		if ( ! $this->should_expose_ase_for_post( $post_id ) ) {
			return new WP_Error(
				'rest_cannot_edit',
				__( 'ASE custom fields are not enabled for REST on this post.', 'admin-site-enhancements' ),
				array( 'status' => 403 )
			);
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new WP_Error(
				'rest_cannot_edit',
				__( 'Sorry, you are not allowed to edit this post.', 'admin-site-enhancements' ),
				array( 'status' => 403 )
			);
		}

		if ( null === $value ) {
			return true;
		}

		$fields = $this->validate_ase_rest_payload( $value );
		if ( is_wp_error( $fields ) ) {
			return $fields;
		}

		if ( empty( $fields ) ) {
			return true;
		}

		if ( ! function_exists( 'get_cf_info' ) || ! function_exists( 'update_cf' ) ) {
			return new WP_Error(
				'rest_ase_unavailable',
				__( 'ASE custom fields API is not available.', 'admin-site-enhancements' ),
				array( 'status' => 500 )
			);
		}

		$all_cf_info = get_cf_info( false, $post_id );
		if ( ! is_array( $all_cf_info ) || empty( $all_cf_info ) ) {
			return new WP_Error(
				'rest_invalid_param',
				__( 'No ASE custom fields are defined for this post.', 'admin-site-enhancements' ),
				array( 'status' => 400 )
			);
		}

		$filtered = $this->filter_ase_rest_fields_by_allowlist( $fields, $all_cf_info );
		if ( is_wp_error( $filtered ) ) {
			return $filtered;
		}

		/**
		 * Filter ASE field values from a REST request before they are passed to update_cf().
		 *
		 * @since 8.7.0
		 *
		 * @param array $filtered Associative array of field_name => value.
		 * @param int   $post_id  Post ID.
		 */
		$filtered = apply_filters( 'asenha_cfgroup_rest_ase_update_data', $filtered, $post_id );

		if ( ! is_array( $filtered ) || empty( $filtered ) ) {
			return true;
		}

		update_cf( $post_id, $filtered );

		return true;
	}

	/**
	 * Update `ase` on a taxonomy term from the REST request body via update_cf().
	 *
	 * @since 8.7.0
	 *
	 * @param mixed           $value   Decoded `ase` value from the request.
	 * @param WP_Term|array   $object  Term object.
	 * @param string          $field_name Field name.
	 * @param WP_REST_Request $request    Request.
	 * @param string          $object_type Taxonomy slug.
	 * @return bool|WP_Error
	 */
	public function update_rest_field_ase_for_term( $value, $object, $field_name, $request, $object_type ) {
		unset( $field_name, $request, $object_type );

		$term = $this->get_term_from_rest_object( $object );
		if ( empty( $term['term_id'] ) || empty( $term['taxonomy'] ) ) {
			return new WP_Error(
				'rest_invalid_term',
				__( 'Invalid term for ASE field update.', 'admin-site-enhancements' ),
				array( 'status' => 400 )
			);
		}

		$term_id      = (int) $term['term_id'];
		$taxonomy     = $term['taxonomy'];
		$cf_object_id = $taxonomy . '_' . $term_id;

		if ( ! $this->should_expose_ase_for_term( $term_id, $taxonomy ) ) {
			return new WP_Error(
				'rest_cannot_edit',
				__( 'ASE custom fields are not enabled for REST on this term.', 'admin-site-enhancements' ),
				array( 'status' => 403 )
			);
		}

		if ( ! current_user_can( 'edit_term', $term_id ) ) {
			return new WP_Error(
				'rest_cannot_edit',
				__( 'Sorry, you are not allowed to edit this term.', 'admin-site-enhancements' ),
				array( 'status' => 403 )
			);
		}

		if ( null === $value ) {
			return true;
		}

		$fields = $this->validate_ase_rest_payload( $value );
		if ( is_wp_error( $fields ) ) {
			return $fields;
		}

		if ( empty( $fields ) ) {
			return true;
		}

		if ( ! function_exists( 'get_cf_info_for_term' ) || ! function_exists( 'update_cf' ) ) {
			return new WP_Error(
				'rest_ase_unavailable',
				__( 'ASE custom fields API is not available.', 'admin-site-enhancements' ),
				array( 'status' => 500 )
			);
		}

		$all_cf_info = get_cf_info_for_term( $term_id );
		if ( ! is_array( $all_cf_info ) || empty( $all_cf_info ) ) {
			return new WP_Error(
				'rest_invalid_param',
				__( 'No ASE custom fields are defined for this term.', 'admin-site-enhancements' ),
				array( 'status' => 400 )
			);
		}

		$filtered = $this->filter_ase_rest_fields_by_allowlist( $fields, $all_cf_info );
		if ( is_wp_error( $filtered ) ) {
			return $filtered;
		}

		/**
		 * Filter ASE field values from a REST term request before they are passed to update_cf().
		 *
		 * @since 8.7.0
		 *
		 * @param array  $filtered     Associative array of field_name => value.
		 * @param int    $term_id      Term ID.
		 * @param string $taxonomy     Taxonomy slug.
		 * @param string $cf_object_id CFG object ID, e.g. genre_84.
		 */
		$filtered = apply_filters( 'asenha_cfgroup_rest_ase_term_update_data', $filtered, $term_id, $taxonomy, $cf_object_id );

		if ( ! is_array( $filtered ) || empty( $filtered ) ) {
			return true;
		}

		$result = update_cf( $cf_object_id, $filtered );

		if ( false === $result ) {
			return new WP_Error(
				'rest_ase_update_failed',
				__( 'ASE custom fields could not be updated for this term.', 'admin-site-enhancements' ),
				array( 'status' => 500 )
			);
		}

		return true;
	}

	/**
	 * Validate and normalize the `ase` payload from a REST request.
	 *
	 * @since 8.7.0
	 *
	 * @param mixed $value Decoded `ase` value.
	 * @return array|WP_Error Associative array of fields, empty array, or error.
	 */
	protected function validate_ase_rest_payload( $value ) {
		if ( is_bool( $value ) || is_string( $value ) || is_numeric( $value ) ) {
			return new WP_Error(
				'rest_invalid_param',
				__( 'The ase parameter must be an object.', 'admin-site-enhancements' ),
				array( 'status' => 400 )
			);
		}

		if ( is_object( $value ) ) {
			$value = json_decode( wp_json_encode( $value ), true );
		}

		if ( ! is_array( $value ) ) {
			return new WP_Error(
				'rest_invalid_param',
				__( 'The ase parameter must be an object.', 'admin-site-enhancements' ),
				array( 'status' => 400 )
			);
		}

		return $value;
	}

	/**
	 * Filter REST `ase` keys to the allowlisted field names.
	 *
	 * @since 8.7.0
	 *
	 * @param array $fields      Request field values.
	 * @param array $all_cf_info Allowed field info map.
	 * @return array|WP_Error
	 */
	protected function filter_ase_rest_fields_by_allowlist( $fields, $all_cf_info ) {
		$allowed_keys = array_keys( $all_cf_info );
		$invalid_keys = array_diff( array_keys( $fields ), $allowed_keys );

		if ( ! empty( $invalid_keys ) ) {
			return new WP_Error(
				'rest_invalid_param',
				sprintf(
					/* translators: %s: comma-separated list of invalid field keys */
					__( 'Invalid ASE field key(s): %s', 'admin-site-enhancements' ),
					implode( ', ', array_map( 'sanitize_text_field', $invalid_keys ) )
				),
				array(
					'status' => 400,
					'params' => array(
						'ase' => $invalid_keys,
					),
				)
			);
		}

		$filtered = array();
		foreach ( $fields as $key => $field_value ) {
			if ( in_array( $key, $allowed_keys, true ) ) {
				$filtered[ $key ] = $field_value;
			}
		}

		return $filtered;
	}

	/**
	 * Resolve post ID from a REST field object (WP_Post or prepared array).
	 *
	 * @param array|WP_Post $object Post object or array.
	 * @return int
	 */
	protected function get_post_id_from_rest_object( $object ) {
		if ( $object instanceof WP_Post ) {
			return (int) $object->ID;
		}
		if ( is_array( $object ) && isset( $object['id'] ) ) {
			return (int) $object['id'];
		}
		return 0;
	}

	/**
	 * Resolve term ID and taxonomy from a REST field object.
	 *
	 * @since 8.7.0
	 *
	 * @param array|WP_Term $object Term object or array.
	 * @return array Keys term_id (int), taxonomy (string).
	 */
	protected function get_term_from_rest_object( $object ) {
		if ( $object instanceof WP_Term ) {
			return array(
				'term_id'  => (int) $object->term_id,
				'taxonomy' => $object->taxonomy,
			);
		}

		if ( is_array( $object ) ) {
			$term_id  = isset( $object['id'] ) ? (int) $object['id'] : 0;
			$taxonomy = '';

			if ( isset( $object['taxonomy'] ) ) {
				$taxonomy = $object['taxonomy'];
			} elseif ( ! empty( $object['meta']['taxonomy'] ) ) {
				$taxonomy = $object['meta']['taxonomy'];
			}

			return array(
				'term_id'  => $term_id,
				'taxonomy' => sanitize_key( $taxonomy ),
			);
		}

		return array(
			'term_id'  => 0,
			'taxonomy' => '',
		);
	}

	/**
	 * Whether the `ase` key should be included for this post.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	public function should_expose_ase_for_post( $post_id ) {
		if ( $post_id <= 0 || ! CFG()->api || ! CFG()->field_group ) {
			return false;
		}

		$matching = CFG()->api->get_matching_groups( $post_id, true );

		if ( empty( $matching ) || ! is_array( $matching ) ) {
			return false;
		}

		foreach ( array_keys( $matching ) as $group_id ) {
			$group_id = (int) $group_id;
			if ( $group_id <= 0 ) {
				continue;
			}

			$rules = get_post_meta( $group_id, 'cfgroup_rules', true );
			if ( ! is_array( $rules ) || empty( $rules['placement'] ) ) {
				continue;
			}

			$placement = isset( $rules['placement']['values'] ) ? $rules['placement']['values'] : '';
			if ( 'posts' !== $placement ) {
				continue;
			}

			$extras = get_post_meta( $group_id, 'cfgroup_extras', true );
			if ( is_array( $extras ) && ! empty( $extras['show_in_rest_api'] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether the `ase` key should be included for this taxonomy term.
	 *
	 * @since 8.7.0
	 *
	 * @param int    $term_id  Term ID.
	 * @param string $taxonomy Taxonomy slug.
	 * @return bool
	 */
	public function should_expose_ase_for_term( $term_id, $taxonomy ) {
		$term_id  = (int) $term_id;
		$taxonomy = sanitize_key( $taxonomy );

		if ( $term_id <= 0 || empty( $taxonomy ) || ! CFG()->api || ! CFG()->field_group ) {
			return false;
		}

		$matching_group_ids = CFG()->api->get_matching_groups_for_taxonomy( $taxonomy );

		if ( empty( $matching_group_ids ) || ! is_array( $matching_group_ids ) ) {
			return false;
		}

		foreach ( $matching_group_ids as $group_id ) {
			$group_id = (int) $group_id;
			if ( $group_id <= 0 ) {
				continue;
			}

			$rules = get_post_meta( $group_id, 'cfgroup_rules', true );
			if ( ! is_array( $rules ) || empty( $rules['placement'] ) ) {
				continue;
			}

			$placement = isset( $rules['placement']['values'] ) ? $rules['placement']['values'] : '';
			if ( 'taxonomy-terms' !== $placement ) {
				continue;
			}

			$extras = get_post_meta( $group_id, 'cfgroup_extras', true );
			if ( is_array( $extras ) && ! empty( $extras['show_in_rest_api'] ) ) {
				return true;
			}
		}

		return false;
	}
}

new cfgroup_rest_api();
