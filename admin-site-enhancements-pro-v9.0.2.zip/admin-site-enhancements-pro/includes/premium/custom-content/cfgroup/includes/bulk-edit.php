<?php
/**
 * Custom Field Groups — Bulk Edit support.
 *
 * @since 8.9.1
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Class cfgroup_bulk_edit
 *
 * Registers a hidden list-table column, renders Bulk Edit fields grouped by
 * field group (with “No Change” defaults), and saves through the CFG API.
 */
class cfgroup_bulk_edit {

	/**
	 * List-table / Bulk Edit column key.
	 *
	 * @var string
	 */
	const COLUMN_KEY = 'asenha_cfgroup_be';

	/**
	 * POST field name prefix for values.
	 *
	 * @var string
	 */
	const INPUT_NAME = 'asenha_cfgroup_be';

	/**
	 * POST field name prefix for multi-choice mode (No Change / Replace).
	 *
	 * @var string
	 */
	const MODE_NAME = 'asenha_cfgroup_be_mode';

	/**
	 * Sentinel value meaning “do not change this field”.
	 *
	 * @var string
	 */
	const NO_CHANGE = '-1';

	/**
	 * Cached map of post_type => structured BE field data for the request.
	 *
	 * @var array|null
	 */
	private $post_type_fields_cache = null;

	/**
	 * Whether the Bulk Edit custom box was already printed for a post type.
	 *
	 * @var array
	 */
	private $printed_boxes = array();

	/**
	 * Constructor — register hooks.
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'register_list_table_hooks' ) );
		add_action( 'bulk_edit_custom_box', array( $this, 'render_bulk_edit_box' ), 10, 2 );
		add_action( 'bulk_edit_posts', array( $this, 'save_bulk_edit' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_filter( 'default_hidden_columns', array( $this, 'default_hidden_columns' ), 10, 2 );
		add_filter( 'hidden_columns', array( $this, 'force_hide_column' ), 10, 2 );
	}

	/**
	 * Supported field types for Bulk Edit (Phase 1–4).
	 *
	 * @return string[]
	 */
	public static function supported_types() {
		return array(
			'text',
			'textarea',
			'number',
			'true_false',
			'select',
			'radio',
			'checkbox',
			'date',
			'time',
			'datetime',
			'color',
			'hyperlink',
			'map',
			'file',
			'gallery',
			'wysiwyg',
			'relationship',
			'term',
			'user',
		);
	}

	/**
	 * Whether a field type is supported in the current Bulk Edit phase.
	 *
	 * @param string $type Field type slug.
	 * @return bool
	 */
	public static function is_supported_type( $type ) {
		return in_array( (string) $type, self::supported_types(), true );
	}

	/**
	 * Register list-table column hooks for post types that have BE fields.
	 *
	 * @return void
	 */
	public function register_list_table_hooks() {
		$post_types = array_keys( $this->get_post_types_with_be_fields() );

		foreach ( $post_types as $post_type ) {
			add_filter( "manage_{$post_type}_posts_columns", array( $this, 'add_column' ) );
			add_action( "manage_{$post_type}_posts_custom_column", array( $this, 'render_column' ), 10, 2 );
		}
	}

	/**
	 * Add the helper column.
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public function add_column( $columns ) {
		if ( ! is_array( $columns ) ) {
			$columns = array();
		}

		$columns[ self::COLUMN_KEY ] = __( 'CFG Bulk Edit', 'admin-site-enhancements' );

		return $columns;
	}

	/**
	 * Hide the helper column by default in Screen Options.
	 *
	 * @param array     $hidden Hidden columns.
	 * @param WP_Screen $screen Current screen.
	 * @return array
	 */
	public function default_hidden_columns( $hidden, $screen = null ) {
		if ( ! is_array( $hidden ) ) {
			$hidden = array();
		}

		if ( ! $this->is_target_list_screen( $screen ) ) {
			return $hidden;
		}

		if ( ! in_array( self::COLUMN_KEY, $hidden, true ) ) {
			$hidden[] = self::COLUMN_KEY;
		}

		return $hidden;
	}

	/**
	 * Force-hide the helper column on list tables.
	 *
	 * @param array     $hidden Hidden columns.
	 * @param WP_Screen $screen Current screen.
	 * @return array
	 */
	public function force_hide_column( $hidden, $screen ) {
		if ( ! is_array( $hidden ) ) {
			$hidden = array();
		}

		if ( ! $this->is_target_list_screen( $screen ) ) {
			return $hidden;
		}

		if ( ! in_array( self::COLUMN_KEY, $hidden, true ) ) {
			$hidden[] = self::COLUMN_KEY;
		}

		return $hidden;
	}

	/**
	 * Whether the screen is a post list table that has BE fields.
	 *
	 * @param WP_Screen|null $screen Screen.
	 * @return bool
	 */
	private function is_target_list_screen( $screen ) {
		if ( ! ( $screen instanceof WP_Screen ) ) {
			return false;
		}

		if ( 'edit' !== $screen->base ) {
			return false;
		}

		$post_type = isset( $screen->post_type ) ? (string) $screen->post_type : '';
		if ( '' === $post_type ) {
			return false;
		}

		$map = $this->get_post_types_with_be_fields();

		return isset( $map[ $post_type ] );
	}

	/**
	 * Output an empty helper cell (Bulk Edit does not need per-row JSON).
	 *
	 * @param string $column_name Column slug.
	 * @param int    $post_id     Post ID.
	 * @return void
	 */
	public function render_column( $column_name, $post_id ) {
		if ( self::COLUMN_KEY !== $column_name ) {
			return;
		}

		echo '<span class="asenha-cfgroup-be-marker" aria-hidden="true"></span>';
	}

	/**
	 * Render Bulk Edit fieldsets for CFG fields.
	 *
	 * @param string $column_name Column being rendered.
	 * @param string $post_type   Post type.
	 * @return void
	 */
	public function render_bulk_edit_box( $column_name, $post_type ) {
		if ( self::COLUMN_KEY !== $column_name ) {
			return;
		}

		if ( isset( $this->printed_boxes[ $post_type ] ) ) {
			return;
		}

		$groups = $this->get_be_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return;
		}

		$this->printed_boxes[ $post_type ] = true;

		wp_nonce_field( 'asenha_cfgroup_bulk_edit', 'asenha_cfgroup_bulk_edit_nonce' );

		foreach ( $groups as $group ) {
			$this->render_group_fieldset( $group );
		}
	}

	/**
	 * Render one field group fieldset.
	 *
	 * @param array $group Structured group data.
	 * @return void
	 */
	private function render_group_fieldset( $group ) {
		$show_tabs = ! empty( $group['show_tab_headings'] );
		$fields    = isset( $group['fields'] ) && is_array( $group['fields'] ) ? $group['fields'] : array();
		?>
		<fieldset class="asenha-cfgroup-be">
			<div class="inline-edit-col">
				<h4 class="asenha-cfgroup-be-heading"><?php echo esc_html( $group['title'] ); ?></h4>
				<?php
				if ( ! $show_tabs ) {
					$this->render_be_fields_grid( $fields );
				} else {
					$untabbed = array();
					$buckets  = array();

					foreach ( $fields as $field ) {
						$tab_key = isset( $field['tab_key'] ) ? (string) $field['tab_key'] : '';
						if ( '' === $tab_key ) {
							$untabbed[] = $field;
							continue;
						}
						if ( ! isset( $buckets[ $tab_key ] ) ) {
							$buckets[ $tab_key ] = array(
								'label'  => isset( $field['tab_label'] ) ? (string) $field['tab_label'] : $tab_key,
								'fields' => array(),
							);
						}
						$buckets[ $tab_key ]['fields'][] = $field;
					}

					if ( ! empty( $untabbed ) ) {
						$this->render_be_fields_grid( $untabbed );
					}

					if ( ! empty( $buckets ) ) {
						$first = true;
						?>
						<div class="asenha-cfgroup-be-tabs" role="tablist">
							<?php foreach ( $buckets as $tab_key => $bucket ) : ?>
								<button
									type="button"
									class="asenha-cfgroup-be-tab<?php echo $first ? ' active' : ''; ?>"
									role="tab"
									aria-selected="<?php echo $first ? 'true' : 'false'; ?>"
									data-tab="<?php echo esc_attr( $tab_key ); ?>"
								><?php echo esc_html( $bucket['label'] ); ?></button>
								<?php
								$first = false;
							endforeach;
							?>
						</div>
						<?php
						$first = true;
						foreach ( $buckets as $tab_key => $bucket ) :
							?>
							<div
								class="asenha-cfgroup-be-tab-pane<?php echo $first ? ' active' : ''; ?>"
								role="tabpanel"
								data-tab="<?php echo esc_attr( $tab_key ); ?>"
								<?php echo $first ? '' : ' hidden'; ?>
							>
								<?php $this->render_be_fields_grid( $bucket['fields'] ); ?>
							</div>
							<?php
							$first = false;
						endforeach;
					}
				}
				?>
			</div>
		</fieldset>
		<?php
	}

	/**
	 * Render a grid wrapper containing Bulk Edit field controls.
	 *
	 * @param array $fields Field definitions.
	 * @return void
	 */
	private function render_be_fields_grid( $fields ) {
		if ( empty( $fields ) || ! is_array( $fields ) ) {
			return;
		}
		echo '<div class="asenha-cfgroup-be-fields">';
		foreach ( $fields as $field ) {
			$this->render_field_control( $field );
		}
		echo '</div>';
	}

	/**
	 * Render a single Bulk Edit control for a supported field type.
	 *
	 * @param array $field Field definition.
	 * @return void
	 */
	private function render_field_control( $field ) {
		$field_id   = (int) $field['id'];
		$input_name = self::INPUT_NAME . '[' . $field_id . ']';
		$input_id   = 'asenha-cfgroup-be-' . $field_id;
		$label      = isset( $field['label'] ) ? $field['label'] : $field['name'];
		$type       = $field['type'];
		$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();

		switch ( $type ) {
			case 'textarea':
				?>
				<label class="asenha-cfgroup-be-field asenha-cfgroup-be-field-textarea">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<textarea name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-be-input" rows="3" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="<?php echo esc_attr( $type ); ?>" placeholder="<?php echo esc_attr__( 'Leave blank for no change', 'admin-site-enhancements' ); ?>"></textarea>
					</span>
				</label>
				<?php
				break;

			case 'number':
				$attrs = '';
				if ( isset( $options['min'] ) && '' !== $options['min'] ) {
					$attrs .= ' min="' . esc_attr( $options['min'] ) . '"';
				}
				if ( isset( $options['max'] ) && '' !== $options['max'] ) {
					$attrs .= ' max="' . esc_attr( $options['max'] ) . '"';
				}
				if ( isset( $options['step'] ) && '' !== $options['step'] ) {
					$attrs .= ' step="' . esc_attr( $options['step'] ) . '"';
				} else {
					$attrs .= ' step="any"';
				}
				?>
				<label class="asenha-cfgroup-be-field asenha-cfgroup-be-field-number">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<input type="number" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-be-input" value="" placeholder="<?php echo esc_attr__( 'No change', 'admin-site-enhancements' ); ?>" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="<?php echo esc_attr( $type ); ?>"<?php echo $attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above ?> />
					</span>
				</label>
				<?php
				break;

			case 'true_false':
				?>
				<label class="asenha-cfgroup-be-field asenha-cfgroup-be-field-true-false">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<select name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-be-input" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="<?php echo esc_attr( $type ); ?>">
							<option value="<?php echo esc_attr( self::NO_CHANGE ); ?>"><?php echo esc_html__( '— No Change —', 'admin-site-enhancements' ); ?></option>
							<option value="1"><?php echo esc_html__( 'Yes', 'admin-site-enhancements' ); ?></option>
							<option value="0"><?php echo esc_html__( 'No', 'admin-site-enhancements' ); ?></option>
						</select>
					</span>
				</label>
				<?php
				break;

			case 'select':
				if ( ! empty( $options['multiple'] ) ) {
					$this->render_multi_choice_with_mode( $field, $input_name, $label, 'select_multiple' );
				} else {
					$this->render_select_single( $field, $input_name, $input_id, $label );
				}
				break;

			case 'radio':
				$this->render_radio_with_no_change( $field, $input_name, $label );
				break;

			case 'checkbox':
				$this->render_multi_choice_with_mode( $field, $input_name, $label, 'checkbox' );
				break;

			case 'date':
				if ( ! empty( $options['year_only'] ) ) {
					?>
					<label class="asenha-cfgroup-be-field asenha-cfgroup-be-field-date-year">
						<span class="title"><?php echo esc_html( $label ); ?></span>
						<span class="input-text-wrap">
							<input type="number" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-be-input asenha-cfgroup-be-year" value="" min="1000" max="9999" step="1" placeholder="<?php echo esc_attr__( 'No change', 'admin-site-enhancements' ); ?>" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="date_year" />
						</span>
					</label>
					<?php
				} else {
					?>
					<label class="asenha-cfgroup-be-field asenha-cfgroup-be-field-date">
						<span class="title"><?php echo esc_html( $label ); ?></span>
						<span class="input-text-wrap">
							<input type="date" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-be-input" value="" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="date" />
						</span>
					</label>
					<?php
				}
				break;

			case 'time':
				$step_minutes = isset( $options['step'] ) ? absint( $options['step'] ) : 5;
				if ( $step_minutes < 1 ) {
					$step_minutes = 5;
				}
				$step_seconds = $step_minutes * 60;
				?>
				<label class="asenha-cfgroup-be-field asenha-cfgroup-be-field-time">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<input type="time" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-be-input" value="" step="<?php echo esc_attr( (string) $step_seconds ); ?>" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="time" />
					</span>
				</label>
				<?php
				break;

			case 'datetime':
				$step_minutes = isset( $options['step'] ) ? absint( $options['step'] ) : 5;
				if ( $step_minutes < 1 ) {
					$step_minutes = 5;
				}
				$step_seconds = $step_minutes * 60;
				?>
				<label class="asenha-cfgroup-be-field asenha-cfgroup-be-field-datetime">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<input type="datetime-local" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-be-input" value="" step="<?php echo esc_attr( (string) $step_seconds ); ?>" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="datetime" />
					</span>
				</label>
				<?php
				break;

			case 'color':
				?>
				<label class="asenha-cfgroup-be-field asenha-cfgroup-be-field-color">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<div class="asenha-cfgroup-be-color">
							<div class="cfgroup-color-preview"></div>
							<input type="text" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-be-input color" value="" placeholder="<?php echo esc_attr__( 'Leave blank for no change', 'admin-site-enhancements' ); ?>" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="color" />
						</div>
					</span>
				</label>
				<?php
				break;

			case 'hyperlink':
				$this->render_hyperlink_with_mode( $field, $input_name, $label );
				break;

			case 'map':
				$this->render_map_with_mode( $field, $input_name, $label );
				break;

			case 'file':
				$this->render_file_with_mode( $field, $input_name, $label );
				break;

			case 'gallery':
				$this->render_gallery_with_mode( $field, $input_name, $label );
				break;

			case 'wysiwyg':
				$this->render_wysiwyg_with_mode( $field, $input_name, $label );
				break;

			case 'relationship':
				$this->render_relationship_with_mode( $field, $input_name, $label );
				break;

			case 'term':
				$this->render_term_with_mode( $field, $input_name, $label );
				break;

			case 'user':
				$this->render_user_with_mode( $field, $input_name, $label );
				break;

			case 'text':
			default:
				?>
				<label class="asenha-cfgroup-be-field asenha-cfgroup-be-field-text">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<input type="text" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-be-input" value="" placeholder="<?php echo esc_attr__( 'Leave blank for no change', 'admin-site-enhancements' ); ?>" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="<?php echo esc_attr( $type ); ?>" />
					</span>
				</label>
				<?php
				break;
		}
	}

	/**
	 * Render a single-select with a leading — No Change — option.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute.
	 * @param string $input_id   Input id attribute.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_select_single( $field, $input_name, $input_id, $label ) {
		$field_id = (int) $field['id'];
		$options  = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$choices  = cfgroup_quick_edit::normalize_choices( isset( $options['choices'] ) ? $options['choices'] : array() );
		?>
		<label class="asenha-cfgroup-be-field asenha-cfgroup-be-field-select">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<select name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-be-input" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="select">
					<option value="<?php echo esc_attr( self::NO_CHANGE ); ?>"><?php echo esc_html__( '— No Change —', 'admin-site-enhancements' ); ?></option>
					<?php foreach ( $choices as $val => $choice_label ) : ?>
						<option value="<?php echo esc_attr( $val ); ?>"><?php echo esc_html( $choice_label ); ?></option>
					<?php endforeach; ?>
				</select>
			</span>
		</label>
		<?php
	}

	/**
	 * Render radio choices with a leading — No Change — radio.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_radio_with_no_change( $field, $input_name, $label ) {
		$field_id = (int) $field['id'];
		$options  = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$choices  = cfgroup_quick_edit::normalize_choices( isset( $options['choices'] ) ? $options['choices'] : array() );
		$layout   = ( isset( $options['layout'] ) && 'horizontal' === $options['layout'] ) ? 'horizontal' : 'vertical';
		$none_id  = 'asenha-cfgroup-be-' . $field_id . '-no-change';
		?>
		<div class="asenha-cfgroup-be-field asenha-cfgroup-be-field-radio">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<div class="asenha-cfgroup-be-choices <?php echo esc_attr( $layout ); ?>">
					<label for="<?php echo esc_attr( $none_id ); ?>">
						<input type="radio" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $none_id ); ?>" class="asenha-cfgroup-be-input" value="<?php echo esc_attr( self::NO_CHANGE ); ?>" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="radio" checked="checked" />
						<?php echo esc_html__( '— No Change —', 'admin-site-enhancements' ); ?>
					</label>
					<?php foreach ( $choices as $val => $choice_label ) : ?>
						<?php
						$choice_id = 'asenha-cfgroup-be-' . $field_id . '-' . md5( (string) $val );
						?>
						<label for="<?php echo esc_attr( $choice_id ); ?>">
							<input type="radio" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $choice_id ); ?>" class="asenha-cfgroup-be-input" value="<?php echo esc_attr( $val ); ?>" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="radio" />
							<?php echo esc_html( $choice_label ); ?>
						</label>
					<?php endforeach; ?>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Render multi-choice (checkbox / multi-select) with No Change / Replace mode.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Base input name (without []).
	 * @param string $label      Field label.
	 * @param string $data_type  data-field-type value.
	 * @return void
	 */
	private function render_multi_choice_with_mode( $field, $input_name, $label, $data_type ) {
		$field_id   = (int) $field['id'];
		$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$choices    = cfgroup_quick_edit::normalize_choices( isset( $options['choices'] ) ? $options['choices'] : array() );
		$layout     = ( isset( $options['layout'] ) && 'horizontal' === $options['layout'] ) ? 'horizontal' : 'vertical';
		$array_name = $input_name . '[]';
		$mode_name  = self::MODE_NAME . '[' . $field_id . ']';
		$mode_id    = 'asenha-cfgroup-be-mode-' . $field_id;
		?>
		<div class="asenha-cfgroup-be-field asenha-cfgroup-be-field-checkbox" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<select name="<?php echo esc_attr( $mode_name ); ?>" id="<?php echo esc_attr( $mode_id ); ?>" class="asenha-cfgroup-be-mode" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>">
					<option value="<?php echo esc_attr( self::NO_CHANGE ); ?>"><?php echo esc_html__( '— No Change —', 'admin-site-enhancements' ); ?></option>
					<option value="replace"><?php echo esc_html__( 'Replace', 'admin-site-enhancements' ); ?></option>
				</select>
				<div class="asenha-cfgroup-be-choices asenha-cfgroup-be-choices-replace asenha-cfgroup-be-replace-panel <?php echo esc_attr( $layout ); ?>" hidden>
					<?php foreach ( $choices as $val => $choice_label ) : ?>
						<?php
						$choice_id = 'asenha-cfgroup-be-' . $field_id . '-' . md5( (string) $val );
						?>
						<label for="<?php echo esc_attr( $choice_id ); ?>">
							<input type="checkbox" name="<?php echo esc_attr( $array_name ); ?>" id="<?php echo esc_attr( $choice_id ); ?>" class="asenha-cfgroup-be-input" value="<?php echo esc_attr( $val ); ?>" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="<?php echo esc_attr( $data_type ); ?>" disabled="disabled" />
							<?php echo esc_html( $choice_label ); ?>
						</label>
					<?php endforeach; ?>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Render mode select for No Change / Replace / Clear.
	 *
	 * @param int $field_id Field ID.
	 * @return void
	 */
	private function render_mode_select( $field_id ) {
		$mode_name = self::MODE_NAME . '[' . $field_id . ']';
		$mode_id   = 'asenha-cfgroup-be-mode-' . $field_id;
		?>
		<select name="<?php echo esc_attr( $mode_name ); ?>" id="<?php echo esc_attr( $mode_id ); ?>" class="asenha-cfgroup-be-mode" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>">
			<option value="<?php echo esc_attr( self::NO_CHANGE ); ?>"><?php echo esc_html__( '— No Change —', 'admin-site-enhancements' ); ?></option>
			<option value="replace"><?php echo esc_html__( 'Replace', 'admin-site-enhancements' ); ?></option>
			<option value="clear"><?php echo esc_html__( 'Clear', 'admin-site-enhancements' ); ?></option>
		</select>
		<?php
	}

	/**
	 * Render hyperlink with No Change / Replace / Clear mode.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Base input name.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_hyperlink_with_mode( $field, $input_name, $label ) {
		$field_id = (int) $field['id'];
		$options  = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$ui_mode  = isset( $options['ui'] ) ? $options['ui'] : 'simple';
		?>
		<div class="asenha-cfgroup-be-field asenha-cfgroup-be-field-hyperlink" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<?php $this->render_mode_select( $field_id ); ?>
				<div class="asenha-cfgroup-be-replace-panel" hidden>
					<?php
					if ( 'wp_link' === $ui_mode ) {
						$this->render_hyperlink_wplink_panel( $field, $input_name );
					} else {
						$this->render_hyperlink_simple_panel( $field, $input_name );
					}
					?>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Render map with No Change / Replace / Clear mode.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Base input name.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_map_with_mode( $field, $input_name, $label ) {
		$field_id   = (int) $field['id'];
		$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$defaults   = class_exists( 'cfgroup_map' ) ? cfgroup_map::default_options() : array(
			'map_provider' => 'openstreetmap',
			'center_lat'   => '-37.81411',
			'center_lng'   => '144.96328',
			'zoom'         => '14',
			'height'       => '280',
		);
		$provider   = isset( $options['map_provider'] ) ? $options['map_provider'] : $defaults['map_provider'];
		$provider   = in_array( $provider, array( 'openstreetmap', 'google_maps' ), true ) ? $provider : $defaults['map_provider'];
		$center_lat = isset( $options['center_lat'] ) ? $options['center_lat'] : $defaults['center_lat'];
		$center_lng = isset( $options['center_lng'] ) ? $options['center_lng'] : $defaults['center_lng'];
		$zoom       = isset( $options['zoom'] ) ? $options['zoom'] : $defaults['zoom'];
		$height     = isset( $options['height'] ) ? absint( $options['height'] ) : 280;
		$height     = $height ? min( $height, 320 ) : 280;
		$allow_custom = ! empty( $options['allow_custom_address'] );
		$map_id     = 'cfgroup-map-be-' . $field_id;

		if ( class_exists( 'cfgroup_map' ) ) {
			cfgroup_map::register_needed_provider( $provider );
		}
		?>
		<div class="asenha-cfgroup-be-field asenha-cfgroup-be-field-map" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<?php $this->render_mode_select( $field_id ); ?>
				<div class="asenha-cfgroup-be-replace-panel" hidden>
					<div
						class="cfgroup-map"
						id="<?php echo esc_attr( $map_id ); ?>"
						data-map-provider="<?php echo esc_attr( $provider ); ?>"
						data-center-lat="<?php echo esc_attr( $center_lat ); ?>"
						data-center-lng="<?php echo esc_attr( $center_lng ); ?>"
						data-zoom="<?php echo esc_attr( $zoom ); ?>"
						data-height="<?php echo esc_attr( (string) $height ); ?>"
						<?php if ( $allow_custom ) : ?>
						data-allow-custom-address="1"
						<?php endif; ?>
					>
						<div class="cfgroup-map-search">
							<input
								type="text"
								class="cfgroup-map-address asenha-cfgroup-be-input widefat"
								name="<?php echo esc_attr( $input_name ); ?>[address]"
								value=""
								placeholder="<?php esc_attr_e( 'Search for address…', 'admin-site-enhancements' ); ?>"
								autocomplete="off"
								data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
								data-field-type="map"
								data-subkey="address"
								disabled="disabled"
							/>
						</div>
						<?php if ( $allow_custom ) : ?>
							<div class="cfgroup-map-custom-address-wrap">
								<label class="cfgroup-map-custom-address-label" for="<?php echo esc_attr( $map_id ); ?>-custom-address"><?php esc_html_e( 'Custom address', 'admin-site-enhancements' ); ?></label>
								<input
									type="text"
									id="<?php echo esc_attr( $map_id ); ?>-custom-address"
									class="cfgroup-map-custom-address asenha-cfgroup-be-input widefat"
									name="<?php echo esc_attr( $input_name ); ?>[custom_address]"
									value=""
									placeholder="<?php esc_attr_e( 'Override the address shown on the frontend…', 'admin-site-enhancements' ); ?>"
									autocomplete="off"
									data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
									data-field-type="map"
									data-subkey="custom_address"
									disabled="disabled"
								/>
							</div>
						<?php endif; ?>
						<div class="cfgroup-map-canvas" style="height:<?php echo esc_attr( (string) $height ); ?>px;"></div>
						<input type="hidden" class="cfgroup-map-latitude asenha-cfgroup-be-input" name="<?php echo esc_attr( $input_name ); ?>[latitude]" value="" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="map" data-subkey="latitude" disabled="disabled" />
						<input type="hidden" class="cfgroup-map-longitude asenha-cfgroup-be-input" name="<?php echo esc_attr( $input_name ); ?>[longitude]" value="" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="map" data-subkey="longitude" disabled="disabled" />
						<input type="hidden" class="cfgroup-map-zoom asenha-cfgroup-be-input" name="<?php echo esc_attr( $input_name ); ?>[zoom]" value="" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="map" data-subkey="zoom" disabled="disabled" />
						<?php
						$optional_keys = array( 'place_name', 'street_number', 'street_name', 'city_block', 'sublocality', 'city', 'state', 'post_code', 'country' );
						foreach ( $optional_keys as $opt_key ) :
							?>
							<input type="hidden" class="cfgroup-map-meta asenha-cfgroup-be-input" data-meta-key="<?php echo esc_attr( $opt_key ); ?>" name="<?php echo esc_attr( $input_name ); ?>[<?php echo esc_attr( $opt_key ); ?>]" value="" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="map" data-subkey="<?php echo esc_attr( $opt_key ); ?>" disabled="disabled" />
						<?php endforeach; ?>
					</div>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Render simple hyperlink Replace panel inputs.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Base input name.
	 * @return void
	 */
	private function render_hyperlink_simple_panel( $field, $input_name ) {
		$field_id = (int) $field['id'];
		?>
		<div class="asenha-cfgroup-be-field-hyperlink-simple">
			<label class="asenha-cfgroup-be-hyperlink-sub">
				<span class="asenha-cfgroup-be-hyperlink-sub-label"><?php echo esc_html__( 'URL', 'admin-site-enhancements' ); ?></span>
				<input type="text" name="<?php echo esc_attr( $input_name ); ?>[url]" class="asenha-cfgroup-be-input" value="" placeholder="http://" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="hyperlink" data-subkey="url" disabled="disabled" />
			</label>
			<label class="asenha-cfgroup-be-hyperlink-sub">
				<span class="asenha-cfgroup-be-hyperlink-sub-label"><?php echo esc_html__( 'Link Text', 'admin-site-enhancements' ); ?></span>
				<input type="text" name="<?php echo esc_attr( $input_name ); ?>[text]" class="asenha-cfgroup-be-input" value="" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="hyperlink" data-subkey="text" disabled="disabled" />
			</label>
			<label class="asenha-cfgroup-be-hyperlink-sub">
				<span class="asenha-cfgroup-be-hyperlink-sub-label"><?php echo esc_html__( 'Link Target', 'admin-site-enhancements' ); ?></span>
				<select name="<?php echo esc_attr( $input_name ); ?>[target]" class="asenha-cfgroup-be-input" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="hyperlink" data-subkey="target" disabled="disabled">
					<option value="none">None</option>
					<option value="_blank">_blank</option>
					<option value="_self">_self</option>
					<option value="_top">_top</option>
				</select>
			</label>
		</div>
		<?php
	}

	/**
	 * Render wpLink hyperlink Replace panel.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Base input name.
	 * @return void
	 */
	private function render_hyperlink_wplink_panel( $field, $input_name ) {
		$field_id  = (int) $field['id'];
		$editor_id = 'asenha-cfgroup-be-wplink-' . $field_id;
		?>
		<div
			class="cfgroup-hyperlink-wplink"
			data-ui="wp_link"
			data-empty-text="<?php echo esc_attr__( 'No link selected.', 'admin-site-enhancements' ); ?>"
			data-add-text="<?php echo esc_attr__( 'Add Link', 'admin-site-enhancements' ); ?>"
			data-update-text="<?php echo esc_attr__( 'Update Link', 'admin-site-enhancements' ); ?>"
			data-editor-id="<?php echo esc_attr( $editor_id ); ?>"
		>
			<textarea id="<?php echo esc_attr( $editor_id ); ?>" class="cfgroup-hyperlink-wplink-editor" aria-hidden="true"></textarea>
			<div class="cfgroup-hyperlink-wplink-preview">
				<span class="cfgroup-hyperlink-wplink-preview-empty">
					<?php echo esc_html__( 'No link selected.', 'admin-site-enhancements' ); ?>
				</span>
			</div>
			<div class="cfgroup-hyperlink-wplink-actions">
				<button
					type="button"
					class="button cfgroup-hyperlink-wplink-select"
					data-select-text="<?php echo esc_attr__( 'Select Link', 'admin-site-enhancements' ); ?>"
					data-edit-text="<?php echo esc_attr__( 'Edit Link', 'admin-site-enhancements' ); ?>"
					disabled="disabled"
				>
					<?php echo esc_html__( 'Select Link', 'admin-site-enhancements' ); ?>
				</button>
				<button type="button" class="button cfgroup-hyperlink-wplink-clear" disabled="disabled">
					<?php echo esc_html__( 'Clear', 'admin-site-enhancements' ); ?>
				</button>
			</div>
			<input type="hidden" name="<?php echo esc_attr( $input_name ); ?>[url]" class="asenha-cfgroup-be-input link-url" value="" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="hyperlink" data-subkey="url" disabled="disabled" />
			<input type="hidden" name="<?php echo esc_attr( $input_name ); ?>[text]" class="asenha-cfgroup-be-input link-text" value="" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="hyperlink" data-subkey="text" disabled="disabled" />
			<input type="hidden" name="<?php echo esc_attr( $input_name ); ?>[target]" class="asenha-cfgroup-be-input link-target" value="none" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="hyperlink" data-subkey="target" disabled="disabled" />
		</div>
		<?php
	}

	/**
	 * Render file with No Change / Replace / Clear mode.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_file_with_mode( $field, $input_name, $label ) {
		$field_id = (int) $field['id'];
		$options  = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();

		$file_type          = isset( $options['file_type'] ) ? $options['file_type'] : 'file';
		$image_preview_size = isset( $options['image_preview_size'] ) && ! empty( $options['image_preview_size'] ) ? $options['image_preview_size'] : 'medium';
		$allowed_mime_mode  = isset( $options['allowed_mime_mode'] ) ? $options['allowed_mime_mode'] : 'all';
		$allowed_mime_mode  = in_array( $allowed_mime_mode, array( 'all', 'selected' ), true ) ? $allowed_mime_mode : 'all';

		$field_for_helpers  = array( 'options' => $options );
		$allowed_mimes      = function_exists( 'cfg_file_field_get_effective_allowed_mimes' )
			? cfg_file_field_get_effective_allowed_mimes( $field_for_helpers )
			: array();
		$allowed_extensions = function_exists( 'cfg_file_field_get_effective_allowed_extensions' )
			? cfg_file_field_get_effective_allowed_extensions( $field_for_helpers )
			: array();
		?>
		<div class="asenha-cfgroup-be-field asenha-cfgroup-be-field-file" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<?php $this->render_mode_select( $field_id ); ?>
				<div class="asenha-cfgroup-be-replace-panel" hidden>
					<div
						class="cfgroup_file_input"
						data-file-type="<?php echo esc_attr( $file_type ); ?>"
						data-image-preview-size="<?php echo esc_attr( $image_preview_size ); ?>"
						data-allowed-mime-mode="<?php echo esc_attr( $allowed_mime_mode ); ?>"
						data-allowed-mimes="<?php echo esc_attr( wp_json_encode( array_values( $allowed_mimes ) ) ); ?>"
						data-allowed-extensions="<?php echo esc_attr( wp_json_encode( array_values( $allowed_extensions ) ) ); ?>"
						data-selected-mime=""
					>
						<span class="file_url <?php echo esc_attr( $file_type ); ?>"></span>
						<input type="button" class="button media add" value="<?php echo esc_attr__( 'Add File', 'admin-site-enhancements' ); ?>" disabled="disabled" />
						<input type="button" class="button media remove hidden" value="<?php echo esc_attr__( 'Remove', 'admin-site-enhancements' ); ?>" disabled="disabled" />
						<input
							type="hidden"
							name="<?php echo esc_attr( $input_name ); ?>"
							class="asenha-cfgroup-be-input file_value"
							value=""
							data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
							data-field-type="file"
							disabled="disabled"
						/>
					</div>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Render gallery with No Change / Replace / Clear mode.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_gallery_with_mode( $field, $input_name, $label ) {
		$field_id = (int) $field['id'];
		?>
		<div class="asenha-cfgroup-be-field asenha-cfgroup-be-field-gallery" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<?php $this->render_mode_select( $field_id ); ?>
				<div class="asenha-cfgroup-be-replace-panel" hidden>
					<div class="cfgroup_gallery">
						<div class="gallery-preview"></div>
						<div class="gallery-buttons">
							<button type="button" class="button cfg-button" disabled="disabled"><?php echo esc_html__( 'Select Images', 'admin-site-enhancements' ); ?></button>
							<button type="button" class="button cfg-edit-gallery hidden" disabled="disabled"><?php echo esc_html__( 'Edit Selection', 'admin-site-enhancements' ); ?></button>
							<a href="#" class="cfg-clear-gallery hidden" aria-disabled="true"><?php echo esc_html__( 'Clear', 'admin-site-enhancements' ); ?></a>
						</div>
						<input
							type="hidden"
							name="<?php echo esc_attr( $input_name ); ?>"
							class="asenha-cfgroup-be-input gallery_value cfg-gallery-value"
							value=""
							data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
							data-field-type="gallery"
							disabled="disabled"
						/>
					</div>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Render wysiwyg with No Change / Replace / Clear mode.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_wysiwyg_with_mode( $field, $input_name, $label ) {
		$field_id  = (int) $field['id'];
		$editor_id = 'asenha-cfgroup-be-wysi-' . $field_id;

		if ( isset( CFG()->fields['wysiwyg'] ) && is_object( CFG()->fields['wysiwyg'] )
			&& method_exists( CFG()->fields['wysiwyg'], 'get_pending_data_attrs' )
		) {
			$field_attrs = CFG()->fields['wysiwyg']->get_pending_data_attrs( $field );
		} else {
			$field_attrs = ' data-media-buttons="1" data-editor-tabs="both" data-toolbar-buttons="bold,italic,underline,strikethrough,forecolor,bullist,numlist,alignleft,aligncenter,alignright,link,charmap,removeformat,fullscreen"';
		}
		?>
		<div class="asenha-cfgroup-be-field asenha-cfgroup-be-field-wysiwyg" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<?php $this->render_mode_select( $field_id ); ?>
				<div class="asenha-cfgroup-be-replace-panel" hidden>
					<div class="cfg-wysiwyg-pending"<?php echo $field_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in get_pending_data_attrs() / fallback is static ?>>
						<textarea
							id="<?php echo esc_attr( $editor_id ); ?>"
							name="<?php echo esc_attr( $input_name ); ?>"
							class="asenha-cfgroup-be-input wysiwyg wp-editor-area"
							rows="8"
							data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
							data-field-type="wysiwyg"
							<?php echo $field_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in get_pending_data_attrs() / fallback is static ?>
							disabled="disabled"
						></textarea>
					</div>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Render relationship with No Change / Replace / Clear mode.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_relationship_with_mode( $field, $input_name, $label ) {
		$field_id   = (int) $field['id'];
		$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$limit_min  = isset( $options['limit_min'] ) ? (string) $options['limit_min'] : '';
		$limit_max  = isset( $options['limit_max'] ) ? (string) $options['limit_max'] : '';
		$post_types = cfgroup_quick_edit::qe_relationship_field_post_types( $field );
		?>
		<div
			class="asenha-cfgroup-be-field asenha-cfgroup-be-field-relationship"
			data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
			data-limit-min="<?php echo esc_attr( $limit_min ); ?>"
			data-limit-max="<?php echo esc_attr( $limit_max ); ?>"
			data-post-types="<?php echo esc_attr( wp_json_encode( $post_types ) ); ?>"
		>
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<?php $this->render_mode_select( $field_id ); ?>
				<div class="asenha-cfgroup-be-replace-panel" hidden>
					<input
						type="hidden"
						name="<?php echo esc_attr( $input_name ); ?>"
						class="asenha-cfgroup-be-input asenha-cfgroup-be-relationship"
						value=""
						data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
						data-field-type="relationship"
						style="width:100%"
						disabled="disabled"
					/>
					<span class="asenha-cfgroup-be-relationship-error" hidden></span>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Render term with No Change / Replace / Clear mode.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_term_with_mode( $field, $input_name, $label ) {
		$field_id   = (int) $field['id'];
		$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$limit_min  = isset( $options['limit_min'] ) ? (string) $options['limit_min'] : '';
		$limit_max  = isset( $options['limit_max'] ) ? (string) $options['limit_max'] : '';
		$taxonomies = cfgroup_quick_edit::qe_term_field_taxonomies( $field );
		?>
		<div
			class="asenha-cfgroup-be-field asenha-cfgroup-be-field-term"
			data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
			data-limit-min="<?php echo esc_attr( $limit_min ); ?>"
			data-limit-max="<?php echo esc_attr( $limit_max ); ?>"
			data-taxonomies="<?php echo esc_attr( wp_json_encode( $taxonomies ) ); ?>"
		>
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<?php $this->render_mode_select( $field_id ); ?>
				<div class="asenha-cfgroup-be-replace-panel" hidden>
					<input
						type="hidden"
						name="<?php echo esc_attr( $input_name ); ?>"
						class="asenha-cfgroup-be-input asenha-cfgroup-be-term"
						value=""
						data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
						data-field-type="term"
						style="width:100%"
						disabled="disabled"
					/>
					<span class="asenha-cfgroup-be-term-error" hidden></span>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Render user with No Change / Replace / Clear mode.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_user_with_mode( $field, $input_name, $label ) {
		$field_id  = (int) $field['id'];
		$options   = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$limit_min = isset( $options['limit_min'] ) ? (string) $options['limit_min'] : '';
		$limit_max = isset( $options['limit_max'] ) ? (string) $options['limit_max'] : '';
		?>
		<div
			class="asenha-cfgroup-be-field asenha-cfgroup-be-field-user"
			data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
			data-limit-min="<?php echo esc_attr( $limit_min ); ?>"
			data-limit-max="<?php echo esc_attr( $limit_max ); ?>"
		>
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<?php $this->render_mode_select( $field_id ); ?>
				<div class="asenha-cfgroup-be-replace-panel" hidden>
					<input
						type="hidden"
						name="<?php echo esc_attr( $input_name ); ?>"
						class="asenha-cfgroup-be-input asenha-cfgroup-be-user"
						value=""
						data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
						data-field-type="user"
						style="width:100%"
						disabled="disabled"
					/>
					<span class="asenha-cfgroup-be-user-error" hidden></span>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Save Bulk Edit CFG field changes for updated posts.
	 *
	 * @param int[] $updated          Updated post IDs.
	 * @param array $shared_post_data Shared post data from core bulk edit.
	 * @return void
	 */
	public function save_bulk_edit( $updated, $shared_post_data ) {
		unset( $shared_post_data );

		if ( ! isset( $_REQUEST['asenha_cfgroup_bulk_edit_nonce'] )
			|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['asenha_cfgroup_bulk_edit_nonce'] ) ), 'asenha_cfgroup_bulk_edit' )
		) {
			return;
		}

		if ( ! isset( $_REQUEST[ self::INPUT_NAME ] ) && ! isset( $_REQUEST[ self::MODE_NAME ] ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per field type below.
		$submitted = isset( $_REQUEST[ self::INPUT_NAME ] ) && is_array( $_REQUEST[ self::INPUT_NAME ] )
			? wp_unslash( $_REQUEST[ self::INPUT_NAME ] )
			: array();

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized below.
		$modes = isset( $_REQUEST[ self::MODE_NAME ] ) && is_array( $_REQUEST[ self::MODE_NAME ] )
			? wp_unslash( $_REQUEST[ self::MODE_NAME ] )
			: array();

		if ( ! is_array( $updated ) || empty( $updated ) ) {
			return;
		}

		foreach ( $updated as $post_id ) {
			$post_id = (int) $post_id;
			if ( $post_id < 1 ) {
				continue;
			}

			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				continue;
			}

			$matching_groups = CFG()->api->get_matching_groups( $post_id, true );
			if ( empty( $matching_groups ) ) {
				continue;
			}

			$allowed_by_id = array();
			foreach ( array_keys( $matching_groups ) as $group_id ) {
				$group_fields = $this->collect_be_fields_from_group( (int) $group_id );
				foreach ( $group_fields['fields'] as $field ) {
					$allowed_by_id[ (int) $field['id'] ] = $field;
				}
			}

			if ( empty( $allowed_by_id ) ) {
				continue;
			}

			$field_data = array();

			foreach ( $allowed_by_id as $field_id => $field ) {
				$name = $field['name'];
				$type = $field['type'];

				if ( ! self::is_supported_type( $type ) ) {
					continue;
				}

				if ( empty( $field['options']['show_in_bulk_edit'] ) ) {
					continue;
				}

				$is_multi = cfgroup_quick_edit::is_multi_value_choice_field( $field );

				if ( $is_multi ) {
					$mode = isset( $modes[ $field_id ] ) ? sanitize_text_field( $modes[ $field_id ] ) : self::NO_CHANGE;
					if ( self::NO_CHANGE === $mode || 'replace' !== $mode ) {
						continue;
					}
					$value                   = isset( $submitted[ $field_id ] ) ? $submitted[ $field_id ] : array();
					$field_data[ $name ] = cfgroup_quick_edit::sanitize_choice_array( $value, $field );
					continue;
				}

				if ( 'hyperlink' === $type || 'map' === $type || 'file' === $type || 'gallery' === $type || 'wysiwyg' === $type
					|| 'relationship' === $type || 'term' === $type || 'user' === $type ) {
					$mode = isset( $modes[ $field_id ] ) ? sanitize_text_field( $modes[ $field_id ] ) : self::NO_CHANGE;

					if ( self::NO_CHANGE === $mode ) {
						continue;
					}

					if ( 'clear' === $mode ) {
						if ( 'hyperlink' === $type ) {
							$field_data[ $name ] = array(
								'url'    => '',
								'text'   => '',
								'target' => 'none',
							);
						} elseif ( 'map' === $type ) {
							$field_data[ $name ] = array(
								'address'   => '',
								'latitude'  => '',
								'longitude' => '',
								'zoom'      => '',
							);
						} elseif ( 'relationship' === $type || 'term' === $type || 'user' === $type ) {
							$field_data[ $name ] = array();
						} else {
							$field_data[ $name ] = '';
						}
						continue;
					}

					if ( 'replace' !== $mode ) {
						continue;
					}

					if ( 'hyperlink' === $type ) {
						$value                   = isset( $submitted[ $field_id ] ) ? $submitted[ $field_id ] : array();
						$field_data[ $name ] = cfgroup_quick_edit::sanitize_qe_hyperlink_value( $value );
						continue;
					}

					if ( 'map' === $type ) {
						$value                   = isset( $submitted[ $field_id ] ) ? $submitted[ $field_id ] : array();
						$field_data[ $name ] = cfgroup_quick_edit::sanitize_qe_map_value( $value );
						continue;
					}

					if ( 'gallery' === $type ) {
						$value                   = isset( $submitted[ $field_id ] ) ? $submitted[ $field_id ] : '';
						$field_data[ $name ] = cfgroup_quick_edit::sanitize_qe_gallery_value( $value );
						continue;
					}

					if ( 'wysiwyg' === $type ) {
						$value                   = isset( $submitted[ $field_id ] ) ? $submitted[ $field_id ] : '';
						$value                   = is_string( $value ) ? $value : '';
						$field_data[ $name ] = wp_kses_post( $value );
						continue;
					}

					if ( 'relationship' === $type ) {
						$value     = isset( $submitted[ $field_id ] ) ? $submitted[ $field_id ] : '';
						$sanitized = cfgroup_quick_edit::sanitize_qe_relationship_value( $value, $field );
						if ( null === $sanitized ) {
							continue;
						}
						$field_data[ $name ] = $sanitized;
						continue;
					}

					if ( 'term' === $type ) {
						$value     = isset( $submitted[ $field_id ] ) ? $submitted[ $field_id ] : '';
						$sanitized = cfgroup_quick_edit::sanitize_qe_term_value( $value, $field );
						if ( null === $sanitized ) {
							continue;
						}
						$field_data[ $name ] = $sanitized;
						continue;
					}

					if ( 'user' === $type ) {
						$value     = isset( $submitted[ $field_id ] ) ? $submitted[ $field_id ] : '';
						$sanitized = cfgroup_quick_edit::sanitize_qe_user_value( $value, $field );
						if ( null === $sanitized ) {
							continue;
						}
						$field_data[ $name ] = $sanitized;
						continue;
					}

					// File replace.
					$value = isset( $submitted[ $field_id ] ) ? $submitted[ $field_id ] : '';
					$id    = ( is_string( $value ) || is_numeric( $value ) ) ? (string) $value : '';
					if ( '' === $id || ! ctype_digit( $id ) ) {
						$field_data[ $name ] = '';
						continue;
					}
					$field_obj = (object) array(
						'options' => isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array(),
					);
					$field_data[ $name ] = ( function_exists( 'cfg_file_field_attachment_mime_is_allowed' )
						&& cfg_file_field_attachment_mime_is_allowed( (int) $id, $field_obj ) )
						? $id
						: '';
					continue;
				}

				if ( ! array_key_exists( $field_id, $submitted ) ) {
					continue;
				}

				$value = $submitted[ $field_id ];

				switch ( $type ) {
					case 'textarea':
						$value = is_string( $value ) ? $value : '';
						if ( '' === $value ) {
							continue 2;
						}
						$field_data[ $name ] = sanitize_textarea_field( $value );
						break;

					case 'number':
						if ( '' === $value || null === $value ) {
							continue 2;
						}
						$field_data[ $name ] = is_numeric( $value ) ? $value : '';
						break;

					case 'true_false':
						if ( (string) self::NO_CHANGE === (string) $value ) {
							continue 2;
						}
						$field_data[ $name ] = ( 0 < (int) $value ) ? 1 : 0;
						break;

					case 'select':
					case 'radio':
						if ( (string) self::NO_CHANGE === (string) $value ) {
							continue 2;
						}
						$field_data[ $name ] = cfgroup_quick_edit::sanitize_choice_scalar( $value, $field );
						break;

					case 'date':
						if ( '' === $value || null === $value ) {
							continue 2;
						}
						$field_data[ $name ] = cfgroup_quick_edit::sanitize_qe_date_value( $value, $field );
						break;

					case 'time':
						if ( '' === $value || null === $value ) {
							continue 2;
						}
						$field_data[ $name ] = cfgroup_quick_edit::sanitize_qe_time_value( $value, $field );
						break;

					case 'datetime':
						if ( '' === $value || null === $value ) {
							continue 2;
						}
						$field_data[ $name ] = cfgroup_quick_edit::sanitize_qe_datetime_value( $value, $field );
						break;

					case 'color':
						if ( '' === $value || null === $value ) {
							continue 2;
						}
						$field_data[ $name ] = cfgroup_quick_edit::sanitize_qe_color_value( $value );
						break;

					case 'text':
					default:
						$value = is_string( $value ) ? $value : '';
						if ( '' === $value ) {
							continue 2;
						}
						$field_data[ $name ] = sanitize_text_field( $value );
						break;
				}
			}

			if ( empty( $field_data ) ) {
				continue;
			}

			CFG()->save( $field_data, array( 'ID' => $post_id ), array( 'format' => 'api' ) );
		}
	}

	/**
	 * Enqueue Bulk Edit assets on relevant list screens.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 * @return void
	 */
	public function enqueue_assets( $hook_suffix ) {
		if ( 'edit.php' !== $hook_suffix ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $this->is_target_list_screen( $screen ) ) {
			return;
		}

		$css_path    = CFG_DIR . '/assets/css/bulk-edit.css';
		$js_path     = CFG_DIR . '/assets/js/bulk-edit.js';
		$colors_path = CFG_DIR . '/assets/js/color-picker/colors.js';
		$picker_path = CFG_DIR . '/assets/js/color-picker/jqColorPicker_mod.js';

		wp_register_script(
			'jqcolors',
			CFG_URL . '/assets/js/color-picker/colors.js',
			array(),
			file_exists( $colors_path ) ? (string) filemtime( $colors_path ) : CFG_VERSION,
			true
		);

		wp_register_script(
			'jqcolorpicker',
			CFG_URL . '/assets/js/color-picker/jqColorPicker_mod.js',
			array( 'jquery', 'jqcolors' ),
			file_exists( $picker_path ) ? (string) filemtime( $picker_path ) : CFG_VERSION,
			true
		);

		wp_enqueue_script( 'jqcolors' );
		wp_enqueue_script( 'jqcolorpicker' );

		$be_script_deps = array( 'jquery', 'jqcolorpicker' );

		if ( $this->post_type_has_be_hyperlink_wplink( $screen->post_type ) ) {
			if ( function_exists( 'wp_enqueue_editor' ) ) {
				wp_enqueue_editor();
			}

			$wplink_path = CFG_DIR . '/assets/js/hyperlink-wplink.js';
			wp_register_script(
				'asenha-cfgroup-hyperlink-wplink',
				CFG_URL . '/assets/js/hyperlink-wplink.js',
				array( 'jquery', 'wplink' ),
				file_exists( $wplink_path ) ? (string) filemtime( $wplink_path ) : CFG_VERSION,
				true
			);
			wp_enqueue_script( 'asenha-cfgroup-hyperlink-wplink' );
			$be_script_deps[] = 'asenha-cfgroup-hyperlink-wplink';
		}

		if ( $this->post_type_has_be_file( $screen->post_type ) ) {
			if ( isset( CFG()->fields['file'] ) && is_object( CFG()->fields['file'] ) ) {
				CFG()->fields['file']->input_head( null );
			} else {
				wp_enqueue_media();
			}

			if ( wp_script_is( 'cfg-file', 'registered' ) || wp_script_is( 'cfg-file', 'enqueued' ) ) {
				$be_script_deps[] = 'cfg-file';
			}
		}

		if ( $this->post_type_has_be_gallery( $screen->post_type ) ) {
			if ( isset( CFG()->fields['gallery'] ) && is_object( CFG()->fields['gallery'] ) ) {
				CFG()->fields['gallery']->input_head( null );
			} else {
				wp_enqueue_media();
			}

			if ( wp_script_is( 'cfg-gallery', 'registered' ) || wp_script_is( 'cfg-gallery', 'enqueued' ) ) {
				$be_script_deps[] = 'cfg-gallery';
			}
		}

		if ( $this->post_type_has_be_wysiwyg( $screen->post_type ) ) {
			if ( isset( CFG()->fields['wysiwyg'] ) && is_object( CFG()->fields['wysiwyg'] ) ) {
				CFG()->fields['wysiwyg']->input_head( null );
			} elseif ( function_exists( 'wp_enqueue_editor' ) ) {
				wp_enqueue_editor();
			}

			if ( wp_script_is( 'cfg-wysiwyg', 'registered' ) || wp_script_is( 'cfg-wysiwyg', 'enqueued' ) ) {
				$be_script_deps[] = 'cfg-wysiwyg';
			}
		}

		if ( $this->post_type_has_be_map( $screen->post_type ) ) {
			if ( isset( CFG()->fields['map'] ) && is_object( CFG()->fields['map'] ) ) {
				$this->register_be_map_providers( $screen->post_type );
				CFG()->fields['map']->input_head( null );
			}

			if ( wp_script_is( 'asenha-cfgroup-map', 'registered' ) || wp_script_is( 'asenha-cfgroup-map', 'enqueued' ) ) {
				$be_script_deps[] = 'asenha-cfgroup-map';
			}
		}

		$be_style_deps = array();
		$needs_select2 = $this->post_type_has_be_relationship( $screen->post_type )
			|| $this->post_type_has_be_term( $screen->post_type )
			|| $this->post_type_has_be_user( $screen->post_type );

		if ( $needs_select2 ) {
			$select2_js  = CFG_DIR . '/assets/js/select2/select2.min.js';
			$select2_css = CFG_DIR . '/assets/js/select2/select2.css';

			wp_register_style(
				'cfgroup-select2',
				CFG_URL . '/assets/js/select2/select2.css',
				array(),
				file_exists( $select2_css ) ? (string) filemtime( $select2_css ) : CFG_VERSION
			);
			wp_enqueue_style( 'cfgroup-select2' );
			$be_style_deps[] = 'cfgroup-select2';

			wp_register_script(
				'cfgroup-select2',
				CFG_URL . '/assets/js/select2/select2.min.js',
				array( 'jquery' ),
				file_exists( $select2_js ) ? (string) filemtime( $select2_js ) : CFG_VERSION,
				true
			);
			wp_enqueue_script( 'cfgroup-select2' );
		}

		if ( $this->post_type_has_be_relationship( $screen->post_type ) ) {
			$rel_js = CFG_DIR . '/assets/js/cfg-relationship-qe.js';

			wp_register_script(
				'cfg-relationship-qe',
				CFG_URL . '/assets/js/cfg-relationship-qe.js',
				array( 'jquery', 'cfgroup-select2' ),
				file_exists( $rel_js ) ? (string) filemtime( $rel_js ) : CFG_VERSION,
				true
			);
			wp_localize_script(
				'cfg-relationship-qe',
				'asenhaCfgroupRelationshipQe',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'asenha_cfgroup_quick_edit' ),
					'i18n'    => array(
						'placeholder' => __( 'Search posts…', 'admin-site-enhancements' ),
						'searching'   => __( 'Searching…', 'admin-site-enhancements' ),
						/* translators: %d: minimum number of related posts */
						'minError'    => __( 'Select at least %d item(s).', 'admin-site-enhancements' ),
						/* translators: %d: maximum number of related posts */
						'maxError'    => __( 'You can select at most %d item(s).', 'admin-site-enhancements' ),
					),
				)
			);
			wp_enqueue_script( 'cfg-relationship-qe' );
			$be_script_deps[] = 'cfg-relationship-qe';
		}

		if ( $this->post_type_has_be_term( $screen->post_type ) ) {
			$term_js = CFG_DIR . '/assets/js/cfg-term-qe.js';

			wp_register_script(
				'cfg-term-qe',
				CFG_URL . '/assets/js/cfg-term-qe.js',
				array( 'jquery', 'cfgroup-select2' ),
				file_exists( $term_js ) ? (string) filemtime( $term_js ) : CFG_VERSION,
				true
			);
			wp_localize_script(
				'cfg-term-qe',
				'asenhaCfgroupTermQe',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'asenha_cfgroup_quick_edit' ),
					'i18n'    => array(
						'placeholder' => __( 'Search terms…', 'admin-site-enhancements' ),
						'searching'   => __( 'Searching…', 'admin-site-enhancements' ),
						/* translators: %d: minimum number of terms */
						'minError'    => __( 'Select at least %d item(s).', 'admin-site-enhancements' ),
						/* translators: %d: maximum number of terms */
						'maxError'    => __( 'You can select at most %d item(s).', 'admin-site-enhancements' ),
					),
				)
			);
			wp_enqueue_script( 'cfg-term-qe' );
			$be_script_deps[] = 'cfg-term-qe';
		}

		if ( $this->post_type_has_be_user( $screen->post_type ) ) {
			$user_js = CFG_DIR . '/assets/js/cfg-user-qe.js';

			wp_register_script(
				'cfg-user-qe',
				CFG_URL . '/assets/js/cfg-user-qe.js',
				array( 'jquery', 'cfgroup-select2' ),
				file_exists( $user_js ) ? (string) filemtime( $user_js ) : CFG_VERSION,
				true
			);
			wp_localize_script(
				'cfg-user-qe',
				'asenhaCfgroupUserQe',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'asenha_cfgroup_quick_edit' ),
					'i18n'    => array(
						'placeholder' => __( 'Search users…', 'admin-site-enhancements' ),
						'searching'   => __( 'Searching…', 'admin-site-enhancements' ),
						/* translators: %d: minimum number of users */
						'minError'    => __( 'Select at least %d item(s).', 'admin-site-enhancements' ),
						/* translators: %d: maximum number of users */
						'maxError'    => __( 'You can select at most %d item(s).', 'admin-site-enhancements' ),
					),
				)
			);
			wp_enqueue_script( 'cfg-user-qe' );
			$be_script_deps[] = 'cfg-user-qe';
		}

		wp_enqueue_style(
			'asenha-cfgroup-bulk-edit',
			CFG_URL . '/assets/css/bulk-edit.css',
			$be_style_deps,
			file_exists( $css_path ) ? (string) filemtime( $css_path ) : CFG_VERSION
		);

		wp_enqueue_script(
			'asenha-cfgroup-bulk-edit',
			CFG_URL . '/assets/js/bulk-edit.js',
			$be_script_deps,
			file_exists( $js_path ) ? (string) filemtime( $js_path ) : CFG_VERSION,
			true
		);
	}

	/**
	 * Whether the post type has any BE-enabled hyperlink field using wpLink UI.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_be_hyperlink_wplink( $post_type ) {
		$groups = $this->get_be_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'hyperlink' === $field['type'] ) {
					$ui = isset( $field['options']['ui'] ) ? $field['options']['ui'] : 'simple';
					if ( 'wp_link' === $ui ) {
						return true;
					}
				}
			}
		}

		return false;
	}

	/**
	 * Whether the post type has any BE-enabled file field.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_be_file( $post_type ) {
		$groups = $this->get_be_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'file' === $field['type'] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether the post type has any BE-enabled gallery field.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_be_gallery( $post_type ) {
		$groups = $this->get_be_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'gallery' === $field['type'] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether the post type has any BE-enabled wysiwyg field.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_be_wysiwyg( $post_type ) {
		$groups = $this->get_be_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'wysiwyg' === $field['type'] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether the post type has any BE-enabled map field.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_be_map( $post_type ) {
		$groups = $this->get_be_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'map' === $field['type'] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Register map providers used by BE-enabled map fields for asset enqueue.
	 *
	 * @param string $post_type Post type slug.
	 * @return void
	 */
	private function register_be_map_providers( $post_type ) {
		if ( ! class_exists( 'cfgroup_map' ) ) {
			return;
		}

		$groups = $this->get_be_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( empty( $field['type'] ) || 'map' !== $field['type'] ) {
					continue;
				}
				$provider = isset( $field['options']['map_provider'] ) ? $field['options']['map_provider'] : 'openstreetmap';
				cfgroup_map::register_needed_provider( $provider );
			}
		}
	}

	/**
	 * Whether the post type has any BE-enabled relationship field.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_be_relationship( $post_type ) {
		$groups = $this->get_be_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'relationship' === $field['type'] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether the post type has any BE-enabled term field.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_be_term( $post_type ) {
		$groups = $this->get_be_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'term' === $field['type'] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether the post type has any BE-enabled user field.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_be_user( $post_type ) {
		$groups = $this->get_be_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'user' === $field['type'] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Map of post types that have at least one BE-enabled field → groups data.
	 *
	 * @return array
	 */
	private function get_post_types_with_be_fields() {
		if ( null !== $this->post_type_fields_cache ) {
			return $this->post_type_fields_cache;
		}

		$this->post_type_fields_cache = array();

		$field_groups = CFG()->field_group->load_field_groups();

		foreach ( $field_groups as $group_id => $group ) {
			$rules = isset( $group['rules'] ) && is_array( $group['rules'] ) ? $group['rules'] : array();

			if ( empty( $rules['placement']['values'] ) || 'posts' !== $rules['placement']['values'] ) {
				continue;
			}

			$collected = $this->collect_be_fields_from_group( (int) $group_id, $group );
			if ( empty( $collected['fields'] ) ) {
				continue;
			}

			$post_types = $this->resolve_group_post_types( $rules );
			foreach ( $post_types as $post_type ) {
				if ( ! isset( $this->post_type_fields_cache[ $post_type ] ) ) {
					$this->post_type_fields_cache[ $post_type ] = array();
				}
				$this->post_type_fields_cache[ $post_type ][ (int) $group_id ] = $collected;
			}
		}

		return $this->post_type_fields_cache;
	}

	/**
	 * Get structured BE groups for a post type.
	 *
	 * @param string $post_type Post type.
	 * @return array
	 */
	private function get_be_groups_for_post_type( $post_type ) {
		$map = $this->get_post_types_with_be_fields();

		if ( empty( $map[ $post_type ] ) ) {
			return array();
		}

		$groups = array_values( $map[ $post_type ] );

		usort(
			$groups,
			function ( $a, $b ) {
				$order_a = isset( $a['order'] ) ? (int) $a['order'] : 0;
				$order_b = isset( $b['order'] ) ? (int) $b['order'] : 0;
				if ( $order_a === $order_b ) {
					return strcmp( $a['title'], $b['title'] );
				}
				return $order_a <=> $order_b;
			}
		);

		return $groups;
	}

	/**
	 * Resolve post types a field group targets (from placement rules).
	 *
	 * @param array $rules Field group rules.
	 * @return string[]
	 */
	private function resolve_group_post_types( $rules ) {
		if ( empty( $rules['post_types']['values'] ) || ! is_array( $rules['post_types']['values'] ) ) {
			return array();
		}

		$values   = array_map( 'strval', $rules['post_types']['values'] );
		$operator = isset( $rules['post_types']['operator'] ) ? $rules['post_types']['operator'] : '==';

		if ( is_array( $operator ) ) {
			$operator = isset( $operator[0] ) ? $operator[0] : '==';
		}

		if ( '==' === $operator ) {
			return $values;
		}

		$all = get_post_types( array( 'show_ui' => true ), 'names' );
		unset( $all['attachment'], $all['asenha_cfgroup'], $all['asenha_cpt'], $all['asenha_ctax'] );

		return array_values( array_diff( array_keys( $all ), $values ) );
	}

	/**
	 * Collect BE-enabled top-level fields from a group.
	 *
	 * @param int        $group_id Group post ID.
	 * @param array|null $group    Optional preloaded group data.
	 * @return array{group_id:int,title:string,order:int,show_tab_headings:bool,fields:array}
	 */
	private function collect_be_fields_from_group( $group_id, $group = null ) {
		if ( null === $group ) {
			$all   = CFG()->field_group->load_field_groups();
			$group = isset( $all[ $group_id ] ) ? $all[ $group_id ] : null;
		}

		$result = array(
			'group_id'          => (int) $group_id,
			'title'             => $group ? $group['title'] : get_the_title( $group_id ),
			'order'             => 0,
			'show_tab_headings' => false,
			'fields'            => array(),
		);

		if ( ! $group || empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
			return $result;
		}

		if ( ! empty( $group['extras']['order'] ) ) {
			$result['order'] = (int) $group['extras']['order'];
		}

		$fields = $group['fields'];
		usort(
			$fields,
			function ( $a, $b ) {
				$wa = isset( $a['weight'] ) ? (int) $a['weight'] : 0;
				$wb = isset( $b['weight'] ) ? (int) $b['weight'] : 0;
				return $wa <=> $wb;
			}
		);

		$current_tab_key   = '';
		$current_tab_label = '';
		$tab_keys_used     = array();

		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			if ( 0 < (int) $field['parent_id'] ) {
				continue;
			}

			$type = isset( $field['type'] ) ? $field['type'] : '';

			if ( 'tab' === $type ) {
				$current_tab_key   = isset( $field['name'] ) ? (string) $field['name'] : (string) $field['id'];
				$current_tab_label = isset( $field['label'] ) ? (string) $field['label'] : $current_tab_key;
				continue;
			}

			if ( ! self::is_supported_type( $type ) ) {
				continue;
			}

			if ( empty( $field['options']['show_in_bulk_edit'] ) ) {
				continue;
			}

			if ( '' !== $current_tab_key ) {
				$tab_keys_used[ $current_tab_key ] = true;
			}

			$result['fields'][] = array(
				'id'        => (int) $field['id'],
				'name'      => $field['name'],
				'label'     => isset( $field['label'] ) ? $field['label'] : $field['name'],
				'type'      => $type,
				'options'   => isset( $field['options'] ) ? $field['options'] : array(),
				'tab_key'   => $current_tab_key,
				'tab_label' => $current_tab_label,
			);
		}

		$result['show_tab_headings'] = ( count( $tab_keys_used ) > 1 );

		return $result;
	}
}
