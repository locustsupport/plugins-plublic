<?php
/**
 * CFG Map field type — OpenStreetMap (Leaflet) or Google Maps per field.
 *
 * @package ASENHA
 */

class cfgroup_map extends cfgroup_field {

	/**
	 * Providers needed on the current screen (set from html()).
	 *
	 * @var array<string,bool>
	 */
	private static $needed_providers = array();

	/**
	 * Whether assets have been prepared.
	 *
	 * @var bool
	 */
	private static $assets_prepared = false;

	/**
	 * Constructor.
	 */
	function __construct() {
		$this->name  = 'map';
		$this->label = __( 'Map', 'admin-site-enhancements' );

		add_action( 'wp_ajax_asenha_cfgroup_map_geocode', array( $this, 'ajax_geocode' ) );
	}

	/**
	 * Mark a provider as needed for the current request (QE/BE/forms).
	 *
	 * @param string $provider openstreetmap|google_maps.
	 * @return void
	 */
	public static function register_needed_provider( $provider ) {
		if ( in_array( $provider, array( 'openstreetmap', 'google_maps' ), true ) ) {
			self::$needed_providers[ $provider ] = true;
		}
	}

	/**
	 * Default field options.
	 *
	 * @return array
	 */
	public static function default_options() {
		return array(
			'map_provider'         => 'openstreetmap',
			'center_lat'           => '-37.81411',
			'center_lng'           => '144.96328',
			'zoom'                 => '14',
			'height'               => '400',
			'allow_custom_address' => '0',
		);
	}

	/**
	 * Field settings UI in the CFG editor.
	 *
	 * @param int    $key   Field weight key.
	 * @param object $field Field object.
	 */
	function options_html( $key, $field ) {
		$defaults = self::default_options();
		?>
		<tr class="field_option field_option_<?php echo esc_attr( $this->name ); ?>">
			<td>
				<label>
					<?php esc_html_e( 'Map Provider', 'admin-site-enhancements' ); ?>
					<div class="cfgroup_tooltip">?
						<div class="tooltip_inner"><?php esc_html_e( 'OpenStreetMap needs no API key. Google Maps uses the key from Custom Content Types settings.', 'admin-site-enhancements' ); ?></div>
					</div>
				</label>
			</td>
			<td>
				<?php
				CFG()->create_field(
					array(
						'type'       => 'radio',
						'input_name' => "cfgroup[fields][$key][options][map_provider]",
						'options'    => array(
							'choices' => array(
								'openstreetmap' => __( 'OpenStreetMap', 'admin-site-enhancements' ),
								'google_maps'   => __( 'Google Maps', 'admin-site-enhancements' ),
							),
							'layout'  => 'horizontal',
						),
						'value'      => $this->get_option( $field, 'map_provider', $defaults['map_provider'] ),
					)
				);
				?>
			</td>
		</tr>
		<tr class="field_option field_option_<?php echo esc_attr( $this->name ); ?>">
			<td class="label">
				<label>
					<?php esc_html_e( 'Center', 'admin-site-enhancements' ); ?>
					<div class="cfgroup_tooltip">?
						<div class="tooltip_inner"><?php esc_html_e( 'Center the initial map', 'admin-site-enhancements' ); ?></div>
					</div>
				</label>
			</td>
			<td>
				<div class="cfgroup-map-center-inputs">
					<label class="cfgroup-map-center-lat">
						<span class="cfgroup-map-input-prefix"><?php esc_html_e( 'Latitude', 'admin-site-enhancements' ); ?></span>
						<input type="text" name="cfgroup[fields][<?php echo esc_attr( $key ); ?>][options][center_lat]" value="<?php echo esc_attr( $this->get_option( $field, 'center_lat', $defaults['center_lat'] ) ); ?>" />
					</label>
					<label class="cfgroup-map-center-lng">
						<span class="cfgroup-map-input-prefix"><?php esc_html_e( 'Longitude', 'admin-site-enhancements' ); ?></span>
						<input type="text" name="cfgroup[fields][<?php echo esc_attr( $key ); ?>][options][center_lng]" value="<?php echo esc_attr( $this->get_option( $field, 'center_lng', $defaults['center_lng'] ) ); ?>" />
					</label>
				</div>
			</td>
		</tr>
		<tr class="field_option field_option_<?php echo esc_attr( $this->name ); ?>">
			<td class="label">
				<label>
					<?php esc_html_e( 'Zoom', 'admin-site-enhancements' ); ?>
					<div class="cfgroup_tooltip">?
						<div class="tooltip_inner"><?php esc_html_e( 'Set the initial zoom level', 'admin-site-enhancements' ); ?></div>
					</div>
				</label>
			</td>
			<td>
				<input type="number" min="1" max="21" step="1" name="cfgroup[fields][<?php echo esc_attr( $key ); ?>][options][zoom]" value="<?php echo esc_attr( $this->get_option( $field, 'zoom', $defaults['zoom'] ) ); ?>" />
			</td>
		</tr>
		<tr class="field_option field_option_<?php echo esc_attr( $this->name ); ?>">
			<td class="label">
				<label>
					<?php esc_html_e( 'Height', 'admin-site-enhancements' ); ?>
					<div class="cfgroup_tooltip">?
						<div class="tooltip_inner"><?php esc_html_e( 'Customise the map height', 'admin-site-enhancements' ); ?></div>
					</div>
				</label>
			</td>
			<td>
				<label class="cfgroup-map-height-input">
					<input type="number" min="100" max="2000" step="1" name="cfgroup[fields][<?php echo esc_attr( $key ); ?>][options][height]" value="<?php echo esc_attr( $this->get_option( $field, 'height', $defaults['height'] ) ); ?>" />
					<span class="cfgroup-map-input-suffix"><?php esc_html_e( 'px', 'admin-site-enhancements' ); ?></span>
				</label>
			</td>
		</tr>
		<tr class="field_option field_option_<?php echo esc_attr( $this->name ); ?>">
			<td>
				<label>
					<?php esc_html_e( 'Custom Address', 'admin-site-enhancements' ); ?>
					<div class="cfgroup_tooltip">?
						<div class="tooltip_inner"><?php esc_html_e( 'When enabled, editors can enter a custom address text that overrides the geocoded address for frontend and get_cf() output (useful when OSM/Google Maps order or detail differs from local usage).', 'admin-site-enhancements' ); ?></div>
					</div>
				</label>
			</td>
			<td>
				<?php
				CFG()->create_field(
					array(
						'type'        => 'true_false',
						'input_name'  => "cfgroup[fields][$key][options][allow_custom_address]",
						'input_class' => 'true_false',
						'value'       => $this->get_option( $field, 'allow_custom_address', $defaults['allow_custom_address'] ),
						'options'     => array(
							'message' => __( 'Allow custom address text', 'admin-site-enhancements' ),
						),
					)
				);
				?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Sanitize field definition options on CFG save.
	 *
	 * @param array $field Field definition.
	 * @return array
	 */
	function pre_save_field( $field ) {
		$defaults = self::default_options();

		if ( ! isset( $field['options'] ) || ! is_array( $field['options'] ) ) {
			$field['options'] = array();
		}

		$provider = isset( $field['options']['map_provider'] ) ? $field['options']['map_provider'] : $defaults['map_provider'];
		$field['options']['map_provider'] = in_array( $provider, array( 'openstreetmap', 'google_maps' ), true )
			? $provider
			: $defaults['map_provider'];

		$field['options']['center_lat'] = isset( $field['options']['center_lat'] )
			? $this->sanitize_coordinate( $field['options']['center_lat'], $defaults['center_lat'] )
			: $defaults['center_lat'];

		$field['options']['center_lng'] = isset( $field['options']['center_lng'] )
			? $this->sanitize_coordinate( $field['options']['center_lng'], $defaults['center_lng'] )
			: $defaults['center_lng'];

		$zoom = isset( $field['options']['zoom'] ) ? absint( $field['options']['zoom'] ) : (int) $defaults['zoom'];
		$field['options']['zoom'] = (string) max( 1, min( 21, $zoom ) );

		$height = isset( $field['options']['height'] ) ? absint( $field['options']['height'] ) : (int) $defaults['height'];
		$field['options']['height'] = (string) max( 100, min( 2000, $height ? $height : (int) $defaults['height'] ) );

		$field['options']['allow_custom_address'] = ! empty( $field['options']['allow_custom_address'] ) ? '1' : '0';

		return $field;
	}

	/**
	 * Render the map input UI.
	 *
	 * @param object $field Field object.
	 */
	function html( $field ) {
		$defaults = self::default_options();
		$value    = is_array( $field->value ) ? $field->value : array();

		$address = isset( $value['address'] ) ? (string) $value['address'] : '';
		$lat     = isset( $value['latitude'] ) ? (string) $value['latitude'] : '';
		$lng     = isset( $value['longitude'] ) ? (string) $value['longitude'] : '';
		$zoom    = isset( $value['zoom'] ) ? (string) $value['zoom'] : '';

		$provider   = $this->get_option( $field, 'map_provider', $defaults['map_provider'] );
		$provider   = in_array( $provider, array( 'openstreetmap', 'google_maps' ), true ) ? $provider : $defaults['map_provider'];
		$center_lat = $this->get_option( $field, 'center_lat', $defaults['center_lat'] );
		$center_lng = $this->get_option( $field, 'center_lng', $defaults['center_lng'] );
		$init_zoom  = $this->get_option( $field, 'zoom', $defaults['zoom'] );
		$height     = absint( $this->get_option( $field, 'height', $defaults['height'] ) );
		$height     = $height ? $height : (int) $defaults['height'];
		$allow_custom = ! empty( $this->get_option( $field, 'allow_custom_address', $defaults['allow_custom_address'] ) );
		$custom_address = isset( $value['custom_address'] ) ? (string) $value['custom_address'] : '';

		self::$needed_providers[ $provider ] = true;

		$has_google_key = ( '' !== $this->get_google_maps_api_key() );
		$missing_key    = ( 'google_maps' === $provider && ! $has_google_key );

		$map_id = 'cfgroup-map-' . substr( md5( (string) $field->input_name ), 0, 12 );
		?>
		<div
			class="cfgroup-map"
			id="<?php echo esc_attr( $map_id ); ?>"
			data-map-provider="<?php echo esc_attr( $provider ); ?>"
			data-center-lat="<?php echo esc_attr( $center_lat ); ?>"
			data-center-lng="<?php echo esc_attr( $center_lng ); ?>"
			data-zoom="<?php echo esc_attr( $init_zoom ); ?>"
			data-height="<?php echo esc_attr( (string) $height ); ?>"
			<?php if ( $allow_custom ) : ?>
			data-allow-custom-address="1"
			<?php endif; ?>
		>
			<?php if ( $missing_key ) : ?>
				<div class="cfgroup-map-notice notice notice-warning inline">
					<p><?php esc_html_e( 'Google Maps API key is missing. Add it under Tools → Enhancements → Custom Content Types, or switch this field to OpenStreetMap.', 'admin-site-enhancements' ); ?></p>
				</div>
			<?php endif; ?>

			<div class="cfgroup-map-search">
				<label class="screen-reader-text" for="<?php echo esc_attr( $map_id ); ?>-address"><?php esc_html_e( 'Search for address', 'admin-site-enhancements' ); ?></label>
				<input
					type="text"
					id="<?php echo esc_attr( $map_id ); ?>-address"
					class="cfgroup-map-address widefat"
					name="<?php echo esc_attr( $field->input_name ); ?>[address]"
					value="<?php echo esc_attr( $address ); ?>"
					placeholder="<?php esc_attr_e( 'Search for address…', 'admin-site-enhancements' ); ?>"
					autocomplete="off"
				/>
			</div>

			<?php if ( $allow_custom ) : ?>
				<div class="cfgroup-map-custom-address-wrap">
					<label class="cfgroup-map-custom-address-label" for="<?php echo esc_attr( $map_id ); ?>-custom-address"><?php esc_html_e( 'Custom address', 'admin-site-enhancements' ); ?></label>
					<input
						type="text"
						id="<?php echo esc_attr( $map_id ); ?>-custom-address"
						class="cfgroup-map-custom-address widefat"
						name="<?php echo esc_attr( $field->input_name ); ?>[custom_address]"
						value="<?php echo esc_attr( $custom_address ); ?>"
						placeholder="<?php esc_attr_e( 'Override the address shown on the frontend…', 'admin-site-enhancements' ); ?>"
						autocomplete="off"
					/>
				</div>
			<?php endif; ?>

			<div class="cfgroup-map-canvas" style="height:<?php echo esc_attr( (string) $height ); ?>px;"></div>

			<input type="hidden" class="cfgroup-map-latitude" name="<?php echo esc_attr( $field->input_name ); ?>[latitude]" value="<?php echo esc_attr( $lat ); ?>" />
			<input type="hidden" class="cfgroup-map-longitude" name="<?php echo esc_attr( $field->input_name ); ?>[longitude]" value="<?php echo esc_attr( $lng ); ?>" />
			<input type="hidden" class="cfgroup-map-zoom" name="<?php echo esc_attr( $field->input_name ); ?>[zoom]" value="<?php echo esc_attr( $zoom ); ?>" />

			<?php
			$optional_keys = array( 'place_name', 'street_number', 'street_name', 'city_block', 'sublocality', 'city', 'state', 'post_code', 'country' );
			foreach ( $optional_keys as $opt_key ) :
				$opt_val = isset( $value[ $opt_key ] ) ? (string) $value[ $opt_key ] : '';
				?>
				<input type="hidden" class="cfgroup-map-meta" data-meta-key="<?php echo esc_attr( $opt_key ); ?>" name="<?php echo esc_attr( $field->input_name ); ?>[<?php echo esc_attr( $opt_key ); ?>]" value="<?php echo esc_attr( $opt_val ); ?>" />
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Enqueue map assets once per page load.
	 *
	 * @param mixed $field Field object (first of type).
	 */
	function input_head( $field = null ) {
		if ( self::$assets_prepared ) {
			return;
		}
		self::$assets_prepared = true;

		if ( null !== $field && is_object( $field ) ) {
			$provider = $this->get_option( $field, 'map_provider', 'openstreetmap' );
			if ( in_array( $provider, array( 'openstreetmap', 'google_maps' ), true ) ) {
				self::$needed_providers[ $provider ] = true;
			}
		}

		$this->enqueue_assets();

		// Late pass: include providers discovered while rendering other map fields.
		add_action( 'admin_footer', array( $this, 'enqueue_provider_scripts' ), 5 );
		add_action( 'wp_footer', array( $this, 'enqueue_provider_scripts' ), 5 );
	}

	/**
	 * Enqueue shared map CSS/JS and localize config.
	 *
	 * @return void
	 */
	public function enqueue_assets() {
		$version = defined( 'ASENHA_VERSION' ) ? ASENHA_VERSION : '1.0.0';

		wp_enqueue_style(
			'asenha-cfgroup-leaflet',
			CFG_URL . '/assets/vendor/leaflet/leaflet.css',
			array(),
			'1.9.4'
		);

		wp_enqueue_script(
			'asenha-cfgroup-leaflet',
			CFG_URL . '/assets/vendor/leaflet/leaflet.js',
			array(),
			'1.9.4',
			true
		);

		wp_enqueue_style(
			'asenha-cfgroup-map',
			CFG_URL . '/assets/css/cfg-map.css',
			array( 'asenha-cfgroup-leaflet' ),
			$version
		);

		wp_enqueue_script(
			'asenha-cfgroup-map',
			CFG_URL . '/assets/js/cfg-map.js',
			array( 'jquery', 'asenha-cfgroup-leaflet' ),
			$version,
			true
		);

		$google_key = $this->get_google_maps_api_key();

		wp_localize_script(
			'asenha-cfgroup-map',
			'asenhaCfgMap',
			array(
				'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
				'geocodeNonce'  => wp_create_nonce( 'asenha_cfgroup_map_geocode' ),
				'geocodeAction' => 'asenha_cfgroup_map_geocode',
				'googleApiKey'  => $google_key,
				'i18n'          => array(
					'searchPlaceholder' => __( 'Search for address…', 'admin-site-enhancements' ),
					'geocodeError'      => __( 'Could not find that address. Try a different search.', 'admin-site-enhancements' ),
					'missingGoogleKey'  => __( 'Google Maps API key is missing.', 'admin-site-enhancements' ),
					'searching'         => __( 'Searching…', 'admin-site-enhancements' ),
					'noResults'         => __( 'No places found', 'admin-site-enhancements' ),
					/* translators: Prefix shown beside the map field label when a place/POI name is set. */
					'placeNamePrefix'   => __( 'Place name:', 'admin-site-enhancements' ),
				),
			)
		);

		$this->enqueue_provider_scripts();
	}

	/**
	 * Enqueue Google Maps JS when needed and a key is available.
	 *
	 * @return void
	 */
	public function enqueue_provider_scripts() {
		static $google_enqueued = false;

		$needs_google = ! empty( self::$needed_providers['google_maps'] );
		$google_key   = $this->get_google_maps_api_key();

		if ( $needs_google && '' !== $google_key && ! $google_enqueued ) {
			$google_enqueued = true;
			$maps_url        = add_query_arg(
				array(
					'key'       => $google_key,
					'libraries' => 'places',
					'v'         => 'weekly',
				),
				'https://maps.googleapis.com/maps/api/js'
			);

			wp_enqueue_script(
				'asenha-cfgroup-google-maps',
				$maps_url,
				array(),
				null,
				true
			);
		}
	}

	/**
	 * Nominatim geocode/reverse-geocode AJAX proxy.
	 *
	 * @return void
	 */
	public function ajax_geocode() {
		if ( ! check_ajax_referer( 'asenha_cfgroup_map_geocode', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'invalid_nonce' ), 403 );
		}

		if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}

		$mode = isset( $_REQUEST['mode'] ) ? sanitize_key( wp_unslash( $_REQUEST['mode'] ) ) : 'search';

		if ( 'reverse' === $mode ) {
			$lat = isset( $_REQUEST['lat'] ) ? (float) wp_unslash( $_REQUEST['lat'] ) : 0;
			$lng = isset( $_REQUEST['lng'] ) ? (float) wp_unslash( $_REQUEST['lng'] ) : 0;

			$url = add_query_arg(
				array(
					'format'         => 'jsonv2',
					'lat'            => $lat,
					'lon'            => $lng,
					'addressdetails' => 1,
				),
				'https://nominatim.openstreetmap.org/reverse'
			);
		} else {
			$query = isset( $_REQUEST['q'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['q'] ) ) : '';

			if ( '' === $query ) {
				wp_send_json_error( array( 'message' => 'empty_query' ), 400 );
			}

			$url = add_query_arg(
				array(
					'format'         => 'jsonv2',
					'q'              => $query,
					'addressdetails' => 1,
					'limit'          => 5,
				),
				'https://nominatim.openstreetmap.org/search'
			);
		}

		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 8,
				'headers' => array(
					'User-Agent' => 'AdminSiteEnhancements/' . ( defined( 'ASENHA_VERSION' ) ? ASENHA_VERSION : '1.0' ) . '; ' . home_url( '/' ),
					'Accept'     => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( array( 'message' => $response->get_error_message() ), 500 );
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( 200 !== (int) $code || null === $data ) {
			wp_send_json_error( array( 'message' => 'bad_response' ), 502 );
		}

		$results = array();

		if ( 'reverse' === $mode ) {
			$results[] = $this->normalize_nominatim_result( $data );
		} else {
			foreach ( (array) $data as $item ) {
				$normalized = $this->normalize_nominatim_result( $item );
				if ( ! empty( $normalized ) ) {
					$results[] = $normalized;
				}
			}
		}

		wp_send_json_success( array( 'results' => $results ) );
	}

	/**
	 * Normalize a Nominatim result into CFG map value keys.
	 *
	 * @param array $item Nominatim item.
	 * @return array
	 */
	private function normalize_nominatim_result( $item ) {
		if ( ! is_array( $item ) ) {
			return array();
		}

		$address_parts = isset( $item['address'] ) && is_array( $item['address'] ) ? $item['address'] : array();

		$city = '';
		if ( ! empty( $address_parts['city'] ) ) {
			$city = (string) $address_parts['city'];
		} elseif ( ! empty( $address_parts['town'] ) ) {
			$city = (string) $address_parts['town'];
		} elseif ( ! empty( $address_parts['village'] ) ) {
			$city = (string) $address_parts['village'];
		}

		$neighbourhood_keys = array( 'neighbourhood', 'residential', 'hamlet', 'allotments', 'isolated_dwelling', 'quarter', 'suburb', 'city_district', 'district', 'borough' );
		$neighbourhood_parts = array();
		$seen               = array();
		foreach ( $neighbourhood_keys as $n_key ) {
			if ( empty( $address_parts[ $n_key ] ) ) {
				continue;
			}
			$label = trim( (string) $address_parts[ $n_key ] );
			if ( '' === $label ) {
				continue;
			}
			if ( '' !== $city && 0 === strcasecmp( $label, $city ) ) {
				continue;
			}
			$lower = strtolower( $label );
			if ( isset( $seen[ $lower ] ) ) {
				continue;
			}
			$seen[ $lower ]        = true;
			$neighbourhood_parts[] = $label;
		}

		$place_name = '';
		if ( ! empty( $item['name'] ) ) {
			$place_name = trim( (string) $item['name'] );
		} else {
			$poi_keys = array( 'amenity', 'shop', 'tourism', 'office', 'leisure', 'craft', 'club', 'building', 'house_name' );
			foreach ( $poi_keys as $poi_key ) {
				if ( empty( $address_parts[ $poi_key ] ) ) {
					continue;
				}
				$poi_label = trim( (string) $address_parts[ $poi_key ] );
				if ( '' !== $poi_label ) {
					$place_name = $poi_label;
					break;
				}
			}
		}

		$display_name = isset( $item['display_name'] ) ? (string) $item['display_name'] : '';
		$state        = $this->resolve_nominatim_state( $address_parts, $display_name, $place_name );

		return array(
			'address'       => $display_name,
			'latitude'      => isset( $item['lat'] ) ? (string) $item['lat'] : '',
			'longitude'     => isset( $item['lon'] ) ? (string) $item['lon'] : '',
			'place_name'    => $place_name,
			'street_number' => isset( $address_parts['house_number'] ) ? (string) $address_parts['house_number'] : '',
			'street_name'   => isset( $address_parts['road'] ) ? (string) $address_parts['road'] : '',
			'city_block'    => isset( $address_parts['city_block'] ) ? (string) $address_parts['city_block'] : '',
			'sublocality'   => ! empty( $neighbourhood_parts ) ? implode( ', ', $neighbourhood_parts ) : '',
			'city'          => $city,
			'state'         => $state,
			'post_code'     => isset( $address_parts['postcode'] ) ? (string) $address_parts['postcode'] : '',
			'country'       => isset( $address_parts['country'] ) ? (string) $address_parts['country'] : '',
		);
	}

	/**
	 * Resolve state from Nominatim address keys, then display_name residual.
	 *
	 * Some places (e.g. Jakarta) only expose ISO3166-2-lvl* without a named
	 * state/region key; the human-readable name still appears in display_name.
	 *
	 * @param array  $address_parts Nominatim address object.
	 * @param string $display_name  Full display_name string.
	 * @param string $place_name    Resolved place name.
	 * @return string
	 */
	private function resolve_nominatim_state( $address_parts, $display_name, $place_name = '' ) {
		if ( ! is_array( $address_parts ) ) {
			$address_parts = array();
		}

		foreach ( array( 'state', 'region', 'province', 'state_district' ) as $key ) {
			if ( empty( $address_parts[ $key ] ) ) {
				continue;
			}
			$label = trim( (string) $address_parts[ $key ] );
			if ( '' !== $label ) {
				return $label;
			}
		}

		return $this->extract_state_from_display_name( $display_name, $address_parts, $place_name );
	}

	/**
	 * Recover a missing state label from Nominatim display_name.
	 *
	 * Walks comma-separated segments from the end, skipping country/postcode
	 * and any label already present in the address object (or place_name).
	 *
	 * @param string $display_name  Full display_name string.
	 * @param array  $address_parts Nominatim address object.
	 * @param string $place_name    Resolved place name.
	 * @return string
	 */
	private function extract_state_from_display_name( $display_name, $address_parts, $place_name = '' ) {
		$display_name = trim( (string) $display_name );
		if ( '' === $display_name ) {
			return '';
		}

		if ( ! is_array( $address_parts ) ) {
			$address_parts = array();
		}

		$accounted = array();
		foreach ( $address_parts as $val ) {
			if ( ! is_scalar( $val ) ) {
				continue;
			}
			$label = trim( (string) $val );
			if ( '' === $label ) {
				continue;
			}
			$accounted[ strtolower( $label ) ] = true;
		}

		$place_name = trim( (string) $place_name );
		if ( '' !== $place_name ) {
			$accounted[ strtolower( $place_name ) ] = true;
		}

		$country  = ! empty( $address_parts['country'] ) ? trim( (string) $address_parts['country'] ) : '';
		$postcode = ! empty( $address_parts['postcode'] ) ? trim( (string) $address_parts['postcode'] ) : '';

		$segments = array_map( 'trim', explode( ',', $display_name ) );
		for ( $i = count( $segments ) - 1; $i >= 0; $i-- ) {
			$segment = $segments[ $i ];
			if ( '' === $segment ) {
				continue;
			}
			if ( '' !== $country && 0 === strcasecmp( $segment, $country ) ) {
				continue;
			}
			if ( '' !== $postcode && 0 === strcasecmp( $segment, $postcode ) ) {
				continue;
			}
			if ( isset( $accounted[ strtolower( $segment ) ] ) ) {
				continue;
			}
			return $segment;
		}

		return '';
	}

	/**
	 * Prepare value for save.
	 *
	 * @param mixed $value Submitted value.
	 * @param mixed $field Field object.
	 * @return string Serialized array.
	 */
	function pre_save( $value, $field = null ) {
		// Repeater [value][] splits each map sub-key into its own numeric index
		// (0=address, 1=latitude, …). Slot 0 is address, not latitude — merge when
		// the value is still an indexed list of partial arrays.
		if ( is_array( $value )
			&& isset( $value[0] )
			&& is_array( $value[0] )
			&& ! isset( $value['address'] )
			&& ! isset( $value['latitude'] ) ) {
			$rebuilt = array();
			foreach ( $value as $part ) {
				if ( is_array( $part ) ) {
					$rebuilt = array_merge( $rebuilt, $part );
				}
			}
			$value = $rebuilt;
		}

		$normalized = $this->normalize_value_array( $value );

		return serialize( $normalized );
	}

	/**
	 * Prepare value after DB load.
	 *
	 * @param mixed $value Raw DB rows.
	 * @param mixed $field Field object.
	 * @return array
	 */
	function prepare_value( $value, $field = null ) {
		$raw   = isset( $value[0] ) ? $value[0] : '';
		$maybe = maybe_unserialize( $raw );

		return is_array( $maybe ) ? $this->normalize_value_array( $maybe ) : array();
	}

	/**
	 * Format value for API / CFG()->get().
	 *
	 * Always returns the normalized map data array. Use get_cf() for HTML / address string formats.
	 *
	 * @param mixed $value Prepared value.
	 * @param mixed $field Field object.
	 * @return array
	 */
	function format_value_for_api( $value, $field = null ) {
		return is_array( $value ) ? $this->normalize_value_array( $value ) : array();
	}

	/**
	 * Format value for display.
	 *
	 * @param mixed $value Prepared value.
	 * @param mixed $field Field object.
	 * @return array
	 */
	function format_value_for_display( $value, $field = null ) {
		return $this->format_value_for_api( $value, $field );
	}

	/**
	 * Format value for input (edit screens).
	 *
	 * @param mixed $value Prepared value.
	 * @param mixed $field Field object.
	 * @return array
	 */
	function format_value_for_input( $value, $field = null ) {
		return is_array( $value ) ? $this->normalize_value_array( $value ) : array();
	}

	/**
	 * Normalize map value keys.
	 *
	 * @param mixed $value Raw value.
	 * @return array
	 */
	private function normalize_value_array( $value ) {
		if ( ! is_array( $value ) ) {
			return array(
				'address'   => '',
				'latitude'  => '',
				'longitude' => '',
				'zoom'      => '',
			);
		}

		$out = array(
			'address'   => isset( $value['address'] ) ? sanitize_text_field( $value['address'] ) : '',
			'latitude'  => isset( $value['latitude'] ) ? $this->sanitize_coordinate( $value['latitude'], '' ) : '',
			'longitude' => isset( $value['longitude'] ) ? $this->sanitize_coordinate( $value['longitude'], '' ) : '',
			'zoom'      => isset( $value['zoom'] ) && '' !== $value['zoom'] ? (string) max( 1, min( 21, absint( $value['zoom'] ) ) ) : '',
		);

		$optional = array( 'custom_address', 'place_name', 'street_number', 'street_name', 'city_block', 'sublocality', 'city', 'state', 'post_code', 'country' );
		foreach ( $optional as $key ) {
			if ( ! empty( $value[ $key ] ) ) {
				$out[ $key ] = sanitize_text_field( $value[ $key ] );
			}
		}

		// Legacy key: promote neighbourhood → sublocality when sublocality is empty.
		if ( empty( $out['sublocality'] ) && ! empty( $value['neighbourhood'] ) ) {
			$out['sublocality'] = sanitize_text_field( $value['neighbourhood'] );
		}

		return $out;
	}

	/**
	 * Sanitize a latitude/longitude string.
	 *
	 * @param mixed  $value   Raw value.
	 * @param string $default Default when invalid.
	 * @return string
	 */
	private function sanitize_coordinate( $value, $default = '' ) {
		if ( ! is_scalar( $value ) || '' === $value ) {
			return $default;
		}

		$value = trim( (string) $value );

		if ( ! is_numeric( $value ) ) {
			return $default;
		}

		return (string) (float) $value;
	}

	/**
	 * Decrypt Google Maps API key from CCT settings.
	 *
	 * @return string
	 */
	private function get_google_maps_api_key() {
		if ( ! class_exists( '\ASENHA\Classes\CCT_Secrets' ) ) {
			$path = ASENHA_PATH . 'includes/premium/custom-content/class-cct-secrets.php';
			if ( file_exists( $path ) ) {
				require_once $path;
			}
		}

		if ( ! class_exists( '\ASENHA\Classes\CCT_Secrets' ) ) {
			return '';
		}

		$secrets = new \ASENHA\Classes\CCT_Secrets();
		return $secrets->get_google_maps_api_key();
	}
}
