<?php

class cfgroup_wysiwyg extends cfgroup_field
{

    function __construct() {
        $this->name = 'wysiwyg';
        $this->label = __( 'WYSIWYG Editor', 'admin-site-enhancements' );
    }


    /**
     * Build a unique, jQuery-safe editor ID from the field input name.
     *
     * @param string $input_name Field input name attribute.
     * @return string
     */
    private function get_editor_id( $input_name ) {
        return 'cfgwysi_' . substr( md5( $input_name ), 0, 12 );
    }


    /**
     * Whether this field is rendered inside a repeater clone buffer.
     *
     * @param string $input_name Field input name attribute.
     * @return bool
     */
    private function is_clone_field( $input_name ) {
        return false !== strpos( $input_name, '[clone]' );
    }


    /**
     * Whether this field should render as a rich editor (TinyMCE + Quicktags).
     *
     * @return bool
     */
    private function should_use_rich_editor() {
        if ( user_can_richedit() ) {
            return true;
        }

        // Frontend CFG forms historically initialized TinyMCE for guests.
        if ( ! is_user_logged_in() && ! is_admin() ) {
            return true;
        }

        return false;
    }


    /**
     * Ordered TinyMCE toolbar button IDs and labels for the Custom toolbar UI.
     *
     * @return array<string, string> Button ID => label.
     */
    private function get_toolbar_button_definitions() {
        return array(
            'bold'          => __( 'Bold', 'admin-site-enhancements' ),
            'italic'        => __( 'Italic', 'admin-site-enhancements' ),
            'underline'     => __( 'Underline', 'admin-site-enhancements' ),
            'strikethrough' => __( 'Strikethrough', 'admin-site-enhancements' ),
            'forecolor'     => __( 'Text color', 'admin-site-enhancements' ),
            'bullist'       => __( 'Bulleted list', 'admin-site-enhancements' ),
            'numlist'       => __( 'Numbered list', 'admin-site-enhancements' ),
            'alignleft'     => __( 'Align left', 'admin-site-enhancements' ),
            'aligncenter'   => __( 'Align center', 'admin-site-enhancements' ),
            'alignright'    => __( 'Align right', 'admin-site-enhancements' ),
            'link'          => __( 'Link', 'admin-site-enhancements' ),
            'charmap'       => __( 'Special character', 'admin-site-enhancements' ),
            'removeformat'  => __( 'Clear formatting', 'admin-site-enhancements' ),
            'fullscreen'    => __( 'Fullscreen', 'admin-site-enhancements' ),
        );
    }


    /**
     * Default TinyMCE toolbar1 string (all 14 buttons).
     *
     * @return string
     */
    private function get_default_toolbar1() {
        return implode( ',', array_keys( $this->get_toolbar_button_definitions() ) );
    }


    /**
     * Default button IDs checked when Custom mode has no stored selection.
     *
     * @return string[]
     */
    private function get_default_custom_toolbar_buttons() {
        return array( 'bold', 'italic' );
    }


    /**
     * Resolve toolbar1 for a field based on toolbar_mode / toolbar_buttons.
     *
     * @param object $field Field object.
     * @return string Comma-separated TinyMCE button IDs.
     */
    private function resolve_toolbar1( $field ) {
        $mode = $this->get_option( $field, 'toolbar_mode', 'default' );

        if ( 'custom' !== $mode ) {
            return $this->get_default_toolbar1();
        }

        $definitions = $this->get_toolbar_button_definitions();
        $stored      = array();

        if ( isset( $field->options['toolbar_buttons'] ) && is_array( $field->options['toolbar_buttons'] ) ) {
            $stored = $field->options['toolbar_buttons'];
        }

        $selected = array();

        foreach ( array_keys( $definitions ) as $button_id ) {
            if ( in_array( $button_id, $stored, true ) ) {
                $selected[] = $button_id;
            }
        }

        return implode( ',', $selected );
    }


    /**
     * HTML attributes for per-field toolbar override on deferred/clone editors.
     *
     * @param object $field Field object.
     * @return string Attribute string (leading space when present) or empty.
     */
    private function get_toolbar_data_attr( $field ) {
        $mode = $this->get_option( $field, 'toolbar_mode', 'default' );

        if ( 'custom' !== $mode ) {
            return '';
        }

        return ' data-toolbar-buttons="' . esc_attr( $this->resolve_toolbar1( $field ) ) . '"';
    }


    /**
     * Normalized editor tabs mode for a field.
     *
     * @param object $field Field object.
     * @return string both|visual|code
     */
    private function get_editor_tabs_mode( $field ) {
        $mode = $this->get_option( $field, 'editor_tabs', 'both' );

        return in_array( $mode, array( 'both', 'visual', 'code' ), true ) ? $mode : 'both';
    }


    /**
     * HTML attribute for Visual/Code tabs mode on deferred/clone editors.
     *
     * @param object $field Field object.
     * @return string Attribute string (always set).
     */
    private function get_editor_tabs_data_attr( $field ) {
        return ' data-editor-tabs="' . esc_attr( $this->get_editor_tabs_mode( $field ) ) . '"';
    }


    /**
     * Remove a TinyMCE plugin/button token from a comma-separated list.
     *
     * @param string $list  Comma-separated plugins or toolbar buttons.
     * @param string $token Token to remove (e.g. fullscreen).
     * @return string
     */
    private function remove_tinymce_list_token( $list, $token ) {
        $parts = array_filter(
            array_map( 'trim', explode( ',', (string) $list ) ),
            function( $part ) use ( $token ) {
                return '' !== $part && $part !== $token;
            }
        );

        return implode( ',', $parts );
    }


    /**
     * Whether the current screen is the block editor (Gutenberg).
     *
     * @return bool
     */
    private function is_block_editor_screen() {
        if ( ! function_exists( 'get_current_screen' ) ) {
            return false;
        }

        $screen = get_current_screen();

        return $screen && method_exists( $screen, 'is_block_editor' ) && $screen->is_block_editor();
    }


    /**
     * Normalize a field array/object so option helpers can read $field->options.
     *
     * @param object|array $field Field definition.
     * @return object
     */
    private function normalize_field_object( $field ) {
        if ( is_array( $field ) ) {
            $field = (object) $field;
        }

        if ( ! is_object( $field ) ) {
            $field = (object) array();
        }

        if ( ! isset( $field->options ) || ! is_array( $field->options ) ) {
            $field->options = array();
        }

        return $field;
    }


    /**
     * Data attributes for deferred/pending editors (meta-box wrappers, clones, Quick Edit).
     *
     * Encodes media button, editor tabs, and custom toolbar settings for cfg-wysiwyg.js.
     *
     * @param object|array $field Field definition (array from QE, object from meta-box).
     * @return string Attribute string including leading spaces.
     */
    public function get_pending_data_attrs( $field ) {
        $field = $this->normalize_field_object( $field );

        $hide_media = ! empty( $this->get_option( $field, 'hide_media_button' ) );
        $media_attr = $hide_media ? ' data-hide-media-button="1"' : ' data-media-buttons="1"';

        return $media_attr . $this->get_toolbar_data_attr( $field ) . $this->get_editor_tabs_data_attr( $field );
    }


    /**
     * Editor settings for wp_editor() and deferred JS initialization.
     *
     * @param object $field Field object.
     * @return array
     */
    private function get_editor_settings( $field ) {
        $media_buttons = is_user_logged_in();

        if ( ! empty( $this->get_option( $field, 'hide_media_button' ) ) ) {
            $media_buttons = false;
        }

        $tinymce = array(
            'wpautop'                       => true,
            'add_unload_trigger'            => false,
            'branding'                      => false,
            'browser_spellcheck'            => true,
            'convert_urls'                  => false,
            'end_container_on_empty_block'  => true,
            'entities'                      => '38,amp,60,lt,62,gt',
            'entity_encoding'               => 'raw',
            'fix_list_elements'             => true,
            'indent'                        => false,
            'keep_styles'                   => false,
            'menubar'                       => false,
            'plugins'                       => 'charmap,colorpicker,hr,lists,media,paste,tabfocus,textcolor,fullscreen,wordpress,wpautoresize,wpeditimage,wpgallery,wplink,wpdialogs,wptextpattern,wpview',
            'preview_styles'                => 'font-family font-size font-weight font-style text-decoration text-transform',
            'relative_urls'                 => false,
            'remove_script_host'            => false,
            'resize'                        => 'vertical',
            'skin'                          => 'lightgray',
            'theme'                         => 'modern',
            'wp_autoresize_on'              => true,
            'wp_keep_scroll_position'       => false,
            'toolbar1'                      => $this->resolve_toolbar1( $field ),
            'toolbar2'                      => '',
        );

        // TinyMCE fullscreen is unreliable inside Gutenberg meta boxes — omit it there.
        if ( $this->is_block_editor_screen() ) {
            $tinymce['plugins']  = $this->remove_tinymce_list_token( $tinymce['plugins'], 'fullscreen' );
            $tinymce['toolbar1'] = $this->remove_tinymce_list_token( $tinymce['toolbar1'], 'fullscreen' );
        }

        $quicktags    = true;
        $editor_tabs  = $this->get_editor_tabs_mode( $field );

        if ( 'visual' === $editor_tabs ) {
            $quicktags = false;
        } elseif ( 'code' === $editor_tabs ) {
            $tinymce   = false;
            $quicktags = true;
        }

        $settings = array(
            'textarea_name' => $field->input_name,
            'textarea_rows' => 8,
            'editor_height' => 300,
            'media_buttons' => $media_buttons,
            'quicktags'     => $quicktags,
            'wpautop'       => true,
            'editor_class'  => 'wysiwyg',
            'tinymce'       => $tinymce,
        );

        return $settings;
    }


    /**
     * Editor settings passed to cfg-wysiwyg.js for wp.editor.initialize().
     *
     * @return array
     */
    private function get_js_editor_settings() {
        $dummy_field = (object) array( 'input_name' => '' );
        $settings    = $this->get_editor_settings( $dummy_field );

        return array(
            'tinymce'      => $settings['tinymce'],
            'quicktags'    => true,
            'mediaButtons' => $settings['media_buttons'],
        );
    }


    function html( $field ) {
        $field_value = isset( $field->value ) ? $field->value : '';

        if ( ! $this->should_use_rich_editor() ) {
            ?>
            <textarea name="<?php echo esc_attr( $field->input_name ); ?>" class="wysiwyg <?php echo esc_attr( $field->input_class ); ?>" rows="8" style="width:100%;height:200px"><?php echo esc_textarea( $field_value ); ?></textarea>
            <?php
            return;
        }

        if ( $this->is_clone_field( $field->input_name ) ) {
            $field_attrs = $this->get_pending_data_attrs( $field );
            ?>
            <div class="cfg-wysiwyg-pending"<?php echo $field_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in get_pending_data_attrs() ?>>
                <textarea name="<?php echo esc_attr( $field->input_name ); ?>" class="wysiwyg wp-editor-area <?php echo esc_attr( $field->input_class ); ?>" rows="8"<?php echo $field_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in get_pending_data_attrs() ?>><?php echo esc_textarea( $field_value ); ?></textarea>
            </div>
            <?php
            return;
        }

        $editor_id   = $this->get_editor_id( $field->input_name );
        $field_attrs = $this->get_pending_data_attrs( $field );
        ?>
        <div class="cfg-wysiwyg-editor"<?php echo $field_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in get_pending_data_attrs() ?>>
            <?php
            wp_editor(
                $field_value,
                $editor_id,
                $this->get_editor_settings( $field )
            );
            ?>
        </div>
        <?php
    }


    function options_html( $key, $field ) {
    ?>
        <tr class="field_option field_option_<?php echo $this->name; ?>">
            <td class="label">
                <label><?php _e( 'Formatting', 'admin-site-enhancements' ); ?></label>
            </td>
            <td>
                <?php
                    CFG()->create_field( [
                        'type' => 'select',
                        'input_name' => "cfgroup[fields][$key][options][formatting]",
                        'options' => [
                            'choices' => [
                                'default' => __( 'Default', 'admin-site-enhancements' ),
                                'none' => __( 'None (bypass filters)', 'admin-site-enhancements' )
                            ],
                            'force_single' => true,
                        ],
                        'value' => $this->get_option( $field, 'formatting', 'default' ),
                    ] );
                ?>
            </td>
        </tr>
        <tr class="field_option field_option_<?php echo $this->name; ?>">
            <td>
                <label>
                    <?php _e( 'Paragraph output', 'admin-site-enhancements' ); ?>
                    <div class="cfgroup_tooltip">?
                        <div class="tooltip_inner"><?php
                            // translators: Tooltip for the Paragraph output option in Custom Field Groups WYSIWYG field settings.
                            _e( 'Useful to prevent paragraph tags from overriding styling applied to the wrapper element, e.g. by page builders.', 'admin-site-enhancements' );
                        ?></div>
                    </div>
                </label>
            </td>
            <td>
                <?php
                    CFG()->create_field( [
                        'type' => 'true_false',
                        'input_name' => "cfgroup[fields][$key][options][use_double_br_for_paragraphs]",
                        'input_class' => 'true_false',
                        'value' => $this->get_option( $field, 'use_double_br_for_paragraphs' ),
                        'options' => [
                            // translators: WYSIWYG field option shown beside a checkbox in Custom Field Groups.
                            'message' => __( 'Use double line breaks instead of paragraph tags', 'admin-site-enhancements' ),
                        ],
                    ] );
                ?>
            </td>
        </tr>
        <tr class="field_option field_option_<?php echo $this->name; ?>">
            <td class="label validation-label">
                <label><?php _e( 'Media button', 'admin-site-enhancements' ); ?></label>
            </td>
            <td>
                <?php
                    CFG()->create_field( [
                        'type' => 'true_false',
                        'input_name' => "cfgroup[fields][$key][options][hide_media_button]",
                        'input_class' => 'true_false',
                        'value' => $this->get_option( $field, 'hide_media_button' ),
                        'options' => [
                            // translators: WYSIWYG field option shown beside a checkbox in Custom Field Groups.
                            'message' => __( 'Do not display the media button', 'admin-site-enhancements' ),
                        ],
                    ] );
                ?>
            </td>
        </tr>
        <?php
            $editor_tabs = $this->get_editor_tabs_mode( $field );
        ?>
        <tr class="field_option field_option_<?php echo $this->name; ?> field_option_wysiwyg_editor_tabs">
            <td>
                <label><?php _e( 'Editor tabs', 'admin-site-enhancements' ); ?></label>
            </td>
            <td>
                <div class="cfgroup-wysiwyg-editor-tabs-radios">
                    <label>
                        <input type="radio" class="cfgroup-wysiwyg-editor-tabs" name="cfgroup[fields][<?php echo esc_attr( $key ); ?>][options][editor_tabs]" value="both"<?php checked( $editor_tabs, 'both' ); ?> />
                        <?php _e( 'Both', 'admin-site-enhancements' ); ?>
                    </label>
                    <label>
                        <input type="radio" class="cfgroup-wysiwyg-editor-tabs" name="cfgroup[fields][<?php echo esc_attr( $key ); ?>][options][editor_tabs]" value="visual"<?php checked( $editor_tabs, 'visual' ); ?> />
                        <?php _e( 'Visual', 'admin-site-enhancements' ); ?>
                    </label>
                    <label>
                        <input type="radio" class="cfgroup-wysiwyg-editor-tabs" name="cfgroup[fields][<?php echo esc_attr( $key ); ?>][options][editor_tabs]" value="code"<?php checked( $editor_tabs, 'code' ); ?> />
                        <?php _e( 'Code', 'admin-site-enhancements' ); ?>
                    </label>
                </div>
            </td>
        </tr>
        <?php
            $toolbar_mode = $this->get_option( $field, 'toolbar_mode', 'default' );
            $toolbar_mode = in_array( $toolbar_mode, array( 'default', 'custom' ), true ) ? $toolbar_mode : 'default';
        ?>
        <tr class="field_option field_option_<?php echo $this->name; ?> field_option_wysiwyg_toolbar">
            <td>
                <label><?php _e( 'Toolbar', 'admin-site-enhancements' ); ?></label>
            </td>
            <td>
                <div class="cfgroup-wysiwyg-toolbar-mode-radios">
                    <label>
                        <input type="radio" class="cfgroup-wysiwyg-toolbar-mode" name="cfgroup[fields][<?php echo esc_attr( $key ); ?>][options][toolbar_mode]" value="default"<?php checked( $toolbar_mode, 'default' ); ?> />
                        <?php _e( 'Default', 'admin-site-enhancements' ); ?>
                    </label>
                    <label>
                        <input type="radio" class="cfgroup-wysiwyg-toolbar-mode" name="cfgroup[fields][<?php echo esc_attr( $key ); ?>][options][toolbar_mode]" value="custom"<?php checked( $toolbar_mode, 'custom' ); ?> />
                        <?php _e( 'Custom', 'admin-site-enhancements' ); ?>
                    </label>
                </div>
                <div class="cfgroup-wysiwyg-toolbar-buttons-wrap"<?php echo ( 'custom' === $toolbar_mode ) ? '' : ' style="display:none;"'; ?>>
                    <?php $this->render_toolbar_button_checkboxes( $key, $field ); ?>
                </div>
            </td>
        </tr>
        <tr class="field_option field_option_<?php echo $this->name; ?>">
            <td class="label validation-label">
                <label><?php _e( 'Validation', 'admin-site-enhancements' ); ?></label>
            </td>
            <td>
                <?php
                    CFG()->create_field( [
                        'type' => 'true_false',
                        'input_name' => "cfgroup[fields][$key][options][required]",
                        'input_class' => 'true_false',
                        'value' => $this->get_option( $field, 'required' ),
                        'options' => [ 'message' => __( 'This is a required field', 'admin-site-enhancements' ) ],
                    ] );
                ?>
            </td>
        </tr>
    <?php
    }


    /**
     * Render the Custom toolbar button checkbox grid (two columns).
     *
     * @param int|string $key   Field array key.
     * @param object     $field Field object.
     */
    function render_toolbar_button_checkboxes( $key, $field ) {
        $definitions = $this->get_toolbar_button_definitions();
        $button_ids  = array_keys( $definitions );

        if ( isset( $field->options['toolbar_buttons'] ) && is_array( $field->options['toolbar_buttons'] ) ) {
            $stored = array_values(
                array_intersect(
                    $button_ids,
                    array_map( 'sanitize_key', $field->options['toolbar_buttons'] )
                )
            );
        } else {
            $stored = $this->get_default_custom_toolbar_buttons();
        }

        $input_name = "cfgroup[fields][$key][options][toolbar_buttons][]";
        $col1       = array_slice( $button_ids, 0, 7 );
        $col2       = array_slice( $button_ids, 7, 7 );
        ?>
        <div class="cfgroup-wysiwyg-toolbar-buttons">
            <div class="cfgroup-wysiwyg-toolbar-buttons-col">
                <?php foreach ( $col1 as $button_id ) : ?>
                    <label>
                        <input type="checkbox" name="<?php echo esc_attr( $input_name ); ?>" value="<?php echo esc_attr( $button_id ); ?>" class="cfgroup-wysiwyg-toolbar-button"<?php checked( in_array( $button_id, $stored, true ) ); ?> />
                        <?php echo esc_html( $definitions[ $button_id ] ); ?>
                    </label>
                <?php endforeach; ?>
            </div>
            <div class="cfgroup-wysiwyg-toolbar-buttons-col">
                <?php foreach ( $col2 as $button_id ) : ?>
                    <label>
                        <input type="checkbox" name="<?php echo esc_attr( $input_name ); ?>" value="<?php echo esc_attr( $button_id ); ?>" class="cfgroup-wysiwyg-toolbar-button"<?php checked( in_array( $button_id, $stored, true ) ); ?> />
                        <?php echo esc_html( $definitions[ $button_id ] ); ?>
                    </label>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }


    /**
     * Sanitize editor_tabs, toolbar_mode, and toolbar_buttons before saving the field definition.
     *
     * @param array $field Field definition array.
     * @return array
     */
    function pre_save_field( $field ) {
        $editor_tabs = isset( $field['options']['editor_tabs'] ) ? $field['options']['editor_tabs'] : 'both';
        $editor_tabs = in_array( $editor_tabs, array( 'both', 'visual', 'code' ), true ) ? $editor_tabs : 'both';
        $field['options']['editor_tabs'] = $editor_tabs;

        $mode = isset( $field['options']['toolbar_mode'] ) ? $field['options']['toolbar_mode'] : 'default';
        $mode = in_array( $mode, array( 'default', 'custom' ), true ) ? $mode : 'default';
        $field['options']['toolbar_mode'] = $mode;

        if ( 'default' === $mode ) {
            unset( $field['options']['toolbar_buttons'] );
            return $field;
        }

        $valid_buttons = array_keys( $this->get_toolbar_button_definitions() );
        $submitted     = isset( $field['options']['toolbar_buttons'] ) ? (array) $field['options']['toolbar_buttons'] : array();
        $submitted     = array_map( 'sanitize_key', $submitted );
        $field['options']['toolbar_buttons'] = array_values( array_intersect( $valid_buttons, $submitted ) );

        return $field;
    }


    function input_head( $field = null ) {

        $needs_assets = $this->should_use_rich_editor();

        // Logged-in users with Visual Editor disabled in their profile do not need editor assets.
        if ( is_user_logged_in() && 'true' != get_user_meta( get_current_user_id(), 'rich_editing', true ) ) {
            $needs_assets = false;
        }

        if ( ! $needs_assets ) {
            return;
        }

        if ( function_exists( 'wp_enqueue_editor' ) ) {
            wp_enqueue_editor();
        }

        wp_enqueue_script(
            'cfg-wysiwyg',
            CFG_URL . '/assets/js/cfg-wysiwyg.js',
            array( 'jquery', 'editor', 'quicktags', 'wp-util', 'media-upload' ),
            CFG_VERSION,
            true
        );

        wp_localize_script(
            'cfg-wysiwyg',
            'cfgWysiwygL10n',
            array(
                'editorSettings' => $this->get_js_editor_settings(),
                'contentCss'     => includes_url( 'css/dashicons.css' ) . ',' . includes_url( 'js/tinymce/skins/wordpress/wp-content.css' ),
            )
        );
    }


    function format_value_for_input( $value, $field = null ) {
        // Return raw HTML; wp_editor() applies format_for_editor() once via the_editor_content.
        return $value;
    }


    function format_value_for_api( $value, $field = null ) {
        if ( ! is_null( $field ) && property_exists( $field, 'option_pages' ) ) {
            if ( ! empty( $field->option_pages ) ) {
                // This WYSIWYG field is part of an option page, let's bypass filters and return content as is
                $formatting = 'none';
            } else {
                $formatting = $this->get_option( $field, 'formatting', 'default' );
            }
        } else {
            $formatting = $this->get_option( $field, 'formatting', 'default' );
        }

        $use_double_br_opt = $this->get_option( $field, 'use_double_br_for_paragraphs', '' );
        $use_double_br     = ! empty( $use_double_br_opt );

        if ( 'none' === $formatting ) {
            if ( ! $use_double_br ) {
                return $value;
            }
            if ( ! is_string( $value ) ) {
                return $value;
            }
            // None (bypass filters): no wpautop, no do_shortcode — only replace paragraph boundaries with double br (best-effort for nested blocks).
            return $this->convert_paragraphs_to_double_br( $value );
        }

        if ( ! is_string( $value ) ) {
            return $value;
        }

        if ( ! $use_double_br ) {
            return do_shortcode( wpautop( $value ) );
        }

        $html = wpautop( $value );
        $html = $this->convert_paragraphs_to_double_br( $html );

        return do_shortcode( $html );
    }

    /**
     * Replace paragraph boundaries with double line breaks for page-builder-friendly output.
     *
     * Best-effort: nested blocks (e.g. blockquotes with multiple paragraphs) may be affected.
     *
     * @param string $html HTML from TinyMCE or after wpautop().
     * @return string
     */
    private function convert_paragraphs_to_double_br( $html ) {
        if ( ! is_string( $html ) || '' === $html ) {
            return $html;
        }

        $html = trim( $html );
        // Adjacent paragraph blocks.
        $html = preg_replace( '#</p>\s*<p(\s[^>]*)?>#i', '<br /><br />', $html );
        // Unwrap a single outer wrapping pair.
        $html = preg_replace( '#^\s*<p(\s[^>]*)?>#i', '', $html );
        $html = preg_replace( '#</p>\s*$#i', '', $html );

        return $html;
    }


    function format_value_for_display( $value, $field = null ) {
        return $this->format_value_for_api( $value, $field );
    }
}
