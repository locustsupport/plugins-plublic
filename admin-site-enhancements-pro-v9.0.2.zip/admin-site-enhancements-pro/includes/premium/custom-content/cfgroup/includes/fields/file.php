<?php

class cfgroup_file extends cfgroup_field
{

    function __construct() {
        $this->name = 'file';
        $this->label = __( 'File / Media', 'admin-site-enhancements' );

        add_filter( 'wp_handle_upload_prefilter', 'cfg_file_field_upload_prefilter' );
    }


    function html( $field ) {
        $file_url = ! is_null( $field->value ) ? $field->value : '';

        if ( ctype_digit( $file_url ) ) {
            if ( wp_attachment_is_image( $file_url ) ) {
                if ( isset( $field->options['image_preview_size'] ) && ! empty( $field->options['image_preview_size'] ) ) {
                    $image_size = $field->options['image_preview_size'];
                } else {
                    $image_size = 'medium';
                }

                $file_url = wp_get_attachment_image_src( $file_url, $image_size );
                $file_url = '<img src="' . $file_url[0] . '" />';
            }
            else
            {
                $file_url = wp_get_attachment_url( $file_url );
                $filename = substr( $file_url, strrpos( $file_url, '/' ) + 1 );
                $file_url = '<a href="'. $file_url .'" target="_blank">'. $filename .'</a>';
            }
        }

        // Attributes for disabling buttons for logged-out users
        if ( ! is_user_logged_in() ) {
            $disabled_class = ' disabled';
            $disabled = ' disabled="disabled"';
        } else {
            $disabled_class = '';
            $disabled = '';
        }

        // CSS logic for "Add" / "Remove" buttons
        $css = empty( $field->value ) ? [ '', ' hidden' ] : [ ' hidden', '' ];

        $allowed_mimes      = cfg_file_field_get_effective_allowed_mimes( $field );
        $allowed_extensions = cfg_file_field_get_effective_allowed_extensions( $field );
        $allowed_mime_mode  = isset( $field->options['allowed_mime_mode'] ) ? $field->options['allowed_mime_mode'] : 'all';
        $allowed_mime_mode  = in_array( $allowed_mime_mode, array( 'all', 'selected' ), true ) ? $allowed_mime_mode : 'all';
        $selected_mime      = '';

        if ( ! empty( $field->value ) && ctype_digit( (string) $field->value ) ) {
            $selected_mime = (string) get_post_mime_type( (int) $field->value );
        }

        $file_type = isset( $field->options['file_type'] ) ? $field->options['file_type'] : 'file';
        $image_preview_size = isset( $field->options['image_preview_size'] ) && ! empty( $field->options['image_preview_size'] ) ? $field->options['image_preview_size'] : 'medium';
        ?>
        <div class="cfgroup_file_input"
            data-file-type="<?php echo esc_attr( $file_type ); ?>"
            data-image-preview-size="<?php echo esc_attr( $image_preview_size ); ?>"
            data-allowed-mime-mode="<?php echo esc_attr( $allowed_mime_mode ); ?>"
            data-allowed-mimes="<?php echo esc_attr( wp_json_encode( array_values( $allowed_mimes ) ) ); ?>"
            data-allowed-extensions="<?php echo esc_attr( wp_json_encode( array_values( $allowed_extensions ) ) ); ?>"
            data-selected-mime="<?php echo esc_attr( $selected_mime ); ?>">
            <span class="file_url <?php echo esc_attr( isset( $field->options['file_type'] ) ? $field->options['file_type'] : 'file' ); ?>"><?php echo $file_url; ?></span>
            <input type="button" class="media button add<?php echo $css[0]; ?><?php echo esc_attr( $disabled_class ); ?>" value="<?php _e( 'Add File', 'admin-site-enhancements' ); ?>" <?php echo esc_html( $disabled ); ?> />
            <input type="button" class="media button remove<?php echo $css[1]; ?><?php echo esc_attr( $disabled_class ); ?>" value="<?php _e( 'Remove', 'admin-site-enhancements' ); ?>" <?php echo esc_html( $disabled ); ?> />
            <input type="hidden" name="<?php echo esc_attr( $field->input_name ); ?>" class="file_value" value="<?php echo esc_attr( $field->value ); ?>" />
        </div>
        <?php
    }


    function options_html( $key, $field ) {
        $allowed_mime_mode = $this->get_option( $field, 'allowed_mime_mode', 'all' );
        $allowed_mime_mode = in_array( $allowed_mime_mode, array( 'all', 'selected' ), true ) ? $allowed_mime_mode : 'all';
    ?>
        <tr class="field_option field_option_<?php echo $this->name; ?>">
            <td class="label">
                <label><?php _e( 'File / Media Type', 'admin-site-enhancements' ); ?></label>
            </td>
            <td>
                <?php
                    CFG()->create_field( [
                        'type' => 'select',
                        'input_name' => "cfgroup[fields][$key][options][file_type]",
                        'input_class' => 'cfgroup-file-type-select',
                        'options' => [
                            'choices' => [
                                'file'  => __( 'Any', 'admin-site-enhancements' ),
                                'image' => __( 'Image', 'admin-site-enhancements' ),
                                'audio' => __( 'Audio', 'admin-site-enhancements' ),
                                'video' => __( 'Video', 'admin-site-enhancements' ),
                                'pdf'   => __( 'PDF', 'admin-site-enhancements' )
                            ],
                            'force_single' => true,
                        ],
                        'value' => $this->get_option( $field, 'file_type', 'file' ),
                    ] );
                ?>
            </td>
        </tr>
        <tr class="field_option field_option_<?php echo $this->name; ?> field_option_file_allowed_extensions">
            <td class="label">
                <label><?php _e( 'Allowed File Extensions', 'admin-site-enhancements' ); ?></label>
            </td>
            <td>
                <div class="cfgroup-allowed-mime-mode-radios">
                    <label>
                        <input type="radio" class="cfgroup-allowed-mime-mode" name="cfgroup[fields][<?php echo esc_attr( $key ); ?>][options][allowed_mime_mode]" value="all"<?php checked( $allowed_mime_mode, 'all' ); ?> />
                        <?php _e( 'All relevant extensions', 'admin-site-enhancements' ); ?>
                    </label>
                    <label>
                        <input type="radio" class="cfgroup-allowed-mime-mode" name="cfgroup[fields][<?php echo esc_attr( $key ); ?>][options][allowed_mime_mode]" value="selected"<?php checked( $allowed_mime_mode, 'selected' ); ?> />
                        <?php _e( 'Only selected extensions', 'admin-site-enhancements' ); ?>
                    </label>
                </div>
                <div class="cfgroup-allowed-extensions-wrap"<?php echo ( 'selected' === $allowed_mime_mode ) ? '' : ' style="display:none;"'; ?>>
                    <?php $this->render_allowed_extension_checkboxes( $key, $field ); ?>
                </div>
            </td>
        </tr>
        <tr class="field_option field_option_<?php echo $this->name; ?>">
            <td class="label">
                <label><?php _e( 'Image Preview Size', 'admin-site-enhancements' ); ?></label>
            </td>
            <td>
                <?php
                    CFG()->create_field( [
                        'type' => 'select',
                        'input_name' => "cfgroup[fields][$key][options][image_preview_size]",
                        'options' => [
                            'choices' => [
                                'thumbnail' => __( 'Thumbnail (cropped)', 'admin-site-enhancements' ),
                                'medium'    => __( 'Medium (uncropped)', 'admin-site-enhancements' ),
                            ],
                            'force_single' => true,
                        ],
                        'value' => $this->get_option( $field, 'image_preview_size', '' ),
                    ] );
                ?>
            </td>
        </tr>
        <tr class="field_option field_option_<?php echo $this->name; ?>">
            <td class="label">
                <label><?php _e( 'Return Value', 'admin-site-enhancements' ); ?></label>
            </td>
            <td>
                <?php
                    CFG()->create_field( [
                        'type' => 'select',
                        'input_name' => "cfgroup[fields][$key][options][return_value]",
                        'options' => [
                            'choices' => [
                                'url' => __( 'File URL', 'admin-site-enhancements' ),
                                // 'html' => __( 'HTML (Display)', 'admin-site-enhancements' ),
                                'id' => __( 'Attachment ID', 'admin-site-enhancements' )
                            ],
                            'force_single' => true,
                        ],
                        'value' => $this->get_option( $field, 'return_value', 'url' ),
                    ] );
                ?>
            </td>
        </tr>
        <tr class="field_option field_option_<?php echo $this->name; ?>">
            <td class="label validation-label">
                <label><?php _e( 'Validation', 'admin-site-enhancements' ); ?></label>
            </td>
            <td>
                <?php
                    CFG()->create_field( [
                        'type' => 'true_false',
                        'input_name' => "cfgroup[fields][$key][options][required]",
                        'input_class' => 'true_false',
                        'value' => $this->get_option( $field, 'required' ),
                        'options' => [ 'message' => __( 'This is a required field', 'admin-site-enhancements' ) ],
                    ] );
                ?>
            </td>
        </tr>
    <?php
    }


    /**
     * Render the allowed extension checkbox grid for the field group editor.
     *
     * @param int|string $key   Field array key.
     * @param object     $field Field object.
     */
    function render_allowed_extension_checkboxes( $key, $field ) {
        $file_type = $this->get_option( $field, 'file_type', 'file' );
        $entries   = cfg_get_extensions_for_file_type( $file_type );
        $stored    = array();

        if ( isset( $field->options['allowed_extensions'] ) && is_array( $field->options['allowed_extensions'] ) ) {
            $stored = array_map(
                function( $ext ) {
                    return strtolower( sanitize_key( $ext ) );
                },
                $field->options['allowed_extensions']
            );
        }

        $input_name  = "cfgroup[fields][$key][options][allowed_extensions][]";
        ?>
        <div class="cfgroup-allowed-extensions">
            <?php foreach ( $entries as $entry ) : ?>
                <?php
                $ext     = $entry['ext'];
                $mime    = $entry['mime'];
                $checked = in_array( $ext, $stored, true ) ? ' checked' : '';
                ?>
                <label>
                    <input type="checkbox" name="<?php echo esc_attr( $input_name ); ?>" value="<?php echo esc_attr( $ext ); ?>" class="cfgroup-allowed-extension"<?php echo $checked; ?> />
                    .<?php echo esc_html( $ext ); ?> <span class="cfgroup-ext-mime">(<?php echo esc_html( $mime ); ?>)</span>
                </label>
            <?php endforeach; ?>
        </div>
        <?php
    }


    function pre_save_field( $field ) {
        $mode = isset( $field['options']['allowed_mime_mode'] ) ? $field['options']['allowed_mime_mode'] : 'all';
        $mode = in_array( $mode, array( 'all', 'selected' ), true ) ? $mode : 'all';
        $field['options']['allowed_mime_mode'] = $mode;

        if ( 'all' === $mode ) {
            unset( $field['options']['allowed_extensions'] );
            return $field;
        }

        $file_type        = isset( $field['options']['file_type'] ) ? $field['options']['file_type'] : 'file';
        $relevant_entries = cfg_get_extensions_for_file_type( $file_type );
        $valid_extensions = array_column( $relevant_entries, 'ext' );
        $allowed_extensions = isset( $field['options']['allowed_extensions'] ) ? (array) $field['options']['allowed_extensions'] : array();
        $allowed_extensions = array_map(
            function( $ext ) {
                return strtolower( sanitize_key( $ext ) );
            },
            $allowed_extensions
        );
        $allowed_extensions = array_values( array_intersect( $allowed_extensions, $valid_extensions ) );
        $field['options']['allowed_extensions'] = $allowed_extensions;

        return $field;
    }


    function pre_save( $value, $field = null ) {
        if ( empty( $value ) || ! ctype_digit( (string) $value ) ) {
            return $value;
        }

        if ( ! cfg_file_field_attachment_mime_is_allowed( (int) $value, $field ) ) {
            return '';
        }

        return $value;
    }


    function input_head( $field = null ) {
        static $cfgroup_file_picker_script_done = false;

        if ( $cfgroup_file_picker_script_done ) {
            return;
        }

        $cfgroup_file_picker_script_done = true;

        $js_path  = CFG_DIR . '/assets/js/cfg-file.js';
        $css_path = CFG_DIR . '/assets/css/cfg-file.css';

        wp_enqueue_media();

        wp_enqueue_style(
            'cfg-file',
            CFG_URL . '/assets/css/cfg-file.css',
            array(),
            file_exists( $css_path ) ? (string) filemtime( $css_path ) : CFG_VERSION
        );

        wp_enqueue_script(
            'cfg-file',
            CFG_URL . '/assets/js/cfg-file.js',
            array( 'jquery', 'media-editor' ),
            file_exists( $js_path ) ? (string) filemtime( $js_path ) : CFG_VERSION,
            true
        );

        wp_localize_script(
            'cfg-file',
            'cfgFileL10n',
            array(
                'invalidFile' => __( 'This file type is not allowed.', 'admin-site-enhancements' ),
            )
        );
    }


    function format_value_for_api( $value, $field = null ) {
        if ( ctype_digit( $value ) ) {
            $return_value = $this->get_option( $field, 'return_value', 'url' );
            return ( 'id' == $return_value ) ? (int) $value : wp_get_attachment_url( $value );
        }
        return $value;
    }

    function format_value_for_display( $value, $field = null ) {
        if ( ctype_digit( $value ) ) {
            $file_type = $this->get_option( $field, 'file_type', 'file' );
            $return_value = $this->get_option( $field, 'return_value', 'url' );

            if ( 'id' == $return_value ) {
                return (int) $value;
            } else {
                switch ( $file_type ) {
                    case 'file':
                        return wp_get_attachment_url( $value );
                        break;

                    case 'image':
                        return wp_get_attachment_image( $value, 'medium' );
                        break;

                    case 'audio':
                        return do_shortcode( '[audio src="' . wp_get_attachment_url( $value ) . '"]' );
                        break;

                    case 'video':
                        return do_shortcode( '[video src="' . wp_get_attachment_url( $value ) . '"]' );                    
                        break;

                    case 'pdf':
                        return (string) get_cf_pdf_viewer( wp_get_attachment_url( $value ) );
                        break;
                }
            }
        }

        return $value;
    }
}
