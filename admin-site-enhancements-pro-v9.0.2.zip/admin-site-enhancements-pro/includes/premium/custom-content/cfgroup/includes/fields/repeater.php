<?php

class cfgroup_repeater extends cfgroup_field
{
    public $values;

    function __construct() {
        $this->name = 'repeater';
        $this->label = __( 'Repeater', 'admin-site-enhancements' );
        $this->values = [];
    }


    /*
    ================================================================
        html
    ================================================================
    */
    function html( $field ) {
        global $post;
        
        if ( is_object( $post ) && property_exists( $post, 'ID' ) ) {
            // for posts and options pages - 'post' $object_type
            $this->values = CFG()->api->get_fields( $post->ID, [ 'format' => 'input' ], 'post' );
        } else if ( isset( $_GET['tag_ID'] ) ) {
            // for taxonomy terms - 'term' $object_type
            $term_id = $_GET['tag_ID'];
            $this->values = CFG()->api->get_fields( $term_id, [ 'format' => 'input' ], 'term' );
        } else {
            // TODO: to handle when in a taxonomy term add/create screens
            $this->values = array();
        }

        // Pass the repeater field object through so options are always available (incl. newly added options).
        $this->recursive_clone( $field->group_id, $field->id, $field );
        $this->recursive_html( $field->group_id, $field->id, array( (int) $field->id ), 0, $field );
    }


    /*
    ================================================================
        options_html
    ================================================================
    */
    function options_html( $key, $field ) {
    ?>
        <tr class="field_option field_option_<?php echo $this->name; ?>">
            <td class="label repeater-label">
                <label><?php _e( 'Row Display', 'admin-site-enhancements' ); ?></label>
            </td>
            <td>
                <?php
                    CFG()->create_field( [
                        'type' => 'true_false',
                        'input_name' => "cfgroup[fields][$key][options][row_display]",
                        'input_class' => 'true_false',
                        'value' => $this->get_option( $field, 'row_display' ),
                        'options' => [ 'message' => __( 'Show the values by default', 'admin-site-enhancements' ) ],
                    ] );
                ?>
            </td>
        </tr>
        <tr class="field_option field_option_<?php echo $this->name; ?>">
            <td class="label">
                <label><?php _e( 'Row Label', 'admin-site-enhancements' ); ?></label>
                <div class="cfgroup_tooltip">?
                    <div class="tooltip_inner"><?php _e( 'Override the "Repeater Row” header text. You can also dynamically populate the row label with field values. If you have a text field named “first_name”, enter {first_name} to use the field value as the row label.', 'admin-site-enhancements' ); ?></div>
                </div>
            </td>
            <td>
                <?php
                    CFG()->create_field( [
                        'type' => 'text',
                        'input_name' => "cfgroup[fields][$key][options][row_label]",
                        'value' => $this->get_option( $field, 'row_label', __( 'Repeater Row', 'admin-site-enhancements' ) ),
                    ] );
                ?>

                <div class="asenha-repeater-row-label-seq-setting">
                    <?php
                        CFG()->create_field( [
                            'type'        => 'true_false',
                            'input_name'  => "cfgroup[fields][$key][options][row_label_show_seq]",
                            'input_class' => 'true_false',
                            'value'       => $this->get_option( $field, 'row_label_show_seq', 0 ),
                            'options'     => [
                                'message' => __( 'Show sequence number in list of rows', 'admin-site-enhancements' ),
                            ],
                        ] );
                    ?>
                </div>
            </td>
        </tr>
        <tr class="field_option field_option_<?php echo $this->name; ?>">
            <td class="label">
                <label><?php _e( 'Button Label', 'admin-site-enhancements' ); ?></label>
            </td>
            <td>
                <?php
                    CFG()->create_field( [
                        'type' => 'text',
                        'input_name' => "cfgroup[fields][$key][options][button_label]",
                        'value' => $this->get_option( $field, 'button_label', __( 'Add Row', 'admin-site-enhancements' ) ),
                    ] );
                ?>
            </td>
        </tr>

        <tr class="field_option field_option_<?php echo $this->name; ?>">
            <td class="label">
                <label><?php _e( 'Limits', 'admin-site-enhancements' ); ?></label>
            </td>
            <td>
                <input type="text" name="cfgroup[fields][<?php echo $key; ?>][options][limit_min]" value="<?php echo $this->get_option( $field, 'limit_min' ); ?>" placeholder="min" style="width:60px" />
                <input type="text" name="cfgroup[fields][<?php echo $key; ?>][options][limit_max]" value="<?php echo $this->get_option( $field, 'limit_max' ); ?>" placeholder="max" style="width:60px" />
            </td>
        </tr>

    <?php
    }


    /*
    ================================================================
        recursive_clone
    ================================================================
    */
    function recursive_clone( $group_id, $field_id, $repeater_field_obj = null ) {
        $repeater_fields = [];

        // Get repeater field if it wasn't passed in.
        if ( ! is_object( $repeater_field_obj ) ) {
            $repeater_field = CFG()->api->get_input_fields(
                [
                    'field_id' => $field_id,
                ]
            );

            $repeater_field_obj = isset( $repeater_field[ $field_id ] ) ? $repeater_field[ $field_id ] : null;
        }

        if ( ! is_object( $repeater_field_obj ) ) {
            return;
        }

        // Get sub-fields
        $results = CFG()->api->get_input_fields( [
            'group_id' => $group_id,
            'parent_id' => $field_id
        ] );

        $row_label = $this->dynamic_label(
            $this->get_option( $repeater_field_obj, 'row_label', __( 'Repeater Row', 'admin-site-enhancements' ) )
        );
        $row_label_show_seq = ( 0 < (int) $this->get_option( $repeater_field_obj, 'row_label_show_seq', 0 ) );

        ob_start();
    ?>
        <div class="repeater_wrapper">
            <div class="cfgroup_repeater_head open">
                <a class="cfgroup_delete_field" href="javascript:;"></a>
                <a class="cfgroup_toggle_field" href="javascript:;"></a>
                <?php if ( $row_label_show_seq ) : ?>
                    <span class="asenha-repeater-row-seq" aria-hidden="true"></span>
                <?php endif; ?>
                <a class="cfgroup_insert_field" href="javascript:;"></a>
                <span class="label"><?php echo esc_attr( $row_label ); ?></span>
            </div>
            <div class="cfgroup_repeater_body open">
                <div class="fields-wrapper">
                    <?php foreach ( $results as $field ) : ?>
                        <div class="field-column-<?php echo esc_attr( $field->column_width ); ?> cfgroup-repeater-sub-wrap" data-field-id="<?php echo (int) $field->id; ?>">
                            <label><?php echo esc_html( $field->label ); ?></label>

                            <?php if ( ! empty( $field->notes ) ) : ?>
                            <div class="notes"><?php echo wp_kses_post( $field->notes ); ?></div>
                            <?php endif; ?>

                            <div class="field field-<?php echo esc_attr( $field->name ); ?> cfgroup_<?php echo esc_attr( $field->type ); ?><?php echo ( 'date' === $field->type && ! empty( $field->options['year_only'] ) ) ? ' year-only' : ''; ?>" data-field-id="<?php echo (int) $field->id; ?>">
                            <?php
                            if ( 'repeater' == $field->type ) :
                                $repeater_fields[] = $field;
                            ?>
                                <div class="table_footer">
                                    <input type="button" class="button-secondary cfgroup_add_field" value="<?php echo esc_attr( $this->get_option( $field, 'button_label', __( 'Add Row', 'admin-site-enhancements' ) ) ); ?>" data-repeater-tag="[clone][<?php echo $field->id; ?>]" data-rows="0" />
                                </div>
                            <?php else : ?>
                            <?php
                                CFG()->create_field( [
                                    'type' => $field->type,
                                    'input_name' => "cfgroup[input][clone][$field->id][value][]",
                                    'input_class' => $field->type,
                                    'options' => $field->options,
                                    'value' => $this->get_option( $field, 'default_value' ),
                                ] );
                            ?>
                            <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php
        $buffer = ob_get_clean();
    ?>

        <script>
        // In frontend CFG forms, this prevents CFG is undfined error
        if ( typeof CFG === 'undefined' ) {
            var CFG = CFG || {};
            CFG['get_field_value'] = {};
            CFG['repeater_buffer'] = [];            
        }
        
        CFG.repeater_buffer[<?php echo $field_id; ?>] = <?php echo json_encode( $buffer ); ?>;
        </script>

    <?php
        foreach ( $repeater_fields as $nested_repeater_field ) {
            $this->recursive_clone( $group_id, $nested_repeater_field->id, $nested_repeater_field );
        }
    }


    /*
    ================================================================
        recursive_html
    ================================================================
    */
    function recursive_html( $group_id, $field_id, $value_path = array(), $parent_weight = 0, $repeater_field_obj = null ) {

        // Get repeater field if it wasn't passed in.
        if ( ! is_object( $repeater_field_obj ) ) {
            $repeater_field = CFG()->api->get_input_fields(
                [
                    'field_id' => $field_id,
                ]
            );
            $repeater_field_obj = isset( $repeater_field[ $field_id ] ) ? $repeater_field[ $field_id ] : null;
        }

        if ( ! is_object( $repeater_field_obj ) ) {
            return;
        }

        // Get sub-fields
        $results = CFG()->api->get_input_fields( [
            'group_id' => $group_id,
            'parent_id' => $field_id
        ] );

        // Resolve nested values via integer path walk (never eval).
        if ( empty( $value_path ) ) {
            $value_path = array( (int) $field_id );
        }

        $safe_path = array();
        foreach ( (array) $value_path as $segment ) {
            if ( ! $this->is_non_negative_int_key( $segment ) ) {
                return;
            }
            $safe_path[] = (int) $segment;
        }

        if ( empty( $safe_path ) ) {
            return;
        }

        // Walk nested values using integer keys only (never eval).
        $values = false;
        $cursor = $this->values;
        foreach ( $safe_path as $segment ) {
            if ( ! is_array( $cursor ) || ! array_key_exists( $segment, $cursor ) ) {
                $values = false;
                $cursor = null;
                break;
            }
            $cursor = $cursor[ $segment ];
            $values = $cursor;
        }

        // HTML name / data-repeater-tag path built only from integer segments.
        $parent_tag = '[' . implode( '][', $safe_path ) . ']';

        // Row options
        $row_display = $this->get_option( $repeater_field_obj, 'row_display', 0 );
        $row_label = $this->get_option( $repeater_field_obj, 'row_label', __( 'Repeater Row', 'admin-site-enhancements' ) );
        $button_label = $this->get_option( $repeater_field_obj, 'button_label', __( 'Add Row', 'admin-site-enhancements' ) );
        $row_label_show_seq = ( 0 < (int) $this->get_option( $repeater_field_obj, 'row_label_show_seq', 0 ) );
        $css_class = ( 0 < (int) $row_display ) ? ' open' : '';

        // Do the dirty work
        $row_offset = -1;

        if ( $values ) :
            foreach ( $values as $i => $value ) :
                // Skip poisoned / non-integer row keys (e.g. leftover exploit payloads).
                if ( ! $this->is_non_negative_int_key( $i ) ) {
                    continue;
                }
                $i = (int) $i;
                $row_offset = max( $i, $row_offset );
    ?>
        <div class="repeater_wrapper">
            <div class="cfgroup_repeater_head<?php echo $css_class; ?>">
                <a class="cfgroup_delete_field" href="javascript:;"></a>
                <a class="cfgroup_toggle_field" href="javascript:;"></a>
                <?php if ( $row_label_show_seq ) : ?>
                    <span class="asenha-repeater-row-seq" aria-hidden="true"></span>
                <?php endif; ?>
                <a class="cfgroup_insert_field" href="javascript:;"></a>
                <span class="label"><?php echo esc_attr( $this->dynamic_label( $row_label, $results, $values[ $i ] ) ); ?>&nbsp;</span>
            </div>
            <div class="cfgroup_repeater_body<?php echo $css_class; ?>">
                <div class="fields-wrapper">
                <?php foreach ( $results as $field ) : ?>
                    <div class="field-column-<?php echo esc_attr( $field->column_width ); ?> cfgroup-repeater-sub-wrap" data-field-id="<?php echo (int) $field->id; ?>">
                        <?php if ( 'line_break' != $field->type ): ?>
                        <label><?php echo esc_html( $field->label ); ?></label>
                        <?php endif; ?>

                        <?php if ( ! empty( $field->notes ) ) : ?>
                        <div class="notes"><?php echo wp_kses_post( $field->notes ); ?></div>
                        <?php endif; ?>

                        <div class="field field-<?php echo esc_attr( $field->name ); ?> cfgroup_<?php echo esc_attr( $field->type ); ?><?php echo ( 'date' === $field->type && ! empty( $field->options['year_only'] ) ) ? ' year-only' : ''; ?>" data-field-id="<?php echo (int) $field->id; ?>">
                        <?php if ( 'repeater' == $field->type ) : ?>
                            <?php $this->recursive_html( $group_id, $field->id, array_merge( $safe_path, array( $i, (int) $field->id ) ), $i, $field ); ?>
                        <?php else : ?>
                        <?php
                            $args = [
                                'type' => $field->type,
                                'input_name' => "cfgroup[input]{$parent_tag}[$i][$field->id][value][]",
                                'input_class' => $field->type,
                                'options' => $field->options,
                            ];

                            if ( isset( $values[ $i ][ $field->id ] ) ) {
                                $args['value'] = $values[ $i ][ $field->id ];
                            }
                            elseif ( isset( $field->options['default_value'] ) ) {
                                $args['value'] = $field->options['default_value'];
                            }

                            CFG()->create_field( $args );
                        ?>
                        <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
                </div>
            </div>
        </div>

        <?php endforeach; endif; ?>

        <div class="table_footer">
            <input type="button" class="button-secondary cfgroup_add_field" value="<?php echo esc_attr( $button_label ); ?>" data-repeater-tag="<?php echo esc_attr( $parent_tag ); ?>" data-rows="<?php echo ( $row_offset + 1 ); ?>" />
        </div>
    <?php
    }

    /**
     * Whether a value is a non-negative integer key (int or digit-only string).
     *
     * @param mixed $key Array key to validate.
     * @return bool
     */
    private function is_non_negative_int_key( $key ) {
        if ( is_int( $key ) ) {
            return $key >= 0;
        }

        if ( is_string( $key ) && '' !== $key && ctype_digit( $key ) ) {
            return true;
        }

        return false;
    }


    /*---------------------------------------------------------------------------------------------
        input_head
    ---------------------------------------------------------------------------------------------*/

    function input_head( $field = null ) {
    ?>
        <script>
        (function($) {
            $(function() {
                function asenhaUpdateRepeaterRowSeq( $repeater ) {
                    if ( ! $repeater || 1 > $repeater.length ) {
                        return;
                    }

                    // Number rows for this repeater only (supports nested repeaters).
                    $repeater.children('.repeater_wrapper').each(function(index) {
                        var $seq = $(this).find('> .cfgroup_repeater_head > .asenha-repeater-row-seq');
                        if ( 0 < $seq.length ) {
                            $seq.text( index + 1 );
                        }
                    });
                }

                $(document).on('click', '.cfgroup_add_field', function() {
                    var num_rows = $(this).attr('data-rows');
                    var repeater_tag = $(this).attr('data-repeater-tag');
                    var repeater_id = repeater_tag.match(/.*\[(.*?)\]/)[1];
                    var html = CFG.repeater_buffer[repeater_id].replace(/\[clone\]/g, repeater_tag + '[' + num_rows + ']');
                    $(this).attr('data-rows', parseInt(num_rows)+1);
                    $(html).insertBefore( $(this).closest('.table_footer') ).addClass('repeater_wrapper_new');
                    $(this).trigger('cfgroup/ready');

                    asenhaUpdateRepeaterRowSeq( $(this).closest('.cfgroup_repeater') );
                });

                $(document).on('click', '.cfgroup_insert_field', function(event) {
                    event.stopPropagation();
                    var $add_field = $(this).parents('.cfgroup_repeater').find('.cfgroup_add_field');
                    var num_rows = $add_field.attr('data-rows');
                    var repeater_tag = $add_field.attr('data-repeater-tag');
                    var repeater_id = repeater_tag.match(/.*\[(.*?)\]/)[1];
                    var html = CFG.repeater_buffer[repeater_id].replace(/\[clone\]/g, repeater_tag + '[' + num_rows + ']');
                    $add_field.attr('data-rows', parseInt(num_rows)+1);
                    $(html).insertAfter( $(this).closest('.repeater_wrapper') ).addClass('repeater_wrapper_new');
                    $add_field.trigger('cfgroup/ready');

                    asenhaUpdateRepeaterRowSeq( $add_field.closest('.cfgroup_repeater') );
                });

                $(document).on('click', '.cfgroup_delete_field', function(event) {
                    if (confirm('Remove this row?')) {
                        var $repeater = $(this).closest('.cfgroup_repeater');
                        $(this).closest('.repeater_wrapper').remove();
                        asenhaUpdateRepeaterRowSeq( $repeater );
                    }
                    event.stopPropagation();
                });

                $(document).on('click', '.cfgroup_repeater_head', function() {
                    $(this).toggleClass('open');
                    $(this).siblings('.cfgroup_repeater_body').toggleClass('open');
                });

                // Hide or show all rows
                // The HTML is located in includes/form.php
                $(document).on('click', '.cfgroup_repeater_toggle', function() {
                    $(this).closest('.field').find('.cfgroup_repeater_head').toggleClass('open');
                    $(this).closest('.field').find('.cfgroup_repeater_body').toggleClass('open');
                });

                $('.cfgroup_repeater').sortable({
                    axis: 'y',
                    containment: 'parent',
                    items: '.repeater_wrapper',
                    handle: '.cfgroup_repeater_head',
                    update: function(event, ui) {

                        // To re-order field names:
                        // 1. Get the depth of the dragged element
                        // 2. Repeater through each input field within the dragged element
                        // 3. Reset the array index within the name attribute
                        var $container = ui.item.closest('.field');
                        var depth = $container.closest('.cfgroup_repeater').parents('.cfgroup_repeater').length;
                        var array_element = 3 + (depth * 2);

                        var counter = -1;
                        var last_index = -1;
                        $container.find('[name^="cfgroup[input]"]').each(function() {
                            var name_attr = $(this).attr('name').split('[');
                            var current_index = parseInt( name_attr[array_element] );
                            if (current_index != last_index) {
                                counter += 1;
                            }
                            name_attr[array_element] = counter + ']';
                            last_index = current_index;
                            $(this).attr('name', name_attr.join('['));
                        });

                        asenhaUpdateRepeaterRowSeq( ui.item.closest('.cfgroup_repeater') );
                    }
                });

                // Initial numbering.
                $('.cfgroup_repeater').each(function() {
                    asenhaUpdateRepeaterRowSeq( $(this) );
                });
            });
        })(jQuery);
        </script>
    <?php
    }


    /*
    ================================================================
        dynamic_label
    ================================================================
    */
    function dynamic_label( $row_label, $fields = [], $values = [] ) {

        // Exit stage left
        if ( '{' != substr( $row_label, 0, 1 ) || '}' != substr( $row_label, -1 ) ) {
            return $row_label;
        }

        $field = false;
        $fallback = false;
        $field_name = substr( $row_label, 1, -1 );

        // Check for fallback value
        if ( false !== strpos( $field_name, ':' ) ) {
            list( $field_name, $fallback ) = explode( ':', $field_name );
        }

        // Get all field names and IDs
        foreach ( $fields as $f ) {
            if ( $field_name == $f->name ) {
                $field = $f;
                break;
            }
        }

        if ( ! empty( $field ) && isset( $values[ $field->id ] ) ) {
            if ( 'select' == $field->type ) {
                $select_key = reset( $values[ $field->id ] );
                $row_label = $field->options['choices'][ $select_key ];
            }
            else {
                $row_label = $values[ $field->id ];
            }
        }
        elseif ( false !== $fallback ) {
             $row_label = $fallback;
        }

        return $row_label;
    }


    /*
    ================================================================
        prepare_value
    ================================================================
    */
    function prepare_value( $value, $field = null ) {
        return $value;
    }
}
