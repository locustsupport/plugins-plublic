<?php

class cfgroup_gallery extends cfgroup_field
{

    function __construct() {
        $this->name = 'gallery';
        $this->label = __( 'Gallery', 'admin-site-enhancements' );
    }

    function options_html( $key, $field ) {
    ?>
        <tr class="field_option field_option_<?php echo $this->name; ?>">
            <td class="label validation-label">
                <label><?php _e( 'Validation', 'admin-site-enhancements' ); ?></label>
            </td>
            <td>
                <?php
                    CFG()->create_field( [
                        'type' => 'true_false',
                        'input_name' => "cfgroup[fields][$key][options][required]",
                        'input_class' => 'true_false',
                        'value' => $this->get_option( $field, 'required' ),
                        'options' => [ 'message' => __( 'This is a required field', 'admin-site-enhancements' ) ],
                    ] );
                ?>
            </td>
        </tr>
    <?php
    }

    function html( $field ) {
        $gallery_image_ids = $field->value; // Comma-separated attachemtn IDs, e.g. 7682,7681,7680
        
        // Css class to sho/hide buttons/links
        $show = ( empty( $gallery_image_ids ) ) ? '' : ' hidden';
        $hidden = ( empty( $gallery_image_ids ) ) ? ' hidden' : '';

        ?>
        <div class="gallery-preview">
        <?php 
        if ( ! empty( $gallery_image_ids ) ) {
            $values = explode( ',', $gallery_image_ids );

            foreach ( $values as $id ) {
                $attachment = wp_get_attachment_image_src( $id, 'thumbnail' );
                ?>
                <div class="preview-image"><img src="<?php echo esc_url( ( is_array( $attachment ) ) ? $attachment[0] : '' ); ?>" /></div>
                <?php
            }
        }

        ?>
        </div>
        <div class="gallery-buttons">
        <?php
        if ( ! is_user_logged_in() ) {
            // We show a disabled button when the field is shown to logged-out user
            ?>
            <input type="button" class="button cfg-button<?php echo esc_attr( $show ); ?> disabled" value="<?php _e( 'Select Images', 'admin-site-enhancements' ); ?>" disabled="disabled" />
            <?php
            } else {
            ?>
            <a href="#" class="button cfg-button<?php echo esc_attr( $show ); ?>">Select Images</a>
            <a href="#" class="button cfg-edit-gallery<?php echo esc_attr( $hidden ); ?>">Edit Selection</a>
            <a href="#" class="cfg-clear-gallery<?php echo esc_attr( $hidden ); ?>">Clear</a>        
            <?php
        }
        ?>
        </div>
        <input type="hidden" name="<?php echo esc_attr( $field->input_name ); ?>" class="cfg-gallery-value" value="<?php echo esc_attr( $gallery_image_ids ); ?>" />
        <?php
    }

    function input_head( $field = null ) {
        static $cfgroup_gallery_picker_script_done = false;

        if ( $cfgroup_gallery_picker_script_done ) {
            return;
        }

        $cfgroup_gallery_picker_script_done = true;

        $js_path  = CFG_DIR . '/assets/js/cfg-gallery.js';
        $css_path = CFG_DIR . '/assets/css/cfg-gallery.css';

        wp_enqueue_media();

        wp_enqueue_style(
            'cfg-gallery',
            CFG_URL . '/assets/css/cfg-gallery.css',
            array(),
            file_exists( $css_path ) ? (string) filemtime( $css_path ) : CFG_VERSION
        );

        wp_enqueue_script(
            'cfg-gallery',
            CFG_URL . '/assets/js/cfg-gallery.js',
            array( 'jquery', 'media-editor' ),
            file_exists( $js_path ) ? (string) filemtime( $js_path ) : CFG_VERSION,
            true
        );
    }

    function format_value_for_api( $value, $field = null ) {
        if ( ! empty( $value ) ) {
            // Turn comma-separated IDs into indexed array of integer IDs
            $value = explode( ',', $value );
            $new_value = array();
            foreach( $value as $id ) {
                $new_value[] = (int) $id;
            }
            $value = $new_value;
        } else {
            $value = array();
        }
        
        return $value;
    }

    function format_value_for_display( $value, $field = null ) {
        return get_cf_gallery_justified( explode( ',', $value ), 'medium' );
    }
}