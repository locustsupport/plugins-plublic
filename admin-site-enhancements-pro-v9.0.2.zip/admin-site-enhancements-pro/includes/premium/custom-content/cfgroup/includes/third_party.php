<?php

class cfgroup_third_party
{

    public function __construct() {

        // Post Type Switcher - http://wordpress.org/plugins/post-type-switcher/
        add_filter( 'pts_post_type_filter', [ $this, 'pts_post_type_filter' ] );

        // WPML - http://wpml.org/
        add_action( 'icl_make_duplicate', [ $this, 'wpml_handler' ], 10, 4 );

        // Duplicate Post - http://wordpress.org/plugins/duplicate-post/
        add_action( 'dp_duplicate_post', [ $this, 'duplicate_post' ], 100, 2 );
        add_action( 'dp_duplicate_page', [ $this, 'duplicate_post' ], 100, 2 );

        // WooCommerce product duplication.
        add_action( 'woocommerce_product_duplicate', [ $this, 'duplicate_product' ], 100, 2 );
    }


    /**
     * WPML support
     * 
     * Properly copy CFG fields on WPML post duplication (requires WPML 2.6+)
     * 
     * @param int $master_id 
     * @param string $lang 
     * @param array $post_data 
     * @param int $duplicate_id 
     * @since 1.6.8
     */
    function wpml_handler( $master_id, $lang, $post_data, $duplicate_id ) {
        $handled = apply_filters( 'asenha_cct_wpml_duplicate_post_fields', false, (int) $master_id, (int) $duplicate_id, $lang, $post_data );

        if ( $handled ) {
            return;
        }

        $field_data = CFG()->get( false, $master_id, [ 'format' => 'raw' ] );

        if ( ! empty( $field_data ) ) {
            CFG()->save( $field_data, [ 'ID' => $duplicate_id ] );
        }
    }


    /**
     * WooCommerce product duplication support.
     *
     * WooCommerce fires this action after the duplicate product and its
     * variations have been saved, so the duplicate has a database ID.
     *
     * @param object $duplicate Duplicate product object.
     * @param object $product   Original product object.
     * @return void
     * @since 8.9.3
     */
    public function duplicate_product( $duplicate, $product ) {
        if ( ! is_a( $duplicate, 'WC_Product' ) || ! is_a( $product, 'WC_Product' ) ) {
            return;
        }

        $product_id = absint( $product->get_id() );

        // The native row action duplicates parent products, not variations.
        if ( 'product' !== get_post_type( $product_id ) ) {
            return;
        }

        $this->duplicate_cfg_values( $duplicate->get_id(), $product_id );
    }


    /**
     * Post Type Switcher support
     * @param array $args 
     * @return array
     * @since 1.8.1
     */
    function pts_post_type_filter( $args ) {
        global $current_screen;

        if ( ! is_null( $current_screen ) ) {
            if ( 'cfgroup' == $current_screen->id ) {
                $args = [ 'public' => false, 'show_ui' => true ];
            }
        }

        return $args;
    }


    /**
     * Duplicate Post support
     * @param int $new_post_id
     * @param object $post
     * @since 2.0.0
     */
    function duplicate_post($new_post_id, $post) {
        $this->duplicate_cfg_values( $new_post_id, $post->ID );
    }


    /**
     * Copy CFG values to a duplicate post and rebuild its value index.
     *
     * Use the same field-ID/input format as the normal CFG form save. This is
     * required for repeater rows and lets CFG remove copied metadata before
     * rebuilding fresh postmeta and asenha_cfgroup_values rows.
     *
     * @param int $new_post_id      Duplicate post ID.
     * @param int $original_post_id Original post ID.
     * @return void
     */
    private function duplicate_cfg_values( $new_post_id, $original_post_id ) {
        $new_post_id      = absint( $new_post_id );
        $original_post_id = absint( $original_post_id );

        if ( 0 === $new_post_id || 0 === $original_post_id ) {
            return;
        }

        $all_cf_info = get_cf_info( false, $original_post_id );

        if ( ! is_array( $all_cf_info ) || empty( $all_cf_info ) ) {
            return;
        }

        $cf_raw_values = get_cf( false, 'raw', $original_post_id );
        if ( ! is_array( $cf_raw_values ) ) {
            $cf_raw_values = array();
        }

        $common_methods = new ASENHA\Classes\Common_Methods;
        $field_data = $common_methods->convert_ase_cf_raw_values_to_cfg_save_format__premium_only(
            $cf_raw_values,
            $all_cf_info
        );

        $cfgroup_ids = array();
        foreach ( $all_cf_info as $cf_info ) {
            if ( ! is_array( $cf_info ) || ! isset( $cf_info['group_id'] ) ) {
                continue;
            }

            $group_id = absint( $cf_info['group_id'] );
            if ( 0 < $group_id && ! in_array( $group_id, $cfgroup_ids, true ) ) {
                $cfgroup_ids[] = $group_id;
            }
        }

        if ( empty( $cfgroup_ids ) ) {
            return;
        }

        CFG()->save(
            $field_data,
            [ 'ID' => $new_post_id ],
            [
                'format'        => 'input',
                'field_groups'  => $cfgroup_ids,
            ]
        );
    }
}

new cfgroup_third_party();
