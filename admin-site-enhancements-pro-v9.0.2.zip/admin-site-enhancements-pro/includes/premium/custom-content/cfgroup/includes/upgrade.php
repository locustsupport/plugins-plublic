<?php

class cfgroup_upgrade
{

    public $version;
    public $last_version;


    public function __construct() {
        $this->version = CFG_VERSION;
        $options = get_option( ASENHA_SLUG_U . '_extra', array() );

        // This will be false (zero) on a fresh install
        if ( isset( $options['cfgroup_version'] ) ) {
            $this->last_version = $options['cfgroup_version'];
        } else {
            $this->last_version = get_option('cfgroup_version');
            $options['cfgroup_version'] = get_option('cfgroup_version');
            update_option( ASENHA_SLUG_U . '_extra', $options, true );
            delete_option( 'cfgroup_version' );
        }

        if ( version_compare( $this->last_version, $this->version, '<' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
            if ( version_compare( $this->last_version, '1.0.0', '<' ) ) {
                $this->clean_install();
            }
            else {
                $this->run_upgrade();
            }

            $options = get_option( ASENHA_SLUG_U . '_extra', array() );
            $options['cfgroup_version'] = $this->version;
            update_option( ASENHA_SLUG_U . '_extra', $options, true );
        }

        // Ensure post values storage exists even when cfgroup_version is already current.
        self::ensure_cfgroup_values_table_exists();
        self::ensure_cfgroup_sessions_table_exists();
        self::ensure_cfgroup_term_values_table_exists();
        self::ensure_cfgroup_meta_id_indexes();
    }

    /**
     * Create the posts/options-pages custom field values table when it is missing.
     *
     * Safe to call on every request; no-ops when the table already exists.
     */
    public static function ensure_cfgroup_values_table_exists() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'asenha_cfgroup_values';
        $query      = $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table_name ) );

        if ( $wpdb->get_var( $query ) !== $table_name ) {
            self::create_table_for_post_cfg_values();
        }
    }

    /**
     * Create the CFG sessions table when it is missing.
     *
     * Safe to call on every request; no-ops when the table already exists.
     */
    public static function ensure_cfgroup_sessions_table_exists() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'asenha_cfgroup_sessions';
        $query      = $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table_name ) );

        if ( $wpdb->get_var( $query ) !== $table_name ) {
            self::create_table_for_post_cfg_sessions();
        }
    }

    /**
     * Create the taxonomy-term custom field values table when it is missing.
     *
     * Safe to call on every request; no-ops when the table already exists.
     */
    public static function ensure_cfgroup_term_values_table_exists() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'asenha_cfgroup_values_for_terms';
        $query      = $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table_name ) );

        if ( $wpdb->get_var( $query ) !== $table_name ) {
            self::create_table_for_term_cfg_values();
        }
    }

    /**
     * One-time dbDelta pass to add meta_id indexes on existing CFG value tables.
     *
     * @return void
     */
    public static function ensure_cfgroup_meta_id_indexes() {
        $options = get_option( ASENHA_SLUG_U . '_extra', array() );
        if ( ! empty( $options['cfgroup_meta_id_index_v1'] ) ) {
            return;
        }

        self::create_table_for_post_cfg_values();
        self::create_table_for_term_cfg_values();

        $options['cfgroup_meta_id_index_v1'] = 1;
        update_option( ASENHA_SLUG_U . '_extra', $options, true );
    }

    private function clean_install() {
        global $wpdb;

        self::create_table_for_post_cfg_values();

        // Create table for custom fields values in taxonomy terms
        self::create_table_for_term_cfg_values();

        self::create_table_for_post_cfg_sessions();

        // Set the field counter
        // update_option( 'cfgroup_next_field_id', 1 );
        $options = get_option( ASENHA_SLUG_U . '_extra', array() );
        $options['cfgroup_next_field_id'] = 1;
        $options['cfgroup_meta_id_index_v1'] = 1;
        update_option( ASENHA_SLUG_U . '_extra', $options, true );
    }

    private function run_upgrade() {
        self::ensure_cfgroup_values_table_exists();
        self::ensure_cfgroup_sessions_table_exists();
        self::ensure_cfgroup_term_values_table_exists();
        self::ensure_cfgroup_meta_id_indexes();
    }

    private static function create_table_for_post_cfg_values() {
        global $wpdb;

        if ( ! function_exists( 'dbDelta' ) ) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }

        $sql = "
        CREATE TABLE {$wpdb->prefix}asenha_cfgroup_values (
            id INT unsigned not null auto_increment,
            field_id INT unsigned,
            meta_id INT unsigned,
            post_id INT unsigned,
            base_field_id INT unsigned default 0,
            hierarchy TEXT,
            depth INT unsigned default 0,
            weight INT unsigned default 0,
            sub_weight INT unsigned default 0,
            PRIMARY KEY (id),
            INDEX field_id_idx (field_id),
            INDEX post_id_idx (post_id),
            INDEX meta_id_idx (meta_id)
        ) DEFAULT CHARSET=utf8";

        dbDelta( $sql );
    }

    /**
     * Create the CFG sessions table schema.
     */
    private static function create_table_for_post_cfg_sessions() {
        global $wpdb;

        if ( ! function_exists( 'dbDelta' ) ) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }

        $sql = "
        CREATE TABLE {$wpdb->prefix}asenha_cfgroup_sessions (
            id VARCHAR(32),
            data TEXT,
            expires VARCHAR(10),
            PRIMARY KEY (id)
        ) DEFAULT CHARSET=utf8";

        dbDelta( $sql );
    }
    
    private static function create_table_for_term_cfg_values() {
        global $wpdb;

        if ( ! function_exists( 'dbDelta' ) ) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }

        $sql = "
        CREATE TABLE {$wpdb->prefix}asenha_cfgroup_values_for_terms (
            id INT unsigned not null auto_increment,
            field_id INT unsigned,
            meta_id INT unsigned,
            term_id INT unsigned,
            base_field_id INT unsigned default 0,
            hierarchy TEXT,
            depth INT unsigned default 0,
            weight INT unsigned default 0,
            sub_weight INT unsigned default 0,
            PRIMARY KEY (id),
            INDEX field_id_idx (field_id),
            INDEX term_id_idx (term_id),
            INDEX meta_id_idx (meta_id)
        ) DEFAULT CHARSET=utf8";

        dbDelta( $sql );
    }
}

new cfgroup_upgrade();
