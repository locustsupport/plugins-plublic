<?php
/**
 * Conditional logic for Custom Field Groups (CFG).
 *
 * cfgroup_rules (placement) control where a group appears (location rules).
 * conditional_logic on each field controls visibility within the group (ACF-style).
 *
 * @package Admin and Site Enhancements
 */

/**
 * Sanitization, evaluation, and JS config for CFG conditional logic.
 */
class cfgroup_conditional_logic {

	/**
	 * Field types used only for layout (no stored input value for rules).
	 */
	const LAYOUT_TYPES = array( 'tab', 'heading', 'line_break' );

	/**
	 * Safety caps.
	 */
	const MAX_OR_GROUPS = 20;

	const MAX_AND_RULES = 20;

	const MAX_FIXPOINT_ITERATIONS = 25;

	/**
	 * Legacy conditional operators for number fields (pre-numeric UI); still accepted on save/evaluate.
	 *
	 * @var string[]
	 */
	private static $legacy_number_operators = array( 'empty', '!=', 'contains', 'match' );

	/**
	 * Legacy conditional operators for date fields (pre date-specific UI); still accepted on save/evaluate.
	 *
	 * @var string[]
	 */
	private static $legacy_date_operators = array( 'empty', '==', '!=', 'contains', 'match' );

	/**
	 * Legacy conditional operators for time fields (pre time-specific UI); still accepted on save/evaluate.
	 *
	 * @var string[]
	 */
	private static $legacy_time_operators = array( 'empty', '==', '!=', 'contains', 'match' );

	/**
	 * Legacy conditional operators for datetime fields (pre datetime-specific UI); still accepted on save/evaluate.
	 *
	 * @var string[]
	 */
	private static $legacy_datetime_operators = array( 'empty', '==', '!=', 'contains', 'match' );

	/**
	 * Legacy conditional operators for textual fields (pre removal of empty from UI); still accepted on save/evaluate.
	 *
	 * @var string[]
	 */
	private static $legacy_textual_operators = array( 'empty' );

	/**
	 * Legacy conditional operators for repeater fields (pre limited UI); still accepted on save/evaluate.
	 *
	 * @var string[]
	 */
	private static $legacy_repeater_operators = array( 'empty', 'not_empty', '==', '!=', 'contains', 'match' );

	/**
	 * Build JSON config for the browser (per field group).
	 *
	 * @param int   $group_id Field group post ID.
	 * @param array $fields   Output of get_input_fields for this group (id => field object).
	 * @return array<string,mixed>
	 */
	public static function build_js_config( $group_id, $fields ) {
		$by_id   = array();
		$cl_meta = array();

		foreach ( $fields as $fid => $field ) {
			$field = (array) $field;
			$fid   = (int) $fid;
			$type  = isset( $field['type'] ) ? $field['type'] : '';

			$by_id[ (string) $fid ] = array(
				'id'         => $fid,
				'name'       => isset( $field['name'] ) ? $field['name'] : '',
				'type'       => $type,
				'parent_id'  => isset( $field['parent_id'] ) ? (int) $field['parent_id'] : 0,
				'group_id'   => (int) $group_id,
			);

			$cl = isset( $field['conditional_logic'] ) ? $field['conditional_logic'] : array();
			if ( ! empty( $cl['enabled'] ) && ! empty( $cl['groups'] ) && is_array( $cl['groups'] ) ) {
				$cl_meta[ (string) $fid ] = array(
					'enabled' => 1,
					'groups'  => $cl['groups'],
				);
			}
		}

		return array(
			'groupId' => (int) $group_id,
			'fields'  => $by_id,
			'logic'   => $cl_meta,
		);
	}

	/**
	 * Sanitize conditional_logic from the field group editor POST.
	 *
	 * @param array $raw              Raw cfgroup[fields][i][conditional_logic].
	 * @param int   $current_field_id Current field id (0 for new).
	 * @param int   $parent_id        Parent field id.
	 * @param array $siblings_by_id     id => field row (must include type).
	 * @return array{enabled:int,groups:array<int,array<int,array{field_id:int,operator:string,value:mixed}>>}
	 */
	public static function sanitize_from_post( $raw, $current_field_id, $parent_id, $siblings_by_id ) {
		$out = array(
			'enabled' => 0,
			'groups'  => array(),
		);

		if ( ! is_array( $raw ) ) {
			return $out;
		}

		$out['enabled'] = ! empty( $raw['enabled'] ) ? 1 : 0;
		if ( ! $out['enabled'] ) {
			return $out;
		}

		if ( empty( $raw['groups'] ) || ! is_array( $raw['groups'] ) ) {
			$out['enabled'] = 0;
			return $out;
		}

		$parent_id = (int) $parent_id;
		$or_index  = 0;

		foreach ( $raw['groups'] as $and_rules ) {
			if ( $or_index >= self::MAX_OR_GROUPS ) {
				break;
			}
			if ( ! is_array( $and_rules ) ) {
				continue;
			}

			$clean_and = array();
			$ai        = 0;

			foreach ( $and_rules as $rule ) {
				if ( $ai >= self::MAX_AND_RULES ) {
					break;
				}
				if ( ! is_array( $rule ) ) {
					continue;
				}

				$dep_id = isset( $rule['field_id'] ) ? absint( $rule['field_id'] ) : 0;
				if ( $dep_id < 1 || $dep_id === (int) $current_field_id ) {
					continue;
				}
				if ( ! isset( $siblings_by_id[ $dep_id ] ) ) {
					continue;
				}

				$dep_row = $siblings_by_id[ $dep_id ];
				$dep_pt  = isset( $dep_row['parent_id'] ) ? (int) $dep_row['parent_id'] : 0;
				if ( $dep_pt !== $parent_id ) {
					continue;
				}

				$dep_type = isset( $dep_row['type'] ) ? $dep_row['type'] : '';
				if ( self::is_layout_type( $dep_type ) ) {
					continue;
				}

				$op = isset( $rule['operator'] ) ? self::sanitize_operator_from_post( $rule['operator'] ) : '==';
				if ( ! self::is_operator_allowed_for_type( $dep_type, $op ) ) {
					continue;
				}

				$val = isset( $rule['value'] ) ? $rule['value'] : '';
				$val = self::sanitize_rule_value( $dep_type, $op, $val );

				$clean_and[] = array(
					'field_id' => $dep_id,
					'operator' => $op,
					'value'    => $val,
				);
				$ai++;
			}

			if ( ! empty( $clean_and ) ) {
				$out['groups'][] = $clean_and;
				$or_index++;
			}
		}

		if ( empty( $out['groups'] ) ) {
			$out['enabled'] = 0;
		}

		return $out;
	}

	/**
	 * Normalize operator from POST.
	 *
	 * Do not use sanitize_text_field() here: it strips angle brackets and breaks operators
	 * such as '<' and '<='. Validity is enforced by is_operator_allowed_for_type().
	 *
	 * @param mixed $raw Raw operator from the request.
	 * @return string Trimmed operator string.
	 */
	private static function sanitize_operator_from_post( $raw ) {
		if ( ! isset( $raw ) || is_array( $raw ) ) {
			return '';
		}
		return trim( wp_unslash( (string) $raw ) );
	}

	/**
	 * Remap conditional_logic field_id references after import.
	 *
	 * @param array $conditional_logic Saved conditional_logic array.
	 * @param array $field_id_mapping  Old id => new id.
	 * @return array
	 */
	public static function remap_import_field_ids( $conditional_logic, $field_id_mapping ) {
		if ( empty( $conditional_logic['groups'] ) || ! is_array( $conditional_logic['groups'] ) ) {
			return $conditional_logic;
		}

		foreach ( $conditional_logic['groups'] as $gi => $and_rules ) {
			if ( ! is_array( $and_rules ) ) {
				continue;
			}
			foreach ( $and_rules as $ri => $rule ) {
				if ( ! is_array( $rule ) || empty( $rule['field_id'] ) ) {
					continue;
				}
				$old = (int) $rule['field_id'];
				if ( isset( $field_id_mapping[ $old ] ) ) {
					$conditional_logic['groups'][ $gi ][ $ri ]['field_id'] = (int) $field_id_mapping[ $old ];
				}
			}
		}

		return $conditional_logic;
	}

	/**
	 * Whether a field type cannot be used as a rule source.
	 *
	 * @param string $type Field type slug.
	 * @return bool
	 */
	public static function is_layout_type( $type ) {
		return in_array( $type, self::LAYOUT_TYPES, true );
	}

	/**
	 * Compute visibility for top-level fields from POST input (same semantics as JS).
	 *
	 * @param array $top_level_fields Field id => object with type, parent_id, conditional_logic.
	 * @param array $input            cfgroup['input'] from POST (stripslashed).
	 * @return array<int,bool> field_id => visible
	 */
	public static function compute_visibility_map( $top_level_fields, $input ) {
		$ids = array();
		foreach ( $top_level_fields as $fid => $f ) {
			$f = (array) $f;
			if ( 0 !== (int) ( isset( $f['parent_id'] ) ? $f['parent_id'] : 0 ) ) {
				continue;
			}
			$ids[] = (int) $fid;
		}

		$visible = array();
		foreach ( $ids as $fid ) {
			$visible[ $fid ] = true;
		}

		$iter = 0;
		do {
			$changed       = false;
			$visible_prev  = $visible;
			$next_visible    = array();
			foreach ( $ids as $fid ) {
				$next_visible[ $fid ] = self::evaluate_field_visible( $fid, $top_level_fields, $input, $visible_prev );
			}
			foreach ( $ids as $fid ) {
				if ( ! isset( $visible[ $fid ] ) || $visible[ $fid ] !== $next_visible[ $fid ] ) {
					$changed = true;
				}
				$visible[ $fid ] = $next_visible[ $fid ];
			}
			$iter++;
		} while ( $changed && $iter < self::MAX_FIXPOINT_ITERATIONS );

		return $visible;
	}

	/**
	 * Compute visibility for sub-fields within a single repeater row (same semantics as JS).
	 *
	 * @param int   $repeater_id     Repeater field id.
	 * @param array $sibling_fields  Sub-field id => field array/object (same parent_id).
	 * @param array $row_input       Row slice of cfgroup[input] (field_id => array with value key).
	 * @return array<int,bool> field_id => visible
	 */
	public static function compute_repeater_row_visibility_map( $repeater_id, $sibling_fields, $row_input ) {
		unset( $repeater_id );

		$ids = array();
		foreach ( $sibling_fields as $fid => $f ) {
			$ids[] = (int) $fid;
		}

		if ( empty( $ids ) || ! is_array( $row_input ) ) {
			return array();
		}

		$visible = array();
		foreach ( $ids as $fid ) {
			$visible[ $fid ] = true;
		}

		$iter = 0;
		do {
			$changed      = false;
			$visible_prev = $visible;
			$next_visible = array();
			foreach ( $ids as $fid ) {
				$next_visible[ $fid ] = self::evaluate_row_field_visible( $fid, $sibling_fields, $row_input, $visible_prev );
			}
			foreach ( $ids as $fid ) {
				if ( ! isset( $visible[ $fid ] ) || $visible[ $fid ] !== $next_visible[ $fid ] ) {
					$changed = true;
				}
				$visible[ $fid ] = $next_visible[ $fid ];
			}
			$iter++;
		} while ( $changed && $iter < self::MAX_FIXPOINT_ITERATIONS );

		return $visible;
	}

	/**
	 * Raw value for a sub-field within a repeater row POST slice.
	 *
	 * @param int   $field_id  Sub-field id.
	 * @param array $row_input Row input tree.
	 * @return mixed
	 */
	public static function get_row_input_value_for_field( $field_id, $row_input ) {
		$field_id = (int) $field_id;
		if ( ! is_array( $row_input ) || ! isset( $row_input[ $field_id ] ) || ! is_array( $row_input[ $field_id ] ) ) {
			return null;
		}
		if ( ! array_key_exists( 'value', $row_input[ $field_id ] ) ) {
			return null;
		}
		return $row_input[ $field_id ]['value'];
	}

	/**
	 * Convert repeater-row hyperlink POST (indexed url/text/target slots) to associative shape.
	 *
	 * @param mixed $raw Raw value from row input.
	 * @return mixed Associative hyperlink array or original value.
	 */
	private static function normalize_hyperlink_row_value( $raw ) {
		if ( ! is_array( $raw ) ) {
			return $raw;
		}

		if ( isset( $raw['url'] ) || isset( $raw['text'] ) || isset( $raw['target'] ) ) {
			return array(
				'url'    => isset( $raw['url'] ) ? (string) $raw['url'] : '',
				'text'   => isset( $raw['text'] ) ? (string) $raw['text'] : '',
				'target' => isset( $raw['target'] ) ? (string) $raw['target'] : '',
			);
		}

		// Repeater sub-fields use input names ending in [value][]; hyperlink posts as indexed slots.
		if ( isset( $raw[0]['url'], $raw[1]['text'], $raw[2]['target'] ) ) {
			return array(
				'url'    => $raw[0]['url'],
				'text'   => $raw[1]['text'],
				'target' => $raw[2]['target'],
			);
		}

		return $raw;
	}

	/**
	 * Convert repeater-row map POST (indexed address/lat/lng/zoom slots) to associative shape.
	 *
	 * @param mixed $raw Raw value from row input.
	 * @return mixed Associative map array or original value.
	 */
	private static function normalize_map_row_value( $raw ) {
		if ( ! is_array( $raw ) ) {
			return $raw;
		}

		if ( isset( $raw['address'] ) || isset( $raw['latitude'] ) ) {
			return $raw;
		}

		// Repeater sub-fields use input names ending in [value][]; map posts as indexed slots.
		if ( isset( $raw[0] ) && is_array( $raw[0] ) ) {
			$rebuilt = array();
			foreach ( $raw as $part ) {
				if ( is_array( $part ) ) {
					$rebuilt = array_merge( $rebuilt, $part );
				}
			}
			return $rebuilt;
		}

		return $raw;
	}

	/**
	 * Unwrap single-element scalar arrays from repeater [value][] POST names.
	 *
	 * @param mixed $raw Raw value from row input.
	 * @return mixed Scalar or original array for multi-value / composite fields.
	 */
	private static function unwrap_repeater_scalar_row_value( $raw ) {
		if ( ! is_array( $raw ) ) {
			return $raw;
		}

		if ( isset( $raw['url'] ) || isset( $raw['text'] ) || isset( $raw['target'] )
			|| isset( $raw[0]['url'] ) ) {
			return $raw;
		}

		if ( 1 === count( $raw ) && array_key_exists( 0, $raw ) && ! is_array( $raw[0] ) ) {
			return $raw[0];
		}

		return $raw;
	}

	/**
	 * Normalize a sub-field value from repeater row POST before conditional logic evaluation.
	 *
	 * @param string $type Field type slug.
	 * @param mixed  $raw  Raw value from get_row_input_value_for_field().
	 * @return mixed
	 */
	public static function normalize_row_input_value( $type, $raw ) {
		if ( null === $raw ) {
			return null;
		}

		if ( 'hyperlink' === $type ) {
			return self::normalize_hyperlink_row_value( $raw );
		}

		if ( 'map' === $type ) {
			return self::normalize_map_row_value( $raw );
		}

		return self::unwrap_repeater_scalar_row_value( $raw );
	}

	/**
	 * @param int   $field_id       Sub-field being evaluated.
	 * @param array $sibling_fields id => field array/object.
	 * @param array $row_input      Row slice of cfgroup[input].
	 * @param array $visible_deps   Dependency visibility for this iteration.
	 * @return bool
	 */
	private static function evaluate_row_field_visible( $field_id, $sibling_fields, $row_input, $visible_deps ) {
		$f  = isset( $sibling_fields[ $field_id ] ) ? (array) $sibling_fields[ $field_id ] : array();
		$cl = isset( $f['conditional_logic'] ) ? $f['conditional_logic'] : array();

		if ( empty( $cl['enabled'] ) || empty( $cl['groups'] ) || ! is_array( $cl['groups'] ) ) {
			return true;
		}

		foreach ( $cl['groups'] as $and_rules ) {
			if ( ! is_array( $and_rules ) || array() === $and_rules ) {
				continue;
			}
			$all_ok = true;
			foreach ( $and_rules as $rule ) {
				if ( ! is_array( $rule ) || empty( $rule['field_id'] ) ) {
					$all_ok = false;
					break;
				}
				$dep_id = (int) $rule['field_id'];
				if ( empty( $visible_deps[ $dep_id ] ) ) {
					$all_ok = false;
					break;
				}
				$dep = isset( $sibling_fields[ $dep_id ] ) ? (array) $sibling_fields[ $dep_id ] : null;
				if ( null === $dep ) {
					$all_ok = false;
					break;
				}
				$dep_type = isset( $dep['type'] ) ? $dep['type'] : '';
				$raw_val  = self::get_row_input_value_for_field( $dep_id, $row_input );
				$raw_val  = self::normalize_row_input_value( $dep_type, $raw_val );
				if ( ! self::rule_matches( $dep, $rule, $raw_val ) ) {
					$all_ok = false;
					break;
				}
			}
			if ( $all_ok ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @param int   $field_id         Field being evaluated.
	 * @param array $top_level_fields id => field array/object.
	 * @param array $input            cfgroup input tree.
	 * @param array $visible_deps     Dependency visibility map for this iteration (field_id => bool).
	 * @return bool
	 */
	private static function evaluate_field_visible( $field_id, $top_level_fields, $input, $visible_deps ) {
		$f = isset( $top_level_fields[ $field_id ] ) ? (array) $top_level_fields[ $field_id ] : array();
		$cl = isset( $f['conditional_logic'] ) ? $f['conditional_logic'] : array();

		if ( empty( $cl['enabled'] ) || empty( $cl['groups'] ) || ! is_array( $cl['groups'] ) ) {
			return true;
		}

		foreach ( $cl['groups'] as $and_rules ) {
			if ( ! is_array( $and_rules ) || array() === $and_rules ) {
				continue;
			}
			$all_ok = true;
			foreach ( $and_rules as $rule ) {
				if ( ! is_array( $rule ) || empty( $rule['field_id'] ) ) {
					$all_ok = false;
					break;
				}
				$dep_id = (int) $rule['field_id'];
				if ( empty( $visible_deps[ $dep_id ] ) ) {
					$all_ok = false;
					break;
				}
				$dep = isset( $top_level_fields[ $dep_id ] ) ? (array) $top_level_fields[ $dep_id ] : null;
				if ( null === $dep ) {
					$all_ok = false;
					break;
				}
				$raw_val = self::get_input_value_for_field( $dep_id, $input );
				if ( ! self::rule_matches( $dep, $rule, $raw_val ) ) {
					$all_ok = false;
					break;
				}
			}
			if ( $all_ok ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Raw value for a field from cfgroup[input] POST.
	 *
	 * @param int   $field_id Field id.
	 * @param array $input    cfgroup[input].
	 * @return mixed
	 */
	public static function get_input_value_for_field( $field_id, $input ) {
		$field_id = (int) $field_id;
		if ( ! isset( $input[ $field_id ] ) || ! is_array( $input[ $field_id ] ) ) {
			return null;
		}
		if ( ! array_key_exists( 'value', $input[ $field_id ] ) ) {
			return null;
		}
		return $input[ $field_id ]['value'];
	}

	/**
	 * @param array $dep_field Dependency field definition.
	 * @param array $rule      Single rule (field_id, operator, value).
	 * @param mixed $raw       Value from POST.
	 * @return bool
	 */
	public static function rule_matches( $dep_field, $rule, $raw ) {
		$type = isset( $dep_field['type'] ) ? $dep_field['type'] : '';
		$op   = isset( $rule['operator'] ) ? $rule['operator'] : '==';
		$expect = isset( $rule['value'] ) ? $rule['value'] : '';

		$norm = self::normalize_value( $type, $raw );

		switch ( $op ) {
			case 'empty':
				return self::is_empty_value( $type, $norm );
			case 'not_empty':
				return ! self::is_empty_value( $type, $norm );
			case '==':
				if ( 'number' === $type ) {
					return self::compare_numeric_equality( $norm, $expect );
				}
				return self::compare_equals( $type, $norm, $expect );
			case '!=':
				// Legacy number rules used string inequality.
				if ( 'number' === $type ) {
					return ! self::compare_string_scalar( $norm, $expect );
				}
				return ! self::compare_equals( $type, $norm, $expect );
			case 'contains':
				return self::contains_value( $type, $norm, $expect );
			case 'not_contains':
				return ! self::contains_value( $type, $norm, $expect );
			case 'match':
				return self::match_pattern( $norm, $expect );
			case '<':
			case '<=':
			case '>':
			case '>=':
				if ( 'number' !== $type ) {
					return false;
				}
				return self::compare_numeric_relation( $op, $norm, $expect );
			case 'date_before':
			case 'date_before_or_equal':
			case 'date_after':
			case 'date_after_or_equal':
				if ( 'date' === $type ) {
					$field_ymd = self::parse_ymd_for_cl( $norm );
					$b         = self::parse_ymd_for_cl( is_string( $expect ) ? $expect : ( is_scalar( $expect ) ? (string) $expect : '' ) );
					if ( null === $field_ymd || null === $b ) {
						return false;
					}
					return self::compare_date_relation( $op, $field_ymd, $b );
				}
				if ( 'time' === $type ) {
					$field_hi = self::parse_hi_for_cl( $norm );
					$b        = self::parse_hi_for_cl( is_string( $expect ) ? $expect : ( is_scalar( $expect ) ? (string) $expect : '' ) );
					if ( null === $field_hi || null === $b ) {
						return false;
					}
					return self::compare_date_relation( $op, $field_hi, $b );
				}
				if ( 'datetime' === $type ) {
					$field_ymdhi = self::parse_ymd_hi_for_cl( $norm );
					$b           = self::parse_ymd_hi_for_cl( is_string( $expect ) ? $expect : ( is_scalar( $expect ) ? (string) $expect : '' ) );
					if ( null === $field_ymdhi || null === $b ) {
						return false;
					}
					return self::compare_date_relation( $op, $field_ymdhi, $b );
				}
				return false;
			case 'date_between':
				if ( 'date' === $type ) {
					$field_ymd = self::parse_ymd_for_cl( $norm );
					if ( null === $field_ymd ) {
						return false;
					}
					if ( ! is_array( $expect ) ) {
						return false;
					}
					$start = isset( $expect['start'] ) ? self::parse_ymd_for_cl( $expect['start'] ) : null;
					$end   = isset( $expect['end'] ) ? self::parse_ymd_for_cl( $expect['end'] ) : null;
					if ( null === $start || null === $end ) {
						return false;
					}
					return ( $start <= $field_ymd && $field_ymd <= $end );
				}
				if ( 'time' === $type ) {
					$field_hi = self::parse_hi_for_cl( $norm );
					if ( null === $field_hi ) {
						return false;
					}
					if ( ! is_array( $expect ) ) {
						return false;
					}
					$start = isset( $expect['start'] ) ? self::parse_hi_for_cl( $expect['start'] ) : null;
					$end   = isset( $expect['end'] ) ? self::parse_hi_for_cl( $expect['end'] ) : null;
					if ( null === $start || null === $end ) {
						return false;
					}
					return ( $start <= $field_hi && $field_hi <= $end );
				}
				if ( 'datetime' === $type ) {
					$field_ymdhi = self::parse_ymd_hi_for_cl( $norm );
					if ( null === $field_ymdhi ) {
						return false;
					}
					if ( ! is_array( $expect ) ) {
						return false;
					}
					$start = isset( $expect['start'] ) ? self::parse_ymd_hi_for_cl( $expect['start'] ) : null;
					$end   = isset( $expect['end'] ) ? self::parse_ymd_hi_for_cl( $expect['end'] ) : null;
					if ( null === $start || null === $end ) {
						return false;
					}
					return ( $start <= $field_ymdhi && $field_ymdhi <= $end );
				}
				return false;
			default:
				return false;
		}
	}

	/**
	 * Parse a Y-m-d string for conditional date rules.
	 *
	 * @param mixed $raw Raw or normalized value.
	 * @return string|null Normalized Y-m-d or null if invalid.
	 */
	private static function parse_ymd_for_cl( $raw ) {
		$raw = self::unwrap_repeater_scalar_row_value( $raw );
		if ( null === $raw || is_array( $raw ) ) {
			return null;
		}
		$s = trim( (string) $raw );
		if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $s, $m ) ) {
			return null;
		}
		$y  = (int) $m[1];
		$mo = (int) $m[2];
		$d  = (int) $m[3];
		if ( ! checkdate( $mo, $d, $y ) ) {
			return null;
		}
		return sprintf( '%04d-%02d-%02d', $y, $mo, $d );
	}

	/**
	 * Sanitize a single segment to Y-m-d or empty string.
	 *
	 * @param mixed $val Raw.
	 * @return string
	 */
	private static function sanitize_ymd_segment( $val ) {
		$s = sanitize_text_field( wp_unslash( (string) $val ) );
		$p = self::parse_ymd_for_cl( $s );
		return null !== $p ? $p : '';
	}

	/**
	 * Parse a time string for conditional time rules (canonical H:i, 24-hour).
	 *
	 * Accepts H:i from the field (and rule) or 12-hour strings parseable via strtotime (e.g. Flatpickr G:i K).
	 *
	 * @param mixed $raw Raw or normalized value.
	 * @return string|null Normalized H:i or null if invalid.
	 */
	private static function parse_hi_for_cl( $raw ) {
		$raw = self::unwrap_repeater_scalar_row_value( $raw );
		if ( null === $raw || is_array( $raw ) ) {
			return null;
		}
		$s = trim( (string) $raw );
		if ( '' === $s ) {
			return null;
		}
		if ( preg_match( '/^(\d{1,2}):(\d{2})$/', $s, $m ) ) {
			$h = (int) $m[1];
			$i = (int) $m[2];
			if ( $h >= 0 && $h <= 23 && $i >= 0 && $i <= 59 ) {
				return sprintf( '%02d:%02d', $h, $i );
			}
			return null;
		}
		// phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date
		$ts = strtotime( '2000-01-01 ' . $s );
		if ( false === $ts ) {
			return null;
		}
		// phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date
		return date( 'H:i', $ts );
	}

	/**
	 * Sanitize a single segment to H:i or empty string.
	 *
	 * @param mixed $val Raw.
	 * @return string
	 */
	private static function sanitize_hi_segment( $val ) {
		$s = sanitize_text_field( wp_unslash( (string) $val ) );
		$p = self::parse_hi_for_cl( $s );
		return null !== $p ? $p : '';
	}

	/**
	 * Parse a datetime string for conditional datetime rules (canonical Y-m-d H:i, 24-hour).
	 *
	 * Accepts strict Y-m-d H:i from the field or rule, or other strings parseable via strtotime (e.g. Flatpickr Y-m-d G:i K).
	 *
	 * @param mixed $raw Raw or normalized value.
	 * @return string|null Normalized Y-m-d H:i or null if invalid.
	 */
	private static function parse_ymd_hi_for_cl( $raw ) {
		$raw = self::unwrap_repeater_scalar_row_value( $raw );
		if ( null === $raw || is_array( $raw ) ) {
			return null;
		}
		$s = trim( (string) $raw );
		if ( '' === $s ) {
			return null;
		}
		if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2})$/', $s, $m ) ) {
			$y  = (int) $m[1];
			$mo = (int) $m[2];
			$d  = (int) $m[3];
			$h  = (int) $m[4];
			$i  = (int) $m[5];
			if ( ! checkdate( $mo, $d, $y ) ) {
				return null;
			}
			if ( $h < 0 || $h > 23 || $i < 0 || $i > 59 ) {
				return null;
			}
			return sprintf( '%04d-%02d-%02d %02d:%02d', $y, $mo, $d, $h, $i );
		}
		// phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date
		$ts = strtotime( $s );
		if ( false === $ts ) {
			return null;
		}
		// phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date
		return date( 'Y-m-d H:i', $ts );
	}

	/**
	 * Sanitize a single segment to Y-m-d H:i or empty string.
	 *
	 * @param mixed $val Raw.
	 * @return string
	 */
	private static function sanitize_ymd_hi_segment( $val ) {
		$s = sanitize_text_field( wp_unslash( (string) $val ) );
		$p = self::parse_ymd_hi_for_cl( $s );
		return null !== $p ? $p : '';
	}

	/**
	 * Calendar comparison for date field rules (Y-m-d strings).
	 *
	 * @param string $op          One of date_before, date_before_or_equal, date_after, date_after_or_equal.
	 * @param string $field_ymd   Field value Y-m-d.
	 * @param string $boundary_ymd Boundary Y-m-d.
	 * @return bool
	 */
	private static function compare_date_relation( $op, $field_ymd, $boundary_ymd ) {
		switch ( $op ) {
			case 'date_before':
				return $field_ymd < $boundary_ymd;
			case 'date_before_or_equal':
				return $field_ymd <= $boundary_ymd;
			case 'date_after':
				return $field_ymd > $boundary_ymd;
			case 'date_after_or_equal':
				return $field_ymd >= $boundary_ymd;
			default:
				return false;
		}
	}

	/**
	 * Parse a scalar for numeric conditional rules; invalid or empty input yields null.
	 *
	 * @param mixed $raw Raw or normalized value.
	 * @return float|null
	 */
	private static function parse_numeric_for_cl( $raw ) {
		$raw = self::unwrap_repeater_scalar_row_value( $raw );
		if ( null === $raw || is_array( $raw ) ) {
			return null;
		}
		$s = trim( (string) $raw );
		if ( '' === $s ) {
			return null;
		}
		if ( ! is_numeric( $s ) ) {
			return null;
		}
		return (float) $s + 0.0;
	}

	/**
	 * Numeric equality for number field (==).
	 *
	 * @param mixed $norm   Normalized value.
	 * @param mixed $expect Rule compare value.
	 * @return bool
	 */
	private static function compare_numeric_equality( $norm, $expect ) {
		$left  = self::parse_numeric_for_cl( $norm );
		$right = self::parse_numeric_for_cl( $expect );
		if ( null === $left || null === $right ) {
			return false;
		}
		// Loose compare: parsed values are floats; avoids strict binary float quirks.
		return (float) $left == (float) $right;
	}

	/**
	 * Legacy string scalar compare for number field (!=).
	 *
	 * @param mixed $norm   Normalized value.
	 * @param mixed $expect Rule value.
	 * @return bool
	 */
	private static function compare_string_scalar( $norm, $expect ) {
		if ( is_array( $norm ) ) {
			$exp = is_array( $expect ) ? $expect : array( $expect );
			$n = array_map( 'strval', array_values( $norm ) );
			$e = array_map( 'strval', array_values( $exp ) );
			sort( $n );
			sort( $e );
			return $n === $e;
		}
		return (string) $norm === (string) $expect;
	}

	/**
	 * Relational comparison for number field (<, <=, >, >=).
	 *
	 * @param string $op     Operator.
	 * @param mixed  $norm   Normalized field value.
	 * @param mixed  $expect Rule compare value.
	 * @return bool
	 */
	private static function compare_numeric_relation( $op, $norm, $expect ) {
		$left  = self::parse_numeric_for_cl( $norm );
		$right = self::parse_numeric_for_cl( $expect );
		if ( null === $left || null === $right ) {
			return false;
		}
		switch ( $op ) {
			case '<':
				return $left < $right;
			case '<=':
				return $left <= $right;
			case '>':
				return $left > $right;
			case '>=':
				return $left >= $right;
			default:
				return false;
		}
	}

	/**
	 * @param string $type Field type.
	 * @param mixed  $raw  Raw POST value.
	 * @return mixed Normalized for comparisons.
	 */
	public static function normalize_value( $type, $raw ) {
		if ( null === $raw ) {
			return null;
		}
		if ( 'true_false' === $type ) {
			return (string) (int) (bool) $raw;
		}
		if ( is_array( $raw ) ) {
			return $raw;
		}
		return (string) $raw;
	}

	/**
	 * Whether WYSIWYG HTML has no visible text (for empty / not_empty only).
	 *
	 * @param mixed $norm Normalized value (usually HTML string).
	 * @return bool True if visually empty.
	 */
	private static function wysiwyg_is_visually_empty( $norm ) {
		if ( null === $norm ) {
			return true;
		}
		if ( is_array( $norm ) ) {
			return array() === $norm;
		}
		$s = wp_strip_all_tags( (string) $norm );
		$s = str_replace( array( "\xc2\xa0", '&nbsp;' ), ' ', $s );
		$s = trim( preg_replace( '/\s+/u', ' ', $s ) );
		return '' === $s;
	}

	/**
	 * @param string $type Field type.
	 * @param mixed  $norm Normalized value.
	 * @return bool
	 */
	public static function is_empty_value( $type, $norm ) {
		if ( null === $norm ) {
			return true;
		}
		if ( 'repeater' === $type ) {
			return ! is_array( $norm ) || array() === $norm;
		}
		if ( 'hyperlink' === $type && is_array( $norm ) ) {
			$norm = self::normalize_hyperlink_row_value( $norm );
			$url  = isset( $norm['url'] ) ? trim( (string) $norm['url'] ) : '';
			$text = isset( $norm['text'] ) ? trim( (string) $norm['text'] ) : '';
			return '' === $url && '' === $text;
		}
		if ( is_array( $norm ) ) {
			return array() === $norm;
		}
		if ( 'wysiwyg' === $type ) {
			return self::wysiwyg_is_visually_empty( $norm );
		}
		$s = trim( (string) $norm );
		if ( '' === $s ) {
			return true;
		}
		if ( in_array( $type, array( 'file', 'gallery', 'relationship', 'term', 'user' ), true ) ) {
			return '' === $s || '0' === $s;
		}
		return false;
	}

	/**
	 * @param string $type   Field type.
	 * @param mixed  $norm   Normalized.
	 * @param mixed  $expect Rule value.
	 * @return bool
	 */
	private static function compare_equals( $type, $norm, $expect ) {
		if ( is_array( $norm ) ) {
			$exp = is_array( $expect ) ? $expect : array( $expect );
			$n = array_map( 'strval', array_values( $norm ) );
			$e = array_map( 'strval', array_values( $exp ) );
			sort( $n );
			sort( $e );
			return $n === $e;
		}
		return (string) $norm === (string) $expect;
	}

	/**
	 * @param string $type   Field type.
	 * @param mixed  $norm   Normalized.
	 * @param mixed  $expect Needle.
	 * @return bool
	 */
	private static function contains_value( $type, $norm, $expect ) {
		if ( 'hyperlink' === $type && is_array( $norm ) ) {
			$norm   = self::normalize_hyperlink_row_value( $norm );
			$url    = isset( $norm['url'] ) ? (string) $norm['url'] : '';
			$text   = isset( $norm['text'] ) ? (string) $norm['text'] : '';
			$needle = (string) $expect;
			return false !== strpos( $url, $needle ) || false !== strpos( $text, $needle );
		}
		if ( 'repeater' === $type ) {
			$needle = trim( (string) $expect );
			if ( '' === $needle ) {
				return false;
			}
			$haystack = self::repeater_flatten_for_contains( $norm );
			return false !== strpos( $haystack, $needle );
		}
		if ( is_array( $norm ) ) {
			return in_array( (string) $expect, array_map( 'strval', $norm ), true );
		}
		return false !== strpos( (string) $norm, (string) $expect );
	}

	/**
	 * Concatenate all scalar sub-field text from repeater POST data for "contains" matching.
	 *
	 * @param mixed $data Raw or normalized repeater value (nested arrays).
	 * @return string
	 */
	private static function repeater_flatten_for_contains( $data ) {
		$parts = array();
		self::repeater_flatten_for_contains_rec( $data, $parts );
		return implode( "\n", $parts );
	}

	/**
	 * @param mixed    $data  Repeater row or nested fragment.
	 * @param string[] $parts Out parameter of string fragments.
	 * @return void
	 */
	private static function repeater_flatten_for_contains_rec( $data, array &$parts ) {
		if ( null === $data ) {
			return;
		}
		if ( is_scalar( $data ) ) {
			$s = self::repeater_scalar_for_contains( $data );
			if ( '' !== $s ) {
				$parts[] = $s;
			}
			return;
		}
		if ( ! is_array( $data ) ) {
			return;
		}
		if ( array_key_exists( 'url', $data ) || array_key_exists( 'text', $data ) ) {
			if ( isset( $data['url'] ) ) {
				$s = self::repeater_scalar_for_contains( $data['url'] );
				if ( '' !== $s ) {
					$parts[] = $s;
				}
			}
			if ( isset( $data['text'] ) ) {
				$s = self::repeater_scalar_for_contains( $data['text'] );
				if ( '' !== $s ) {
					$parts[] = $s;
				}
			}
			return;
		}
		foreach ( $data as $val ) {
			self::repeater_flatten_for_contains_rec( $val, $parts );
		}
	}

	/**
	 * Normalize a scalar sub-field value for substring search (strip tags when HTML-like).
	 *
	 * @param mixed $data Scalar.
	 * @return string
	 */
	private static function repeater_scalar_for_contains( $data ) {
		$s = trim( (string) $data );
		if ( '' === $s ) {
			return '';
		}
		if ( false !== strpos( $s, '<' ) ) {
			$s = wp_strip_all_tags( $s );
			$s = str_replace( array( "\xc2\xa0", '&nbsp;' ), ' ', $s );
			$s = trim( preg_replace( '/\s+/u', ' ', $s ) );
		}
		return $s;
	}

	/**
	 * @param mixed  $norm   Normalized string.
	 * @param string $pattern Regex.
	 * @return bool
	 */
	private static function match_pattern( $norm, $pattern ) {
		$pattern = (string) $pattern;
		if ( '' === $pattern ) {
			return false;
		}
		$s = is_array( $norm ) ? '' : (string) $norm;
		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return 1 === @preg_match( $pattern, $s );
	}

	/**
	 * @param string $type Field type.
	 * @param string $op   Operator.
	 * @return bool
	 */
	public static function is_operator_allowed_for_type( $type, $op ) {
		$ops = self::operators_for_type( $type );
		// Legacy: allow saved rules that used "has no value" before it was removed from the UI.
		if ( in_array( $type, array( 'file', 'gallery', 'relationship', 'term', 'user' ), true ) ) {
			$ops = array_merge( $ops, array( 'empty' ) );
		}
		if ( 'number' === $type ) {
			$ops = array_merge( $ops, self::$legacy_number_operators );
		}
		if ( 'date' === $type ) {
			$ops = array_merge( $ops, self::$legacy_date_operators );
		}
		if ( 'time' === $type ) {
			$ops = array_merge( $ops, self::$legacy_time_operators );
		}
		if ( 'datetime' === $type ) {
			$ops = array_merge( $ops, self::$legacy_datetime_operators );
		}
		if ( in_array( $type, array( 'text', 'textarea', 'wysiwyg', 'color' ), true ) ) {
			$ops = array_merge( $ops, self::$legacy_textual_operators );
		}
		if ( 'repeater' === $type ) {
			$ops = array_merge( $ops, self::$legacy_repeater_operators );
		}
		return in_array( $op, $ops, true );
	}

	/**
	 * Operators available for a dependency field type (editor + server).
	 *
	 * @param string $type Field type.
	 * @return string[]
	 */
	public static function operators_for_type( $type ) {
		if ( 'hyperlink' === $type ) {
			return array( 'not_empty', 'contains' );
		}

		if ( 'number' === $type ) {
			return array( 'not_empty', '<', '<=', '==', '>', '>=' );
		}

		if ( 'date' === $type ) {
			return array(
				'not_empty',
				'date_before',
				'date_before_or_equal',
				'date_between',
				'date_after_or_equal',
				'date_after',
			);
		}

		if ( 'time' === $type ) {
			return array(
				'not_empty',
				'date_before',
				'date_before_or_equal',
				'date_between',
				'date_after_or_equal',
				'date_after',
			);
		}

		if ( 'datetime' === $type ) {
			return array(
				'not_empty',
				'date_before',
				'date_before_or_equal',
				'date_between',
				'date_after_or_equal',
				'date_after',
			);
		}

		$textual = array( 'text', 'textarea', 'wysiwyg', 'color' );
		$choice  = array( 'radio', 'select' );
		$multi   = array( 'checkbox' );

		if ( in_array( $type, $textual, true ) ) {
			return array( 'not_empty', '==', '!=', 'contains', 'match' );
		}
		if ( 'true_false' === $type ) {
			return array( '==', '!=' );
		}
		if ( in_array( $type, $choice, true ) ) {
			return array( 'not_empty', '==', '!=' );
		}
		if ( in_array( $type, $multi, true ) ) {
			return array( 'not_empty', 'contains', 'not_contains' );
		}
		if ( in_array( $type, array( 'file', 'gallery', 'relationship', 'term', 'user' ), true ) ) {
			return array( 'not_empty' );
		}

		if ( 'repeater' === $type ) {
			return array( 'not_empty', 'contains' );
		}

		return array( 'empty', 'not_empty', '==', '!=', 'contains', 'match' );
	}

	/**
	 * @param string $type Field type.
	 * @param string $op   Operator.
	 * @param mixed  $val  Raw value.
	 * @return mixed
	 */
	private static function sanitize_rule_value( $type, $op, $val ) {
		if ( in_array( $op, array( 'empty', 'not_empty' ), true ) ) {
			return '';
		}
		if ( 'match' === $op ) {
			return sanitize_text_field( wp_unslash( (string) $val ) );
		}
		if ( 'true_false' === $type && in_array( $op, array( '==', '!=' ), true ) ) {
			// Rule always compares against the checked state (1); operator distinguishes checked vs not checked.
			return '1';
		}
		if ( 'date' === $type ) {
			if ( 'date_between' === $op ) {
				if ( ! is_array( $val ) ) {
					return array(
						'start' => '',
						'end'   => '',
					);
				}
				$start = isset( $val['start'] ) ? self::sanitize_ymd_segment( $val['start'] ) : '';
				$end   = isset( $val['end'] ) ? self::sanitize_ymd_segment( $val['end'] ) : '';
				if ( '' !== $start && '' !== $end && $start > $end ) {
					return array(
						'start' => $end,
						'end'   => $start,
					);
				}
				return array(
					'start' => $start,
					'end'   => $end,
				);
			}
			if ( in_array( $op, array( 'date_before', 'date_before_or_equal', 'date_after', 'date_after_or_equal' ), true ) ) {
				return self::sanitize_ymd_segment( is_array( $val ) ? '' : $val );
			}
		}
		if ( 'time' === $type ) {
			if ( 'date_between' === $op ) {
				if ( ! is_array( $val ) ) {
					return array(
						'start' => '',
						'end'   => '',
					);
				}
				$start = isset( $val['start'] ) ? self::sanitize_hi_segment( $val['start'] ) : '';
				$end   = isset( $val['end'] ) ? self::sanitize_hi_segment( $val['end'] ) : '';
				if ( '' !== $start && '' !== $end && $start > $end ) {
					return array(
						'start' => $end,
						'end'   => $start,
					);
				}
				return array(
					'start' => $start,
					'end'   => $end,
				);
			}
			if ( in_array( $op, array( 'date_before', 'date_before_or_equal', 'date_after', 'date_after_or_equal' ), true ) ) {
				return self::sanitize_hi_segment( is_array( $val ) ? '' : $val );
			}
		}
		if ( 'datetime' === $type ) {
			if ( 'date_between' === $op ) {
				if ( ! is_array( $val ) ) {
					return array(
						'start' => '',
						'end'   => '',
					);
				}
				$start = isset( $val['start'] ) ? self::sanitize_ymd_hi_segment( $val['start'] ) : '';
				$end   = isset( $val['end'] ) ? self::sanitize_ymd_hi_segment( $val['end'] ) : '';
				if ( '' !== $start && '' !== $end && $start > $end ) {
					return array(
						'start' => $end,
						'end'   => $start,
					);
				}
				return array(
					'start' => $start,
					'end'   => $end,
				);
			}
			if ( in_array( $op, array( 'date_before', 'date_before_or_equal', 'date_after', 'date_after_or_equal' ), true ) ) {
				return self::sanitize_ymd_hi_segment( is_array( $val ) ? '' : $val );
			}
		}
		if ( is_array( $val ) ) {
			return array_map( 'sanitize_text_field', array_map( 'wp_unslash', $val ) );
		}
		return sanitize_text_field( wp_unslash( (string) $val ) );
	}
}
