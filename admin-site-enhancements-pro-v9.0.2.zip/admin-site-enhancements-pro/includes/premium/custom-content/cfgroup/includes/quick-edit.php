<?php
/**
 * Custom Field Groups — Quick Edit support.
 *
 * @since 8.9.1
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Class cfgroup_quick_edit
 *
 * Registers a hidden list-table column, renders Quick Edit fields grouped by
 * field group (and tab sub-headings when needed), populates values via JS, and
 * saves through the CFG API.
 */
class cfgroup_quick_edit {

	/**
	 * List-table / Quick Edit column key.
	 *
	 * @var string
	 */
	const COLUMN_KEY = 'asenha_cfgroup_qe';

	/**
	 * POST / nonce field name prefix.
	 *
	 * @var string
	 */
	const INPUT_NAME = 'asenha_cfgroup_qe';

	/**
	 * Cached map of post_type => structured QE field data for the request.
	 *
	 * @var array|null
	 */
	private $post_type_fields_cache = null;

	/**
	 * Whether the Quick Edit custom box was already printed for a post type.
	 *
	 * @var array
	 */
	private $printed_boxes = array();

	/**
	 * Constructor — register hooks.
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'register_list_table_hooks' ) );
		add_action( 'quick_edit_custom_box', array( $this, 'render_quick_edit_box' ), 10, 2 );
		add_action( 'save_post', array( $this, 'save_quick_edit' ), 20, 2 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_ajax_asenha_cfgroup_qe_search_posts', array( $this, 'ajax_search_posts' ) );
		add_action( 'wp_ajax_asenha_cfgroup_qe_search_terms', array( $this, 'ajax_search_terms' ) );
		add_action( 'wp_ajax_asenha_cfgroup_qe_search_users', array( $this, 'ajax_search_users' ) );
		add_filter( 'default_hidden_columns', array( $this, 'default_hidden_columns' ), 10, 2 );
		add_filter( 'hidden_columns', array( $this, 'force_hide_column' ), 10, 2 );
	}

	/**
	 * Supported field types for Quick Edit.
	 *
	 * @return string[]
	 */
	public static function supported_types() {
		return array(
			'text',
			'textarea',
			'number',
			'true_false',
			'select',
			'radio',
			'checkbox',
			'date',
			'time',
			'datetime',
			'color',
			'hyperlink',
			'map',
			'wysiwyg',
			'file',
			'gallery',
			'relationship',
			'term',
			'user',
		);
	}

	/**
	 * Whether a field type is supported in the current Quick Edit phase.
	 *
	 * @param string $type Field type slug.
	 * @return bool
	 */
	public static function is_supported_type( $type ) {
		return in_array( (string) $type, self::supported_types(), true );
	}

	/**
	 * Whether a field stores multiple choice values (checkbox or multi-select).
	 *
	 * @param array $field Field definition.
	 * @return bool
	 */
	public static function is_multi_value_choice_field( $field ) {
		$type = isset( $field['type'] ) ? $field['type'] : '';

		if ( 'checkbox' === $type ) {
			return true;
		}

		if ( 'select' === $type && ! empty( $field['options']['multiple'] ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Normalize choices map: {empty} key becomes empty string value key.
	 *
	 * @param array $choices Raw choices.
	 * @return array
	 */
	public static function normalize_choices( $choices ) {
		if ( ! is_array( $choices ) ) {
			return array();
		}

		$normalized = array();

		foreach ( $choices as $val => $label ) {
			$key                  = ( '{empty}' === (string) $val ) ? '' : (string) $val;
			$normalized[ $key ] = $label;
		}

		return $normalized;
	}

	/**
	 * Register list-table column hooks for post types that have QE fields.
	 *
	 * @return void
	 */
	public function register_list_table_hooks() {
		$post_types = array_keys( $this->get_post_types_with_qe_fields() );

		foreach ( $post_types as $post_type ) {
			add_filter( "manage_{$post_type}_posts_columns", array( $this, 'add_column' ) );
			add_action( "manage_{$post_type}_posts_custom_column", array( $this, 'render_column' ), 10, 2 );
		}
	}

	/**
	 * Add the helper column.
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public function add_column( $columns ) {
		if ( ! is_array( $columns ) ) {
			$columns = array();
		}

		$columns[ self::COLUMN_KEY ] = __( 'CFG Quick Edit', 'admin-site-enhancements' );

		return $columns;
	}

	/**
	 * Hide the helper column by default in Screen Options.
	 *
	 * @param array     $hidden Hidden columns.
	 * @param WP_Screen $screen Current screen.
	 * @return array
	 */
	public function default_hidden_columns( $hidden, $screen = null ) {
		if ( ! is_array( $hidden ) ) {
			$hidden = array();
		}

		if ( ! $this->is_target_list_screen( $screen ) ) {
			return $hidden;
		}

		if ( ! in_array( self::COLUMN_KEY, $hidden, true ) ) {
			$hidden[] = self::COLUMN_KEY;
		}

		return $hidden;
	}

	/**
	 * Force-hide the helper column on list tables.
	 *
	 * @param array     $hidden Hidden columns.
	 * @param WP_Screen $screen Current screen.
	 * @return array
	 */
	public function force_hide_column( $hidden, $screen ) {
		if ( ! is_array( $hidden ) ) {
			$hidden = array();
		}

		if ( ! $this->is_target_list_screen( $screen ) ) {
			return $hidden;
		}

		if ( ! in_array( self::COLUMN_KEY, $hidden, true ) ) {
			$hidden[] = self::COLUMN_KEY;
		}

		return $hidden;
	}

	/**
	 * Whether the screen is a post list table that has QE fields.
	 *
	 * @param WP_Screen|null $screen Screen.
	 * @return bool
	 */
	private function is_target_list_screen( $screen ) {
		if ( ! ( $screen instanceof WP_Screen ) ) {
			return false;
		}

		if ( 'edit' !== $screen->base ) {
			return false;
		}

		$post_type = isset( $screen->post_type ) ? (string) $screen->post_type : '';
		if ( '' === $post_type ) {
			return false;
		}

		$map = $this->get_post_types_with_qe_fields();

		return isset( $map[ $post_type ] );
	}

	/**
	 * Output per-row JSON of Quick Edit field values.
	 *
	 * @param string $column_name Column slug.
	 * @param int    $post_id     Post ID.
	 * @return void
	 */
	public function render_column( $column_name, $post_id ) {
		if ( self::COLUMN_KEY !== $column_name ) {
			return;
		}

		$post_id   = (int) $post_id;
		$post_type = get_post_type( $post_id );
		$groups    = $this->get_qe_groups_for_post_type( $post_type );

		if ( empty( $groups ) ) {
			echo '<span class="asenha-cfgroup-qe-data" data-cfgroup-qe="{}"></span>';
			return;
		}

		$values = array();

		foreach ( $groups as $group ) {
			foreach ( $group['fields'] as $field ) {
				$field_id = (int) $field['id'];
				$name     = $field['name'];
				$raw      = CFG()->get( $name, $post_id, array( 'format' => 'raw' ) );

				if ( self::is_multi_value_choice_field( $field ) ) {
					if ( null === $raw || '' === $raw ) {
						$values[ $field_id ] = array();
					} elseif ( is_array( $raw ) ) {
						$values[ $field_id ] = array_values( $raw );
					} else {
						$values[ $field_id ] = array( $raw );
					}
					continue;
				}

				if ( 'hyperlink' === $field['type'] ) {
					$values[ $field_id ] = $this->normalize_qe_hyperlink_value( $raw );
					continue;
				}

				if ( 'map' === $field['type'] ) {
					$values[ $field_id ] = self::normalize_qe_map_value( $raw );
					continue;
				}

				if ( 'file' === $field['type'] ) {
					$values[ $field_id ] = $this->normalize_qe_file_value( $raw, $field );
					continue;
				}

				if ( 'gallery' === $field['type'] ) {
					$values[ $field_id ] = $this->normalize_qe_gallery_value( $raw );
					continue;
				}

				if ( 'relationship' === $field['type'] ) {
					$values[ $field_id ] = $this->normalize_qe_relationship_value( $raw, $field );
					continue;
				}

				if ( 'term' === $field['type'] ) {
					$values[ $field_id ] = $this->normalize_qe_term_value( $raw, $field );
					continue;
				}

				if ( 'user' === $field['type'] ) {
					$values[ $field_id ] = $this->normalize_qe_user_value( $raw, $field );
					continue;
				}

				if ( is_array( $raw ) ) {
					$raw = isset( $raw[0] ) ? $raw[0] : '';
				}

				if ( 'true_false' === $field['type'] ) {
					$values[ $field_id ] = ( 0 < (int) $raw ) ? 1 : 0;
				} elseif ( null === $raw || '' === $raw ) {
					$values[ $field_id ] = '';
				} else {
					$values[ $field_id ] = $this->format_value_for_qe_input( $raw, $field );
				}
			}
		}

		echo '<span class="asenha-cfgroup-qe-data" data-cfgroup-qe="' . esc_attr( wp_json_encode( $values ) ) . '"></span>';
	}

	/**
	 * Render Quick Edit fieldsets for CFG fields.
	 *
	 * @param string $column_name Column being rendered.
	 * @param string $post_type   Post type.
	 * @return void
	 */
	public function render_quick_edit_box( $column_name, $post_type ) {
		if ( self::COLUMN_KEY !== $column_name ) {
			return;
		}

		if ( isset( $this->printed_boxes[ $post_type ] ) ) {
			return;
		}

		$groups = $this->get_qe_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return;
		}

		$this->printed_boxes[ $post_type ] = true;

		wp_nonce_field( 'asenha_cfgroup_quick_edit', 'asenha_cfgroup_quick_edit_nonce' );

		foreach ( $groups as $group ) {
			$this->render_group_fieldset( $group );
		}
	}

	/**
	 * Render one field group fieldset.
	 *
	 * @param array $group Structured group data from get_qe_groups_for_post_type().
	 * @return void
	 */
	private function render_group_fieldset( $group ) {
		$show_tabs = ! empty( $group['show_tab_headings'] );
		$fields    = isset( $group['fields'] ) && is_array( $group['fields'] ) ? $group['fields'] : array();
		?>
		<fieldset class="asenha-cfgroup-qe">
			<div class="inline-edit-col">
				<h4 class="asenha-cfgroup-qe-heading"><?php echo esc_html( $group['title'] ); ?></h4>
				<?php
				if ( ! $show_tabs ) {
					$this->render_qe_fields_grid( $fields );
				} else {
					$untabbed = array();
					$buckets  = array();

					foreach ( $fields as $field ) {
						$tab_key = isset( $field['tab_key'] ) ? (string) $field['tab_key'] : '';
						if ( '' === $tab_key ) {
							$untabbed[] = $field;
							continue;
						}
						if ( ! isset( $buckets[ $tab_key ] ) ) {
							$buckets[ $tab_key ] = array(
								'label'  => isset( $field['tab_label'] ) ? (string) $field['tab_label'] : $tab_key,
								'fields' => array(),
							);
						}
						$buckets[ $tab_key ]['fields'][] = $field;
					}

					if ( ! empty( $untabbed ) ) {
						$this->render_qe_fields_grid( $untabbed );
					}

					if ( ! empty( $buckets ) ) {
						$first = true;
						?>
						<div class="asenha-cfgroup-qe-tabs" role="tablist">
							<?php foreach ( $buckets as $tab_key => $bucket ) : ?>
								<button
									type="button"
									class="asenha-cfgroup-qe-tab<?php echo $first ? ' active' : ''; ?>"
									role="tab"
									aria-selected="<?php echo $first ? 'true' : 'false'; ?>"
									data-tab="<?php echo esc_attr( $tab_key ); ?>"
								><?php echo esc_html( $bucket['label'] ); ?></button>
								<?php
								$first = false;
							endforeach;
							?>
						</div>
						<?php
						$first = true;
						foreach ( $buckets as $tab_key => $bucket ) :
							?>
							<div
								class="asenha-cfgroup-qe-tab-pane<?php echo $first ? ' active' : ''; ?>"
								role="tabpanel"
								data-tab="<?php echo esc_attr( $tab_key ); ?>"
								<?php echo $first ? '' : ' hidden'; ?>
							>
								<?php $this->render_qe_fields_grid( $bucket['fields'] ); ?>
							</div>
							<?php
							$first = false;
						endforeach;
					}
				}
				?>
			</div>
		</fieldset>
		<?php
	}

	/**
	 * Render a grid wrapper containing Quick Edit field controls.
	 *
	 * @param array $fields Field definitions.
	 * @return void
	 */
	private function render_qe_fields_grid( $fields ) {
		if ( empty( $fields ) || ! is_array( $fields ) ) {
			return;
		}
		echo '<div class="asenha-cfgroup-qe-fields">';
		foreach ( $fields as $field ) {
			$this->render_field_control( $field );
		}
		echo '</div>';
	}

	/**
	 * Render a single Quick Edit control for a supported field type.
	 *
	 * @param array $field Field definition.
	 * @return void
	 */
	private function render_field_control( $field ) {
		$field_id   = (int) $field['id'];
		$input_name = self::INPUT_NAME . '[' . $field_id . ']';
		$input_id   = 'asenha-cfgroup-qe-' . $field_id;
		$label      = isset( $field['label'] ) ? $field['label'] : $field['name'];
		$type       = $field['type'];
		$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();

		switch ( $type ) {
			case 'textarea':
				?>
				<label class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-textarea">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<textarea name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-qe-input" rows="3" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="<?php echo esc_attr( $type ); ?>"></textarea>
					</span>
				</label>
				<?php
				break;

			case 'number':
				$attrs = '';
				if ( isset( $options['min'] ) && '' !== $options['min'] ) {
					$attrs .= ' min="' . esc_attr( $options['min'] ) . '"';
				}
				if ( isset( $options['max'] ) && '' !== $options['max'] ) {
					$attrs .= ' max="' . esc_attr( $options['max'] ) . '"';
				}
				if ( isset( $options['step'] ) && '' !== $options['step'] ) {
					$attrs .= ' step="' . esc_attr( $options['step'] ) . '"';
				} else {
					$attrs .= ' step="any"';
				}
				?>
				<label class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-number">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<input type="number" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-qe-input" value="" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="<?php echo esc_attr( $type ); ?>"<?php echo $attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above ?> />
					</span>
				</label>
				<?php
				break;

			case 'true_false':
				$message = isset( $options['message'] ) ? $options['message'] : '';
				?>
				<label class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-true-false">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<input type="hidden" name="<?php echo esc_attr( $input_name ); ?>" value="0" />
						<input type="checkbox" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-qe-input asenha-cfgroup-qe-checkbox" value="1" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="<?php echo esc_attr( $type ); ?>" />
						<?php if ( '' !== $message ) : ?>
							<span class="asenha-cfgroup-qe-checkbox-message"><?php echo esc_html( $message ); ?></span>
						<?php endif; ?>
					</span>
				</label>
				<?php
				break;

			case 'select':
				if ( ! empty( $options['multiple'] ) ) {
					$this->render_choice_checkboxes( $field, $input_name, $label, 'select_multiple' );
				} else {
					$this->render_select_single( $field, $input_name, $input_id, $label );
				}
				break;

			case 'radio':
				$this->render_choice_radios( $field, $input_name, $label );
				break;

			case 'checkbox':
				$this->render_choice_checkboxes( $field, $input_name, $label, 'checkbox' );
				break;

			case 'date':
				if ( ! empty( $options['year_only'] ) ) {
					?>
					<label class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-date-year">
						<span class="title"><?php echo esc_html( $label ); ?></span>
						<span class="input-text-wrap">
							<input type="number" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-qe-input asenha-cfgroup-qe-year" value="" min="1000" max="9999" step="1" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="date_year" />
						</span>
					</label>
					<?php
				} else {
					?>
					<label class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-date">
						<span class="title"><?php echo esc_html( $label ); ?></span>
						<span class="input-text-wrap">
							<input type="date" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-qe-input" value="" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="date" />
						</span>
					</label>
					<?php
				}
				break;

			case 'time':
				$step_minutes = isset( $options['step'] ) ? absint( $options['step'] ) : 5;
				if ( $step_minutes < 1 ) {
					$step_minutes = 5;
				}
				$step_seconds = $step_minutes * 60;
				?>
				<label class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-time">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<input type="time" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-qe-input" value="" step="<?php echo esc_attr( (string) $step_seconds ); ?>" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="time" />
					</span>
				</label>
				<?php
				break;

			case 'datetime':
				$step_minutes = isset( $options['step'] ) ? absint( $options['step'] ) : 5;
				if ( $step_minutes < 1 ) {
					$step_minutes = 5;
				}
				$step_seconds = $step_minutes * 60;
				?>
				<label class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-datetime">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<input type="datetime-local" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-qe-input" value="" step="<?php echo esc_attr( (string) $step_seconds ); ?>" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="datetime" />
					</span>
				</label>
				<?php
				break;

			case 'color':
				?>
				<label class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-color">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<div class="asenha-cfgroup-qe-color">
							<div class="cfgroup-color-preview"></div>
							<input type="text" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-qe-input color" value="" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="color" />
						</div>
					</span>
				</label>
				<?php
				break;

			case 'hyperlink':
				$ui_mode = isset( $options['ui'] ) ? $options['ui'] : 'simple';
				if ( 'wp_link' === $ui_mode ) {
					$this->render_hyperlink_wplink( $field, $input_name, $label );
				} else {
					$this->render_hyperlink_simple( $field, $input_name, $label );
				}
				break;

			case 'map':
				$this->render_map_field( $field, $input_name, $label );
				break;

			case 'wysiwyg':
				if ( isset( CFG()->fields['wysiwyg'] ) && is_object( CFG()->fields['wysiwyg'] )
					&& method_exists( CFG()->fields['wysiwyg'], 'get_pending_data_attrs' )
				) {
					$field_attrs = CFG()->fields['wysiwyg']->get_pending_data_attrs( $field );
				} else {
					$field_attrs = ' data-media-buttons="1" data-editor-tabs="both" data-toolbar-buttons="bold,italic,underline,strikethrough,forecolor,bullist,numlist,alignleft,aligncenter,alignright,link,charmap,removeformat,fullscreen"';
				}
				?>
				<div class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-wysiwyg">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<div class="cfg-wysiwyg-pending"<?php echo $field_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in get_pending_data_attrs() / fallback is static ?>>
							<textarea
								name="<?php echo esc_attr( $input_name ); ?>"
								class="asenha-cfgroup-qe-input wysiwyg wp-editor-area"
								rows="8"
								data-field-id="<?php echo esc_attr( $field_id ); ?>"
								data-field-type="wysiwyg"
								<?php echo $field_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in get_pending_data_attrs() / fallback is static ?>
							></textarea>
						</div>
					</span>
				</div>
				<?php
				break;

			case 'file':
				$this->render_file_field( $field, $input_name, $label );
				break;

			case 'gallery':
				$this->render_gallery_field( $field, $input_name, $label );
				break;

			case 'relationship':
				$this->render_relationship_field( $field, $input_name, $label );
				break;

			case 'term':
				$this->render_term_field( $field, $input_name, $label );
				break;

			case 'user':
				$this->render_user_field( $field, $input_name, $label );
				break;

			case 'text':
			default:
				?>
				<label class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-text">
					<span class="title"><?php echo esc_html( $label ); ?></span>
					<span class="input-text-wrap">
						<input type="text" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-qe-input" value="" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="<?php echo esc_attr( $type ); ?>" />
					</span>
				</label>
				<?php
				break;
		}
	}

	/**
	 * Render a single-select dropdown for Quick Edit.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute.
	 * @param string $input_id   Input id attribute.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_select_single( $field, $input_name, $input_id, $label ) {
		$field_id = (int) $field['id'];
		$options  = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$choices  = self::normalize_choices( isset( $options['choices'] ) ? $options['choices'] : array() );
		?>
		<label class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-select">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<select name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $input_id ); ?>" class="asenha-cfgroup-qe-input" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="select">
					<option value=""><?php echo esc_html( __( '— Select —', 'admin-site-enhancements' ) ); ?></option>
					<?php foreach ( $choices as $val => $choice_label ) : ?>
						<option value="<?php echo esc_attr( $val ); ?>"><?php echo esc_html( $choice_label ); ?></option>
					<?php endforeach; ?>
				</select>
			</span>
		</label>
		<?php
	}

	/**
	 * Render radio choice inputs for Quick Edit.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_choice_radios( $field, $input_name, $label ) {
		$field_id = (int) $field['id'];
		$options  = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$choices  = self::normalize_choices( isset( $options['choices'] ) ? $options['choices'] : array() );
		$layout   = ( isset( $options['layout'] ) && 'horizontal' === $options['layout'] ) ? 'horizontal' : 'vertical';
		?>
		<div class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-radio">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<div class="asenha-cfgroup-qe-choices <?php echo esc_attr( $layout ); ?>">
					<?php foreach ( $choices as $val => $choice_label ) : ?>
						<?php
						$choice_id = 'asenha-cfgroup-qe-' . $field_id . '-' . md5( (string) $val );
						?>
						<label for="<?php echo esc_attr( $choice_id ); ?>">
							<input type="radio" name="<?php echo esc_attr( $input_name ); ?>" id="<?php echo esc_attr( $choice_id ); ?>" class="asenha-cfgroup-qe-input" value="<?php echo esc_attr( $val ); ?>" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="radio" />
							<?php echo esc_html( $choice_label ); ?>
						</label>
					<?php endforeach; ?>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Render checkbox choice inputs for checkbox and multi-select fields.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Base input name (without []).
	 * @param string $label      Field label.
	 * @param string $data_type  data-field-type value (checkbox|select_multiple).
	 * @return void
	 */
	private function render_choice_checkboxes( $field, $input_name, $label, $data_type ) {
		$field_id   = (int) $field['id'];
		$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$choices    = self::normalize_choices( isset( $options['choices'] ) ? $options['choices'] : array() );
		$layout     = ( isset( $options['layout'] ) && 'horizontal' === $options['layout'] ) ? 'horizontal' : 'vertical';
		$array_name = $input_name . '[]';
		?>
		<div class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-checkbox">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<div class="asenha-cfgroup-qe-choices <?php echo esc_attr( $layout ); ?>">
					<?php foreach ( $choices as $val => $choice_label ) : ?>
						<?php
						$choice_id = 'asenha-cfgroup-qe-' . $field_id . '-' . md5( (string) $val );
						?>
						<label for="<?php echo esc_attr( $choice_id ); ?>">
							<input type="checkbox" name="<?php echo esc_attr( $array_name ); ?>" id="<?php echo esc_attr( $choice_id ); ?>" class="asenha-cfgroup-qe-input" value="<?php echo esc_attr( $val ); ?>" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="<?php echo esc_attr( $data_type ); ?>" />
							<?php echo esc_html( $choice_label ); ?>
						</label>
					<?php endforeach; ?>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Render file / media Quick Edit control (Add / Remove + preview).
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_file_field( $field, $input_name, $label ) {
		$field_id = (int) $field['id'];
		$options  = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();

		$file_type          = isset( $options['file_type'] ) ? $options['file_type'] : 'file';
		$image_preview_size = isset( $options['image_preview_size'] ) && ! empty( $options['image_preview_size'] ) ? $options['image_preview_size'] : 'medium';
		$allowed_mime_mode  = isset( $options['allowed_mime_mode'] ) ? $options['allowed_mime_mode'] : 'all';
		$allowed_mime_mode  = in_array( $allowed_mime_mode, array( 'all', 'selected' ), true ) ? $allowed_mime_mode : 'all';

		$field_for_helpers = array( 'options' => $options );
		$allowed_mimes      = cfg_file_field_get_effective_allowed_mimes( $field_for_helpers );
		$allowed_extensions = cfg_file_field_get_effective_allowed_extensions( $field_for_helpers );
		?>
		<div class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-file">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<div
					class="cfgroup_file_input"
					data-file-type="<?php echo esc_attr( $file_type ); ?>"
					data-image-preview-size="<?php echo esc_attr( $image_preview_size ); ?>"
					data-allowed-mime-mode="<?php echo esc_attr( $allowed_mime_mode ); ?>"
					data-allowed-mimes="<?php echo esc_attr( wp_json_encode( array_values( $allowed_mimes ) ) ); ?>"
					data-allowed-extensions="<?php echo esc_attr( wp_json_encode( array_values( $allowed_extensions ) ) ); ?>"
					data-selected-mime=""
				>
					<span class="file_url <?php echo esc_attr( $file_type ); ?>"></span>
					<input type="button" class="button media add" value="<?php echo esc_attr__( 'Add File', 'admin-site-enhancements' ); ?>" />
					<input type="button" class="button media remove hidden" value="<?php echo esc_attr__( 'Remove', 'admin-site-enhancements' ); ?>" />
					<input
						type="hidden"
						name="<?php echo esc_attr( $input_name ); ?>"
						class="asenha-cfgroup-qe-input file_value"
						value=""
						data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
						data-field-type="file"
					/>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Render gallery Quick Edit control (Select / Edit / Clear + thumbs).
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_gallery_field( $field, $input_name, $label ) {
		$field_id = (int) $field['id'];
		?>
		<div class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-gallery">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<div class="cfgroup_gallery">
					<div class="gallery-preview"></div>
					<div class="gallery-buttons">
						<button type="button" class="button cfg-button"><?php echo esc_html__( 'Select Images', 'admin-site-enhancements' ); ?></button>
						<button type="button" class="button cfg-edit-gallery hidden"><?php echo esc_html__( 'Edit Selection', 'admin-site-enhancements' ); ?></button>
						<a href="#" class="cfg-clear-gallery hidden"><?php echo esc_html__( 'Clear', 'admin-site-enhancements' ); ?></a>
					</div>
					<input
						type="hidden"
						name="<?php echo esc_attr( $input_name ); ?>"
						class="asenha-cfgroup-qe-input gallery_value cfg-gallery-value"
						value=""
						data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
						data-field-type="gallery"
					/>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Render relationship Quick Edit control (Select2 multi + AJAX search).
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute (without []).
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_relationship_field( $field, $input_name, $label ) {
		$field_id  = (int) $field['id'];
		$options   = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$limit_min = isset( $options['limit_min'] ) ? (string) $options['limit_min'] : '';
		$limit_max = isset( $options['limit_max'] ) ? (string) $options['limit_max'] : '';
		$post_types = array();

		if ( ! empty( $options['post_types'] ) && is_array( $options['post_types'] ) ) {
			foreach ( $options['post_types'] as $post_type ) {
				$post_type = sanitize_key( $post_type );
				if ( '' !== $post_type ) {
					$post_types[] = $post_type;
				}
			}
		}

		$post_types = array_values( array_unique( $post_types ) );
		?>
		<div
			class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-relationship"
			data-limit-min="<?php echo esc_attr( $limit_min ); ?>"
			data-limit-max="<?php echo esc_attr( $limit_max ); ?>"
			data-post-types="<?php echo esc_attr( wp_json_encode( $post_types ) ); ?>"
		>
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<input
					type="hidden"
					name="<?php echo esc_attr( $input_name ); ?>"
					class="asenha-cfgroup-qe-input asenha-cfgroup-qe-relationship"
					value=""
					data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
					data-field-type="relationship"
					style="width:100%"
				/>
				<span class="asenha-cfgroup-qe-relationship-error" hidden></span>
			</span>
		</div>
		<?php
	}

	/**
	 * Render term Quick Edit control (Select2 multi + AJAX search).
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute (without []).
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_term_field( $field, $input_name, $label ) {
		$field_id    = (int) $field['id'];
		$options     = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$limit_min   = isset( $options['limit_min'] ) ? (string) $options['limit_min'] : '';
		$limit_max   = isset( $options['limit_max'] ) ? (string) $options['limit_max'] : '';
		$taxonomies  = self::qe_term_field_taxonomies( $field );
		?>
		<div
			class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-term"
			data-limit-min="<?php echo esc_attr( $limit_min ); ?>"
			data-limit-max="<?php echo esc_attr( $limit_max ); ?>"
			data-taxonomies="<?php echo esc_attr( wp_json_encode( $taxonomies ) ); ?>"
		>
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<input
					type="hidden"
					name="<?php echo esc_attr( $input_name ); ?>"
					class="asenha-cfgroup-qe-input asenha-cfgroup-qe-term"
					value=""
					data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
					data-field-type="term"
					style="width:100%"
				/>
				<span class="asenha-cfgroup-qe-term-error" hidden></span>
			</span>
		</div>
		<?php
	}

	/**
	 * Render user Quick Edit control (Select2 multi + AJAX search).
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Input name attribute (without []).
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_user_field( $field, $input_name, $label ) {
		$field_id  = (int) $field['id'];
		$options   = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$limit_min = isset( $options['limit_min'] ) ? (string) $options['limit_min'] : '';
		$limit_max = isset( $options['limit_max'] ) ? (string) $options['limit_max'] : '';
		?>
		<div
			class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-user"
			data-limit-min="<?php echo esc_attr( $limit_min ); ?>"
			data-limit-max="<?php echo esc_attr( $limit_max ); ?>"
		>
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<input
					type="hidden"
					name="<?php echo esc_attr( $input_name ); ?>"
					class="asenha-cfgroup-qe-input asenha-cfgroup-qe-user"
					value=""
					data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
					data-field-type="user"
					style="width:100%"
				/>
				<span class="asenha-cfgroup-qe-user-error" hidden></span>
			</span>
		</div>
		<?php
	}

	/**
	 * Render Map Quick Edit controls.
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Base input name.
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_map_field( $field, $input_name, $label ) {
		$field_id   = (int) $field['id'];
		$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$defaults   = class_exists( 'cfgroup_map' ) ? cfgroup_map::default_options() : array(
			'map_provider' => 'openstreetmap',
			'center_lat'   => '-37.81411',
			'center_lng'   => '144.96328',
			'zoom'         => '14',
			'height'       => '280',
		);
		$provider   = isset( $options['map_provider'] ) ? $options['map_provider'] : $defaults['map_provider'];
		$provider   = in_array( $provider, array( 'openstreetmap', 'google_maps' ), true ) ? $provider : $defaults['map_provider'];
		$center_lat = isset( $options['center_lat'] ) ? $options['center_lat'] : $defaults['center_lat'];
		$center_lng = isset( $options['center_lng'] ) ? $options['center_lng'] : $defaults['center_lng'];
		$zoom       = isset( $options['zoom'] ) ? $options['zoom'] : $defaults['zoom'];
		$height     = isset( $options['height'] ) ? absint( $options['height'] ) : 280;
		$height     = $height ? min( $height, 320 ) : 280;
		$allow_custom = ! empty( $options['allow_custom_address'] );
		$map_id     = 'cfgroup-map-qe-' . $field_id;

		if ( class_exists( 'cfgroup_map' ) ) {
			cfgroup_map::register_needed_provider( $provider );
		}
		?>
		<div class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-map">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<div
					class="cfgroup-map"
					id="<?php echo esc_attr( $map_id ); ?>"
					data-map-provider="<?php echo esc_attr( $provider ); ?>"
					data-center-lat="<?php echo esc_attr( $center_lat ); ?>"
					data-center-lng="<?php echo esc_attr( $center_lng ); ?>"
					data-zoom="<?php echo esc_attr( $zoom ); ?>"
					data-height="<?php echo esc_attr( (string) $height ); ?>"
					<?php if ( $allow_custom ) : ?>
					data-allow-custom-address="1"
					<?php endif; ?>
				>
					<div class="cfgroup-map-search">
						<input
							type="text"
							class="cfgroup-map-address asenha-cfgroup-qe-input widefat"
							name="<?php echo esc_attr( $input_name ); ?>[address]"
							value=""
							placeholder="<?php esc_attr_e( 'Search for address…', 'admin-site-enhancements' ); ?>"
							autocomplete="off"
							data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
							data-field-type="map"
							data-subkey="address"
						/>
					</div>
					<?php if ( $allow_custom ) : ?>
						<div class="cfgroup-map-custom-address-wrap">
							<label class="cfgroup-map-custom-address-label" for="<?php echo esc_attr( $map_id ); ?>-custom-address"><?php esc_html_e( 'Custom address', 'admin-site-enhancements' ); ?></label>
							<input
								type="text"
								id="<?php echo esc_attr( $map_id ); ?>-custom-address"
								class="cfgroup-map-custom-address asenha-cfgroup-qe-input widefat"
								name="<?php echo esc_attr( $input_name ); ?>[custom_address]"
								value=""
								placeholder="<?php esc_attr_e( 'Override the address shown on the frontend…', 'admin-site-enhancements' ); ?>"
								autocomplete="off"
								data-field-id="<?php echo esc_attr( (string) $field_id ); ?>"
								data-field-type="map"
								data-subkey="custom_address"
							/>
						</div>
					<?php endif; ?>
					<div class="cfgroup-map-canvas" style="height:<?php echo esc_attr( (string) $height ); ?>px;"></div>
					<input type="hidden" class="cfgroup-map-latitude asenha-cfgroup-qe-input" name="<?php echo esc_attr( $input_name ); ?>[latitude]" value="" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="map" data-subkey="latitude" />
					<input type="hidden" class="cfgroup-map-longitude asenha-cfgroup-qe-input" name="<?php echo esc_attr( $input_name ); ?>[longitude]" value="" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="map" data-subkey="longitude" />
					<input type="hidden" class="cfgroup-map-zoom asenha-cfgroup-qe-input" name="<?php echo esc_attr( $input_name ); ?>[zoom]" value="" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="map" data-subkey="zoom" />
					<?php
					$optional_keys = array( 'place_name', 'street_number', 'street_name', 'city_block', 'sublocality', 'city', 'state', 'post_code', 'country' );
					foreach ( $optional_keys as $opt_key ) :
						?>
						<input type="hidden" class="cfgroup-map-meta asenha-cfgroup-qe-input" data-meta-key="<?php echo esc_attr( $opt_key ); ?>" name="<?php echo esc_attr( $input_name ); ?>[<?php echo esc_attr( $opt_key ); ?>]" value="" data-field-id="<?php echo esc_attr( (string) $field_id ); ?>" data-field-type="map" data-subkey="<?php echo esc_attr( $opt_key ); ?>" />
					<?php endforeach; ?>
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Render simple hyperlink Quick Edit controls (URL / text / target).
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Base input name (without subkey).
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_hyperlink_simple( $field, $input_name, $label ) {
		$field_id = (int) $field['id'];
		?>
		<div class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-hyperlink asenha-cfgroup-qe-field-hyperlink-simple">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<label class="asenha-cfgroup-qe-hyperlink-sub">
					<span class="asenha-cfgroup-qe-hyperlink-sub-label"><?php echo esc_html__( 'URL', 'admin-site-enhancements' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $input_name ); ?>[url]" class="asenha-cfgroup-qe-input" value="" placeholder="http://" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="hyperlink" data-subkey="url" />
				</label>
				<label class="asenha-cfgroup-qe-hyperlink-sub">
					<span class="asenha-cfgroup-qe-hyperlink-sub-label"><?php echo esc_html__( 'Link Text', 'admin-site-enhancements' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $input_name ); ?>[text]" class="asenha-cfgroup-qe-input" value="" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="hyperlink" data-subkey="text" />
				</label>
				<label class="asenha-cfgroup-qe-hyperlink-sub">
					<span class="asenha-cfgroup-qe-hyperlink-sub-label"><?php echo esc_html__( 'Link Target', 'admin-site-enhancements' ); ?></span>
					<select name="<?php echo esc_attr( $input_name ); ?>[target]" class="asenha-cfgroup-qe-input" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="hyperlink" data-subkey="target">
						<option value="none">None</option>
						<option value="_blank">_blank</option>
						<option value="_self">_self</option>
						<option value="_top">_top</option>
					</select>
				</label>
			</span>
		</div>
		<?php
	}

	/**
	 * Render wpLink hyperlink Quick Edit controls (preview + modal).
	 *
	 * @param array  $field      Field definition.
	 * @param string $input_name Base input name (without subkey).
	 * @param string $label      Field label.
	 * @return void
	 */
	private function render_hyperlink_wplink( $field, $input_name, $label ) {
		$field_id  = (int) $field['id'];
		$editor_id = 'asenha-cfgroup-qe-wplink-' . $field_id;
		?>
		<div class="asenha-cfgroup-qe-field asenha-cfgroup-qe-field-hyperlink asenha-cfgroup-qe-field-hyperlink-wplink">
			<span class="title"><?php echo esc_html( $label ); ?></span>
			<span class="input-text-wrap">
				<div
					class="cfgroup-hyperlink-wplink"
					data-ui="wp_link"
					data-empty-text="<?php echo esc_attr__( 'No link selected.', 'admin-site-enhancements' ); ?>"
					data-add-text="<?php echo esc_attr__( 'Add Link', 'admin-site-enhancements' ); ?>"
					data-update-text="<?php echo esc_attr__( 'Update Link', 'admin-site-enhancements' ); ?>"
					data-editor-id="<?php echo esc_attr( $editor_id ); ?>"
				>
					<textarea id="<?php echo esc_attr( $editor_id ); ?>" class="cfgroup-hyperlink-wplink-editor" aria-hidden="true"></textarea>
					<div class="cfgroup-hyperlink-wplink-preview">
						<span class="cfgroup-hyperlink-wplink-preview-empty">
							<?php echo esc_html__( 'No link selected.', 'admin-site-enhancements' ); ?>
						</span>
					</div>
					<div class="cfgroup-hyperlink-wplink-actions">
						<button
							type="button"
							class="button cfgroup-hyperlink-wplink-select"
							data-select-text="<?php echo esc_attr__( 'Select Link', 'admin-site-enhancements' ); ?>"
							data-edit-text="<?php echo esc_attr__( 'Edit Link', 'admin-site-enhancements' ); ?>"
						>
							<?php echo esc_html__( 'Select Link', 'admin-site-enhancements' ); ?>
						</button>
						<button type="button" class="button cfgroup-hyperlink-wplink-clear">
							<?php echo esc_html__( 'Clear', 'admin-site-enhancements' ); ?>
						</button>
					</div>
					<input type="hidden" name="<?php echo esc_attr( $input_name ); ?>[url]" class="asenha-cfgroup-qe-input link-url" value="" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="hyperlink" data-subkey="url" />
					<input type="hidden" name="<?php echo esc_attr( $input_name ); ?>[text]" class="asenha-cfgroup-qe-input link-text" value="" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="hyperlink" data-subkey="text" />
					<input type="hidden" name="<?php echo esc_attr( $input_name ); ?>[target]" class="asenha-cfgroup-qe-input link-target" value="none" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-field-type="hyperlink" data-subkey="target" />
				</div>
			</span>
		</div>
		<?php
	}

	/**
	 * Save Quick Edit submitted CFG field values.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @return void
	 */
	public function save_quick_edit( $post_id, $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST['asenha_cfgroup_quick_edit_nonce'] )
			|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['asenha_cfgroup_quick_edit_nonce'] ) ), 'asenha_cfgroup_quick_edit' )
		) {
			return;
		}

		if ( ! isset( $_POST[ self::INPUT_NAME ] ) || ! is_array( $_POST[ self::INPUT_NAME ] ) ) {
			$submitted = array();
		} else {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per field type below.
			$submitted = wp_unslash( $_POST[ self::INPUT_NAME ] );
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( ! ( $post instanceof WP_Post ) ) {
			$post = get_post( $post_id );
		}

		if ( ! $post ) {
			return;
		}

		// Only save fields that still match this post.
		$matching_groups = CFG()->api->get_matching_groups( $post_id, true );
		if ( empty( $matching_groups ) ) {
			return;
		}

		$allowed_by_id = array();
		foreach ( array_keys( $matching_groups ) as $group_id ) {
			$group_fields = $this->collect_qe_fields_from_group( (int) $group_id );
			foreach ( $group_fields['fields'] as $field ) {
				$allowed_by_id[ (int) $field['id'] ] = $field;
			}
		}

		if ( empty( $allowed_by_id ) ) {
			return;
		}

		$field_data = array();

		foreach ( $allowed_by_id as $field_id => $field ) {
			$name = $field['name'];
			$type = $field['type'];

			if ( ! self::is_supported_type( $type ) ) {
				continue;
			}

			if ( empty( $field['options']['show_in_quick_edit'] ) ) {
				continue;
			}

			$is_multi         = self::is_multi_value_choice_field( $field );
			$is_relationship  = ( 'relationship' === $type );
			$is_term          = ( 'term' === $type );
			$is_user          = ( 'user' === $type );
			$has_post         = array_key_exists( $field_id, $submitted );

			// Hidden CSV / multi fields may omit the key when empty.
			if ( ! $has_post && ! $is_multi && ! $is_relationship && ! $is_term && ! $is_user ) {
				continue;
			}

			$value = $has_post ? $submitted[ $field_id ] : array();

			switch ( $type ) {
				case 'textarea':
					$field_data[ $name ] = sanitize_textarea_field( $value );
					break;

				case 'number':
					$field_data[ $name ] = is_numeric( $value ) ? $value : '';
					break;

				case 'true_false':
					$field_data[ $name ] = ( 0 < (int) $value ) ? 1 : 0;
					break;

				case 'select':
					if ( $is_multi ) {
						$field_data[ $name ] = $this->sanitize_choice_array( $value, $field );
					} else {
						$field_data[ $name ] = $this->sanitize_choice_scalar( $value, $field );
					}
					break;

				case 'radio':
					$field_data[ $name ] = $this->sanitize_choice_scalar( $value, $field );
					break;

				case 'checkbox':
					$field_data[ $name ] = $this->sanitize_choice_array( $value, $field );
					break;

				case 'date':
					$field_data[ $name ] = $this->sanitize_qe_date_value( $value, $field );
					break;

				case 'time':
					$field_data[ $name ] = $this->sanitize_qe_time_value( $value, $field );
					break;

				case 'datetime':
					$field_data[ $name ] = $this->sanitize_qe_datetime_value( $value, $field );
					break;

				case 'color':
					$field_data[ $name ] = $this->sanitize_qe_color_value( $value );
					break;

				case 'hyperlink':
					$field_data[ $name ] = $this->sanitize_qe_hyperlink_value( $value );
					break;

				case 'map':
					$field_data[ $name ] = self::sanitize_qe_map_value( $value );
					break;

				case 'wysiwyg':
					$field_data[ $name ] = is_string( $value ) ? wp_kses_post( $value ) : '';
					break;

				case 'file':
					$id = ( is_string( $value ) || is_numeric( $value ) ) ? (string) $value : '';
					if ( '' === $id || ! ctype_digit( $id ) ) {
						$field_data[ $name ] = '';
						break;
					}
					$field_obj = (object) array(
						'options' => isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array(),
					);
					$field_data[ $name ] = cfg_file_field_attachment_mime_is_allowed( (int) $id, $field_obj ) ? $id : '';
					break;

				case 'gallery':
					$field_data[ $name ] = self::sanitize_qe_gallery_value( $value );
					break;

				case 'relationship':
					$sanitized = self::sanitize_qe_relationship_value( $value, $field );
					if ( null === $sanitized ) {
						continue 2;
					}
					$field_data[ $name ] = $sanitized;
					break;

				case 'term':
					$sanitized = self::sanitize_qe_term_value( $value, $field );
					if ( null === $sanitized ) {
						continue 2;
					}
					$field_data[ $name ] = $sanitized;
					break;

				case 'user':
					$sanitized = self::sanitize_qe_user_value( $value, $field );
					if ( null === $sanitized ) {
						continue 2;
					}
					$field_data[ $name ] = $sanitized;
					break;

				case 'text':
				default:
					$field_data[ $name ] = sanitize_text_field( $value );
					break;
			}
		}

		if ( empty( $field_data ) ) {
			return;
		}

		CFG()->save( $field_data, array( 'ID' => $post_id ), array( 'format' => 'api' ) );
	}

	/**
	 * Sanitize a single choice value against the field's allowed choices.
	 *
	 * @param mixed $value Submitted value.
	 * @param array $field Field definition.
	 * @return string
	 */
	public static function sanitize_choice_scalar( $value, $field ) {
		if ( is_array( $value ) ) {
			$value = isset( $value[0] ) ? $value[0] : '';
		}

		$value   = sanitize_text_field( $value );
		$choices = self::normalize_choices(
			isset( $field['options']['choices'] ) ? $field['options']['choices'] : array()
		);

		if ( ! array_key_exists( $value, $choices ) ) {
			return '';
		}

		return $value;
	}

	/**
	 * Sanitize an array of choice values against the field's allowed choices.
	 *
	 * @param mixed $value Submitted value(s).
	 * @param array $field Field definition.
	 * @return array
	 */
	public static function sanitize_choice_array( $value, $field ) {
		if ( ! is_array( $value ) ) {
			$value = ( '' === $value || null === $value ) ? array() : array( $value );
		}

		$choices = self::normalize_choices(
			isset( $field['options']['choices'] ) ? $field['options']['choices'] : array()
		);
		$allowed = array_keys( $choices );
		$clean   = array();

		foreach ( $value as $item ) {
			$item = sanitize_text_field( $item );
			if ( in_array( $item, $allowed, true ) ) {
				$clean[] = $item;
			}
		}

		return array_values( array_unique( $clean ) );
	}

	/**
	 * Format a raw meta value for the Quick Edit HTML control (HTML5 / color string).
	 *
	 * @param mixed $raw   Raw stored value.
	 * @param array $field Field definition.
	 * @return string
	 */
	private function format_value_for_qe_input( $raw, $field ) {
		$type    = isset( $field['type'] ) ? $field['type'] : '';
		$options = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$value   = is_string( $raw ) ? trim( $raw ) : (string) $raw;

		if ( '' === $value ) {
			return '';
		}

		switch ( $type ) {
			case 'date':
				if ( ! empty( $options['year_only'] ) ) {
					return self::qe_date_to_year( $value );
				}
				return self::qe_sanitize_ymd( $value );

			case 'time':
				$input_format = isset( $options['input_format'] ) ? $options['input_format'] : 'H:i';
				return self::qe_time_to_html5( $value, $input_format );

			case 'datetime':
				$input_format = isset( $options['input_format'] ) ? $options['input_format'] : 'Y-m-d H:i';
				return self::qe_datetime_to_html5( $value, $input_format );

			case 'color':
				return self::sanitize_qe_color_value( $value );

			default:
				return $value;
		}
	}

	/**
	 * Sanitize a date Quick Edit submission (Y-m-d or year-only).
	 *
	 * @param mixed $value Submitted value.
	 * @param array $field Field definition.
	 * @return string
	 */
	public static function sanitize_qe_date_value( $value, $field ) {
		if ( is_array( $value ) ) {
			$value = isset( $value[0] ) ? $value[0] : '';
		}

		$value   = sanitize_text_field( $value );
		$options = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();

		if ( '' === $value ) {
			return '';
		}

		if ( ! empty( $options['year_only'] ) ) {
			if ( preg_match( '/^(\d{4})$/', $value, $matches ) ) {
				return $matches[1] . '-01-01';
			}
			if ( preg_match( '/^(\d{4})-\d{2}-\d{2}$/', $value, $matches ) ) {
				return $matches[1] . '-01-01';
			}
			return '';
		}

		return self::qe_sanitize_ymd( $value );
	}

	/**
	 * Sanitize a time Quick Edit submission (HTML5 HH:mm → storage format).
	 *
	 * @param mixed $value Submitted value.
	 * @param array $field Field definition.
	 * @return string
	 */
	public static function sanitize_qe_time_value( $value, $field ) {
		if ( is_array( $value ) ) {
			$value = isset( $value[0] ) ? $value[0] : '';
		}

		$value = sanitize_text_field( $value );
		if ( '' === $value ) {
			return '';
		}

		$options      = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$input_format = isset( $options['input_format'] ) ? $options['input_format'] : 'H:i';

		return self::qe_html5_to_time( $value, $input_format );
	}

	/**
	 * Sanitize a datetime Quick Edit submission (HTML5 datetime-local → storage format).
	 *
	 * @param mixed $value Submitted value.
	 * @param array $field Field definition.
	 * @return string
	 */
	public static function sanitize_qe_datetime_value( $value, $field ) {
		if ( is_array( $value ) ) {
			$value = isset( $value[0] ) ? $value[0] : '';
		}

		$value = sanitize_text_field( $value );
		if ( '' === $value ) {
			return '';
		}

		$options      = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$input_format = isset( $options['input_format'] ) ? $options['input_format'] : 'Y-m-d H:i';

		return self::qe_html5_to_datetime( $value, $input_format );
	}

	/**
	 * Sanitize a color value: hex, rgb(), rgba(), or empty.
	 *
	 * @param mixed $value Submitted value.
	 * @return string
	 */
	public static function sanitize_qe_color_value( $value ) {
		if ( is_array( $value ) ) {
			$value = isset( $value[0] ) ? $value[0] : '';
		}

		$value = trim( sanitize_text_field( $value ) );
		if ( '' === $value ) {
			return '';
		}

		if ( preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $value ) ) {
			return $value;
		}

		if ( preg_match( '/^rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*(?:,\s*[\d.]+\s*)?\)$/i', $value ) ) {
			return $value;
		}

		return '';
	}

	/**
	 * Normalize a raw hyperlink value for Quick Edit JSON / controls.
	 *
	 * @param mixed $raw Raw value from CFG()->get( ..., format raw ).
	 * @return array{url:string,text:string,target:string}
	 */
	private function normalize_qe_hyperlink_value( $raw ) {
		$empty = array(
			'url'    => '',
			'text'   => '',
			'target' => 'none',
		);

		if ( null === $raw || '' === $raw ) {
			return $empty;
		}

		if ( is_string( $raw ) && function_exists( 'cfg_normalize_hyperlink_value' ) ) {
			$raw = cfg_normalize_hyperlink_value( $raw, null );
		}

		if ( ! is_array( $raw ) ) {
			return $empty;
		}

		// Indexed legacy shape from some save paths.
		if ( isset( $raw[0]['url'], $raw[1]['text'], $raw[2]['target'] ) ) {
			$raw = array(
				'url'    => $raw[0]['url'],
				'text'   => $raw[1]['text'],
				'target' => $raw[2]['target'],
			);
		}

		$url    = isset( $raw['url'] ) ? (string) $raw['url'] : '';
		$text   = isset( $raw['text'] ) ? (string) $raw['text'] : '';
		$target = isset( $raw['target'] ) ? (string) $raw['target'] : 'none';

		$allowed_targets = array( 'none', '_blank', '_self', '_top' );
		if ( ! in_array( $target, $allowed_targets, true ) ) {
			$target = 'none';
		}

		return array(
			'url'    => $url,
			'text'   => $text,
			'target' => $target,
		);
	}

	/**
	 * Normalize a raw file attachment ID for Quick Edit JSON / controls.
	 *
	 * @param mixed $raw   Raw value from CFG()->get( ..., format raw ).
	 * @param array $field Field definition.
	 * @return array{id:string,preview:string,mime:string}
	 */
	private function normalize_qe_file_value( $raw, $field ) {
		$empty = array(
			'id'      => '',
			'preview' => '',
			'mime'    => '',
		);

		if ( is_array( $raw ) ) {
			$raw = isset( $raw[0] ) ? $raw[0] : '';
		}

		if ( null === $raw || '' === $raw ) {
			return $empty;
		}

		$id = (string) $raw;
		if ( ! ctype_digit( $id ) ) {
			return $empty;
		}

		$attachment_id = (int) $id;
		if ( $attachment_id < 1 || ! get_post( $attachment_id ) ) {
			return $empty;
		}

		$options            = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$image_preview_size = isset( $options['image_preview_size'] ) && ! empty( $options['image_preview_size'] ) ? $options['image_preview_size'] : 'medium';
		$mime               = (string) get_post_mime_type( $attachment_id );
		$preview            = '';

		if ( wp_attachment_is_image( $attachment_id ) ) {
			$src = wp_get_attachment_image_src( $attachment_id, $image_preview_size );
			if ( is_array( $src ) && ! empty( $src[0] ) ) {
				$preview = '<img src="' . esc_url( $src[0] ) . '" alt="" />';
			}
		} else {
			$url = wp_get_attachment_url( $attachment_id );
			if ( $url ) {
				$filename = wp_basename( $url );
				$preview  = '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $filename ) . '</a>';
			}
		}

		return array(
			'id'      => $id,
			'preview' => $preview,
			'mime'    => $mime,
		);
	}

	/**
	 * Normalize a raw gallery CSV for Quick Edit JSON / controls.
	 *
	 * @param mixed $raw Raw value from CFG()->get( ..., format raw ).
	 * @return array{ids:string,preview:string}
	 */
	private function normalize_qe_gallery_value( $raw ) {
		$empty = array(
			'ids'     => '',
			'preview' => '',
		);

		if ( is_array( $raw ) ) {
			$raw = implode( ',', array_map( 'strval', $raw ) );
		}

		if ( null === $raw || '' === $raw ) {
			return $empty;
		}

		$parts   = array_filter( array_map( 'trim', explode( ',', (string) $raw ) ) );
		$ids     = array();
		$preview = '';

		foreach ( $parts as $part ) {
			if ( ! ctype_digit( $part ) ) {
				continue;
			}

			$attachment_id = (int) $part;
			if ( $attachment_id < 1 || ! wp_attachment_is_image( $attachment_id ) ) {
				continue;
			}

			$ids[] = (string) $attachment_id;
			$src   = wp_get_attachment_image_src( $attachment_id, 'thumbnail' );
			if ( is_array( $src ) && ! empty( $src[0] ) ) {
				$preview .= '<div class="preview-image"><img src="' . esc_url( $src[0] ) . '" alt="" /></div>';
			}
		}

		if ( empty( $ids ) ) {
			return $empty;
		}

		return array(
			'ids'     => implode( ',', $ids ),
			'preview' => $preview,
		);
	}

	/**
	 * Sanitize a gallery Quick Edit / Bulk Edit submission to a CSV of image attachment IDs.
	 *
	 * @param mixed $value Submitted value (CSV string or array).
	 * @return string
	 */
	public static function sanitize_qe_gallery_value( $value ) {
		if ( is_array( $value ) ) {
			$value = implode( ',', array_map( 'strval', $value ) );
		}

		if ( ! is_string( $value ) && ! is_numeric( $value ) ) {
			return '';
		}

		$parts = array_filter( array_map( 'trim', explode( ',', (string) $value ) ) );
		$ids   = array();

		foreach ( $parts as $part ) {
			if ( ! ctype_digit( $part ) ) {
				continue;
			}

			$attachment_id = (int) $part;
			if ( $attachment_id < 1 || ! wp_attachment_is_image( $attachment_id ) ) {
				continue;
			}

			$ids[] = (string) $attachment_id;
		}

		$ids = array_values( array_unique( $ids ) );

		return empty( $ids ) ? '' : implode( ',', $ids );
	}

	/**
	 * Normalize a raw relationship ID list for Quick Edit JSON / Select2.
	 *
	 * @param mixed $raw   Raw value from CFG()->get( ..., format raw ).
	 * @param array $field Field definition.
	 * @return array{ids:string,options:array<int,array{id:string,text:string,post_type_label:string}>,limit_min:string,limit_max:string,post_types:array<int,string>}
	 */
	private function normalize_qe_relationship_value( $raw, $field ) {
		$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$limit_min  = isset( $options['limit_min'] ) ? (string) $options['limit_min'] : '';
		$limit_max  = isset( $options['limit_max'] ) ? (string) $options['limit_max'] : '';
		$post_types = self::qe_relationship_field_post_types( $field );

		$empty = array(
			'ids'        => '',
			'options'    => array(),
			'limit_min'  => $limit_min,
			'limit_max'  => $limit_max,
			'post_types' => $post_types,
		);

		$ids = self::qe_relationship_parse_ids( $raw );
		if ( empty( $ids ) ) {
			return $empty;
		}

		$field_obj = (object) array(
			'id'      => isset( $field['id'] ) ? (int) $field['id'] : 0,
			'name'    => isset( $field['name'] ) ? $field['name'] : '',
			'type'    => 'relationship',
			'options' => $options,
		);

		$select_options = array();
		foreach ( $ids as $id ) {
			$option = $this->qe_relationship_option_for_post( (int) $id, $field_obj );
			if ( null !== $option ) {
				$select_options[] = $option;
			}
		}

		if ( empty( $select_options ) ) {
			return $empty;
		}

		$kept_ids = array();
		foreach ( $select_options as $option ) {
			$kept_ids[] = $option['id'];
		}

		return array(
			'ids'        => implode( ',', $kept_ids ),
			'options'    => $select_options,
			'limit_min'  => $limit_min,
			'limit_max'  => $limit_max,
			'post_types' => $post_types,
		);
	}

	/**
	 * Sanitize a relationship Quick Edit submission to an ordered ID array.
	 *
	 * Returns null when under limit_min (skip writing the field).
	 *
	 * @param mixed $value Submitted value (array or CSV).
	 * @param array $field Field definition.
	 * @return array<int,string>|null
	 */
	public static function sanitize_qe_relationship_value( $value, $field ) {
		$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$limit_min  = isset( $options['limit_min'] ) && '' !== (string) $options['limit_min'] ? (int) $options['limit_min'] : 0;
		$limit_max  = isset( $options['limit_max'] ) && '' !== (string) $options['limit_max'] ? (int) $options['limit_max'] : 0;
		$post_types = self::qe_relationship_field_post_types( $field );

		$ids = self::qe_relationship_parse_ids( $value );
		$kept = array();

		foreach ( $ids as $id ) {
			$post = get_post( (int) $id );
			if ( ! $post ) {
				continue;
			}

			if ( ! in_array( $post->post_status, array( 'publish', 'private' ), true ) ) {
				continue;
			}

			if ( ! empty( $post_types ) && ! in_array( $post->post_type, $post_types, true ) ) {
				continue;
			}

			$kept[] = (string) (int) $id;
		}

		$kept = array_values( array_unique( $kept ) );

		if ( $limit_max > 0 && count( $kept ) > $limit_max ) {
			$kept = array_slice( $kept, 0, $limit_max );
		}

		if ( $limit_min > 0 && count( $kept ) < $limit_min ) {
			return null;
		}

		return $kept;
	}

	/**
	 * AJAX: search posts for relationship Quick Edit Select2.
	 *
	 * @return void
	 */
	public function ajax_search_posts() {
		if ( ! check_ajax_referer( 'asenha_cfgroup_quick_edit', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'invalid_nonce' ), 403 );
		}

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}

		$q = isset( $_REQUEST['q'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['q'] ) ) : '';
		$page = isset( $_REQUEST['page'] ) ? max( 1, (int) $_REQUEST['page'] ) : 1;

		$post_types = array();
		if ( isset( $_REQUEST['post_types'] ) ) {
			$raw_types = wp_unslash( $_REQUEST['post_types'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			if ( is_string( $raw_types ) ) {
				$decoded = json_decode( $raw_types, true );
				if ( is_array( $decoded ) ) {
					$raw_types = $decoded;
				} else {
					$raw_types = array_filter( array_map( 'trim', explode( ',', $raw_types ) ) );
				}
			}
			if ( is_array( $raw_types ) ) {
				foreach ( $raw_types as $post_type ) {
					$post_type = sanitize_key( $post_type );
					if ( '' !== $post_type && post_type_exists( $post_type ) ) {
						$post_types[] = $post_type;
					}
				}
			}
		}

		$post_types = array_values( array_unique( $post_types ) );
		if ( empty( $post_types ) ) {
			$post_types = cfgroup_get_relationship_post_types( 'names' );
		}

		$per_page = 20;
		$args     = array(
			'post_type'              => $post_types,
			'post_status'            => array( 'publish', 'private' ),
			'posts_per_page'         => $per_page,
			'paged'                  => $page,
			'orderby'                => 'title',
			'order'                  => 'ASC',
			's'                      => $q,
			'no_found_rows'          => false,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		);

		$field_obj = (object) array(
			'type'    => 'relationship',
			'options' => array(
				'post_types' => $post_types,
			),
		);

		$args = apply_filters( 'cfgroup_field_relationship_query_args', $args, array( 'field' => $field_obj ) );
		$query = new WP_Query( $args );

		$results = array();
		foreach ( $query->posts as $post ) {
			$option = $this->qe_relationship_option_for_post( (int) $post->ID, $field_obj, $post );
			if ( null !== $option ) {
				$results[] = $option;
			}
		}

		wp_send_json(
			array(
				'results' => $results,
				'more'    => ( $page * $per_page ) < (int) $query->found_posts,
			)
		);
	}

	/**
	 * Parse ordered unique digit post IDs from CSV / array.
	 *
	 * @param mixed $raw Raw IDs.
	 * @return array<int,string>
	 */
	public static function qe_relationship_parse_ids( $raw ) {
		if ( is_array( $raw ) ) {
			$parts = $raw;
		} else {
			$parts = array_filter( array_map( 'trim', explode( ',', (string) $raw ) ) );
		}

		$ids = array();
		foreach ( $parts as $part ) {
			$part = (string) $part;
			if ( ! ctype_digit( $part ) ) {
				continue;
			}
			$id = (int) $part;
			if ( $id < 1 ) {
				continue;
			}
			$ids[] = (string) $id;
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Allowed post types for a relationship field.
	 *
	 * @param array $field Field definition.
	 * @return array<int,string>
	 */
	public static function qe_relationship_field_post_types( $field ) {
		$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$post_types = array();

		if ( ! empty( $options['post_types'] ) && is_array( $options['post_types'] ) ) {
			foreach ( $options['post_types'] as $post_type ) {
				$post_type = sanitize_key( $post_type );
				if ( '' !== $post_type ) {
					$post_types[] = $post_type;
				}
			}
		}

		return array_values( array_unique( $post_types ) );
	}

	/**
	 * Build a Select2 option object for a related post.
	 *
	 * @param int           $post_id   Post ID.
	 * @param object        $field_obj Minimal field object for filters.
	 * @param WP_Post|null  $post      Optional post object.
	 * @return array{id:string,text:string,post_type_label:string}|null
	 */
	private function qe_relationship_option_for_post( $post_id, $field_obj, $post = null ) {
		if ( ! ( $post instanceof WP_Post ) ) {
			$post = get_post( $post_id );
		}

		if ( ! $post ) {
			return null;
		}

		$title = (string) $post->post_title;
		if ( 'private' === $post->post_status ) {
			$title = '(Private) ' . $title;
		}

		$title = apply_filters( 'cfgroup_relationship_display', $title, $post->ID, $field_obj );

		$post_type_obj   = get_post_type_object( $post->post_type );
		$post_type_label = ( $post_type_obj && isset( $post_type_obj->labels->singular_name ) )
			? (string) $post_type_obj->labels->singular_name
			: (string) $post->post_type;

		return array(
			'id'              => (string) (int) $post->ID,
			'text'            => $title,
			'post_type_label' => $post_type_label,
		);
	}

	/**
	 * Normalize a raw term ID list for Quick Edit JSON / Select2.
	 *
	 * @param mixed $raw   Raw value from CFG()->get( ..., format raw ).
	 * @param array $field Field definition.
	 * @return array{ids:string,options:array<int,array{id:string,text:string,taxonomy_label:string}>,limit_min:string,limit_max:string,taxonomies:array<int,string>}
	 */
	private function normalize_qe_term_value( $raw, $field ) {
		$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$limit_min  = isset( $options['limit_min'] ) ? (string) $options['limit_min'] : '';
		$limit_max  = isset( $options['limit_max'] ) ? (string) $options['limit_max'] : '';
		$taxonomies = self::qe_term_field_taxonomies( $field );

		$empty = array(
			'ids'         => '',
			'options'     => array(),
			'limit_min'   => $limit_min,
			'limit_max'   => $limit_max,
			'taxonomies'  => $taxonomies,
		);

		$ids = self::qe_relationship_parse_ids( $raw );
		if ( empty( $ids ) ) {
			return $empty;
		}

		$field_obj = (object) array(
			'id'      => isset( $field['id'] ) ? (int) $field['id'] : 0,
			'name'    => isset( $field['name'] ) ? $field['name'] : '',
			'type'    => 'term',
			'options' => $options,
		);

		$select_options = array();
		foreach ( $ids as $id ) {
			$option = $this->qe_term_option_for_term( (int) $id, $field_obj );
			if ( null !== $option ) {
				$select_options[] = $option;
			}
		}

		if ( empty( $select_options ) ) {
			return $empty;
		}

		$kept_ids = array();
		foreach ( $select_options as $option ) {
			$kept_ids[] = $option['id'];
		}

		return array(
			'ids'        => implode( ',', $kept_ids ),
			'options'    => $select_options,
			'limit_min'  => $limit_min,
			'limit_max'  => $limit_max,
			'taxonomies' => $taxonomies,
		);
	}

	/**
	 * Sanitize a term Quick Edit submission to an ordered ID array.
	 *
	 * Returns null when under limit_min (skip writing the field).
	 *
	 * @param mixed $value Submitted value (array or CSV).
	 * @param array $field Field definition.
	 * @return array<int,string>|null
	 */
	public static function sanitize_qe_term_value( $value, $field ) {
		$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$limit_min  = isset( $options['limit_min'] ) && '' !== (string) $options['limit_min'] ? (int) $options['limit_min'] : 0;
		$limit_max  = isset( $options['limit_max'] ) && '' !== (string) $options['limit_max'] ? (int) $options['limit_max'] : 0;
		$taxonomies = self::qe_term_field_taxonomies( $field );

		$ids  = self::qe_relationship_parse_ids( $value );
		$kept = array();

		foreach ( $ids as $id ) {
			$term = get_term( (int) $id );
			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}

			if ( ! empty( $taxonomies ) && ! in_array( $term->taxonomy, $taxonomies, true ) ) {
				continue;
			}

			$kept[] = (string) (int) $term->term_id;
		}

		$kept = array_values( array_unique( $kept ) );

		if ( $limit_max > 0 && count( $kept ) > $limit_max ) {
			$kept = array_slice( $kept, 0, $limit_max );
		}

		if ( $limit_min > 0 && count( $kept ) < $limit_min ) {
			return null;
		}

		return $kept;
	}

	/**
	 * AJAX: search terms for term Quick Edit Select2.
	 *
	 * @return void
	 */
	public function ajax_search_terms() {
		if ( ! check_ajax_referer( 'asenha_cfgroup_quick_edit', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'invalid_nonce' ), 403 );
		}

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}

		$q    = isset( $_REQUEST['q'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['q'] ) ) : '';
		$page = isset( $_REQUEST['page'] ) ? max( 1, (int) $_REQUEST['page'] ) : 1;

		$taxonomies = array();
		if ( isset( $_REQUEST['taxonomies'] ) ) {
			$raw_tax = wp_unslash( $_REQUEST['taxonomies'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			if ( is_string( $raw_tax ) ) {
				$decoded = json_decode( $raw_tax, true );
				if ( is_array( $decoded ) ) {
					$raw_tax = $decoded;
				} else {
					$raw_tax = array_filter( array_map( 'trim', explode( ',', $raw_tax ) ) );
				}
			}
			if ( is_array( $raw_tax ) ) {
				foreach ( $raw_tax as $taxonomy ) {
					$taxonomy = sanitize_key( $taxonomy );
					if ( '' !== $taxonomy && taxonomy_exists( $taxonomy ) ) {
						$taxonomies[] = $taxonomy;
					}
				}
			}
		}

		$taxonomies = array_values( array_unique( $taxonomies ) );
		if ( empty( $taxonomies ) ) {
			$taxonomies = array_values( get_taxonomies( array( 'public' => true ) ) );
		}

		$per_page = 20;
		$args     = array(
			'taxonomy'   => $taxonomies,
			'hide_empty' => false,
			'number'     => $per_page,
			'offset'     => ( $page - 1 ) * $per_page,
			'orderby'    => 'name',
			'order'      => 'ASC',
			'search'     => $q,
		);

		$field_obj = (object) array(
			'type'    => 'term',
			'options' => array(
				'taxonomies' => $taxonomies,
			),
		);

		$args = apply_filters( 'cfgroup_field_term_query_args', $args, array( 'field' => $field_obj ) );

		$count_args = $args;
		unset( $count_args['number'], $count_args['offset'], $count_args['fields'] );
		$count_args['fields'] = 'count';
		$found_raw = get_terms( $count_args );
		$found     = is_wp_error( $found_raw ) ? 0 : (int) $found_raw;

		$terms = get_terms( $args );
		if ( is_wp_error( $terms ) ) {
			$terms = array();
		}

		$results = array();
		foreach ( $terms as $term ) {
			$option = $this->qe_term_option_for_term( (int) $term->term_id, $field_obj, $term );
			if ( null !== $option ) {
				$results[] = $option;
			}
		}

		wp_send_json(
			array(
				'results' => $results,
				'more'    => ( $page * $per_page ) < $found,
			)
		);
	}

	/**
	 * Allowed taxonomies for a term field.
	 *
	 * @param array $field Field definition.
	 * @return array<int,string>
	 */
	public static function qe_term_field_taxonomies( $field ) {
		$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$taxonomies = array();

		if ( ! empty( $options['taxonomies'] ) && is_array( $options['taxonomies'] ) ) {
			foreach ( $options['taxonomies'] as $taxonomy ) {
				$taxonomy = sanitize_key( $taxonomy );
				if ( '' !== $taxonomy ) {
					$taxonomies[] = $taxonomy;
				}
			}
		}

		return array_values( array_unique( $taxonomies ) );
	}

	/**
	 * Build a Select2 option object for a related term.
	 *
	 * @param int          $term_id   Term ID.
	 * @param object       $field_obj Minimal field object for filters.
	 * @param WP_Term|null $term      Optional term object.
	 * @return array{id:string,text:string,taxonomy_label:string}|null
	 */
	private function qe_term_option_for_term( $term_id, $field_obj, $term = null ) {
		if ( ! ( $term instanceof WP_Term ) ) {
			$term = get_term( $term_id );
		}

		if ( ! $term || is_wp_error( $term ) ) {
			return null;
		}

		$name = (string) $term->name;
		$name = apply_filters( 'cfgroup_term_display', $name, $term->term_id, $field_obj );

		$tax_obj         = get_taxonomy( $term->taxonomy );
		$taxonomy_label  = '';
		if ( $tax_obj ) {
			if ( isset( $tax_obj->singular_label ) && $tax_obj->singular_label ) {
				$taxonomy_label = (string) $tax_obj->singular_label;
			} elseif ( isset( $tax_obj->labels->singular_name ) ) {
				$taxonomy_label = (string) $tax_obj->labels->singular_name;
			} else {
				$taxonomy_label = (string) $term->taxonomy;
			}
		} else {
			$taxonomy_label = (string) $term->taxonomy;
		}

		return array(
			'id'             => (string) (int) $term->term_id,
			'text'           => $name,
			'taxonomy_label' => $taxonomy_label,
		);
	}

	/**
	 * Normalize a raw user ID list for Quick Edit JSON / Select2.
	 *
	 * @param mixed $raw   Raw value from CFG()->get( ..., format raw ).
	 * @param array $field Field definition.
	 * @return array{ids:string,options:array<int,array{id:string,text:string,username:string,email:string}>,limit_min:string,limit_max:string}
	 */
	private function normalize_qe_user_value( $raw, $field ) {
		$options   = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$limit_min = isset( $options['limit_min'] ) ? (string) $options['limit_min'] : '';
		$limit_max = isset( $options['limit_max'] ) ? (string) $options['limit_max'] : '';

		$empty = array(
			'ids'       => '',
			'options'   => array(),
			'limit_min' => $limit_min,
			'limit_max' => $limit_max,
		);

		$ids = self::qe_relationship_parse_ids( $raw );
		if ( empty( $ids ) ) {
			return $empty;
		}

		$field_obj = (object) array(
			'id'      => isset( $field['id'] ) ? (int) $field['id'] : 0,
			'name'    => isset( $field['name'] ) ? $field['name'] : '',
			'type'    => 'user',
			'options' => $options,
		);

		$select_options = array();
		foreach ( $ids as $id ) {
			$option = $this->qe_user_option_for_user( (int) $id, $field_obj );
			if ( null !== $option ) {
				$select_options[] = $option;
			}
		}

		if ( empty( $select_options ) ) {
			return $empty;
		}

		$kept_ids = array();
		foreach ( $select_options as $option ) {
			$kept_ids[] = $option['id'];
		}

		return array(
			'ids'       => implode( ',', $kept_ids ),
			'options'   => $select_options,
			'limit_min' => $limit_min,
			'limit_max' => $limit_max,
		);
	}

	/**
	 * Sanitize a user Quick Edit submission to an ordered ID array.
	 *
	 * Returns null when under limit_min (skip writing the field).
	 *
	 * @param mixed $value Submitted value (array or CSV).
	 * @param array $field Field definition.
	 * @return array<int,string>|null
	 */
	public static function sanitize_qe_user_value( $value, $field ) {
		$options   = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$limit_min = isset( $options['limit_min'] ) && '' !== (string) $options['limit_min'] ? (int) $options['limit_min'] : 0;
		$limit_max = isset( $options['limit_max'] ) && '' !== (string) $options['limit_max'] ? (int) $options['limit_max'] : 0;

		$ids  = self::qe_relationship_parse_ids( $value );
		$kept = array();

		foreach ( $ids as $id ) {
			$user = get_userdata( (int) $id );
			if ( ! $user ) {
				continue;
			}
			$kept[] = (string) (int) $user->ID;
		}

		$kept = array_values( array_unique( $kept ) );

		if ( $limit_max > 0 && count( $kept ) > $limit_max ) {
			$kept = array_slice( $kept, 0, $limit_max );
		}

		if ( $limit_min > 0 && count( $kept ) < $limit_min ) {
			return null;
		}

		return $kept;
	}

	/**
	 * AJAX: search users for user Quick Edit Select2.
	 *
	 * @return void
	 */
	public function ajax_search_users() {
		if ( ! check_ajax_referer( 'asenha_cfgroup_quick_edit', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'invalid_nonce' ), 403 );
		}

		if ( ! current_user_can( 'list_users' ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}

		$q    = isset( $_REQUEST['q'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['q'] ) ) : '';
		$page = isset( $_REQUEST['page'] ) ? max( 1, (int) $_REQUEST['page'] ) : 1;

		$per_page = 20;
		$args     = array(
			'number'         => $per_page,
			'paged'          => $page,
			'orderby'        => 'display_name',
			'order'          => 'ASC',
			'count_total'    => true,
			'search'         => '' !== $q ? '*' . $q . '*' : '',
			'search_columns' => array( 'user_login', 'user_nicename', 'user_email', 'display_name' ),
			'fields'         => 'all',
		);

		$query = new WP_User_Query( $args );
		$users = $query->get_results();
		$found = (int) $query->get_total();

		$field_obj = (object) array(
			'type'    => 'user',
			'options' => array(),
		);

		$results = array();
		foreach ( $users as $user ) {
			$option = $this->qe_user_option_for_user( (int) $user->ID, $field_obj, $user );
			if ( null !== $option ) {
				$results[] = $option;
			}
		}

		wp_send_json(
			array(
				'results' => $results,
				'more'    => ( $page * $per_page ) < $found,
			)
		);
	}

	/**
	 * Build a Select2 option object for a user.
	 *
	 * @param int                 $user_id   User ID.
	 * @param object              $field_obj Minimal field object for filters.
	 * @param WP_User|object|null $user      Optional user object.
	 * @return array{id:string,text:string,username:string,email:string}|null
	 */
	private function qe_user_option_for_user( $user_id, $field_obj, $user = null ) {
		if ( ! ( $user instanceof WP_User ) ) {
			$user = get_userdata( $user_id );
		}

		if ( ! $user ) {
			return null;
		}

		$username = apply_filters( 'cfgroup_user_display', (string) $user->user_login, (int) $user->ID, $field_obj );

		return array(
			'id'       => (string) (int) $user->ID,
			'text'     => (string) $user->display_name,
			'username' => (string) $username,
			'email'    => (string) $user->user_email,
		);
	}

	/**
	 * Sanitize a Map Quick Edit / Bulk Edit submission.
	 *
	 * @param mixed $value Submitted value.
	 * @return array
	 */
	public static function sanitize_qe_map_value( $value ) {
		if ( ! is_array( $value ) ) {
			$value = array();
		}

		$lat = isset( $value['latitude'] ) ? trim( (string) $value['latitude'] ) : '';
		$lng = isset( $value['longitude'] ) ? trim( (string) $value['longitude'] ) : '';

		$out = array(
			'address'   => isset( $value['address'] ) ? sanitize_text_field( $value['address'] ) : '',
			'latitude'  => ( '' !== $lat && is_numeric( $lat ) ) ? (string) (float) $lat : '',
			'longitude' => ( '' !== $lng && is_numeric( $lng ) ) ? (string) (float) $lng : '',
			'zoom'      => '',
		);

		if ( isset( $value['zoom'] ) && '' !== $value['zoom'] ) {
			$out['zoom'] = (string) max( 1, min( 21, absint( $value['zoom'] ) ) );
		}

		$optional = array( 'place_name', 'street_number', 'street_name', 'city_block', 'sublocality', 'city', 'state', 'post_code', 'country' );
		foreach ( $optional as $key ) {
			if ( ! empty( $value[ $key ] ) ) {
				$out[ $key ] = sanitize_text_field( $value[ $key ] );
			}
		}

		return $out;
	}

	/**
	 * Normalize a raw map value for Quick Edit JSON / controls.
	 *
	 * @param mixed $raw Raw value from CFG()->get( ..., format raw ).
	 * @return array
	 */
	public static function normalize_qe_map_value( $raw ) {
		$empty = array(
			'address'   => '',
			'latitude'  => '',
			'longitude' => '',
			'zoom'      => '',
		);

		if ( null === $raw || '' === $raw ) {
			return $empty;
		}

		if ( is_string( $raw ) ) {
			$raw = maybe_unserialize( $raw );
		}

		if ( ! is_array( $raw ) ) {
			return $empty;
		}

		return self::sanitize_qe_map_value( $raw );
	}

	/**
	 * Sanitize a hyperlink Quick Edit / Bulk Edit submission.
	 *
	 * @param mixed $value Submitted value (expected array with url/text/target).
	 * @return array{url:string,text:string,target:string}
	 */
	public static function sanitize_qe_hyperlink_value( $value ) {
		if ( ! is_array( $value ) ) {
			$value = array();
		}

		$url    = isset( $value['url'] ) ? esc_url_raw( sanitize_text_field( $value['url'] ) ) : '';
		$text   = isset( $value['text'] ) ? sanitize_text_field( $value['text'] ) : '';
		$target = isset( $value['target'] ) ? sanitize_text_field( $value['target'] ) : 'none';

		$allowed_targets = array( 'none', '_blank', '_self', '_top' );
		if ( ! in_array( $target, $allowed_targets, true ) ) {
			$target = 'none';
		}

		return array(
			'url'    => $url,
			'text'   => $text,
			'target' => $target,
		);
	}

	/**
	 * Accept a Y-m-d date string or return empty.
	 *
	 * @param string $value Candidate date.
	 * @return string
	 */
	private static function qe_sanitize_ymd( $value ) {
		$value = trim( (string) $value );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
			return '';
		}

		$dt = DateTime::createFromFormat( 'Y-m-d', $value );
		if ( ! $dt || $dt->format( 'Y-m-d' ) !== $value ) {
			return '';
		}

		return $value;
	}

	/**
	 * Extract a 4-digit year from a stored date / year value.
	 *
	 * @param string $value Stored value.
	 * @return string
	 */
	private static function qe_date_to_year( $value ) {
		$value = trim( (string) $value );
		if ( preg_match( '/^(\d{4})(?:-\d{2}-\d{2})?$/', $value, $matches ) ) {
			return $matches[1];
		}

		return '';
	}

	/**
	 * Map Flatpickr storage input_format to a PHP DateTime format for time.
	 *
	 * Flatpickr `G:i K` ≈ PHP `h:i A`; Flatpickr `H:i` = PHP `H:i`.
	 *
	 * @param string $input_format Field input_format option.
	 * @return string
	 */
	private static function qe_php_time_format( $input_format ) {
		return ( 'G:i K' === $input_format ) ? 'h:i A' : 'H:i';
	}

	/**
	 * Map Flatpickr storage input_format to a PHP DateTime format for datetime.
	 *
	 * @param string $input_format Field input_format option.
	 * @return string
	 */
	private static function qe_php_datetime_format( $input_format ) {
		return ( 'Y-m-d G:i K' === $input_format ) ? 'Y-m-d h:i A' : 'Y-m-d H:i';
	}

	/**
	 * Convert stored time string to HTML5 time value (HH:mm).
	 *
	 * @param string $value         Stored time.
	 * @param string $input_format  Field input_format.
	 * @return string
	 */
	private static function qe_time_to_html5( $value, $input_format ) {
		$value  = trim( (string) $value );
		$formats = array_unique(
			array(
				self::qe_php_time_format( $input_format ),
				'H:i',
				'h:i A',
				'g:i A',
			)
		);

		foreach ( $formats as $format ) {
			$dt = DateTime::createFromFormat( $format, $value );
			if ( $dt instanceof DateTime ) {
				return $dt->format( 'H:i' );
			}
		}

		// Already HTML5-ish.
		if ( preg_match( '/^\d{2}:\d{2}$/', $value ) ) {
			return $value;
		}

		return '';
	}

	/**
	 * Convert HTML5 time (HH:mm) to storage format.
	 *
	 * @param string $value         HTML5 time.
	 * @param string $input_format  Field input_format.
	 * @return string
	 */
	private static function qe_html5_to_time( $value, $input_format ) {
		$value = trim( (string) $value );
		if ( ! preg_match( '/^\d{2}:\d{2}(?::\d{2})?$/', $value ) ) {
			return '';
		}

		// Strip optional seconds for createFromFormat with H:i.
		if ( preg_match( '/^(\d{2}:\d{2}):\d{2}$/', $value, $matches ) ) {
			$value = $matches[1];
		}

		$dt = DateTime::createFromFormat( 'H:i', $value );
		if ( ! ( $dt instanceof DateTime ) ) {
			return '';
		}

		return $dt->format( self::qe_php_time_format( $input_format ) );
	}

	/**
	 * Convert stored datetime string to HTML5 datetime-local (YYYY-MM-DDTHH:mm).
	 *
	 * @param string $value         Stored datetime.
	 * @param string $input_format  Field input_format.
	 * @return string
	 */
	private static function qe_datetime_to_html5( $value, $input_format ) {
		$value   = trim( (string) $value );
		$formats = array_unique(
			array(
				self::qe_php_datetime_format( $input_format ),
				'Y-m-d H:i',
				'Y-m-d h:i A',
				'Y-m-d g:i A',
			)
		);

		foreach ( $formats as $format ) {
			$dt = DateTime::createFromFormat( $format, $value );
			if ( $dt instanceof DateTime ) {
				return $dt->format( 'Y-m-d\TH:i' );
			}
		}

		if ( preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $value ) ) {
			return $value;
		}

		return '';
	}

	/**
	 * Convert HTML5 datetime-local to storage format.
	 *
	 * @param string $value         HTML5 datetime-local.
	 * @param string $input_format  Field input_format.
	 * @return string
	 */
	private static function qe_html5_to_datetime( $value, $input_format ) {
		$value = trim( (string) $value );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?$/', $value ) ) {
			return '';
		}

		$formats = array( 'Y-m-d\TH:i:s', 'Y-m-d\TH:i' );
		$dt      = false;

		foreach ( $formats as $format ) {
			$dt = DateTime::createFromFormat( $format, $value );
			if ( $dt instanceof DateTime ) {
				break;
			}
		}

		if ( ! ( $dt instanceof DateTime ) ) {
			return '';
		}

		return $dt->format( self::qe_php_datetime_format( $input_format ) );
	}

	/**
	 * Enqueue Quick Edit assets on relevant list screens.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 * @return void
	 */
	public function enqueue_assets( $hook_suffix ) {
		if ( 'edit.php' !== $hook_suffix ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $this->is_target_list_screen( $screen ) ) {
			return;
		}

		$css_path = CFG_DIR . '/assets/css/quick-edit.css';
		$js_path  = CFG_DIR . '/assets/js/quick-edit.js';

		$colors_path = CFG_DIR . '/assets/js/color-picker/colors.js';
		$picker_path = CFG_DIR . '/assets/js/color-picker/jqColorPicker_mod.js';

		wp_register_script(
			'jqcolors',
			CFG_URL . '/assets/js/color-picker/colors.js',
			array(),
			file_exists( $colors_path ) ? (string) filemtime( $colors_path ) : CFG_VERSION,
			true
		);

		wp_register_script(
			'jqcolorpicker',
			CFG_URL . '/assets/js/color-picker/jqColorPicker_mod.js',
			array( 'jquery', 'jqcolors' ),
			file_exists( $picker_path ) ? (string) filemtime( $picker_path ) : CFG_VERSION,
			true
		);

		wp_enqueue_script( 'jqcolors' );
		wp_enqueue_script( 'jqcolorpicker' );

		$qe_script_deps = array( 'jquery', 'inline-edit-post', 'jqcolorpicker' );

		if ( $this->post_type_has_qe_hyperlink_wplink( $screen->post_type ) ) {
			if ( function_exists( 'wp_enqueue_editor' ) ) {
				wp_enqueue_editor();
			}

			$wplink_path = CFG_DIR . '/assets/js/hyperlink-wplink.js';
			wp_register_script(
				'asenha-cfgroup-hyperlink-wplink',
				CFG_URL . '/assets/js/hyperlink-wplink.js',
				array( 'jquery', 'wplink' ),
				file_exists( $wplink_path ) ? (string) filemtime( $wplink_path ) : CFG_VERSION,
				true
			);
			wp_enqueue_script( 'asenha-cfgroup-hyperlink-wplink' );
			$qe_script_deps[] = 'asenha-cfgroup-hyperlink-wplink';
		}

		if ( $this->post_type_has_qe_wysiwyg( $screen->post_type ) ) {
			if ( isset( CFG()->fields['wysiwyg'] ) && is_object( CFG()->fields['wysiwyg'] ) ) {
				CFG()->fields['wysiwyg']->input_head( null );
			} elseif ( function_exists( 'wp_enqueue_editor' ) ) {
				wp_enqueue_editor();
			}

			if ( wp_script_is( 'cfg-wysiwyg', 'registered' ) || wp_script_is( 'cfg-wysiwyg', 'enqueued' ) ) {
				$qe_script_deps[] = 'cfg-wysiwyg';
			}
		}

		if ( $this->post_type_has_qe_file( $screen->post_type ) ) {
			if ( isset( CFG()->fields['file'] ) && is_object( CFG()->fields['file'] ) ) {
				CFG()->fields['file']->input_head( null );
			} else {
				wp_enqueue_media();
			}

			if ( wp_script_is( 'cfg-file', 'registered' ) || wp_script_is( 'cfg-file', 'enqueued' ) ) {
				$qe_script_deps[] = 'cfg-file';
			}
		}

		if ( $this->post_type_has_qe_gallery( $screen->post_type ) ) {
			if ( isset( CFG()->fields['gallery'] ) && is_object( CFG()->fields['gallery'] ) ) {
				CFG()->fields['gallery']->input_head( null );
			} else {
				wp_enqueue_media();
			}

			if ( wp_script_is( 'cfg-gallery', 'registered' ) || wp_script_is( 'cfg-gallery', 'enqueued' ) ) {
				$qe_script_deps[] = 'cfg-gallery';
			}
		}

		if ( $this->post_type_has_qe_map( $screen->post_type ) ) {
			if ( isset( CFG()->fields['map'] ) && is_object( CFG()->fields['map'] ) ) {
				$this->register_qe_map_providers( $screen->post_type );
				CFG()->fields['map']->input_head( null );
			}

			if ( wp_script_is( 'asenha-cfgroup-map', 'registered' ) || wp_script_is( 'asenha-cfgroup-map', 'enqueued' ) ) {
				$qe_script_deps[] = 'asenha-cfgroup-map';
			}
		}

		$qe_style_deps = array();
		$needs_select2 = $this->post_type_has_qe_relationship( $screen->post_type )
			|| $this->post_type_has_qe_term( $screen->post_type )
			|| $this->post_type_has_qe_user( $screen->post_type );

		if ( $needs_select2 ) {
			$select2_js  = CFG_DIR . '/assets/js/select2/select2.min.js';
			$select2_css = CFG_DIR . '/assets/js/select2/select2.css';

			wp_register_style(
				'cfgroup-select2',
				CFG_URL . '/assets/js/select2/select2.css',
				array(),
				file_exists( $select2_css ) ? (string) filemtime( $select2_css ) : CFG_VERSION
			);
			wp_enqueue_style( 'cfgroup-select2' );
			$qe_style_deps[] = 'cfgroup-select2';

			wp_register_script(
				'cfgroup-select2',
				CFG_URL . '/assets/js/select2/select2.min.js',
				array( 'jquery' ),
				file_exists( $select2_js ) ? (string) filemtime( $select2_js ) : CFG_VERSION,
				true
			);
			wp_enqueue_script( 'cfgroup-select2' );
		}

		if ( $this->post_type_has_qe_relationship( $screen->post_type ) ) {
			$rel_js = CFG_DIR . '/assets/js/cfg-relationship-qe.js';

			wp_register_script(
				'cfg-relationship-qe',
				CFG_URL . '/assets/js/cfg-relationship-qe.js',
				array( 'jquery', 'cfgroup-select2' ),
				file_exists( $rel_js ) ? (string) filemtime( $rel_js ) : CFG_VERSION,
				true
			);
			wp_localize_script(
				'cfg-relationship-qe',
				'asenhaCfgroupRelationshipQe',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'asenha_cfgroup_quick_edit' ),
					'i18n'    => array(
						'placeholder' => __( 'Search posts…', 'admin-site-enhancements' ),
						'searching'   => __( 'Searching…', 'admin-site-enhancements' ),
						/* translators: %d: minimum number of related posts */
						'minError'    => __( 'Select at least %d item(s).', 'admin-site-enhancements' ),
						/* translators: %d: maximum number of related posts */
						'maxError'    => __( 'You can select at most %d item(s).', 'admin-site-enhancements' ),
					),
				)
			);
			wp_enqueue_script( 'cfg-relationship-qe' );
			$qe_script_deps[] = 'cfg-relationship-qe';
		}

		if ( $this->post_type_has_qe_term( $screen->post_type ) ) {
			$term_js = CFG_DIR . '/assets/js/cfg-term-qe.js';

			wp_register_script(
				'cfg-term-qe',
				CFG_URL . '/assets/js/cfg-term-qe.js',
				array( 'jquery', 'cfgroup-select2' ),
				file_exists( $term_js ) ? (string) filemtime( $term_js ) : CFG_VERSION,
				true
			);
			wp_localize_script(
				'cfg-term-qe',
				'asenhaCfgroupTermQe',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'asenha_cfgroup_quick_edit' ),
					'i18n'    => array(
						'placeholder' => __( 'Search terms…', 'admin-site-enhancements' ),
						'searching'   => __( 'Searching…', 'admin-site-enhancements' ),
						/* translators: %d: minimum number of terms */
						'minError'    => __( 'Select at least %d item(s).', 'admin-site-enhancements' ),
						/* translators: %d: maximum number of terms */
						'maxError'    => __( 'You can select at most %d item(s).', 'admin-site-enhancements' ),
					),
				)
			);
			wp_enqueue_script( 'cfg-term-qe' );
			$qe_script_deps[] = 'cfg-term-qe';
		}

		if ( $this->post_type_has_qe_user( $screen->post_type ) ) {
			$user_js = CFG_DIR . '/assets/js/cfg-user-qe.js';

			wp_register_script(
				'cfg-user-qe',
				CFG_URL . '/assets/js/cfg-user-qe.js',
				array( 'jquery', 'cfgroup-select2' ),
				file_exists( $user_js ) ? (string) filemtime( $user_js ) : CFG_VERSION,
				true
			);
			wp_localize_script(
				'cfg-user-qe',
				'asenhaCfgroupUserQe',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'asenha_cfgroup_quick_edit' ),
					'i18n'    => array(
						'placeholder' => __( 'Search users…', 'admin-site-enhancements' ),
						'searching'   => __( 'Searching…', 'admin-site-enhancements' ),
						/* translators: %d: minimum number of users */
						'minError'    => __( 'Select at least %d item(s).', 'admin-site-enhancements' ),
						/* translators: %d: maximum number of users */
						'maxError'    => __( 'You can select at most %d item(s).', 'admin-site-enhancements' ),
					),
				)
			);
			wp_enqueue_script( 'cfg-user-qe' );
			$qe_script_deps[] = 'cfg-user-qe';
		}

		wp_enqueue_style(
			'asenha-cfgroup-quick-edit',
			CFG_URL . '/assets/css/quick-edit.css',
			$qe_style_deps,
			file_exists( $css_path ) ? (string) filemtime( $css_path ) : CFG_VERSION
		);

		wp_enqueue_script(
			'asenha-cfgroup-quick-edit',
			CFG_URL . '/assets/js/quick-edit.js',
			$qe_script_deps,
			file_exists( $js_path ) ? (string) filemtime( $js_path ) : CFG_VERSION,
			true
		);
	}

	/**
	 * Whether the post type has any QE-enabled hyperlink field using wpLink UI.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_qe_hyperlink_wplink( $post_type ) {
		$groups = $this->get_qe_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'hyperlink' === $field['type'] ) {
					$ui = isset( $field['options']['ui'] ) ? $field['options']['ui'] : 'simple';
					if ( 'wp_link' === $ui ) {
						return true;
					}
				}
			}
		}

		return false;
	}

	/**
	 * Whether the post type has any QE-enabled wysiwyg field.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_qe_wysiwyg( $post_type ) {
		$groups = $this->get_qe_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'wysiwyg' === $field['type'] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether the post type has any QE-enabled file field.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_qe_file( $post_type ) {
		$groups = $this->get_qe_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'file' === $field['type'] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether the post type has any QE-enabled gallery field.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_qe_gallery( $post_type ) {
		$groups = $this->get_qe_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'gallery' === $field['type'] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether the post type has any QE-enabled map field.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_qe_map( $post_type ) {
		$groups = $this->get_qe_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'map' === $field['type'] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Register map providers used by QE-enabled map fields for asset enqueue.
	 *
	 * @param string $post_type Post type slug.
	 * @return void
	 */
	private function register_qe_map_providers( $post_type ) {
		if ( ! class_exists( 'cfgroup_map' ) ) {
			return;
		}

		$groups = $this->get_qe_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( empty( $field['type'] ) || 'map' !== $field['type'] ) {
					continue;
				}
				$provider = isset( $field['options']['map_provider'] ) ? $field['options']['map_provider'] : 'openstreetmap';
				cfgroup_map::register_needed_provider( $provider );
			}
		}
	}

	/**
	 * Whether the post type has any QE-enabled relationship field.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_qe_relationship( $post_type ) {
		$groups = $this->get_qe_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'relationship' === $field['type'] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether the post type has any QE-enabled term field.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_qe_term( $post_type ) {
		$groups = $this->get_qe_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'term' === $field['type'] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether the post type has any QE-enabled user field.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	private function post_type_has_qe_user( $post_type ) {
		$groups = $this->get_qe_groups_for_post_type( $post_type );
		if ( empty( $groups ) ) {
			return false;
		}

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $field ) {
				if ( isset( $field['type'] ) && 'user' === $field['type'] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Map of post types that have at least one QE-enabled field → groups data.
	 *
	 * @return array
	 */
	private function get_post_types_with_qe_fields() {
		if ( null !== $this->post_type_fields_cache ) {
			return $this->post_type_fields_cache;
		}

		$this->post_type_fields_cache = array();

		$field_groups = CFG()->field_group->load_field_groups();

		foreach ( $field_groups as $group_id => $group ) {
			$rules = isset( $group['rules'] ) && is_array( $group['rules'] ) ? $group['rules'] : array();

			if ( empty( $rules['placement']['values'] ) || 'posts' !== $rules['placement']['values'] ) {
				continue;
			}

			$collected = $this->collect_qe_fields_from_group( (int) $group_id, $group );
			if ( empty( $collected['fields'] ) ) {
				continue;
			}

			$post_types = $this->resolve_group_post_types( $rules );
			foreach ( $post_types as $post_type ) {
				if ( ! isset( $this->post_type_fields_cache[ $post_type ] ) ) {
					$this->post_type_fields_cache[ $post_type ] = array();
				}
				$this->post_type_fields_cache[ $post_type ][ (int) $group_id ] = $collected;
			}
		}

		return $this->post_type_fields_cache;
	}

	/**
	 * Get structured QE groups for a post type (sorted by group extras order when available).
	 *
	 * @param string $post_type Post type.
	 * @return array
	 */
	private function get_qe_groups_for_post_type( $post_type ) {
		$map = $this->get_post_types_with_qe_fields();

		if ( empty( $map[ $post_type ] ) ) {
			return array();
		}

		$groups = array_values( $map[ $post_type ] );

		usort(
			$groups,
			function ( $a, $b ) {
				$order_a = isset( $a['order'] ) ? (int) $a['order'] : 0;
				$order_b = isset( $b['order'] ) ? (int) $b['order'] : 0;
				if ( $order_a === $order_b ) {
					return strcmp( $a['title'], $b['title'] );
				}
				return $order_a <=> $order_b;
			}
		);

		return $groups;
	}

	/**
	 * Resolve post types a field group targets (from placement rules).
	 *
	 * @param array $rules Field group rules.
	 * @return string[]
	 */
	private function resolve_group_post_types( $rules ) {
		if ( empty( $rules['post_types']['values'] ) || ! is_array( $rules['post_types']['values'] ) ) {
			return array();
		}

		$values   = array_map( 'strval', $rules['post_types']['values'] );
		$operator = isset( $rules['post_types']['operator'] ) ? $rules['post_types']['operator'] : '==';

		if ( is_array( $operator ) ) {
			$operator = isset( $operator[0] ) ? $operator[0] : '==';
		}

		if ( '==' === $operator ) {
			return $values;
		}

		// Inequality: all public post types minus listed ones.
		$all = get_post_types( array( 'show_ui' => true ), 'names' );
		unset( $all['attachment'], $all['asenha_cfgroup'], $all['asenha_cpt'], $all['asenha_ctax'] );

		return array_values( array_diff( array_keys( $all ), $values ) );
	}

	/**
	 * Collect QE-enabled top-level fields from a group, preserving weight order and tab info.
	 *
	 * @param int        $group_id Group post ID.
	 * @param array|null $group    Optional preloaded group data.
	 * @return array{group_id:int,title:string,order:int,show_tab_headings:bool,fields:array}
	 */
	private function collect_qe_fields_from_group( $group_id, $group = null ) {
		if ( null === $group ) {
			$all = CFG()->field_group->load_field_groups();
			$group = isset( $all[ $group_id ] ) ? $all[ $group_id ] : null;
		}

		$result = array(
			'group_id'          => (int) $group_id,
			'title'             => $group ? $group['title'] : get_the_title( $group_id ),
			'order'             => 0,
			'show_tab_headings' => false,
			'fields'            => array(),
		);

		if ( ! $group || empty( $group['fields'] ) || ! is_array( $group['fields'] ) ) {
			return $result;
		}

		if ( ! empty( $group['extras']['order'] ) ) {
			$result['order'] = (int) $group['extras']['order'];
		}

		$fields = $group['fields'];
		usort(
			$fields,
			function ( $a, $b ) {
				$wa = isset( $a['weight'] ) ? (int) $a['weight'] : 0;
				$wb = isset( $b['weight'] ) ? (int) $b['weight'] : 0;
				return $wa <=> $wb;
			}
		);

		$current_tab_key   = '';
		$current_tab_label = '';
		$tab_keys_used     = array();

		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			if ( 0 < (int) $field['parent_id'] ) {
				continue;
			}

			$type = isset( $field['type'] ) ? $field['type'] : '';

			if ( 'tab' === $type ) {
				$current_tab_key   = isset( $field['name'] ) ? (string) $field['name'] : (string) $field['id'];
				$current_tab_label = isset( $field['label'] ) ? (string) $field['label'] : $current_tab_key;
				continue;
			}

			// Layout / unsupported types are never Quick Edit fields.
			if ( ! self::is_supported_type( $type ) ) {
				continue;
			}

			if ( empty( $field['options']['show_in_quick_edit'] ) ) {
				continue;
			}

			if ( '' !== $current_tab_key ) {
				$tab_keys_used[ $current_tab_key ] = true;
			}

			$result['fields'][] = array(
				'id'        => (int) $field['id'],
				'name'      => $field['name'],
				'label'     => isset( $field['label'] ) ? $field['label'] : $field['name'],
				'type'      => $type,
				'options'   => isset( $field['options'] ) ? $field['options'] : array(),
				'tab_key'   => $current_tab_key,
				'tab_label' => $current_tab_label,
			);
		}

		$result['show_tab_headings'] = ( count( $tab_keys_used ) > 1 );

		return $result;
	}
}
