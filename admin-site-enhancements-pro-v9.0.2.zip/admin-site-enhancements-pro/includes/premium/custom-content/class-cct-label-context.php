<?php
/**
 * Context rules for ASE custom post type and taxonomy labels.
 *
 * @package Admin and Site Enhancements
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determines which label keys apply for a given CPT/taxonomy definition configuration.
 */
class ASENHA_CCT_Label_Context {

	/**
	 * CPT meta keys gated by thumbnail support.
	 *
	 * @var string[]
	 */
	private static $cpt_featured_image_meta_keys = array(
		'cpt_label_featured_image',
		'cpt_label_set_featured_image',
		'cpt_label_remove_featured_image',
		'cpt_label_use_featured_image',
	);

	/**
	 * CPT register_post_type label keys gated by thumbnail support.
	 *
	 * @var string[]
	 */
	private static $cpt_featured_image_label_keys = array(
		'featured_image',
		'set_featured_image',
		'remove_featured_image',
		'use_featured_image',
	);

	/**
	 * CPT meta keys gated by hierarchical setting.
	 *
	 * @var string[]
	 */
	private static $cpt_hierarchical_meta_keys = array(
		'cpt_label_parent_item_colon',
	);

	/**
	 * CPT register_post_type label keys gated by hierarchical setting.
	 *
	 * @var string[]
	 */
	private static $cpt_hierarchical_label_keys = array(
		'parent_item_colon',
	);

	/**
	 * CPT meta keys gated by page-attributes support.
	 *
	 * @var string[]
	 */
	private static $cpt_page_attributes_meta_keys = array(
		'cpt_label_attributes',
	);

	/**
	 * CPT register_post_type label keys gated by page-attributes support.
	 *
	 * @var string[]
	 */
	private static $cpt_page_attributes_label_keys = array(
		'attributes',
	);

	/**
	 * CPT meta keys gated by has_archive setting.
	 *
	 * @var string[]
	 */
	private static $cpt_has_archive_meta_keys = array(
		'cpt_label_archives',
	);

	/**
	 * CPT register_post_type label keys gated by has_archive setting.
	 *
	 * @var string[]
	 */
	private static $cpt_has_archive_label_keys = array(
		'archives',
	);

	/**
	 * Taxonomy meta keys gated by hierarchical setting.
	 *
	 * @var string[]
	 */
	private static $ctax_hierarchical_meta_keys = array(
		'ctax_label_parent_item',
		'ctax_label_parent_item_colon',
		'ctax_label_parent_field_description',
		'ctax_label_filter_by_item',
	);

	/**
	 * Taxonomy register_taxonomy label keys gated by hierarchical setting.
	 *
	 * @var string[]
	 */
	private static $ctax_hierarchical_label_keys = array(
		'parent_item',
		'parent_item_colon',
		'parent_field_description',
		'filter_by_item',
	);

	/**
	 * Taxonomy meta keys gated by non-hierarchical (tag-style) setting.
	 *
	 * @var string[]
	 */
	private static $ctax_non_hierarchical_meta_keys = array(
		'ctax_label_popular_items',
		'ctax_label_separate_items_with_commas',
		'ctax_label_add_or_remove_items',
		'ctax_label_choose_from_most_used',
	);

	/**
	 * Taxonomy register_taxonomy label keys gated by non-hierarchical setting.
	 *
	 * @var string[]
	 */
	private static $ctax_non_hierarchical_label_keys = array(
		'popular_items',
		'separate_items_with_commas',
		'add_or_remove_items',
		'choose_from_most_used',
	);

	/**
	 * Whether a CPT label/meta key applies for the given definition.
	 *
	 * @param int    $definition_post_id ASE CPT definition post ID.
	 * @param string $key                Meta key or register_post_type label key.
	 * @return bool
	 */
	public static function is_post_type_label_applicable( $definition_post_id, $key ) {
		$definition_post_id = (int) $definition_post_id;
		if ( $definition_post_id <= 0 || '' === $key ) {
			return true;
		}

		$supports      = self::get_cpt_supports( $definition_post_id );
		$hierarchical  = self::is_cpt_hierarchical( $definition_post_id );
		$has_archive   = self::cpt_has_archive_enabled( $definition_post_id );

		if ( in_array( $key, self::$cpt_featured_image_meta_keys, true ) || in_array( $key, self::$cpt_featured_image_label_keys, true ) ) {
			return in_array( 'thumbnail', $supports, true );
		}

		if ( in_array( $key, self::$cpt_hierarchical_meta_keys, true ) || in_array( $key, self::$cpt_hierarchical_label_keys, true ) ) {
			return $hierarchical;
		}

		if ( in_array( $key, self::$cpt_page_attributes_meta_keys, true ) || in_array( $key, self::$cpt_page_attributes_label_keys, true ) ) {
			return in_array( 'page-attributes', $supports, true );
		}

		if ( in_array( $key, self::$cpt_has_archive_meta_keys, true ) || in_array( $key, self::$cpt_has_archive_label_keys, true ) ) {
			return $has_archive;
		}

		return true;
	}

	/**
	 * Whether a taxonomy label/meta key applies for the given definition.
	 *
	 * @param int    $definition_post_id ASE taxonomy definition post ID.
	 * @param string $key                Meta key or register_taxonomy label key.
	 * @return bool
	 */
	public static function is_taxonomy_label_applicable( $definition_post_id, $key ) {
		$definition_post_id = (int) $definition_post_id;
		if ( $definition_post_id <= 0 || '' === $key ) {
			return true;
		}

		$hierarchical = self::is_ctax_hierarchical( $definition_post_id );

		if ( in_array( $key, self::$ctax_hierarchical_meta_keys, true ) || in_array( $key, self::$ctax_hierarchical_label_keys, true ) ) {
			return $hierarchical;
		}

		if ( in_array( $key, self::$ctax_non_hierarchical_meta_keys, true ) || in_array( $key, self::$ctax_non_hierarchical_label_keys, true ) ) {
			return ! $hierarchical;
		}

		return true;
	}

	/**
	 * Remove inapplicable keys from a register_post_type labels array.
	 *
	 * @param array $labels             Runtime labels.
	 * @param int   $definition_post_id ASE CPT definition post ID.
	 * @return array
	 */
	public static function filter_post_type_labels( $labels, $definition_post_id ) {
		if ( ! is_array( $labels ) ) {
			return array();
		}

		foreach ( array_keys( $labels ) as $label_key ) {
			if ( ! self::is_post_type_label_applicable( $definition_post_id, $label_key ) ) {
				unset( $labels[ $label_key ] );
			}
		}

		return $labels;
	}

	/**
	 * Remove inapplicable keys from a register_taxonomy labels array.
	 *
	 * @param array $labels             Runtime labels.
	 * @param int   $definition_post_id ASE taxonomy definition post ID.
	 * @return array
	 */
	public static function filter_taxonomy_labels( $labels, $definition_post_id ) {
		if ( ! is_array( $labels ) ) {
			return array();
		}

		foreach ( array_keys( $labels ) as $label_key ) {
			if ( ! self::is_taxonomy_label_applicable( $definition_post_id, $label_key ) ) {
				unset( $labels[ $label_key ] );
			}
		}

		return $labels;
	}

	/**
	 * Delete stored CPT label meta that does not apply to the current configuration.
	 *
	 * @param int $definition_post_id ASE CPT definition post ID.
	 * @return void
	 */
	public static function clear_inapplicable_post_type_label_meta( $definition_post_id ) {
		$definition_post_id = (int) $definition_post_id;
		if ( $definition_post_id <= 0 ) {
			return;
		}

		$meta_keys = array_merge(
			self::$cpt_featured_image_meta_keys,
			self::$cpt_hierarchical_meta_keys,
			self::$cpt_page_attributes_meta_keys,
			self::$cpt_has_archive_meta_keys
		);

		foreach ( $meta_keys as $meta_key ) {
			if ( ! self::is_post_type_label_applicable( $definition_post_id, $meta_key ) ) {
				delete_post_meta( $definition_post_id, $meta_key );
			}
		}
	}

	/**
	 * Delete stored taxonomy label meta that does not apply to the current configuration.
	 *
	 * @param int $definition_post_id ASE taxonomy definition post ID.
	 * @return void
	 */
	public static function clear_inapplicable_taxonomy_label_meta( $definition_post_id ) {
		$definition_post_id = (int) $definition_post_id;
		if ( $definition_post_id <= 0 ) {
			return;
		}

		$meta_keys = array_merge(
			self::$ctax_hierarchical_meta_keys,
			self::$ctax_non_hierarchical_meta_keys
		);

		foreach ( $meta_keys as $meta_key ) {
			if ( ! self::is_taxonomy_label_applicable( $definition_post_id, $meta_key ) ) {
				delete_post_meta( $definition_post_id, $meta_key );
			}
		}
	}

	/**
	 * Get CPT supports for a definition post.
	 *
	 * @param int $definition_post_id ASE CPT definition post ID.
	 * @return string[]
	 */
	private static function get_cpt_supports( $definition_post_id ) {
		$supports = get_post_meta( $definition_post_id, 'cpt_supports', true );
		$supports = maybe_unserialize( $supports );

		if ( ! is_array( $supports ) ) {
			return array();
		}

		if ( in_array( 'none', $supports, true ) ) {
			return array();
		}

		return $supports;
	}

	/**
	 * Whether a CPT definition is hierarchical.
	 *
	 * @param int $definition_post_id ASE CPT definition post ID.
	 * @return bool
	 */
	private static function is_cpt_hierarchical( $definition_post_id ) {
		return (bool) get_post_meta( $definition_post_id, 'cpt_hierarchical', true );
	}

	/**
	 * Whether a CPT definition has archives enabled.
	 *
	 * @param int $definition_post_id ASE CPT definition post ID.
	 * @return bool
	 */
	private static function cpt_has_archive_enabled( $definition_post_id ) {
		return (bool) get_post_meta( $definition_post_id, 'cpt_has_archive', true );
	}

	/**
	 * Whether a taxonomy definition is hierarchical.
	 *
	 * @param int $definition_post_id ASE taxonomy definition post ID.
	 * @return bool
	 */
	private static function is_ctax_hierarchical( $definition_post_id ) {
		return (bool) get_post_meta( $definition_post_id, 'ctax_hierarchical', true );
	}
}
