<?php
namespace PowerpackElements\Modules\Album\Widgets;

use PowerpackElements\Base\Powerpack_Widget;
use PowerpackElements\Classes\PP_Helper;
use PowerpackElements\Modules\Album\Module;

// Elementor Classes
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Css_Filter;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Modules\DynamicTags\Module as TagsModule;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Album Widget
 */
class Album extends Powerpack_Widget {

	/**
	 * Retrieve Album widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Album' );
	}

	/**
	 * Retrieve Album widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Album' );
	}

	/**
	 * Retrieve Album widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Album' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the Album widget belongs to.
	 *
	 * @since 1.4.13.1
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Album' );
	}

	protected function is_dynamic_content(): bool {
		return false;
	}

	/**
	 * Retrieve the list of scripts the Album widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		if ( PP_Helper::is_edit_mode() || PP_Helper::is_preview_mode() ) {
			return [
				'jquery-fancybox',
				'pp-album',
			];
		}

		$settings = $this->get_settings_for_display();
		$scripts = [];

		if ( 'fancybox' !== $settings['lightbox_library'] ) {
			array_push( $scripts, 'swiper' );
		}

		if ( 'fancybox' === $settings['lightbox_library'] ) {
			array_push( $scripts, 'jquery-fancybox', 'pp-album' );
		}

		return $scripts;
	}

	/**
	 * Retrieve the list of styles the Album widget depended on.
	 *
	 * Used to set styles dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_style_depends() {
		if ( PP_Helper::is_edit_mode() || PP_Helper::is_preview_mode() ) {
			return [
				'widget-pp-album',
				'fancybox',
				'pp-image-filters',
			];
		}

		$settings = $this->get_settings_for_display();
		$styles = [ 'widget-pp-album' ];

		if ( 'fancybox' !== $settings['lightbox_library'] ) {
			array_push( $styles, 'e-swiper' );
		}

		if ( 'fancybox' === $settings['lightbox_library'] ) {
			array_push( $styles, 'fancybox' );
		}

		if ( 'cover' === $settings['trigger'] ) {
			$has_filter = ( ! empty( $settings['album_cover_image_filter'] ) && 'normal' !== $settings['album_cover_image_filter'] )
				|| ( ! empty( $settings['album_cover_image_filter_hover'] ) && 'normal' !== $settings['album_cover_image_filter_hover'] );

			if ( $has_filter ) {
				array_push( $styles, 'pp-image-filters' );
			}
		}

		return $styles;
	}

	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register Album widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function register_controls() {

		/**
		 * Content Tab: Album
		 */
		$this->start_controls_section(
			'section_album',
			[
				'label' => esc_html__( 'Album', 'powerpack' ),
			]
		);

		$this->add_control(
			'album_images',
			[
				'label'   => esc_html__( 'Add Images', 'powerpack' ),
				'type'    => Controls_Manager::GALLERY,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->end_controls_section();

		/**
		 * Content Tab: Trigger
		 */
		$this->start_controls_section(
			'section_album_cover_settings',
			[
				'label' => esc_html__( 'Trigger', 'powerpack' ),
			]
		);

		$this->add_control(
			'trigger',
			[
				'label'   => esc_html__( 'Trigger', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'cover',
				'options' => [
					'cover'  => esc_html__( 'Album Cover', 'powerpack' ),
					'button' => esc_html__( 'Button', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'album_cover_type',
			[
				'label'     => esc_html__( 'Cover Image', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'first_img',
				'options'   => [
					'custom_img' => esc_html__( 'Custom', 'powerpack' ),
					'first_img'  => esc_html__( 'First Image of Album', 'powerpack' ),
				],
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'album_cover',
			[
				'label'     => esc_html__( 'Add Cover Image', 'powerpack' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'trigger'          => 'cover',
					'album_cover_type' => 'custom_img',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'album_cover',
				'default'   => 'full',
				'separator' => 'none',
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_responsive_control(
			'album_height',
			[
				'label'      => esc_html__( 'Album Cover Height', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => 300,
					'unit' => 'px',
				],
				'range'      => [
					'px' => [
						'min'  => 50,
						'max'  => 1000,
						'step' => 1,
					],
				],
				'size_units' => [ 'px', 'em', 'rem', 'vh', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-cover-wrap' => 'height: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'album_trigger_button_text',
			[
				'label'     => esc_html__( 'Button Text', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'View Album', 'powerpack' ),
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_control(
			'select_album_trigger_button_icon',
			[
				'label'            => esc_html__( 'Button Icon', 'powerpack' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'album_trigger_button_icon',
				'condition'        => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_control(
			'album_trigger_button_icon_position',
			[
				'label'     => esc_html__( 'Icon Position', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'after',
				'options'   => [
					'after'  => esc_html__( 'After', 'powerpack' ),
					'before' => esc_html__( 'Before', 'powerpack' ),
				],
				'condition' => [
					'trigger'                    => 'button',
					'album_trigger_button_text!' => '',
					'select_album_trigger_button_icon[value]!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'album_trigger_button_icon_spacing',
			[
				'label'      => esc_html__( 'Icon Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => 8,
					'unit' => 'px',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'size_units' => [ 'px', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-trigger-icon-before .pp-button-icon' => 'margin-right: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .pp-album-trigger-icon-after .pp-button-icon' => 'margin-left: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'trigger'                    => 'button',
					'album_trigger_button_text!' => '',
					'select_album_trigger_button_icon[value]!' => '',
				],
			]
		);

		$this->end_controls_section();

		/**
		 * Content Tab: Album Cover Content
		 */
		$this->start_controls_section(
			'section_album_content',
			[
				'label'     => esc_html__( 'Album Cover Content', 'powerpack' ),
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'select_album_icon',
			[
				'label'            => esc_html__( 'Album Icon', 'powerpack' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'album_icon',
				'condition'        => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'album_title',
			[
				'label'     => esc_html__( 'Title', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'dynamic'   => [
					'active' => true,
				],
				'separator' => 'before',
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'album_title_html_tag',
			[
				'label'     => esc_html__( 'Title HTML Tag', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'div',
				'options'   => [
					'h1'   => esc_html__( 'H1', 'powerpack' ),
					'h2'   => esc_html__( 'H2', 'powerpack' ),
					'h3'   => esc_html__( 'H3', 'powerpack' ),
					'h4'   => esc_html__( 'H4', 'powerpack' ),
					'h5'   => esc_html__( 'H5', 'powerpack' ),
					'h6'   => esc_html__( 'H6', 'powerpack' ),
					'div'  => esc_html__( 'div', 'powerpack' ),
					'span' => esc_html__( 'span', 'powerpack' ),
					'p'    => esc_html__( 'p', 'powerpack' ),
				],
				'condition' => [
					'trigger'      => 'cover',
					'album_title!' => '',
				],
			]
		);

		$this->add_control(
			'album_subtitle',
			[
				'label'     => esc_html__( 'Subtitle', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'album_subtitle_html_tag',
			[
				'label'     => esc_html__( 'Subtitle HTML Tag', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'div',
				'options'   => [
					'h1'   => esc_html__( 'H1', 'powerpack' ),
					'h2'   => esc_html__( 'H2', 'powerpack' ),
					'h3'   => esc_html__( 'H3', 'powerpack' ),
					'h4'   => esc_html__( 'H4', 'powerpack' ),
					'h5'   => esc_html__( 'H5', 'powerpack' ),
					'h6'   => esc_html__( 'H6', 'powerpack' ),
					'div'  => esc_html__( 'div', 'powerpack' ),
					'span' => esc_html__( 'span', 'powerpack' ),
					'p'    => esc_html__( 'p', 'powerpack' ),
				],
				'condition' => [
					'trigger'         => 'cover',
					'album_subtitle!' => '',
				],
			]
		);

		$this->add_control(
			'album_cover_button',
			[
				'label'        => esc_html__( 'Show Button', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'return_value' => 'yes',
				'separator'    => 'before',
				'condition'    => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'album_cover_button_text',
			[
				'label'     => esc_html__( 'Button Text', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'View More', 'powerpack' ),
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'select_album_cover_button_icon',
			[
				'label'            => esc_html__( 'Button Icon', 'powerpack' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'album_cover_button_icon',
				'condition'        => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'album_cover_button_icon_position',
			[
				'label'     => esc_html__( 'Icon Position', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'after',
				'options'   => [
					'after'  => esc_html__( 'After', 'powerpack' ),
					'before' => esc_html__( 'Before', 'powerpack' ),
				],
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
					'select_album_cover_button_icon[value]!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'album_cover_button_position',
			[
				'label'        => esc_html__( 'Button Position', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'bottom',
				'options'      => [
					'inline' => esc_html__( 'Inline', 'powerpack' ),
					'bottom' => esc_html__( 'Below Title', 'powerpack' ),
				],
				'prefix_class' => 'pp-album-cover-button%s-position-',
				'conditions'   => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'trigger',
							'operator' => '==',
							'value'    => 'cover',
						],
						[
							'name'     => 'album_cover_button',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'relation' => 'or',
							'terms'    => [
								[
									'name'     => 'album_title',
									'operator' => '!=',
									'value'    => '',
								],
								[
									'name'     => 'album_subtitle',
									'operator' => '!=',
									'value'    => '',
								],
							],
						],
					],
				],
			]
		);

		$this->end_controls_section();

		/**
		 * Content Tab: Settings
		 */
		$this->start_controls_section(
			'section_general_settings',
			[
				'label' => esc_html__( 'Settings', 'powerpack' ),
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'    => 'image',
				'label'   => esc_html__( 'Image Size', 'powerpack' ),
				'default' => 'full',
				'exclude' => [ 'custom' ],
			]
		);

		$this->add_control(
			'lightbox_library',
			[
				'label'              => esc_html__( 'Lightbox Library', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => '',
				'options'            => [
					''         => esc_html__( 'Elementor', 'powerpack' ),
					'fancybox' => esc_html__( 'Fancybox', 'powerpack' ),
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'lightbox_options_heading',
			[
				'type'      => Controls_Manager::HEADING,
				'label'     => esc_html__( 'Lightbox Options', 'powerpack' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'lightbox_caption',
			[
				'type'    => Controls_Manager::SELECT,
				'label'   => esc_html__( 'Lightbox Title', 'powerpack' ),
				'default' => '',
				'options' => [
					''            => esc_html__( 'None', 'powerpack' ),
					'caption'     => esc_html__( 'Caption', 'powerpack' ),
					'title'       => esc_html__( 'Title', 'powerpack' ),
					'description' => esc_html__( 'Description', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'lightbox_description',
			[
				'type'      => Controls_Manager::SELECT,
				'label'     => esc_html__( 'Lightbox Description', 'powerpack' ),
				'default'   => '',
				'options'   => [
					''            => esc_html__( 'None', 'powerpack' ),
					'caption'     => esc_html__( 'Caption', 'powerpack' ),
					'title'       => esc_html__( 'Title', 'powerpack' ),
					'description' => esc_html__( 'Description', 'powerpack' ),
				],
				'condition' => [
					'lightbox_library!' => 'fancybox',
				],
			]
		);

		$this->add_control(
			'loop',
			[
				'label'              => esc_html__( 'Loop', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'lightbox_library' => 'fancybox',
				],
			]
		);

		$this->add_control(
			'arrows',
			[
				'label'              => esc_html__( 'Arrows', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'lightbox_library' => 'fancybox',
				],
			]
		);

		$this->add_control(
			'slides_counter',
			[
				'label'              => esc_html__( 'Slides Counter', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'lightbox_library' => 'fancybox',
				],
			]
		);

		$this->add_control(
			'keyboard',
			[
				'label'              => esc_html__( 'Keyboard Navigation', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'lightbox_library' => 'fancybox',
				],
			]
		);

		$this->add_control(
			'toolbar',
			[
				'label'              => esc_html__( 'Toolbar', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'lightbox_library' => 'fancybox',
				],
			]
		);

		$this->add_control(
			'toolbar_buttons',
			[
				'label'              => esc_html__( 'Toolbar Buttons', 'powerpack' ),
				'type'               => Controls_Manager::SELECT2,
				'label_block'        => true,
				'default'            => [ 'zoom', 'slideShow', 'thumbs', 'close' ],
				'options'            => [
					'zoom'       => esc_html__( 'Zoom', 'powerpack' ),
					'share'      => esc_html__( 'Share', 'powerpack' ),
					'slideShow'  => esc_html__( 'SlideShow', 'powerpack' ),
					'fullScreen' => esc_html__( 'Full Screen', 'powerpack' ),
					'download'   => esc_html__( 'Download', 'powerpack' ),
					'thumbs'     => esc_html__( 'Thumbs', 'powerpack' ),
					'close'      => esc_html__( 'Close', 'powerpack' ),
				],
				'multiple'           => true,
				'frontend_available' => true,
				'condition'          => [
					'lightbox_library' => 'fancybox',
					'toolbar'          => 'yes',
				],
			]
		);

		$this->add_control(
			'thumbs_auto_start',
			[
				'label'              => esc_html__( 'Thumbs Auto Start', 'powerpack' ),
				'description'        => esc_html__( 'Display thumbnails on lightbox opening', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => '',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'lightbox_library' => 'fancybox',
				],
			]
		);

		$this->add_control(
			'thumbs_position',
			[
				'label'              => esc_html__( 'Thumbs Position', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => '',
				'options'            => [
					''       => esc_html__( 'Default', 'powerpack' ),
					'bottom' => esc_html__( 'Bottom', 'powerpack' ),
				],
				'frontend_available' => true,
				'condition'          => [
					'lightbox_library' => 'fancybox',
				],
			]
		);

		$this->add_control(
			'lightbox_animation',
			[
				'label'              => esc_html__( 'Animation', 'powerpack' ),
				'description'        => esc_html__( 'Open/Close animation', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => 'zoom',
				'options'            => [
					''            => esc_html__( 'None', 'powerpack' ),
					'fade'        => esc_html__( 'Fade', 'powerpack' ),
					'zoom'        => esc_html__( 'Zoom', 'powerpack' ),
					'zoom-in-out' => esc_html__( 'Zoom in Out', 'powerpack' ),
				],
				'frontend_available' => true,
				'condition'          => [
					'lightbox_library' => 'fancybox',
				],
			]
		);

		$this->add_control(
			'transition_effect',
			[
				'label'              => esc_html__( 'Transition Effect', 'powerpack' ),
				'description'        => esc_html__( 'Transition effect between slides', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => 'fade',
				'options'            => [
					''            => esc_html__( 'None', 'powerpack' ),
					'fade'        => esc_html__( 'Fade', 'powerpack' ),
					'slide'       => esc_html__( 'Slide', 'powerpack' ),
					'circular'    => esc_html__( 'Circular', 'powerpack' ),
					'tube'        => esc_html__( 'Tube', 'powerpack' ),
					'zoom-in-out' => esc_html__( 'Zoom in Out', 'powerpack' ),
					'rotate'      => esc_html__( 'Rotate', 'powerpack' ),
				],
				'frontend_available' => true,
				'condition'          => [
					'lightbox_library' => 'fancybox',
				],
			]
		);

		$this->end_controls_section();

		/**
		 * Style Tab: Album Cover
		 */
		$this->start_controls_section(
			'section_cover_style',
			[
				'label'     => esc_html__( 'Album Cover', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_album_cover_style' );

		$this->start_controls_tab(
			'tab_album_cover_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'album_cover_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-album-cover',
				'condition'   => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'album_cover_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-cover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'album_cover_image_scale',
			[
				'label'     => esc_html__( 'Image Scale', 'powerpack' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 1,
				],
				'range'     => [
					'px' => [
						'min'  => 1,
						'max'  => 2,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-album-cover img' => 'transform: scale({{SIZE}});',
				],
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'album_cover_box_shadow',
				'selector'  => '{{WRAPPER}} .pp-album-cover',
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name'      => 'album_cover_css_filters',
				'selector'  => '{{WRAPPER}} .pp-album-cover img',
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'album_cover_image_filter',
			[
				'label'        => esc_html__( 'Image Filter', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'normal',
				'options'      => PP_Helper::get_image_filters(),
				'prefix_class' => 'pp-ins-',
				'condition'    => [
					'trigger' => 'cover',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_album_cover_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'album_cover_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-cover:hover' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'album_cover_image_scale_hover',
			[
				'label'     => esc_html__( 'Image Scale', 'powerpack' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 1,
				],
				'range'     => [
					'px' => [
						'min'  => 1,
						'max'  => 2,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-album-cover:hover img' => 'transform: scale({{SIZE}});',
				],
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'album_cover_box_shadow_hover',
				'selector'  => '{{WRAPPER}} .pp-album-cover:hover',
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name'      => 'album_cover_css_filters_hover',
				'selector'  => '{{WRAPPER}} .pp-album-cover:hover img',
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'album_cover_image_filter_hover',
			[
				'label'        => esc_html__( 'Image Filter', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'normal',
				'options'      => PP_Helper::get_image_filters( true ),
				'prefix_class' => 'pp-ins-hover-',
				'condition'    => [
					'trigger' => 'cover',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			'album_cover_overlay_style_heading',
			[
				'label'     => esc_html__( 'Cover Overlay', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_album_cover_overlay_style' );

		$this->start_controls_tab(
			'tab_album_cover_overlay_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'album_cover_overlay_background',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pp-album-cover-overlay',
				'exclude'   => [
					'image',
				],
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_responsive_control(
			'overlay_margin',
			[
				'label'      => esc_html__( 'Margin', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-cover-overlay' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'trigger' => 'cover',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_album_cover_overlay_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'album_cover_overlay_background_hover',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pp-album-cover:hover .pp-album-cover-overlay',
				'exclude'   => [
					'image',
				],
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		/**
		 * Style Tab: Album Cover Content
		 */
		$this->start_controls_section(
			'section_cover_content_style',
			[
				'label'     => esc_html__( 'Album Cover Content', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_responsive_control(
			'cover_content_vertical_align',
			[
				'label'                => esc_html__( 'Vertical Align', 'powerpack' ),
				'type'                 => Controls_Manager::CHOOSE,
				'options'              => [
					'top'    => [
						'title' => esc_html__( 'Top', 'powerpack' ),
						'icon'  => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_html__( 'Middle', 'powerpack' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_html__( 'Bottom', 'powerpack' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'default'              => 'middle',
				'selectors'            => [
					'{{WRAPPER}} .pp-album-content-wrap' => 'justify-content: {{VALUE}};',
					'{{WRAPPER}}.pp-album-cover-button-position-inline .pp-album-content' => 'align-items: {{VALUE}};',
				],
				'selectors_dictionary' => [
					'top'    => 'flex-start',
					'bottom' => 'flex-end',
					'middle' => 'center',
				],
				'condition'            => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_responsive_control(
			'cover_content_horizontal_align',
			[
				'label'                => esc_html__( 'Horizontal Align', 'powerpack' ),
				'type'                 => Controls_Manager::CHOOSE,
				'options'              => [
					'left'    => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center'  => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'   => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-h-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justify', 'powerpack' ),
						'icon'  => 'eicon-h-align-stretch',
					],
				],
				'default'              => 'center',
				'selectors'            => [
					'{{WRAPPER}} .pp-album-content-wrap' => 'align-items: {{VALUE}};',
				],
				'selectors_dictionary' => [
					'left'    => 'flex-start',
					'right'   => 'flex-end',
					'center'  => 'center',
					'justify' => 'stretch',
				],
				'condition'            => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_responsive_control(
			'cover_content_text_align',
			[
				'label'     => esc_html__( 'Text Align', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .pp-album-content' => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_responsive_control(
			'cover_content_margin',
			[
				'label'      => esc_html__( 'Margin', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator'  => 'before',
				'condition'  => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_responsive_control(
			'cover_content_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'trigger' => 'cover',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_cover_content_style' );

		$this->start_controls_tab(
			'tab_cover_content_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'cover_content_background',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pp-album-content',
				'exclude'   => [
					'image',
				],
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'cover_content_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-album-content',
				'condition'   => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'cover_content_border_radius_normal',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'album_icon_style_heading',
			[
				'label'     => esc_html__( 'Icon', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'trigger'                   => 'cover',
					'select_album_icon[value]!' => '',
				],
			]
		);

		$this->add_control(
			'album_icon_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-icon'     => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-album-icon svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'trigger'                   => 'cover',
					'select_album_icon[value]!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'album_icon_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => '',
					'unit' => 'px',
				],
				'range'      => [
					'px' => [
						'min'  => 1,
						'max'  => 100,
						'step' => 1,
					],
				],
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-icon' => 'font-size: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'trigger'                   => 'cover',
					'select_album_icon[value]!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'icon_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => '',
					'unit' => 'px',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-icon' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'trigger'                   => 'cover',
					'select_album_icon[value]!' => '',
				],
			]
		);

		$this->add_control(
			'album_title_style_heading',
			[
				'label'     => esc_html__( 'Title', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'trigger'      => 'cover',
					'album_title!' => '',
				],
			]
		);

		$this->add_control(
			'album_title_text_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-title' => 'color: {{VALUE}}',
				],
				'condition' => [
					'trigger'      => 'cover',
					'album_title!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'album_title_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector'  => '{{WRAPPER}} .pp-album-title',
				'condition' => [
					'trigger'      => 'cover',
					'album_title!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'title_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => '',
					'unit' => 'px',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-title' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'trigger'      => 'cover',
					'album_title!' => '',
				],
			]
		);

		$this->add_control(
			'album_subtitle_style_heading',
			[
				'label'     => esc_html__( 'Subtitle', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'trigger'         => 'cover',
					'album_subtitle!' => '',
				],
			]
		);

		$this->add_control(
			'album_subtitle_text_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-subtitle' => 'color: {{VALUE}}',
				],
				'condition' => [
					'trigger'         => 'cover',
					'album_subtitle!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'album_subtitle_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
				'selector'  => '{{WRAPPER}} .pp-album-subtitle',
				'condition' => [
					'trigger'         => 'cover',
					'album_subtitle!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'subtitle_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => '',
					'unit' => 'px',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-subtitle' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'trigger'         => 'cover',
					'album_subtitle!' => '',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_cover_content_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'cover_content_background_hover',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pp-album-cover:hover .pp-album-content',
				'exclude'   => [
					'image',
				],
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->add_control(
			'album_icon_color_hover',
			[
				'label'     => esc_html__( 'Icon Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-cover:hover .pp-album-icon' => 'color: {{VALUE}}',
				],
				'condition' => [
					'trigger'                   => 'cover',
					'select_album_icon[value]!' => '',
				],
			]
		);

		$this->add_control(
			'album_title_color_hover',
			[
				'label'     => esc_html__( 'Title Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-cover:hover .pp-album-title' => 'color: {{VALUE}}',
				],
				'condition' => [
					'trigger'      => 'cover',
					'album_title!' => '',
				],
			]
		);

		$this->add_control(
			'album_subtitle_color_hover',
			[
				'label'     => esc_html__( 'Subtitle Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-cover:hover .pp-album-subtitle' => 'color: {{VALUE}}',
				],
				'condition' => [
					'trigger'         => 'cover',
					'album_subtitle!' => '',
				],
			]
		);

		$this->add_control(
			'cover_content_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-cover:hover .pp-album-content' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'cover_content_blend_mode',
			[
				'label'     => esc_html__( 'Blend Mode', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''            => esc_html__( 'Normal', 'powerpack' ),
					'multiply'    => 'Multiply',
					'screen'      => 'Screen',
					'overlay'     => 'Overlay',
					'darken'      => 'Darken',
					'lighten'     => 'Lighten',
					'color-dodge' => 'Color Dodge',
					'saturation'  => 'Saturation',
					'color'       => 'Color',
					'difference'  => 'Difference',
					'exclusion'   => 'Exclusion',
					'hue'         => 'Hue',
					'luminosity'  => 'Luminosity',
				],
				'selectors' => [
					'{{WRAPPER}} .pp-album-content' => 'mix-blend-mode: {{VALUE}}',
				],
				'separator' => 'before',
				'condition' => [
					'trigger' => 'cover',
				],
			]
		);

		$this->end_controls_section();

		/**
		 * Style Tab: Album Cover Button
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_album_cover_button_style',
			[
				'label'     => esc_html__( 'Album Cover Button', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'album_cover_button_size',
			[
				'label'     => esc_html__( 'Size', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'xs',
				'options'   => [
					'xs' => esc_html__( 'Extra Small', 'powerpack' ),
					'sm' => esc_html__( 'Small', 'powerpack' ),
					'md' => esc_html__( 'Medium', 'powerpack' ),
					'lg' => esc_html__( 'Large', 'powerpack' ),
					'xl' => esc_html__( 'Extra Large', 'powerpack' ),
				],
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_album_cover_button_style' );

		$this->start_controls_tab(
			'tab_album_cover_button_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'album_cover_button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-cover-button' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-album-cover-button svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'album_cover_button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_ACCENT,
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-cover-button' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'album_cover_button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-album-cover-button',
				'condition'   => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'album_cover_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-cover-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'album_cover_button_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector'  => '{{WRAPPER}} .pp-album-cover-button',
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'album_cover_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-cover-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'album_cover_button_box_shadow',
				'selector'  => '{{WRAPPER}} .pp-album-cover-button',
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'album_cover_button_icon_heading',
			[
				'label'     => esc_html__( 'Button Icon', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
					'select_album_cover_button_icon[value]!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'album_cover_button_icon_margin',
			[
				'label'       => esc_html__( 'Margin', 'powerpack' ),
				'type'        => Controls_Manager::DIMENSIONS,
				'size_units'  => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'placeholder' => [
					'top'    => '',
					'right'  => '',
					'bottom' => '',
					'left'   => '',
				],
				'selectors'   => [
					'{{WRAPPER}} .pp-album-cover-button .pp-button-icon' => 'margin-top: {{TOP}}{{UNIT}}; margin-left: {{LEFT}}{{UNIT}}; margin-right: {{RIGHT}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}};',
				],
				'condition'   => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
					'select_album_cover_button_icon[value]!' => '',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_album_cover_button_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'album_cover_button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-cover-button:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-album-cover-button:hover svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'album_cover_button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-cover-button:hover' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'album_cover_button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-cover-button:hover' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'album_cover_button_animation',
			[
				'label'     => esc_html__( 'Animation', 'powerpack' ),
				'type'      => Controls_Manager::HOVER_ANIMATION,
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'album_cover_button_box_shadow_hover',
				'selector'  => '{{WRAPPER}} .pp-album-cover-button:hover',
				'condition' => [
					'trigger'            => 'cover',
					'album_cover_button' => 'yes',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();

		/**
		 * Style Tab: Album Trigger Button
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_album_trigger_button_style',
			[
				'label'     => esc_html__( 'Album Trigger Button', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_control(
			'album_trigger_button_size',
			[
				'label'     => esc_html__( 'Size', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'md',
				'options'   => [
					'xs' => esc_html__( 'Extra Small', 'powerpack' ),
					'sm' => esc_html__( 'Small', 'powerpack' ),
					'md' => esc_html__( 'Medium', 'powerpack' ),
					'lg' => esc_html__( 'Large', 'powerpack' ),
					'xl' => esc_html__( 'Extra Large', 'powerpack' ),
				],
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_responsive_control(
			'album_trigger_button_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-trigger-button-wrap' => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_album_trigger_button_style' );

		$this->start_controls_tab(
			'tab_album_trigger_button_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_control(
			'album_trigger_button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-trigger-button' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-album-trigger-button svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_control(
			'album_trigger_button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_ACCENT,
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-trigger-button' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'album_trigger_button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-album-trigger-button',
				'condition'   => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_control(
			'album_trigger_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-trigger-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'album_trigger_button_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector'  => '{{WRAPPER}} .pp-album-trigger-button',
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_responsive_control(
			'album_trigger_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-album-trigger-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'album_trigger_button_box_shadow',
				'selector'  => '{{WRAPPER}} .pp-album-trigger-button',
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_album_trigger_button_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_control(
			'album_trigger_button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-trigger-button:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-album-trigger-button:hover svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_control(
			'album_trigger_button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-trigger-button:hover' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_control(
			'album_trigger_button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-album-trigger-button:hover' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_control(
			'album_trigger_button_animation',
			[
				'label'     => esc_html__( 'Animation', 'powerpack' ),
				'type'      => Controls_Manager::HOVER_ANIMATION,
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'album_trigger_button_box_shadow_hover',
				'selector'  => '{{WRAPPER}} .pp-album-trigger-button:hover',
				'condition' => [
					'trigger' => 'button',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute(
			'album',
			[
				'class'   => 'pp-album',
				'data-id' => 'pp-album-' . esc_attr( $this->get_id() ) . '-' . esc_attr( (int) get_the_ID() ),
			]
		);

		if ( 'cover' === $settings['trigger'] ) {
			$this->add_render_attribute( 'album', 'class', [ 'pp-album-cover-wrap', 'pp-ins-filter-hover' ] );
		}

		if ( 'fancybox' === $settings['lightbox_library'] ) {
			if ( 'bottom' === $settings['thumbs_position'] ) {
				$this->add_render_attribute(
					'album',
					[
						'data-fancybox-class' => 'pp-fancybox-thumbs-x',
						'data-fancybox-axis'  => 'x',
					]
				);
			} else {
				$this->add_render_attribute(
					'album',
					[
						'data-fancybox-class' => 'pp-fancybox-thumbs-y',
						'data-fancybox-axis'  => 'y',
					]
				);
			}
		}

		$this->add_render_attribute( 'album-gallery', 'class', 'pp-album-gallery pp-hidden' );
		?>
		<div class="pp-album-container">
			<?php if ( ! empty( $settings['album_images'] ) ) { ?>
			<div <?php $this->print_render_attribute_string( 'album' ); ?>>
				<?php
				if ( 'cover' === $settings['trigger'] ) {
					// Album Cover
					$this->render_album_cover();
				} else {
					// Album Trigger Button
					echo $this->get_album_trigger_button(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				?>
				<div <?php $this->print_render_attribute_string( 'album-gallery' ); ?>>
					<?php
						$this->render_album_images();
					?>
				</div>
			</div>
				<?php
			} else {
				$placeholder = esc_html__( 'Choose some images for album in widget settings.', 'powerpack' );

				$this->render_editor_placeholder(
					[
						'title' => esc_html__( 'Album is empty!', 'powerpack' ),
						'body'  => $placeholder,
					]
				);
			}
			?>
		</div>
		<?php
	}

	protected function render_album_images() {
		$settings = $this->get_settings_for_display();
		$gallery  = $settings['album_images'];
		$is_first = true;
		foreach ( $gallery as $index => $item ) {
			if ( $is_first ) {
				$is_first = false;
				continue;
			}

			$image_key = $this->get_repeater_setting_key( 'image', 'album_images', $index );

			$image_url = Group_Control_Image_Size::get_attachment_image_src( $item['id'], 'image', $settings );

			$thumbs_url = wp_get_attachment_image_src( $item['id'], 'thumbnail' );

			$this->add_render_attribute(
				$image_key,
				[
					'class' => 'pp-album-image',
				]
			);

			$this->get_lightbox_atts( $image_key, $item, $image_url );

			$thumbs_html = '';

			$toolbar_buttons = isset( $settings['toolbar_buttons'] ) && is_array( $settings['toolbar_buttons'] ) ? $settings['toolbar_buttons'] : [];

			if ( 'fancybox' === $settings['lightbox_library'] && is_array( $thumbs_url ) ) {
				if ( in_array( 'thumbs', $toolbar_buttons, true ) || 'yes' === $settings['thumbs_auto_start'] ) {
					$thumbs_html = '<img src="' . esc_url( $thumbs_url[0] ) . '" alt="">';
				}
			}
			?>
			<a <?php $this->print_render_attribute_string( $image_key ); ?>><?php echo wp_kses_post( $thumbs_html ); ?></a>
			<?php
		}
	}

	protected function render_album_cover() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute(
			'album-cover',
			[
				'class' => [ 'pp-album-cover', 'pp-ins-filter-target' ],
			]
		);

		$link_key = 'album-cover-link';

		$album = $settings['album_images'];

		if ( ! empty( $album ) ) {
			$album_first_item = $album[0];
			$album_image_url  = Group_Control_Image_Size::get_attachment_image_src( $album_first_item['id'], 'image', $settings );

			$this->get_lightbox_atts( $link_key, $album_first_item, $album_image_url );
			?>
			<a <?php $this->print_render_attribute_string( $link_key ); ?>>
				<div <?php $this->print_render_attribute_string( 'album-cover' ); ?>>
				<?php
				if ( 'custom_img' === $settings['album_cover_type'] ) {
					$image_html = Group_Control_Image_Size::get_attachment_image_html( $settings, 'album_cover', 'album_cover' );
				} else {
					$settings['album_cover']['id'] = $album_first_item['id'];
					$image_html                    = Group_Control_Image_Size::get_attachment_image_html( $settings, 'album_cover', 'album_cover' );
				}

				$image_html .= $this->render_image_overlay();

				$image_html .= $this->get_album_content();

				echo wp_kses_post( $image_html );
				?>
				</div>
			</a>
			<?php
		}
	}

	protected function get_album_content() {
		$settings = $this->get_settings_for_display();

		ob_start();
		if ( ! isset( $settings['album_icon'] ) && ! Icons_Manager::is_migration_allowed() ) {
			// add old default
			$settings['album_icon'] = '';
		}

		$has_icon = ! empty( $settings['album_icon'] );

		if ( $has_icon ) {
			$this->add_render_attribute( 'i', 'class', $settings['album_icon'] );
			$this->add_render_attribute( 'i', 'aria-hidden', 'true' );
		}

		if ( ! $has_icon && ! empty( $settings['select_album_icon']['value'] ) ) {
			$has_icon = true;
		}
		$migrated = isset( $settings['__fa4_migrated']['select_album_icon'] );
		$is_new   = ! isset( $settings['album_icon'] ) && Icons_Manager::is_migration_allowed();

		$content_html = '';
		$is_icon      = '';

		if ( $has_icon || $settings['album_title'] || $settings['album_subtitle'] || 'yes' === $settings['album_cover_button'] ) {
			?>
			<div class="pp-album-content-wrap pp-media-content">
				<div class="pp-album-content">
					<div class="pp-album-content-inner">
						<?php if ( $has_icon ) { ?>
							<div class="pp-icon pp-album-icon">
								<?php
								if ( $is_new || $migrated ) {
									Icons_Manager::render_icon( $settings['select_album_icon'], [ 'aria-hidden' => 'true' ] );
								} elseif ( ! empty( $settings['album_icon'] ) ) {
									?>
									<i <?php $this->print_render_attribute_string( 'i' ); ?>></i>
									<?php
								}
								?>
							</div>
						<?php } ?>
						<?php
						if ( $settings['album_title'] ) {
							echo wp_kses_post( $this->get_album_title() );
						}

						if ( $settings['album_subtitle'] ) {
							echo wp_kses_post( $this->get_album_subtitle() );
						}
						?>
					</div>
					<?php
					if ( 'yes' === $settings['album_cover_button'] ) {
						echo wp_kses_post( $this->get_album_cover_button() );
					}
					?>
				</div>
			</div>
			<?php
		}

		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

	protected function get_album_title() {
		$settings = $this->get_settings_for_display();

		$title_html = '';

		$this->add_render_attribute( 'album_title', 'class', 'pp-album-title' );

		$title_html     .= sprintf( '<%1$s %2$s>', $settings['album_title_html_tag'], $this->get_render_attribute_string( 'album_title' ) );
			$title_html .= $settings['album_title'];
		$title_html     .= sprintf( '</%1$s>', $settings['album_title_html_tag'] );

		return $title_html;
	}

	protected function get_album_subtitle() {
		$settings = $this->get_settings_for_display();

		$subtitle_html = '';

		$this->add_render_attribute( 'album_subtitle', 'class', 'pp-album-subtitle' );

		$subtitle_html     .= sprintf( '<%1$s %2$s>', $settings['album_subtitle_html_tag'], $this->get_render_attribute_string( 'album_subtitle' ) );
			$subtitle_html .= $settings['album_subtitle'];
		$subtitle_html     .= sprintf( '</%1$s>', $settings['album_subtitle_html_tag'] );

		return $subtitle_html;
	}

	protected function get_album_cover_button() {
		$settings = $this->get_settings_for_display();
		ob_start();

		$this->add_render_attribute(
			'cover-button',
			'class',
			[
				'pp-album-cover-button',
				'elementor-button',
				'elementor-size-' . $settings['album_cover_button_size'],
			]
		);

		if ( $settings['album_cover_button_animation'] ) {
			$this->add_render_attribute( 'cover-button', 'class', 'elementor-animation-' . $settings['album_cover_button_animation'] );
		}

		if ( ! isset( $settings['album_cover_button_icon'] ) && ! Icons_Manager::is_migration_allowed() ) {
			// add old default
			$settings['album_cover_button_icon'] = '';
		}

		$has_icon = ! empty( $settings['album_cover_button_icon'] );

		if ( $has_icon ) {
			$this->add_render_attribute( 'i', 'class', $settings['album_cover_button_icon'] );
			$this->add_render_attribute( 'i', 'aria-hidden', 'true' );
		}

		$icon_attributes = $this->get_render_attribute_string( 'album_cover_button_icon' );

		if ( ! $has_icon && ! empty( $settings['select_album_cover_button_icon']['value'] ) ) {
			$has_icon = true;
		}
		$migrated = isset( $settings['__fa4_migrated']['select_album_cover_button_icon'] );
		$is_new   = ! isset( $settings['album_cover_button_icon'] ) && Icons_Manager::is_migration_allowed();
		?>
		<div class="pp-album-cover-button-wrap">
			<div <?php $this->print_render_attribute_string( 'cover-button' ); ?>>
				<?php if ( ! empty( $settings['album_cover_button_icon'] ) || ( ! empty( $settings['select_album_cover_button_icon']['value'] ) && $is_new ) ) { ?>
					<?php if ( 'before' === $settings['album_cover_button_icon_position'] ) { ?>
					<span class="pp-button-icon pp-icon pp-no-trans">
						<?php
						if ( $is_new || $migrated ) {
							Icons_Manager::render_icon( $settings['select_album_cover_button_icon'], [ 'aria-hidden' => 'true' ] );
						} elseif ( ! empty( $settings['album_cover_button_icon'] ) ) {
							?>
							<i <?php $this->print_render_attribute_string( 'i' ); ?>></i>
							<?php
						}
						?>
					</span>
				<?php } ?>
				<?php } ?>
				<?php if ( ! empty( $settings['album_cover_button_text'] ) ) { ?>
					<span <?php $this->print_render_attribute_string( 'album_cover_button_text' ); ?>>
						<?php echo esc_html( $settings['album_cover_button_text'] ); ?>
					</span>
				<?php } ?>
				<?php if ( ! empty( $settings['album_cover_button_icon'] ) || ( ! empty( $settings['select_album_cover_button_icon']['value'] ) && $is_new ) ) { ?>
					<?php if ( 'after' === $settings['album_cover_button_icon_position'] ) { ?>
					<span class="pp-button-icon pp-icon pp-no-trans">
						<?php
						if ( $is_new || $migrated ) {
							Icons_Manager::render_icon( $settings['select_album_cover_button_icon'], [ 'aria-hidden' => 'true' ] );
						} elseif ( ! empty( $settings['album_cover_button_icon'] ) ) {
							?>
							<i <?php $this->print_render_attribute_string( 'i' ); ?>></i>
							<?php
						}
						?>
					</span>
				<?php } ?>
				<?php } ?>
			</div>
		</div>
		<?php

		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

	protected function get_album_trigger_button() {
		$settings = $this->get_settings_for_display();
		ob_start();

		$this->add_render_attribute(
			'trigger-button',
			'class',
			[
				'pp-album-trigger-button',
				'elementor-button',
				'elementor-size-' . $settings['album_trigger_button_size'],
			]
		);

		if ( $settings['album_trigger_button_animation'] ) {
			$this->add_render_attribute( 'trigger-button', 'class', 'elementor-animation-' . $settings['album_trigger_button_animation'] );
		}

		$album            = $settings['album_images'];
		$album_first_item = $album[0];
		$album_image_url  = Group_Control_Image_Size::get_attachment_image_src( $album_first_item['id'], 'image', $settings );

		$this->get_lightbox_atts( 'trigger-button', $album_first_item, $album_image_url );

		$this->add_render_attribute( 'trigger-button-content', 'class', 'pp-album-button-content' );

		if ( ! isset( $settings['album_trigger_button_icon'] ) && ! Icons_Manager::is_migration_allowed() ) {
			// add old default
			$settings['album_trigger_button_icon'] = '';
		}

		$has_icon = ! empty( $settings['album_trigger_button_icon'] );

		if ( $has_icon ) {
			$this->add_render_attribute( 'i', 'class', $settings['album_trigger_button_icon'] );
			$this->add_render_attribute( 'i', 'aria-hidden', 'true' );
		}

		$icon_attributes = $this->get_render_attribute_string( 'album_trigger_button_icon' );

		if ( ! $has_icon && ! empty( $settings['select_album_trigger_button_icon']['value'] ) ) {
			$has_icon = true;
		}
		$migrated = isset( $settings['__fa4_migrated']['select_album_trigger_button_icon'] );
		$is_new   = ! isset( $settings['album_trigger_button_icon'] ) && Icons_Manager::is_migration_allowed();

		if ( ! empty( $settings['album_trigger_button_icon'] ) || ( ! empty( $settings['select_album_trigger_button_icon']['value'] ) && ( $is_new || $migrated ) ) ) {
			$this->add_render_attribute( 'trigger-button', 'class', 'pp-album-trigger-icon-' . $settings['album_trigger_button_icon_position'] );
		}
		?>
		<div class="pp-album-trigger-button-wrap">
			<a <?php $this->print_render_attribute_string( 'trigger-button' ); ?>>
				<span <?php $this->print_render_attribute_string( 'trigger-button-content' ); ?>>
					<?php if ( ! empty( $settings['album_trigger_button_text'] ) ) { ?>
						<span <?php $this->print_render_attribute_string( 'album_trigger_button_text' ); ?>>
							<?php echo esc_html( $settings['album_trigger_button_text'] ); ?>
						</span>
					<?php } ?>
					<?php if ( ! empty( $settings['album_trigger_button_icon'] ) || ( ! empty( $settings['select_album_trigger_button_icon']['value'] ) && $is_new ) ) { ?>
						<span class="pp-button-icon pp-icon">
						<?php
						if ( $is_new || $migrated ) {
							Icons_Manager::render_icon( $settings['select_album_trigger_button_icon'], [ 'aria-hidden' => 'true' ] );
						} elseif ( ! empty( $settings['album_trigger_button_icon'] ) ) {
							?>
							<i <?php $this->print_render_attribute_string( 'i' ); ?>></i>
							<?php
						}
						?>
						</span>
					<?php } ?>
				</span>
			</a>
		</div>
		<?php

		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

	protected function get_lightbox_atts( $key = '', $item = '', $link = '' ) {
		$settings = $this->get_settings_for_display();

		if ( 'fancybox' === $settings['lightbox_library'] ) {
			$this->add_render_attribute(
				$key,
				[
					'data-elementor-open-lightbox' => 'no',
					'data-fancybox'                => 'pp-album-' . esc_attr( $this->get_id() ) . '-' . esc_attr( get_the_ID() ),
				]
			);

			if ( $settings['lightbox_caption'] ) {
				// Fancybox injects this with .html(), so markup in the attachment
				// reaches the DOM. Captions are allowed to carry formatting, so it is
				// filtered rather than escaped.
				$caption = wp_kses_post( Module::get_image_caption( $item['id'], $settings['lightbox_caption'] ) );

				$this->add_render_attribute( $key, 'data-caption', $caption );
			}

			$this->add_render_attribute( $key, 'data-src', esc_url( $link ) );
		} else {
			$this->add_lightbox_data_attributes( $key, $item['id'], 'yes', $this->get_id() );

			if ( $settings['lightbox_caption'] ) {
				$caption = Module::get_image_caption( $item['id'], $settings['lightbox_caption'] );

				$this->add_render_attribute( $key, 'data-elementor-lightbox-title', $caption );
			}

			if ( $settings['lightbox_description'] ) {
				$description = Module::get_image_caption( $item['id'], $settings['lightbox_description'] );

				$this->add_render_attribute( $key, 'data-elementor-lightbox-description', $description );
			}

			$this->add_render_attribute(
				$key,
				[
					'href'  => esc_url( $link ),
					'class' => 'elementor-clickable',
				]
			);
		}
	}

	protected function render_image_overlay() {
		return '<div class="pp-album-cover-overlay pp-media-overlay"></div>';
	}
}
