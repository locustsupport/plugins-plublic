<?php
namespace PowerpackElements\Modules\Posts\Widgets;

use PowerpackElements\Modules\Posts\Widgets\Posts_Base;
use PowerpackElements\Classes\PP_Posts_Helper;
use PowerpackElements\Classes\PP_Helper;

// Elementor Classes.
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Modules\DynamicTags\Module as TagsModule;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Timeline Widget
 */
class Timeline extends Posts_Base {

	/**
	 * Retrieve timeline widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Timeline' );
	}

	/**
	 * The timeline's post query, built at most once per render pass.
	 *
	 * Both the horizontal navigation rail and the cards iterate the same posts.
	 * Building the query lazily and rewinding it means one WP_Query per render
	 * instead of one per consumer.
	 *
	 * @since 3.0.1
	 * @access protected
	 *
	 * @return \WP_Query|null
	 */
	protected function get_timeline_query() {
		if ( ! $this->get_query() instanceof \WP_Query ) {
			$this->query_posts( [
				'widget_type' => 'timeline',
				'old_code'    => true,
			] );
		}

		$query = $this->get_query();

		if ( $query instanceof \WP_Query ) {
			$query->rewind_posts();
		}

		return $query;
	}

	/**
	 * Retrieve timeline widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Timeline' );
	}

	/**
	 * Retrieve timeline widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Timeline' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Timeline' );
	}

	/**
	 * Whether the widget produces dynamic content.
	 *
	 * Used by Elementor to decide whether the widget should bypass page cache.
	 *
	 * @access protected
	 *
	 * @return bool
	 */
	protected function is_dynamic_content(): bool {
		return true;
	}

	/**
	 * Retrieve the list of scripts the timeline widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		if ( PP_Helper::is_edit_mode() || PP_Helper::is_preview_mode() ) {
			return [
				'swiper',
				'pp-timeline',
			];
		}

		$settings = $this->get_settings_for_display();
		$scripts  = [ 'pp-timeline' ];

		if ( 'horizontal' === $settings['layout'] ) {
			array_push( $scripts, 'swiper' );
		}

		return $scripts;
	}

	/**
	 * Retrieve the list of styles the timeline widget depended on.
	 *
	 * Used to set styles dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget styles dependencies.
	 */
	public function get_style_depends() {
		if ( PP_Helper::is_edit_mode() || PP_Helper::is_preview_mode() ) {
			return [ 'e-swiper', 'pp-swiper', 'widget-pp-timeline' ];
		}

		$settings = $this->get_settings_for_display();
		$styles   = [ 'widget-pp-timeline' ];

		if ( 'horizontal' === $settings['layout'] ) {
			array_push( $styles, 'e-swiper', 'pp-swiper' );
		}

		return $styles;
	}

	/**
	 * Whether the widget wraps its output in Elementor's inner wrapper element.
	 *
	 * @access public
	 *
	 * @return bool
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register timeline widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_controls() {

		/* Content Tab: Settings */
		$this->register_content_settings_controls();

		/* Content Tab: Timeline */
		$this->register_content_timeline_items_controls();

		/* Content Tab: Query */
		$this->register_query_section_controls( [ 'source' => 'posts' ], 'timeline', 'yes' );

		/* Content Tab: Posts */
		$this->register_content_posts_controls();

		/* Content Tab: Pagination */
		$this->register_pagination_controls();

		/* Style Tab: Layout */
		$this->register_style_layout_controls();

		/* Style Tab: Cards */
		$this->register_style_cards_controls();

		/* Style Tab: Marker */
		$this->register_style_marker_controls();

		/* Style Tab: Dates */
		$this->register_style_dates_controls();

		/* Style Tab: Connector */
		$this->register_style_connector_controls();

		/* Style Tab: Arrows */
		$this->register_style_arrows_controls();

		/* Style Tab: Dots */
		$this->register_style_dots_controls();

		/* Style Tab: Button */
		$this->register_style_button_controls();

		/* Style Tab: Pagination */
		$this->register_style_pagination_controls();
	}

	/**
	 * Content Tab: Settings
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_content_settings_controls() {
		$this->start_controls_section(
			'section_post_settings',
			[
				'label' => esc_html__( 'Settings', 'powerpack' ),
			]
		);

		$this->add_control(
			'source',
			[
				'label'   => esc_html__( 'Source', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'custom' => esc_html__( 'Custom', 'powerpack' ),
					'posts'  => esc_html__( 'Posts', 'powerpack' ),
				],
				'default' => 'custom',
			]
		);

		$this->add_control(
			'layout',
			[
				'label'              => esc_html__( 'Layout', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'options'            => [
					'horizontal' => esc_html__( 'Horizontal', 'powerpack' ),
					'vertical'   => esc_html__( 'Vertical', 'powerpack' ),
				],
				'default'            => 'vertical',
				'frontend_available' => true,
			]
		);

		$slides_per_view = range( 1, 8 );
		$slides_per_view = array_combine( $slides_per_view, $slides_per_view );

		$this->add_responsive_control(
			'columns',
			[
				'label'              => esc_html__( 'Columns', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => '3',
				'tablet_default'     => '2',
				'mobile_default'     => '1',
				'options'            => $slides_per_view,
				'frontend_available' => true,
				'condition'          => [
					'layout' => 'horizontal',
				],
			]
		);

		$this->add_responsive_control(
			'slides_to_scroll',
			[
				'type'                  => Controls_Manager::SELECT,
				'label'                 => esc_html__( 'Cards to Scroll', 'powerpack' ),
				'description'           => esc_html__( 'Set how many card are scrolled per swipe.', 'powerpack' ),
				'options'               => $slides_per_view,
				'default'               => '1',
				'tablet_default'        => '1',
				'mobile_default'        => '1',
				'frontend_available'    => true,
				'condition'             => [
					'layout'       => 'horizontal',
				],
			]
		);

		$this->add_control(
			'title_html_tag',
			[
				'label'   => esc_html__( 'Title HTML Tag', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1'   => esc_html__( 'H1', 'powerpack' ),
					'h2'   => esc_html__( 'H2', 'powerpack' ),
					'h3'   => esc_html__( 'H3', 'powerpack' ),
					'h4'   => esc_html__( 'H4', 'powerpack' ),
					'h5'   => esc_html__( 'H5', 'powerpack' ),
					'h6'   => esc_html__( 'H6', 'powerpack' ),
					'div'  => esc_html__( 'div', 'powerpack' ),
					'span' => esc_html__( 'span', 'powerpack' ),
					'p'    => esc_html__( 'p', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'media_position',
			[
				'label'   => esc_html__( 'Image Position', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'above-title',
				'options' => [
					'above-title'   => esc_html__( 'Above Title', 'powerpack' ),
					'below-title'   => esc_html__( 'Below Title', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'equal_height',
			[
				'label'        => esc_html__( 'Equal Height', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'return_value' => 'yes',
				'frontend_available' => true,
				'condition'    => [
					'layout' => 'horizontal',
				],
			]
		);

		$this->add_control(
			'posts_per_page',
			[
				'label'     => esc_html__( 'Posts Count', 'powerpack' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 4,
				'condition' => [
					'source' => 'posts',
				],
			]
		);

		$this->add_control(
			'dates',
			[
				'label'              => esc_html__( 'Date', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'return_value'       => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'date_format',
			[
				'label'     => esc_html__( 'Date Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''         => esc_html__( 'Published Date', 'powerpack' ),
					'ago'      => esc_html__( 'Time Ago', 'powerpack' ),
					'modified' => esc_html__( 'Last Modified Date', 'powerpack' ),
					'key'      => esc_html__( 'Custom Meta Key', 'powerpack' ),
				],
				'default'   => '',
				'condition' => [
					'source' => 'posts',
					'dates'  => 'yes',
				],
			]
		);

		$this->add_control(
			'timeline_post_date_key',
			[
				'label'       => esc_html__( 'Custom Meta Key', 'powerpack' ),
				'description' => esc_html__( 'Display the post date stored in custom meta key.', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => false,
				'default'     => '',
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'source'      => 'posts',
					'dates'       => 'yes',
					'date_format' => 'key',
				],
			]
		);

		$this->add_control(
			'date_format_select',
			[
				'label'     => esc_html__( 'Date Format', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''       => esc_html__( 'Default', 'powerpack' ),
					'F j, Y' => date_i18n( 'F j, Y' ),
					'Y-m-d'  => date_i18n( 'Y-m-d' ),
					'm/d/Y'  => date_i18n( 'm/d/Y' ),
					'd/m/Y'  => date_i18n( 'd/m/Y' ),
					'custom' => esc_html__( 'Custom', 'powerpack' ),
				],
				'default'   => '',
				'condition' => [
					'source' => 'posts',
					'dates'  => 'yes',
					'date_format' => [ '', 'modified', 'key' ],
				],
			]
		);

		$this->add_control(
			'timeline_post_date_format',
			[
				'label'       => esc_html__( 'Custom Format', 'powerpack' ),
				'description' => sprintf(
					/* translators: 1: Link opening tag, 2: 2: Link closing tag. */
					esc_html__( 'Refer to PHP date formats %1$shere%2$s', 'powerpack' ),
					sprintf( '<a href="%s" target="_blank">', 'https://wordpress.org/support/article/formatting-date-and-time/' ),
					'</a>'
				),
				'type'        => Controls_Manager::TEXT,
				'label_block' => false,
				'default'     => get_option( 'date_format' ),
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'source'      => 'posts',
					'dates'       => 'yes',
					'date_format' => [ '', 'modified', 'key' ],
					'date_format_select' => 'custom',
				],
			]
		);

		$this->add_control(
			'card_arrow',
			[
				'label'              => esc_html__( 'Card Arrow', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'return_value'       => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'animate_cards',
			[
				'label'              => esc_html__( 'Animate Cards', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'layout' => 'vertical',
				],
			]
		);

		$this->add_control(
			'arrows',
			[
				'label'              => esc_html__( 'Arrows', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'layout' => 'horizontal',
				],
			]
		);

		$this->add_control(
			'dots',
			[
				'label'              => esc_html__( 'Dots', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => '',
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'layout' => 'horizontal',
				],
			]
		);

		$this->add_control(
			'slider_speed',
			[
				'label'                 => esc_html__( 'Slider Speed', 'powerpack' ),
				'description'           => esc_html__( 'Duration of transition between slides (in ms)', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => '',
				'default'               => [ 'size' => 500 ],
				'range'                 => [
					'px' => [
						'min'   => 100,
						'max'   => 3000,
						'step'  => 1,
					],
				],
				'frontend_available' => true,
				'condition'             => [
					'layout' => 'horizontal',
				],
			]
		);

		$this->add_control(
			'infinite_loop',
			[
				'label'              => esc_html__( 'Infinite Loop', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'layout' => 'horizontal',
				],
			]
		);

		$this->add_control(
			'center_mode',
			[
				'label'              => esc_html__( 'Center Mode', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => '',
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'layout'        => 'horizontal',
					'infinite_loop' => 'yes',
				],
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'              => esc_html__( 'Autoplay', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'layout' => 'horizontal',
				],
			]
		);

		$this->add_control(
			'autoplay_speed',
			[
				'label'              => esc_html__( 'Autoplay Speed', 'powerpack' ),
				'type'               => Controls_Manager::NUMBER,
				'default'            => 3000,
				'frontend_available' => true,
				'condition'          => [
					'layout'   => 'horizontal',
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'pause_on_hover',
			[
				'label'              => esc_html__( 'Pause on Hover', 'powerpack' ),
				'description'        => '',
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'layout'   => 'horizontal',
					'autoplay' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Content Tab: Timeline
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_content_timeline_items_controls() {
		$this->start_controls_section(
			'section_timeline_items',
			[
				'label'     => esc_html__( 'Timeline', 'powerpack' ),
				'condition' => [
					'source' => 'custom',
				],
			]
		);

		$repeater = new Repeater();

		$repeater->start_controls_tabs( 'timeline_items_tabs' );

		$repeater->start_controls_tab( 'tab_timeline_items_content', [ 'label' => esc_html__( 'Content', 'powerpack' ) ] );

			$repeater->add_control(
				'timeline_item_date',
				[
					'label'       => esc_html__( 'Date', 'powerpack' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => false,
					'default'     => esc_html__( '1 June 2018', 'powerpack' ),
					'dynamic'     => [
						'active' => true,
					],
					'ai'          => [
						'active' => false,
					],
				]
			);

			$repeater->add_control(
				'timeline_item_title',
				[
					'label'       => esc_html__( 'Title', 'powerpack' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => false,
					'default'     => '',
					'dynamic'     => [
						'active' => true,
					],
				]
			);

			$repeater->add_control(
				'timeline_item_content',
				[
					'label'   => esc_html__( 'Content', 'powerpack' ),
					'type'    => Controls_Manager::WYSIWYG,
					'default' => '',
					'dynamic' => [
						'active' => true,
					],
				]
			);

			$repeater->add_control(
				'timeline_item_link',
				[
					'label'       => esc_html__( 'Link', 'powerpack' ),
					'type'        => Controls_Manager::URL,
					'dynamic'     => [
						'active'     => true,
						'categories' => [
							TagsModule::POST_META_CATEGORY,
							TagsModule::URL_CATEGORY,
						],
					],
					'placeholder' => 'https://www.your-link.com',
					'default'     => [
						'url' => '',
					],
				]
			);

			$repeater->add_control(
				'single_marker_side',
				[
					'label'     => esc_html__( 'Direction', 'powerpack' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						''      => esc_html__( 'Default', 'powerpack' ),
						'left'  => esc_html__( 'Left', 'powerpack' ),
						'right' => esc_html__( 'Right', 'powerpack' ),
					],
					'default'   => '',
				]
			);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab( 'tab_timeline_items_image', [ 'label' => esc_html__( 'Media', 'powerpack' ) ] );

		$repeater->add_control(
			'card_image',
			[
				'label'        => esc_html__( 'Show Media', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$repeater->add_control(
			'media_type',
			[
				'label'     => esc_html__( 'Media Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'image',
				'options'   => [
					'image' => esc_html__( 'Image', 'powerpack' ),
					'video' => esc_html__( 'Video', 'powerpack' ),
				],
				'condition' => [
					'card_image' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'      => esc_html__( 'Choose Image', 'powerpack' ),
				'type'       => Controls_Manager::MEDIA,
				'default'    => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'dynamic'    => [
					'active' => true,
				],
				'conditions' => [
					'terms' => [
						[
							'name'     => 'card_image',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'media_type',
							'operator' => '==',
							'value'    => 'image',
						],
					],
				],
			]
		);

		$repeater->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'       => 'image',
				'exclude'    => [ 'custom' ],
				'include'    => [],
				'default'    => 'large',
				'conditions' => [
					'terms' => [
						[
							'name'     => 'card_image',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'media_type',
							'operator' => '==',
							'value'    => 'image',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'video_source',
			[
				'label'      => esc_html__( 'Video Source', 'powerpack' ),
				'type'       => Controls_Manager::SELECT,
				'default'    => 'youtube',
				'options'    => [
					'youtube'     => esc_html__( 'YouTube', 'powerpack' ),
					'vimeo'       => esc_html__( 'Vimeo', 'powerpack' ),
					'dailymotion' => esc_html__( 'Dailymotion', 'powerpack' ),
					'hosted'      => esc_html__( 'Self Hosted', 'powerpack' ),
				],
				'conditions' => [
					'terms' => [
						[
							'name'     => 'card_image',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'media_type',
							'operator' => '==',
							'value'    => 'video',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'youtube_url',
			[
				'label'       => esc_html__( 'URL', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder' => esc_html__( 'Enter your YouTube URL', 'powerpack' ),
				'label_block' => true,
				'conditions'  => [
					'terms' => [
						[
							'name'     => 'card_image',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'media_type',
							'operator' => '==',
							'value'    => 'video',
						],
						[
							'name'     => 'video_source',
							'operator' => '==',
							'value'    => 'youtube',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'vimeo_url',
			[
				'label'       => esc_html__( 'URL', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder' => esc_html__( 'Enter your Vimeo URL', 'powerpack' ),
				'label_block' => true,
				'conditions'  => [
					'terms' => [
						[
							'name'     => 'card_image',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'media_type',
							'operator' => '==',
							'value'    => 'video',
						],
						[
							'name'     => 'video_source',
							'operator' => '==',
							'value'    => 'vimeo',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'dailymotion_url',
			[
				'label'       => esc_html__( 'URL', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder' => esc_html__( 'Enter your Dailymotion URL', 'powerpack' ),
				'label_block' => true,
				'conditions'  => [
					'terms' => [
						[
							'name'     => 'card_image',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'media_type',
							'operator' => '==',
							'value'    => 'video',
						],
						[
							'name'     => 'video_source',
							'operator' => '==',
							'value'    => 'dailymotion',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'insert_url',
			[
				'label'      => esc_html__( 'External URL', 'powerpack' ),
				'type'       => Controls_Manager::SWITCHER,
				'conditions' => [
					'terms' => [
						[
							'name'     => 'card_image',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'media_type',
							'operator' => '==',
							'value'    => 'video',
						],
						[
							'name'     => 'video_source',
							'operator' => '==',
							'value'    => 'hosted',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'hosted_url',
			[
				'label'      => esc_html__( 'Choose File', 'powerpack' ),
				'type'       => Controls_Manager::MEDIA,
				'dynamic'    => [
					'active'     => true,
					'categories' => [
						TagsModule::MEDIA_CATEGORY,
					],
				],
				'media_type' => 'video',
				'conditions' => [
					'terms' => [
						[
							'name'     => 'card_image',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'media_type',
							'operator' => '==',
							'value'    => 'video',
						],
						[
							'name'     => 'video_source',
							'operator' => '==',
							'value'    => 'hosted',
						],
						[
							'name'     => 'insert_url',
							'operator' => '!=',
							'value'    => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'external_url',
			[
				'label'        => esc_html__( 'URL', 'powerpack' ),
				'type'         => Controls_Manager::URL,
				'autocomplete' => false,
				'options'      => false,
				'label_block'  => true,
				'show_label'   => false,
				'dynamic'      => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'media_type'   => 'video',
				'placeholder'  => esc_html__( 'Enter your URL', 'powerpack' ),
				'conditions'   => [
					'terms' => [
						[
							'name'     => 'card_image',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'media_type',
							'operator' => '==',
							'value'    => 'video',
						],
						[
							'name'     => 'video_source',
							'operator' => '==',
							'value'    => 'hosted',
						],
						[
							'name'     => 'insert_url',
							'operator' => '==',
							'value'    => 'yes',
						],
					],
				],
			]
		);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab( 'tab_timeline_items_style', [ 'label' => esc_html__( 'Style', 'powerpack' ) ] );

		$repeater->add_control(
			'custom_style',
			[
				'label'        => esc_html__( 'Custom Style', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$repeater->add_control(
			'single_heading_marker',
			[
				'label'     => esc_html__( 'Marker', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => [
					'custom_style' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'single_marker_type',
			[
				'label'     => esc_html__( 'Marker Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'global' => esc_html__( 'Global', 'powerpack' ),
					'none'   => esc_html__( 'None', 'powerpack' ),
					'icon'   => esc_html__( 'Icon', 'powerpack' ),
					'image'  => esc_html__( 'Image', 'powerpack' ),
					'text'   => esc_html__( 'Text', 'powerpack' ),
				],
				'default'   => 'global',
				'condition' => [
					'custom_style' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'marker_icon_single',
			[
				'label'            => esc_html__( 'Choose Icon', 'powerpack' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'single_marker_icon',
				'default'          => [
					'value'   => 'fas fa-calendar',
					'library' => 'fa-solid',
				],
				'condition'        => [
					'custom_style'       => 'yes',
					'single_marker_type' => 'icon',
				],
			]
		);

		$repeater->add_control(
			'single_marker_icon_image',
			[
				'label'     => esc_html__( 'Choose Image', 'powerpack' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'custom_style'       => 'yes',
					'single_marker_type' => 'image',
				],
			]
		);

		$repeater->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'single_marker_icon_image',
				'include'   => [],
				'default'   => 'large',
				'condition' => [
					'custom_style'       => 'yes',
					'single_marker_type' => 'image',
				],
			]
		);

		$repeater->add_control(
			'single_marker_text',
			[
				'label'     => esc_html__( 'Enter Marker Text', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => [
					'custom_style'       => 'yes',
					'single_marker_type' => 'text',
				],
			]
		);

		$repeater->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'single_marker_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .pp-timeline-marker',
				'condition' => [
					'custom_style'       => 'yes',
					'single_marker_type' => 'text',
				],
			]
		);

		$repeater->add_control(
			'single_marker_color',
			[
				'label'      => esc_html__( 'Marker Color', 'powerpack' ),
				'type'       => Controls_Manager::COLOR,
				'default'    => '',
				'selectors'  => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .pp-timeline-marker' => 'color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .pp-timeline-marker svg' => 'fill: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'     => 'custom_style',
							'operator' => '==',
							'value'    => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'single_marker_bg_color',
			[
				'label'      => esc_html__( 'Background Color', 'powerpack' ),
				'type'       => Controls_Manager::COLOR,
				'default'    => '',
				'selectors'  => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .pp-timeline-marker' => 'background-color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'     => 'custom_style',
							'operator' => '==',
							'value'    => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'single_heading_card',
			[
				'label'     => esc_html__( 'Card', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'custom_style' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'single_card_background_color',
			[
				'label'      => esc_html__( 'Background Color', 'powerpack' ),
				'type'       => Controls_Manager::COLOR,
				'default'    => '',
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline {{CURRENT_ITEM}} .pp-timeline-card' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .pp-timeline {{CURRENT_ITEM}} .pp-timeline-arrow' => 'color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'     => 'custom_style',
							'operator' => '==',
							'value'    => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'single_card_border_color',
			[
				'label'      => esc_html__( 'Border Color', 'powerpack' ),
				'type'       => Controls_Manager::COLOR,
				'default'    => '',
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline {{CURRENT_ITEM}} .pp-timeline-card' => 'border-color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'     => 'custom_style',
							'operator' => '==',
							'value'    => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'single_heading_title',
			[
				'label'     => esc_html__( 'Content', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'custom_style' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'single_title_color',
			[
				'label'      => esc_html__( 'Title Color', 'powerpack' ),
				'type'       => Controls_Manager::COLOR,
				'default'    => '',
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline {{CURRENT_ITEM}} .pp-timeline-card-title' => 'color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'     => 'custom_style',
							'operator' => '==',
							'value'    => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'single_content_color',
			[
				'label'      => esc_html__( 'Content Color', 'powerpack' ),
				'type'       => Controls_Manager::COLOR,
				'default'    => '',
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline {{CURRENT_ITEM}} .pp-timeline-card-content' => 'color: {{VALUE}}',
				],
				'separator'  => 'after',
				'conditions' => [
					'terms' => [
						[
							'name'     => 'custom_style',
							'operator' => '==',
							'value'    => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'timeline_item_css_classes',
			[
				'label'     => esc_html__( 'CSS Classes', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'ai'        => [
					'active' => false,
				],
			]
		);

		$repeater->end_controls_tab();

		$repeater->end_controls_tabs();

		$this->add_control(
			'items',
			[
				'label'       => '',
				'type'        => Controls_Manager::REPEATER,
				'default'     => [
					[
						'timeline_item_date'    => esc_html__( '1 May 2018', 'powerpack' ),
						'timeline_item_title'   => esc_html__( 'Timeline Item 1', 'powerpack' ),
						'timeline_item_content' => esc_html__( 'I am timeline item content. Click here to edit this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'powerpack' ),
					],
					[
						'timeline_item_date'    => esc_html__( '1 June 2018', 'powerpack' ),
						'timeline_item_title'   => esc_html__( 'Timeline Item 2', 'powerpack' ),
						'timeline_item_content' => esc_html__( 'I am timeline item content. Click here to edit this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'powerpack' ),
					],
					[
						'timeline_item_date'    => esc_html__( '1 July 2018', 'powerpack' ),
						'timeline_item_title'   => esc_html__( 'Timeline Item 3', 'powerpack' ),
						'timeline_item_content' => esc_html__( 'I am timeline item content. Click here to edit this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'powerpack' ),
					],
					[
						'timeline_item_date'    => esc_html__( '1 August 2018', 'powerpack' ),
						'timeline_item_title'   => esc_html__( 'Timeline Item 4', 'powerpack' ),
						'timeline_item_content' => esc_html__( 'I am timeline item content. Click here to edit this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'powerpack' ),
					],
				],
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ timeline_item_date }}}',
				'condition'   => [
					'source' => 'custom',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Content Tab: Posts
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_content_posts_controls() {
		$this->start_controls_section(
			'section_posts',
			[
				'label'     => esc_html__( 'Posts', 'powerpack' ),
				'condition' => [
					'source' => 'posts',
				],
			]
		);

		$this->add_control(
			'post_title',
			[
				'label'        => esc_html__( 'Post Title', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'show',
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'show',
				'condition'    => [
					'source' => 'posts',
				],
			]
		);

		$this->add_control(
			'post_image',
			[
				'label'        => esc_html__( 'Post Media', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'show',
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'show',
				'condition'    => [
					'source' => 'posts',
				],
			]
		);

		$this->add_control(
			'post_media_type',
			[
				'label'     => esc_html__( 'Media Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'image',
				'options'   => [
					'image' => esc_html__( 'Image', 'powerpack' ),
					'video' => esc_html__( 'Video', 'powerpack' ),
				],
				'condition' => [
					'source'     => 'posts',
					'post_image' => 'show',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'image_size',
				'label'     => esc_html__( 'Image Size', 'powerpack' ),
				'default'   => 'medium_large',
				'condition' => [
					'source'          => 'posts',
					'post_image'      => 'show',
					'post_media_type' => 'image',
				],
			]
		);

		$this->add_control(
			'post_video_source',
			[
				'label'     => esc_html__( 'Video Source', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'youtube',
				'options'   => [
					'youtube'     => esc_html__( 'YouTube', 'powerpack' ),
					'vimeo'       => esc_html__( 'Vimeo', 'powerpack' ),
					'dailymotion' => esc_html__( 'Dailymotion', 'powerpack' ),
					'hosted'      => esc_html__( 'Self Hosted', 'powerpack' ),
				],
				'condition' => [
					'source'          => 'posts',
					'post_image'      => 'show',
					'post_media_type' => 'video',
				],
			]
		);

		$this->add_control(
			'post_video_field',
			[
				'label'       => esc_html__( 'Video URL Custom Field', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'description' => esc_html__( 'Enter the meta key of the custom field that stores the video URL (or file URL for self hosted) on each post.', 'powerpack' ),
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'condition'   => [
					'source'          => 'posts',
					'post_image'      => 'show',
					'post_media_type' => 'video',
				],
			]
		);

		$this->add_control(
			'post_content',
			[
				'label'        => esc_html__( 'Post Content', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'show',
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'show',
				'condition'    => [
					'source' => 'posts',
				],
			]
		);

		$this->add_control(
			'content_type',
			[
				'label'     => esc_html__( 'Content Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'excerpt'         => esc_html__( 'Excerpt', 'powerpack' ),
					'limited-content' => esc_html__( 'Limited Content', 'powerpack' ),
				],
				'default'   => 'excerpt',
				'condition' => [
					'source'       => 'posts',
					'post_content' => 'show',
				],
			]
		);

		$this->add_control(
			'content_length',
			[
				'label'     => esc_html__( 'Content Limit', 'powerpack' ),
				'title'     => esc_html__( 'Words', 'powerpack' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 40,
				'min'       => 0,
				'step'      => 1,
				'condition' => [
					'source'       => 'posts',
					'post_content' => 'show',
					'content_type' => 'limited-content',
				],
			]
		);

		$this->add_control(
			'link_type',
			[
				'label'     => esc_html__( 'Link Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''       => esc_html__( 'None', 'powerpack' ),
					'title'  => esc_html__( 'Title', 'powerpack' ),
					'button' => esc_html__( 'Button', 'powerpack' ),
					'card'   => esc_html__( 'Card', 'powerpack' ),
				],
				'default'   => 'title',
				'condition' => [
					'source' => 'posts',
				],
			]
		);

		$this->add_control(
			'posts_link_to',
			[
				'label'     => esc_html__( 'Link to', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'post_url',
				'options'   => [
					'post_url'  => esc_html__( 'Post URL', 'powerpack' ),
					'custom'    => esc_html__( 'Custom URL', 'powerpack' ),
				],
				'condition' => [
					'source' => 'posts',
				],
			]
		);

		$this->add_control(
			'posts_link',
			[
				'label'       => esc_html__( 'Link', 'powerpack' ),
				'show_label'  => false,
				'type'        => Controls_Manager::URL,
				'dynamic'     => [
					'active'  => true,
				],
				'condition'   => [
					'source'        => 'posts',
					'posts_link_to' => 'custom',
				],
			]
		);

		$this->add_control(
			'button_text',
			[
				'label'       => esc_html__( 'Button Text', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => false,
				'default'     => esc_html__( 'Read More', 'powerpack' ),
				'condition'   => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_control(
			'post_meta',
			[
				'label'        => esc_html__( 'Post Meta', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'show',
				'condition'    => [
					'source' => 'posts',
				],
			]
		);

		$this->add_control(
			'meta_items_divider',
			[
				'label'     => esc_html__( 'Meta Items Divider', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => '-',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-meta > span:not(:last-child):after, {{WRAPPER}} .pp-timeline-category .pp-post-term:not(:last-child):after' => 'content: "{{UNIT}}";',
				],
				'ai'        => [
					'active' => false,
				],
				'condition' => [
					'source'    => 'posts',
					'post_meta' => 'show',
				],
			]
		);

		$this->add_control(
			'post_author',
			[
				'label'        => esc_html__( 'Post Author', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'show',
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'show',
				'condition'    => [
					'source'    => 'posts',
					'post_meta' => 'show',
				],
			]
		);

		$this->add_control(
			'post_category',
			[
				'label'        => esc_html__( 'Post Terms', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'show',
				'condition'    => [
					'source'    => 'posts',
					'post_meta' => 'show',
				],
			]
		);

		$post_types = PP_Posts_Helper::get_post_types();

		foreach ( $post_types as $post_type_slug => $post_type_label ) {

			$taxonomy = PP_Posts_Helper::get_post_taxonomies( $post_type_slug );

			if ( ! empty( $taxonomy ) ) {

				$related_tax = [];

				// Only the labels are needed here — do not query the terms.
				foreach ( $taxonomy as $index => $tax ) {
					$related_tax[ $index ] = $tax->label;
				}

				// Add control for all taxonomies.
				$this->add_control(
					'tax_badge_' . $post_type_slug,
					[
						'label'       => esc_html__( 'Select Taxonomy', 'powerpack' ),
						'type'        => Controls_Manager::SELECT2,
						'label_block' => true,
						'options'     => $related_tax,
						'multiple'    => true,
						// A multiple SELECT2 stores an array; the default has to be one too.
						'default'     => [ array_keys( $related_tax )[0] ],
						'condition'   => [
							'source'        => 'posts',
							'post_type'     => $post_type_slug,
							'post_meta'     => 'show',
							'post_category' => 'show',
						],
					]
				);
			}
		}

		/**
		 * @since 2.13.2
		 */
		$this->add_control(
			'max_terms',
			[
				'label'       => esc_html__( 'Max Terms', 'powerpack' ),
				'description' => esc_html__( 'Maximum number of terms to display per post. Set to 0 to show all selected terms.', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 1,
				'min'         => 0,
				'condition'   => [
					'source'        => 'posts',
					'post_meta'     => 'show',
					'post_category' => 'show',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Content Tab: Pagination
	 *
	 * @since 2.13.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_pagination_controls() {
		$this->start_controls_section(
			'section_pagination',
			[
				'label'     => esc_html__( 'Pagination', 'powerpack' ),
				'condition' => [
					'source' => 'posts',
				],
			]
		);

		$this->add_control(
			'pagination_type',
			[
				'label'     => esc_html__( 'Pagination', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'none',
				'options'   => [
					'none'                  => esc_html__( 'None', 'powerpack' ),
					'numbers'               => esc_html__( 'Numbers', 'powerpack' ),
					'numbers_and_prev_next' => esc_html__( 'Numbers', 'powerpack' ) . ' + ' . esc_html__( 'Previous/Next', 'powerpack' ),
					'load_more'             => esc_html__( 'Load More Button', 'powerpack' ),
					'infinite'              => esc_html__( 'Infinite', 'powerpack' ),
				],
				'condition' => [
					'source' => 'posts',
				],
			]
		);

		$this->add_control(
			'pagination_note',
			[
				'label'           => '',
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'Load more and Infinite pagination does not work with Main Query.', 'powerpack' ),
				'content_classes' => 'pp-editor-info',
				'condition'       => [
					'source'          => 'posts',
					'layout!'         => 'horizontal',
					'pagination_type' => [ 'load_more', 'infinite' ],
					'query_type'      => 'main',
				],
			]
		);

		$this->add_control(
			'pagination_ajax',
			[
				'label'     => esc_html__( 'Ajax Pagination', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => [
					'source'          => 'posts',
					'layout!'         => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', ],
					'query_type!'     => 'main',
				],
			]
		);

		$this->add_control(
			'pagination_page_limit',
			[
				'label'     => esc_html__( 'Page Limit', 'powerpack' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 5,
				'condition' => [
					'source'          => 'posts',
					'layout!'         => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', ],
				],
			]
		);

		$this->add_control(
			'pagination_numbers_shorten',
			[
				'label'     => esc_html__( 'Shorten', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => '',
				'condition' => [
					'source'          => 'posts',
					'layout!'         => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', ],
				],
			]
		);

		$this->add_control(
			'pagination_load_more_label',
			[
				'label'     => esc_html__( 'Button Label', 'powerpack' ),
				'default'   => esc_html__( 'Load More', 'powerpack' ),
				'condition' => [
					'source'          => 'posts',
					'layout!'         => 'horizontal',
					'pagination_type' => 'load_more',
				],
			]
		);

		$this->add_control(
			'select_pagination_load_more_button_icon',
			[
				'label'            => esc_html__( 'Button Icon', 'powerpack' ),
				'type'             => Controls_Manager::ICONS,
				'label_block'      => false,
				'skin'             => 'inline',
				'fa4compatibility' => 'pagination_load_more_button_icon',
				'condition'        => [
					'source'          => 'posts',
					'layout!'         => 'horizontal',
					'pagination_type' => 'load_more',
				],
			]
		);

		$this->add_control(
			'pagination_load_more_button_icon_position',
			[
				'label'                => esc_html__( 'Icon Position', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => is_rtl() ? 'before' : 'after',
				'options'              => [
					'after'  => esc_html__( 'After', 'powerpack' ),
					'before' => esc_html__( 'Before', 'powerpack' ),
				],
				'selectors_dictionary' => [
					'before' => is_rtl() ? 'row' : 'row-reverse',
					'after'  => is_rtl() ? 'row-reverse' : 'row',
				],
				'selectors'            => [
					'{{WRAPPER}} .pp-post-load-more-wrap .elementor-button-content-wrapper' => 'flex-direction: {{VALUE}};',
				],
				'condition'            => [
					'source'          => 'posts',
					'layout!'         => 'horizontal',
					'pagination_type' => 'load_more',
					'select_pagination_load_more_button_icon[value]!' => '',
				],
			]
		);

		$this->add_control(
			'pagination_prev_label',
			[
				'label'     => esc_html__( 'Previous Label', 'powerpack' ),
				'default'   => esc_html__( '&laquo; Previous', 'powerpack' ),
				'condition' => [
					'source'          => 'posts',
					'layout!'         => 'horizontal',
					'pagination_type' => 'numbers_and_prev_next',
				],
			]
		);

		$this->add_control(
			'pagination_next_label',
			[
				'label'     => esc_html__( 'Next Label', 'powerpack' ),
				'default'   => esc_html__( 'Next &raquo;', 'powerpack' ),
				'condition' => [
					'source'          => 'posts',
					'layout!'         => 'horizontal',
					'pagination_type' => 'numbers_and_prev_next',
				],
			]
		);

		$this->add_control(
			'pagination_align',
			[
				'label'     => esc_html__( 'Alignment', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-pagination-wrap' => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'source'           => 'posts',
					'layout!'          => 'horizontal',
					'pagination_type!' => 'none',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Layout
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_layout_controls() {
		$this->start_controls_section(
			'section_layout_style',
			[
				'label' => esc_html__( 'Layout', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'direction',
			[
				'label'              => esc_html__( 'Direction', 'powerpack' ),
				'type'               => Controls_Manager::CHOOSE,
				'toggle'             => true,
				'default'            => 'center',
				'tablet_default'     => 'left',
				'mobile_default'     => 'left',
				'options'            => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'frontend_available' => true,
				'condition'          => [
					'layout' => 'vertical',
				],
			]
		);

		$this->add_control(
			'cards_arrows_alignment',
			[
				'label'       => esc_html__( 'Arrows Alignment', 'powerpack' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'     => [
					'top'    => [
						'title' => esc_html__( 'Top', 'powerpack' ),
						'icon'  => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_html__( 'Middle', 'powerpack' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_html__( 'Bottom', 'powerpack' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'default'     => 'top',
				'condition'   => [
					'layout' => 'vertical',
				],
			]
		);

		$this->add_responsive_control(
			'items_spacing',
			[
				'label'              => esc_html__( 'Items Spacing', 'powerpack' ),
				'type'               => Controls_Manager::SLIDER,
				'size_units'         => [ 'px', 'em', 'rem', 'custom' ],
				'default'            => [
					'size' => '',
				],
				'range'              => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'frontend_available' => true,
				'render_type'        => 'template',
				'selectors'          => [
					'{{WRAPPER}} .pp-timeline-vertical .pp-timeline-item:not(:last-child)' => 'margin-bottom: {{SIZE}}px;',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Cards
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_cards_controls() {
		$this->start_controls_section(
			'section_cards_style',
			[
				'label' => esc_html__( 'Cards', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'cards_padding',
			[
				'label'      => esc_html__( 'Cards Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => esc_html__( 'Content Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-card-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'cards_text_align',
			[
				'label'     => esc_html__( 'Text Align', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'left',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-card' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( 'card_tabs' );

		$this->start_controls_tab( 'tab_card_normal', [ 'label' => esc_html__( 'Normal', 'powerpack' ) ] );

		$this->add_control(
			'cards_bg',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-card' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .pp-timeline .pp-timeline-arrow' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'cards_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-timeline .pp-timeline-card',
			]
		);

		$this->add_responsive_control(
			'cards_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'cards_box_shadow',
			[
				'label'        => esc_html__( 'Box Shadow', 'powerpack' ),
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label_off'    => esc_html__( 'Default', 'powerpack' ),
				'label_on'     => esc_html__( 'Custom', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->start_popover();

			$this->add_control(
				'cards_box_shadow_color',
				[
					'label'     => esc_html__( 'Color', 'powerpack' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => 'rgba(0,0,0,0.5)',
					'selectors' => [
						'{{WRAPPER}} .pp-timeline-card-wrapper' => 'filter: drop-shadow({{cards_box_shadow_horizontal.SIZE}}px {{cards_box_shadow_vertical.SIZE}}px {{cards_box_shadow_blur.SIZE}}px {{VALUE}}); -webkit-filter: drop-shadow({{cards_box_shadow_horizontal.SIZE}}px {{cards_box_shadow_vertical.SIZE}}px {{cards_box_shadow_blur.SIZE}}px {{VALUE}});',
					],
					'condition' => [
						'cards_box_shadow' => 'yes',
					],
				]
			);

			$this->add_control(
				'cards_box_shadow_horizontal',
				[
					'label'     => esc_html__( 'Horizontal', 'powerpack' ),
					'type'      => Controls_Manager::SLIDER,
					'default'   => [
						'size' => 0,
						'unit' => 'px',
					],
					'range'     => [
						'px' => [
							'min'  => -100,
							'max'  => 100,
							'step' => 1,
						],
					],
					'condition' => [
						'cards_box_shadow' => 'yes',
					],
				]
			);

			$this->add_control(
				'cards_box_shadow_vertical',
				[
					'label'     => esc_html__( 'Vertical', 'powerpack' ),
					'type'      => Controls_Manager::SLIDER,
					'default'   => [
						'size' => 0,
						'unit' => 'px',
					],
					'range'     => [
						'px' => [
							'min'  => -100,
							'max'  => 100,
							'step' => 1,
						],
					],
					'condition' => [
						'cards_box_shadow' => 'yes',
					],
				]
			);

			$this->add_control(
				'cards_box_shadow_blur',
				[
					'label'     => esc_html__( 'Blur', 'powerpack' ),
					'type'      => Controls_Manager::SLIDER,
					'default'   => [
						'size' => 4,
						'unit' => 'px',
					],
					'range'     => [
						'px' => [
							'min'  => 1,
							'max'  => 10,
							'step' => 1,
						],
					],
					'condition' => [
						'cards_box_shadow' => 'yes',
					],
				]
			);

		$this->end_popover();

		$this->add_control(
			'heading_image',
			[
				'label'     => esc_html__( 'Image', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'label'      => esc_html__( 'Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [
					'unit' => '%',
				],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vw' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-card-image img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_max_width',
			[
				'label'      => esc_html__( 'Max Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [
					'unit' => '%',
				],
				'range'      => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vw' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-card-image img' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_height',
			[
				'label'      => esc_html__( 'Height', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vh', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 1,
						'max' => 500,
					],
					'vh' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-card-image img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_object_fit',
			[
				'label'     => esc_html__( 'Object Fit', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''        => esc_html__( 'Default', 'powerpack' ),
					'fill'    => esc_html__( 'Fill', 'powerpack' ),
					'cover'   => esc_html__( 'Cover', 'powerpack' ),
					'contain' => esc_html__( 'Contain', 'powerpack' ),
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-card-image img' => 'object-fit: {{VALUE}};',
				],
				'condition' => [
					'image_height[size]!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'image_object_position',
			[
				'label'     => esc_html__( 'Object Position', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'center center' => esc_html__( 'Center Center', 'powerpack' ),
					'center left'   => esc_html__( 'Center Left', 'powerpack' ),
					'center right'  => esc_html__( 'Center Right', 'powerpack' ),
					'top center'    => esc_html__( 'Top Center', 'powerpack' ),
					'top left'      => esc_html__( 'Top Left', 'powerpack' ),
					'top right'     => esc_html__( 'Top Right', 'powerpack' ),
					'bottom center' => esc_html__( 'Bottom Center', 'powerpack' ),
					'bottom left'   => esc_html__( 'Bottom Left', 'powerpack' ),
					'bottom right'  => esc_html__( 'Bottom Right', 'powerpack' ),
				],
				'default'   => 'center center',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-card-image img' => 'object-position: {{VALUE}};',
				],
				'condition' => [
					'image_height[size]!' => '',
					'image_object_fit' => 'cover',
				],
			]
		);

		$this->add_responsive_control(
			'image_align',
			[
				'label' => esc_html__( 'Alignment', 'powerpack' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-card-image' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'image_border',
				'label'    => esc_html__( 'Border', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-timeline-card-image img',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'image_box_shadow',
				'selector' => '{{WRAPPER}} .pp-timeline-card-image img',
			]
		);

		$this->add_responsive_control(
			'image_margin_bottom',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 20,
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-card-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_title',
			[
				'label'     => esc_html__( 'Title', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_bg',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-card-title-wrap' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'title_text_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-card-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-timeline-card-title',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'title_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-timeline .pp-timeline-card-title-wrap',
			]
		);

		$this->add_responsive_control(
			'title_margin_bottom',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-card-title-wrap' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_padding',
			[
				'label'      => esc_html__( 'Title Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-card-title-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_content',
			[
				'label'     => esc_html__( 'Content', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'card_text_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-card' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'card_text_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-timeline-card',
			]
		);

		$this->add_control(
			'meta_content',
			[
				'label'     => esc_html__( 'Post Meta', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'source'    => 'posts',
					'post_meta' => 'show',
				],
			]
		);

		$this->add_control(
			'meta_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-meta' => 'color: {{VALUE}}',
				],
				'condition' => [
					'source'    => 'posts',
					'post_meta' => 'show',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'meta_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-timeline-meta',
				'condition' => [
					'source'    => 'posts',
					'post_meta' => 'show',
				],
			]
		);

		$this->add_responsive_control(
			'meta_items_gap',
			[
				'label'      => esc_html__( 'Meta Items Gap', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 10,
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 60,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-meta > span:not(:last-child)' => 'margin-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pp-timeline-meta > span:not(:last-child):after' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'source'    => 'posts',
					'post_meta' => 'show',
				],
			]
		);

		$this->add_responsive_control(
			'meta_margin_bottom',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 20,
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 60,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-meta' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'source'    => 'posts',
					'post_meta' => 'show',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'tab_card_hover', [ 'label' => esc_html__( 'Hover', 'powerpack' ) ] );

		$this->add_control(
			'card_bg_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-item:hover .pp-timeline-card' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .pp-timeline .pp-timeline-item:hover .pp-timeline-arrow' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'title_bg_hover',
			[
				'label'     => esc_html__( 'Title Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-item:hover .pp-timeline-card-title-wrap' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_title_color_hover',
			[
				'label'     => esc_html__( 'Title Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-item:hover .pp-timeline-card-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_title_border_color_hover',
			[
				'label'     => esc_html__( 'Title Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-item:hover .pp-timeline-card-title-wrap' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_color_hover',
			[
				'label'     => esc_html__( 'Content Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-item:hover .pp-timeline-card' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-item:hover .pp-timeline-card' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'tab_card_focused', [ 'label' => esc_html__( 'Focused', 'powerpack' ) ] );

		$this->add_control(
			'card_bg_focused',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-item-active .pp-timeline-card, {{WRAPPER}} .pp-timeline .swiper-slide-active .pp-timeline-card' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .pp-timeline .pp-timeline-item-active .pp-timeline-arrow, {{WRAPPER}} .pp-timeline .swiper-slide-active .pp-timeline-arrow' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'title_bg_focused',
			[
				'label'     => esc_html__( 'Title Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-item-active .pp-timeline-card-title-wrap, {{WRAPPER}} .pp-timeline .swiper-slide-active .pp-timeline-card-title-wrap' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_title_color_focused',
			[
				'label'     => esc_html__( 'Title Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-item-active .pp-timeline-card-title, {{WRAPPER}} .pp-timeline .swiper-slide-active .pp-timeline-card-title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_title_border_color_focused',
			[
				'label'     => esc_html__( 'Title Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-item-active .pp-timeline-card-title-wrap, {{WRAPPER}} .pp-timeline .swiper-slide-active .pp-timeline-card-title-wrap' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_color_focused',
			[
				'label'     => esc_html__( 'Content Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-item-active .pp-timeline-card, {{WRAPPER}} .pp-timeline .swiper-slide-active .pp-timeline-card' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'card_border_color_focused',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline .pp-timeline-item-active .pp-timeline-card, {{WRAPPER}} .pp-timeline .swiper-slide-active .pp-timeline-card' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Marker
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_marker_controls() {
		$this->start_controls_section(
			'section_marker_style',
			[
				'label' => esc_html__( 'Marker', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'marker_type',
			[
				'label'       => esc_html__( 'Type', 'powerpack' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'toggle'      => false,
				'options'     => [
					'none'   => [
						'title' => esc_html__( 'None', 'powerpack' ),
						'icon'  => 'eicon-ban',
					],
					'icon'   => [
						'title' => esc_html__( 'Icon', 'powerpack' ),
						'icon'  => 'eicon-star',
					],
					'image'  => [
						'title' => esc_html__( 'Icon Image', 'powerpack' ),
						'icon'  => 'eicon-image-bold',
					],
					'number' => [
						'title' => esc_html__( 'Number', 'powerpack' ),
						'icon'  => 'eicon-number-field',
					],
					'letter' => [
						'title' => esc_html__( 'Letter', 'powerpack' ),
						'icon'  => 'eicon-t-letter-bold',
					],
				],
				'default'     => 'icon',
			]
		);

		$this->add_control(
			'select_marker_icon',
			[
				'label'            => esc_html__( 'Choose Icon', 'powerpack' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'marker_icon',
				'default'          => [
					'value'   => 'fas fa-calendar',
					'library' => 'fa-solid',
				],
				'condition'        => [
					'marker_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'icon_image',
			[
				'label'     => esc_html__( 'Choose Icon Image', 'powerpack' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'marker_type' => 'image',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'icon_image',
				'include'   => [],
				'default'   => 'large',
				'condition' => [
					'marker_type' => 'image',
				],
			]
		);

		$this->add_responsive_control(
			'marker_size',
			[
				'label'      => esc_html__( 'Marker Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 5,
						'max'  => 150,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-marker'     => 'font-size: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .pp-timeline-marker img' => 'width: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'marker_type!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'marker_box_size',
			[
				'label'      => esc_html__( 'Marker Box Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 10,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-marker' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .pp-timeline-connector-wrap' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pp-timeline-navigation:before, {{WRAPPER}} .pp-timeline-navigation-wrap .pp-slider-arrow' => 'bottom: calc( {{SIZE}}{{UNIT}}/2 );',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'marker_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-timeline-marker',
				'condition' => [
					'marker_type' => [ 'number', 'letter' ],
				],
			]
		);

		$this->start_controls_tabs( 'marker_tabs' );

		$this->start_controls_tab( 'tab_marker_normal', [ 'label' => esc_html__( 'Normal', 'powerpack' ) ] );

		$this->add_control(
			'marker_color',
			[
				'label'     => esc_html__( 'Marker Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-marker'     => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-timeline-marker svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'marker_bg',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-marker' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'marker_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-timeline-marker',
			]
		);

		$this->add_responsive_control(
			'marker_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-marker' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'marker_box_shadow',
				'selector' => '{{WRAPPER}} .pp-timeline-marker',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'tab_marker_hover', [ 'label' => esc_html__( 'Hover', 'powerpack' ) ] );

		$this->add_control(
			'marker_color_hover',
			[
				'label'     => esc_html__( 'Marker Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-item:hover .pp-timeline-marker, {{WRAPPER}} .pp-timeline-marker-wrapper:hover .pp-timeline-marker' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-timeline-item:hover .pp-timeline-marker svg, {{WRAPPER}} .pp-timeline-marker-wrapper:hover .pp-timeline-marker svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'marker_bg_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-item:hover .pp-timeline-marker, {{WRAPPER}} .pp-timeline-marker-wrapper:hover .pp-timeline-marker' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'marker_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-item:hover .pp-timeline-marker, {{WRAPPER}} .pp-timeline-marker-wrapper:hover .pp-timeline-marker' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'tab_marker_focused', [ 'label' => esc_html__( 'Focused', 'powerpack' ) ] );

		$this->add_control(
			'marker_color_focused',
			[
				'label'     => esc_html__( 'Marker Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-item-active .pp-timeline-marker, {{WRAPPER}} .swiper-slide-active .pp-timeline-marker' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-timeline-item-active .pp-timeline-marker svg, {{WRAPPER}} .swiper-slide-active .pp-timeline-marker svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'marker_bg_focused',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-item-active .pp-timeline-marker, {{WRAPPER}} .swiper-slide-active .pp-timeline-marker' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'marker_border_color_focused',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-item-active .pp-timeline-marker, {{WRAPPER}} .swiper-slide-active .pp-timeline-marker' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Dates
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_dates_controls() {
		$this->start_controls_section(
			'section_dates_style',
			[
				'label'     => esc_html__( 'Dates', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'dates' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'dates_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-timeline-card-date',
				'condition' => [
					'dates' => 'yes',
				],
			]
		);

		$this->start_controls_tabs( 'dates_tabs' );

		$this->start_controls_tab( 'tab_dates_normal', [ 'label' => esc_html__( 'Normal', 'powerpack' ) ] );

		$this->add_control(
			'dates_bg',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-card-date' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'dates' => 'yes',
				],
			]
		);

		$this->add_control(
			'dates_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-card-date' => 'color: {{VALUE}}',
				],
				'condition' => [
					'dates' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'dates_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-timeline-card-date',
				'condition'   => [
					'dates' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'dates_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-card-date' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'dates' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'dates_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-card-date' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'dates' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'dates_box_shadow',
				'selector'  => '{{WRAPPER}} .pp-timeline-card-date',
				'condition' => [
					'dates' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'tab_dates_hover', [ 'label' => esc_html__( 'Hover', 'powerpack' ) ] );

		$this->add_control(
			'dates_bg_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-card-date:hover' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'dates' => 'yes',
				],
			]
		);

		$this->add_control(
			'dates_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-card-date:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'dates' => 'yes',
				],
			]
		);

		$this->add_control(
			'dates_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-card-date:hover' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'dates' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'tab_dates_focused', [ 'label' => esc_html__( 'Focused', 'powerpack' ) ] );

		$this->add_control(
			'dates_bg_focused',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-item-active .pp-timeline-card-date, {{WRAPPER}} .swiper-slide-active .pp-timeline-card-date' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'dates' => 'yes',
				],
			]
		);

		$this->add_control(
			'dates_color_focused',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-item-active .pp-timeline-card-date, {{WRAPPER}} .swiper-slide-active .pp-timeline-card-date' => 'color: {{VALUE}}',
				],
				'condition' => [
					'dates' => 'yes',
				],
			]
		);

		$this->add_control(
			'dates_border_color_focused',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-item-active .pp-timeline-card-date, {{WRAPPER}} .swiper-slide-active .pp-timeline-card-date' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'dates' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Connector
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_connector_controls() {
		$this->start_controls_section(
			'section_connector_style',
			[
				'label' => esc_html__( 'Connector', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'connector_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-vertical.pp-timeline-left .pp-timeline-marker-wrapper' => 'margin-right: {{SIZE}}px;',
					'{{WRAPPER}} .pp-timeline-vertical.pp-timeline-right .pp-timeline-marker-wrapper' => 'margin-left: {{SIZE}}px;',
					'{{WRAPPER}} .pp-timeline-vertical.pp-timeline-center .pp-timeline-marker-wrapper' => 'margin-left: {{SIZE}}px; margin-right: {{SIZE}}px',

					'(tablet){{WRAPPER}} .pp-timeline-vertical.pp-timeline-tablet-left .pp-timeline-marker-wrapper' => 'margin-right: {{SIZE}}px;',
					'(tablet){{WRAPPER}} .pp-timeline-vertical.pp-timeline-tablet-right .pp-timeline-marker-wrapper' => 'margin-left: {{SIZE}}px;',
					'(tablet){{WRAPPER}} .pp-timeline-vertical.pp-timeline-tablet-center .pp-timeline-marker-wrapper' => 'margin-left: {{SIZE}}px; margin-right: {{SIZE}}px',

					'(mobile){{WRAPPER}} .pp-timeline-vertical.pp-timeline-mobile-left .pp-timeline-marker-wrapper' => 'margin-right: {{SIZE}}px !important;',
					'(mobile){{WRAPPER}} .pp-timeline-vertical.pp-timeline-mobile-right .pp-timeline-marker-wrapper' => 'margin-left: {{SIZE}}px !important;',
					'(mobile){{WRAPPER}} .pp-timeline-vertical.pp-timeline-mobile-center .pp-timeline-marker-wrapper' => 'margin-left: {{SIZE}}px !important; margin-right: {{SIZE}}px !important;',

					'{{WRAPPER}} .pp-timeline-horizontal' => 'margin-top: {{SIZE}}px;',
					'{{WRAPPER}} .pp-timeline-navigation .pp-timeline-card-date-wrapper' => 'margin-bottom: {{SIZE}}px;',
				],
			]
		);

		$this->add_responsive_control(
			'connector_thickness',
			[
				'label'      => esc_html__( 'Thickness', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 1,
						'max'  => 12,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-vertical .pp-timeline-connector' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pp-timeline-navigation:before' => 'height: {{SIZE}}{{UNIT}}; transform: translateY(calc({{SIZE}}{{UNIT}}/2))',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_connector' );

		$this->start_controls_tab(
			'tab_connector_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'layout' => 'vertical',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'connector_bg',
				'label'    => esc_html__( 'Background', 'powerpack' ),
				'types'    => [ 'classic', 'gradient' ],
				'exclude'  => [ 'image' ],
				'selector' => '{{WRAPPER}} .pp-timeline-connector, {{WRAPPER}} .pp-timeline-navigation:before',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_connector_progress',
			[
				'label'     => esc_html__( 'Progress', 'powerpack' ),
				'condition' => [
					'layout' => 'vertical',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'connector_bg_progress',
				'label'     => esc_html__( 'Background', 'powerpack' ),
				'types'     => [ 'classic', 'gradient' ],
				'exclude'   => [ 'image' ],
				'selector'  => '{{WRAPPER}} .pp-timeline-connector-inner',
				'condition' => [
					'layout' => 'vertical',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Arrows
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_arrows_controls() {
		$this->start_controls_section(
			'section_arrows_style',
			[
				'label'     => esc_html__( 'Arrows', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout' => 'horizontal',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_control(
			'select_arrow',
			[
				'label'                  => esc_html__( 'Choose Arrow', 'powerpack' ),
				'type'                   => Controls_Manager::ICONS,
				'fa4compatibility'       => 'arrow',
				'label_block'            => false,
				'default'                => [
					'value'   => 'fas fa-angle-right',
					'library' => 'fa-solid',
				],
				'skin'                   => 'inline',
				'exclude_inline_options' => 'svg',
				'recommended'            => [
					'fa-regular' => [
						'arrow-alt-circle-right',
						'caret-square-right',
						'hand-point-right',
					],
					'fa-solid'   => [
						'angle-right',
						'angle-double-right',
						'chevron-right',
						'chevron-circle-right',
						'arrow-right',
						'long-arrow-alt-right',
						'caret-right',
						'caret-square-right',
						'arrow-circle-right',
						'arrow-alt-circle-right',
						'toggle-right',
						'hand-point-right',
					],
				],
				'frontend_available' => true,
				'condition'          => [
					'layout' => 'horizontal',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_size',
			[
				'label'      => esc_html__( 'Arrows Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [ 'size' => '22' ],
				'range'      => [
					'px' => [
						'min'  => 15,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-navigation-wrap .pp-slider-arrow' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'horizontal',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_box_size',
			[
				'label'      => esc_html__( 'Arrows Box Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [ 'size' => '40' ],
				'range'      => [
					'px' => [
						'min'  => 15,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-navigation-wrap .pp-slider-arrow' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; transform: translateY(calc({{SIZE}}{{UNIT}}/2))',
				],
				'condition'  => [
					'layout' => 'horizontal',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'align_arrows',
			[
				'label'      => esc_html__( 'Align Arrows', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => -40,
						'max'  => 0,
						'step' => 1,
					],
				],
				/*
				 * PP_Helper::render_arrows() emits .elementor-swiper-button-prev /
				 * -next; the .pp-arrow-* classes these used to target belong to
				 * other widgets, so this control did nothing at any value.
				 */
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-navigation-wrap .elementor-swiper-button-prev' => 'inset-inline-start: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pp-timeline-navigation-wrap .elementor-swiper-button-next' => 'inset-inline-end: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'horizontal',
					'arrows' => 'yes',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_arrows_style' );

		$this->start_controls_tab(
			'tab_arrows_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'layout' => 'horizontal',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-navigation-wrap .pp-slider-arrow' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'layout' => 'horizontal',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_color_normal',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-navigation-wrap .pp-slider-arrow' => 'color: {{VALUE}};',
				],
				'condition' => [
					'layout' => 'horizontal',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'arrows_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-timeline-navigation-wrap .pp-slider-arrow',
				'condition'   => [
					'layout' => 'horizontal',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_border_radius_normal',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-navigation-wrap .pp-slider-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'horizontal',
					'arrows' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_arrows_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'layout' => 'horizontal',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-navigation-wrap .pp-slider-arrow:hover' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'layout' => 'horizontal',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-navigation-wrap .pp-slider-arrow:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'layout' => 'horizontal',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-navigation-wrap .pp-slider-arrow:hover' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'layout' => 'horizontal',
					'arrows' => 'yes',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Dots
	 *
	 * @since 2.2.5
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_dots_controls() {
		$this->start_controls_section(
			'section_dots_style',
			[
				'label'                 => esc_html__( 'Dots', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'layout' => 'horizontal',
					'dots'   => 'yes',
				],
			]
		);

		$this->add_control(
			'dots_position',
			[
				'label'                 => esc_html__( 'Position', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'options'               => [
					'inside'     => esc_html__( 'Inside', 'powerpack' ),
					'outside'    => esc_html__( 'Outside', 'powerpack' ),
				],
				'default'               => 'outside',
				'condition'             => [
					'layout' => 'horizontal',
					'dots'   => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'dots_size',
			[
				'label'                 => esc_html__( 'Size', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'min'   => 2,
						'max'   => 40,
						'step'  => 1,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}',
				],
				'condition'             => [
					'layout' => 'horizontal',
					'dots'   => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'dots_spacing',
			[
				'label'                 => esc_html__( 'Spacing', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'min'   => 1,
						'max'   => 30,
						'step'  => 1,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}}',
				],
				'condition'             => [
					'layout' => 'horizontal',
					'dots'   => 'yes',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_dots_style' );

		$this->start_controls_tab(
			'tab_dots_normal',
			[
				'label'                 => esc_html__( 'Normal', 'powerpack' ),
				'condition'             => [
					'layout' => 'horizontal',
					'dots'   => 'yes',
				],
			]
		);

		$this->add_control(
			'dots_color_normal',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet' => 'background: {{VALUE}};',
				],
				'condition'             => [
					'layout' => 'horizontal',
					'dots'   => 'yes',
				],
			]
		);

		$this->add_control(
			'active_dot_color_normal',
			[
				'label'                 => esc_html__( 'Active Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet-active' => 'background: {{VALUE}};',
				],
				'condition'             => [
					'layout' => 'horizontal',
					'dots'   => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'dots_border_normal',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'selector'              => '{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet',
				'condition'             => [
					'layout' => 'horizontal',
					'dots'   => 'yes',
				],
			]
		);

		$this->add_control(
			'dots_border_radius_normal',
			[
				'label'                 => esc_html__( 'Border Radius', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'             => [
					'layout' => 'horizontal',
					'dots'   => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'dots_margin',
			[
				'label'                 => esc_html__( 'Margin', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'allowed_dimensions'    => 'vertical',
				'placeholder'           => [
					'top'      => '',
					'right'    => 'auto',
					'bottom'   => '',
					'left'     => 'auto',
				],
				'selectors'             => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullets' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'             => [
					'layout' => 'horizontal',
					'dots'   => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_dots_hover',
			[
				'label'                 => esc_html__( 'Hover', 'powerpack' ),
				'condition'             => [
					'layout' => 'horizontal',
					'dots'   => 'yes',
				],
			]
		);

		$this->add_control(
			'dots_color_hover',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet:hover' => 'background: {{VALUE}};',
				],
				'condition'             => [
					'layout' => 'horizontal',
					'dots'   => 'yes',
				],
			]
		);

		$this->add_control(
			'dots_border_color_hover',
			[
				'label'                 => esc_html__( 'Border Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet:hover' => 'border-color: {{VALUE}};',
				],
				'condition'             => [
					'layout' => 'horizontal',
					'dots'   => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Button
	 * -------------------------------------------------
	 */
	protected function register_style_button_controls() {
		$this->start_controls_section(
			'section_button_style',
			[
				'label'     => esc_html__( 'Button', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_control(
			'button_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 20,
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-button' => 'margin-top: {{SIZE}}px;',
				],
				'condition' => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_control(
			'button_size',
			[
				'label'     => esc_html__( 'Size', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'md',
				'options'   => [
					'xs' => esc_html__( 'Extra Small', 'powerpack' ),
					'sm' => esc_html__( 'Small', 'powerpack' ),
					'md' => esc_html__( 'Medium', 'powerpack' ),
					'lg' => esc_html__( 'Large', 'powerpack' ),
					'xl' => esc_html__( 'Extra Large', 'powerpack' ),
				],
				'condition' => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_button_style' );

		$this->start_controls_tab(
			'tab_button_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_control(
			'button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-button' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_control(
			'button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-button' => 'color: {{VALUE}}',
				],
				'condition' => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-timeline-button',
				'condition'   => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_responsive_control(
			'button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'button_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector'  => '{{WRAPPER}} .pp-timeline-button',
				'condition' => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_responsive_control(
			'button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'button_box_shadow',
				'selector'  => '{{WRAPPER}} .pp-timeline-button',
				'condition' => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_control(
			'button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-button:hover' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_control(
			'button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-button:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_control(
			'button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-button:hover' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_control(
			'button_animation',
			[
				'label'     => esc_html__( 'Animation', 'powerpack' ),
				'type'      => Controls_Manager::HOVER_ANIMATION,
				'condition' => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'button_box_shadow_hover',
				'selector'  => '{{WRAPPER}} .pp-timeline-button:hover',
				'condition' => [
					'source'    => 'posts',
					'link_type' => 'button',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Pagination
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_pagination_controls() {
		$this->start_controls_section(
			'section_pagination_style',
			[
				'label'     => esc_html__( 'Pagination', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'pagination_margin_top',
			[
				'label'      => esc_html__( 'Gap between Posts & Pagination', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-pagination-bottom .pp-timeline-pagination' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', 'load_more' ],
				],
			]
		);

		$this->add_control(
			'load_more_button_size',
			[
				'label'     => esc_html__( 'Size', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'sm',
				'options'   => [
					'xs' => esc_html__( 'Extra Small', 'powerpack' ),
					'sm' => esc_html__( 'Small', 'powerpack' ),
					'md' => esc_html__( 'Medium', 'powerpack' ),
					'lg' => esc_html__( 'Large', 'powerpack' ),
					'xl' => esc_html__( 'Extra Large', 'powerpack' ),
				],
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => 'load_more',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'pagination_typography',
				'selector'  => '{{WRAPPER}} .pp-timeline-pagination .page-numbers, {{WRAPPER}} .pp-timeline-pagination a',
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', 'load_more' ],
				],
			]
		);

		$this->start_controls_tabs( 'tabs_pagination' );

		$this->start_controls_tab(
			'tab_pagination_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', 'load_more' ],
				],
			]
		);

		$this->add_control(
			'pagination_link_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-pagination .page-numbers, {{WRAPPER}} .pp-timeline-pagination a' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', 'load_more' ],
				],
			]
		);

		$this->add_control(
			'pagination_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-pagination .page-numbers, {{WRAPPER}} .pp-timeline-pagination a' => 'color: {{VALUE}};',
				],
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', 'load_more' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'pagination_link_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-timeline-pagination .page-numbers, {{WRAPPER}} .pp-timeline-pagination a',
				'condition'   => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', 'load_more' ],
				],
			]
		);

		$this->add_responsive_control(
			'pagination_link_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-pagination .page-numbers, {{WRAPPER}} .pp-timeline-pagination a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', 'load_more' ],
				],
			]
		);

		$this->add_responsive_control(
			'pagination_link_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-timeline-pagination .page-numbers, {{WRAPPER}} .pp-timeline-pagination a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', 'load_more' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'pagination_link_box_shadow',
				'selector'  => '{{WRAPPER}} .pp-timeline-pagination .page-numbers, {{WRAPPER}} .pp-timeline-pagination a',
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', 'load_more' ],
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_pagination_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', 'load_more' ],
				],
			]
		);

		$this->add_control(
			'pagination_link_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-pagination a:hover' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', 'load_more' ],
				],
			]
		);

		$this->add_control(
			'pagination_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-pagination a:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', 'load_more' ],
				],
			]
		);

		$this->add_control(
			'pagination_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-pagination a:hover' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', 'load_more' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'pagination_link_box_shadow_hover',
				'selector'  => '{{WRAPPER}} .pp-timeline-pagination a:hover',
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next', 'load_more' ],
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_pagination_active',
			[
				'label'     => esc_html__( 'Active', 'powerpack' ),
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next' ],
				],
			]
		);

		$this->add_control(
			'pagination_link_bg_color_active',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-pagination .page-numbers.current' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next' ],
				],
			]
		);

		$this->add_control(
			'pagination_color_active',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-pagination .page-numbers.current' => 'color: {{VALUE}};',
				],
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next' ],
				],
			]
		);

		$this->add_control(
			'pagination_border_color_active',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-timeline-pagination .page-numbers.current' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'pagination_link_box_shadow_active',
				'selector'  => '{{WRAPPER}} .pp-timeline-pagination .page-numbers.current',
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next' ],
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'pagination_spacing',
			[
				'label'      => esc_html__( 'Space Between', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'separator'  => 'before',
				'default'    => [
					'size' => 10,
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'body:not(.rtl) {{WRAPPER}} .pp-timeline-pagination .page-numbers:not(:first-child)' => 'margin-left: calc( {{SIZE}}{{UNIT}}/2 );',
					'body:not(.rtl) {{WRAPPER}} .pp-timeline-pagination .page-numbers:not(:last-child)' => 'margin-right: calc( {{SIZE}}{{UNIT}}/2 );',
					'body.rtl {{WRAPPER}} .pp-timeline-pagination .page-numbers:not(:first-child)' => 'margin-right: calc( {{SIZE}}{{UNIT}}/2 );',
					'body.rtl {{WRAPPER}} .pp-timeline-pagination .page-numbers:not(:last-child)' => 'margin-left: calc( {{SIZE}}{{UNIT}}/2 );',
				],
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'numbers', 'numbers_and_prev_next' ],
				],
			]
		);

		$this->add_control(
			'heading_loader',
			[
				'label'     => esc_html__( 'Loader', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'load_more', 'infinite' ],
				],
			]
		);

		$this->add_control(
			'loader_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-loader:after, {{WRAPPER}} .pp-posts-loader:after' => 'border-bottom-color: {{VALUE}}; border-top-color: {{VALUE}};',
				],
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'load_more', 'infinite' ],
				],
			]
		);

		$this->add_responsive_control(
			'loader_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 10,
						'max'  => 80,
						'step' => 1,
					],
				],
				'default'    => [
					'size' => 46,
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-posts-loader' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'source' => 'posts',
					'layout!' => 'horizontal',
					'pagination_type' => [ 'load_more', 'infinite' ],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render timeline widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$timeline_classes = [];
		$query_type       = $settings['query_type'];
		$page_id          = '';

		if ( null !== \Elementor\Plugin::$instance->documents->get_current() ) {
			$page_id = \Elementor\Plugin::$instance->documents->get_current()->get_main_id();
		}

		$timeline_classes[] = 'pp-timeline';

		if ( 'none' !== $settings['pagination_type'] ) {
			$timeline_classes[] = 'pp-timeline-with-pagination';
		}

		// Layout.
		if ( $settings['layout'] ) {
			$timeline_classes[] = 'pp-timeline-' . $settings['layout'];
		}

		// Direction.
		if ( isset( $settings['direction'] ) && $settings['direction'] ) {
			$timeline_classes[] = 'pp-timeline-' . $settings['direction'];
		}

		if ( 'yes' === $settings['dates'] ) {
			$timeline_classes[] = 'pp-timeline-dates';
		}

		if ( $settings['cards_arrows_alignment'] ) {
			$timeline_classes[] = 'pp-timeline-arrows-' . $settings['cards_arrows_alignment'];
		}

		if ( 'infinite' === $settings['pagination_type'] ) {
			$this->add_render_attribute( 'timeline-wrapper', 'class', 'pp-posts-infinite-scroll' );
		}

		$this->add_render_attribute( 'timeline', 'class', $timeline_classes );
		$this->add_render_attribute( 'timeline', 'data-query-type', $query_type );
		$this->add_render_attribute( 'timeline', 'data-page', $page_id );

		$this->add_render_attribute( 'timeline-wrapper', 'class', 'pp-timeline-wrapper' );
		$this->add_render_attribute( 'timeline-items', 'class', 'pp-timeline-items' );

		if ( 'horizontal' === $settings['layout'] ) {
			$this->add_render_attribute( 'timeline', 'class', 'swiper-container-wrap' );

			$this->add_render_attribute(
				[
					'timeline-items' => [
						'class'                => [
							'pp-swiper-slider',
							'swiper',
						],
						'role'                 => 'region',
						'aria-roledescription' => 'carousel',
						'aria-label'           => esc_attr__( 'Timeline', 'powerpack' ),
					],
					'swiper-wrapper' => [
						'class'     => 'swiper-wrapper',
						// An auto-rotating carousel must not announce every slide
						// change, so the live region is only active without autoplay.
						'aria-live' => ( 'yes' === $settings['autoplay'] ) ? 'off' : 'polite',
					],
				]
			);

			if ( $settings['dots_position'] ) {
				$this->add_render_attribute( 'timeline', 'class', 'swiper-container-wrap-dots-' . $settings['dots_position'] );
			}

			if ( 'yes' === $settings['equal_height'] ) {
				$this->add_render_attribute( 'timeline-items', 'class', 'pp-timeline-equal-height' );
			}
		}

		if ( 'horizontal' === $settings['layout'] && is_rtl() ) {
			$this->add_render_attribute( 'timeline-wrapper', 'dir', 'rtl' );
		}
		?>
		<div <?php $this->print_render_attribute_string( 'timeline-wrapper' ); ?>>
			<?php $this->render_horizontal_timeline_nav(); ?>

			<div <?php $this->print_render_attribute_string( 'timeline' ); ?>>
				<?php if ( 'vertical' === $settings['layout'] ) { ?>
					<div class="pp-timeline-connector-wrap">
						<div class="pp-timeline-connector">
							<div class="pp-timeline-connector-inner">
							</div>
						</div>
					</div>
				<?php } ?>
				<div <?php $this->print_render_attribute_string( 'timeline-items' ); ?>>
					<?php
					// The swiper wrapper only exists for the carousel; in vertical
					// layout it would be an attribute-less div around every item.
					$has_swiper_wrapper = ( 'horizontal' === $settings['layout'] );

					if ( $has_swiper_wrapper ) {
						?>
						<div <?php $this->print_render_attribute_string( 'swiper-wrapper' ); ?>>
						<?php
					}

					if ( 'posts' === $settings['source'] ) {
						$this->render_source_posts();
					} elseif ( 'custom' === $settings['source'] ) {
						$this->render_source_custom();
					}

					if ( $has_swiper_wrapper ) {
						?>
						</div>
						<?php
					}
					?>
				</div>
				<?php $this->render_dots(); ?>
			</div>

			<?php if ( 'horizontal' !== $settings['layout'] && 'posts' === $settings['source'] ) { ?>
				<?php $pagination_type = $settings['pagination_type']; ?>
				<?php if ( 'none' !== $pagination_type ) { ?>
				<div class="pp-timeline-pagination-wrap pp-timeline-pagination-bottom">
					<?php $this->render_pagination(); ?>
				</div>
				<?php
					if ( 'load_more' === $pagination_type || 'infinite' === $pagination_type ) {
						?>
						<div class="pp-posts-loader"></div>
						<?php
					}
				?>
				<?php } ?>
			<?php } ?>
		</div>
		<?php
	}

	/**
	 * Render timeline carousel dots output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_dots() {
		$settings = $this->get_settings_for_display();

		if ( 'yes' === $settings['dots'] ) {
			?>
			<!-- Add Pagination -->
			<div class="swiper-pagination swiper-pagination-<?php echo esc_attr( $this->get_id() ); ?>"></div>
			<?php
		}
	}

	/**
	 * Render the carousel navigation arrows on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_arrows() {
		PP_Helper::render_arrows( $this );
	}

	/**
	 * Render the horizontal timeline navigation output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_horizontal_timeline_nav() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'navigation', 'class', 'pp-timeline-navigation' );

		if ( 'horizontal' === $settings['layout'] ) {
			$this->add_render_attribute( 'navigation', 'class', [ 'pp-swiper-slider', 'swiper' ] );

			$this->add_render_attribute( 'navigation-wrapper', 'class', 'swiper-wrapper' );

			?>
			<div class="pp-timeline-navigation-wrap swiper-container-wrap">
				<?php $this->render_arrows(); ?>

				<div <?php $this->print_render_attribute_string( 'navigation' ); ?>>
					<div <?php $this->print_render_attribute_string( 'navigation-wrapper' ); ?>>
						<?php
						$i = 1;
						if ( 'custom' === $settings['source'] ) {
							foreach ( $settings['items'] as $index => $item ) {
								$item_key = $this->get_repeater_setting_key( 'h_custom_item', 'items', $index );
								$date     = $item['timeline_item_date'];

								$this->add_render_attribute(
									$item_key,
									'class',
									[
										'swiper-slide',
										'pp-timeline-nav-item',
										'elementor-repeater-item-' . esc_attr( $item['_id'] ),
									]
								);

								$this->add_render_attribute( $item_key, $this->get_nav_item_attributes( $i, $date ) );

								if ( $item['timeline_item_css_classes'] ) {
									$this->add_render_attribute( $item_key, 'class', $item['timeline_item_css_classes'] );
								}
								?>
								<div <?php $this->print_render_attribute_string( $item_key ); ?>>
									<?php
									$this->render_connector_marker( $i, $date, $item );

									$i++;
									?>
								</div>
								<?php
							}
						} elseif ( 'posts' === $settings['source'] ) {
							$posts_query = $this->get_timeline_query();

							if ( $posts_query && $posts_query->have_posts() ) :
								while ( $posts_query->have_posts() ) :
									$posts_query->the_post();

									$date         = $this->pp_get_date( $settings );
									$nav_item_key = 'h_post_item' . $i;

									$this->add_render_attribute(
										$nav_item_key,
										'class',
										[
											'swiper-slide',
											'pp-timeline-nav-item',
											'pp-timeline-item-' . intval( $i ),
										]
									);

									$this->add_render_attribute( $nav_item_key, $this->get_nav_item_attributes( $i, $date ) );
									?>
									<div <?php $this->print_render_attribute_string( $nav_item_key ); ?>>
									<?php
									$this->render_connector_marker( $i, $date );
									?>
									</div>
									<?php
									$i++;
								endwhile;
							endif;
							wp_reset_postdata();
						}
						?>
					</div>
				</div>
			</div>
			<?php
		}
	}

	/**
	 * Build the attributes that make a horizontal navigation item operable.
	 *
	 * The navigation items are click targets — Swiper's slideToClickedSlide
	 * moves the carousel to the item that was clicked — so they need a role, a
	 * tab stop and an accessible name to be usable without a mouse. The
	 * keyboard activation itself is bound in frontend-timeline.js.
	 *
	 * @since 3.0.1
	 * @access protected
	 *
	 * @param int    $number Item count.
	 * @param string $date   Item date, used as the accessible name when present.
	 *
	 * @return array Render attributes.
	 */
	protected function get_nav_item_attributes( $number, $date = '' ) {
		$label = wp_strip_all_tags( (string) $date );

		if ( '' === trim( $label ) ) {
			/* translators: %d: Timeline item number. */
			$label = sprintf( esc_html__( 'Timeline item %d', 'powerpack' ), (int) $number );
		}

		return [
			'role'       => 'button',
			'tabindex'   => '0',
			'aria-label' => $label,
		];
	}

	/**
	 * Render a card date.
	 *
	 * Posts carry a machine-readable publish date, so they are printed inside a
	 * <time> element. Custom items hold free text — which may legitimately be
	 * something like "Spring 1987" — so they stay a plain <div>.
	 *
	 * @since 3.0.1
	 * @access protected
	 *
	 * @param string $date The formatted date to display.
	 *
	 * @return void
	 */
	protected function render_card_date( $date ) {
		$settings = $this->get_settings_for_display();

		if ( 'posts' !== $settings['source'] ) {
			?>
			<div class="pp-timeline-card-date">
				<?php echo wp_kses_post( $date ); ?>
			</div>
			<?php
			return;
		}

		// Keep the machine-readable value in step with the date being shown.
		$date_attr = ( 'modified' === $settings['date_format'] )
			? get_the_modified_date( DATE_W3C )
			: get_the_date( DATE_W3C );
		?>
		<time class="pp-timeline-card-date"<?php echo $date_attr ? ' datetime="' . esc_attr( $date_attr ) . '"' : ''; ?>>
			<?php echo esc_html( $date ); ?>
		</time>
		<?php
	}

	/**
	 * Render the marker, and the date that travels with it, on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @param int          $number Item count, used by the number and letter marker types.
	 * @param string       $date   Item date.
	 * @param array|string $item   Repeater item when the source is Custom, an empty string when the source is Posts.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_connector_marker( $number = '', $date = '', $item = '' ) {
		$settings = $this->get_settings_for_display();

		$migration_allowed = Icons_Manager::is_migration_allowed();

		// Add old default.
		if ( is_array( $item ) && ! isset( $item['single_marker_icon'] ) && ! $migration_allowed ) {
			$item['single_marker_icon'] = 'fa fa-calendar';
		}

		$migrated_single = isset( $item['__fa4_migrated']['marker_icon_single'] );
		$is_new_single   = ! isset( $item['single_marker_icon'] ) && $migration_allowed;

		// Global Icon.
		if ( ! isset( $settings['marker_icon'] ) && ! $migration_allowed ) {
			// add old default.
			$settings['marker_icon'] = 'fa fa-calendar';
		}

		$has_icon = ! empty( $settings['marker_icon'] );

		if ( $has_icon ) {
			$this->add_render_attribute( 'i', 'class', $settings['marker_icon'] );
			$this->add_render_attribute( 'i', 'aria-hidden', 'true' );
		}

		if ( ! $has_icon && ! empty( $settings['select_marker_icon']['value'] ) ) {
			$has_icon = true;
		}
		$migrated = isset( $settings['__fa4_migrated']['select_marker_icon'] );
		$is_new   = ! isset( $settings['marker_icon'] ) && $migration_allowed;
		?>
		<div class="pp-timeline-marker-wrapper">
			<?php if ( 'horizontal' === $settings['layout'] && 'yes' === $settings['dates'] ) { ?>
				<div class="pp-timeline-card-date-wrapper">
					<?php $this->render_card_date( $date ); ?>
				</div>
			<?php } ?>

			<div class="pp-timeline-marker">
				<?php
				if ( 'custom' === $settings['source'] && 'yes' === $item['custom_style'] && 'global' !== $item['single_marker_type'] ) {
					if ( 'icon' === $item['single_marker_type'] ) {
						if ( ! empty( $item['single_marker_icon'] ) || ( ! empty( $item['marker_icon_single']['value'] ) && $is_new_single ) ) {
							echo '<span class="pp-icon">';
							if ( $is_new_single || $migrated_single ) {
								Icons_Manager::render_icon( $item['marker_icon_single'], [ 'aria-hidden' => 'true' ] );
							} else {
								?>
								<i class="<?php echo esc_attr( $item['single_marker_icon'] ); ?>" aria-hidden="true"></i>
								<?php
							}
							echo '</span>';
						}
					} elseif ( 'image' === $item['single_marker_type'] ) {
						Group_Control_Image_Size::print_attachment_image_html( $item, 'single_marker_icon_image', 'single_marker_icon_image' );
					} elseif ( 'text' === $item['single_marker_type'] ) {
						echo wp_kses_post( $item['single_marker_text'] );
					}
				} else {
					if ( 'icon' === $settings['marker_type'] && $has_icon ) {
						?>
						<span class="pp-icon">
						<?php
						if ( $is_new || $migrated ) {
							Icons_Manager::render_icon( $settings['select_marker_icon'], [ 'aria-hidden' => 'true' ] );
						} elseif ( ! empty( $settings['marker_icon'] ) ) {
							?>
							<i <?php $this->print_render_attribute_string( 'i' ); ?>></i>
							<?php
						}
						?>
						</span>
						<?php
					} elseif ( 'image' === $settings['marker_type'] ) {
						Group_Control_Image_Size::print_attachment_image_html( $settings, 'icon_image', 'icon_image' );
					} elseif ( 'number' === $settings['marker_type'] ) {
						echo esc_html( $number );
					} elseif ( 'letter' === $settings['marker_type'] ) {
						$alphabets = range( 'A', 'Z' );

						$alphabets = array_combine( range( 1, count( $alphabets ) ), $alphabets );

						// Wraps back to A after Z rather than reading past the end.
						$letter = $alphabets[ ( ( (int) $number - 1 ) % 26 ) + 1 ];

						echo esc_html( $letter );
					}
				}
				?>
			</div>
		</div>
		<?php if ( 'vertical' === $settings['layout'] ) { ?>
			<div class="pp-timeline-card-date-wrapper">
				<?php
				if ( 'yes' === $settings['dates'] ) {
					$this->render_card_date( $date );
				}
				?>
			</div>
		<?php } ?>
		<?php
	}

	/**
	 * Render custom content output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_source_custom() {
		$settings = $this->get_settings_for_display();

		$i = 1;

		foreach ( $settings['items'] as $index => $item ) {
			$item_key    = $this->get_repeater_setting_key( 'item', 'items', $index );
			$title_key   = $this->get_repeater_setting_key( 'timeline_item_title', 'items', $index );
			$content_key = $this->get_repeater_setting_key( 'timeline_item_content', 'items', $index );

			$this->add_inline_editing_attributes( $title_key, 'basic' );
			$this->add_inline_editing_attributes( $content_key, 'advanced' );

			if ( 0 === $i % 2 ) {
				$item_side = 'right';
			} else {
				$item_side = 'left';
			}

			if ( '' !== $item['single_marker_side'] ) {
				$item_side = $item['single_marker_side'];
			}

			$this->add_render_attribute(
				$item_key,
				'class',
				[
					'pp-timeline-item',
					'pp-timeline-item-' . $item_side,
					'elementor-repeater-item-' . esc_attr( $item['_id'] ),
				]
			);

			if ( 'yes' === $settings['animate_cards'] ) {
				$this->add_render_attribute( $item_key, 'class', 'pp-timeline-item-hidden' );
			}

			if ( 'horizontal' === $settings['layout'] ) {
				$this->add_render_attribute( $item_key, 'class', 'swiper-slide' );
			}

			if ( $item['timeline_item_css_classes'] ) {
				$this->add_render_attribute( $item_key, 'class', $item['timeline_item_css_classes'] );
			}

			$this->add_render_attribute( $title_key, 'class', 'pp-timeline-card-title' );

			$this->add_render_attribute( $content_key, 'class', 'pp-timeline-card-content' );

			$has_link = ! empty( $item['timeline_item_link']['url'] );

			if ( $has_link ) {
				$link_key = $this->get_repeater_setting_key( 'link', 'items', $index );

				$this->add_link_attributes( $link_key, $item['timeline_item_link'] );
			}
			?>
			<div <?php $this->print_render_attribute_string( $item_key ); ?>>
				<div class="pp-timeline-card-wrapper">
					<?php if ( $has_link ) { ?>
					<a <?php $this->print_render_attribute_string( $link_key ); ?>>
					<?php } ?>
					<?php if ( 'yes' === $settings['card_arrow'] ) { ?>
					<div class="pp-timeline-arrow"></div>
					<?php } ?>
					<div class="pp-timeline-card">
						<?php
							if ( 'below-title' !== $settings['media_position'] ) {
								$this->render_image( $settings, $item );
							}
						?>
						<?php if ( $item['timeline_item_title'] || 'yes' === $settings['dates'] ) { ?>
							<div class="pp-timeline-card-title-wrap">
								<?php
								if ( 'vertical' === $settings['layout'] && 'yes' === $settings['dates'] ) {
									$this->render_card_date( $item['timeline_item_date'] );
								}
								?>
								<?php if ( $item['timeline_item_title'] ) { ?>
									<?php $title_tag = PP_Helper::validate_html_tag( $settings['title_html_tag'] ); ?>
									<<?php echo esc_html( $title_tag ); ?> <?php $this->print_render_attribute_string( $title_key ); ?>>
										<?php
											echo wp_kses_post( $item['timeline_item_title'] );
										?>
									</<?php echo esc_html( $title_tag ); ?>>
								<?php } ?>
							</div>
						<?php } ?>
						<?php
							if ( 'below-title' === $settings['media_position'] ) {
								$this->render_image( $settings, $item );
							}
						?>
						<?php if ( $item['timeline_item_content'] ) { ?>
							<div <?php $this->print_render_attribute_string( $content_key ); ?>>
								<?php
									echo $this->parse_text_editor( $item['timeline_item_content'] ); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								?>
							</div>
						<?php } ?>
					</div>
					<?php if ( $has_link ) { ?>
					</a>
					<?php } ?>
				</div>

				<?php if ( 'vertical' === $settings['layout'] ) { ?>
					<?php $this->render_connector_marker( $i, $item['timeline_item_date'], $item ); ?>
				<?php } ?>
			</div>
			<?php
			$i++;
		}
	}

	/**
	 * Render post terms output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_terms() {
		$settings   = $this->get_settings_for_display();
		$post_meta  = $settings['post_meta'];
		$post_terms = $settings['post_category'];

		if ( 'show' !== $post_meta ) {
			return;
		}

		if ( 'show' !== $post_terms ) {
			return;
		}

		$post_type = $settings['post_type'];

		if ( 'related' === $settings['post_type'] ) {
			$post_type = get_post_type();
		}

		/*
		 * tax_badge_{post_type} only exists for post types that have taxonomies,
		 * and "related" resolves to whatever type the current post is — so this
		 * key is genuinely optional and must not be read directly.
		 */
		$tax_badge_key = 'tax_badge_' . $post_type;
		$taxonomies    = ! empty( $settings[ $tax_badge_key ] ) ? $settings[ $tax_badge_key ] : [];

		$terms = [];

		/*
		 * get_the_terms() reads the object term cache that WP_Query primed for
		 * this result set, so the terms cost no extra query per item;
		 * wp_get_post_terms() always hit the database.
		 */
		foreach ( (array) $taxonomies as $taxonomy ) {
			if ( ! $taxonomy ) {
				continue;
			}

			$terms_tax = get_the_terms( get_the_ID(), $taxonomy );

			if ( $terms_tax && ! is_wp_error( $terms_tax ) ) {
				$terms = array_merge( $terms, $terms_tax );
			}
		}

		if ( empty( $terms ) || is_wp_error( $terms ) ) {
			return;
		}

		$max_terms = (int) $settings['max_terms'];

		if ( $max_terms > 0 ) {
			$terms = array_slice( $terms, 0, $max_terms );
		}

		// The whole card is already an anchor when the link type is "Card", and
		// anchors cannot be nested, so terms fall back to plain text there.
		$link_terms = ( 'card' !== $settings['link_type'] );
		?>
		<span class="pp-timeline-category">
			<?php
			foreach ( $terms as $term ) {
				$term_link = $link_terms ? get_term_link( (int) $term->term_id ) : '';

				if ( $term_link && ! is_wp_error( $term_link ) ) {
					printf(
						'<a class="pp-post-term" href="%2$s">%1$s</a>',
						esc_html( $term->name ),
						esc_url( $term_link )
					);
				} else {
					printf( '<span class="pp-post-term">%1$s</span>', esc_html( $term->name ) );
				}
			}
			?>
		</span>
		<?php
	}

	/**
	 * Render post body output for an AJAX pagination request.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access public
	 *
	 * @param string $filter   Term filter. Accepted for signature parity with the posts skins; unused here.
	 * @param string $taxonomy Taxonomy filter. Accepted for signature parity with the posts skins; unused here.
	 * @param string $search   Search filter. Accepted for signature parity with the posts skins; unused here.
	 *
	 * @return string Timeline items markup.
	 */
	public function render_ajax_post_body( $filter = '', $taxonomy = '', $search = '' ) {
		/*
		 * Items only. This used to re-emit the connector and the items container
		 * as well, which the Load More path then appended *inside* .pp-timeline —
		 * so every click added another connector rail and another items wrapper,
		 * restarting the left/right alternation. The JS now fills
		 * .pp-timeline-items, so both paths match the initial render.
		 */
		ob_start();

		$this->render_source_posts();

		return ob_get_clean();
	}

	/**
	 * Render the pagination output for an AJAX pagination request.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 2.3.7
	 * @access public
	 *
	 * @param string $filter   Term filter.
	 * @param string $taxonomy Taxonomy filter.
	 * @param string $search   Search filter.
	 *
	 * @return string Pagination markup.
	 */
	public function render_ajax_pagination( $filter = '', $taxonomy = '', $search = '' ) {
		ob_start();
		$this->render_pagination( $filter, $taxonomy, $search );
		return ob_get_clean();
	}

	/**
	 * Render posts output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_source_posts() {
		$settings = $this->get_settings_for_display();

		/**
		 * Pre-compute pieces needed to re-resolve the Custom URL dynamic tag
		 * for each post inside the loop. Otherwise get_settings_for_display()
		 * caches the URL parsed once against the outer post context and reuses
		 * it for every timeline item.
		 *
		 * @since 2.13.2
		 */
		$raw_settings        = $this->get_settings();
		$posts_link_controls = [];
		$controls            = $this->get_controls();

		if ( isset( $controls['posts_link'] ) ) {
			$posts_link_controls = [ 'posts_link' => $controls['posts_link'] ];
		}

		$i = 1;

		// Query Arguments — shared with the horizontal navigation rail.
		$posts_query = $this->get_timeline_query();

		if ( $posts_query && $posts_query->have_posts() ) :
			while ( $posts_query->have_posts() ) :
				$posts_query->the_post();

				if ( '' !== $settings['link_type'] ) {
					$link_key = $this->get_repeater_setting_key( 'post_link', 'items', $i );

					$link = [];

					if ( 'custom' === $settings['posts_link_to'] ) {
						$post_link = $settings['posts_link'];

						if ( ! empty( $posts_link_controls ) && ! empty( $raw_settings['__dynamic__']['posts_link'] ) ) {
							/**
							 * Several dynamic-tag providers (notably Elementor Pro's ACF
							 * tags) resolve their value against get_queried_object()
							 * rather than the global $post. Inside a secondary WP_Query
							 * loop the queried object never changes, so every item ends
							 * up with the same URL. Swap the main query's queried object
							 * to the current post for the duration of the parse, then
							 * restore it.
							 *
							 * @since 2.13.2
							 */
							global $wp_query;

							$orig_queried_object    = isset( $wp_query->queried_object ) ? $wp_query->queried_object : null;
							$orig_queried_object_id = isset( $wp_query->queried_object_id ) ? $wp_query->queried_object_id : null;

							$wp_query->queried_object    = get_post();
							$wp_query->queried_object_id = get_the_ID();

							$resolved = $this->parse_dynamic_settings( $raw_settings, $posts_link_controls, $raw_settings );

							$wp_query->queried_object    = $orig_queried_object;
							$wp_query->queried_object_id = $orig_queried_object_id;

							$post_link = ! empty( $resolved['posts_link'] ) ? $resolved['posts_link'] : $post_link;
						}

						if ( ! empty( $post_link['url'] ) ) {
							$link = [
								'url'         => $post_link['url'],
								'is_external' => ! empty( $post_link['is_external'] ) ? $post_link['is_external'] : '',
								'nofollow'    => ! empty( $post_link['nofollow'] ) ? $post_link['nofollow'] : '',
							];
						}
					}

					if ( empty( $link ) ) {
						$link = [
							'url'         => esc_url( get_permalink() ),
							'is_external' => '',
							'nofollow'    => '',
						];
					}

					$this->add_link_attributes( $link_key, $link );
				}

				$item_key = 'timeline-item' . $i;

				if ( has_post_thumbnail() || 'attachment' === $settings['post_type'] ) {
					if ( 'attachment' === $settings['post_type'] ) {
						$image_id = get_the_ID();
					} else {
						$image_id = get_post_thumbnail_id( get_the_ID() );
					}

					$thumb_url = Group_Control_Image_Size::get_attachment_image_src( $image_id, 'image_size', $settings );

					/*
					 * Handing the attachment ID to Group_Control_Image_Size lets it
					 * build the <img> through wp_get_attachment_image(), which keeps
					 * srcset/sizes, loading="lazy", decoding and the intrinsic
					 * width/height a hand-built tag threw away.
					 */
					$image_html_settings = array_merge(
						$settings,
						[
							'image_size' => [
								'id'  => $image_id,
								'url' => $thumb_url,
							],
						]
					);
				} else {
					$thumb_url           = '';
					$image_html_settings = [];
				}

				// Cast before the modulo below: a non-numeric value would be a TypeError on PHP 8.
				$page_number = ! empty( $_POST['page_number'] ) ? absint( wp_unslash( $_POST['page_number'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Missing

				if ( ( ( 0 === $page_number % 2 ) && ( 0 !== (int) $settings['posts_per_page'] % 2 ) ) && in_array( $settings['pagination_type'], [ 'load_more', 'infinite' ] ) ) {
					if ( 0 === $i % 2 ) {
						$item_side = 'left';
					} else {
						$item_side = 'right';
					}
				} else {
					if ( 0 === $i % 2 ) {
						$item_side = 'right';
					} else {
						$item_side = 'left';
					}
				}

				$this->add_render_attribute(
					$item_key,
					'class',
					[
						'pp-timeline-item',
						'pp-timeline-item-' . $item_side,
						'pp-timeline-item-' . intval( $i ),
					]
				);

				if ( 'yes' === $settings['animate_cards'] ) {
					$this->add_render_attribute( $item_key, 'class', 'pp-timeline-item-hidden' );
				}

				if ( 'horizontal' === $settings['layout'] ) {
					$this->add_render_attribute( $item_key, 'class', 'swiper-slide' );
				}

				$post_date = $this->pp_get_date( $settings );
				?>
				<div <?php $this->print_render_attribute_string( $item_key ); ?>>
					<div class="pp-timeline-card-wrapper">
						<?php if ( 'card' === $settings['link_type'] ) { ?>
						<a <?php $this->print_render_attribute_string( $link_key ); ?>>
						<?php } ?>
						<?php if ( 'yes' === $settings['card_arrow'] ) { ?>
						<div class="pp-timeline-arrow"></div>
						<?php } ?>
						<div class="pp-timeline-card">
							<?php
								if ( 'below-title' !== $settings['media_position'] ) {
									$this->render_image( $settings, '', 'post', $image_html_settings );
								}
							?>
							<?php if ( 'show' === $settings['post_title'] || 'yes' === $settings['dates'] ) { ?>
								<div class="pp-timeline-card-title-wrap">
									<?php
									if ( 'vertical' === $settings['layout'] && 'yes' === $settings['dates'] ) {
										$this->render_card_date( $post_date );
									}
									?>
									<?php if ( 'show' === $settings['post_title'] ) { ?>
										<?php $title_tag = PP_Helper::validate_html_tag( $settings['title_html_tag'] ); ?>
										<<?php echo esc_html( $title_tag ); ?> class="pp-timeline-card-title">
											<?php
											if ( 'title' === $settings['link_type'] ) {
												// The attribute string is already escaped per value by
											// add_render_attribute(); wp_kses_post() is for markup, not attributes.
											printf(
												'<a %1$s>%2$s</a>',
												$this->get_render_attribute_string( $link_key ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
												wp_kses_post( get_the_title() )
											);
											} else {
												the_title();
											}
											?>
										</<?php echo esc_html( $title_tag ); ?>>
									<?php } ?>
									<?php if ( 'show' === $settings['post_meta'] ) { ?>
										<div class="pp-timeline-meta">
											<?php if ( 'show' === $settings['post_author'] ) { ?>
												<span class="pp-timeline-author">
													<?php echo esc_html( get_the_author() ); ?>
												</span>
											<?php } ?>
											<?php $this->render_terms(); ?>
										</div>
									<?php } ?>
								</div>
							<?php } ?>
							<?php
								if ( 'below-title' === $settings['media_position'] ) {
									$this->render_image( $settings, '', 'post', $image_html_settings );
								}
							?>
							<?php
							$has_content = ( 'show' === $settings['post_content'] );
							$has_button  = ( 'button' === $settings['link_type'] && $settings['button_text'] );

							// Skip the container entirely rather than emitting an
							// empty, padded box when the card has neither part.
							if ( $has_content || $has_button ) {
								?>
								<div class="pp-timeline-card-content">
									<?php if ( $has_content ) { ?>
										<div class="pp-timeline-card-excerpt">
											<?php $this->render_post_content(); ?>
										</div>
									<?php } ?>
									<?php
									if ( $has_button ) {
										$this->add_render_attribute(
											'button',
											'class',
											[
												'pp-timeline-button',
												'elementor-button',
												'elementor-size-' . $settings['button_size'],
											]
										);
										?>
										<a <?php $this->print_render_attribute_string( 'button' ); ?> <?php $this->print_render_attribute_string( $link_key ); ?>>
											<span class="pp-timeline-button-text">
												<?php echo esc_html( $settings['button_text'] ); ?>
											</span>
										</a>
										<?php
									}
									?>
								</div>
								<?php
							}
							?>
						</div>
						<?php if ( 'card' === $settings['link_type'] ) { ?>
						</a>
						<?php } ?>
					</div>

					<?php
					if ( 'vertical' === $settings['layout'] ) {
						$this->render_connector_marker( $i, $post_date );
					}
					?>
				</div>
				<?php
				$i++;
		endwhile;
		endif;
		wp_reset_postdata();
	}

	/**
	 * Get Pagination.
	 *
	 * Prints the pagination HTML.
	 *
	 * @since 2.13.0
	 * @access public
	 *
	 * @param string $filter   Term filter. Accepted for signature parity with the posts skins; unused here.
	 * @param string $taxonomy Taxonomy filter. Accepted for signature parity with the posts skins; unused here.
	 * @param string $search   Search filter. Accepted for signature parity with the posts skins; unused here.
	 *
	 * @return void
	 */
	public function render_pagination( $filter = '', $taxonomy = '', $search = '' ) {
		$settings = $this->get_settings_for_display();

		$pagination_type    = $settings['pagination_type'];
		$page_limit         = $settings['pagination_page_limit'];
		$pagination_shorten = $settings['pagination_numbers_shorten'];

		if ( 'none' === $pagination_type ) {
			return;
		}

		// Get current page number.
		$paged = $this->get_paged();

		$query = $this->get_query();

		// Bail if the query was never built — e.g. when the source is "custom"
		// (render_source_custom() does not call query_posts()) or when an
		// upstream filter short-circuited the query.
		if ( ! $query instanceof \WP_Query ) {
			return;
		}

		$total_pages            = $query->max_num_pages;
		$total_pages_pagination = $query->max_num_pages;

		if ( 'load_more' !== $pagination_type && 'infinite' !== $pagination_type ) {

			if ( '' !== $page_limit && null !== $page_limit ) {
				$total_pages = min( $page_limit, $total_pages );
			}
		}

		if ( 2 > $total_pages ) {
			return;
		}

		$has_numbers   = in_array( $pagination_type, [ 'numbers', 'numbers_and_prev_next' ] );
		$has_prev_next = ( 'numbers_and_prev_next' === $pagination_type );
		$is_load_more  = ( 'load_more' === $pagination_type );
		$is_infinite   = ( 'infinite' === $pagination_type );

		$links = [];

		if ( $has_numbers || $is_infinite ) {

			$current_page = $paged;
			if ( ! $current_page ) {
				$current_page = 1;
			}

			$paginate_args = [
				'type'      => 'array',
				'current'   => $current_page,
				'total'     => $total_pages,
				'prev_next' => false,
				'show_all'  => 'yes' !== $pagination_shorten,
			];
		}

		if ( $has_prev_next ) {
			$prev_label = $settings['pagination_prev_label'];
			$next_label = $settings['pagination_next_label'];

			$paginate_args['prev_next'] = true;

			if ( $prev_label ) {
				$paginate_args['prev_text'] = $prev_label;
			}
			if ( $next_label ) {
				$paginate_args['next_text'] = $next_label;
			}
		}

		if ( $has_numbers || $has_prev_next || $is_infinite ) {

			if ( is_singular() && ! is_front_page() && ! is_singular( 'page' ) ) {
				global $wp_rewrite;
				if ( $wp_rewrite->using_permalinks() ) {
					$paginate_args['base']   = trailingslashit( get_permalink() ) . '%_%';
					$paginate_args['format'] = user_trailingslashit( '%#%', 'single_paged' );
				} else {
					$paginate_args['format'] = '?page=%#%';
				}
			}

			$links = paginate_links( $paginate_args );

		}

		if ( ! $is_load_more ) {
			$pagination_ajax = $settings['pagination_ajax'];
			$query_type      = $settings['query_type'];
			$pagination_type = 'standard';

			if ( 'yes' === $pagination_ajax && 'main' !== $query_type ) {
				$pagination_type = 'ajax';
			}
			?>
			<nav class="pp-timeline-pagination pp-timeline-pagination-<?php echo esc_attr( $pagination_type ); ?> elementor-pagination" role="navigation" aria-label="<?php esc_attr_e( 'Pagination', 'powerpack' ); ?>" data-total="<?php echo esc_html( $total_pages_pagination ); ?>">
				<?php echo implode( PHP_EOL, $links ); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</nav>
			<?php
		}

		if ( $is_load_more ) {
			$load_more_label       = $settings['pagination_load_more_label'];
			$load_more_button_size = $settings['load_more_button_size'];

			// fa4compatibility key: only present on sites carrying a pre-migration icon.
			$load_more_button_icon = ! empty( $settings['pagination_load_more_button_icon'] ) ? $settings['pagination_load_more_button_icon'] : '';
			?>
			<div class="pp-post-load-more-wrap pp-timeline-pagination" data-total="<?php echo esc_html( $total_pages_pagination ); ?>">
				<a class="pp-post-load-more elementor-button elementor-size-<?php echo esc_attr( $load_more_button_size ); ?>" href="javascript:void(0);">
					<span class="elementor-button-content-wrapper">
						<?php if ( $load_more_label ) { ?>
							<span class="pp-button-text">
								<?php echo esc_html( $load_more_label ); ?>
							</span>
						<?php } ?>

						<?php $this->render_load_more_button_icon( $is_load_more ); ?>
					</span>
				</a>
			</div>
			<?php
		}
	}

	/**
	 * Render load more button icon output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 *
	 * @param bool $is_load_more Whether the Load More pagination type is active.
	 *
	 * @return void
	 */
	protected function render_load_more_button_icon( $is_load_more ) {
		$settings = $this->get_settings_for_display();

		if ( ! $is_load_more ) {
			return;
		}

		$button_icon        = ! empty( $settings['pagination_load_more_button_icon'] ) ? $settings['pagination_load_more_button_icon'] : '';
		$select_button_icon = $settings['select_pagination_load_more_button_icon'];

		$migrated = isset( $settings['__fa4_migrated']['select_pagination_load_more_button_icon'] );
		$is_new   = empty( $button_icon ) && Icons_Manager::is_migration_allowed();

		// Nothing to wrap when no icon was chosen.
		if ( empty( $button_icon ) && empty( $select_button_icon['value'] ) ) {
			return;
		}

		if ( $is_new || $migrated ) { ?>
			<span class="pp-button-icon elementor-button-icon">
				<?php Icons_Manager::render_icon( $select_button_icon, [ 'aria-hidden' => 'true' ] ); ?>
			</span>
			<?php
		} else { ?>
			<span class="pp-button-icon elementor-button-icon">
				<i class="pp-button-icon <?php echo esc_attr( $button_icon ); ?>" aria-hidden="true"></i>
			</span>
			<?php
		}
	}

	/**
	 * Get post date.
	 *
	 * Returns the post date for the post currently in the loop, formatted
	 * according to the widget's date settings.
	 *
	 * @since 1.4.11.0
	 * @access public
	 *
	 * @param array $settings Widget settings.
	 *
	 * @return string Formatted post date.
	 */
	public function pp_get_date( $settings ) {
		$date_type          = $settings['date_format'];
		$date_format        = $settings['date_format_select'];
		$date_custom_format = $settings['timeline_post_date_format'];
		$date               = '';

		if ( ! $date_format ) {
			$date_format = 'F j, Y';
		}

		if ( 'custom' === $date_format && $date_custom_format ) {
			$date_format = $date_custom_format;
		}

		if ( 'ago' === $date_type ) {
			/* translators: %s: Human-readable time difference. */
			$date = sprintf( _x( '%s ago', '%s = human-readable time difference', 'powerpack' ), human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) ) );
		} elseif ( 'modified' === $date_type ) {
			$date = get_the_modified_date( $date_format, get_the_ID() );
		} elseif ( 'key' === $date_type ) {
			$date_meta_key = $settings['timeline_post_date_key'];

			if ( $date_meta_key ) {
				$date = get_post_meta( get_the_ID(), $date_meta_key, true );
			}

			if ( $date ) {
				$date = date_i18n( $date_format, strtotime( $date ) );
			}
		} else {
			$date = get_the_date( $date_format );
		}

		if ( '' === $date ) {
			$date = get_the_date( $date_format );
		}

		/**
		 * Filters the formatted date displayed by the Timeline widget.
		 *
		 * @since 1.4.11.0
		 *
		 * @param string $date        The formatted date.
		 * @param string $date_format The site's default date format option.
		 * @param string $unused_1    Unused. Reserved for backward compatibility.
		 * @param string $unused_2    Unused. Reserved for backward compatibility.
		 */
		return apply_filters( 'pp_timeline_date_format', $date, get_option( 'date_format' ), '', '' );
	}

	/**
	 * Render the card media — an image or a video — on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 *
	 * @param array        $settings       Widget settings.
	 * @param array|string $item           Repeater item when $image_type is 'custom', an empty string otherwise.
	 * @param string       $image_type     Either 'custom' for a repeater item or 'post' for a queried post.
	 * @param array        $image_settings Settings carrying the post thumbnail's attachment ID, used when
	 *                                     $image_type is 'post'. Empty when the post has no thumbnail.
	 *
	 * @return void
	 */
	protected function render_image( $settings, $item = '', $image_type = 'custom', $image_settings = [] ) {
		if ( 'post' === $image_type ) {
			if ( 'show' !== $settings['post_image'] ) {
				return;
			}

			$post_media_type = ! empty( $settings['post_media_type'] ) ? $settings['post_media_type'] : 'image';

			if ( 'video' === $post_media_type ) {
				$video_source = ! empty( $settings['post_video_source'] ) ? $settings['post_video_source'] : 'youtube';
				$video_url    = '';

				if ( ! empty( $settings['post_video_field'] ) ) {
					$video_url = get_post_meta( get_the_ID(), $settings['post_video_field'], true );
				}

				$this->render_card_video( $video_source, $video_url );
			} elseif ( ! empty( $image_settings['image_size']['id'] ) ) {
				// Without this guard a post with no featured image rendered
				// <img src="">, which makes the browser re-request the page.
				?>
				<div class="pp-timeline-card-image">
					<?php Group_Control_Image_Size::print_attachment_image_html( $image_settings, 'image_size' ); ?>
				</div>
				<?php
			}
		} else {
			if ( 'yes' !== $item['card_image'] ) {
				return;
			}

			$media_type = ! empty( $item['media_type'] ) ? $item['media_type'] : 'image';

			if ( 'video' === $media_type ) {
				$video_source = ! empty( $item['video_source'] ) ? $item['video_source'] : 'youtube';

				if ( 'hosted' === $video_source ) {
					if ( ! empty( $item['insert_url'] ) ) {
						$video_url = ! empty( $item['external_url']['url'] ) ? $item['external_url']['url'] : '';
					} else {
						$video_url = ! empty( $item['hosted_url']['url'] ) ? $item['hosted_url']['url'] : '';
					}
				} else {
					$video_url = ! empty( $item[ $video_source . '_url' ] ) ? $item[ $video_source . '_url' ] : '';
				}

				$this->render_card_video( $video_source, $video_url );
			} elseif ( ! empty( $item['image']['url'] ) ) { ?>
				<div class="pp-timeline-card-image">
					<?php Group_Control_Image_Size::print_attachment_image_html( $item, 'image', 'image' ); ?>
				</div>
				<?php
			}
		}
	}

	/**
	 * Render the card video markup for either a custom item or a post.
	 *
	 * @since 2.13.5
	 * @access protected
	 *
	 * @param string $video_source One of youtube|vimeo|dailymotion|hosted.
	 * @param string $video_url    The source/file URL of the video.
	 *
	 * @return void
	 */
	protected function render_card_video( $video_source, $video_url ) {
		if ( empty( $video_url ) ) {
			return;
		}
		?>
		<div class="pp-timeline-card-image">
			<div class="pp-timeline-card-video">
				<?php
				if ( 'hosted' === $video_source ) {
					?>
					<video controls src="<?php echo esc_url( $video_url ); ?>"></video>
					<?php
				} else {
					$embed_url = \Elementor\Embed::get_embed_url( $video_url );

					if ( $embed_url ) {
						?>
						<iframe src="<?php echo esc_url( $embed_url ); ?>" title="<?php echo esc_attr__( 'Timeline video', 'powerpack' ); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
						<?php
					}
				}
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the post content output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_post_content() {
		$settings = $this->get_settings_for_display();

		$content_length = $settings['content_length'];

		if ( 'excerpt' === $settings['content_type'] || '' === $content_length ) {
			$content = get_the_excerpt();
		} else {
			$content = wp_trim_words( get_the_content(), $content_length );
		}

		echo wp_kses_post( $content );
	}
}
