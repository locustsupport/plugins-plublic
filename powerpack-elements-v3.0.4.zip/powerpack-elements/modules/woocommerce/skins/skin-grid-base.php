<?php
/**
 * PowerPack WooCommerce Skin Grid - Default.
 *
 * @package PowerPack
 */

namespace PowerpackElements\Modules\Woocommerce\Skins;

use PowerpackElements\Classes\PP_Helper;

use Elementor\Controls_Manager;
use Elementor\Skin_Base;
use Elementor\Icons_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Skin_Grid_Base
 *
 * @property Products $parent
 */
abstract class Skin_Grid_Base extends Skin_Base {

	/**
	 * Holds add to cart button text for simple products.
	 *
	 * @since 2.9.7
	 */
	public static $add_to_cart_text;

	/**
	 * Holds add to cart button text for variable products.
	 *
	 * @since 2.9.7
	 */
	public static $select_options_text;

	/**
	 * Holds add to cart button text for grouped products.
	 *
	 * @since 2.9.7
	 */
	public static $view_products_text;

	/**
	 * Holds read more button text for simple and variable products.
	 *
	 * @since 2.9.7
	 */
	public static $read_more_text;

	/**
	 * Build the icon descriptor for an action icon.
	 *
	 * @access private
	 * @param string $network_name Font Awesome icon name, without the fa- prefix.
	 * @return array Icon value and library, as Icons_Manager expects them.
	 */
	private static function get_network_icon_data( $network_name ) {
		$prefix = 'fa ';
		$library = '';

		if ( Icons_Manager::is_migration_allowed() ) {
			$prefix = 'fas ';
			$library = 'fa-solid';
		}

		return [
			'value' => $prefix . 'fa-' . $network_name,
			'library' => $library,
		];
	}

	/**
	 * Query object
	 *
	 * @since 2.4.0
	 * @var object $query
	 */
	public static $query;

	/**
	 * Settings
	 *
	 * @since 2.4.0
	 * @var object $settings
	 */
	public static $settings;

	/**
	 * Get the settings this skin should render with.
	 *
	 * During an AJAX pagination request the widget is rebuilt from stored data
	 * and its settings are handed to the skin through self::$settings. Every
	 * other render reads them from the parent widget.
	 *
	 * @since 3.0.0
	 * @access protected
	 * @return array Widget settings.
	 */
	protected function get_skin_settings() {
		if ( ! empty( self::$settings ) ) {
			return self::$settings;
		}

		return $this->parent->get_settings();
	}

	/**
	 * Change pagination arguments based on settings.
	 *
	 * @since 1.3.3
	 * @access protected
	 * @param string $located location.
	 * @param string $template_name template name.
	 * @param array  $args arguments.
	 * @param string $template_path path.
	 * @param string $default_path default path.
	 * @return string template location
	 */
	public function woo_pagination_template( $located, $template_name, $args, $template_path, $default_path ) {

		if ( 'loop/pagination.php' === $template_name ) {
			$located = POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/loop/pagination.php';
		}

		return $located;
	}

	/**
	 * Change pagination arguments based on settings.
	 *
	 * @since 1.3.3
	 * @access protected
	 * @param array $args pagination args.
	 * @return array
	 */
	public function woo_pagination_options( $args ) {

		$settings = $this->get_skin_settings();

		$pagination_arrow = false;

		if ( 'numbers_arrow' === $settings['pagination_type'] ) {
			$pagination_arrow = true;
		}

		$args['prev_next'] = $pagination_arrow;

		if ( '' !== $settings['pagination_prev_label'] ) {
			$args['prev_text'] = $settings['pagination_prev_label'];
		}

		if ( '' !== $settings['pagination_next_label'] ) {
			$args['next_text'] = $settings['pagination_next_label'];
		}

		return $args;
	}

	/**
	 * Get Wrapper Classes.
	 *
	 * @since 1.3.3
	 * @access public
	 */
	public function set_slider_attr() {

		$settings = $this->get_skin_settings();

		if ( 'slider' !== $settings['products_layout_type'] ) {
			return;
		}

		$responsive = $this->get_slider_responsive_options( $settings );

		$slider_options = [
			'direction'             => 'horizontal',
			'slidesPerView'         => $responsive['desktop']['slidesPerView'],
			'slidesPerGroup'        => $responsive['desktop']['slidesPerGroup'],
			'speed'                 => ( $settings['transition_speed'] ) ? absint( $settings['transition_speed'] ) : 400,
			'spaceBetween'          => $responsive['desktop']['spaceBetween'],
			'loop'                  => ( 'yes' === $settings['infinite'] ),
			'grabCursor'            => ( 'yes' === $settings['grab_cursor'] ),
			'autoHeight'            => true,
			'watchSlidesVisibility' => true,
			'observer'              => true,
			'observeParents'        => true,
		];

		if ( 'yes' === $settings['autoplay'] ) {
			// pauseOnMouseEnter and disableOnInteraction belong inside autoplay.
			// At the top level Swiper ignores them, which is why Pause on Hover
			// never did anything.
			$slider_options['autoplay'] = [
				'delay'                => ! empty( $settings['autoplay_speed'] ) ? absint( $settings['autoplay_speed'] ) : 2000,
				'pauseOnMouseEnter'    => ( 'yes' === $settings['pause_on_hover'] ),
				'disableOnInteraction' => false,
			];
		} else {
			$slider_options['autoplay'] = false;
		}

		if ( 'yes' === $settings['arrows'] ) {
			$slider_options['navigation'] = [
				'nextEl' => '.swiper-button-next-' . esc_attr( $this->parent->get_id() ),
				'prevEl' => '.swiper-button-prev-' . esc_attr( $this->parent->get_id() ),
			];
		}

		if ( 'yes' === $settings['carousel_pagination'] ) {
			$slider_options['pagination'] = [
				'el'        => '.swiper-pagination-' . esc_attr( $this->parent->get_id() ),
				'clickable' => true,
			];
		}

		$slider_options['breakpoints'] = $responsive['breakpoints'];

		$this->parent->add_render_attribute(
			'wrapper', [
				'data-woo_slider' => wp_json_encode( $slider_options ),
			]
		);
	}

	/**
	 * Build the per device carousel options.
	 *
	 * Walks every breakpoint the site has active rather than the fixed
	 * desktop/tablet/mobile trio, so the responsive controls Elementor
	 * generates for custom breakpoints are honoured too.
	 *
	 * Elementor breakpoints are max-widths and inherit downwards, while Swiper
	 * breakpoints are min-widths. A device therefore starts one pixel above the
	 * next smaller breakpoint, and a device with no value of its own reuses the
	 * value resolved for the next larger one.
	 *
	 * @since 3.0.0
	 * @access protected
	 * @param array $settings Widget settings.
	 * @return array {
	 *     @type array $desktop     Options for the largest device.
	 *     @type array $breakpoints Swiper breakpoints keyed by min-width.
	 * }
	 */
	protected function get_slider_responsive_options( $settings ) {
		$active = PP_Helper::elementor()->breakpoints->get_active_breakpoints();

		// Elementor mixes two kinds of breakpoint. The max-width ones sit below
		// desktop; widescreen is min-width and sits above it.
		$below = [];
		$above = [];

		foreach ( $active as $device => $breakpoint ) {
			if ( 'min' === $breakpoint->get_direction() ) {
				$above[ $device ] = $breakpoint;
			} else {
				$below[ $device ] = $breakpoint;
			}
		}

		// Narrowest to widest, with desktop between the two groups.
		$devices = array_merge( array_keys( $below ), [ 'desktop' ], array_keys( $above ) );

		// Desktop is the base that every other device falls back to. The
		// max-width devices then inherit down from it and widescreen inherits up,
		// which is how Elementor's own responsive values cascade.
		$resolved = [];
		$base     = [
			'slidesPerView'  => $this->get_slider_number( $settings, 'slides_to_show', 'desktop', 4 ),
			'slidesPerGroup' => $this->get_slider_number( $settings, 'slides_to_scroll', 'desktop', 1 ),
			'spaceBetween'   => $this->get_slider_size( $settings, 'column_gap', 'desktop', 10 ),
		];

		$resolved['desktop'] = $base;

		$chains = [
			array_reverse( array_keys( $below ) ), // Widest max-width device first.
			array_keys( $above ),                  // Narrowest min-width device first.
		];

		foreach ( $chains as $chain ) {
			$inherited = $base;

			foreach ( $chain as $device ) {
				$inherited = [
					'slidesPerView'  => $this->get_slider_number( $settings, 'slides_to_show', $device, $inherited['slidesPerView'] ),
					'slidesPerGroup' => $this->get_slider_number( $settings, 'slides_to_scroll', $device, $inherited['slidesPerGroup'] ),
					'spaceBetween'   => $this->get_slider_size( $settings, 'column_gap', $device, $inherited['spaceBetween'] ),
				];

				$resolved[ $device ] = $inherited;
			}
		}

		$breakpoints = [];
		$min_width   = 0;

		foreach ( $devices as $device ) {
			if ( isset( $above[ $device ] ) ) {
				// A min-width breakpoint starts at its own value.
				$min_width = $above[ $device ]->get_value();
			}

			$breakpoints[ $min_width ] = $resolved[ $device ];

			if ( isset( $below[ $device ] ) ) {
				// A max-width breakpoint hands over one pixel later.
				$min_width = $below[ $device ]->get_value() + 1;
			}
		}

		return [
			'desktop'     => $resolved['desktop'],
			'breakpoints' => $breakpoints,
		];
	}

	/**
	 * Read one device's value from a responsive number control.
	 *
	 * @since 3.0.0
	 * @access protected
	 * @param array  $settings Widget settings.
	 * @param string $key      Base control name.
	 * @param string $device   Device name, or 'desktop' for the base key.
	 * @param int    $fallback Value to inherit when this device sets none.
	 * @return int
	 */
	protected function get_slider_number( $settings, $key, $device, $fallback ) {
		$setting_key = ( 'desktop' === $device ) ? $key : $key . '_' . $device;

		// Custom breakpoint variants only exist once that breakpoint is enabled.
		if ( ! empty( $settings[ $setting_key ] ) ) {
			return absint( $settings[ $setting_key ] );
		}

		return $fallback;
	}

	/**
	 * Read one device's size from a responsive slider control.
	 *
	 * @since 3.0.0
	 * @access protected
	 * @param array  $settings Widget settings.
	 * @param string $key      Base control name.
	 * @param string $device   Device name, or 'desktop' for the base key.
	 * @param int    $fallback Value to inherit when this device sets none.
	 * @return int
	 */
	protected function get_slider_size( $settings, $key, $device, $fallback ) {
		$setting_key = ( 'desktop' === $device ) ? $key : $key . '_' . $device;

		if ( ! empty( $settings[ $setting_key ]['size'] ) ) {
			return absint( $settings[ $setting_key ]['size'] );
		}

		return $fallback;
	}

	/**
	 * Render Query.
	 *
	 * @since 1.1.0
	 */
	public function render_query() {

		$settings = $this->get_skin_settings();

		$this->parent->query_posts( $settings );

		self::$query = $this->parent->get_query();
	}

	/**
	 * Render loop required arguments.
	 *
	 * @since 1.1.0
	 */
	public function render_loop_args() {

		$query = $this->parent->get_query();

		global $woocommerce_loop;

		$settings = $this->get_skin_settings();

		if ( 'grid' === $settings['products_layout_type'] ) {
			$woocommerce_loop['columns'] = (int) $settings['products_columns'];

			if ( 'main' !== $settings['source'] ) {
				if ( '' !== $settings['pagination_type'] ) {
					/* Pagination */
					$paged = $this->parent->get_ajax_paged( get_query_var( 'paged' ) );

					// Same limit the query used, so the page count always matches.
					$per_page = $this->parent->get_products_per_page( $settings );

					$woocommerce_loop['paged']        = $paged;
					$woocommerce_loop['total']        = $query->found_posts;
					$woocommerce_loop['post_count']   = $query->post_count;
					$woocommerce_loop['per_page']     = $per_page;
					$woocommerce_loop['total_pages']  = ceil( $query->found_posts / $per_page );
					$woocommerce_loop['current_page'] = $paged;
				}
			}

			$this->parent->add_render_attribute(
				'inner', [
					'class' => [
						' columns-' . $woocommerce_loop['columns'],
					],
				]
			);
		}
	}

	/**
	 * Pagination Structure.
	 *
	 * @since 1.1.0
	 */
	public function render_pagination_structure() {

		$settings = $this->get_skin_settings();

		if ( 'grid' === $settings['products_layout_type'] ) {
			if ( '' !== $settings['pagination_type'] ) {
				add_filter( 'wc_get_template', [ $this, 'woo_pagination_template' ], 10, 5 );
				add_filter( 'pp_woocommerce_pagination_args', [ $this, 'woo_pagination_options' ] );
				woocommerce_pagination();
				remove_filter( 'pp_woocommerce_pagination_args', [ $this, 'woo_pagination_options' ] );
				remove_filter( 'wc_get_template', [ $this, 'woo_pagination_template' ], 10, 5 );
			}
		}
	}

	/**
	 * Render wrapper start.
	 *
	 * @since 1.1.0
	 */
	public function render_wrapper_start() {
		global $product;

		$settings = $this->get_skin_settings();

		$skin = $this->get_id();
		$page_id = 0;

		if ( null !== \Elementor\Plugin::$instance->documents->get_current() ) {
			$page_id = \Elementor\Plugin::$instance->documents->get_current()->get_main_id();
		}

		$product_id = ( is_product() ) ? ( $product->get_id() ) : 0;

		$this->parent->add_render_attribute(
			'wrapper', [
				'class' => [
					'pp-woocommerce',
					'pp-woo-products-' . $settings['products_layout_type'],
					'pp-woo-skin-' . $this->get_id(),
					'pp-woo-query-' . $settings['source'],
				],
				'data-page'        => $page_id,
				'data-skin'        => $skin,
				'data-product-id' => $product_id,
			]
		);

		if ( 'slider' === $settings['products_layout_type'] ) {
			$this->parent->add_render_attribute( 'wrapper', 'class', 'swiper-container-wrap' );

			if ( $settings['dots_position'] ) {
				$this->parent->add_render_attribute( 'wrapper', 'class', 'swiper-container-wrap-dots-' . $settings['dots_position'] );
			}
		}

		$this->set_slider_attr();

		echo '<div ' . wp_kses_post( $this->parent->get_render_attribute_string( 'wrapper' ) ) . '>';
	}

	/**
	 * Render wrapper end.
	 *
	 * @since 1.1.0
	 */
	public function render_wrapper_end() {
		echo '</div>';
	}

	/**
	 * Render inner container start.
	 *
	 * @since 1.1.0
	 */
	public function render_inner_start() {
		$settings = $this->get_skin_settings();

		// The pp-woo-product__column-* classes that used to be added here had no
		// rule in any stylesheet, control selector or script. Columns come from
		// the elementor-grid%s- prefix class and the columns-N class below.
		$this->parent->add_render_attribute(
			'inner', [
				'class' => [
					'pp-woo-products-inner',
				],
			]
		);

		if ( '' !== $settings['products_hover_style'] ) {
			$this->parent->add_render_attribute(
				'inner', [
					'class' => [
						'pp-woo-product__hover-' . $settings['products_hover_style'],
					],
				]
			);
		}

		if ( 'slider' === $settings['products_layout_type'] ) {
			$this->parent->add_render_attribute(
				'inner', [
					'class' => [
						'pp-swiper-slider',
						'swiper'
					],
				]
			);

			if ( is_rtl() ) {
				$this->parent->add_render_attribute( 'inner', 'dir', 'rtl' );
			}
		}

		echo '<div ' . wp_kses_post( $this->parent->get_render_attribute_string( 'inner' ) ) . '>';
	}

	/**
	 * Render inner container end.
	 *
	 * @since 1.1.0
	 */
	public function render_inner_end() {
		echo '</div>';
	}

	/**
	 * Render woo loop start.
	 *
	 * @since 1.1.0
	 */
	public function render_woo_loop_start() {
		$settings = $this->get_skin_settings();

		include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/loop/loop-start.php';
	}

	/**
	 * Swap the add to cart label for the one set on the widget.
	 *
	 * Filter callback for 'woocommerce_product_add_to_cart_text', added only
	 * while the loop runs.
	 *
	 * @access public
	 * @param string     $text    Default button text.
	 * @param WC_Product $product Product being rendered.
	 * @return string Button text.
	 */
	public function add_to_cart_button_text( $text, $product ) {
		if ( 'simple' === $product->get_type() ) {
			$text = $product->is_purchasable() && $product->is_in_stock() ? self::$add_to_cart_text : self::$read_more_text;
		}

		if ( 'variable' === $product->get_type() ) {
			$text = $product->is_purchasable() ? self::$select_options_text : self::$read_more_text;
		}

		if ( 'grouped' === $product->get_type() ) {
			$text = self::$view_products_text;
		}

		return $text;
	}

	/**
	 * Render woo loop.
	 *
	 * @since 1.1.0
	 */
	public function render_woo_loop() {
		$settings = $this->get_skin_settings();

		$query = $this->parent->get_query();

		if ( 'yes' === $settings['show_add_cart'] && 'yes' === $settings['change_add_to_cart_text'] ) {
			self::$add_to_cart_text = $settings['add_to_cart_simple_text'] ? $settings['add_to_cart_simple_text'] : esc_html__( 'Add to cart', 'powerpack' );
			self::$select_options_text = $settings['add_to_cart_variable_text'] ? $settings['add_to_cart_variable_text'] : esc_html__( 'Select options', 'powerpack' );
			self::$view_products_text = $settings['add_to_cart_group_text'] ? $settings['add_to_cart_group_text'] : esc_html__( 'View products', 'powerpack' );
			self::$read_more_text = $settings['add_to_cart_read_more_text'] ? $settings['add_to_cart_read_more_text'] : esc_html__( 'Read more', 'powerpack' );

			add_filter( 'woocommerce_product_add_to_cart_text', [ $this, 'add_to_cart_button_text' ], 10, 2 );
		}

		while ( $query->have_posts() ) :
			$query->the_post();
			$this->render_woo_loop_template();
		endwhile;

		if ( 'yes' === $settings['show_add_cart'] && 'yes' === $settings['change_add_to_cart_text'] ) {
			remove_filter( 'woocommerce_product_add_to_cart_text', [ $this, 'add_to_cart_button_text' ], 10, 2 );
		}
	}

	/**
	 * Render woo default template.
	 *
	 * @since 1.1.0
	 */
	public function render_woo_loop_template() {

		$settings = $this->get_skin_settings();

		include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/content-product-skin-1.php';
	}
	/**
	 * Render woo loop end.
	 *
	 * @since 1.1.0
	 */
	public function render_woo_loop_end() {
		include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/loop/loop-end.php';
	}

	/**
	 * Render reset loop.
	 *
	 * @since 1.1.0
	 */
	public function render_reset_loop() {

		woocommerce_reset_loop();

		wp_reset_postdata();
	}

	/**
	 * Quick View.
	 *
	 * @since 1.3.3
	 * @access public
	 */
	public function quick_view_modal() {

		$settings = $this->get_skin_settings();

		$quick_view_type = $settings['quick_view_type'];

		if ( '' !== $quick_view_type ) {
			wp_enqueue_script( 'wc-add-to-cart-variation' );
			wp_enqueue_script( 'flexslider' );

			$widget_id = $this->parent->get_id();

			include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/quick-view-modal.php';
		}
	}

	/**
	 * Get Best Selling Product for Badge.
	 *
	 * @since 1.3.3
	 * @access public
	 */
	public function is_best_selling_product( $product_id ) {

		$settings = $this->get_skin_settings();
		$number_of_sales = $settings['number_of_sales'];

		if ( empty( $number_of_sales ) ) {
			return false;
		}

		$total_sales = get_post_meta( $product_id, 'total_sales', true );

		if ( ! $total_sales || empty( $total_sales ) ) {
			return false;
		}

		return $total_sales >= $number_of_sales;
	}

	/**
	 * Get Top Rated Product for Badge.
	 *
	 * @since 1.3.3
	 * @access public
	 */
	public function is_top_rated_product( $product_id ) {

		$settings = $this->get_skin_settings();
		$rating = $settings['number_of_ratings'];

		if ( empty( $rating ) ) {
			return false;
		}

		$total_rating = get_post_meta( $product_id, '_wc_average_rating', true );

		if ( ! $total_rating || empty( $total_rating ) ) {
			return false;
		}

		return $total_rating >= $rating;
	}

	/**
	 * Render product body output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 2.4.0
	 * @access protected
	 */
	public function render_ajax_product_body( $widget ) {
		ob_start();

		self::$settings = $widget->get_settings();

		$this->render_query();

		$this->render_loop_args();
		$this->render_woo_loop_start();
			$this->render_woo_loop();
		$this->render_woo_loop_end();

		return ob_get_clean();
	}

	/**
	 * Render product pagination HTML via AJAX call.
	 *
	 * @param array|string $widget    Widget object.
	 *
	 * @since 2.4.0
	 * @access public
	 */
	public function render_ajax_pagination( $widget ) {
		ob_start();

		self::$settings = $widget->get_settings();

		$this->render_query();

		$this->render_pagination_structure();

		return ob_get_clean();
	}

	/**
	 * Print an action icon, as an SVG or a font icon depending on the site.
	 *
	 * @access protected
	 * @param string $network_name Font Awesome icon name, without the fa- prefix.
	 */
	protected static function render_product_icon( $network_name ) {
		$network_icon_data = self::get_network_icon_data( $network_name );

		if ( PP_Helper::is_feature_active( 'e_font_icon_svg' ) ) {
			$icon = Icons_Manager::render_font_icon( $network_icon_data );
		} else {
			$icon = sprintf( '<i class="%s" aria-hidden="true"></i>', $network_icon_data['value'] );
		}

		\Elementor\Utils::print_unescaped_internal_string( $icon );
	}

	/**
	 * Render team member carousel dots output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render_dots() {
		$settings = $this->get_skin_settings();

		if ( 'slider' !== $settings['products_layout_type'] ) {
			return;
		}

		if ( 'yes' === $settings['carousel_pagination'] ) {
			?>
			<!-- Add Pagination -->
			<div class="swiper-pagination swiper-pagination-<?php echo esc_attr( $this->parent->get_id() ); ?>"></div>
			<?php
		}
	}

	/**
	 * Render team member carousel arrows output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render_arrows() {
		$settings = $this->get_skin_settings();

		if ( 'slider' !== $settings['products_layout_type'] ) {
			return;
		}

		$migration_allowed = Icons_Manager::is_migration_allowed();

		if ( ! isset( $settings['arrow'] ) && ! Icons_Manager::is_migration_allowed() ) {
			// add old default.
			$settings['arrow'] = 'fa fa-angle-right';
		}

		$has_icon = ! empty( $settings['arrow'] );

		if ( ! $has_icon && ! empty( $settings['select_arrow']['value'] ) ) {
			$has_icon = true;
		}

		if ( ! empty( $settings['arrow'] ) ) {
			$this->parent->add_render_attribute( 'arrow-icon', 'class', $settings['arrow'] );
			$this->parent->add_render_attribute( 'arrow-icon', 'aria-hidden', 'true' );
		}

		$migrated = isset( $settings['__fa4_migrated']['select_arrow'] );
		$is_new = ! isset( $settings['arrow'] ) && $migration_allowed;

		if ( 'yes' === $settings['arrows'] ) {
			if ( $has_icon ) {
				if ( $is_new || $migrated ) {
					$next_arrow = $settings['select_arrow'];
					$prev_arrow = str_replace( 'right', 'left', $settings['select_arrow'] );
				} else {
					$next_arrow = $settings['arrow'];
					$prev_arrow = str_replace( 'right', 'left', $settings['arrow'] );
				}
			} else {
				$next_arrow = 'fa fa-angle-right';
				$prev_arrow = 'fa fa-angle-left';
			}

			if ( ! empty( $settings['arrow'] ) || ( ! empty( $settings['select_arrow']['value'] ) && $is_new ) ) { ?>
				<button type="button" class="pp-slider-arrow elementor-swiper-button-prev swiper-button-prev-<?php echo esc_attr( $this->parent->get_id() ); ?>" aria-label="<?php echo esc_attr__( 'Previous slide', 'powerpack' ); ?>">
					<?php if ( $is_new || $migrated ) :
						Icons_Manager::render_icon( $prev_arrow, [ 'aria-hidden' => 'true' ] );
					else : ?>
						<i <?php $this->parent->print_render_attribute_string( 'arrow-icon' ); ?>></i>
					<?php endif; ?>
				</button>
				<button type="button" class="pp-slider-arrow elementor-swiper-button-next swiper-button-next-<?php echo esc_attr( $this->parent->get_id() ); ?>" aria-label="<?php echo esc_attr__( 'Next slide', 'powerpack' ); ?>">
					<?php if ( $is_new || $migrated ) :
						Icons_Manager::render_icon( $next_arrow, [ 'aria-hidden' => 'true' ] );
					else : ?>
						<i <?php $this->parent->print_render_attribute_string( 'arrow-icon' ); ?>></i>
					<?php endif; ?>
				</button>
			<?php }
		}
	}

	/**
	 * Get no products found message.
	 *
	 * Returns the no products found message HTML.
	 *
	 * @since 2.7.7
	 * @access public
	 */
	public function render_empty() {
		$settings = $this->get_skin_settings();
		?>
		<div class="pp-wooproducts-empty">
			<p><?php echo wp_kses_post( $settings['no_products_message'] ); ?></p>
		</div>
		<?php
	}

	/**
	 * Render Content.
	 *
	 * @since 1.3.3
	 * @access protected
	 */
	public function render() {
		$settings = $this->get_skin_settings();
		$this->render_query();

		$query = $this->parent->get_query();

		if ( ! $query->have_posts() ) {
			$this->render_empty();
			return;
		}

		$this->render_loop_args();
		$this->render_wrapper_start();
			$this->render_inner_start();
				$this->render_woo_loop_start();
					$this->render_woo_loop();
				$this->render_woo_loop_end();
				$this->render_pagination_structure();
				$this->render_reset_loop();
			$this->render_inner_end();
			if ( 'slider' === $settings['products_layout_type'] ) {
				$this->render_dots();
				$this->render_arrows();
			}
		$this->render_wrapper_end();

		$this->quick_view_modal();

	}
}
