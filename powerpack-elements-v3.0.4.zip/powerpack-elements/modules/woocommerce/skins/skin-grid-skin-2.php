<?php
/**
 * PowerPack WooCommerce Skin Grid - Classic.
 *
 * @package PowerPack
 */

namespace PowerpackElements\Modules\Woocommerce\Skins;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Skin_Grid_Skin_2
 *
 * @property Products $parent
 */
class Skin_Grid_Skin_2 extends Skin_Grid_Base {

	/**
	 * Get ID.
	 *
	 * @since 1.3.3
	 * @access public
	 */
	public function get_id() {
		return 'skin-2';
	}

	/**
	 * Get title.
	 *
	 * @since 1.3.3
	 * @access public
	 */
	public function get_title() {
		return esc_html__( 'Skin 2', 'powerpack' );
	}

	/**
	 * Loop Template.
	 *
	 * @since 1.3.3
	 * @access public
	 */
	public function render_woo_loop_template() {

		$settings = $this->get_skin_settings();

		include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/content-product-skin-2.php';
	}
}
