<?php
/**
 * PowerPack WooCommerce Products.
 *
 * @package PowerPack
 */

namespace PowerpackElements\Modules\Woocommerce\Widgets;

use PowerpackElements\Base\Powerpack_Widget;
use PowerpackElements\Classes\PP_Admin_Settings;
use PowerpackElements\Classes\PP_Config;
use PowerpackElements\Classes\PP_Posts_Query_Builder;
use PowerpackElements\Classes\PP_Helper;
use PowerpackElements\Classes\PP_Posts_Helper;

use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Image_Size;
use PowerpackElements\Modules\Woocommerce\Skins;

if ( ! defined( 'ABSPATH' ) ) {
	exit;   // Exit if accessed directly.
}

/**
 * Class Woo_Products.
 */
class Woo_Products extends Powerpack_Widget {

	/**
	 * Number of products queried when the per page setting is missing or invalid.
	 *
	 * Matches the default of the 'products_per_page' control.
	 *
	 * @since 3.0.0
	 */
	const DEFAULT_PRODUCTS_PER_PAGE = 8;

	/**
	 * Products Query
	 *
	 * @var query
	 */
	private $query = null;

	/**
	 * Has Template content
	 *
	 * @var _has_template_content
	 */
	protected $_has_template_content = false;

	/**
	 * Retrieve Woo - Products widget categories.
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return parent::get_woo_categories();
	}

	/**
	 * Retrieve Woo Product Grid Widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Woo_Products' );
	}

	/**
	 * Retrieve Woo Product Grid Widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Woo_Products' );
	}

	/**
	 * Retrieve Woo Product Grid Widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Woo_Products' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 1.4.13.1
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Woo_Products' );
	}

	/**
	 * Get Script Depends.
	 *
	 * @access public
	 *
	 * @return array scripts.
	 */
	public function get_script_depends() {
		if ( PP_Helper::is_edit_mode() || PP_Helper::is_preview_mode() ) {
			return [
				'imagesloaded',
				'swiper',
				'pp-woo-product',
				'flexslider'
			];
		}

		$settings = $this->get_settings_for_display();
		$scripts  = [];

		if ( 'yes' === $settings['quick_view_type'] ) {
			array_push( $scripts, 'imagesloaded', 'flexslider', 'pp-woo-product' );
		}

		if ( 'slider' === $settings['products_layout_type'] ) {
			array_push( $scripts, 'swiper', 'pp-woo-product' );
		}

		// The AJAX pagination handler lives in the same script. Without it the
		// page links fall through to the main query and paginate the wrong loop.
		if ( 'grid' === $settings['products_layout_type'] && '' !== $settings['pagination_type'] ) {
			$scripts[] = 'pp-woo-product';
		}

		// Skins 2-5 render the product actions bar, whose add to cart button is
		// wired up by the same script.
		if ( in_array( $this->get_current_skin_id(), [ 'skin-2', 'skin-3', 'skin-4', 'skin-5' ], true ) ) {
			$scripts[] = 'pp-woo-product';
		}

		return array_values( array_unique( $scripts ) );
	}

	/**
	 * Retrieve the list of styles the Woo - Products widget depended on.
	 *
	 * Used to set style dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_style_depends() {
		if ( PP_Helper::is_edit_mode() || PP_Helper::is_preview_mode() ) {
			return [ 'e-swiper', 'pp-swiper', 'pp-woocommerce' ];
		}

		$settings = $this->get_settings_for_display();
		$styles   = [ 'pp-woocommerce' ];

		if ( Icons_Manager::is_migration_allowed() ) {
			array_push( $styles, 'elementor-icons-fa-solid', 'elementor-icons-fa-brands' );
		}

		if ( 'slider' === $settings['products_layout_type'] ) {
			array_push( $styles, 'e-swiper', 'pp-swiper' );
		}

		return $styles;
	}

	/**
	 * Whether Elementor should wrap the widget in its own container.
	 *
	 * The widget renders its own wrapper, so the extra one is dropped whenever
	 * optimized markup is switched on.
	 *
	 * @access public
	 *
	 * @return bool
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register Get Query.
	 *
	 * @access protected
	 */
	public function get_query() {
		return $this->query;
	}

	/**
	 * Register Woo - Products Skins.
	 *
	 * @since 2.2.7
	 * @access protected
	 */
	protected function register_skins() {
		$this->add_skin( new Skins\Skin_Grid_Skin_1( $this ) );
		$this->add_skin( new Skins\Skin_Grid_Skin_2( $this ) );
		$this->add_skin( new Skins\Skin_Grid_Skin_3( $this ) );
		$this->add_skin( new Skins\Skin_Grid_Skin_4( $this ) );
		$this->add_skin( new Skins\Skin_Grid_Skin_5( $this ) );
	}

	/**
	 * Register Woo - Products widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function register_controls() {
		/* Content Tab */
		$this->register_content_layout_controls();
		$this->register_content_slider_controls();
		$this->register_content_query_controls();
		$this->register_content_content_controls();
		$this->register_content_product_badges_controls();
		$this->register_image_controls();
		$this->register_quick_view_controls();
		$this->register_add_to_wishlist_controls();
		$this->register_content_pagination_controls();

		/* Style Tab */
		$this->register_style_layout_controls();
		$this->register_style_content_controls();
		$this->register_style_product_badges_controls();
		$this->register_quick_view_style_controls();
		$this->register_lightbox_style_controls();

		$this->register_style_pagination_controls();
		$this->register_style_arrows_controls();
		$this->register_style_dots_controls();
	}

	/**
	 * Register Woo Products Layout Controls.
	 *
	 * @access protected
	 */
	protected function register_content_layout_controls() {

		$this->start_controls_section(
			'section_layout',
			[
				'label' => esc_html__( 'Layout', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'products_layout_type',
			[
				'label'     => esc_html__( 'Layout', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'grid',
				'options'   => [
					'grid'   => esc_html__( 'Grid', 'powerpack' ),
					'slider' => esc_html__( 'Carousel', 'powerpack' ),
				],
				'condition' => [
					'_skin' => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
				],
			]
		);

		$this->add_responsive_control(
			'products_columns',
			[
				'label'              => esc_html__( 'Columns', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => '4',
				'tablet_default'     => '3',
				'mobile_default'     => '1',
				'options'            => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
				],
				'prefix_class'       => 'elementor-grid%s-',
				// The column count also lands in markup: the columns-N class on
				// ul.products and the carousel's slidesPerView. A control carrying
				// only prefix_class never re-renders, so that markup would go stale
				// in the editor until a refresh.
				'render_type'        => 'template',
				'condition'          => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
				],
			]
		);

		$this->add_control(
			'products_per_page',
			[
				'label'     => esc_html__( 'Products Per Page', 'powerpack' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => '8',
				'min'       => 1,
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'source!' => 'main',
				],
			]
		);

		$this->add_control(
			'slider_products_per_page',
			[
				'label'     => esc_html__( 'Total Products', 'powerpack' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => '8',
				'min'       => 1,
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					// Matches products_per_page: the main query sets its own limit.
					'source!'              => 'main',
				],
			]
		);

		$this->add_responsive_control(
			'slides_to_show',
			[
				'label'          => esc_html__( 'Products to Show', 'powerpack' ),
				'type'           => Controls_Manager::NUMBER,
				'default'        => 4,
				'tablet_default' => 3,
				'mobile_default' => 1,
				'condition'      => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
				],
			]
		);

		$this->add_responsive_control(
			'slides_to_scroll',
			[
				'label'          => esc_html__( 'Products to Scroll', 'powerpack' ),
				'type'           => Controls_Manager::NUMBER,
				'default'        => 1,
				'tablet_default' => 1,
				'mobile_default' => 1,
				'condition'      => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register Carousel Controls.
	 *
	 * @access protected
	 */
	protected function register_content_slider_controls() {
		$this->start_controls_section(
			'section_carousel_options',
			[
				'label'     => esc_html__( 'Carousel Settings', 'powerpack' ),
				'type'      => Controls_Manager::SECTION,
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
				],
			]
		);

		$this->add_control(
			'transition_speed',
			[
				'label'       => esc_html__( 'Transition Speed', 'powerpack' ),
				'description' => esc_html__( 'Duration of transition between slides (in ms)', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 400,
				'condition'   => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
				],
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'              => esc_html__( 'Autoplay', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'separator'          => 'before',
				'condition'          => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
				],
			]
		);

		$this->add_control(
			'autoplay_speed',
			[
				'label'              => esc_html__( 'Autoplay Speed', 'powerpack' ),
				'type'               => Controls_Manager::NUMBER,
				'default'            => 2000,
				'min'                => 500,
				'max'                => 5000,
				'step'               => 1,
				'condition'          => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'autoplay'             => 'yes',
				],
			]
		);

		$this->add_control(
			'grab_cursor',
			[
				'label'              => esc_html__( 'Grab Cursor', 'powerpack' ),
				'description'        => esc_html__( 'Shows grab cursor when you hover over the slider', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => '',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'separator'          => 'before',
				'condition'          => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
				],
			]
		);

		$this->add_control(
			'pause_on_hover',
			[
				'label'        => esc_html__( 'Pause on Hover', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'autoplay'             => 'yes',
				],
			]
		);

		$this->add_control(
			'infinite',
			[
				'label'        => esc_html__( 'Infinite Loop', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
				],
			]
		);

		$this->add_control(
			'navigation_heading',
			[
				'label'     => esc_html__( 'Navigation', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
				],
			]
		);

		$this->add_control(
			'arrows',
			[
				'label'              => esc_html__( 'Arrows', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'condition'          => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
				],
			]
		);

		$this->add_control(
			'carousel_pagination',
			[
				'label'              => esc_html__( 'Dots', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'condition'          => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register Woo Products Filter Controls.
	 *
	 * @access protected
	 */
	protected function register_content_query_controls() {

		$this->start_controls_section(
			'section_query',
			[
				'label' => esc_html__( 'Query', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'source',
			[
				'label'   => esc_html__( 'Source', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'all',
				'options' => [
					'all'             => esc_html__( 'All Products', 'powerpack' ),
					'custom'          => esc_html__( 'Custom Query', 'powerpack' ),
					'manual'          => esc_html__( 'Manual Selection', 'powerpack' ),
					'main'            => esc_html__( 'Main Query', 'powerpack' ),
					'related'         => esc_html__( 'Related Products', 'powerpack' ),
					'upsells'         => esc_html__( 'Upsells', 'powerpack' ),
					'cross_sells'     => esc_html__( 'Cross-Sells', 'powerpack' ),
					'recently_viewed' => esc_html__( 'Recently Viewed', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'upsells_notice',
			[
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'Note: The Upsells Query is available when creating a Single Product template.', 'powerpack' ),
				'content_classes' => 'pp-editor-info',
				'condition'       => [
					'source' => 'upsells',
				],
			]
		);

		$this->add_control(
			'cross_sells_notice',
			[
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'Note: The Cross-Sells Query is available when creating a Cart page.', 'powerpack' ),
				'content_classes' => 'pp-editor-info',
				'condition'       => [
					'source' => 'cross_sells',
				],
			]
		);

		if ( ! PP_Admin_Settings::get_option( 'pp_woo_recently_viewed_tracking' ) ) {
			$settings_url = admin_url( 'admin.php?page=powerpack-settings&tab=woo_template_manager' );
			$this->add_control(
				'recently_viewed_tracking_notice',
				[
					'type'            => Controls_Manager::RAW_HTML,
					'raw'             => sprintf(
						/* translators: %s: URL to PowerPack WooCommerce settings page */
						__( 'Enable <strong>Recently Viewed Products Tracking</strong> option in <a href="%s" target="_blank">PowerPack &rarr; WooCommerce Builder</a> settings to show recently viewed products.', 'powerpack' ),
						esc_url( $settings_url )
					),
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
					'condition'       => [
						'source' => 'recently_viewed',
					],
				]
			);
		}

		$this->add_control(
			'category_filter_rule',
			[
				'label'     => esc_html__( 'Category Filter Rule', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'IN',
				'options'   => [
					'IN'     => esc_html__( 'Match Categories', 'powerpack' ),
					'NOT IN' => esc_html__( 'Exclude Categories', 'powerpack' ),
				],
				'condition' => [
					'source' => 'custom',
				],
			]
		);
		$this->add_control(
			'category_filter',
			[
				'label'       => esc_html__( 'Select Categories', 'powerpack' ),
				'type'          => 'pp-query',
				'post_type'     => '',
				'options'       => [],
				'label_block'   => true,
				'multiple'      => true,
				'query_type'    => 'terms-slug',
				'object_type'   => 'product_cat',
				'include_type'  => true,
				'condition'   => [
					'source' => 'custom',
				],
			]
		);
		$this->add_control(
			'tag_filter_rule',
			[
				'label'     => esc_html__( 'Tag Filter Rule', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'IN',
				'options'   => [
					'IN'     => esc_html__( 'Match Tags', 'powerpack' ),
					'NOT IN' => esc_html__( 'Exclude Tags', 'powerpack' ),
				],
				'condition' => [
					'source' => 'custom',
				],
			]
		);
		$this->add_control(
			'tag_filter',
			[
				'label'       => esc_html__( 'Select Tags', 'powerpack' ),
				'type'          => 'pp-query',
				'post_type'     => '',
				'options'       => [],
				'label_block'   => true,
				'multiple'      => true,
				'query_type'    => 'terms-slug',
				'object_type'   => 'product_tag',
				'include_type'  => true,
				'condition'   => [
					'source' => 'custom',
				],
			]
		);
		$this->add_control(
			'offset',
			[
				'label'       => esc_html__( 'Offset', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 0,
				'description' => esc_html__( 'Number of post to displace or pass over.', 'powerpack' ),
				'condition'   => [
					'source' => 'custom',
				],
			]
		);

		$this->add_control(
			'query_manual_ids',
			[
				'label'     => esc_html__( 'Select Products', 'powerpack' ),
				'type'      => 'pp-query-posts',
				'post_type' => 'product',
				'multiple'  => true,
				'condition' => [
					'source' => 'manual',
				],
			]
		);

		/* Exclude */
		$this->add_control(
			'query_exclude',
			[
				'label'     => esc_html__( 'Exclude', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'source!' => [ 'manual', 'main', 'related', 'upsells', 'cross_sells', 'recently_viewed' ],
				],
			]
		);
		$this->add_control(
			'query_exclude_ids',
			[
				'label'       => esc_html__( 'Select Products', 'powerpack' ),
				'type'        => 'pp-query-posts',
				'post_type'   => 'product',
				'multiple'    => true,
				'description' => esc_html__( 'Select products to exclude from the query.', 'powerpack' ),
				'condition'   => [
					'source!' => [ 'manual', 'main', 'related', 'upsells', 'cross_sells', 'recently_viewed' ],
				],
			]
		);
		$this->add_control(
			'query_exclude_current',
			[
				'label'        => esc_html__( 'Exclude Current Product', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => '',
				'description'  => esc_html__( 'Enable this option to remove current product from the query.', 'powerpack' ),
				'condition'    => [
					'source!' => [ 'manual', 'main', 'related', 'upsells', 'cross_sells', 'recently_viewed' ],
				],
			]
		);

		/* Advanced Filter */
		$this->add_control(
			'query_advanced',
			[
				'label'     => esc_html__( 'Advanced', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'source!' => [ 'main' ],
				],
			]
		);
		$this->add_control(
			'filter_by',
			[
				'label'     => esc_html__( 'Filter By', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''             => esc_html__( 'None', 'powerpack' ),
					'featured'     => esc_html__( 'Featured', 'powerpack' ),
					'sale'         => esc_html__( 'Sale', 'powerpack' ),
					'top_rated'    => esc_html__( 'Top Rated', 'powerpack' ),
					'best_selling' => esc_html__( 'Best Selling', 'powerpack' ),
				],
				'condition' => [
					'source!' => [ 'main', 'related', 'upsells', 'cross_sells', 'recently_viewed' ],
				],
			]
		);
		$this->add_control(
			'orderby',
			[
				'label'     => esc_html__( 'Order by', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'date',
				'options'   => [
					'date'       => esc_html__( 'Date', 'powerpack' ),
					'title'      => esc_html__( 'Title', 'powerpack' ),
					'price'      => esc_html__( 'Price', 'powerpack' ),
					'popularity' => esc_html__( 'Popularity', 'powerpack' ),
					'rating'     => esc_html__( 'Rating', 'powerpack' ),
					'rand'       => esc_html__( 'Random', 'powerpack' ),
					'menu_order' => esc_html__( 'Menu Order', 'powerpack' ),
					'post__in'   => esc_html__( 'Manual Selection', 'powerpack' ),
				],
				'condition' => [
					'source!' => [ 'main', 'recently_viewed' ],
				],
			]
		);
		$this->add_control(
			'order',
			[
				'label'     => esc_html__( 'Order', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'desc',
				'options'   => [
					'desc' => esc_html__( 'Descending', 'powerpack' ),
					'asc'  => esc_html__( 'Ascending', 'powerpack' ),
				],
				'condition' => [
					'source!'  => [ 'main' ],
					'orderby!' => 'post__in',
				],
			]
		);

		$this->add_control(
			'query_id',
			[
				'label'       => esc_html__( 'Query ID', 'powerpack' ),
				'description' => esc_html__( 'Give your Query a custom unique id to allow server side filtering', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'separator'   => 'before',
				'ai'          => [
					'active' => false,
				],
			]
		);

		$this->add_control(
			'no_products_heading',
			[
				'label'     => esc_html__( 'If No Products Found', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'no_products_message',
			[
				'label'   => esc_html__( 'Display Message', 'powerpack' ),
				'type'    => Controls_Manager::TEXTAREA,
				'rows'    => 3,
				'default' => esc_html__( 'No products were found matching your selection.', 'powerpack' ),
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register Content Control Section.
	 *
	 * @access protected
	 */
	protected function register_content_content_controls() {

		$this->start_controls_section(
			'section_content_field',
			[
				'label' => esc_html__( 'Content', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_category',
			[
				'label'        => esc_html__( 'Category', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_title',
			[
				'label'        => esc_html__( 'Title', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'title_html_tag',
			[
				'label'   => esc_html__( 'Title HTML Tag', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1'   => esc_html__( 'H1', 'powerpack' ),
					'h2'   => esc_html__( 'H2', 'powerpack' ),
					'h3'   => esc_html__( 'H3', 'powerpack' ),
					'h4'   => esc_html__( 'H4', 'powerpack' ),
					'h5'   => esc_html__( 'H5', 'powerpack' ),
					'h6'   => esc_html__( 'H6', 'powerpack' ),
					'div'  => esc_html__( 'div', 'powerpack' ),
					'span' => esc_html__( 'span', 'powerpack' ),
					'p'    => esc_html__( 'p', 'powerpack' ),
				],
				'condition' => [
					'show_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'link_title',
			[
				'label'        => esc_html__( 'Link Title to Product', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'show_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'link_title_target',
			[
				'label'        => esc_html__( 'Open Link in a New Tab?', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'    => [
					'show_title' => 'yes',
					'link_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'show_ratings',
			[
				'label'        => esc_html__( 'Ratings', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'separator'    => 'before',
			]
		);
		$this->add_control(
			'show_price',
			[
				'label'        => esc_html__( 'Price', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'show_short_desc',
			[
				'label'        => esc_html__( 'Short Description', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => '',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'show_add_cart',
			[
				'label'        => esc_html__( 'Add to Cart', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'change_add_to_cart_text',
			[
				'label'        => esc_html__( 'Change Button Text', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => '',
			]
		);

		$this->add_control(
			'add_to_cart_simple_text',
			[
				'label'       => esc_html__( 'Add to Cart Text', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'default'     => '',
				'description' => '',
				'condition'   => [
					'show_add_cart' => 'yes',
					'change_add_to_cart_text' => 'yes',
				],
			]
		);

		$this->add_control(
			'add_to_cart_variable_text',
			[
				'label'       => esc_html__( 'Select Options Text', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'default'     => '',
				'description' => '',
				'condition'   => [
					'show_add_cart' => 'yes',
					'change_add_to_cart_text' => 'yes',
				],
			]
		);

		$this->add_control(
			'add_to_cart_group_text',
			[
				'label'       => esc_html__( 'View Products Text', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'default'     => '',
				'description' => '',
				'condition'   => [
					'show_add_cart' => 'yes',
					'change_add_to_cart_text' => 'yes',
				],
			]
		);

		$this->add_control(
			'add_to_cart_read_more_text',
			[
				'label'       => esc_html__( 'Read More Text', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'default'     => '',
				'description' => '',
				'condition'   => [
					'show_add_cart' => 'yes',
					'change_add_to_cart_text' => 'yes',
				],
			]
		);

		$this->add_control(
			'out_of_stock_text',
			[
				'label'     => esc_html__( 'Out of Stock Text', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Out of Stock', 'powerpack' ),
				'separator' => 'before',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register Content Style Section.
	 *
	 * @access protected
	 */
	protected function register_style_content_controls() {

		$this->start_controls_section(
			'section_design_content',
			[
				'label' => esc_html__( 'Content', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'        => esc_html__( 'Alignment', 'powerpack' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'left'    => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'  => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'   => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justify', 'powerpack' ),
						'icon'  => 'eicon-text-align-justify',
					],
				],
				'default'      => 'left',
				'prefix_class' => 'pp-woo%s--align-',
			]
		);

		$this->add_control(
			'product_content_bg_color',
			[
				'label'     => esc_html__( 'Content Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-products-summary-wrap' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'product_content_padding',
			[
				'label'      => esc_html__( 'Content Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-products-summary-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'product_category_style',
			[
				'label'     => esc_html__( 'Category', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_category' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_category_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-woo-product-category, .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .product_meta' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_category' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'product_category_typography',
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'  => '{{WRAPPER}} .pp-woocommerce .pp-woo-product-category',
				'condition' => [
					'show_category' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'product_category_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-woo-product-category, .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .product_meta' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_category' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_title_style',
			[
				'label'     => esc_html__( 'Title', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_title_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-loop-product__link, {{WRAPPER}} .pp-woocommerce .woocommerce-loop-product__title, .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .product_title' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_title_hover_color',
			[
				'label'     => esc_html__( 'Hover Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-loop-product__link:hover .woocommerce-loop-product__title, .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .product_title:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_title' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'product_title_typography',
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector'  => '{{WRAPPER}} .pp-woocommerce .pp-loop-product__link, {{WRAPPER}} .pp-woocommerce .woocommerce-loop-product__title, .pp-quick-view-{{ID}} .woocommerce div.product .product_title',
				'condition' => [
					'show_title' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'product_title_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .woocommerce-loop-product__title, .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .product_title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_rating_style',
			[
				'label'     => esc_html__( 'Rating', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_ratings' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_rating_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .star-rating, {{WRAPPER}} .pp-woocommerce .star-rating::before, .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .star-rating, .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .star-rating:before' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_ratings' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'product_rating_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .star-rating, .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .woocommerce-product-rating' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_ratings' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_price_style',
			[
				'label'     => esc_html__( 'Price', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_price' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_price_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce li.product .price, .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .price' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_price' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'product_price_typography',
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'  => '{{WRAPPER}} .pp-woocommerce li.product .price, .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .price',
				'condition' => [
					'show_price' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'product_price_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce li.product .price, .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .price' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_price' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_short_desc_style',
			[
				'label'     => esc_html__( 'Short Description', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_short_desc' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_short_desc_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-woo-products-description, .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .woocommerce-product-details__short-description' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_short_desc' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'product_short_desc_typography',
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'  => '{{WRAPPER}} .pp-woocommerce .pp-woo-products-description',
				'condition' => [
					'show_short_desc' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'product_short_desc_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-woo-products-description, .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .woocommerce-product-details__short-description p:last-child' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_short_desc' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_add_cart_style',
			[
				'label'     => esc_html__( 'Add to Cart', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_add_cart' => 'yes',
					'_skin'         => [ 'skin-1' ],
				],
			]
		);

		$this->add_control(
			'product_actions_style',
			[
				'label'     => esc_html__( 'Product Actions', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_add_cart' => 'yes',
					'_skin'         => [ 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
				],
			]
		);

		$this->add_control(
			'actions_overlay_color',
			[
				'label'     => esc_html__( 'Overlay Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-skin-skin-5 .woocommerce-loop-product__link:before' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'_skin' => 'skin-5',
				],
			]
		);

		$this->add_responsive_control(
			'product_add_cart_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-woo-products-summary-wrap .button,
					{{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-action-item-wrap,
					.pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_add_cart' => 'yes',
					'_skin'         => [ 'skin-1', 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->start_controls_tabs( 'product_add_cart_tabs_style' );

		$this->start_controls_tab(
			'product_add_cart_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'show_add_cart' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_add_cart_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-woo-products-summary-wrap .button,
                    {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-action-item-wrap,
                    {{WRAPPER}} .pp-product-actions .pp-action-item,
                    .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .button' => 'color: {{VALUE}};',
					'{{WRAPPER}} .pp-product-actions .pp-action-item svg' => 'fill: {{VALUE}};',
				],
				'condition' => [
					'show_add_cart' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_view_cart_color',
			[
				'label'     => esc_html__( 'View Cart Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .added_to_cart,
					.pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .added_to_cart' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_add_cart' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'product_add_cart_background_color',
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'types'     => [ 'classic', 'gradient' ],
				'exclude'   => [ 'image' ],
				'selector'  => '{{WRAPPER}} .pp-woocommerce .pp-woo-products-summary-wrap .button,
                {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-action-item-wrap,
                .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .button',
				'condition' => [
					'show_add_cart' => 'yes',
					'_skin'         => [ 'skin-1', 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'product_add_cart_border',
				'label'     => esc_html__( 'Border', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-woocommerce .pp-woo-products-summary-wrap .button,
                {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-action-item-wrap,
                .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .button',
				'condition' => [
					'show_add_cart' => 'yes',
					'_skin'         => [ 'skin-1', 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->add_control(
			'product_add_cart_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-woo-products-summary-wrap .button,
                {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-action-item-wrap,
                .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'show_add_cart' => 'yes',
					'_skin'         => [ 'skin-1', 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->add_control(
			'product_actions_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-action-item-wrap,
                    .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .button' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'show_add_cart' => 'yes',
					'_skin'         => [ 'skin-2', 'skin-5' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'product_add_cart_typography',
				'selector'  => '{{WRAPPER}} .pp-woocommerce .pp-woo-products-summary-wrap .button, {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-action-item-wrap',
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'condition' => [
					'show_add_cart' => 'yes',
					'_skin'         => [ 'skin-1', 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->add_responsive_control(
			'product_add_cart_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-woo-products-summary-wrap .button' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_add_cart' => 'yes',
					'_skin'         => 'skin-1',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'product_add_cart_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'show_add_cart' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_add_cart_hover_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-woo-products-summary-wrap .button:hover,
                    {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-action-item-wrap:hover,
                    {{WRAPPER}} .pp-product-actions .pp-action-item-wrap:hover .pp-action-item,
                    .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .button:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_add_cart' => 'yes',
				],
			]
		);

		$this->add_control(
			'product_view_cart_hover_color',
			[
				'label'     => esc_html__( 'View Cart Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .added_to_cart:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_add_cart' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'product_add_cart_background_hover_color',
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pp-woocommerce .pp-woo-products-summary-wrap .button:hover,
                {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-action-item-wrap:hover,
                .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .button:hover',
				'condition' => [
					'show_add_cart' => 'yes',
					'_skin'         => [ 'skin-1', 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->add_control(
			'product_add_cart_border_hover_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-woo-products-summary-wrap .button:hover,
                {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-action-item-wrap:hover,
                .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .button:hover' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'show_add_cart' => 'yes',
					'_skin'         => [ 'skin-1', 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->add_control(
			'product_actions_background_hover_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-action-item-wrap:hover,
                    .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .button:hover' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'show_add_cart' => 'yes',
					'_skin'         => [ 'skin-2', 'skin-5' ],
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'out_of_stock_style_heading',
			[
				'label'     => esc_html__( 'Out of Stock Text', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'out_of_stock_text_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-out-of-stock' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'out_of_stock_text_background_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-out-of-stock' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'out_of_stock_text_typography',
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector' => '{{WRAPPER}} .pp-woocommerce .pp-out-of-stock',
			]
		);

		$this->add_control(
			'out_of_stock_text_opacity',
			[
				'label'     => esc_html__( 'Opacity', 'powerpack' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max'  => 1,
						'min'  => 0,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-out-of-stock' => 'opacity: {{SIZE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register Pagination Controls.
	 *
	 * @access protected
	 */
	protected function register_content_pagination_controls() {

		$this->start_controls_section(
			'section_pagination_field',
			[
				'label'     => esc_html__( 'Pagination', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
				],
			]
		);

		$this->add_control(
			'pagination_type',
			[
				'label'     => esc_html__( 'Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''              => esc_html__( 'None', 'powerpack' ),
					'numbers'       => esc_html__( 'Numbers', 'powerpack' ),
					'numbers_arrow' => esc_html__( 'Numbers + Pre/Next Arrow', 'powerpack' ),
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
				],
			]
		);

		$this->add_control(
			'pagination_prev_label',
			[
				'label'     => esc_html__( 'Previous Label', 'powerpack' ),
				'default'   => '←',
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type'      => 'numbers_arrow',
				],
			]
		);

		$this->add_control(
			'pagination_next_label',
			[
				'label'     => esc_html__( 'Next Label', 'powerpack' ),
				'default'   => '→',
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type'      => 'numbers_arrow',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register Product Badge Controls.
	 *
	 * @access protected
	 */
	protected function register_content_product_badges_controls() {

		$this->start_controls_section(
			'section_content_product_badge',
			[
				'label' => esc_html__( 'Product Badges', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sale_badge_heading',
			[
				'label' => esc_html__( 'Sale', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'sale_badge_position',
			[
				'label'   => esc_html__( 'Position', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					''      => esc_html__( 'None', 'powerpack' ),
					'left'  => esc_html__( 'Left', 'powerpack' ),
					'right' => esc_html__( 'Right', 'powerpack' ),
				],
				'default' => 'left',
			]
		);

		$this->add_control(
			'sale_badge_custom_text',
			[
				'label'       => esc_html__( 'Custom Text', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'description' => esc_html__( 'Show Sale % Value ( [value] Autocalculated offer value will replace this ).', 'powerpack' ),
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'sale_badge_position!' => '',
				],
			]
		);

		$this->add_control(
			'featured_badge_heading',
			[
				'label'     => esc_html__( 'Featured', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'featured_badge_position',
			[
				'label'   => esc_html__( 'Position', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					''      => esc_html__( 'None', 'powerpack' ),
					'left'  => esc_html__( 'Left', 'powerpack' ),
					'right' => esc_html__( 'Right', 'powerpack' ),
				],
				'default' => '',
			]
		);

		$this->add_control(
			'featured_badge_custom_text',
			[
				'label'     => esc_html__( 'Custom Text', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => [
					'featured_badge_position!' => '',
				],
			]
		);

		$this->add_control(
			'top_rating_badge_heading',
			[
				'label'     => esc_html__( 'Top Rated', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'top_rating_badge_position',
			[
				'label'   => esc_html__( 'Position', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					''      => esc_html__( 'None', 'powerpack' ),
					'left'  => esc_html__( 'Left', 'powerpack' ),
					'right' => esc_html__( 'Right', 'powerpack' ),
				],
				'default' => '',
			]
		);

		$this->add_control(
			'top_rating_badge_custom_text',
			[
				'label'     => esc_html__( 'Custom Text', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => [
					'top_rating_badge_position!' => '',
				],
			]
		);

		$this->add_control(
			'number_of_ratings',
			[
				'label'       => esc_html__( 'Rating', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '4',
				'description' => esc_html__( 'Show badge according to count of total rating greater than rating.', 'powerpack' ),
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'top_rating_badge_position!' => '',
				],
			]
		);

		$this->add_control(
			'best_selling_badge_heading',
			[
				'label'     => esc_html__( 'Best Selling', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'best_selling_badge_position',
			[
				'label'   => esc_html__( 'Position', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					''      => esc_html__( 'None', 'powerpack' ),
					'left'  => esc_html__( 'Left', 'powerpack' ),
					'right' => esc_html__( 'Right', 'powerpack' ),
				],
				'default' => '',
			]
		);

		$this->add_control(
			'best_selling_badge_custom_text',
			[
				'label'     => esc_html__( 'Custom Text', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => [
					'best_selling_badge_position!' => '',
				],
			]
		);

		$this->add_control(
			'number_of_sales',
			[
				'label'       => esc_html__( 'Number of Sales', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '1',
				'description' => esc_html__( 'Minimum number of sales.', 'powerpack' ),
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'best_selling_badge_position!' => '',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register style Product Badges Controls.
	 *
	 * @access protected
	 */
	protected function register_style_product_badges_controls() {

		$this->start_controls_section(
			'section_style_product_badges',
			[
				'label' => esc_html__( 'Product Badges', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'product_badge_margin',
			[
				'label'      => esc_html__( 'Margin', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [
					'top'    => '10',
					'bottom' => '10',
					'left'   => '10',
					'right'  => '10',
					'unit'   => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-badge-container' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'sale_badge_style_heading',
			[
				'label'     => esc_html__( 'Sale', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'sale_badge_position!' => '',
				],
			]
		);

		$this->add_control(
			'sale_badge_style',
			[
				'label'        => esc_html__( 'Style', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'options'      => [
					'circle' => esc_html__( 'Circle', 'powerpack' ),
					'square' => esc_html__( 'Square', 'powerpack' ),
					'ribbon' => esc_html__( 'Ribbon', 'powerpack' ),
					'custom' => esc_html__( 'Custom', 'powerpack' ),
				],
				'default'      => 'custom',
				'condition'    => [
					'sale_badge_position!' => '',
				],
				'prefix_class' => 'pp-sale-badge-',
			]
		);

		$this->add_control(
			'sale_badge_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-sale-badge' => 'color: {{VALUE}};',
				],
				'condition' => [
					'sale_badge_position!' => '',
				],
			]
		);

		$this->add_control(
			'sale_badge_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-sale-badge' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'sale_badge_position!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'sale_badge_typography',
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'  => '{{WRAPPER}} .pp-woocommerce .pp-sale-badge',
				'condition' => [
					'sale_badge_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'sale_badge_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 20,
						'max' => 200,
					],
					'em' => [
						'min' => 1,
						'max' => 10,
					],
				],
				'default'    => [
					'size' => 2,
					'unit' => 'em',
				],
				'condition'  => [
					'sale_badge_position!' => '',
					'sale_badge_style'     => [ 'circle', 'square', 'custom' ],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-sale-badge' => 'min-height: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',

				],
			]
		);

		$this->add_responsive_control(
			'sale_badge_radius',
			[
				'label'      => esc_html__( 'Rounded Corners', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'top'    => '',
					'bottom' => '',
					'left'   => '',
					'right'  => '',
					'unit'   => 'px',
				],
				'condition'  => [
					'sale_badge_position!' => '',
					'sale_badge_style'     => 'custom',

				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-sale-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sale_badge_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-sale-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default'    => [
					'top'      => '2',
					'bottom'   => '2',
					'left'     => '10',
					'right'    => '10',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'condition'  => [
					'sale_badge_position!' => '',
					'sale_badge_style'     => 'custom',
				],
			]
		);

		$this->add_control(
			'featured_badge_style_heading',
			[
				'label'     => esc_html__( 'Featured', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'featured_badge_position!' => '',
				],
			]
		);

		$this->add_control(
			'featured_badge_style',
			[
				'label'        => esc_html__( 'Style', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'options'      => [
					'circle' => esc_html__( 'Circle', 'powerpack' ),
					'square' => esc_html__( 'Square', 'powerpack' ),
					'ribbon' => esc_html__( 'Ribbon', 'powerpack' ),
					'custom' => esc_html__( 'Custom', 'powerpack' ),
				],
				'default'      => 'custom',
				'condition'    => [
					'featured_badge_position!' => '',
				],
				'prefix_class' => 'pp-featured-badge-',
			]
		);

		$this->add_control(
			'featured_badge_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-featured-badge' => 'color: {{VALUE}};',
				],
				'condition' => [
					'featured_badge_position!' => '',
				],
			]
		);

		$this->add_control(
			'featured_badge_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-featured-badge' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'featured_badge_position!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'featured_badge_typography',
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'  => '{{WRAPPER}} .pp-woocommerce .pp-featured-badge',
				'condition' => [
					'featured_badge_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'featured_badge_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 20,
						'max' => 200,
					],
					'em' => [
						'min' => 1,
						'max' => 10,
					],
				],
				'default'    => [
					'size' => 2,
					'unit' => 'em',
				],
				'condition'  => [
					'featured_badge_position!' => '',
					'featured_badge_style'     => [ 'circle', 'square', 'custom' ],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-featured-badge' => 'min-height: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',

				],
			]
		);

		$this->add_responsive_control(
			'featured_badge_radius',
			[
				'label'      => esc_html__( 'Rounded Corners', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'top'    => '',
					'bottom' => '',
					'left'   => '',
					'right'  => '',
					'unit'   => 'px',
				],
				'condition'  => [
					'featured_badge_position!' => '',
					'featured_badge_style'     => 'custom',

				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-featured-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'featured_badge_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-featured-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default'    => [
					'top'      => '2',
					'bottom'   => '2',
					'left'     => '10',
					'right'    => '10',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'condition'  => [
					'featured_badge_position!' => '',
					'featured_badge_style'     => 'custom',
				],
			]
		);

		$this->add_control(
			'top_rating_badge_style_heading',
			[
				'label'     => esc_html__( 'Top Rated', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'top_rating_badge_position!' => '',
				],
			]
		);

		$this->add_control(
			'top_rating_badge_style',
			[
				'label'        => esc_html__( 'Style', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'options'      => [
					'circle' => esc_html__( 'Circle', 'powerpack' ),
					'square' => esc_html__( 'Square', 'powerpack' ),
					'ribbon' => esc_html__( 'Ribbon', 'powerpack' ),
					'custom' => esc_html__( 'Custom', 'powerpack' ),
				],
				'default'      => 'custom',
				'condition'    => [
					'top_rating_badge_position!' => '',
				],
				'prefix_class' => 'pp-top-rated-badge-',
			]
		);

		$this->add_control(
			'top_rating_badge_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-top-rated-badge' => 'color: {{VALUE}};',
				],
				'condition' => [
					'top_rating_badge_position!' => '',
				],
			]
		);

		$this->add_control(
			'top_rating_badge_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-top-rated-badge' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'top_rating_badge_position!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'top_rating_badge_typography',
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'  => '{{WRAPPER}} .pp-woocommerce .pp-top-rated-badge',
				'condition' => [
					'top_rating_badge_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'top_rating_badge_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 20,
						'max' => 200,
					],
					'em' => [
						'min' => 1,
						'max' => 10,
					],
				],
				'default'    => [
					'size' => 2,
					'unit' => 'em',
				],
				'condition'  => [
					'top_rating_badge_position!' => '',
					'top_rating_badge_style'     => [ 'circle', 'square', 'custom' ],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-top-rated-badge' => 'min-height: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',

				],
			]
		);

		$this->add_responsive_control(
			'top_rating_badge_radius',
			[
				'label'      => esc_html__( 'Rounded Corners', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'top'    => '',
					'bottom' => '',
					'left'   => '',
					'right'  => '',
					'unit'   => 'px',
				],
				'condition'  => [
					'top_rating_badge_position!' => '',
					'top_rating_badge_style'     => 'custom',

				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-top-rated-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'top_rating_badge_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-top-rated-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default'    => [
					'top'      => '2',
					'bottom'   => '2',
					'left'     => '10',
					'right'    => '10',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'condition'  => [
					'top_rating_badge_position!' => '',
					'top_rating_badge_style'     => 'custom',
				],
			]
		);

		$this->add_control(
			'best_selling_badge_style_heading',
			[
				'label'     => esc_html__( 'Best Selling', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'best_selling_badge_position!' => '',
				],
			]
		);

		$this->add_control(
			'best_selling_badge_style',
			[
				'label'        => esc_html__( 'Style', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'options'      => [
					'circle' => esc_html__( 'Circle', 'powerpack' ),
					'square' => esc_html__( 'Square', 'powerpack' ),
					'ribbon' => esc_html__( 'Ribbon', 'powerpack' ),
					'custom' => esc_html__( 'Custom', 'powerpack' ),
				],
				'default'      => 'custom',
				'condition'    => [
					'best_selling_badge_position!' => '',
				],
				'prefix_class' => 'pp-best-selling-badge-',
			]
		);

		$this->add_control(
			'best_selling_badge_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-best-selling-badge' => 'color: {{VALUE}};',
				],
				'condition' => [
					'best_selling_badge_position!' => '',
				],
			]
		);

		$this->add_control(
			'best_selling_badge_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-best-selling-badge' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'best_selling_badge_position!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'best_selling_badge_typography',
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'  => '{{WRAPPER}} .pp-woocommerce .pp-best-selling-badge',
				'condition' => [
					'best_selling_badge_position!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'best_selling_badge_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 20,
						'max' => 200,
					],
					'em' => [
						'min' => 1,
						'max' => 10,
					],
				],
				'default'    => [
					'size' => 2,
					'unit' => 'em',
				],
				'condition'  => [
					'best_selling_badge_position!' => '',
					'best_selling_badge_style'     => [ 'circle', 'square', 'custom' ],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-best-selling-badge' => 'min-height: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',

				],
			]
		);

		$this->add_responsive_control(
			'best_selling_badge_radius',
			[
				'label'      => esc_html__( 'Rounded Corners', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'top'    => '',
					'bottom' => '',
					'left'   => '',
					'right'  => '',
					'unit'   => 'px',
				],
				'condition'  => [
					'best_selling_badge_position!' => '',
					'best_selling_badge_style'     => 'custom',

				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-best-selling-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'best_selling_badge_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-best-selling-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default'    => [
					'top'      => '2',
					'bottom'   => '2',
					'left'     => '10',
					'right'    => '10',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'condition'  => [
					'best_selling_badge_position!' => '',
					'best_selling_badge_style'     => 'custom',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register Image Controls.
	 *
	 * @access protected
	 */
	protected function register_image_controls() {
		$this->start_controls_section(
			'section_design_image',
			[
				'label' => esc_html__( 'Image', 'powerpack' ),
			]
		);

		$this->add_control(
			'link_image',
			[
				'label'        => esc_html__( 'Link to Product', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'link_image_target',
			[
				'label'        => esc_html__( 'Open Link in New Tab?', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'    => [
					'link_image' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'    => 'thumbnail',
				'label'   => esc_html__( 'Image Size', 'powerpack' ),
				'default' => 'woocommerce_thumbnail',
			]
		);

		$this->add_control(
			'products_hover_style',
			[
				'label'   => esc_html__( 'Image Hover Effect', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''     => esc_html__( 'None', 'powerpack' ),
					'swap' => esc_html__( 'Swap Images', 'powerpack' ),
					'zoom' => esc_html__( 'Zoom Image', 'powerpack' ),
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register Quick View Controls.
	 *
	 * @access protected
	 */
	protected function register_quick_view_controls() {

		$this->start_controls_section(
			'section_content_quick_view',
			[
				'label' => esc_html__( 'Quick View', 'powerpack' ),
			]
		);

		$this->add_control(
			'quick_view_type',
			[
				'label'        => esc_html__( 'Quick View', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => '',
			]
		);

		$this->add_control(
			'quick_view_text',
			[
				'label'     => esc_html__( 'Quick View Text', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Quick View', 'powerpack' ),
				'condition' => [
					'quick_view_type!' => '',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register Add to Wishlist Controls.
	 *
	 * @access protected
	 */
	protected function register_add_to_wishlist_controls() {

		if ( class_exists( 'YITH_WCWL' ) ) {
			$this->start_controls_section(
				'section_content_add_to_wishlist',
				[
					'label' => esc_html__( 'Add to Wishlist', 'powerpack' ),
				]
			);

			$this->add_control(
				'show_add_to_wishlist',
				[
					'label'        => esc_html__( 'Add to Wishlist', 'powerpack' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => esc_html__( 'Show', 'powerpack' ),
					'label_off'    => esc_html__( 'Hide', 'powerpack' ),
					'return_value' => 'yes',
					'default'      => '',
				]
			);

			$this->add_control(
				'add_to_wishlist_type',
				[
					'label'     => esc_html__( 'Add to Wishlist Type', 'powerpack' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'text',
					'options'   => [
						'icon' => esc_html__( 'Heart Icon', 'powerpack' ),
						'text' => esc_html__( 'Text', 'powerpack' ),
					],
					'condition' => [
						'_skin'                => [ 'skin-1', 'skin-4' ],
						'show_add_to_wishlist' => 'yes',
					],
				]
			);

			$this->end_controls_section();
		}
	}

	/**
	 * Register Quick View Style Controls.
	 *
	 * @access protected
	 */
	protected function register_quick_view_style_controls() {

		$this->start_controls_section(
			'section_content_quick_view_style',
			[
				'label'     => esc_html__( 'Quick View', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'quick_view_type' => 'yes',
				],
			]
		);

		$this->add_control(
			'quick_view_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-quick-view-btn span, {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn' => 'color: {{VALUE}};',
					'{{WRAPPER}} .pp-woocommerce .pp-quick-view-btn svg' => 'fill: {{VALUE}};',
				],
				'condition' => [
					'quick_view_type' => 'yes',
					'_skin'           => [ 'skin-1', 'skin-2', 'skin-5' ],
				],
			]
		);

		$this->add_control(
			'quick_view_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-quick-view-btn, {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'quick_view_type' => 'yes',
					'_skin'           => [ 'skin-1', 'skin-2', 'skin-5' ],
				],
			]
		);

		$this->add_responsive_control(
			'product_quick_view_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn .pp-action-item-wrap, {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'quick_view_type' => 'yes',
					'_skin'           => [ 'skin-3' ],
				],
			]
		);

		$this->start_controls_tabs( 'product_quick_view_tabs_style' );

		$this->start_controls_tab(
			'product_quick_view_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'quick_view_type' => 'yes',
					'_skin'           => [ 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->add_control(
			'product_quick_view_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn .pp-action-item-wrap,
                    {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn .pp-action-item-wrap span,
                    {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn' => 'color: {{VALUE}};',
					'{{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn svg' => 'fill: {{VALUE}};',
				],
				'condition' => [
					'quick_view_type' => 'yes',
					'_skin'           => [ 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'product_quick_view_background_color',
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn .pp-action-item-wrap, {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn',
				'condition' => [
					'quick_view_type' => 'yes',
					'_skin'           => [ 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'product_quick_view_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'quick_view_type' => 'yes',
					'_skin'           => [ 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->add_control(
			'product_quick_view_hover_color',
			[
				'label'     => esc_html__( 'Text Hover Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn .pp-action-item-wrap:hover,
                    {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn .pp-action-item-wrap:hover span,
                    {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'quick_view_type' => 'yes',
					'_skin'           => [ 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'product_quick_view_background_hover_color',
				'label'     => esc_html__( 'Background Hover Color', 'powerpack' ),
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn .pp-action-item-wrap:hover, {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn:hover',
				'condition' => [
					'quick_view_type' => 'yes',
					'_skin'           => [ 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'quick_view_typography',
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'  => '{{WRAPPER}} .pp-woocommerce .pp-quick-view-btn, {{WRAPPER}} .pp-woocommerce .pp-product-actions .pp-quick-view-btn .pp-action-item-wrap',
				'condition' => [
					'quick_view_type' => 'yes',
					'_skin'           => [ 'skin-1', 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->add_control(
			'quick_view_advanced_styling',
			[
				'label'        => esc_html__( 'Advanced Styling', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => [
					'quick_view_type' => 'yes',
				],
			]
		);

		$this->add_control(
			'quick_view_title_heading',
			[
				'label'     => esc_html__( 'Title', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'quick_view_type' => 'yes',
					'quick_view_advanced_styling' => 'yes',
				],
			]
		);

		$this->add_control(
			'quick_view_product_title_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'.pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .product_title' => 'color: {{VALUE}};',
				],
				'condition' => [
					'quick_view_type' => 'yes',
					'quick_view_advanced_styling' => 'yes',
				],
			]
		);

		$this->add_control(
			'quick_view_product_title_hover_color',
			[
				'label'     => esc_html__( 'Hover Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'.pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .product_title:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'quick_view_type' => 'yes',
					'quick_view_advanced_styling' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'quick_view_product_title_typography',
				'selector'  => '.pp-quick-view-{{ID}} .woocommerce div.product .product_title',
				'condition' => [
					'quick_view_type' => 'yes',
					'quick_view_advanced_styling' => 'yes',
				],
			]
		);

		$this->add_control(
			'quick_view_product_rating_style',
			[
				'label'     => esc_html__( 'Rating', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'quick_view_type' => 'yes',
					'quick_view_advanced_styling' => 'yes',
				],
			]
		);

		$this->add_control(
			'quick_view_product_rating_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'.pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .star-rating, .pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .star-rating:before' => 'color: {{VALUE}};',
				],
				'condition' => [
					'quick_view_type' => 'yes',
					'quick_view_advanced_styling' => 'yes',
				],
			]
		);

		$this->add_control(
			'quick_view_product_price_style',
			[
				'label'     => esc_html__( 'Price', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'quick_view_type' => 'yes',
					'quick_view_advanced_styling' => 'yes',
				],
			]
		);

		$this->add_control(
			'quick_view_product_price_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'.pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .price' => 'color: {{VALUE}};',
				],
				'condition' => [
					'quick_view_type' => 'yes',
					'quick_view_advanced_styling' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'quick_view_product_price_typography',
				'selector'  => '.pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .price',
				'condition' => [
					'quick_view_type' => 'yes',
					'quick_view_advanced_styling' => 'yes',
				],
			]
		);

		$this->add_control(
			'quick_view_product_short_desc_style',
			[
				'label'     => esc_html__( 'Short Description', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'quick_view_type' => 'yes',
					'quick_view_advanced_styling' => 'yes',
				],
			]
		);

		$this->add_control(
			'quick_view_product_short_desc_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'.pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .woocommerce-product-details__short-description' => 'color: {{VALUE}};',
				],
				'condition' => [
					'quick_view_type' => 'yes',
					'quick_view_advanced_styling' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'quick_view_product_short_desc_typography',
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'  => '.pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content .woocommerce-product-details__short-description',
				'condition' => [
					'quick_view_type' => 'yes',
					'quick_view_advanced_styling' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab
	 */
	/**
	 * Register Layout Controls.
	 *
	 * @access protected
	 */
	protected function register_style_layout_controls() {
		$this->start_controls_section(
			'section_design_layout',
			[
				'label' => esc_html__( 'Layout', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'column_gap',
			[
				'label'       => esc_html__( 'Columns Gap', 'powerpack' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ 'px', 'em', 'rem', 'custom' ],
				'default'     => [
					'size' => 20,
				],
				'range'       => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'render_type' => 'template',
				'selectors'   => [
					'{{WRAPPER}}' => '--grid-column-gap: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'row_gap',
			[
				'label'      => esc_html__( 'Rows Gap', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 35,
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--grid-row-gap: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_design_box',
			[
				'label' => esc_html__( 'Box', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'product_border',
				'label'     => esc_html__( 'Border', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-woo-product-wrapper',
			]
		);

		$this->add_responsive_control(
			'product_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-product-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'product_box_padding',
			[
				'label'      => esc_html__( 'Box Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-product-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'box_tabs_style' );

		$this->start_controls_tab(
			'box_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'product_box_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-product-wrapper' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'product_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-product-wrapper',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'box_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'product_box_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} li.product:hover .pp-woo-product-wrapper' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'product_box_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} li.product:hover .pp-woo-product-wrapper' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'product_box_shadow_hover',
				'selector' => '{{WRAPPER}} li.product:hover .pp-woo-product-wrapper',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register Lightbox Style Controls.
	 *
	 * @access protected
	 */
	protected function register_lightbox_style_controls() {
		$this->start_controls_section(
			'section_content_lightbox_style',
			[
				'label' => esc_html__( 'Lightbox', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'lightbox_overlay_color',
			[
				'label'     => esc_html__( 'Overlay Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'.pp-quick-view-{{ID}} .pp-quick-view-bg' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'lightbox_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'.pp-quick-view-{{ID}} .pp-quick-view-modal .pp-lightbox-content' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'lightbox_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'.pp-quick-view-{{ID}} .pp-lightbox-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'lightbox_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'separator'   => 'before',
				'selector'    => '.pp-quick-view-{{ID}} .pp-lightbox-content',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'lightbox_box_shadow',
				'separator' => 'before',
				'selector'  => '.pp-quick-view-{{ID}} .pp-lightbox-content',
			]
		);

		$this->add_control(
			'close_icon_size',
			[
				'label'      => esc_html__( 'Close Icon Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 10,
						'max' => 50,
					],
				],
				'selectors'  => [
					'.pp-quick-view-{{ID}} .pp-quick-view-close-btn, .pp-quick-view-{{ID}} .pp-quick-view-close-btn:before, .pp-quick-view-{{ID}} .pp-quick-view-close-btn:after' => 'width: {{SIZE}}{{UNIT}};',
					'.pp-quick-view-{{ID}} .pp-quick-view-close-btn' => 'height: {{SIZE}}{{UNIT}};',
				],
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'close_icon_thickness',
			[
				'label'      => esc_html__( 'Close Icon Thickness', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 1,
						'max' => 5,
					],
				],
				'selectors'  => [
					'.pp-quick-view-{{ID}} .pp-quick-view-close-btn:before, .pp-quick-view-{{ID}} .pp-quick-view-close-btn:after' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'close_icon_color',
			[
				'label'     => esc_html__( 'Close Icon Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'.pp-quick-view-{{ID}} .pp-quick-view-close-btn:before, .pp-quick-view-{{ID}} .pp-quick-view-close-btn:after' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register Pagination Controls.
	 *
	 * @access protected
	 */
	protected function register_style_pagination_controls() {

		$this->start_controls_section(
			'section_design_pagination',
			[
				'label'     => esc_html__( 'Pagination', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->add_responsive_control(
			'pagination_align',
			[
				'label'        => esc_html__( 'Alignment', 'powerpack' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'      => 'center',
				'prefix_class' => 'pp-woo-pagination%s-align-',
				'condition'    => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'pagination_typography',
				'selector'  => '{{WRAPPER}} nav.pp-woocommerce-pagination ul li > .page-numbers',
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],

			]
		);

		$this->start_controls_tabs( 'pagination_tabs_style' );

		$this->start_controls_tab(
			'pagination_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->add_control(
			'pagination_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} nav.pp-woocommerce-pagination ul li > .page-numbers' => 'color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->add_control(
			'pagination_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} nav.pp-woocommerce-pagination ul li > .page-numbers' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->add_control(
			'pagination_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} nav.pp-woocommerce-pagination ul li .page-numbers, {{WRAPPER}} nav.pp-woocommerce-pagination ul li span.current' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->add_responsive_control(
			'pagination_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 10,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} nav.pp-woocommerce-pagination ul li .page-numbers' => 'border-width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'pagination_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->add_control(
			'pagination_hover_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} nav.pp-woocommerce-pagination ul li .page-numbers:focus, {{WRAPPER}} nav.pp-woocommerce-pagination ul li .page-numbers:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->add_control(
			'pagination_background_hover_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} nav.pp-woocommerce-pagination ul li .page-numbers:focus, {{WRAPPER}} nav.pp-woocommerce-pagination ul li .page-numbers:hover' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->add_control(
			'pagination_border_hover_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} nav.pp-woocommerce-pagination ul li .page-numbers:focus, {{WRAPPER}} nav.pp-woocommerce-pagination ul li .page-numbers:hover' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'pagination_active',
			[
				'label'     => esc_html__( 'Active', 'powerpack' ),
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->add_control(
			'pagination_active_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} nav.pp-woocommerce-pagination ul li span.current' => 'color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->add_control(
			'pagination_background_active_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} nav.pp-woocommerce-pagination ul li span.current' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->add_control(
			'pagination_border_active_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} nav.pp-woocommerce-pagination ul li span.current' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'grid',
					'pagination_type!'     => '',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register Navigation Controls.
	 *
	 * @access protected
	 */
	public function register_style_arrows_controls() {
		$this->start_controls_section(
			'section_arrows_style',
			[
				'label'     => esc_html__( 'Arrows', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->add_control(
			'select_arrow',
			[
				'label'                  => esc_html__( 'Choose Arrow', 'powerpack' ),
				'type'                   => Controls_Manager::ICONS,
				'fa4compatibility'       => 'arrow',
				'label_block'            => false,
				'default'                => [
					'value'   => 'fas fa-angle-right',
					'library' => 'fa-solid',
				],
				'skin'                   => 'inline',
				'exclude_inline_options' => 'svg',
				'recommended'            => [
					'fa-regular' => [
						'arrow-alt-circle-right',
						'caret-square-right',
						'hand-point-right',
					],
					'fa-solid'   => [
						'angle-right',
						'angle-double-right',
						'chevron-right',
						'chevron-circle-right',
						'arrow-right',
						'long-arrow-alt-right',
						'caret-right',
						'caret-square-right',
						'arrow-circle-right',
						'arrow-alt-circle-right',
						'toggle-right',
						'hand-point-right',
					],
				],
				'condition'          => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_position',
			[
				'label'        => esc_html__( 'Position', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'outside',
				'options'      => [
					'inside'  => esc_html__( 'Inside', 'powerpack' ),
					'outside' => esc_html__( 'Outside', 'powerpack' ),
				],
				'prefix_class' => 'pp-woo-slider-arrow-',
				'condition'    => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [ 'size' => '22' ],
				'range'      => [
					'px' => [
						'min'  => 15,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-slider-arrow' => 'font-size: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_spacing',
			[
				'label'      => esc_html__( 'Align Arrows', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => -100,
						'max'  => 50,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-products-slider .elementor-swiper-button-next' => 'right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pp-woo-products-slider .elementor-swiper-button-prev' => 'left: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_arrows_style' );

		$this->start_controls_tab(
			'tab_arrows_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-slider-arrow' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-slider-arrow' => 'color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'arrows_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-slider-arrow',
				'condition'   => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-slider-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_arrows_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-slider-arrow:hover' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-slider-arrow:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-slider-arrow:hover' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'arrows_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-slider-arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator'  => 'before',
				'condition'  => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register Dots Style Controls.
	 *
	 * @access public
	 */
	public function register_style_dots_controls() {
		$this->start_controls_section(
			'section_dots_style',
			[
				'label'     => esc_html__( 'Dots', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->add_control(
			'dots_position',
			[
				'label'                 => esc_html__( 'Position', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'options'               => [
					'inside'     => esc_html__( 'Inside', 'powerpack' ),
					'outside'    => esc_html__( 'Outside', 'powerpack' ),
				],
				'default'               => 'outside',
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'dots_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 2,
						'max'  => 40,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'dots_top_spacing',
			[
				'label'      => esc_html__( 'Top Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .swiper-container-wrap-dots-outside .swiper-pagination' => 'margin-top: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .swiper-container-wrap-dots-inside .swiper-pagination' => 'bottom: -{{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'dots_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 1,
						'max'  => 30,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet' => 'margin-left: calc( {{SIZE}}{{UNIT}}/2 ); margin-right: calc( {{SIZE}}{{UNIT}}/2 );',
				],
				'condition'  => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_dots_style' );

		$this->start_controls_tab(
			'tab_dots_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->add_control(
			'dots_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet' => 'background: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'dots_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet',
				'condition'   => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'dots_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'dots_box_shadow',
				'selector'  => '{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet',
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_dots_active',
			[
				'label'     => esc_html__( 'Active', 'powerpack' ),
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->add_control(
			'dots_color_active',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'background: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->add_control(
			'dots_border_color_active',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'dots_box_shadow_active',
				'selector'  => '{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet.swiper-pagination-bullet-active',
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_dots_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->add_control(
			'dots_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet:hover' => 'background: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->add_control(
			'dots_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet:hover' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'carousel_pagination'  => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'dots_box_shadow_hover',
				'selector'  => '{{WRAPPER}} .swiper-container-wrap .swiper-pagination-bullet:hover',
				'condition' => [
					'_skin'                => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4', 'skin-5' ],
					'products_layout_type' => 'slider',
					'arrows'               => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Get the number of products to query for the current layout.
	 *
	 * @since 3.0.0
	 * @access public
	 * @param array $settings  Widget settings.
	 * @param bool  $allow_all Whether a missing limit may mean "every match". Only
	 *                         pass true when the query is already bounded, such as
	 *                         by a post__in of upsell or cross-sell IDs.
	 * @return int Posts per page, or -1 for no limit.
	 */
	public function get_products_per_page( $settings, $allow_all = false ) {
		$key = ( 'slider' === $settings['products_layout_type'] ) ? 'slider_products_per_page' : 'products_per_page';

		$limit = (int) $settings[ $key ];

		if ( $limit > 0 ) {
			return $limit;
		}

		return $allow_all ? -1 : self::DEFAULT_PRODUCTS_PER_PAGE;
	}

	/**
	 * Whether the current layout needs a total row count.
	 *
	 * Only paginated grids read found_posts, so every other layout can skip
	 * the SQL_CALC_FOUND_ROWS pass.
	 *
	 * @since 3.0.0
	 * @access public
	 * @param array $settings Widget settings.
	 * @return bool
	 */
	public function needs_found_rows( $settings ) {
		return 'grid' === $settings['products_layout_type'] && '' !== $settings['pagination_type'];
	}

	/**
	 * Let developers alter the arguments before the products query runs.
	 *
	 * @since 3.0.0
	 * @access protected
	 * @param array $query_args Arguments about to be handed to WP_Query.
	 * @param array $settings   Widget settings.
	 * @return array Filtered query arguments.
	 */
	protected function filter_query_args( $query_args, $settings ) {
		/**
		 * Filters the Woo - Products query arguments.
		 *
		 * @since 3.0.0
		 *
		 * @param array $query_args Arguments about to be handed to WP_Query.
		 * @param array $settings   Widget settings.
		 */
		$query_args = apply_filters( 'pp_woo_products_query_args', $query_args, $settings );

		/**
		 * Filters the Woo - Products query arguments.
		 *
		 * Kept for back compatibility. The 'ppe_' prefix is inconsistent with the
		 * rest of the plugin; use 'pp_woo_products_query_args' in new code.
		 *
		 * @since 1.3.3
		 * @deprecated 3.0.0 Use 'pp_woo_products_query_args' instead.
		 *
		 * @param array $query_args Arguments about to be handed to WP_Query.
		 * @param array $settings   Widget settings.
		 */
		return apply_filters( 'ppe_woo_product_query_args', $query_args, $settings );
	}

	/**
	 * Get query arguments that deliberately match no products.
	 *
	 * @since 3.0.0
	 * @access public
	 * @return array Query arguments.
	 */
	public function get_empty_query_args() {
		return [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'paged'          => 1,
			'post__in'       => [ 0 ],
			'no_found_rows'  => true,
		];
	}

	/**
	 * Get the page number requested by an AJAX pagination request.
	 *
	 * The page number is only honoured when the request carries a valid
	 * 'pp-product-nonce'. Any other request falls back to the given default.
	 *
	 * @since 3.0.0
	 * @access public
	 * @param mixed $fallback Page number to use when the request carries none.
	 * @return int Page number, never lower than 1.
	 */
	public function get_ajax_paged( $fallback = 1 ) {
		$fallback = max( 1, absint( $fallback ) );

		if ( ! isset( $_POST['nonce'], $_POST['page_number'] ) ) {
			return $fallback;
		}

		$nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ) );

		if ( ! wp_verify_nonce( $nonce, 'pp-product-nonce' ) ) {
			return $fallback;
		}

		$paged = absint( wp_unslash( $_POST['page_number'] ) );

		return ( $paged > 0 ) ? $paged : $fallback;
	}

	/**
	 * Get the product ID sent with an AJAX pagination request.
	 *
	 * The ID is only honoured when the request carries a valid
	 * 'pp-product-nonce' and resolves to an existing product.
	 *
	 * @since 3.0.0
	 * @access public
	 * @return int Product ID, or 0 when the request does not carry a usable one.
	 */
	public function get_ajax_product_id() {
		if ( ! isset( $_POST['nonce'], $_POST['product_id'] ) ) {
			return 0;
		}

		$nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ) );

		if ( ! wp_verify_nonce( $nonce, 'pp-product-nonce' ) ) {
			return 0;
		}

		$product_id = absint( wp_unslash( $_POST['product_id'] ) );

		if ( ! $product_id || 'product' !== get_post_type( $product_id ) ) {
			return 0;
		}

		return $product_id;
	}

	/**
	 * Get query products based on settings.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access public
	 * @param array $settings Widget settings.
	 */
	public function query_posts( $settings ) {

		//$settings = $this->get_settings_for_display();
		$query_id = $settings['query_id'];

		if ( ! empty( $query_id ) ) {
			add_action( 'pre_get_posts', [ $this, 'pre_get_product_query_filter' ] );
		}

		if ( 'main' === $settings['source'] ) {

			// WordPress has already run this query and primed the post, meta and
			// term caches. Clone it rather than issuing the same SQL a second time;
			// the clone keeps its own loop pointer so the main loop is unaffected.
			$this->query = clone $GLOBALS['wp_query'];
			$this->query->rewind_posts();

		} elseif ( 'related' === $settings['source'] ) {

			if ( is_product() ) {

				global $product;

				$product_id                  = $product->get_id();
				$product_visibility_term_ids = wc_get_product_visibility_term_ids();

				$query_args = [
					'post_type'      => 'product',
					'post_status'    => 'publish',
					// Related products are only bounded by category, so always cap them.
					'posts_per_page' => $this->get_products_per_page( $settings ),
					'paged'          => 1,
					'post__not_in'   => [],
					'no_found_rows'  => ! $this->needs_found_rows( $settings ),
				];

				if ( $this->needs_found_rows( $settings ) ) {
					$query_args['paged'] = $this->get_ajax_paged( get_query_var( 'paged' ) );
				}

				// Get current post categories and pass to filter.
				$product_cat = [];

				$product_categories = wp_get_post_terms( $product_id, 'product_cat' );

				if ( ! empty( $product_categories ) ) {

					foreach ( $product_categories as $key => $category ) {

						$product_cat[] = $category->slug;
					}
				}

				if ( ! empty( $product_cat ) ) {

					$query_args['tax_query'][] = [
						'taxonomy' => 'product_cat',
						'field'    => 'slug',
						'terms'    => $product_cat,
						'operator' => 'IN',
					];
				}

				// Exclude current product.
				$query_args['post__not_in'][] = $product_id;

				if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {

					$query_args['tax_query'][] = [
						'taxonomy' => 'product_visibility',
						'field'    => 'term_taxonomy_id',
						'terms'    => $product_visibility_term_ids['outofstock'],
						'operator' => 'NOT IN',
					];
				}

				if ( ! empty( $product_visibility_term_ids['exclude-from-catalog'] ) ) {

					$query_args['tax_query'][] = [
						'taxonomy' => 'product_visibility',
						'field'    => 'term_taxonomy_id',
						'terms'    => $product_visibility_term_ids['exclude-from-catalog'],
						'operator' => 'NOT IN',
					];
				}

				// Default ordering args.
				$ordering_args = WC()->query->get_catalog_ordering_args( $settings['orderby'], $settings['order'] );

				$query_args['orderby'] = $ordering_args['orderby'];
				$query_args['order']   = $ordering_args['order'];

				$query_args = $this->filter_query_args( $query_args, $settings );

				$this->query = PP_Posts_Query_Builder::run( $query_args );

			} else {

				$query_args = $this->get_empty_query_args();

				// Default ordering args.
				$ordering_args = WC()->query->get_catalog_ordering_args( $settings['orderby'], $settings['order'] );

				$query_args['orderby'] = $ordering_args['orderby'];
				$query_args['order']   = $ordering_args['order'];

				$query_args = $this->filter_query_args( $query_args, $settings );

				$this->query = PP_Posts_Query_Builder::run( $query_args );
			}
		} elseif ( 'upsells' === $settings['source'] ) {
			global $product;

			$ajax_product_id = $this->get_ajax_product_id();

			if ( $ajax_product_id ) {
				$product = new \WC_Product( $ajax_product_id );
			}

			if ( is_product() && $product instanceof \WC_Product && $product->get_id() ) {

				$product_id  = $product->get_id();
				$upsells     = $product->get_upsell_ids();

				if ( ! empty( $upsells ) ) {

					$meta_query = WC()->query->get_meta_query();

					$query_args = [
						'post_type'      => 'product',
						'post_status'    => 'publish',
						'posts_per_page' => $this->get_products_per_page( $settings, true ),
						'paged'          => 1,
						'post__in'       => $upsells,
						'post__not_in'   => [ $product_id ],
						'meta_query'     => $meta_query,
						'no_found_rows'  => ! $this->needs_found_rows( $settings ),
					];

					if ( $this->needs_found_rows( $settings ) ) {
						$query_args['paged'] = $this->get_ajax_paged( get_query_var( 'paged' ) );
					}
				} else {
					$query_args = $this->get_empty_query_args();
				}
			} else {
				$query_args = $this->get_empty_query_args();
			}
			// Default ordering args.
			$ordering_args = WC()->query->get_catalog_ordering_args( $settings['orderby'], $settings['order'] );

			$query_args['orderby'] = $ordering_args['orderby'];
			$query_args['order']   = $ordering_args['order'];

			$query_args = $this->filter_query_args( $query_args, $settings );

			$this->query = PP_Posts_Query_Builder::run( $query_args );
		} elseif ( 'cross_sells' === $settings['source'] ) {
			$cart_data = WC()->cart;
			if ( ! WC()->cart->is_empty() ) {

				$upsell_ids    = [];
				$cart_item_ids = [];

				// Loop through cart items
				foreach ( $cart_data->get_cart() as $cart_item ) {
					// Merge all cart items upsells ids.
					$upsell_ids      = array_merge( $upsell_ids, $cart_item['data']->get_upsell_ids() );
					$cart_item_ids[] = $cart_item['product_id'];
				}

				// Remove cart item ids from upsells.
				$upsell_ids = array_diff( $upsell_ids, $cart_item_ids );
				$upsell_ids = array_unique( $upsell_ids ); // Remove duplicated Ids.

				if ( ! empty( $upsell_ids ) ) {

					$meta_query = WC()->query->get_meta_query();

					$query_args = [
						'post_type'      => 'product',
						'post_status'    => 'publish',
						'posts_per_page' => $this->get_products_per_page( $settings, true ),
						'paged'          => 1,
						'post__in'       => $upsell_ids,
						'post__not_in'   => $cart_item_ids,
						'meta_query'     => $meta_query,
						'no_found_rows'  => ! $this->needs_found_rows( $settings ),
					];

					if ( $this->needs_found_rows( $settings ) ) {
						$query_args['paged'] = $this->get_ajax_paged( get_query_var( 'paged' ) );
					}
				} else {
					$query_args = $this->get_empty_query_args();
				}
			} else {
				$query_args = $this->get_empty_query_args();
			}
			// Default ordering args.
			$ordering_args = WC()->query->get_catalog_ordering_args( $settings['orderby'], $settings['order'] );

			$query_args['orderby'] = $ordering_args['orderby'];
			$query_args['order']   = $ordering_args['order'];

			$query_args = $this->filter_query_args( $query_args, $settings );

			$this->query = PP_Posts_Query_Builder::run( $query_args );
		} elseif ( 'recently_viewed' === $settings['source'] ) {
			$cookie_usermeta_name = 'pp_viewed_products_ids';
			$recently_product_ids = [];
			$query_args           = [];
			if ( is_user_logged_in() ) {
				$user_viewed = get_user_meta( get_current_user_id(), $cookie_usermeta_name, true );

				if ( ! empty( $user_viewed ) && is_array( $user_viewed ) ) {
					$recently_product_ids = array_map( 'intval', $user_viewed );
				}
			} else {
				if ( isset( $_COOKIE[ $cookie_usermeta_name ] ) ) {
					$cookie_ids = explode( ',', sanitize_text_field( wp_unslash( $_COOKIE[ $cookie_usermeta_name ] ) ) );
					$recently_product_ids = array_filter( array_map( 'absint', $cookie_ids ) );
				}
			}

			if ( ! empty( $recently_product_ids ) ) {
				if ( 'desc' === $settings['order'] ) {
					$recently_product_ids = array_reverse( $recently_product_ids );
				}

				// Honours the carousel limit too, which the grid-only read missed.
				$products_per_page    = $this->get_products_per_page( $settings );
				$recently_product_ids = array_slice( $recently_product_ids, 0, $products_per_page );

				$query_args = [
					'post_type'      => 'product',
					'post_status'    => 'publish',
					'posts_per_page' => $products_per_page,
					'paged'          => 1,
					'post__in'       => $recently_product_ids,
					'orderby'        => 'post__in',
					'no_found_rows'  => ! $this->needs_found_rows( $settings ),
				];
			}

			if ( empty( $query_args ) ) {
				// No recently viewed products — return an empty result set.
				$query_args = $this->get_empty_query_args();
			}

			$query_args = $this->filter_query_args( $query_args, $settings );

			$this->query = PP_Posts_Query_Builder::run( $query_args );
		} else {

			global $post;
			$product_visibility_term_ids = wc_get_product_visibility_term_ids();

			$query_args = [
				'post_type'      => 'product',
				// This query is only bounded by the catalogue itself, so an unset
				// or zero limit must never fall through to -1.
				'posts_per_page' => $this->get_products_per_page( $settings ),
				'paged'          => 1,
				'post__not_in'   => [],
				'no_found_rows'  => ! $this->needs_found_rows( $settings ),
			];

			if ( $this->needs_found_rows( $settings ) ) {
				$query_args['paged'] = $this->get_ajax_paged( max( 1, get_query_var( 'paged' ), get_query_var( 'page' ) ) );
			}

			// Default ordering args.
			/* $ordering_args = WC()->query->get_catalog_ordering_args( $settings['orderby'], $settings['order'] );

			$query_args['orderby'] = $ordering_args['orderby'];
			$query_args['order']   = $ordering_args['order']; */

			if ( 'price' === $settings['orderby'] || 'popularity' === $settings['orderby'] || 'rating' === $settings['orderby'] ) {
				if ( 'price' === $settings['orderby'] ) {
					$query_args['meta_key'] = '_price';
				} elseif ( 'popularity' === $settings['orderby'] ) {
					$query_args['meta_key'] = 'total_sales';
				} elseif ( 'rating' === $settings['orderby'] ) {
					$query_args['meta_key'] = '_wc_average_rating';
				}

				$query_args['orderby'] = 'meta_value_num';
				$query_args['order']   = $settings['order'];
			} else {
				$ordering_args = WC()->query->get_catalog_ordering_args( $settings['orderby'], $settings['order'] );

				$query_args['orderby'] = $ordering_args['orderby'];
				$query_args['order']   = $ordering_args['order'];
			}

			if ( 'sale' === $settings['filter_by'] ) {

				$query_args['post__in'] = array_merge( [ 0 ], wc_get_product_ids_on_sale() );
			} elseif ( 'featured' === $settings['filter_by'] ) {

				$query_args['tax_query'][] = [
					'taxonomy' => 'product_visibility',
					'field'    => 'term_taxonomy_id',
					'terms'    => $product_visibility_term_ids['featured'],
				];
			} elseif ( 'top_rated' === $settings['filter_by'] ) {
				$query_args['meta_key']   = '_wc_average_rating';
				$query_args['orderby']    = 'meta_value_num';
				$query_args['meta_query'] = WC()->query->get_meta_query();
				$query_args['tax_query']  = WC()->query->get_tax_query();
			} elseif ( 'best_selling' === $settings['filter_by'] ) {
				$query_args['meta_key'] = 'total_sales';
				$query_args['order']    = 'DESC';
				$query_args['orderby']  = 'meta_value_num';
			}

			if ( 'custom' === $settings['source'] ) {

				if ( ! empty( $settings['category_filter'] ) ) {

					$cat_operator = $settings['category_filter_rule'];

					$query_args['tax_query'][] = [
						'taxonomy' => 'product_cat',
						'field'    => 'slug',
						'terms'    => $settings['category_filter'],
						'operator' => $cat_operator,
					];
				}

				if ( ! empty( $settings['tag_filter'] ) ) {

					$tag_operator = $settings['tag_filter_rule'];

					$query_args['tax_query'][] = [
						'taxonomy' => 'product_tag',
						'field'    => 'slug',
						'terms'    => $settings['tag_filter'],
						'operator' => $tag_operator,
					];
				}

				if ( 0 < $settings['offset'] ) {

					/**
					 * Offser break the pagination. Using WordPress's work around
					 *
					 * @see https://codex.wordpress.org/Making_Custom_Queries_using_Offset_and_Pagination
					 */
					$query_args[ PP_Posts_Query_Builder::OFFSET_QUERY_VAR ] = $settings['offset'];
				}
			}

			if ( 'manual' === $settings['source'] ) {

				$manual_ids = $settings['query_manual_ids'];

				$query_args['post__in'] = $manual_ids;

				// When "Manual Selection" is chosen as the order, preserve the exact order in which
				// products were added in the "Select Products" field. WP_Query only honors the
				// post__in array order when orderby is set to post__in.
				if ( 'post__in' === $settings['orderby'] ) {
					$query_args['orderby'] = 'post__in';
				}
			}

			if ( 'manual' !== $settings['source'] ) {

				if ( '' !== $settings['query_exclude_ids'] ) {

					$exclude_ids = $settings['query_exclude_ids'];

					$query_args['post__not_in'] = $exclude_ids;
				}

				if ( 'yes' === $settings['query_exclude_current'] ) {

					$query_args['post__not_in'][] = $post->ID;
				}
			}

			if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {

				$query_args['tax_query'][] = [
					'taxonomy' => 'product_visibility',
					'field'    => 'term_taxonomy_id',
					'terms'    => $product_visibility_term_ids['outofstock'],
					'operator' => 'NOT IN',
				];
			}

			if ( ! empty( $product_visibility_term_ids['exclude-from-catalog'] ) ) {

				$query_args['tax_query'][] = [
					'taxonomy' => 'product_visibility',
					'field'    => 'term_taxonomy_id',
					'terms'    => $product_visibility_term_ids['exclude-from-catalog'],
					'operator' => 'NOT IN',
				];
			}

			$query_args = $this->filter_query_args( $query_args, $settings );

			$this->query = PP_Posts_Query_Builder::run( $query_args );
		}

		remove_action( 'pre_get_posts', [ $this, 'pre_get_product_query_filter' ] );
	}

	/**
	 * pre_get_product_query_filter
	 *
	 * @param  mixed $wp_query
	 */
	public function pre_get_product_query_filter( $wp_query ) {
		$settings = $this->get_settings_for_display();
		$query_id = $settings['query_id'];

		/**
		 * Query args.
		 *
		 * It allows developers to alter individual products widget queries.
		 *
		 * The dynamic portion of the hook name '$query_id', refers to the Query ID.
		 *
		 * @since 2.9.7
		 *
		 * @param \WP_Query     $wp_query
		 */
		do_action( "powerpack/products/query/{$query_id}", $wp_query, $this );
	}
}
