<?php
/**
 * PowerPack WooCommerce My Account widget.
 *
 * @package PowerPack
 */

namespace PowerpackElements\Modules\Woocommerce\Widgets;

use PowerpackElements\Base\Powerpack_Widget;
use PowerpackElements\Classes\PP_Helper;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit;   // Exit if accessed directly.
}

/**
 * Class Woo_My_Account.
 *
 * Renders the WooCommerce My Account page inside an Elementor widget by
 * wrapping the [woocommerce_my_account] shortcode.
 *
 * @since 2.0.3
 */
class Woo_My_Account extends Powerpack_Widget {

	/**
	 * Settings resolved for the current render.
	 *
	 * Held so modify_menu_items(), which runs inside the shortcode call in
	 * render(), does not resolve them a second time. Resolving is not free
	 * here: all six tab name controls accept dynamic tags, so every call
	 * re-runs tag parsing over them.
	 *
	 * @since 3.0.0
	 * @access private
	 * @var array|null
	 */
	private $render_settings = null;

	/**
	 * Retrieve woo my account widget categories.
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return parent::get_woo_categories();
	}

	/**
	 * Retrieve woo my account widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Woo_My_Account' );
	}

	/**
	 * Retrieve woo my account widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Woo_My_Account' );
	}

	/**
	 * Retrieve woo my account widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Woo_My_Account' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 1.4.13.4
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Woo_My_Account' );
	}

	/**
	 * Retrieve the list of scripts the Woo - My Account depended on.
	 *
	 * Used to set style dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [
			'pp-woo-my-account',
		];
	}

	/**
	 * Retrieve the list of styles the Woo - My Account depended on.
	 *
	 * Used to set style dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_style_depends() {
		return [
			'pp-woocommerce',
		];
	}

	/**
	 * Whether the widget renders Elementor's inner wrapper element.
	 *
	 * Returns false when the Optimized Markup experiment is active, so the
	 * extra '.elementor-widget-container' div is dropped.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @return bool Whether to render the inner wrapper.
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Retrieve the My Account endpoints offered by the Preview control.
	 *
	 * Keys are the endpoint slugs WooCommerce actually registers, which store
	 * owners can rename under WooCommerce > Settings > Advanced. Reading them
	 * back from WC_Query keeps the preview working on those stores; falling
	 * back to WooCommerce's own defaults keeps it working if WC is not loaded
	 * yet. An empty key stands for the Dashboard, which is what WooCommerce
	 * falls back to when no endpoint query var is set.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @return array Endpoint slug => label.
	 */
	public static function get_endpoints() {
		$labels = [
			'orders'       => esc_html__( 'Orders', 'powerpack' ),
			'downloads'    => esc_html__( 'Downloads', 'powerpack' ),
			'edit-address' => esc_html__( 'Addresses', 'powerpack' ),
			'edit-account' => esc_html__( 'Account Details', 'powerpack' ),
		];

		$query_vars = [];

		if ( function_exists( 'WC' ) && isset( WC()->query ) ) {
			$query_vars = WC()->query->get_query_vars();
		}

		$endpoints = [ '' => esc_html__( 'Dashboard', 'powerpack' ) ];

		foreach ( $labels as $endpoint_key => $label ) {
			$slug = ! empty( $query_vars[ $endpoint_key ] ) ? $query_vars[ $endpoint_key ] : $endpoint_key;

			$endpoints[ $slug ] = $label;
		}

		return $endpoints;
	}

	/**
	 * Register Woo - My Account widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function register_controls() {
		/* Content: General */
		$this->register_content_controls_general();

		/* Content: Tabs */
		$this->register_content_controls_tabs();

		/* Style: Tabs */
		$this->register_style_controls_tabs();

		/* Style: Tables */
		$this->register_style_controls_tables();

		/* Style: Buttons */
		$this->register_style_controls_buttons();

		/* Style: Forms */
		$this->register_style_controls_forms();

		/* Style: Notices */
		$this->register_style_controls_notices();

	}

	/**
	 * Content Tab: Preview
	 * -------------------------------------------------
	 */
	protected function register_content_controls_general() {

		$this->start_controls_section(
			'section_content_general',
			[
				'label' => esc_html__( 'Preview', 'powerpack' ),
			]
		);

		$this->add_control(
			'endpoint',
			[
				'label'   => esc_html__( 'Select Endpoint', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => self::get_endpoints(),
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Content Tab: Tabs
	 * -------------------------------------------------
	 */
	protected function register_content_controls_tabs() {

		$this->start_controls_section(
			'section_content_tabs',
			[
				'label' => esc_html__( 'Tabs', 'powerpack' ),
			]
		);

		$this->add_control(
			'show_dashboard',
			[
				'label'        => esc_html__( 'Show Dashboard', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'dashboard_tab_name',
			[
				'label'     => esc_html__( 'Tab Name', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Dashboard', 'powerpack' ),
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'show_dashboard' => 'yes',
				],
			]
		);

		$this->add_control(
			'show_orders',
			[
				'label'        => esc_html__( 'Show Orders', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'orders_tab_name',
			[
				'label'     => esc_html__( 'Tab Name', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Orders', 'powerpack' ),
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'show_orders' => 'yes',
				],
			]
		);

		$this->add_control(
			'show_downloads',
			[
				'label'        => esc_html__( 'Show Downloads', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'downloads_tab_name',
			[
				'label'     => esc_html__( 'Tab Name', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Downloads', 'powerpack' ),
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'show_downloads' => 'yes',
				],
			]
		);

		$this->add_control(
			'show_addresses',
			[
				'label'        => esc_html__( 'Show Addresses', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'addresses_tab_name',
			[
				'label'     => esc_html__( 'Tab Name', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Addresses', 'powerpack' ),
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'show_addresses' => 'yes',
				],
			]
		);

		$this->add_control(
			'show_account_details',
			[
				'label'        => esc_html__( 'Show Account Details', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'account_details_tab_name',
			[
				'label'     => esc_html__( 'Tab Name', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Account Details', 'powerpack' ),
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'show_account_details' => 'yes',
				],
			]
		);

		$this->add_control(
			'show_logout_link',
			[
				'label'        => esc_html__( 'Show Logout Link', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'logout_link_tab_name',
			[
				'label'     => esc_html__( 'Tab Name', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Logout', 'powerpack' ),
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'show_logout_link' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Tabs
	 * -------------------------------------------------
	 */
	protected function register_style_controls_tabs() {

		$this->start_controls_section(
			'section_tabs_style',
			[
				'label' => esc_html__( 'Tabs', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'tab_position',
			[
				'label'        => esc_html__( 'Tab Position', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'left',
				'options'      => [
					'left'  => esc_html__( 'Left', 'powerpack' ),
					'right' => esc_html__( 'Right', 'powerpack' ),
					'top'   => esc_html__( 'Top', 'powerpack' ),
				],
				'prefix_class' => 'pp-woo-tab-position%s-',
			]
		);

		$this->add_control(
			'tabs_alignment',
			[
				'label'                => esc_html__( 'Alignment', 'powerpack' ),
				'type'                 => Controls_Manager::CHOOSE,
				'label_block'          => false,
				'options'              => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'              => 'left',
				/*
				 * The tab list is a flex row when the tabs sit on top, so the
				 * alignment belongs on the main axis. The previous rule also
				 * set align-items, which is the cross axis and does not accept
				 * left/right at all.
				 */
				'selectors_dictionary' => [
					'left'   => 'flex-start',
					'center' => 'center',
					'right'  => 'flex-end',
				],
				'selectors'            => [
					'{{WRAPPER}}.pp-woo-tab-position-top .woocommerce .woocommerce-MyAccount-navigation ul' => 'justify-content: {{VALUE}};',
					'(tablet) {{WRAPPER}}.pp-woo-tab-position-tablet-top .woocommerce .woocommerce-MyAccount-navigation ul' => 'justify-content: {{VALUE}};',
					'(mobile) {{WRAPPER}}.pp-woo-tab-position-mobile-top .woocommerce .woocommerce-MyAccount-navigation ul' => 'justify-content: {{VALUE}};',
				],
				/*
				 * Shown as soon as any breakpoint puts the tabs on top. A
				 * plain 'condition' array is ANDed, which hid this control
				 * unless all three were set to top at once.
				 */
				'conditions'           => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'     => 'tab_position',
							'operator' => '===',
							'value'    => 'top',
						],
						[
							'name'     => 'tab_position_tablet',
							'operator' => '===',
							'value'    => 'top',
						],
						[
							'name'     => 'tab_position_mobile',
							'operator' => '===',
							'value'    => 'top',
						],
					],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'tab_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'global'   => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-navigation ul li a',
			]
		);

		$this->add_responsive_control(
			'tabs_spacing',
			[
				'label'      => esc_html__( 'Spacing between Tabs & Content', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'size' => 30,
				],
				'selectors'  => [
					'{{WRAPPER}}.pp-woo-tab-position-top .pp-woo-my-account .woocommerce-MyAccount-navigation' => 'margin-bottom: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}}.pp-woo-tab-position-left .pp-woo-my-account .woocommerce-MyAccount-content,
					{{WRAPPER}}.pp-woo-tab-position-right .pp-woo-my-account .woocommerce-MyAccount-content' => 'width: calc( 70% - {{SIZE}}{{UNIT}} )',
					'(mobile){{WRAPPER}}.pp-woo-tab-position-left .pp-woo-my-account .woocommerce-MyAccount-content,
					{{WRAPPER}}.pp-woo-tab-position-right .pp-woo-my-account .woocommerce-MyAccount-content' => 'width: calc( 100% - {{SIZE}}{{UNIT}} )',
				],
			]
		);

		$this->add_responsive_control(
			'tab_margin',
			[
				'label'      => esc_html__( 'Spacing between Tabs', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}.pp-woo-tab-position-top .woocommerce .woocommerce-MyAccount-navigation ul li' => 'margin-right: {{SIZE}}{{UNIT}}',
					'(tablet) {{WRAPPER}}.pp-woo-tab-position-tablet-top .woocommerce .woocommerce-MyAccount-navigation ul li' => 'margin-right: {{SIZE}}{{UNIT}}',
					'(mobile) {{WRAPPER}}.pp-woo-tab-position-mobile-top .woocommerce .woocommerce-MyAccount-navigation ul li' => 'margin-right: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}}.pp-woo-tab-position-left .woocommerce .woocommerce-MyAccount-navigation ul li'  => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-right:0;',
					'(tablet) {{WRAPPER}}.pp-woo-tab-position-tablet-left .woocommerce .woocommerce-MyAccount-navigation ul li'  => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-right:0;',
					'(mobile) {{WRAPPER}}.pp-woo-tab-position-mobile-left .woocommerce .woocommerce-MyAccount-navigation ul li' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-right:0;',
					'{{WRAPPER}}.pp-woo-tab-position-right .woocommerce .woocommerce-MyAccount-navigation ul li' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-right:0;',
					'(tablet) {{WRAPPER}}.pp-woo-tab-position-tablet-right .woocommerce .woocommerce-MyAccount-navigation ul li' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-right:0;',
					'(mobile) {{WRAPPER}}.pp-woo-tab-position-mobile-right .woocommerce .woocommerce-MyAccount-navigation ul li' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-right:0;',
				],
			]
		);

		$this->add_responsive_control(
			'tab_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-navigation ul li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_style' );

		$this->start_controls_tab(
			'tabs_normal',
			[
				'label' => esc_html__( 'Default', 'powerpack' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'tab_bg_color',
				'label'    => esc_html__( 'Background', 'powerpack' ),
				'types'    => [ 'classic', 'gradient' ],
				'exclude'  => [ 'image' ],
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-navigation ul li a',
			]
		);

		$this->add_control(
			'tab_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-navigation ul li a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'tab_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-navigation ul li a',
			]
		);

		$this->add_responsive_control(
			'tab_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-navigation ul li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'tab_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-navigation ul li a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tabs_style_active',
			[
				'label' => esc_html__( 'Active', 'powerpack' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'active_tab_bg_color',
				'label'    => esc_html__( 'Background', 'powerpack' ),
				'types'    => [ 'classic', 'gradient' ],
				'exclude'  => [ 'image' ],
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-navigation ul li.is-active a, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-navigation ul li:hover a',
			]
		);

		$this->add_control(
			'active_tab_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-navigation ul li.is-active a, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-navigation ul li:hover a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'active_tab_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-navigation ul li.is-active a, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-navigation ul li:hover a' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'active_tab_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-navigation ul li.is-active a, {{WRAPPER}} .pp-woo-my-account .woocommerce-MyAccount-navigation ul li:hover a',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'tabs_content_heading',
			[
				'label'     => esc_html__( 'Tab Content', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'tab_content_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'tab_content_link_color',
			[
				'label'     => esc_html__( 'Link Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'tab_content_link_hover',
			[
				'label'     => esc_html__( 'Link Hover Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'tab_content_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'global'   => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Tables
	 * -------------------------------------------------
	 */
	protected function register_style_controls_tables() {

		$this->start_controls_section(
			'section_tables_style',
			[
				'label' => esc_html__( 'Tables', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'table_heading',
			[
				'label' => esc_html__( 'Table', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'table_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'global'   => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce table thead th, {{WRAPPER}} .pp-woo-my-account .woocommerce table tbody td, {{WRAPPER}} .pp-woo-my-account .woocommerce table tfoot td',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'table_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '',
				'default'     => '',
				'selector'    => '{{WRAPPER}} .pp-woo-my-account .woocommerce table',
			]
		);

		$this->add_responsive_control(
			'table_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce table' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'table_margin',
			[
				'label'      => esc_html__( 'Margin', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce table' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'table_header_heading',
			[
				'label'     => esc_html__( 'Header', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'table_header_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'global'   => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce table thead th',
			]
		);

		$this->add_control(
			'table_header_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce table thead th' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'table_header_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce table thead th' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'table_header_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '',
				'default'     => '',
				'selector'    => '{{WRAPPER}} .pp-woo-my-account .woocommerce table thead th',
			]
		);

		$this->add_responsive_control(
			'table_header_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce table thead th' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'table_rows_heading',
			[
				'label'     => esc_html__( 'Rows', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'table_rows_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce table tbody tr td' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'table_rows_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce table tbody tr td' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'table_even_rows_bg_color',
			[
				'label'     => esc_html__( 'Even Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce table tbody tr:nth-child(even) td' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'table_even_rows_text_color',
			[
				'label'     => esc_html__( 'Even Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce table tbody tr:nth-child(even) td' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'table_row_vertical_align',
			[
				'label'       => esc_html__( 'Vertical Align', 'powerpack' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'     => [
					'top'    => [
						'title' => esc_html__( 'Top', 'powerpack' ),
						'icon'  => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_html__( 'Middle', 'powerpack' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_html__( 'Bottom', 'powerpack' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'selectors'   => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce table tbody tr td'   => 'vertical-align: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'table_row_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '',
				'default'     => '',
				'selector'    => '{{WRAPPER}} .pp-woo-my-account .woocommerce table tbody tr th, {{WRAPPER}} .pp-woo-my-account .woocommerce table tbody tr td,
								{{WRAPPER}} .pp-woo-my-account .woocommerce table tfoot tr th, {{WRAPPER}} .pp-woo-my-account .woocommerce table tfoot tr td',
			]
		);

		$this->add_control(
			'table_cells_heading',
			[
				'label'     => esc_html__( 'Cell', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'table_cell_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '',
				'default'     => '',
				'selector'    => '{{WRAPPER}} .pp-woo-my-account .woocommerce table tbody tr td',
			]
		);

		$this->add_responsive_control(
			'table_cell_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce table tbody tr td' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'table_footer_heading',
			[
				'label'     => esc_html__( 'Footer', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'table_footer_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'global'   => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce table tfoot td',
			]
		);

		$this->add_control(
			'table_footer_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce table tfoot td' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'table_footer_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce table tfoot td' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'table_footer_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '',
				'default'     => '',
				'selector'    => '{{WRAPPER}} .pp-woo-my-account .woocommerce table tfoot td',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Button
	 * -------------------------------------------------
	 */
	protected function register_style_controls_buttons() {

		$this->start_controls_section(
			'buttons_style',
			[
				'label' => esc_html__( 'Buttons', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'button_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'global'   => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content .button',
			]
		);

		$this->start_controls_tabs( 'tabs_button_style' );

		$this->start_controls_tab(
			'tab_button_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content .button' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content .button' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content .button',
			]
		);

		$this->add_responsive_control(
			'button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content .button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content .button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'button_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content .button',
			]
		);

		$this->add_control(
			'order_section_button_settings',
			[
				'label'     => esc_html__( 'Orders Section', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'order_section_button_spacing',
			[
				'label'       => esc_html__( 'Button Spacing', 'powerpack' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ 'px', 'em', 'rem', 'custom' ],
				'default'     => [
					'unit' => 'px',
					'size' => 0,
				],
				'description' => esc_html__( 'Use this spacing when there is more than one action button in the Orders table Actions column.', 'powerpack' ),
				'selectors'   => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce td.woocommerce-orders-table__cell.woocommerce-orders-table__cell-order-actions .woocommerce-button' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content .button:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content .button:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content .button:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'button_box_shadow_hover',
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content .button:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();

	}

	/**
	 * Style Tab: Forms
	 * -------------------------------------------------
	 */
	protected function register_style_controls_forms() {

		$this->start_controls_section(
			'section_form_style',
			[
				'label' => esc_html__( 'Forms', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'form_heading',
			[
				'label' => esc_html__( 'Form', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'form_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce form' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'form_link_color',
			[
				'label'     => esc_html__( 'Link Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce form a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'form_link_hover_color',
			[
				'label'     => esc_html__( 'Link Hover Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce form a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'form_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce form',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'form_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-my-account .woocommerce form',
			]
		);

		$this->add_responsive_control(
			'form_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce form' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'form_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce form',
			]
		);

		$this->add_responsive_control(
			'form_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce form' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'form_title_heading',
			[
				'label'     => esc_html__( 'Headings', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'form_title_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'global'   => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce h2, {{WRAPPER}} .pp-woo-my-account .woocommerce h3',
			]
		);

		$this->add_control(
			'form_title_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce h2, {{WRAPPER}} .pp-woo-my-account .woocommerce h3' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'form_title_margin',
			[
				'label'              => esc_html__( 'Margin', 'powerpack' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'allowed_dimensions' => 'vertical',
				'placeholder'        => [
					'top'    => '',
					'right'  => 'auto',
					'bottom' => '',
					'left'   => 'auto',
				],
				'selectors'          => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce h2, {{WRAPPER}} .pp-woo-my-account .woocommerce h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		/** Inputs */
		$this->add_control(
			'form_inputs',
			[
				'label'     => esc_html__( 'Inputs', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'inputs_text_align',
			[
				'label'       => esc_html__( 'Text Alignment', 'powerpack' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'     => 'left',
				'selectors'   => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .form-row .input-text' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'input_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'global'   => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .form-row .input-text',
			]
		);

		$this->add_control(
			'input_text_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .form-row .input-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'input_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .form-row .input-text' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'input_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-my-account .woocommerce .form-row .input-text',
			]
		);

		$this->add_responsive_control(
			'input_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .form-row .input-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'input_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .form-row .input-text',
			]
		);

		$this->add_responsive_control(
			'input_gap',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .form-row' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'input_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .form-row .input-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'input_height',
			[
				'label'      => esc_html__( 'Input Height', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 35,
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .form-row .input-text' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		/** Form Labels */
		$this->add_control(
			'form_labels',
			[
				'label'     => esc_html__( 'Labels', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'form_label_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'global'   => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .form-row label',
			]
		);

		$this->add_control(
			'form_label_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .form-row label' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'form_label_margin',
			[
				'label'      => esc_html__( 'Margin', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .form-row label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		/** Form Buttons */
		$this->add_control(
			'form_buttons',
			[
				'label'     => esc_html__( 'Buttons', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'form_button_align',
			[
				'label'       => esc_html__( 'Alignment', 'powerpack' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'default'     => 'left',
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'selectors'   => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-form-register .form-row:last-child,
					{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-form-login .form-row:last-child,
					{{WRAPPER}} .pp-woo-my-account .woocommerce form .pp-my-account-button' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'form_button_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'global'   => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce form .form-row button, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content form .button',
			]
		);

		$this->add_control(
			'form_button_width',
			[
				'label'        => esc_html__( 'Width', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'auto',
				'options'      => [
					'auto'   => esc_html__( 'Auto', 'powerpack' ),
					'full'   => esc_html__( 'Full Width', 'powerpack' ),
					'custom' => esc_html__( 'Custom', 'powerpack' ),
				],
				'prefix_class' => 'pp-woo-my-account-button-',
			]
		);

		$this->add_responsive_control(
			'form_button_custom_width',
			[
				'label'      => esc_html__( 'Custom Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 50,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce form .form-row button, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content form .button' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'form_button_width' => 'custom',
				],
			]
		);

		$this->add_responsive_control(
			'form_button_margin',
			[
				'label'              => esc_html__( 'Margin', 'powerpack' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'allowed_dimensions' => 'vertical',
				'placeholder'        => [
					'top'    => '',
					'right'  => 'auto',
					'bottom' => '',
					'left'   => 'auto',
				],
				'selectors'          => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce form .form-row button, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content form .button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_form_button_style' );

		$this->start_controls_tab(
			'tab_form_button_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'form_button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce form .form-row button, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content form .button' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'form_button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce form .form-row button, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content form .button' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'form_button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-my-account .woocommerce form .form-row button, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content form .button',
			]
		);

		$this->add_responsive_control(
			'form_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce form .form-row button, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content form .button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'form_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce form .form-row button, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content form .button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'form_button_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce form .form-row button, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content form .button',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_form_button_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'form_button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce form .form-row button:hover, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content form .button:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'form_button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce form .form-row button:hover, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content form .button:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'form_button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce form .form-row button:hover, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content form .button:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'form_button_box_shadow_hover',
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce form .form-row button:hover, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-MyAccount-content form .button:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Notices
	 * -------------------------------------------------
	 */
	protected function register_style_controls_notices() {

		$this->start_controls_section(
			'section_notices_style',
			[
				'label' => esc_html__( 'Notices', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		/** Form Errors */
		$this->add_control(
			'form_errors',
			[
				'label' => esc_html__( 'Errors', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'error_message_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-error' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'error_message_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-error' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'error_message_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-error:before' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'error_message_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-error',
			]
		);

		$this->add_responsive_control(
			'error_message_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-error' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'error_message_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-error' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'error_message_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-error',
			]
		);

		/** Notices */
		$this->add_control(
			'form_notices',
			[
				'label'     => esc_html__( 'General Notices', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'notice_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-info, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-message' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'notice_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-info, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-message' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'notice_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-info:before, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-message:before' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'notice_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-info, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-message',
			]
		);

		$this->add_responsive_control(
			'notice_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-info, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-message' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'notice_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-info, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-message' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'notice_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-info, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-message',
			]
		);

		/** Notices Typography */

		$this->add_control(
			'form_notices_typography',
			[
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'notice_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'global'   => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-error, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-info, {{WRAPPER}} .pp-woo-my-account .woocommerce .woocommerce-message',
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Filter the WooCommerce My Account menu items.
	 *
	 * Drops the tabs switched off in the widget settings and relabels the rest
	 * from their Tab Name controls. Hooked only for the duration of the
	 * shortcode call in render().
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @param array $items Menu items, keyed by WooCommerce endpoint key.
	 * @return array Filtered menu items.
	 */
	public function modify_menu_items( $items ) {
		// Set by render(), which is the only place this filter is hooked.
		$settings = ( null !== $this->render_settings ) ? $this->render_settings : $this->get_settings_for_display();

		$menu_links = [
			'dashboard'       => [
				'field_key' => 'dashboard',
				'tab_name'  => esc_html__( 'Dashboard', 'powerpack' ),
			],
			'orders'          => [
				'field_key' => 'orders',
				'tab_name'  => esc_html__( 'Orders', 'powerpack' ),
			],
			'downloads'       => [
				'field_key' => 'downloads',
				'tab_name'  => esc_html__( 'Downloads', 'powerpack' ),
			],
			'addresses'       => [
				'field_key' => 'edit-address',
				'tab_name'  => esc_html__( 'Addresses', 'powerpack' ),
			],
			'account_details' => [
				'field_key' => 'edit-account',
				'tab_name'  => esc_html__( 'Account Details', 'powerpack' ),
			],
			'logout_link'     => [
				'field_key' => 'customer-logout',
				'tab_name'  => esc_html__( 'Logout', 'powerpack' ),
			],
		];

		foreach ( $menu_links as $tab_key => $tab ) {
			if ( 'yes' !== $settings[ 'show_' . $tab_key ] ) {
				unset( $items[ $tab['field_key'] ] ); // Remove the tab.
				continue;
			}

			/*
			 * These labels are dynamic-tag capable, so the value can come from
			 * post meta rather than from whoever built the page. Strip markup
			 * here rather than escaping: WooCommerce's navigation template
			 * runs the label through esc_html(), so escaping now would
			 * double-encode a label such as "Orders & Returns", while a theme
			 * shipping its own navigation.php override is under no obligation
			 * to escape at all.
			 */
			$label = trim( wp_strip_all_tags( (string) $settings[ $tab_key . '_tab_name' ] ) );

			/*
			 * WooCommerce prints the label as the tab link's only content, so
			 * an empty Tab Name would leave a focusable link with no
			 * accessible name. Fall back to the tab's default label.
			 */
			$items[ $tab['field_key'] ] = ( '' !== $label ) ? $label : $tab['tab_name'];
		}

		return $items;
	}

	/**
	 * Build the My Account shortcode string.
	 *
	 * The shortcode takes no attributes. It used to interpolate the
	 * 'shortcode' render attribute, which this widget never sets, so the
	 * result was this same literal with a stray trailing space.
	 *
	 * @since 3.0.0
	 * @access private
	 *
	 * @return string The [woocommerce_my_account] shortcode.
	 */
	private function get_shortcode() {

		return '[woocommerce_my_account]';
	}

	/**
	 * Render output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		// Reused by modify_menu_items() while the shortcode runs, below.
		$this->render_settings = $settings;

		$this->add_render_attribute(
			'container',
			'class',
			[
				'pp-woocommerce',
				'pp-woo-my-account',
				'clearfix',
			]
		);

		?>
		<div <?php $this->print_render_attribute_string( 'container' ); ?>>
			<?php
			/**
			 * Fires inside the Woo - My Account widget wrapper, before the
			 * account markup is printed.
			 *
			 * @since 3.0.0
			 */
			do_action( 'pp_woo_before_my_account_wrap' );

			/**
			 * Fires before the My Account shortcode is rendered.
			 *
			 * @since 3.0.0
			 *
			 * @param array $settings The widget settings.
			 */
			do_action( 'pp_woo_before_my_account_content', $settings );

			/*
			 * Force the previewed endpoint in the Editor only. WooCommerce
			 * dispatches on the first matching key in $wp->query_vars and
			 * returns, so this has to be taken back off again afterwards:
			 * left in place it would leak into every widget rendered later in
			 * the request, and a second My Account widget on the same page
			 * would render this one's endpoint instead of its own.
			 */
			$previewed_endpoint = '';

			if ( ! empty( $settings['endpoint'] ) && PP_Helper::elementor()->editor->is_edit_mode()
				&& array_key_exists( $settings['endpoint'], self::get_endpoints() ) ) {
				global $wp;

				// Only ours to remove if it was not already set for this request.
				if ( ! isset( $wp->query_vars[ $settings['endpoint'] ] ) ) {
					$previewed_endpoint = $settings['endpoint'];
				}

				$wp->query_vars[ $settings['endpoint'] ] = 1;
			}

			add_filter( 'woocommerce_account_menu_items', [ $this, 'modify_menu_items' ] );
			echo do_shortcode( '[woocommerce_my_account]' );
			remove_filter( 'woocommerce_account_menu_items', [ $this, 'modify_menu_items' ] );

			// Nothing should read these once the filter is off again.
			$this->render_settings = null;

			if ( '' !== $previewed_endpoint ) {
				global $wp;

				unset( $wp->query_vars[ $previewed_endpoint ] );
			}

			/**
			 * Fires after the My Account shortcode has been rendered.
			 *
			 * @since 3.0.0
			 *
			 * @param array $settings The widget settings.
			 */
			do_action( 'pp_woo_after_my_account_content', $settings );

			/**
			 * Fires inside the Woo - My Account widget wrapper, after the
			 * account markup has been printed.
			 *
			 * @since 3.0.0
			 */
			do_action( 'pp_woo_after_my_account_wrap' );
			?>
		</div>
		<?php
	}

	/**
	 * Render the widget as plain content.
	 *
	 * Used by Elementor when the element is exported without markup, so the
	 * shortcode is printed as-is rather than executed.
	 *
	 * @since 3.0.0
	 * @access public
	 */
	public function render_plain_content() {
		/*
		 * Printed raw on purpose so the shortcode still runs when it is
		 * executed from post content. get_shortcode() returns a hardcoded
		 * literal with no attributes and no settings interpolated into it.
		 */
		echo $this->get_shortcode(); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
