<?php
/**
 * PowerPack WooCommerce Checkout widget.
 *
 * @package PowerPack
 */

namespace PowerpackElements\Modules\Woocommerce\Widgets;

use PowerpackElements\Classes\PP_Config;
use PowerpackElements\Classes\PP_Helper;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

if ( ! defined( 'ABSPATH' ) ) {
	exit;   // Exit if accessed directly.
}

/**
 * Woo - Checkout widget
 */
class Woo_Checkout extends Woo_Base_Widget {

	/**
	 * Cached form field settings, keyed by WooCommerce form field key.
	 *
	 * Populated on the first call to get_reformatted_form_fields().
	 *
	 * @since 2.9.5
	 * @access private
	 *
	 * @var array
	 */
	private $reformatted_form_fields;

	/**
	 * Count of wrapper divs this widget has opened and not yet closed.
	 *
	 * The wrappers are opened and closed across five WooCommerce template hooks.
	 * Counting them lets close_checkout_wrappers() keep the markup balanced when
	 * a theme's own form-checkout.php drops one of those hooks.
	 *
	 * @since 3.0.0
	 * @access private
	 *
	 * @var int
	 */
	private $open_wrappers = 0;

	/**
	 * Memoised copy of the widget settings, with dynamic tags resolved.
	 *
	 * Populated on the first call to get_display_settings() and reset at the top
	 * of render().
	 *
	 * @since 3.0.0
	 * @access private
	 *
	 * @var array
	 */
	private $display_settings;

	/**
	 * Get Display Settings
	 *
	 * get_settings_for_display() parses dynamic tags across the whole settings
	 * array, and this widget has several hundred controls plus three repeaters.
	 * The render hooks below need the settings on every WooCommerce form field, so
	 * the result is resolved once per render rather than per call.
	 *
	 * @since 3.0.0
	 * @access private
	 *
	 * @return array
	 */
	private function get_display_settings() {
		if ( ! isset( $this->display_settings ) ) {
			$this->display_settings = $this->get_settings_for_display();
		}

		return $this->display_settings;
	}

	/**
	 * Retrieve Woo - Checkout widget categories.
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return parent::get_woo_categories();
	}

	/**
	 * Retrieve Woo - Checkout widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Woo_Checkout' );
	}

	/**
	 * Retrieve Woo - Checkout widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Woo_Checkout' );
	}

	/**
	 * Retrieve Woo - Checkout widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Woo_Checkout' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the Woo - Checkout widget belongs to.
	 *
	 * @since 1.4.13.1
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Woo_Checkout' );
	}

	/**
	 * Retrieve the list of styles the Woo - Checkout depended on.
	 *
	 * Used to set style dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_style_depends() {
		return [
			'widget-pp-woo-checkout',
		];
	}

	/**
	 * Whether the widget should be wrapped in Elementor's inner wrapper.
	 *
	 * The widget prints its own .pp-woo-checkout wrapper, so the extra element is
	 * dropped when Elementor's optimized markup experiment is active.
	 *
	 * @since 2.11.8
	 * @access public
	 *
	 * @return bool
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register Woo - Checkout widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function register_controls() {
		/* Product Control */
		$this->register_content_general_controls();

		if ( $this->is_wc_feature_active( 'checkout_login_reminder' ) ) {
			$this->register_content_checkout_login_reminder_controls();
		}

		/* Billing Details */
		$this->register_content_billing_details();

		if ( $this->is_wc_feature_active( 'shipping' ) && ! $this->is_wc_feature_active( 'ship_to_billing_address_only' ) ) {
			$this->register_content_shipping_details();
		}

		/* Additional Information */
		$this->register_content_additional_information();

		if ( $this->is_wc_feature_active( 'signup_and_login_from_checkout' ) ) {
			$this->register_content_signup_and_login_from_checkout_controls();
		}

		/* Your Order */
		$this->register_content_order_summary();

		if ( $this->is_wc_feature_active( 'coupons' ) ) {
			$this->register_content_coupon_controls();
		}

		/* Payment */
		$this->register_content_payment();

		/* Style: Sections */
		$this->register_style_controls_sections();

		/* Style: Columns */
		$this->register_style_controls_columns();

		/* Style: Inputs */
		$this->register_style_controls_inputs();

		/* Style: Returning Customer */
		if ( $this->is_wc_feature_active( 'checkout_login_reminder' ) ) {
			$this->register_style_controls_returning_customer();
		}

		/* Style: Coupon Bar */
		$this->register_style_controls_coupon_bar();

		/* Style: Headings */
		$this->register_style_controls_headings();

		/* Style: Billing Details */
		$this->register_style_controls_billing_details();

		/* Style: Additional Information */
		$this->register_style_controls_additional_fields();

		/* Style: Review Order */
		$this->register_style_controls_review_order();

		/* Style: Payment Method */
		$this->register_style_controls_payment_method();

		/* Style: Purchase Button */
		$this->register_style_controls_purchase_button();
	}

	/**
	 * Register the Layout content controls.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_content_general_controls() {

		$this->start_controls_section(
			'section_layout',
			[
				'label' => esc_html__( 'Layout', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'layout',
			[
				'label'        => esc_html__( 'Layout', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => '1',
				'options'      => [
					'1' => esc_html__( 'One Column', 'powerpack' ),
					'2' => esc_html__( 'Two Columns', 'powerpack' ),
				],
				'prefix_class' => 'pp-checkout-layout-',
				// render() builds a pp-woo-checkout-col- class from this value, so
				// the widget has to re-render for a change to take effect in the
				// editor. A prefix_class on its own would only swap the class
				// Elementor manages.
				'render_type'  => 'template',
			]
		);

		$this->add_control(
			'columns_stack',
			[
				'label'        => esc_html__( 'Stack On', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'tablet',
				'options'      => [
					'tablet' => esc_html__( 'Tablet', 'powerpack' ),
					'mobile' => esc_html__( 'Mobile', 'powerpack' ),
				],
				'prefix_class' => 'pp-woo-cols-stack-',
				'condition'    => [
					'layout' => '2',
				],
			]
		);

		$this->add_responsive_control(
			'column_1_width',
			[
				'label'      => esc_html__( 'First Column Width', 'powerpack' ) . ' (%)',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				// Same device list as Columns Gap below. Both only apply while the
				// columns sit side by side, so neither goes down to mobile.
				'devices'    => [ 'widescreen', 'desktop', 'laptop', 'tablet_extra', 'tablet' ],
				'default'    => [
					'size' => 50,
				],
				'range'      => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'separator'  => 'before',
				'selectors'  => [
					'{{WRAPPER}}' => '--first-column-width: {{SIZE}}%;',
				],
				'condition'  => [
					'layout' => '2',
				],
			]
		);

		$this->add_responsive_control(
			'column_gap',
			[
				'label'      => esc_html__( 'Columns Gap', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'devices'    => [ 'widescreen', 'desktop', 'laptop', 'tablet_extra', 'tablet' ],
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 30,
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--checkout-columns-gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => '2',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Returning Customer content controls.
	 *
	 * @since 2.9.5
	 * @access protected
	 */
	protected function register_content_checkout_login_reminder_controls() {
		$this->start_controls_section(
			'section_returning_customer',
			[
				'label' => esc_html__( 'Returning Customer', 'powerpack' ),
			]
		);

		$this->add_control(
			'returning_customer_section_title',
			[
				'label'   => esc_html__( 'Section Title', 'powerpack' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Returning customer?', 'powerpack' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'returning_customer_link_text',
			[
				'label'   => esc_html__( 'Link Text', 'powerpack' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Click here to login', 'powerpack' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Billing Details content controls.
	 *
	 * @since 2.9.5
	 * @access protected
	 */
	protected function register_content_billing_details() {
		$this->start_controls_section(
			'section_billing_details',
			[
				'label' => esc_html__( 'Billing Details', 'powerpack' ),
			]
		);

		$this->add_control(
			'billing_details_section_title',
			[
				'label'       => esc_html__( 'Section Title', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => $this->is_wc_feature_active( 'ship_to_billing_address_only' ) ? esc_html__( 'Billing and Shipping Details', 'powerpack' ) : esc_html__( 'Billing Details', 'powerpack' ),
				'default'     => $this->is_wc_feature_active( 'ship_to_billing_address_only' ) ? esc_html__( 'Billing and Shipping Details', 'powerpack' ) : esc_html__( 'Billing Details', 'powerpack' ),
				'dynamic'     => [
					'active' => true,
				],
			]
		);

		$this->add_responsive_control(
			'billing_details_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start'  => [
						'title' => esc_html__( 'Start', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end'    => [
						'title' => esc_html__( 'End', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				// Aligns the section heading, like the Your Order control does.
				// This used to set a --billing-details-title-alignment variable
				// that no stylesheet ever read, so the control did nothing.
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-billing-fields > h3' => 'text-align: {{VALUE}};',
				],
			]
		);

		$repeater = new Repeater();

		$repeater->start_controls_tabs( 'tabs', [
			'condition' => [
				'repeater_state' => '',
			],
		] );

		$repeater->start_controls_tab( 'content_tab', [
			'label' => esc_html__( 'Content', 'powerpack' ),
		] );

		$repeater->add_control(
			'label',
			[
				'label' => esc_html__( 'Label', 'powerpack' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'placeholder',
			[
				'label' => esc_html__( 'Placeholder', 'powerpack' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab( 'advanced_tab', [
			'label' => esc_html__( 'Advanced', 'powerpack' ),
		] );

		$repeater->add_control(
			'default',
			[
				'label'   => esc_html__( 'Default Value', 'powerpack' ),
				'type'    => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->end_controls_tab();

		$repeater->end_controls_tabs();

		$repeater->add_control(
			'repeater_state',
			[
				'label' => esc_html__( 'Repeater State - hidden', 'powerpack' ),
				'type' => Controls_Manager::HIDDEN,
			]
		);

		$repeater->add_control(
			'locale_notice',
			[
				'raw' => esc_html__( 'Note: This content cannot be changed due to local regulations.', 'powerpack' ),
				'type' => Controls_Manager::RAW_HTML,
				'content_classes' => 'elementor-descriptor',
				'condition' => [
					'repeater_state' => 'locale',
				],
			]
		);

		$repeater->add_control(
			'from_billing_notice',
			[
				'raw' => esc_html__( 'Note: This label and placeholder are taken from the Billing section. You can change it there.', 'powerpack' ),
				'type' => Controls_Manager::RAW_HTML,
				'content_classes' => 'elementor-descriptor',
				'condition' => [
					'repeater_state' => 'from_billing',
				],
			]
		);

		$this->add_control(
			'billing_details_form_fields',
			[
				'label' => esc_html__( 'Form Items', 'powerpack' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'item_actions' => [
					'add' => false,
					'duplicate' => false,
					'remove' => false,
					'sort' => false,
				],
				'default' => $this->get_billing_field_defaults(),
				'title_field' => '{{{ label }}}',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Shipping Details content controls.
	 *
	 * @since 2.9.5
	 * @access protected
	 */
	protected function register_content_shipping_details() {
		$this->start_controls_section(
			'section_shipping_details',
			[
				'label' => esc_html__( 'Shipping Details', 'powerpack' ),
			]
		);

		$this->add_control(
			'shipping_details_section_title',
			[
				'label'   => esc_html__( 'Section Title', 'powerpack' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Ship to a different address?', 'powerpack' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'repeater_state',
			[
				'label' => esc_html__( 'Repeater State - hidden', 'powerpack' ),
				'type' => Controls_Manager::HIDDEN,
			]
		);

		$repeater->add_control(
			'label_placeholder_notification',
			[
				'raw' => esc_html__( 'Note: This label and placeholder are taken from the Billing section. You can change it there.', 'powerpack' ),
				'type' => Controls_Manager::RAW_HTML,
				'content_classes' => 'elementor-descriptor',
				'condition' => [
					'repeater_state' => 'from_billing',
				],
			]
		);

		$repeater->start_controls_tabs( 'tabs', [
			'condition' => [
				'repeater_state' => '',
			],
		] );

		$repeater->start_controls_tab( 'content_tab', [
			'label' => esc_html__( 'Content', 'powerpack' ),
		] );

		$repeater->add_control(
			'label',
			[
				'label' => esc_html__( 'Label', 'powerpack' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'placeholder',
			[
				'label' => esc_html__( 'Placeholder', 'powerpack' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab( 'advanced_tab', [
			'label' => esc_html__( 'Advanced', 'powerpack' ),
		] );

		$repeater->add_control(
			'default',
			[
				'label'   => esc_html__( 'Default Value', 'powerpack' ),
				'type'    => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->end_controls_tab();

		$repeater->end_controls_tabs();

		$repeater->add_control(
			'locale_notice',
			[
				'raw' => esc_html__( 'Note: This content cannot be changed due to local regulations.', 'powerpack' ),
				'type' => Controls_Manager::RAW_HTML,
				'content_classes' => 'elementor-descriptor',
				'condition' => [
					'repeater_state' => 'locale',
				],
			]
		);

		$repeater->add_control(
			'from_billing_notice',
			[
				'raw' => esc_html__( 'Note: This label and placeholder are taken from the Billing section. You can change it there.', 'powerpack' ),
				'type' => Controls_Manager::RAW_HTML,
				'content_classes' => 'elementor-descriptor',
				'condition' => [
					'repeater_state' => 'from_billing',
				],
			]
		);

		$this->add_control(
			'shipping_details_form_fields',
			[
				'label' => esc_html__( 'Form Items', 'powerpack' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'item_actions' => [
					'add' => false,
					'duplicate' => false,
					'remove' => false,
					'sort' => false,
				],
				'default' => $this->get_shipping_field_defaults(),
				'title_field' => '{{{ label }}}',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Additional Information content controls.
	 *
	 * @since 2.9.5
	 * @access protected
	 */
	protected function register_content_additional_information() {
		$this->start_controls_section(
			'section_additional_information',
			[
				'label' => esc_html__( 'Additional Information', 'powerpack' ),
			]
		);

		$this->add_control(
			'hide_additional_info',
			[
				'label'        => esc_html__( 'Hide Additonal Information Box', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		if ( $this->is_wc_feature_active( 'additional_options' ) ) {
			$this->add_control(
				'additional_information_section_title',
				[
					'label'       => esc_html__( 'Section Title', 'powerpack' ),
					'type'        => Controls_Manager::TEXT,
					'placeholder' => esc_html__( 'Additional Information', 'powerpack' ),
					'default'     => esc_html__( 'Additional Information', 'powerpack' ),
					'dynamic'     => [
						'active' => true,
					],
					'condition'   => [
						'hide_additional_info!' => 'yes',
					],
				]
			);

			$this->add_responsive_control(
				'additional_information_alignment',
				[
					'label' => esc_html__( 'Alignment', 'powerpack' ),
					'type' => Controls_Manager::CHOOSE,
					'options' => [
						'start' => [
							'title' => esc_html__( 'Start', 'powerpack' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => esc_html__( 'Center', 'powerpack' ),
							'icon' => 'eicon-text-align-center',
						],
						'end' => [
							'title' => esc_html__( 'End', 'powerpack' ),
							'icon' => 'eicon-text-align-right',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .woocommerce .woocommerce-additional-fields' => 'text-align: {{VALUE}};',
					],
					'condition' => [
						'hide_additional_info!' => 'yes',
					],
				]
			);
		}

		$repeater = new Repeater();

		$repeater->start_controls_tabs( 'additional_information_form_fields_tabs' );

		$repeater->start_controls_tab( 'additional_information_form_fields_content_tab', [
			'label' => esc_html__( 'Content', 'powerpack' ),
		] );

		$repeater->add_control(
			'label',
			[
				'label' => esc_html__( 'Label', 'powerpack' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'placeholder',
			[
				'label' => esc_html__( 'Placeholder', 'powerpack' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab( 'additional_information_form_fields_advanced_tab', [
			'label' => esc_html__( 'Advanced', 'powerpack' ),
		] );

		$repeater->add_control(
			'default',
			[
				'label'   => esc_html__( 'Default Value', 'powerpack' ),
				'type'    => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->end_controls_tab();

		$repeater->end_controls_tabs();

		$this->add_control(
			'additional_information_form_fields',
			[
				'label' => esc_html__( 'Items', 'powerpack' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'item_actions' => [
					'add' => false,
					'duplicate' => false,
					'remove' => false,
					'sort' => false,
				],
				'default' => [
					[
						'field_key' => 'order_comments',
						'field_label' => esc_html__( 'Order Notes', 'powerpack' ),
						'label' => esc_html__( 'Order Notes', 'powerpack' ),
						'placeholder' => esc_html__( 'Notes about your order, e.g. special notes for delivery.', 'powerpack' ),
					],
				],
				'title_field' => '{{{ label }}}',
				'condition' => [
					'hide_additional_info!' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Create an Account content controls.
	 *
	 * @since 2.9.5
	 * @access protected
	 */
	protected function register_content_signup_and_login_from_checkout_controls() {
		$this->start_controls_section(
			'section_create_account',
			[
				'label' => esc_html__( 'Create an Account', 'powerpack' ),
			]
		);

		$this->add_control(
			'create_account_text',
			[
				'label'   => esc_html__( 'Section Title', 'powerpack' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Create an account?', 'powerpack' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Your Order content controls.
	 *
	 * @since 2.9.5
	 * @access protected
	 */
	protected function register_content_order_summary() {
		$this->start_controls_section(
			'section_order_summary',
			[
				'label' => esc_html__( 'Your Order', 'powerpack' ),
			]
		);

		$this->add_control(
			'order_summary_section_title',
			[
				'label'   => esc_html__( 'Section Title', 'powerpack' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Your Order', 'powerpack' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_responsive_control(
			'order_summary_alignment',
			[
				'label' => esc_html__( 'Alignment', 'powerpack' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => esc_html__( 'Start', 'powerpack' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon' => 'eicon-text-align-center',
					],
					'end' => [
						'title' => esc_html__( 'End', 'powerpack' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .woocommerce #order_review_heading' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Coupon content controls.
	 *
	 * @since 2.9.5
	 * @access protected
	 */
	protected function register_content_coupon_controls() {
		$this->start_controls_section(
			'section_coupon',
			[
				'label' => esc_html__( 'Coupon', 'powerpack' ),
			]
		);

		$this->add_control(
			'coupon_section_title_text',
			[
				'label'   => esc_html__( 'Section Title', 'powerpack' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Have a coupon?', 'powerpack' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'coupon_section_title_link_text',
			[
				'label'   => esc_html__( 'Link Text', 'powerpack' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Click here to enter your coupon code', 'powerpack' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Payment content controls.
	 *
	 * @since 2.9.5
	 * @access protected
	 */
	protected function register_content_payment() {
		$this->start_controls_section(
			'section_payment',
			[
				'label' => esc_html__( 'Payment', 'powerpack' ),
			]
		);

		$this->add_control(
			'terms_conditions_heading',
			[
				'type'  => Controls_Manager::HEADING,
				'label' => esc_html__( 'Terms & Conditions', 'powerpack' ),
			]
		);

		$this->add_control(
			'terms_conditions_message_text',
			[
				'label'       => esc_html__( 'Message', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => esc_html__( 'I have read and agree to the website', 'powerpack' ),
				'dynamic'     => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'terms_conditions_link_text',
			[
				'label'       => esc_html__( 'Link Text', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => esc_html__( 'terms and conditions', 'powerpack' ),
				'dynamic'     => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'purchase_buttom_heading',
			[
				'type'  => Controls_Manager::HEADING,
				'label' => esc_html__( 'Purchase Button', 'powerpack' ),
			]
		);

		$this->add_responsive_control(
			'purchase_button_alignment',
			[
				'label' => esc_html__( 'Alignment', 'powerpack' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => esc_html__( 'Start', 'powerpack' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon' => 'eicon-text-align-center',
					],
					'end' => [
						'title' => esc_html__( 'End', 'powerpack' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justify', 'powerpack' ),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'selectors'            => [
					'{{WRAPPER}} .woocommerce-checkout' => '{{VALUE}}',
				],
				// The place order row is a flex column, so align-items is what
				// positions the button and stretches it for Justify. These used to
				// also set a --purchase-button-width variable that no stylesheet
				// read; button width is handled by the Width control below.
				'selectors_dictionary' => [
					'start'   => '--place-order-title-alignment: flex-start;',
					'center'  => '--place-order-title-alignment: center;',
					'end'     => '--place-order-title-alignment: flex-end;',
					'justify' => '--place-order-title-alignment: stretch;',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Columns style controls.
	 *
	 * @since 1.4.13
	 * @access protected
	 */
	protected function register_style_controls_columns() {

		$this->start_controls_section(
			'section_columns_style',
			[
				'label' => esc_html__( 'Columns', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'column_1_style_heading',
			[
				'label' => esc_html__( 'Column 1', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'column_1_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .woocommerce #customer_details .col-1, {{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields',
			]
		);

		$this->add_control(
			'column_1_border_border',
			[
				'label'     => esc_html__( 'Border Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''       => esc_html__( 'None', 'powerpack' ),
					'solid'  => esc_html__( 'Solid', 'powerpack' ),
					'double' => esc_html__( 'Double', 'powerpack' ),
					'dotted' => esc_html__( 'Dotted', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .woocommerce .pp-checkout-column-start' => '--sections-border-type: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'column_1_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [
					'top'       => 1,
					'right'     => 1,
					'bottom'    => 1,
					'left'      => 1,
					'isLinked'  => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .woocommerce .pp-checkout-column-start' => '--sections-border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'column_1_border_border!' => '',
				],
			]
		);

		$this->add_control(
			'column_1_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .woocommerce .pp-checkout-column-start' => '--sections-border-color: {{VALUE}};',
				],
				'condition' => [
					'column_1_border_border!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'column_1_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .woocommerce .pp-checkout-column-start' => '--sections-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'column_1_box_shadow',
				'selector' => '{{WRAPPER}} .woocommerce #customer_details .col-1, {{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields',
			]
		);

		$this->add_responsive_control(
			'column_1_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .woocommerce .pp-checkout-column-start' => '--sections-padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'column_2_style_heading',
			[
				'label'     => esc_html__( 'Column 2', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'layout' => '2',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'column_2_background',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .woocommerce .pp-checkout__order_review, {{WRAPPER}} .woocommerce .woocommerce-checkout #payment',
				'condition' => [
					'layout' => '2',
				],
			]
		);

		$this->add_control(
			'column_2_border_border',
			[
				'label'     => esc_html__( 'Border Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''       => esc_html__( 'None', 'powerpack' ),
					'solid'  => esc_html__( 'Solid', 'powerpack' ),
					'double' => esc_html__( 'Double', 'powerpack' ),
					'dotted' => esc_html__( 'Dotted', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .woocommerce .pp-checkout-column-end' => '--sections-border-type: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'column_2_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [
					'top'       => 1,
					'right'     => 1,
					'bottom'    => 1,
					'left'      => 1,
					'isLinked'  => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .woocommerce .pp-checkout-column-end' => '--sections-border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'column_2_border_border!' => '',
				],
			]
		);

		$this->add_control(
			'column_2_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .woocommerce .pp-checkout-column-end' => '--sections-border-color: {{VALUE}};',
				],
				'condition' => [
					'column_2_border_border!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'column_2_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-checkout-column-end' => '--sections-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => '2',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'column_2_box_shadow',
				'selector'  => '{{WRAPPER}} .woocommerce .pp-checkout__order_review, {{WRAPPER}} .woocommerce .woocommerce-checkout #payment',
				'condition' => [
					'layout' => '2',
				],
			]
		);

		$this->add_responsive_control(
			'column_2_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-checkout-column-end' => '--sections-padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => '2',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Sections style controls.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_controls_sections() {

		$this->start_controls_section(
			'section_sections_style',
			[
				'label' => esc_html__( 'Sections', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'sections_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .woocommerce .pp-woocommerce-login-section, {{WRAPPER}} .woocommerce .pp-checkout__order_review, {{WRAPPER}} .woocommerce .pp-coupon-box, {{WRAPPER}} .woocommerce .woocommerce-checkout #payment, {{WRAPPER}} .woocommerce #customer_details .col-1, {{WRAPPER}} .woocommerce .shipping_address, {{WRAPPER}} .woocommerce .woocommerce-additional-fields',
			]
		);

		$this->add_control(
			'sections_border_border',
			[
				'label'     => esc_html__( 'Border Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'solid',
				'options'   => [
					''       => esc_html__( 'None', 'powerpack' ),
					'solid'  => esc_html__( 'Solid', 'powerpack' ),
					'double' => esc_html__( 'Double', 'powerpack' ),
					'dotted' => esc_html__( 'Dotted', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}}' => '--sections-border-type: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'sections_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [
					'top'       => 1,
					'right'     => 1,
					'bottom'    => 1,
					'left'      => 1,
					'isLinked'  => true,
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--sections-border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'sections_border_border!' => '',
				],
			]
		);

		$this->add_control(
			'sections_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}}' => '--sections-border-color: {{VALUE}};',
				],
				'condition' => [
					'sections_border_border!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'sections_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}}' => '--sections-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'sections_box_shadow',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .woocommerce .pp-woocommerce-login-section, {{WRAPPER}} .woocommerce .pp-checkout__order_review, {{WRAPPER}} .woocommerce .pp-coupon-box, {{WRAPPER}} .woocommerce .woocommerce-checkout #payment, {{WRAPPER}} .woocommerce #customer_details .col-1, {{WRAPPER}} .woocommerce .shipping_address, {{WRAPPER}} .woocommerce .woocommerce-additional-fields',
			]
		);

		$this->add_responsive_control(
			'sections_gap',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 35,
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'separator'  => 'before',
				'selectors'  => [
					'{{WRAPPER}}' => '--sections-margin: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sections_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}}' => '--sections-padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Inputs style controls.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_controls_inputs() {

		$this->start_controls_section(
			'section_inputs_style',
			[
				'label' => esc_html__( 'Inputs', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'inputs_text_align',
			[
				'label'       => esc_html__( 'Text Alignment', 'powerpack' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'     => 'left',
				'selectors'   => [
					'{{WRAPPER}} .woocommerce form .input-text, {{WRAPPER}} .woocommerce form  select, {{WRAPPER}} .select2-container .select2-selection' => 'text-align: {{VALUE}};',
				],
				'separator'   => 'after',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'inputs_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .woocommerce form .input-text, {{WRAPPER}} .woocommerce form  select, {{WRAPPER}} .select2-container .select2-selection',
			]
		);

		$this->add_control(
			'input_text_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce form .input-text, {{WRAPPER}} .woocommerce form  select, {{WRAPPER}} .select2-container .select2-selection' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'input_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce form .input-text, {{WRAPPER}} .woocommerce form  select, {{WRAPPER}} .select2-container .select2-selection' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'inputs_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'separator'   => 'before',
				'selector'    => '{{WRAPPER}} .woocommerce form .input-text, {{WRAPPER}} .woocommerce form  select, {{WRAPPER}} .select2-container .select2-selection',
			]
		);

		$this->add_responsive_control(
			'inputs_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .woocommerce form .input-text, {{WRAPPER}} .woocommerce form  select, {{WRAPPER}} .select2-container .select2-selection' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'inputs_box_shadow',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .woocommerce form .input-text, {{WRAPPER}} .woocommerce form  select, {{WRAPPER}} .select2-container .select2-selection',
			]
		);

		$this->add_responsive_control(
			'inputs_gap',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'separator'  => 'before',
				'selectors'  => [
					'{{WRAPPER}} .woocommerce form .input-text, {{WRAPPER}} .woocommerce form  select, {{WRAPPER}} .select2-container' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'inputs_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .woocommerce form .input-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'inputs_height',
			[
				'label'      => esc_html__( 'Input Height', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'separator'  => 'before',
				'selectors'  => [
					'{{WRAPPER}} .woocommerce .form-row input.input-text, {{WRAPPER}} .woocommerce .form-row select' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'textarea_height',
			[
				'label'      => esc_html__( 'Textarea Height', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .woocommerce form .form-row textarea' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Returning Customer Box style controls.
	 *
	 * @since 1.5.0
	 * @access protected
	 */
	protected function register_style_controls_returning_customer() {
		$this->start_controls_section(
			'section_returning_customer_style',
			[
				'label' => esc_html__( 'Returning Customer Box', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'returning_customer_toggle_heading',
			[
				'label' => esc_html__( 'Returning Customer Toggle', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'returning_customer_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login-toggle .woocommerce-info' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'returning_customer_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login-toggle .woocommerce-info:before' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'returning_customer_links_color',
			[
				'label'     => esc_html__( 'Links Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login-toggle .woocommerce-info a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'returning_customer_links_color_hover',
			[
				'label'     => esc_html__( 'Links Hover Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login-toggle .woocommerce-info a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'returning_customer_toggle_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login-toggle .woocommerce-info',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'returning_customer_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login-toggle .woocommerce-info',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'returning_customer_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login-toggle .woocommerce-info',
			]
		);

		$this->add_responsive_control(
			'returning_customer_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login-toggle .woocommerce-info' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'returning_customer_box_shadow',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login-toggle .woocommerce-info',
			]
		);

		$this->add_control(
			'returning_customer_form_heading',
			[
				'label'     => esc_html__( 'Login Form', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'returning_customer_form_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'returning_customer_form_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'returning_customer_form_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login',
			]
		);

		$this->add_responsive_control(
			'returning_customer_form_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'returning_customer_form_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login',
			]
		);

		$this->add_responsive_control(
			'returning_customer_form_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'returning_customer_form_input_heading',
			[
				'label'     => esc_html__( 'Login Form Input', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'returning_customer_form_input_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login input.input-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'returning_customer_form_input_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login input.input-text' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'returning_customer_form_input_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login input.input-text',
			]
		);

		$this->add_responsive_control(
			'returning_customer_form_input_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login input.input-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'returning_customer_form_input_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login input.input-text',
			]
		);

		$this->add_responsive_control(
			'returning_customer_form_input_height',
			[
				'label'      => esc_html__( 'Input Height', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login input.input-text' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'returning_customer_form_input_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login input.input-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'returning_customer_form_input_label_heading',
			[
				'label'     => esc_html__( 'Login Form Input Label', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'returning_customer_form_input_label_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login label' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'returning_customer_form_input_label_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login label',
			]
		);

		$this->add_responsive_control(
			'returning_customer_form_input_label_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 5,
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'returning_customer_form_button_heading',
			[
				'label'     => esc_html__( 'Login Form Button', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'returning_customer_form_button_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login .button',
			]
		);

		$this->start_controls_tabs( 'tabs_returning_customer_form_button_style' );

		$this->start_controls_tab(
			'tab_returning_customer_form_button_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'returning_customer_form_button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login .button' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'returning_customer_form_button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login .button' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'returning_customer_form_button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login .button',
			]
		);

		$this->add_responsive_control(
			'returning_customer_form_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login .button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'returning_customer_form_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login .button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'returning_customer_form_button_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login .button',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_returning_customer_form_button_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'returning_customer_form_button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login .button:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'returning_customer_form_button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login .button:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'returning_customer_form_button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login .button:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'returning_customer_form_button_box_shadow_hover',
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-login .button:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register the Coupon Bar style controls.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_controls_coupon_bar() {
		$this->start_controls_section(
			'section_coupon_bar_style',
			[
				'label' => esc_html__( 'Coupon Bar', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'coupon_bar_toggle_heading',
			[
				'label' => esc_html__( 'Coupon Toggle', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'coupon_bar_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon-toggle .woocommerce-info' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'coupon_bar_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon-toggle .woocommerce-info:before' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'coupon_bar_links_color',
			[
				'label'     => esc_html__( 'Links Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon-toggle .woocommerce-info a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'coupon_bar_links_color_hover',
			[
				'label'     => esc_html__( 'Links Hover Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon-toggle .woocommerce-info a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'coupon_bar_toggle_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon-toggle .woocommerce-info',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'coupon_bar_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon-toggle .woocommerce-info',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'coupon_bar_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon-toggle .woocommerce-info',
			]
		);

		$this->add_responsive_control(
			'coupon_bar_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon-toggle .woocommerce-info' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'coupon_bar_box_shadow',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon-toggle .woocommerce-info',
			]
		);

		$this->add_control(
			'coupon_bar_form_heading',
			[
				'label'     => esc_html__( 'Coupon Form', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'coupon_form_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'coupon_form_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'coupon_form_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon',
			]
		);

		$this->add_responsive_control(
			'coupon_form_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'coupon_form_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon',
			]
		);

		$this->add_responsive_control(
			'coupon_form_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'coupon_bar_form_input_heading',
			[
				'label'     => esc_html__( 'Coupon Form Input', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'coupon_bar_form_input_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon #coupon_code' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'coupon_bar_form_input_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon #coupon_code' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'coupon_bar_form_input_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon #coupon_code',
			]
		);

		$this->add_responsive_control(
			'coupon_bar_form_input_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon #coupon_code' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'coupon_bar_form_input_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon #coupon_code',
			]
		);

		$this->add_responsive_control(
			'coupon_bar_form_input_height',
			[
				'label'      => esc_html__( 'Input Height', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon #coupon_code' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'coupon_bar_form_input_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon #coupon_code' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'coupon_bar_form_button_heading',
			[
				'label'     => esc_html__( 'Coupon Form Button', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'coupon_bar_form_button_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon .button',
			]
		);

		$this->start_controls_tabs( 'tabs_coupon_form_button_style' );

		$this->start_controls_tab(
			'tab_coupon_form_button_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'coupon_form_button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon .button' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'coupon_form_button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'global'                => [
					'default' => Global_Colors::COLOR_ACCENT,
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon .button' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'coupon_form_button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon .button',
			]
		);

		$this->add_responsive_control(
			'coupon_form_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon .button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'coupon_form_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon .button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'coupon_form_button_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon .button',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_coupon_form_button_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'coupon_form_button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon .button:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'coupon_form_button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon .button:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'coupon_form_button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon .button:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'coupon_form_button_box_shadow_hover',
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-form-coupon .button:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register the Headings style controls.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_controls_headings() {
		$this->start_controls_section(
			'section_headings_style',
			[
				'label' => esc_html__( 'Headings', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'headings_text_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--sections-title-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'headings_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout #customer_details .woocommerce-billing-fields > h3, {{WRAPPER}} .pp-woo-checkout .woocommerce-shipping-fields > h3, {{WRAPPER}} .pp-woo-checkout .woocommerce-additional-fields > h3, {{WRAPPER}} .pp-woo-checkout #order_review_heading',
			]
		);

		$this->add_responsive_control(
			'headings_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--sections-title-spacing: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Billing Details style controls.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_controls_billing_details() {
		$this->start_controls_section(
			'section_billing_details_style',
			[
				'label' => esc_html__( 'Billing Details', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'section_billing_details_heading',
			[
				'label' => esc_html__( 'Section', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'section_billing_details_background',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1',
			]
		);

		$this->add_control(
			'section_billing_details_border_border',
			[
				'label'     => esc_html__( 'Border Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''       => esc_html__( 'None', 'powerpack' ),
					'solid'  => esc_html__( 'Solid', 'powerpack' ),
					'double' => esc_html__( 'Double', 'powerpack' ),
					'dotted' => esc_html__( 'Dotted', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1' => '--sections-border-type: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'section_billing_details_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [
					'top'       => 1,
					'right'     => 1,
					'bottom'    => 1,
					'left'      => 1,
					'isLinked'  => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1' => '--sections-border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'section_billing_details_border_border!' => '',
				],
			]
		);

		$this->add_control(
			'section_billing_details_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1' => '--sections-border-color: {{VALUE}};',
				],
				'condition' => [
					'section_billing_details_border_border!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'section_billing_details_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1' => '--sections-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'section_billing_details_box_shadow',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1',
			]
		);

		$this->add_control(
			'section_billing_details_inputs_heading',
			[
				'label'     => esc_html__( 'Inputs', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'section_billing_details_inputs_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select',
			]
		);

		$this->add_responsive_control(
			'section_billing_details_inputs_height',
			[
				'label'      => esc_html__( 'Input Height', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'section_billing_details_inputs_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_billing_details_inputs_style' );

		$this->start_controls_tab(
			'tab_billing_details_inputs_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'section_billing_details_inputs_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_billing_details_inputs_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'section_billing_details_inputs_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select',
			]
		);

		$this->add_responsive_control(
			'section_billing_details_inputs_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				// Same target as the rest of this tab. It used to select on
				// .woocommerce-billing-fields__field-wrapper, which skipped the
				// selects that every neighbouring control styles.
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'section_billing_details_inputs_box_shadow',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_billing_details_inputs_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'section_billing_details_inputs_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text:hover, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_billing_details_inputs_background_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text:hover, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_billing_details_inputs_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text:hover, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'section_billing_details_inputs_box_shadow_hover',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text:hover, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select:hover',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_billing_details_inputs_focus',
			[
				'label' => esc_html__( 'Focus', 'powerpack' ),
			]
		);

		$this->add_control(
			'section_billing_details_inputs_text_color_focus',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text:focus, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select:focus' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_billing_details_inputs_background_color_focus',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text:focus, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select:focus' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_billing_details_inputs_border_color_focus',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text:focus, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select:focus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'section_billing_details_inputs_box_shadow_focus',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 input.input-text:focus, {{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 select:focus',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'section_billing_details_inputs_label_heading',
			[
				'label'     => esc_html__( 'Input Label', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'section_billing_details_inputs_label_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 label' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'section_billing_details_inputs_label_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 label',
			]
		);

		$this->add_responsive_control(
			'section_billing_details_inputs_label_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 5,
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce #customer_details .col-1 label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Additional Information style controls.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_controls_additional_fields() {
		$this->start_controls_section(
			'section_additional_fields_style',
			[
				'label' => esc_html__( 'Additional Information', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'section_additional_fields_heading',
			[
				'label' => esc_html__( 'Section', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'section_additional_fields_background',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields',
			]
		);

		$this->add_control(
			'section_additional_fields_border_border',
			[
				'label'     => esc_html__( 'Border Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''       => esc_html__( 'None', 'powerpack' ),
					'solid'  => esc_html__( 'Solid', 'powerpack' ),
					'double' => esc_html__( 'Double', 'powerpack' ),
					'dotted' => esc_html__( 'Dotted', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields' => '--sections-border-type: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'section_additional_fields_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [
					'top'       => 1,
					'right'     => 1,
					'bottom'    => 1,
					'left'      => 1,
					'isLinked'  => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields' => '--sections-border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'section_additional_fields_border_border!' => '',
				],
			]
		);

		$this->add_control(
			'section_additional_fields_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields' => '--sections-border-color: {{VALUE}};',
				],
				'condition' => [
					'section_additional_fields_border_border!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'section_additional_fields_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				// Sets the same variable the other section border radius controls
				// use, rather than writing border-radius directly.
				'selectors'  => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields' => '--sections-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'section_additional_fields_box_shadow',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields',
			]
		);

		$this->add_control(
			'section_additional_fields_textarea_heading',
			[
				'label'     => esc_html__( 'Textarea', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'section_additional_fields_textarea_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields textarea',
			]
		);

		$this->start_controls_tabs( 'tabs_additional_fields_textarea_style' );

		$this->start_controls_tab(
			'tab_additional_fields_textarea_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'section_additional_fields_textarea_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields textarea' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_additional_fields_textarea_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields textarea' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'section_additional_fields_textarea_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields textarea',
			]
		);

		$this->add_responsive_control(
			'section_additional_fields_textarea_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields textarea' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'section_additional_fields_textarea_box_shadow',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields textarea',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_additional_fields_textarea_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'section_additional_fields_textarea_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields textarea:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_additional_fields_textarea_background_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields textarea:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_additional_fields_textarea_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields textarea:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'section_additional_fields_textarea_box_shadow_hover',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields textarea:hover',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_additional_fields_textarea_focus',
			[
				'label' => esc_html__( 'Focus', 'powerpack' ),
			]
		);

		$this->add_control(
			'section_additional_fields_textarea_text_color_focus',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields textarea:focus' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_additional_fields_textarea_background_color_focus',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields textarea:focus' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_additional_fields_textarea_border_color_focus',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields textarea:focus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'section_additional_fields_textarea_box_shadow_focus',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields textarea:focus',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			'section_additional_fields_textarea_label_heading',
			[
				'label'     => esc_html__( 'Textarea Label', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'section_additional_fields_textarea_label_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields label' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'section_additional_fields_textarea_label_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields label',
			]
		);

		$this->add_responsive_control(
			'section_additional_fields_textarea_label_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 5,
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .woocommerce #customer_details .woocommerce-additional-fields label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Review Order style controls.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_controls_review_order() {
		$this->start_controls_section(
			'section_review_order_style',
			[
				'label' => esc_html__( 'Review Order', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'section_review_order_heading',
			[
				'label' => esc_html__( 'Section', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'section_review_order_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce .pp-checkout__order_review',
			]
		);

		$this->add_control(
			'section_review_order_border_border',
			[
				'label'     => esc_html__( 'Border Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''       => esc_html__( 'None', 'powerpack' ),
					'solid'  => esc_html__( 'Solid', 'powerpack' ),
					'double' => esc_html__( 'Double', 'powerpack' ),
					'dotted' => esc_html__( 'Dotted', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce .pp-checkout__order_review' => '--sections-border-type: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'section_review_order_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [
					'top'       => 1,
					'right'     => 1,
					'bottom'    => 1,
					'left'      => 1,
					'isLinked'  => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce .pp-checkout__order_review' => '--sections-border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'section_review_order_border_border!' => '',
				],
			]
		);

		$this->add_control(
			'section_review_order_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce .pp-checkout__order_review' => '--sections-border-color: {{VALUE}};',
				],
				'condition' => [
					'section_review_order_border_border!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'section_review_order_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce .pp-checkout__order_review' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'section_review_order_box_shadow',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .pp-woo-checkout .woocommerce .pp-checkout__order_review',
			]
		);

		$this->add_responsive_control(
			'section_review_order_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce .pp-checkout__order_review' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'section_review_order_table_heading',
			[
				'label' => esc_html__( 'Table', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'section_review_order_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce .pp-checkout__order_review',
			]
		);

		$this->add_control(
			'section_review_order_table_cell_heading',
			[
				'label'     => esc_html__( 'Table Cell', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'section_review_order_cell_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woocommerce.pp-woo-checkout .woocommerce-checkout #order_review .shop_table th, {{WRAPPER}} .pp-woocommerce.pp-woo-checkout .woocommerce-checkout #order_review .shop_table td' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'section_review_order_table_head_heading',
			[
				'label'     => esc_html__( 'Table Head', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'section_review_order_table_head_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout-review-order-table thead th' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_review_order_table_head_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout-review-order-table thead th' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_review_order_table_foot_heading',
			[
				'label'     => esc_html__( 'Table Footer', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'section_review_order_table_foot_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout-review-order-table tfoot tr' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_review_order_table_foot_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout-review-order-table tfoot tr' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_review_order_table_body_heading',
			[
				'label'     => esc_html__( 'Table Body', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs( 'section_review_order_tbody_rows_tabs_style' );

		$this->start_controls_tab(
			'tab_section_review_order_even_row',
			[
				'label' => esc_html__( 'Even Row', 'powerpack' ),
			]
		);

		$this->add_control(
			'section_review_order_even_row_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout-review-order-table .cart_item:nth-child(2n) td' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_review_order_even_row_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout-review-order-table .cart_item:nth-child(2n) td' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_section_review_order_odd_row',
			[
				'label' => esc_html__( 'Odd Row', 'powerpack' ),
			]
		);

		$this->add_control(
			'section_review_order_odd_row_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout-review-order-table .cart_item:nth-child(2n+1) td' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_review_order_odd_row_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout-review-order-table .cart_item:nth-child(2n+1) td' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'section_review_order_row_separator_heading',
			[
				'label'     => esc_html__( 'Row Separator', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'section_review_order_row_separator_type',
			[
				'label'     => esc_html__( 'Separator Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'solid',
				'options'   => [
					'none'   => esc_html__( 'None', 'powerpack' ),
					'solid'  => esc_html__( 'Solid', 'powerpack' ),
					'dotted' => esc_html__( 'Dotted', 'powerpack' ),
					'dashed' => esc_html__( 'Dashed', 'powerpack' ),
					'double' => esc_html__( 'Double', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce table.shop_table td, {{WRAPPER}} .pp-woo-checkout .woocommerce table.shop_table tfoot th' => 'border-top-style: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_review_order_row_separator_color',
			[
				'label'     => esc_html__( 'Separator Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce table.shop_table td, {{WRAPPER}} .pp-woo-checkout .woocommerce table.shop_table tfoot th' => 'border-top-color: {{VALUE}};',
				],
				'condition' => [
					'section_review_order_row_separator_type!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'section_review_order_row_separator_size',
			[
				'label'      => esc_html__( 'Separator Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce table.shop_table td, {{WRAPPER}} .pp-woo-checkout .woocommerce table.shop_table tfoot th' => 'border-top-width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'section_review_order_row_separator_type!' => 'none',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Payment Method style controls.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_controls_payment_method() {
		$this->start_controls_section(
			'section_payment_method_style',
			[
				'label' => esc_html__( 'Payment Method', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'section_payment_method_heading',
			[
				'label' => esc_html__( 'Section', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'section_payment_method_background',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pp-woo-checkout .woocommerce .woocommerce-checkout #payment',
			]
		);

		$this->add_control(
			'section_payment_method_border_border',
			[
				'label'     => esc_html__( 'Border Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''       => esc_html__( 'None', 'powerpack' ),
					'solid'  => esc_html__( 'Solid', 'powerpack' ),
					'double' => esc_html__( 'Double', 'powerpack' ),
					'dotted' => esc_html__( 'Dotted', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce .woocommerce-checkout #payment' => '--sections-border-type: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'section_payment_method_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [
					'top'       => 1,
					'right'     => 1,
					'bottom'    => 1,
					'left'      => 1,
					'isLinked'  => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce .woocommerce-checkout #payment' => '--sections-border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'section_payment_method_border_border!' => '',
				],
			]
		);

		$this->add_control(
			'section_payment_method_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce .woocommerce-checkout #payment' => '--sections-border-color: {{VALUE}};',
				],
				'condition' => [
					'section_payment_method_border_border!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'section_payment_method_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce .woocommerce-checkout #payment' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'section_payment_method_box_shadow',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .pp-woo-checkout .woocommerce .woocommerce-checkout #payment',
			]
		);

		$this->add_control(
			'section_payment_method_label_heading',
			[
				'label'     => esc_html__( 'Label', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'payment_method_label_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout .payment_methods label',
			]
		);

		$this->add_control(
			'payment_method_label_text_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout .payment_methods label' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_payment_method_message_heading',
			[
				'label'     => esc_html__( 'Message', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'payment_method_message_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #payment .payment_box',
			]
		);

		$this->add_control(
			'payment_method_message_text_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #payment .payment_box' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'payment_method_message_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #payment .payment_box' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #payment .payment_box:before' => 'border-bottom-color: {{VALUE}};',
				],
			]
		);

		// Privacy Policy
		$this->add_control(
			'payment_privacy_policy',
			[
				'type' => Controls_Manager::HEADING,
				'label' => esc_html__( 'Privacy Policy', 'powerpack' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'privacy_policy_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-terms-and-conditions-wrapper .woocommerce-privacy-policy-text' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'privacy_policy_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-terms-and-conditions-wrapper .woocommerce-privacy-policy-text',
			]
		);

		// Checkbox
		$this->add_control(
			'payment_checkboxes_title',
			[
				'type' => Controls_Manager::HEADING,
				'label' => esc_html__( 'Terms & Conditions', 'powerpack' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'payment_checkboxes_color',
			[
				'label' => esc_html__( 'Color', 'powerpack' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce-terms-and-conditions-wrapper .woocommerce-form__label-for-checkbox span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'payment_checkboxes_typography',
				'selector' => '{{WRAPPER}} .woocommerce-terms-and-conditions-wrapper .woocommerce-form__label-for-checkbox span',
			]
		);

		// Links
		$this->add_control(
			'sections_links_title',
			[
				'type' => Controls_Manager::HEADING,
				'label' => esc_html__( 'Links', 'powerpack' ),
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs( 'payment_colors' );

		$this->start_controls_tab( 'payment_normal_colors', [
			'label' => esc_html__( 'Normal', 'powerpack' ),
		] );

		$this->add_control(
			'payment_normal_color',
			[
				'label' => esc_html__( 'Link Color', 'powerpack' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce-checkout-payment' => '--links-normal-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'payment_hover_colors', [
			'label' => esc_html__( 'Hover', 'powerpack' ),
		] );

		$this->add_control(
			'payment_hover_color',
			[
				'label' => esc_html__( 'Link Color', 'powerpack' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce-checkout-payment' => '--links-hover-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register the Purchase Button style controls.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_controls_purchase_button() {
		$this->start_controls_section(
			'section_checkout_button_style',
			[
				'label' => esc_html__( 'Purchase Button', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'button_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #place_order',
			]
		);

		$this->add_control(
			'button_width',
			[
				'label'        => esc_html__( 'Width', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'auto',
				'options'      => [
					'auto'   => esc_html__( 'Auto', 'powerpack' ),
					'full'   => esc_html__( 'Full Width', 'powerpack' ),
					'custom' => esc_html__( 'Custom', 'powerpack' ),
				],
				'prefix_class' => 'pp-woo-checkout-button-',
			]
		);

		$this->add_responsive_control(
			'button_custom_width',
			[
				'label'      => esc_html__( 'Custom Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 50,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #place_order' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'button_width' => 'custom',
				],
			]
		);

		$this->add_responsive_control(
			'button_margin',
			[
				'label'              => esc_html__( 'Margin', 'powerpack' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'allowed_dimensions' => 'vertical',
				'placeholder'        => [
					'top'    => '',
					'right'  => 'auto',
					'bottom' => '',
					'left'   => 'auto',
				],
				'selectors'          => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #place_order' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_button_style' );

		$this->start_controls_tab(
			'tab_button_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'global'                => [
					'default' => Global_Colors::COLOR_ACCENT,
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #place_order' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #place_order' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #place_order',
			]
		);

		$this->add_responsive_control(
			'button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #place_order' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #place_order' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'button_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #place_order',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #place_order:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #place_order:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #place_order:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'button_box_shadow_hover',
				'selector' => '{{WRAPPER}} .pp-woo-checkout .woocommerce-checkout #place_order:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Get Billing Field Defaults
	 *
	 * Get defaults used for the billing details repeater control.
	 *
	 * @since 2.9.5
	 *
	 * @return array
	 */
	private function get_billing_field_defaults() {
		$fields = [
			'billing_first_name' => [
				'label' => esc_html__( 'First Name', 'powerpack' ),
				'repeater_state' => '',
			],
			'billing_last_name' => [
				'label' => esc_html__( 'Last Name', 'powerpack' ),
				'repeater_state' => '',
			],
			'billing_company' => [
				'label' => esc_html__( 'Company Name', 'powerpack' ),
				'repeater_state' => '',
			],
			'billing_country' => [
				'label' => esc_html__( 'Country / Region', 'powerpack' ),
				'repeater_state' => 'locale',
			],
			'billing_address_1' => [
				'label' => esc_html__( 'Street Address', 'powerpack' ),
				'repeater_state' => 'locale',
			],
			'billing_postcode' => [
				'label' => esc_html__( 'Post Code', 'powerpack' ),
				'repeater_state' => 'locale',
			],
			'billing_city' => [
				'label' => esc_html__( 'Town / City', 'powerpack' ),
				'repeater_state' => 'locale',
			],
			'billing_state' => [
				'label' => esc_html__( 'State', 'powerpack' ),
				'repeater_state' => 'locale',
			],
			'billing_phone' => [
				'label' => esc_html__( 'Phone', 'powerpack' ),
				'repeater_state' => '',
			],
			'billing_email' => [
				'label' => esc_html__( 'Email Address', 'powerpack' ),
				'repeater_state' => '',
			],
		];

		return $this->reformat_address_field_defaults( $fields );
	}

	/**
	 * Get Shipping Field Defaults
	 *
	 * Get defaults used for the shipping details repeater control.
	 *
	 * @since 2.9.5
	 *
	 * @return array
	 */
	private function get_shipping_field_defaults() {
		$fields = [
			'shipping_first_name' => [
				'label' => esc_html__( 'First Name', 'powerpack' ),
				'repeater_state' => '',
			],
			'shipping_last_name' => [
				'label' => esc_html__( 'Last Name', 'powerpack' ),
				'repeater_state' => '',
			],
			'shipping_company' => [
				'label' => esc_html__( 'Company Name', 'powerpack' ),
				'repeater_state' => '',
			],
			'shipping_country' => [
				'label' => esc_html__( 'Country / Region', 'powerpack' ),
				'repeater_state' => 'locale',
			],
			'shipping_address_1' => [
				'label' => esc_html__( 'Street Address', 'powerpack' ),
				'repeater_state' => 'locale',
			],
			'shipping_postcode' => [
				'label' => esc_html__( 'Post Code', 'powerpack' ),
				'repeater_state' => 'locale',
			],
			'shipping_city' => [
				'label' => esc_html__( 'Town / City', 'powerpack' ),
				'repeater_state' => 'locale',
			],
			'shipping_state' => [
				'label' => esc_html__( 'State', 'powerpack' ),
				'repeater_state' => 'locale',
			],
		];

		return $this->reformat_address_field_defaults( $fields );
	}

	/**
	 * Reformat Address Field Defaults
	 *
	 * Used with the `get_..._field_defaults()` methods.
	 * Takes the address array and converts it into the format expected by the repeater controls.
	 *
	 * @since 2.9.5
	 *
	 * @param $address
	 * @return array
	 */
	private function reformat_address_field_defaults( $address ) {
		$defaults = [];
		foreach ( $address as $key => $value ) {
			$defaults[] = [
				'field_key' => $key,
				'field_label' => $value['label'],
				'label' => $value['label'],
				'placeholder' => $value['label'],
				'repeater_state' => $value['repeater_state'],
			];
		}

		return $defaults;
	}

	/**
	 * Init Gettext Modifications
	 *
	 * Sets the `$gettext_modifications` property used with the `filter_gettext()` in the extended Base_Widget.
	 *
	 * @since 2.9.5
	 */
	protected function init_gettext_modifications() {
		$instance = $this->get_display_settings();

		/*
		 * Empty entries are dropped rather than passed through. Each of these
		 * controls shows the WooCommerce wording as its default, so clearing the
		 * field should fall back to the real translation instead of replacing the
		 * heading with nothing.
		 *
		 * Several of these sections are only registered when the matching
		 * WooCommerce feature is switched on, so unlike the billing and order
		 * summary titles those keys are not always present.
		 */
		$shipping_title   = ! empty( $instance['shipping_details_section_title'] ) ? $instance['shipping_details_section_title'] : '';
		$additional_title = ! empty( $instance['additional_information_section_title'] ) ? $instance['additional_information_section_title'] : '';
		$coupon_title     = ! empty( $instance['coupon_section_title_text'] ) ? $instance['coupon_section_title_text'] : '';
		$coupon_link      = ! empty( $instance['coupon_section_title_link_text'] ) ? $instance['coupon_section_title_link_text'] : '';
		$returning_title  = ! empty( $instance['returning_customer_section_title'] ) ? $instance['returning_customer_section_title'] : '';
		$returning_link   = ! empty( $instance['returning_customer_link_text'] ) ? $instance['returning_customer_link_text'] : '';
		$create_account   = ! empty( $instance['create_account_text'] ) ? $instance['create_account_text'] : '';

		$this->gettext_modifications = array_filter(
			[
				'Billing details'                      => $instance['billing_details_section_title'],
				'Billing &amp; Shipping'               => $instance['billing_details_section_title'],
				'Ship to a different address?'         => $shipping_title,
				'Additional information'               => $additional_title,
				'Your order'                           => $instance['order_summary_section_title'],
				'Have a coupon?'                       => $coupon_title,
				'Click here to enter your coupon code' => $coupon_link,
				'Returning customer?'                  => $returning_title,
				'Click here to login'                  => $returning_link,
				'Create an account?'                   => $create_account,
			],
			static function ( $replacement ) {
				return '' !== trim( (string) $replacement );
			}
		);
	}

	/**
	 * WooCommerce Terms and Conditions Checkbox Text.
	 *
	 * WooCommerce filter is used to apply widget settings to Checkout Terms & Conditions text and link text.
	 *
	 * @since 2.9.5
	 *
	 * @param string $text
	 * @return string
	 */
	public function woocommerce_terms_and_conditions_checkbox_text( $text ) {
		$settings = $this->get_display_settings();

		/*
		 * Both values are editor authored and may resolve from a dynamic tag, so
		 * they are not trusted markup. They are stripped here, at the point they
		 * are read, rather than relying on the consumer: WooCommerce runs the
		 * return value of this filter through wp_kses_post(), so nothing is
		 * exploitable today, but that is its choice rather than ours and it is no
		 * guarantee for an overridden checkout/terms.php.
		 *
		 * wp_strip_all_tags() rather than esc_html() for the same reason the base
		 * widget uses it on the gettext replacements: it removes markup without
		 * entity encoding, so the consumer that does escape is not double encoding
		 * an already encoded string.
		 */
		$message = wp_strip_all_tags( $settings['terms_conditions_message_text'] );
		$link    = wp_strip_all_tags( $settings['terms_conditions_link_text'] );

		// Both fields default to the WooCommerce wording, so an empty one means
		// the user cleared it and expects the stock text back rather than a
		// checkbox label with nothing in it.
		if ( '' === trim( $message ) || '' === trim( $link ) ) {
			return $text;
		}

		$terms_page_id = wc_terms_and_conditions_page_id();
		if ( $terms_page_id ) {
			$message .= ' <a href="' . esc_url( get_permalink( $terms_page_id ) ) . '" class="woocommerce-terms-and-conditions-link" target="_blank">' . $link . '</a>';
		}

		return $message;
	}

	/**
	 * Modify Form Field.
	 *
	 * WooCommerce filter is used to apply widget settings to the Checkout forms address fields
	 * from the Billing and Shipping Details widget sections, e.g. label, placeholder, default.
	 *
	 * @since 2.9.5
	 *
	 * @param array $args
	 * @param string $key
	 * @param string $value
	 * @return array
	 */
	public function modify_form_field( $args, $key, $value ) {
		$reformatted_form_fields = $this->get_reformatted_form_fields();

		// Check if we need to modify the args of this form field.
		if ( isset( $reformatted_form_fields[ $key ] ) ) {
			$apply_fields = [
				'label',
				'placeholder',
				'default',
			];

			foreach ( $apply_fields as $field ) {
				if ( ! empty( $reformatted_form_fields[ $key ][ $field ] ) ) {
					$args[ $field ] = $reformatted_form_fields[ $key ][ $field ];
				}
			}
		}

		return $args;
	}

	/**
	 * Get Reformatted Form Fields.
	 *
	 * Combines the 3 relevant repeater settings arrays into a one level deep associative array
	 * with the keys that match those that WooCommerce uses for its form fields.
	 *
	 * The result is cached so the conversion only ever happens once.
	 *
	 * @since 2.9.5
	 *
	 * @return array
	 */
	private function get_reformatted_form_fields() {
		if ( ! isset( $this->reformatted_form_fields ) ) {
			$instance = $this->get_display_settings();

			// Reformat form repeater field into one usable array.
			$repeater_fields = [
				'billing_details_form_fields',
				'shipping_details_form_fields',
				'additional_information_form_fields',
			];

			$this->reformatted_form_fields = [];

			/*
				The shipping repeater is only registered when the store has
				shipping zones and is not shipping to the billing address only, so
				that key is not always present.
			*/
			foreach ( $repeater_fields as $repeater_field ) {
				if ( empty( $instance[ $repeater_field ] ) ) {
					continue;
				}

				foreach ( $instance[ $repeater_field ] as $item ) {
					if ( empty( $item['field_key'] ) ) {
						continue;
					}

					$this->reformatted_form_fields[ $item['field_key'] ] = $item;
				}
			}
		}

		return $this->reformatted_form_fields;
	}

	/**
	 * WooCommerce Checkout Before Customer Details
	 *
	 * Callback function for the woocommerce_checkout_before_customer_details hook that outputs elements
	 *
	 * This eliminates the need for template overrides.
	 *
	 * @since 2.9.5
	 */
	public function woocommerce_checkout_before_customer_details() {
		// Opens the grid container and column 1. The column is closed in
		// woocommerce_checkout_after_customer_details(), the container in
		// woocommerce_checkout_after_order_review().
		$this->open_wrappers += 2;
		?>
		<div class="pp-checkout-container">
			<div class="pp-checkout-column pp-checkout-column-start">
		<?php
	}

	/**
	 * Close Checkout Wrappers
	 *
	 * Closes up to $count of this widget's wrapper divs, never more than are
	 * actually open.
	 *
	 * The wrappers are opened and closed across five WooCommerce template hooks.
	 * A theme shipping its own checkout/form-checkout.php that drops one of those
	 * hooks would otherwise leave divs unclosed, which breaks the rest of the page
	 * rather than just this widget. Counting what was opened keeps the markup
	 * balanced whichever hooks actually fire.
	 *
	 * @since 3.0.0
	 * @access private
	 *
	 * @param int $count Number of wrappers to close.
	 */
	private function close_checkout_wrappers( $count ) {
		$count = min( (int) $count, $this->open_wrappers );

		if ( $count < 1 ) {
			return;
		}

		$this->open_wrappers -= $count;

		echo str_repeat( '</div>', $count ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static markup.
	}

	/**
	 * Woocommerce Checkout After Customer Details
	 *
	 * Output containing elements. Callback function for the woocommerce_checkout_after_customer_details hook.
	 *
	 * This eliminates the need for template overrides.
	 *
	 * @since 2.9.5
	 */
	public function woocommerce_checkout_after_customer_details() {
		// Closes column 1, opened in woocommerce_checkout_before_customer_details().
		$this->close_checkout_wrappers( 1 );
	}

	/**
	 * Woocommerce Checkout Before Order Review Heading 1
	 *
	 * Output containing elements. Callback function for the woocommerce_checkout_before_order_review_heading hook.
	 *
	 * This eliminates the need for template overrides.
	 *
	 * @since 2.9.5
	 */
	public function woocommerce_checkout_before_order_review_heading_1() {
		/*
		 * Opens column 2, closed in woocommerce_checkout_after_order_review().
		 *
		 * pp-checkout-column-inner and pp-sticky-right-column used to be a nested
		 * div of their own, the only child of this element and with no styling
		 * anywhere in the plugin. They are kept as class names on the surviving
		 * element so custom CSS that targets them still matches.
		 */
		++$this->open_wrappers;
		?>
			<div class="pp-checkout-column pp-checkout-column-end pp-checkout-column-inner pp-sticky-right-column">
		<?php
	}

	/**
	 * Woocommerce Checkout Before Order Review Heading 2
	 *
	 * Output containing elements. Callback function for the woocommerce_checkout_before_order_review_heading hook.
	 *
	 * This eliminates the need for template overrides.
	 *
	 * @since 2.9.5
	 */
	public function woocommerce_checkout_before_order_review_heading_2() {
		// Opens the order summary card, which wraps the #order_review_heading that
		// WooCommerce prints next. Closed in woocommerce_checkout_order_review().
		++$this->open_wrappers;
		?>
				<div class="pp-checkout__order_review">
		<?php
	}

	/**
	 * Woocommerce Checkout Order Review
	 *
	 * Output containing elements. Callback function for the woocommerce_checkout_order_review hook.
	 *
	 * This eliminates the need for template overrides.
	 *
	 * @since 2.9.5
	 */
	public function woocommerce_checkout_order_review() {
		/*
		 * Runs at priority 15, between WooCommerce's own woocommerce_order_review
		 * (10) and woocommerce_checkout_payment (20), so the order summary and the
		 * payment box end up in two separately styled cards.
		 *
		 * The first tag closes WooCommerce's #order_review container early, which
		 * is what allows the split. The template's own closing tag for that
		 * element then lands after the payment box and closes the second card, so
		 * pp-checkout__order_review-2 is deliberately not counted here.
		 */
		echo '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static markup, closes WooCommerce's #order_review.

		$this->close_checkout_wrappers( 1 );
		?>
				<div class="pp-checkout__order_review-2">
		<?php
	}

	/**
	 * Woocommerce Checkout After Order Review
	 *
	 * Output containing elements. Callback function for the woocommerce_checkout_after_order_review hook.
	 *
	 * This eliminates the need for template overrides.
	 *
	 * @since 2.9.5
	 */
	public function woocommerce_checkout_after_order_review() {
		// Closes column 2 and the grid container. The second order review card was
		// already closed by the template's own #order_review closing tag.
		$this->close_checkout_wrappers( $this->open_wrappers );
	}

	/**
	 * Hide Order Notes Field
	 *
	 * Callback for the 'woocommerce_enable_order_notes_field' filter, used when
	 * the Hide Additional Information Box option is on.
	 *
	 * A dedicated callback rather than '__return_false' so remove_render_hooks()
	 * takes off this widget's filter and not one another plugin registered at the
	 * same priority.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @return bool Always false.
	 */
	public function hide_order_notes_field() {
		return false;
	}

	/**
	 * Add Render Hooks
	 *
	 * Add actions & filters before displaying our widget.
	 *
	 * @since 2.9.5
	 */
	public function add_render_hooks() {
		$settings = $this->get_display_settings();

		add_filter( 'woocommerce_form_field_args', [ $this, 'modify_form_field' ], 70, 3 );
		add_filter( 'woocommerce_get_terms_and_conditions_checkbox_text', [ $this, 'woocommerce_terms_and_conditions_checkbox_text' ], 10, 1 );

		add_filter( 'gettext', [ $this, 'filter_gettext' ], 20, 3 );

		/*
		 * Paired with the remove_filter() in remove_render_hooks(). This used to
		 * be added in render() and never taken off again, which switched the order
		 * notes field off for everything rendered after this widget rather than
		 * just for the widget itself.
		 */
		if ( 'yes' === $settings['hide_additional_info'] ) {
			add_filter( 'woocommerce_enable_order_notes_field', [ $this, 'hide_order_notes_field' ], 9999 );
		}

		add_action( 'woocommerce_checkout_before_customer_details', [ $this, 'woocommerce_checkout_before_customer_details' ], 5 );
		add_action( 'woocommerce_checkout_after_customer_details', [ $this, 'woocommerce_checkout_after_customer_details' ], 95 );
		add_action( 'woocommerce_checkout_before_order_review_heading', [ $this, 'woocommerce_checkout_before_order_review_heading_1' ], 5 );
		add_action( 'woocommerce_checkout_before_order_review_heading', [ $this, 'woocommerce_checkout_before_order_review_heading_2' ], 95 );
		add_action( 'woocommerce_checkout_order_review', [ $this, 'woocommerce_checkout_order_review' ], 15 );
		add_action( 'woocommerce_checkout_after_order_review', [ $this, 'woocommerce_checkout_after_order_review' ], 95 );
	}

	/**
	 * Remove Render Hooks
	 *
	 * Remove actions & filters after displaying our widget.
	 *
	 * @since 2.9.5
	 */
	public function remove_render_hooks() {
		remove_filter( 'woocommerce_form_field_args', [ $this, 'modify_form_field' ], 70 );
		remove_filter( 'woocommerce_get_terms_and_conditions_checkbox_text', [ $this, 'woocommerce_terms_and_conditions_checkbox_text' ], 10 );

		remove_filter( 'gettext', [ $this, 'filter_gettext' ], 20 );

		// Removed unconditionally. The setting is read from the same memoised
		// array in add_render_hooks(), but taking the filter off either way means
		// a mid-render change of mind cannot leave it installed.
		remove_filter( 'woocommerce_enable_order_notes_field', [ $this, 'hide_order_notes_field' ], 9999 );

		remove_action( 'woocommerce_checkout_before_customer_details', [ $this, 'woocommerce_checkout_before_customer_details' ], 5 );
		remove_action( 'woocommerce_checkout_after_customer_details', [ $this, 'woocommerce_checkout_after_customer_details' ], 95 );
		remove_action( 'woocommerce_checkout_before_order_review_heading', [ $this, 'woocommerce_checkout_before_order_review_heading_1' ], 5 );
		remove_action( 'woocommerce_checkout_before_order_review_heading', [ $this, 'woocommerce_checkout_before_order_review_heading_2' ], 95 );
		remove_action( 'woocommerce_checkout_order_review', [ $this, 'woocommerce_checkout_order_review' ], 15 );
		remove_action( 'woocommerce_checkout_after_order_review', [ $this, 'woocommerce_checkout_after_order_review' ], 95 );
	}

	/**
	 * Render output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		// Reset the per-render caches before anything reads them, so a second
		// render of the same instance sees the current settings.
		$this->display_settings        = null;
		$this->reformatted_form_fields = null;
		$this->open_wrappers           = 0;

		$settings           = $this->get_display_settings();
		$is_editor          = PP_Helper::elementor()->editor->is_edit_mode();
		$store_current_user = 0;

		// Simulate a logged out user so that all WooCommerce sections will render in the Editor
		if ( $is_editor ) {
			$store_current_user = wp_get_current_user()->ID;
			wp_set_current_user( 0 );
		}

		/*
		 * Everything from here runs inside try/finally. A payment gateway or a
		 * third party callback throwing part way through the checkout shortcode
		 * would otherwise leave our filters installed and, in the editor, leave
		 * the request with no current user for whatever renders next.
		 */
		try {
			// Add actions & filters before displaying our Widget.
			$this->add_render_hooks();

			/*
			 * woopack-product-checkout used to be a wrapper div of its own, the
			 * only child of this element and with no styling anywhere in the
			 * plugin. It is kept as a class name on the surviving element so
			 * custom CSS that targets it still matches.
			 *
			 * The clearfix class it used to carry is gone. It had no rule of its
			 * own here, and the floats it was nominally there for are contained
			 * by .pp-woo-checkout .woocommerce::after in the widget stylesheet
			 * instead.
			 */
			$this->add_render_attribute(
				'container',
				[
					'class' => [
						'pp-woocommerce',
						'pp-woo-checkout',
						'pp-woo-checkout-col-' . $settings['layout'],
						'woopack-product-checkout',
					],
					'id'    => 'pp-woo-checkout-' . $this->get_id(),
				]
			);
			?>
			<div <?php $this->print_render_attribute_string( 'container' ); ?>>
				<?php
				/**
				 * Fires at the start of the Woo - Checkout widget's wrapper,
				 * before anything else in it is printed.
				 *
				 * @since 1.4.3
				 */
				do_action( 'pp_woo_before_checkout_wrap' );

				/**
				 * Fires inside the Woo - Checkout widget wrapper, before the
				 * checkout shortcode is rendered.
				 *
				 * @since 1.4.3
				 */
				do_action( 'pp_woo_before_checkout_content' );

				echo do_shortcode( '[woocommerce_checkout]' );

				// Close anything the checkout template left open. A theme that
				// ships its own checkout/form-checkout.php and drops one of the
				// hooks above would otherwise leak unclosed divs into the rest of
				// the page.
				$this->close_checkout_wrappers( $this->open_wrappers );

				/**
				 * Fires inside the Woo - Checkout widget wrapper, after the
				 * checkout shortcode has been rendered.
				 *
				 * @since 1.4.3
				 */
				do_action( 'pp_woo_after_checkout_content' );

				/**
				 * Fires at the end of the Woo - Checkout widget's wrapper, after
				 * everything else in it has been printed.
				 *
				 * @since 1.4.3
				 */
				do_action( 'pp_woo_after_checkout_wrap' );
				?>
			</div>
			<?php
		} finally {
			// Remove actions & filters after displaying our Widget.
			$this->remove_render_hooks();

			// Return to existing logged-in user after widget is rendered.
			if ( $is_editor ) {
				wp_set_current_user( $store_current_user );
			}
		}
	}

	/**
	 * Render the widget as plain content.
	 *
	 * Used when Elementor exports the page without its own markup, e.g. in feeds
	 * and in the WordPress editor's plain content representation.
	 *
	 * @since 1.4.5
	 * @access public
	 */
	public function render_plain_content() {
		echo '[woocommerce_checkout]';
	}
}
