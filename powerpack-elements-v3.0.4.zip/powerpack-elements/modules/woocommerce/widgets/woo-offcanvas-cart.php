<?php
/**
 * PowerPack WooCommerce Cart widget.
 *
 * @package PowerPack
 */

namespace PowerpackElements\Modules\Woocommerce\Widgets;

use PowerpackElements\Base\Powerpack_Widget;
use PowerpackElements\Classes\PP_Helper;

use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) {
	exit;   // Exit if accessed directly.
}

/**
 * Woo - Off Canvas Cart widget
 *
 * @since 1.4.4
 */
class Woo_Offcanvas_Cart extends Powerpack_Widget {

	/**
	 * Retrieve Woo - Offcanvas Cart widget categories.
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return parent::get_woo_categories();
	}

	/**
	 * Retrieve Woo - Offcanvas Cart widget name.
	 *
	 * @since 1.4.4
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Woo_Offcanvas_Cart' );
	}

	/**
	 * Retrieve Woo - Offcanvas Cart widget title.
	 *
	 * @since 1.4.4
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Woo_Offcanvas_Cart' );
	}

	/**
	 * Retrieve Woo - Offcanvas Cart widget icon.
	 *
	 * @since 1.4.4
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Woo_Offcanvas_Cart' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the Woo - Offcanvas Cart widget belongs to.
	 *
	 * @since 1.3.7
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Woo_Offcanvas_Cart' );
	}

	/**
	 * Retrieve the list of scripts the Woo - Offcanvas Cart widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.4.4
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [
			'pp-offcanvas-content',
		];
	}

	/**
	 * Retrieve the list of styles the Woo - Offcanvas Cart depended on.
	 *
	 * Used to set style dependencies required to run the widget.
	 *
	 * @since 1.4.4
	 * @access public
	 *
	 * @return array Widget style dependencies.
	 */
	public function get_style_depends() {
		return [
			'pp-woocommerce',
			'widget-pp-offcanvas-content',
		];
	}

	/**
	 * Whether the widget should be wrapped in Elementor's inner wrapper.
	 *
	 * The widget prints its own container, so the extra wrapper is dropped when
	 * the optimized markup experiment is on.
	 *
	 * @since 2.11.8
	 * @access public
	 *
	 * @return bool
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register Woo - Offcanvas Cart widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function register_controls() {
		/* General Settings */
		$this->register_content_general_controls();

		/* Cart Button Settings */
		$this->register_content_cart_button_controls();

		/* Offcanvas Panel Settings */
		$this->register_panel_controls();

		/* Close Button Settings */
		$this->register_close_button_controls();

		/* Style Tab: Cart Button */
		$this->register_style_cart_button_controls();

		/* Style Tab: Off Canvas Panel */
		$this->register_style_offcanvas_controls();

		/* Style Tab: Item */
		$this->register_style_items_controls();

		/* Style Tab: Empty Cart Message */
		$this->register_style_empty_cart_message_controls();

		/* Style Tab: Subtotal */
		$this->register_style_subtotal_controls();

		/* Style Tab: Action Buttons */
		$this->register_style_buttons_controls();

		/* Style Tab: Close Button */
		$this->register_style_close_button_controls();
	}

	/**
	 * Register the General content controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_content_general_controls() {

		/**
		 * Content Tab: Toggle
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_general_settings',
			[
				'label'                 => esc_html__( 'General', 'powerpack' ),
			]
		);

		$this->add_control(
			'toggle_source',
			[
				'label'                 => esc_html__( 'Trigger', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'button',
				'options'               => [
					'button'        => esc_html__( 'Button', 'powerpack' ),
					'element-class' => esc_html__( 'Element Class', 'powerpack' ),
					'element-id'    => esc_html__( 'Element ID', 'powerpack' ),
				],
				'frontend_available'    => true,
			]
		);

		$this->add_control(
			'toggle_class',
			[
				'label'                 => esc_html__( 'Trigger CSS Class', 'powerpack' ),
				'type'                  => Controls_Manager::TEXT,
				'dynamic'               => [
					'active' => true,
				],
				'ai'                    => [
					'active' => false,
				],
				'default'               => '',
				'frontend_available'    => true,
				'condition'             => [
					'toggle_source' => 'element-class',
				],
			]
		);

		$this->add_control(
			'toggle_id',
			[
				'label'                 => esc_html__( 'Trigger CSS ID', 'powerpack' ),
				'type'                  => Controls_Manager::TEXT,
				'dynamic'               => [
					'active' => true,
				],
				'ai'                    => [
					'active' => false,
				],
				'default'               => '',
				'frontend_available'    => true,
				'condition'             => [
					'toggle_source' => 'element-id',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Cart Button content controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_content_cart_button_controls() {

		$this->start_controls_section(
			'section_settings',
			[
				'label'                 => esc_html__( 'Cart Button', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_CONTENT,
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'icon_style',
			[
				'label'                 => esc_html__( 'Style', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'icon',
				'options'               => [
					'icon'      => esc_html__( 'Icon only', 'powerpack' ),
					'icon_text' => esc_html__( 'Icon + Text', 'powerpack' ),
					'text'      => esc_html__( 'Text only', 'powerpack' ),
				],
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'cart_text',
			[
				'label'                 => esc_html__( 'Text', 'powerpack' ),
				'type'                  => Controls_Manager::TEXT,
				'default'               => esc_html__( 'Cart', 'powerpack' ),
				'condition'             => [
					'toggle_source' => 'button',
					'icon_style'    => [ 'icon_text', 'text' ],
				],
			]
		);

		$this->add_control(
			'icon_type',
			[
				'label'                 => esc_html__( 'Icon Type', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'label_block'           => false,
				'toggle'                => false,
				'options'               => [
					'icon'  => [
						'title' => esc_html__( 'Icon', 'powerpack' ),
						'icon'  => 'eicon-star',
					],
					'image' => [
						'title' => esc_html__( 'Image', 'powerpack' ),
						'icon'  => 'eicon-image-bold',
					],
				],
				'default'               => 'icon',
				'condition'             => [
					'toggle_source' => 'button',
					'icon_style'    => [ 'icon_text', 'icon' ],
				],
			]
		);

		$this->add_control(
			'icon',
			[
				'label'                 => esc_html__( 'Icon', 'powerpack' ),
				'type'                  => Controls_Manager::ICONS,
				'default'               => [
					'value'     => 'fas fa-shopping-cart',
					'library'   => 'fa-solid',
				],
				'condition'             => [
					'toggle_source' => 'button',
					'icon_style'    => [ 'icon_text', 'icon' ],
					'icon_type'     => 'icon',
				],
			]
		);

		$this->add_control(
			'icon_image',
			[
				'label'                 => esc_html__( 'Image Icon', 'powerpack' ),
				'type'                  => Controls_Manager::MEDIA,
				'dynamic'               => [
					'active'   => true,
				],
				'default'               => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition'             => [
					'toggle_source' => 'button',
					'icon_style'    => [ 'icon_text', 'icon' ],
					'icon_type'     => 'image',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'                  => 'icon_image',
				'default'               => 'full',
				'separator'             => 'none',
				'condition'             => [
					'toggle_source' => 'button',
					'icon_style'    => [ 'icon_text', 'icon' ],
					'icon_type'     => 'image',
				],
			]
		);

		$this->add_control(
			'counter_position',
			[
				'label'                 => esc_html__( 'Counter Position', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'top',
				'options'               => [
					'none'      => esc_html__( 'None', 'powerpack' ),
					'top'       => esc_html__( 'Bubble', 'powerpack' ),
					'after'     => esc_html__( 'After Button', 'powerpack' ),
				],
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'hide_empty',
			[
				'label'                 => esc_html__( 'Hide Empty', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'default'               => '',
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'show_subtotal',
			[
				'label'                 => esc_html__( 'Subtotal', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'label_on'              => esc_html__( 'Show', 'powerpack' ),
				'label_off'             => esc_html__( 'Hide', 'powerpack' ),
				'return_value'          => 'yes',
				'default'               => 'yes',
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'toggle_position',
			[
				'label'                 => esc_html__( 'Position', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'inline',
				'options'               => [
					'inline'        => esc_html__( 'Inline', 'powerpack' ),
					'floating'      => esc_html__( 'Floating', 'powerpack' ),
				],
				'separator'             => 'before',
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'floating_toggle_placement',
			[
				'label'                 => esc_html__( 'Placement', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'middle-right',
				'options'               => [
					'top-left'      => esc_html__( 'Top Left', 'powerpack' ),
					'top-center'    => esc_html__( 'Top Center', 'powerpack' ),
					'top-right'     => esc_html__( 'Top Right', 'powerpack' ),
					'middle-left'   => esc_html__( 'Middle Left', 'powerpack' ),
					'middle-right'  => esc_html__( 'Middle Right', 'powerpack' ),
					'bottom-right'  => esc_html__( 'Bottom Right', 'powerpack' ),
					'bottom-center' => esc_html__( 'Bottom Center', 'powerpack' ),
					'bottom-left'   => esc_html__( 'Bottom Left', 'powerpack' ),
				],
				'prefix_class'          => 'pp-floating-element-align-',
				'condition'             => [
					'toggle_source'   => 'button',
					'toggle_position' => 'floating',
				],
			]
		);

		$this->add_control(
			'toggle_zindex',
			[
				'label'                 => esc_html__( 'Z-Index', 'powerpack' ),
				'description'           => esc_html__( 'Adjust the z-index of the floating toggle.', 'powerpack' ),
				'type'                  => Controls_Manager::NUMBER,
				'default'               => 999,
				'min'                   => 0,
				'step'                  => 1,
				'selectors'             => [
					'{{WRAPPER}} .pp-floating-element' => 'z-index: {{SIZE}};',
				],
				'condition'             => [
					'toggle_source'   => 'button',
					'toggle_position' => 'floating',
				],
			]
		);

		$this->add_responsive_control(
			'button_align',
			[
				'label'                 => esc_html__( 'Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'options'               => [
					'left'      => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'    => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'     => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-offcanvas-cart-container'   => 'text-align: {{VALUE}};',
				],
				'separator'             => 'before',
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Off Canvas Panel content controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_panel_controls() {

		/**
		 * Content Tab: Off Canvas Panel
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_panel_settings',
			[
				'label'                 => esc_html__( 'Off Canvas Panel', 'powerpack' ),
			]
		);

		$this->add_control(
			'editor_preview',
			[
				'label'                 => esc_html__( 'Preview in Editor', 'powerpack' ),
				'description'           => esc_html__( 'Hold the panel open while this widget is selected, so the panel style options can be seen while they are set.', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => '',
				'label_on'              => esc_html__( 'Show', 'powerpack' ),
				'label_off'             => esc_html__( 'Hide', 'powerpack' ),
				'return_value'          => 'yes',
				'frontend_available'    => true,
			]
		);

		$this->add_control(
			'open_panel_add_to_cart',
			[
				'label'                 => esc_html__( 'Open Panel on Cart Button Click', 'powerpack' ),
				'description'           => esc_html__( 'Open Off Canvas cart panel when product is added to cart.', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'default'               => '',
				'frontend_available'    => true,
			]
		);

		$this->add_control(
			'direction',
			[
				'label'                 => esc_html__( 'Direction', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'label_block'           => false,
				'toggle'                => false,
				'default'               => 'left',
				'options'               => [
					'left'          => [
						'title'     => esc_html__( 'Left', 'powerpack' ),
						'icon'      => 'eicon-h-align-left',
					],
					'right'         => [
						'title'     => esc_html__( 'Right', 'powerpack' ),
						'icon'      => 'eicon-h-align-right',
					],
					'top'         => [
						'title'     => esc_html__( 'Top', 'powerpack' ),
						'icon'      => 'eicon-v-align-top',
					],
					'bottom'         => [
						'title'     => esc_html__( 'Bottom', 'powerpack' ),
						'icon'      => 'eicon-v-align-bottom',
					],
				],
				'frontend_available'    => true,
			]
		);

		$this->add_control(
			'content_transition',
			[
				'label'                 => esc_html__( 'Transition', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'slide',
				'options'               => [
					'slide'                 => esc_html__( 'Slide', 'powerpack' ),
					'reveal'                => esc_html__( 'Reveal', 'powerpack' ),
					'push'                  => esc_html__( 'Push', 'powerpack' ),
					'slide-along'           => esc_html__( 'Slide Along', 'powerpack' ),
				],
				'frontend_available'    => true,
			]
		);

		$this->add_control(
			'cart_title',
			[
				'label'                 => esc_html__( 'Cart Title', 'powerpack' ),
				'description'           => esc_html__( 'Cart title is displayed on top of cart items.', 'powerpack' ),
				'type'                  => Controls_Manager::TEXT,
				'default'               => esc_html__( 'PowerPack Off Canvas Cart', 'powerpack' ),
				'separator'             => 'before',
			]
		);

		$this->add_control(
			'cart_title_html_tag',
			[
				'label'                 => esc_html__( 'Title HTML Tag', 'powerpack' ),
				'description'           => esc_html__( 'The panel title labels the cart for assistive technology. Use a heading if the cart is a section of the page, or div to keep it out of the page heading outline.', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'div',
				'options'               => [
					'h1'   => esc_html__( 'H1', 'powerpack' ),
					'h2'   => esc_html__( 'H2', 'powerpack' ),
					'h3'   => esc_html__( 'H3', 'powerpack' ),
					'h4'   => esc_html__( 'H4', 'powerpack' ),
					'h5'   => esc_html__( 'H5', 'powerpack' ),
					'h6'   => esc_html__( 'H6', 'powerpack' ),
					'div'  => esc_html__( 'div', 'powerpack' ),
					'span' => esc_html__( 'span', 'powerpack' ),
					'p'    => esc_html__( 'p', 'powerpack' ),
				],
				'condition'             => [
					'cart_title!' => '',
				],
			]
		);

		$this->add_control(
			'cart_message',
			[
				'label'                 => esc_html__( 'Cart Message', 'powerpack' ),
				'description'           => esc_html__( 'Cart message is displayed on bottom of cart items.', 'powerpack' ),
				'type'                  => Controls_Manager::TEXTAREA,
				'default'               => esc_html__( '100% Secure Checkout!', 'powerpack' ),
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Close Button content controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_close_button_controls() {

		/**
		 * Content Tab: Close Button
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_close_button_settings',
			[
				'label'                 => esc_html__( 'Close Button', 'powerpack' ),
			]
		);

		$this->add_control(
			'close_button',
			[
				'label'                 => esc_html__( 'Show Close Button', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'yes',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
			]
		);

		$this->add_control(
			'close_button_align',
			[
				'label'                 => esc_html__( 'Position', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'toggle'                => false,
				'options'               => [
					'left'          => [
						'title'     => esc_html__( 'Left', 'powerpack' ),
						'icon'      => 'eicon-h-align-left',
					],
					'right'         => [
						'title'     => esc_html__( 'Right', 'powerpack' ),
						'icon'      => 'eicon-h-align-right',
					],
				],
				'default'               => 'right',
				'condition'             => [
					'close_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'close_button_icon_type',
			[
				'label'                 => esc_html__( 'Close Icon', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'default',
				'options'               => [
					'default'   => esc_html__( 'Default Icon', 'powerpack' ),
					'icon'      => esc_html__( 'Choose Icon', 'powerpack' ),
				],
				'condition'             => [
					'close_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'close_button_icon',
			[
				'label'                 => esc_html__( 'Choose Close Icon', 'powerpack' ),
				'type'                  => Controls_Manager::ICONS,
				'default'               => [
					'value'     => 'fas fa-times',
					'library'   => 'fa-solid',
				],
				'recommended'           => [
					'fa-regular' => [
						'times-circle',
					],
					'fa-solid' => [
						'times',
						'times-circle',
					],
				],
				'condition'             => [
					'close_button'           => 'yes',
					'close_button_icon_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'close_button_hover_animation',
			[
				'label'             => esc_html__( 'Hover Animation', 'powerpack' ),
				'type'              => Controls_Manager::SWITCHER,
				'default'           => '',
				'label_on'          => esc_html__( 'Yes', 'powerpack' ),
				'label_off'         => esc_html__( 'No', 'powerpack' ),
				'return_value'      => 'yes',
				'condition'         => [
					'close_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'esc_close',
			[
				'label'             => esc_html__( 'Esc to Close', 'powerpack' ),
				'type'              => Controls_Manager::SWITCHER,
				'default'           => 'yes',
				'label_on'          => esc_html__( 'Yes', 'powerpack' ),
				'label_off'         => esc_html__( 'No', 'powerpack' ),
				'return_value'      => 'yes',
			]
		);

		$this->add_control(
			'body_click_close',
			[
				'label'             => esc_html__( 'Click Overlay to Close', 'powerpack' ),
				'type'              => Controls_Manager::SWITCHER,
				'default'           => 'yes',
				'label_on'          => esc_html__( 'Yes', 'powerpack' ),
				'label_off'         => esc_html__( 'No', 'powerpack' ),
				'return_value'      => 'yes',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Off Canvas Panel style controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_style_offcanvas_controls() {

		$this->start_controls_section(
			'section_offcanvas_style',
			[
				'label' => esc_html__( 'Off Canvas Panel', 'powerpack' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'offcanvas_bar_width',
			[
				'label'                 => esc_html__( 'Width', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'vw', 'custom' ],
				'default'               => [
					'size'      => 340,
					'unit'      => 'px',
				],
				'range'                 => [
					'px'        => [
						'min'   => 100,
						'max'   => 1000,
						'step'  => 1,
					],
				],
				'selectors'             => [
					'#pp-offcanvas-{{ID}}' => 'width: {{SIZE}}{{UNIT}}',

					'.pp-offcanvas-content-reveal.pp-offcanvas-open.pp-offcanvas-{{ID}}-open.pp-offcanvas-left .pp-offcanvas-container,
                    .pp-offcanvas-content-push.pp-offcanvas-open.pp-offcanvas-{{ID}}-open.pp-offcanvas-left .pp-offcanvas-container,
                    .pp-offcanvas-content-slide-along.pp-offcanvas-open.pp-offcanvas-{{ID}}-open.pp-offcanvas-left .pp-offcanvas-container' => 'transform: translate3d({{SIZE}}{{UNIT}}, 0, 0)',

					'.pp-offcanvas-content-reveal.pp-offcanvas-open.pp-offcanvas-{{ID}}-open.pp-offcanvas-right .pp-offcanvas-container,
                    .pp-offcanvas-content-push.pp-offcanvas-open.pp-offcanvas-{{ID}}-open.pp-offcanvas-right .pp-offcanvas-container,
                    .pp-offcanvas-content-slide-along.pp-offcanvas-open.pp-offcanvas-{{ID}}-open.pp-offcanvas-right .pp-offcanvas-container' => 'transform: translate3d(-{{SIZE}}{{UNIT}}, 0, 0)',
				],
				'condition' => [
					'direction' => [ 'left', 'right' ],
				],
			]
		);

		$this->add_responsive_control(
			'offcanvas_bar_height',
			[
				'label'                 => esc_html__( 'Height', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'vh', 'custom' ],
				'default'               => [
					'size'      => 300,
					'unit'      => 'px',
				],
				'range'                 => [
					'px'        => [
						'min'   => 100,
						'max'   => 1000,
						'step'  => 1,
					],
				],
				'selectors'             => [
					'#pp-offcanvas-{{ID}}.pp-offcanvas-top, #pp-offcanvas-{{ID}}.pp-offcanvas-bottom' => 'width: 100%; height: {{SIZE}}{{UNIT}}',

					'.pp-offcanvas-content-reveal.pp-offcanvas-open.pp-offcanvas-{{ID}}-open.pp-offcanvas-top .pp-offcanvas-container,
                    .pp-offcanvas-content-push.pp-offcanvas-open.pp-offcanvas-{{ID}}-open.pp-offcanvas-top .pp-offcanvas-container,
                    .pp-offcanvas-content-slide-along.pp-offcanvas-open.pp-offcanvas-{{ID}}-open.pp-offcanvas-top .pp-offcanvas-container' => 'transform: translate3d(0, {{SIZE}}{{UNIT}}, 0)',

					'.pp-offcanvas-content-reveal.pp-offcanvas-open.pp-offcanvas-{{ID}}-open.pp-offcanvas-bottom .pp-offcanvas-container,
                    .pp-offcanvas-content-push.pp-offcanvas-open.pp-offcanvas-{{ID}}-open.pp-offcanvas-bottom .pp-offcanvas-container,
                    .pp-offcanvas-content-slide-along.pp-offcanvas-open.pp-offcanvas-{{ID}}-open.pp-offcanvas-bottom .pp-offcanvas-container' => 'transform: translate3d(0, -{{SIZE}}{{UNIT}}, 0)',
				],
				'condition' => [
					'direction' => [ 'top', 'bottom' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'                  => 'offcanvas_bar_bg',
				'label'                 => esc_html__( 'Background', 'powerpack' ),
				'types'                 => [ 'classic', 'gradient' ],
				'selector'              => '.pp-offcanvas-{{ID}} .pp-offcanvas-inner',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'offcanvas_bar_border',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'selector'              => '.pp-offcanvas-{{ID}} .pp-offcanvas-inner',
			]
		);

		$this->add_responsive_control(
			'offcanvas_bar_padding',
			[
				'label'                 => esc_html__( 'Padding', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'               => [
					'top' => '10',
					'right' => '10',
					'bottom' => '10',
					'left' => '10',
					'unit' => 'px',
					'isLinked' => true,
				],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'                  => 'offcanvas_bar_box_shadow',
				'selector'              => '.pp-offcanvas-{{ID}}',
				'separator'             => 'before',
			]
		);

		$this->add_control(
			'cart_title_heading',
			[
				'label'                 => esc_html__( 'Cart Title', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'cart_title!' => '',
				],
			]
		);

		$this->add_control(
			'cart_title_color',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-woo-menu-cart-title' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'cart_title!' => '',
				],
			]
		);

		$this->add_control(
			'cart_title_bg_color',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-woo-menu-cart-title' => 'background-color: {{VALUE}};',
				],
				'condition'             => [
					'cart_title!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'cart_title_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'selector'              => '.pp-offcanvas-{{ID}} .pp-woo-menu-cart-title',
				'condition'             => [
					'cart_title!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'cart_title_align',
			[
				'label'                 => esc_html__( 'Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'options'               => [
					'left'      => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'    => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'     => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-woo-menu-cart-title' => 'text-align: {{VALUE}};',
				],
				'condition'             => [
					'cart_title!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'cart_title_padding',
			[
				'label'                 => esc_html__( 'Padding', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-woo-menu-cart-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'             => [
					'cart_title!' => '',
				],
			]
		);

		$this->add_control(
			'cart_message_heading',
			[
				'label'                 => esc_html__( 'Cart Message', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'cart_message!' => '',
				],
			]
		);

		$this->add_control(
			'cart_message_color',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-woo-menu-cart-message' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'cart_message!' => '',
				],
			]
		);

		$this->add_control(
			'cart_message_bg_color',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-woo-menu-cart-message' => 'background-color: {{VALUE}};',
				],
				'condition'             => [
					'cart_message!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'cart_message_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'selector'              => '.pp-offcanvas-{{ID}} .pp-woo-menu-cart-message',
				'condition'             => [
					'cart_message!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'cart_message_align',
			[
				'label'                 => esc_html__( 'Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'options'               => [
					'left'      => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'    => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'     => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-woo-menu-cart-message' => 'text-align: {{VALUE}};',
				],
				'condition'             => [
					'cart_message!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'cart_message_padding',
			[
				'label'                 => esc_html__( 'Padding', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'               => [
					'top' => '10',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'unit' => 'px',
					'isLinked' => false,
				],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-woo-menu-cart-message' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'             => [
					'cart_message!' => '',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Empty Cart Message style controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_style_empty_cart_message_controls() {
		$this->start_controls_section(
			'section_empty_cart_message_style',
			[
				'label'                 => esc_html__( 'Empty Cart Message', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'empty_cart_message_color',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-cart.pp-offcanvas-{{ID}} .woocommerce-mini-cart__empty-message' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'empty_cart_message_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'selector'              => '.pp-offcanvas-cart.pp-offcanvas-{{ID}} .woocommerce-mini-cart__empty-message',
			]
		);

		$this->add_responsive_control(
			'empty_cart_message_align',
			[
				'label'                 => esc_html__( 'Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'options'               => [
					'left'      => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'    => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'     => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-cart.pp-offcanvas-{{ID}} .woocommerce-mini-cart__empty-message' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Subtotal style controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_style_subtotal_controls() {
		// The section ID is historical and does not match the section label.
		// It is persisted in saved page data, so it cannot be renamed. Do not
		// reuse it for an items container section.
		$this->start_controls_section(
			'section_items_container_style',
			[
				'label'                 => esc_html__( 'Subtotal', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'subtotal_color',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .woocommerce-mini-cart__total' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'subtotal_bg_color',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .woocommerce-mini-cart__total' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'subtotal_border',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'selector'              => '.pp-offcanvas-{{ID}} .woocommerce-mini-cart__total',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'subtotal_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'selector'              => '.pp-offcanvas-{{ID}} .woocommerce-mini-cart__total',
			]
		);

		$this->add_responsive_control(
			'subtotal_text_align',
			[
				'label'                 => esc_html__( 'Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'options'               => [
					'left'      => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'    => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'     => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-cart-items .woocommerce-mini-cart__total'   => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'subtotal_padding',
			[
				'label'                 => esc_html__( 'Padding', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-cart-items .woocommerce-mini-cart__total' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Item style controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_style_items_controls() {
		$this->start_controls_section(
			'section_items_style',
			[
				'label'                 => esc_html__( 'Item', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'cart_items_row_separator_type',
			[
				'label'                 => esc_html__( 'Separator Type', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'solid',
				'options'               => [
					'none'      => esc_html__( 'None', 'powerpack' ),
					'solid'     => esc_html__( 'Solid', 'powerpack' ),
					'dotted'    => esc_html__( 'Dotted', 'powerpack' ),
					'dashed'    => esc_html__( 'Dashed', 'powerpack' ),
					'double'    => esc_html__( 'Double', 'powerpack' ),
				],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} ul.product_list_widget li:not(:last-child)' => 'border-bottom-style: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_row_separator_color',
			[
				'label'                 => esc_html__( 'Separator Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} ul.product_list_widget li:not(:last-child)' => 'border-bottom-color: {{VALUE}};',
				],
				'condition'             => [
					'cart_items_row_separator_type!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'cart_items_row_separator_size',
			[
				'label'                 => esc_html__( 'Separator Size', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
				],
				'range'                => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} ul.product_list_widget li:not(:last-child)' => 'border-bottom-width: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'cart_items_row_separator_type!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'cart_items_spacing',
			[
				'label'                 => esc_html__( 'Items Spacing', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
				],
				'range'                => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-cart-items ul.product_list_widget li.woocommerce-mini-cart-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'cart_items_padding',
			[
				'label'                 => esc_html__( 'Padding', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-cart-items ul.product_list_widget li.woocommerce-mini-cart-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'cart_items_rows_tabs_style' );

		$this->start_controls_tab(
			'cart_items_even_row',
			[
				'label'                 => esc_html__( 'Even Row', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_items_even_row_text_color',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-cart-items .mini_cart_item:nth-child(2n)' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_even_row_links_color',
			[
				'label'                 => esc_html__( 'Links Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-cart-items .mini_cart_item:nth-child(2n) a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_even_row_background_color',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-cart-items .mini_cart_item:nth-child(2n)' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'cart_items_odd_row',
			[
				'label'                 => esc_html__( 'Odd Row', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_items_odd_row_text_color',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-cart-items .mini_cart_item:nth-child(2n+1)' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_odd_row_links_color',
			[
				'label'                 => esc_html__( 'Links Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-cart-items .mini_cart_item:nth-child(2n+1) a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_odd_row_background_color',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-cart-items .mini_cart_item:nth-child(2n+1)' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'item_name_heading',
			[
				'label'                 => esc_html__( 'Item Name', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);

		$this->add_control(
			'item_name_text_color',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-cart-items .mini_cart_item a:not(.remove)' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'item_name_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'selector'              => '.pp-offcanvas-{{ID}} .pp-offcanvas-cart-items .mini_cart_item a:not(.remove)',
			]
		);

		$this->add_responsive_control(
			'item_name_bottom_spacing',
			[
				'label'                 => esc_html__( 'Bottom Spacing', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
				],
				'range'                => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-cart-items .mini_cart_item a:not(.remove)' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'cart_items_image_heading',
			[
				'label'                 => esc_html__( 'Image', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);

		$this->add_responsive_control(
			'cart_items_image_position',
			[
				'label'                 => esc_html__( 'Position', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'label_block'           => false,
				'options'               => [
					'left'  => [
						'title'     => esc_html__( 'Left', 'powerpack' ),
						'icon'      => 'eicon-h-align-left',
					],
					'right'         => [
						'title'     => esc_html__( 'Right', 'powerpack' ),
						'icon'      => 'eicon-h-align-right',
					],
				],
				'default'               => 'left',
				// Map the saved left/right values onto logical keywords so the float
				// follows the text direction instead of fighting the RTL stylesheet.
				'selectors_dictionary'  => [
					'left'  => 'inline-start',
					'right' => 'inline-end',
				],
				'selectors'             => [
					'.pp-offcanvas-cart.pp-offcanvas-{{ID}} ul li.woocommerce-mini-cart-item a img' => 'float: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'cart_items_image_spacing',
			[
				'label'                 => esc_html__( 'Spacing', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
				],
				'range'                => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors'             => [
					'.pp-offcanvas-cart.pp-offcanvas-{{ID}} ul li.woocommerce-mini-cart-item a img' => 'margin-inline-end: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'cart_items_image_width',
			[
				'label'                 => esc_html__( 'Width', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
				],
				'range'                => [
					'px' => [
						'min' => 10,
						'max' => 250,
					],
				],
				'selectors'             => [
					'.pp-offcanvas-cart.pp-offcanvas-{{ID}} ul li.woocommerce-mini-cart-item a img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'cart_items_price_heading',
			[
				'label'                 => esc_html__( 'Item Quantity & Price', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);

		$this->add_control(
			'cart_items_price_color',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .cart_list .quantity' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'cart_items_price_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'selector'              => '.pp-offcanvas-{{ID}} .cart_list .quantity',
			]
		);

		$this->add_control(
			'cart_items_remove_icon_heading',
			[
				'label'                 => esc_html__( 'Remove Item Icon', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);

		$this->add_responsive_control(
			'cart_items_remove_icon_size',
			[
				'label'                 => esc_html__( 'Size', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
				],
				'range'                => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} ul.cart_list li a.remove' => 'font-size: {{SIZE}}{{UNIT}}; width: calc({{SIZE}}{{UNIT}} + 6px); height: calc({{SIZE}}{{UNIT}} + 6px);',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_cart_items_remove_icon_style' );

		$this->start_controls_tab(
			'tab_cart_items_remove_icon_normal',
			[
				'label'                 => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_items_remove_icon_color',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} ul.cart_list li a.remove' => 'color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_bg_color',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} ul.cart_list li a.remove' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_border_color',
			[
				'label'                 => esc_html__( 'Border Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} ul.cart_list li a.remove' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_cart_items_remove_icon_hover',
			[
				'label'                 => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_items_remove_icon_color_hover',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} ul.cart_list li a.remove:hover' => 'color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_bg_color_hover',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} ul.cart_list li a.remove:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_border_color_hover',
			[
				'label'                 => esc_html__( 'Border Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'.pp-offcanvas-{{ID}} ul.cart_list li a.remove:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register the Buttons style controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_style_buttons_controls() {

		$this->start_controls_section(
			'section_buttons_style',
			[
				'label'                 => esc_html__( 'Buttons', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'buttons_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'selector'              => '.pp-offcanvas-{{ID}} .buttons .button',
			]
		);

		$this->add_control(
			'buttons_position',
			[
				'label'                 => esc_html__( 'Position', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'bottom',
				'options'               => [
					'after'     => esc_html__( 'After Products', 'powerpack' ),
					'bottom'    => esc_html__( 'Bottom', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'buttons_layout',
			[
				'label'                 => esc_html__( 'Layout', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'inline',
				'options'               => [
					'inline'        => esc_html__( 'Inline', 'powerpack' ),
					'stacked'       => esc_html__( 'Stacked', 'powerpack' ),
				],
			]
		);

		$this->add_responsive_control(
			'buttons_align',
			[
				'label'                 => esc_html__( 'Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'options'               => [
					'left'      => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'    => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'     => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'               => '',
				'prefix_class'          => 'pp-woo-menu-cart-align-',
				'selectors'             => [
					'.pp-offcanvas-{{ID}}.pp-woo-cart-buttons-inline .buttons'   => 'text-align: {{VALUE}};',
				],
				'condition'             => [
					'buttons_layout' => 'inline',
				],
			]
		);

		$this->add_responsive_control(
			'buttons_gap',
			[
				'label'                 => esc_html__( 'Space Between', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
				],
				'range'                => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
				],
				'selectors'             => [
					'.pp-offcanvas-{{ID}}.pp-woo-cart-buttons-inline .buttons .button.checkout.checkout' => 'margin-inline-start: {{SIZE}}{{UNIT}};',
					'.pp-offcanvas-{{ID}}.pp-woo-cart-buttons-stacked .buttons .button.checkout.checkout' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'buttons_margin_top',
			[
				'label'                 => esc_html__( 'Margin Top', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
				],
				'range'                => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
				],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-cart-items .buttons' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'buttons_padding',
			[
				'label'                 => esc_html__( 'Padding', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .buttons .button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'view_cart_button_heading',
			[
				'label'                 => esc_html__( 'View Cart Button', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);

		$this->start_controls_tabs( 'tabs_view_cart_button_style' );

		$this->start_controls_tab(
			'tab_view_cart_button_normal',
			[
				'label'                 => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'view_cart_button_bg_color_normal',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .buttons .button:not(.checkout)' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'view_cart_button_text_color_normal',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .buttons .button:not(.checkout)' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'view_cart_button_border_normal',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'selector'              => '.pp-offcanvas-{{ID}} .buttons .button:not(.checkout)',
			]
		);

		$this->add_control(
			'view_cart_button_border_radius',
			[
				'label'                 => esc_html__( 'Border Radius', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .buttons .button:not(.checkout)' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'                  => 'view_cart_button_box_shadow',
				'selector'              => '.pp-offcanvas-{{ID}} .buttons .button:not(.checkout)',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_view_cart_button_hover',
			[
				'label'                 => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'view_cart_button_bg_color_hover',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .buttons .button:not(.checkout):hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'view_cart_button_text_color_hover',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .buttons .button:not(.checkout):hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'view_cart_button_border_color_hover',
			[
				'label'                 => esc_html__( 'Border Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .buttons .button:not(.checkout):hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'                  => 'view_cart_button_box_shadow_hover',
				'selector'              => '.pp-offcanvas-{{ID}} .buttons .button:not(.checkout):hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			'checkout_button_heading',
			[
				'label'                 => esc_html__( 'Checkout Button', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);

		$this->start_controls_tabs( 'tabs_checkout_button_style' );

		$this->start_controls_tab(
			'tab_checkout_button_normal',
			[
				'label'                 => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'checkout_button_bg_color_normal',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .buttons .button.checkout' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'checkout_button_text_color_normal',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .buttons .button.checkout' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'checkout_button_border_normal',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'selector'              => '.pp-offcanvas-{{ID}} .buttons .button.checkout',
			]
		);

		$this->add_control(
			'checkout_button_border_radius',
			[
				'label'                 => esc_html__( 'Border Radius', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .buttons .button.checkout' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'                  => 'checkout_button_box_shadow',
				'selector'              => '.pp-offcanvas-{{ID}} .buttons .button.checkout',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_checkout_button_hover',
			[
				'label'                 => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'checkout_button_bg_color_hover',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .buttons .button.checkout:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'checkout_button_text_color_hover',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .buttons .button.checkout:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'checkout_button_border_color_hover',
			[
				'label'                 => esc_html__( 'Border Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .buttons .button.checkout:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'                  => 'checkout_button_box_shadow_hover',
				'selector'              => '.pp-offcanvas-{{ID}} .buttons .button.checkout:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register the Close Button style controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_style_close_button_controls() {

		$this->start_controls_section(
			'section_close_button_style',
			[
				'label'                 => esc_html__( 'Close Button', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'close_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'close_button_size',
			[
				'label'                 => esc_html__( 'Icon Size', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
				],
				'range'                => [
					'px' => [
						'min' => 10,
						'max' => 80,
					],
				],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-close' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'close_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'close_button_thickness',
			[
				'label'                 => esc_html__( 'Icon Thickness', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
				],
				'range'                => [
					'px' => [
						'min' => 1,
						'max' => 8,
					],
				],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-close-icon:after, .pp-offcanvas-{{ID}} .pp-offcanvas-close-icon:before' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'close_button'           => 'yes',
					'close_button_icon_type' => 'default',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_close_button' );

		$this->start_controls_tab(
			'tab_close_button_normal',
			[
				'label'                 => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'close_button_color',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-close' => 'color: {{VALUE}}',
					'.pp-offcanvas-{{ID}} .pp-offcanvas-close-icon:after, .pp-offcanvas-{{ID}} .pp-offcanvas-close-icon:before' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'close_button_bg_color',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-close' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'close_button_border',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'selector'              => '.pp-offcanvas-{{ID}} .pp-offcanvas-close',
			]
		);

		$this->add_control(
			'close_button_border_radius',
			[
				'label'                 => esc_html__( 'Border Radius', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-close' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'close_button_padding',
			[
				'label'                 => esc_html__( 'Padding', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-close' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_close_button_hover',
			[
				'label'                 => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'close_button_color_hover',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-close:hover' => 'color: {{VALUE}}',
					'.pp-offcanvas-{{ID}} .pp-offcanvas-close-icon:hover:after, .pp-offcanvas-{{ID}} .pp-offcanvas-close-icon:hover:before' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'close_button_bg_color_hover',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'.pp-offcanvas-{{ID}} .pp-offcanvas-close:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register the Cart Button style controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_style_cart_button_controls() {

		$this->start_controls_section(
			'section_cart_button_style',
			[
				'label'                 => esc_html__( 'Cart Button', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'cart_button_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'selector'              => '{{WRAPPER}} .pp-offcanvas-cart-container .pp-woo-cart-contents',
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_cart_button' );

		$this->start_controls_tab(
			'tab_cart_button_normal',
			[
				'label'                 => esc_html__( 'Normal', 'powerpack' ),
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'cart_button_color',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-offcanvas-cart-container .pp-woo-cart-contents' => 'color: {{VALUE}}',
				],
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'cart_button_bg_color',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-offcanvas-cart-container .pp-woo-cart-contents' => 'background-color: {{VALUE}}',
				],
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'cart_button_border',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'selector'              => '{{WRAPPER}} .pp-offcanvas-cart-container .pp-woo-cart-contents',
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'cart_button_border_radius',
			[
				'label'                 => esc_html__( 'Border Radius', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-offcanvas-cart-container .pp-woo-cart-contents' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_responsive_control(
			'cart_button_padding',
			[
				'label'                 => esc_html__( 'Padding', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-offcanvas-cart-container .pp-woo-cart-contents' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_cart_button_hover',
			[
				'label'                 => esc_html__( 'Hover', 'powerpack' ),
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'cart_button_color_hover',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-offcanvas-cart-container .pp-woo-cart-contents:hover' => 'color: {{VALUE}}',
				],
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'cart_button_bg_color_hover',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-offcanvas-cart-container .pp-woo-cart-contents:hover' => 'background-color: {{VALUE}}',
				],
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'cart_button_border_color_hover',
			[
				'label'                 => esc_html__( 'Border Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-offcanvas-cart-container .pp-woo-cart-contents:hover' => 'border-color: {{VALUE}}',
				],
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			'cart_button_icon_heading',
			[
				'label'                 => esc_html__( 'Button Icon', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'toggle_source' => 'button',
					'icon_style'    => [ 'icon_text', 'icon' ],
				],
			]
		);

		$this->add_control(
			'cart_button_icon_color',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-woo-menu-cart-button .pp-mini-cart-button-icon' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-woo-menu-cart-button .pp-icon svg' => 'fill: {{VALUE}}',
				],
				'condition'             => [
					'toggle_source' => 'button',
					'icon_style'    => [ 'icon_text', 'icon' ],
					'icon_type'     => 'icon',
				],
			]
		);

		$this->add_control(
			'cart_button_icon_color_hover',
			[
				'label'                 => esc_html__( 'Hover Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-woo-menu-cart-button .pp-mini-cart-button-icon:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-woo-menu-cart-button .pp-mini-cart-button-icon:hover svg' => 'fill: {{VALUE}}',
				],
				'condition'             => [
					'toggle_source' => 'button',
					'icon_style'    => [ 'icon_text', 'icon' ],
					'icon_type'     => 'icon',
				],
			]
		);

		$this->add_responsive_control(
			'cart_button_icon_size',
			[
				'label'                 => esc_html__( 'Icon Size', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
				],
				'range'                => [
					'px' => [
						'min' => 5,
						'max' => 40,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-woo-menu-cart-button .pp-mini-cart-button-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'toggle_source' => 'button',
					'icon_style'    => [ 'icon_text', 'icon' ],
					'icon_type'     => 'icon',
				],
			]
		);

		$this->add_responsive_control(
			'cart_button_icon_img_size',
			[
				'label'                 => esc_html__( 'Icon Size', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
				],
				'range'                => [
					'px' => [
						'min' => 10,
						'max' => 60,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-woo-menu-cart-button .pp-cart-contents-icon-image img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'toggle_source' => 'button',
					'icon_style'    => [ 'icon_text', 'icon' ],
					'icon_type'     => 'image',
				],
			]
		);

		$this->add_responsive_control(
			'cart_button_icon_spacing',
			[
				'label'                 => esc_html__( 'Icon Spacing', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 5,
				],
				'range'                => [
					'px' => [
						'min' => 0,
						'max' => 40,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-woo-menu-cart-button .pp-icon' => 'margin-inline-start: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'toggle_source' => 'button',
					'icon_style'    => [ 'icon_text', 'icon' ],
				],
			]
		);

		$this->add_control(
			'cart_button_counter_heading',
			[
				'label'                 => esc_html__( 'Counter', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'cart_button_counter_color',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-cart-counter' => 'color: {{VALUE}}',
				],
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'cart_button_counter_bg_color',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-cart-counter' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .pp-woo-menu-cart-counter-after .pp-cart-counter:before' => 'border-right-color: {{VALUE}}',
				],
				'condition'             => [
					'toggle_source' => 'button',
				],
			]
		);

		$this->add_control(
			'cart_button_counter_gap',
			[
				'label'                 => esc_html__( 'Spacing', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'min' => 0,
						'max' => 20,
						'step' => 1,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-woo-menu-cart-counter-after .pp-cart-contents-count-after' => 'margin-inline-start: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'toggle_source'    => 'button',
					'counter_position' => 'after',
				],
			]
		);

		$this->add_control(
			'cart_button_counter_distance',
			[
				'label'                 => esc_html__( 'Distance', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'unit' => 'em',
				],
				'range'                 => [
					'em' => [
						'min' => 0,
						'max' => 4,
						'step' => 0.1,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-cart-counter' => 'inset-inline-end: -{{SIZE}}{{UNIT}}; top: -{{SIZE}}{{UNIT}}',
				],
				'condition'             => [
					'toggle_source'    => 'button',
					'counter_position' => 'top',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the cart items counter.
	 *
	 * The markup is duplicated in Module::pp_cart_count_fragments(), which
	 * replaces this node after every AJAX cart update. Keep the two in sync.
	 *
	 * @access protected
	 */
	protected function render_counter() {
		$count = WC()->cart->get_cart_contents_count();
		?>
		<span class="pp-cart-counter" data-counter="<?php echo esc_attr( $count ); ?>"><?php echo esc_html( $count ); ?></span>
		<?php
	}

	/**
	 * Render the cart counter inside its live region.
	 *
	 * The wrapper is the live region rather than the counter itself. WooCommerce
	 * replaces .pp-cart-counter wholesale through cart fragments, and a live region
	 * that is inserted at the same moment as its content does not get announced.
	 * The wrapper survives the fragment swap, so the new count is.
	 *
	 * @since 3.0.0
	 * @access protected
	 *
	 * @param string $wrap_class Wrapper class for this counter position.
	 */
	protected function render_counter_wrap( $wrap_class ) {
		?>
		<span class="<?php echo esc_attr( $wrap_class ); ?>" aria-live="polite" aria-atomic="true">
			<?php $this->render_counter(); ?>
			<span class="elementor-screen-only"><?php esc_html_e( 'items in cart', 'powerpack' ); ?></span>
		</span>
		<?php
	}

	/**
	 * Render the cart button icon.
	 *
	 * @access protected
	 *
	 * @param array $settings Widget settings, resolved once by render().
	 */
	protected function render_cart_icon( $settings ) {
		if ( 'icon' === $settings['icon_type'] ) {
			?>
			<span class="pp-mini-cart-button-icon pp-icon">
				<?php
					\Elementor\Icons_Manager::render_icon( $settings['icon'], [
						'class' => 'pp-cart-contents-icon',
						'aria-hidden' => 'true',
					] );
				?>
			</span>
			<?php
		} elseif ( 'image' === $settings['icon_type'] && $settings['icon_image']['url'] ) { ?>
			<span class="pp-icon pp-cart-contents-icon-image">
				<?php
					echo wp_kses_post( Group_Control_Image_Size::get_attachment_image_html( $settings, 'icon_image', 'icon_image' ) );
				?>
			</span>
			<?php
		}
	}

	/**
	 * Render the cart button text.
	 *
	 * @access protected
	 *
	 * @param array $settings Widget settings, resolved once by render().
	 */
	protected function render_text( $settings ) {
		?>
		<span class="pp-cart-contents-text"><?php echo wp_kses_post( $settings['cart_text'] ); ?></span>
		<?php
	}

	/**
	 * Render the cart subtotal.
	 *
	 * @access protected
	 *
	 * @param array $settings Widget settings, resolved once by render().
	 */
	protected function render_subtotal( $settings ) {
		$sub_total = WC()->cart->get_cart_subtotal();

		if ( 'yes' === $settings['show_subtotal'] ) {
			?>
			<span class="pp-cart-subtotal"><?php echo wp_kses_post( $sub_total ); ?></span>
			<?php
		}
	}

	/**
	 * Render output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		// The cart is not set up in every context the widget can be edited in -
		// a header template opened outside a session, for one. Say so instead of
		// rendering an empty box with no explanation.
		if ( null === WC()->cart ) {
			$this->render_editor_placeholder( [
				'body' => esc_html__( 'The WooCommerce cart is not available here, so this widget has nothing to render.', 'powerpack' ),
			] );

			return;
		}

		// get_settings_for_display(), not get_settings(): the trigger class, the
		// trigger id and the image icon all accept dynamic tags, and only this
		// method runs the tag parser over them.
		$settings = $this->get_settings_for_display();

		$panel_id = 'pp-offcanvas-' . $this->get_id();
		$title_id = 'pp-offcanvas-title-' . $this->get_id();

		$is_editor_preview = \Elementor\Plugin::$instance->editor->is_edit_mode() && 'yes' === $settings['editor_preview'];

		// Escaped once, on the way out: print_render_attribute_string() runs
		// esc_attr() over the whole encoded string. Escaping the values here as
		// well would put HTML entities inside the JSON, so the script would read
		// a class name of "foo&quot;bar" rather than the one that was saved.
		$settings_attr = [
			'toggle_source'          => $settings['toggle_source'],
			'toggle_id'              => $settings['toggle_id'],
			'toggle_class'           => $settings['toggle_class'],
			'transition'             => $settings['content_transition'],
			'direction'              => $settings['direction'],
			'esc_close'              => $settings['esc_close'],
			'body_click_close'       => $settings['body_click_close'],
			'buttons_position'       => $settings['buttons_position'],
			'open_panel_add_to_cart' => $settings['open_panel_add_to_cart'],
			'editor_preview'         => $is_editor_preview ? 'yes' : '',
		];

		$this->add_render_attribute( 'wrapper', 'class',
			[
				'pp-offcanvas-content-wrap',
				'pp-offcanvas-cart-container',
				'pp-woo-menu-cart-counter-' . $settings['counter_position'],
			]
		);

		if ( 'yes' === $settings['hide_empty'] ) {
			$this->add_render_attribute( 'wrapper', 'class', 'pp-woo-menu-cart-hide-empty' );
		}

		$this->add_render_attribute( 'wrapper', 'data-settings', wp_json_encode( $settings_attr ) );

		// The toggle opens a panel rather than navigating, so it is a real button:
		// it carries the disclosure state and can be reached and fired from the
		// keyboard. It picks up the button reset already in pp-woocommerce.css.
		$this->add_render_attribute( 'button', [
			'class'         => [
				'pp-woo-cart-contents',
				'pp-offcanvas-toggle',
				'pp-woo-cart-' . $settings['icon_style'],
			],
			'type'          => 'button',
			'title'         => esc_attr__( 'View your shopping cart', 'powerpack' ),
			'aria-expanded' => 'false',
			'aria-controls' => $panel_id,
		] );

		$this->add_render_attribute( 'offcanvas',
			[
				'class' => [
					'woocommerce',
					'pp-woo-menu-cart',
					'pp-offcanvas-cart',
					'pp-offcanvas-content',
					'pp-offcanvas-' . $this->get_id(),
					'pp-offcanvas-' . $settings_attr['transition'],
					'pp-offcanvas-' . $settings_attr['direction'],
					'pp-woo-cart-buttons-' . $settings['buttons_layout'],
				],
				'id' => [
					$panel_id,
				],
				'role'       => 'dialog',
				'aria-modal' => 'true',
			]
		);

		// The panel is only exposed to assistive tech while it is open: the
		// stylesheet keeps it visibility:hidden until .pp-offcanvas-visible is set.
		if ( $settings['cart_title'] ) {
			$this->add_render_attribute( 'offcanvas', 'aria-labelledby', $title_id );
		} else {
			$this->add_render_attribute( 'offcanvas', 'aria-label', esc_attr__( 'Shopping cart', 'powerpack' ) );
		}

		$this->add_render_attribute( 'cart-button', 'class', 'pp-woo-menu-cart-button' );

		if ( 'floating' === $settings['toggle_position'] ) {
			$this->add_render_attribute( 'cart-button', 'class', 'pp-floating-element' );
		}
		?>
		<?php
		/**
		 * Fires before the Woo - Off Canvas Cart wrapper markup.
		 *
		 * @since 1.4.4
		 */
		do_action( 'pp_woo_before_offcanvas_cart_wrap' );
		?>

		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div <?php $this->print_render_attribute_string( 'offcanvas' ); ?>>
				<div class="pp-offcanvas-inner">
					<div class="pp-offcanvas-wrap">
						<?php
						$has_close_button = ( 'yes' === $settings['close_button'] );

						// Skip the header entirely when it would be empty. It is a flex
						// row with a bottom margin, so an empty one still pushes the cart
						// items down the panel.
						if ( $has_close_button || $settings['cart_title'] ) {
							?>
							<div class="pp-offcanvas-cart-header">
								<?php
								if ( $has_close_button ) {
									$close_classes = [
										'pp-offcanvas-close',
										'pp-offcanvas-close-' . $settings['close_button_align'],
										( 'default' === $settings['close_button_icon_type'] ) ? 'pp-offcanvas-close-icon' : 'pp-icon',
									];

									if ( 'yes' === $settings['close_button_hover_animation'] ) {
										$close_classes[] = 'pp-offcanvas-close-animation';
									}

									$this->add_render_attribute( 'close-button', [
										'class'      => $close_classes,
										'type'       => 'button',
										'aria-label' => esc_attr__( 'Close cart', 'powerpack' ),
									] );
									?>
									<button <?php $this->print_render_attribute_string( 'close-button' ); ?>>
										<?php
										if ( 'default' !== $settings['close_button_icon_type'] ) {
											\Elementor\Icons_Manager::render_icon( $settings['close_button_icon'], [ 'aria-hidden' => 'true' ] );
										}
										?>
									</button>
									<?php
								}

								if ( $settings['cart_title'] ) {
									$title_tag = PP_Helper::validate_html_tag( $settings['cart_title_html_tag'] );
									?>
									<<?php echo esc_html( $title_tag ); ?> id="<?php echo esc_attr( $title_id ); ?>" class="pp-woo-menu-cart-title">
										<?php echo wp_kses_post( $settings['cart_title'] ); ?>
									</<?php echo esc_html( $title_tag ); ?>>
									<?php
								}
								?>
							</div>
							<?php
						}
						?>

						<div class="pp-offcanvas-cart-items">
							<div class="widget_shopping_cart_content"><?php woocommerce_mini_cart(); ?></div>
						</div>

						<?php if ( $settings['cart_message'] ) { ?>
							<div class="pp-woo-menu-cart-message">
								<?php echo wp_kses_post( $this->parse_text_editor( $settings['cart_message'] ) ); ?>
							</div>
						<?php } ?>
					</div>
				</div>
			</div>

			<?php
				$has_placeholder = false;
				$placeholder     = '';
			?>

			<?php if ( 'button' === $settings['toggle_source'] ) { ?>
				<?php
				if ( 'floating' === $settings['toggle_position'] ) {
					$has_placeholder = true;
					$placeholder .= esc_html__( 'Offcanvas toggle is floating.', 'powerpack' );
				} else {
					$has_placeholder = false;
				}
				?>
				<span <?php $this->print_render_attribute_string( 'cart-button' ); ?>>
					<button <?php $this->print_render_attribute_string( 'button' ); ?>>
						<?php
						// Names the control for assistive tech. Kept outside
						// .pp-cart-button-wrap: the stylesheet puts a gap between
						// adjacent spans in there, so an extra child would shift the
						// visible layout.
						?>
						<span class="elementor-screen-only"><?php esc_html_e( 'View your shopping cart', 'powerpack' ); ?></span>

						<span class="pp-cart-button-wrap">
							<?php
							if ( 'icon' === $settings['icon_style'] ) {

								$this->render_subtotal( $settings );
								$this->render_cart_icon( $settings );

							} elseif ( 'icon_text' === $settings['icon_style'] ) {

								$this->render_text( $settings );
								$this->render_subtotal( $settings );
								$this->render_cart_icon( $settings );

							} else {

								$this->render_text( $settings );
								$this->render_subtotal( $settings );

							}
							?>
						</span>

						<?php if ( 'top' === $settings['counter_position'] ) { ?>
							<?php $this->render_counter_wrap( 'pp-cart-contents-count' ); ?>
						<?php } ?>
					</button>

					<?php if ( 'after' === $settings['counter_position'] ) { ?>
						<?php $this->render_counter_wrap( 'pp-cart-contents-count-after' ); ?>
					<?php } ?>
				</span>
			<?php } else {
				$has_placeholder = true;
				$placeholder .= esc_html__( 'You have selected to open offcanvas bar using another element.', 'powerpack' );
			}

			if ( $has_placeholder ) {
				$placeholder .= ' ' . esc_html__( 'This placeholder will not be shown on the live page.', 'powerpack' );

				$this->render_editor_placeholder( [
					'body' => $placeholder,
				] );
			}
			?>
		</div>

		<?php
		/**
		 * Fires after the Woo - Off Canvas Cart wrapper markup.
		 *
		 * @since 1.4.4
		 */
		do_action( 'pp_woo_after_offcanvas_cart_wrap' );
	}
}
