<?php
/**
 * PowerPack WooCommerce Mini Cart widget.
 *
 * @package PowerPack
 */

namespace PowerpackElements\Modules\Woocommerce\Widgets;

use PowerpackElements\Base\Powerpack_Widget;
use PowerpackElements\Classes\PP_Helper;

use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Modules\DynamicTags\Module as TagsModule;

if ( ! defined( 'ABSPATH' ) ) {
	exit;   // Exit if accessed directly.
}

/**
 * Woo - Mini Cart widget
 *
 * @since 1.4.4
 */
class Woo_Mini_Cart extends Powerpack_Widget {

	/**
	 * Retrieve woo mini cart widget categories.
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return parent::get_woo_categories();
	}

	/**
	 * Retrieve woo mini cart widget name.
	 *
	 * @since 1.4.4
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Woo_Mini_Cart' );
	}

	/**
	 * Retrieve woo mini cart widget title.
	 *
	 * @since 1.4.4
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Woo_Mini_Cart' );
	}

	/**
	 * Retrieve woo mini cart widget icon.
	 *
	 * @since 1.4.4
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Woo_Mini_Cart' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 1.3.7
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Woo_Mini_Cart' );
	}

	/**
	 * Retrieve the list of scripts the woo mini cart widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.4.4
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [
			'pp-mini-cart',
		];
	}

	/**
	 * Retrieve the list of styles the Woo - Mini Cart depended on.
	 *
	 * Used to set style dependencies required to run the widget.
	 *
	 * @since 1.4.4
	 * @access public
	 *
	 * @return array Widget style dependencies.
	 */
	public function get_style_depends() {
		return [
			'pp-woocommerce',
		];
	}

	/**
	 * Whether the widget should be wrapped in Elementor's inner wrapper.
	 *
	 * The widget prints its own container, so the extra wrapper is dropped when
	 * the optimized markup experiment is on.
	 *
	 * @since 2.11.8
	 * @access public
	 *
	 * @return bool
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register woo mini cart widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function register_controls() {
		/* Button Settings */
		$this->register_content_button_controls();

		/* General Settings */
		$this->register_content_cart_controls();

		/* Style Tab: Cart Button */
		$this->register_style_cart_button_controls();

		/* Style Tab: Items Container */
		$this->register_style_items_container_controls();

		/* Style Tab: Item */
		$this->register_style_items_controls();

		/* Style Tab: Checkout Button */
		$this->register_style_buttons_controls();
	}

	/**
	 * Register the Cart Button content controls.
	 *
	 * Style of the toggle itself: icon, text, counter and button position.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_content_button_controls() {

		$this->start_controls_section(
			'section_button_settings',
			[
				'label' => esc_html__( 'Cart Button', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'icon_style',
			[
				'label'   => esc_html__( 'Style', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => [
					'icon'      => esc_html__( 'Icon only', 'powerpack' ),
					'icon_text' => esc_html__( 'Icon + Text', 'powerpack' ),
					'text'      => esc_html__( 'Text only', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'cart_text',
			[
				'label'     => esc_html__( 'Text', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Cart', 'powerpack' ),
				'condition' => [
					'icon_style' => [ 'icon_text', 'text' ],
				],
			]
		);

		$this->add_control(
			'icon_type',
			[
				'label'       => esc_html__( 'Icon Type', 'powerpack' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'toggle'      => false,
				'options'     => [
					'icon'  => [
						'title' => esc_html__( 'Icon', 'powerpack' ),
						'icon'  => 'eicon-star',
					],
					'image' => [
						'title' => esc_html__( 'Image', 'powerpack' ),
						'icon'  => 'eicon-image-bold',
					],
				],
				'default'     => 'icon',
				'condition'   => [
					'icon_style' => [ 'icon_text', 'icon' ],
				],
			]
		);

		$this->add_control(
			'icon',
			[
				'label'     => esc_html__( 'Icon', 'powerpack' ),
				'type'      => Controls_Manager::ICONS,
				'default'   => [
					'value'   => 'fas fa-shopping-bag',
					'library' => 'fa-solid',
				],
				'condition' => [
					'icon_style' => [ 'icon_text', 'icon' ],
					'icon_type'  => 'icon',
				],
			]
		);

		$this->add_control(
			'icon_image',
			[
				'label'     => esc_html__( 'Image Icon', 'powerpack' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'icon_style' => [ 'icon_text', 'icon' ],
					'icon_type'  => 'image',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'icon_image', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `image_size` and `image_custom_dimension`.
				'default'   => 'full',
				'separator' => 'none',
				'condition' => [
					'icon_style' => [ 'icon_text', 'icon' ],
					'icon_type'  => 'image',
				],
			]
		);

		$this->add_control(
			'counter_position',
			[
				'label'   => esc_html__( 'Counter', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'top',
				'options' => [
					'none'  => esc_html__( 'None', 'powerpack' ),
					'top'   => esc_html__( 'Bubble', 'powerpack' ),
					'after' => esc_html__( 'After Button', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'show_subtotal',
			[
				'label'        => esc_html__( 'Subtotal', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'button_position',
			[
				'label'   => esc_html__( 'Position', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'inline',
				'options' => [
					'inline'   => esc_html__( 'Inline', 'powerpack' ),
					'floating' => esc_html__( 'Floating', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'floating_button_placement',
			[
				'label'        => esc_html__( 'Placement', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'top-left',
				'options'      => [
					'top-left'      => esc_html__( 'Top Left', 'powerpack' ),
					'top-center'    => esc_html__( 'Top Center', 'powerpack' ),
					'top-right'     => esc_html__( 'Top Right', 'powerpack' ),
					'middle-right'  => esc_html__( 'Middle Right', 'powerpack' ),
					'bottom-right'  => esc_html__( 'Bottom Right', 'powerpack' ),
					'bottom-center' => esc_html__( 'Bottom Center', 'powerpack' ),
					'bottom-left'   => esc_html__( 'Bottom Left', 'powerpack' ),
					'middle-left'   => esc_html__( 'Middle Left', 'powerpack' ),
				],
				'prefix_class' => 'pp-floating-element-align-',
				'condition'    => [
					'button_position' => 'floating',
				],
			]
		);

		$this->add_responsive_control(
			'button_align',
			[
				'label'        => esc_html__( 'Alignment', 'powerpack' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'      => '',
				'prefix_class' => 'pp-woo-menu-cart%s-align-',
				'selectors'    => [
					'{{WRAPPER}} .pp-woo-cart-button' => 'text-align: {{VALUE}};',
				],
				'condition'    => [
					'button_position!' => 'floating',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Cart content controls.
	 *
	 * How the cart panel opens, and the title and message shown inside it.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_content_cart_controls() {

		$this->start_controls_section(
			'section_settings',
			[
				'label' => esc_html__( 'Cart', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_cart_on',
			[
				'label'   => esc_html__( 'Show Cart on', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'on-click',
				'options' => [
					'on-click' => esc_html__( 'Click', 'powerpack' ),
					'on-hover' => esc_html__( 'Hover', 'powerpack' ),
					'none'     => esc_html__( 'None', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'show_preview',
			[
				'label'        => esc_html__( 'Preview Cart', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_title',
			[
				'label'       => esc_html__( 'Cart Title', 'powerpack' ),
				'description' => esc_html__( 'Cart title is displayed on top of mini cart.', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'PowerPack Mini Cart', 'powerpack' ),
				'separator'   => 'before',
				'condition'   => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_title_html_tag',
			[
				'label'       => esc_html__( 'Title HTML Tag', 'powerpack' ),
				'description' => esc_html__( 'The mini cart usually sits in a site header. Use div or span to keep the cart title out of the page heading outline.', 'powerpack' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'h3',
				'options'     => [
					'h1'   => esc_html__( 'H1', 'powerpack' ),
					'h2'   => esc_html__( 'H2', 'powerpack' ),
					'h3'   => esc_html__( 'H3', 'powerpack' ),
					'h4'   => esc_html__( 'H4', 'powerpack' ),
					'h5'   => esc_html__( 'H5', 'powerpack' ),
					'h6'   => esc_html__( 'H6', 'powerpack' ),
					'div'  => esc_html__( 'div', 'powerpack' ),
					'span' => esc_html__( 'span', 'powerpack' ),
					'p'    => esc_html__( 'p', 'powerpack' ),
				],
				'condition'   => [
					'show_cart_on!' => 'none',
					'cart_title!'   => '',
				],
			]
		);

		$this->add_control(
			'cart_message',
			[
				'label'       => esc_html__( 'Cart Message', 'powerpack' ),
				'description' => esc_html__( 'Cart message is displayed on bottom of mini cart.', 'powerpack' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => esc_html__( '100% Secure Checkout!', 'powerpack' ),
				'condition'   => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'link',
			[
				'label'       => esc_html__( 'Link', 'powerpack' ),
				'type'        => Controls_Manager::URL,
				'dynamic'     => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder' => 'https://www.your-link.com',
				'default'     => [
					'url' => '#',
				],
				'condition'   => [
					'show_cart_on' => 'none',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab
	 */

	/**
	 * Register the Cart Button style controls.
	 *
	 * Typography, colours, icon and counter styling for the toggle.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_style_cart_button_controls() {

		$this->start_controls_section(
			'section_cart_button_style',
			[
				'label' => esc_html__( 'Cart Button', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'cart_button_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-mini-cart-container .pp-woo-cart-contents',
			]
		);

		$this->start_controls_tabs( 'tabs_cart_button' );

		$this->start_controls_tab(
			'tab_cart_button_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_button_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart-container .pp-woo-cart-contents' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'cart_button_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart-container .pp-woo-cart-contents' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'cart_button_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-mini-cart-container .pp-woo-cart-contents',
			]
		);

		$this->add_control(
			'cart_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart-container .pp-woo-cart-contents' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'cart_button_margin',
			[
				'label'      => esc_html__( 'Margin', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart-container .pp-woo-cart-contents' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'cart_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart-container .pp-woo-cart-contents' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_cart_button_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_button_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart-container .pp-woo-cart-contents:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'cart_button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart-container .pp-woo-cart-contents:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'cart_button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart-container .pp-woo-cart-contents:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			'cart_button_icon_heading',
			[
				'label'     => esc_html__( 'Button Icon', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'icon_style' => [ 'icon_text', 'icon' ],
				],
			]
		);

		$this->add_responsive_control(
			'cart_button_icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 40,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart-button .pp-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'icon_style' => [ 'icon_text', 'icon' ],
					'icon_type'  => 'icon',
				],
			]
		);

		$this->add_responsive_control(
			'cart_button_icon_img_size',
			[
				'label'      => esc_html__( 'Icon Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart-button .pp-cart-contents-icon-image img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'icon_style' => [ 'icon_text', 'icon' ],
					'icon_type'  => 'image',
				],
			]
		);

		$this->add_responsive_control(
			'cart_button_icon_spacing',
			[
				'label'      => esc_html__( 'Icon Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 40,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart-button .pp-icon' => 'margin-inline-start: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'icon_style' => [ 'icon_text', 'icon' ],
				],
			]
		);

		$this->start_controls_tabs( 'tabs_cart_button_icon' );

		$this->start_controls_tab(
			'tab_cart_button_icon_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_button_icon_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart-button .pp-icon' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-woo-cart-button .pp-icon svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'icon_style' => [ 'icon_text', 'icon' ],
					'icon_type'  => 'icon',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_cart_button_icon_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_button_icon_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart-button:hover .pp-icon' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-woo-cart-button:hover .pp-icon svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'icon_style' => [ 'icon_text', 'icon' ],
					'icon_type'  => 'icon',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'cart_button_counter_heading',
			[
				'label'     => esc_html__( 'Counter', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'counter_position!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_button_counter_gap',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'unit' => 'px',
				],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 20,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-menu-cart-counter-after .pp-cart-contents-count-after' => 'margin-inline-start: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'counter_position' => 'after',
				],
			]
		);

		$this->add_control(
			'cart_button_counter_distance',
			[
				'label'      => esc_html__( 'Distance', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'unit' => 'em',
				],
				'range'      => [
					'em' => [
						'min'  => 0,
						'max'  => 4,
						'step' => 0.1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-cart-counter' => 'inset-inline-end: -{{SIZE}}{{UNIT}}; top: -{{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'counter_position' => 'top',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_cart_counter' );

		$this->start_controls_tab(
			'tab_cart_counter_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_button_counter_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-cart-counter' => 'color: {{VALUE}}',
				],
				'condition' => [
					'counter_position!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_button_counter_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-cart-counter' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .pp-woo-menu-cart-counter-after .pp-cart-counter:before' => 'border-right-color: {{VALUE}}',
				],
				'condition' => [
					'counter_position!' => 'none',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_cart_counter_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_button_counter_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart-button:hover .pp-cart-counter' => 'color: {{VALUE}}',
				],
				'condition' => [
					'counter_position!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_button_counter_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart-button:hover .pp-cart-counter' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .pp-woo-cart-button:hover .pp-woo-menu-cart-counter-after .pp-cart-counter:before' => 'border-right-color: {{VALUE}}',
				],
				'condition' => [
					'counter_position!' => 'none',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register the Items Container style controls.
	 *
	 * The cart panel itself: background, border, title, subtotal and messages.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_style_items_container_controls() {
		$this->start_controls_section(
			'section_items_container_style',
			[
				'label'     => esc_html__( 'Items Container', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'items_container_background',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pp-woo-mini-cart',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'items_container_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-mini-cart',
				'condition'   => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'items_container_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'items_container_width',
			[
				'label'      => esc_html__( 'Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 150,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart-wrap' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'items_container_margin_top',
			[
				'label'      => esc_html__( 'Margin Top', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'items_container_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default'    => [
					'top'      => '10',
					'right'    => '10',
					'bottom'   => '10',
					'left'     => '10',
					'unit'     => 'px',
					'isLinked' => true,
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'items_container_box_shadow',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .pp-woo-mini-cart',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_title_heading',
			[
				'label'     => esc_html__( 'Cart Title', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_cart_on!' => 'none',
					'cart_title!'   => '',
				],
			]
		);

		$this->add_control(
			'cart_title_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .pp-woo-mini-cart-title' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
					'cart_title!'   => '',
				],
			]
		);

		$this->add_control(
			'cart_title_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .pp-woo-mini-cart-title' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
					'cart_title!'   => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'cart_title_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-woo-mini-cart .pp-woo-mini-cart-title',
				'condition' => [
					'show_cart_on!' => 'none',
					'cart_title!'   => '',
				],
			]
		);

		$this->add_responsive_control(
			'cart_title_text_align',
			[
				'label'     => esc_html__( 'Alignment', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .pp-woo-mini-cart-title'   => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
					'cart_title!'   => '',
				],
			]
		);

		$this->add_responsive_control(
			'cart_title_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart .pp-woo-mini-cart-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
					'cart_title!'   => '',
				],
			]
		);

		$this->add_control(
			'subtotal_heading',
			[
				'label'     => esc_html__( 'Subtotal', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'subtotal_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .woocommerce-mini-cart__total' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'subtotal_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .woocommerce-mini-cart__total' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'subtotal_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-mini-cart .woocommerce-mini-cart__total',
				'condition'   => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'subtotal_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-woo-mini-cart .woocommerce-mini-cart__total',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'subtotal_text_align',
			[
				'label'     => esc_html__( 'Alignment', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .woocommerce-mini-cart__total'   => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'subtotal_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart .woocommerce-mini-cart__total' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_message_heading',
			[
				'label'     => esc_html__( 'Cart Message', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_cart_on!' => 'none',
					'cart_message!' => '',
				],
			]
		);

		$this->add_control(
			'cart_message_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .pp-woo-mini-cart-message' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
					'cart_message!' => '',
				],
			]
		);

		$this->add_control(
			'cart_message_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .pp-woo-mini-cart-message' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
					'cart_message!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'cart_message_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-woo-mini-cart .pp-woo-mini-cart-message',
				'condition' => [
					'show_cart_on!' => 'none',
					'cart_message!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'cart_message_text_align',
			[
				'label'     => esc_html__( 'Alignment', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .pp-woo-mini-cart-message'   => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
					'cart_message!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'cart_message_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [
					'top'      => '10',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart .pp-woo-mini-cart-message' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
					'cart_message!' => '',
				],
			]
		);

		$this->add_control(
			'empty_cart_message_heading',
			[
				'label'     => esc_html__( 'Empty Cart Message', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'empty_cart_message_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .woocommerce-mini-cart__empty-message' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'empty_cart_message_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-woo-mini-cart .woocommerce-mini-cart__empty-message',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'empty_cart_message_text_align',
			[
				'label'     => esc_html__( 'Alignment', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .woocommerce-mini-cart__empty-message'   => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Item style controls.
	 *
	 * Each product row inside the cart panel.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_style_items_controls() {
		$this->start_controls_section(
			'section_items_style',
			[
				'label'     => esc_html__( 'Item', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_row_separator_type',
			[
				'label'     => esc_html__( 'Separator Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'solid',
				'options'   => [
					'none'   => esc_html__( 'None', 'powerpack' ),
					'solid'  => esc_html__( 'Solid', 'powerpack' ),
					'dotted' => esc_html__( 'Dotted', 'powerpack' ),
					'dashed' => esc_html__( 'Dashed', 'powerpack' ),
					'double' => esc_html__( 'Double', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart ul.product_list_widget li:not(:last-child)' => 'border-bottom-style: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_row_separator_color',
			[
				'label'     => esc_html__( 'Separator Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart ul.product_list_widget li:not(:last-child)' => 'border-bottom-color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!'                  => 'none',
					'cart_items_row_separator_type!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'cart_items_row_separator_size',
			[
				'label'      => esc_html__( 'Separator Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart ul.product_list_widget li:not(:last-child)' => 'border-bottom-width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!'                  => 'none',
					'cart_items_row_separator_type!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'cart_items_spacing',
			[
				'label'      => esc_html__( 'Items Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart ul.product_list_widget li' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'cart_items_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart ul.product_list_widget li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->start_controls_tabs( 'cart_items_rows_tabs_style' );

		$this->start_controls_tab(
			'cart_items_even_row',
			[
				'label'     => esc_html__( 'Even Row', 'powerpack' ),
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_even_row_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .mini_cart_item:nth-child(2n)' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_even_row_links_color',
			[
				'label'     => esc_html__( 'Links Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .mini_cart_item:nth-child(2n) a' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_even_row_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .mini_cart_item:nth-child(2n)' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'cart_items_odd_row',
			[
				'label'     => esc_html__( 'Odd Row', 'powerpack' ),
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_odd_row_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .mini_cart_item:nth-child(2n+1)' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_odd_row_links_color',
			[
				'label'     => esc_html__( 'Links Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .mini_cart_item:nth-child(2n+1) a' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_odd_row_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .mini_cart_item:nth-child(2n+1)' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'item_name_heading',
			[
				'label'     => esc_html__( 'Item Name', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'item_name_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-woo-mini-cart .mini_cart_item a:not(.remove)',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'item_name_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .mini_cart_item a:not(.remove)' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'item_name_bottom_spacing',
			[
				'label'      => esc_html__( 'Bottom Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart .mini_cart_item a:not(.remove)' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_image_heading',
			[
				'label'     => esc_html__( 'Image', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'cart_items_image_position',
			[
				'label'                => esc_html__( 'Position', 'powerpack' ),
				'type'                 => Controls_Manager::CHOOSE,
				'label_block'          => false,
				'options'              => [
					'left'  => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-h-align-left',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'              => 'left',
				// Map the saved left/right values onto logical keywords so the float
				// follows the text direction instead of fighting the RTL stylesheet.
				'selectors_dictionary' => [
					'left'  => 'inline-start',
					'right' => 'inline-end',
				],
				'selectors'            => [
					'{{WRAPPER}} .pp-woo-mini-cart ul li.woocommerce-mini-cart-item a img' => 'float: {{VALUE}};',
				],
				'condition'            => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'cart_items_image_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart ul li.woocommerce-mini-cart-item a img' => 'margin-inline-end: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'cart_items_image_width',
			[
				'label'      => esc_html__( 'Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 10,
						'max' => 250,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart ul li.woocommerce-mini-cart-item a img' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_price_heading',
			[
				'label'     => esc_html__( 'Item Quantity & Price', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'cart_items_price_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-woo-mini-cart .cart_list .quantity',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_price_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .cart_list .quantity' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_heading',
			[
				'label'     => esc_html__( 'Remove Item Icon', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'cart_items_remove_icon_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart ul.cart_list li a.remove' => 'font-size: {{SIZE}}{{UNIT}}; width: calc({{SIZE}}{{UNIT}} + 6px); height: calc({{SIZE}}{{UNIT}} + 6px);',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_cart_items_remove_icon_style' );

		$this->start_controls_tab(
			'tab_cart_items_remove_icon_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart ul.cart_list li a.remove' => 'color: {{VALUE}} !important;',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart ul.cart_list li a.remove' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart ul.cart_list li a.remove' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_cart_items_remove_icon_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart ul.cart_list li a.remove:hover' => 'color: {{VALUE}} !important;',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart ul.cart_list li a.remove:hover' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart ul.cart_list li a.remove:hover' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register the Buttons style controls.
	 *
	 * The View Cart and Checkout buttons inside the cart panel.
	 *
	 * @since 1.4.4
	 * @access protected
	 */
	protected function register_style_buttons_controls() {

		$this->start_controls_section(
			'section_buttons_style',
			[
				'label'     => esc_html__( 'Buttons', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'buttons_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-woo-mini-cart .buttons .button',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'buttons_layout',
			[
				'label'        => esc_html__( 'Layout', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'inline',
				'options'      => [
					'inline'  => esc_html__( 'Inline', 'powerpack' ),
					'stacked' => esc_html__( 'Stacked', 'powerpack' ),
				],
				'prefix_class' => 'pp-woo-cart-buttons-',
				'condition'    => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'buttons_align',
			[
				'label'     => esc_html__( 'Alignment', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}}.pp-woo-cart-buttons-inline .buttons'   => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'show_cart_on!'  => 'none',
					'buttons_layout' => 'inline',
				],
			]
		);

		$this->add_responsive_control(
			'buttons_gap',
			[
				'label'      => esc_html__( 'Space Between', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}.pp-woo-cart-buttons-inline .buttons .button.checkout.checkout' => 'margin-inline-start: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}.pp-woo-cart-buttons-stacked .buttons .button.checkout.checkout' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'buttons_margin_top',
			[
				'label'      => esc_html__( 'Margin Top', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart-items .buttons' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'buttons_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart .buttons .button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'view_cart_button_heading',
			[
				'label'     => esc_html__( 'View Cart Button', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_view_cart_button_style' );

		$this->start_controls_tab(
			'tab_view_cart_button_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'view_cart_button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .buttons .button:not(.checkout)' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'view_cart_button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .buttons .button:not(.checkout)' => 'color: {{VALUE}}',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'view_cart_button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-mini-cart .buttons .button:not(.checkout)',
				'condition'   => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'view_cart_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart .buttons .button:not(.checkout)' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'view_cart_button_box_shadow',
				'selector'  => '{{WRAPPER}} .pp-woo-mini-cart .buttons .button:not(.checkout)',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_view_cart_button_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'view_cart_button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .buttons .button:not(.checkout):hover' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'view_cart_button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .buttons .button:not(.checkout):hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'view_cart_button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .buttons .button:not(.checkout):hover' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'view_cart_button_box_shadow_hover',
				'selector'  => '{{WRAPPER}} .pp-woo-mini-cart .buttons .button:not(.checkout):hover',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			'checkout_button_heading',
			[
				'label'     => esc_html__( 'Checkout Button', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_checkout_button_style' );

		$this->start_controls_tab(
			'tab_checkout_button_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'checkout_button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .buttons .button.checkout' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'checkout_button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .buttons .button.checkout' => 'color: {{VALUE}}',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'checkout_button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-mini-cart .buttons .button.checkout',
				'condition'   => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'checkout_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-mini-cart .buttons .button.checkout' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'checkout_button_box_shadow',
				'selector'  => '{{WRAPPER}} .pp-woo-mini-cart .buttons .button.checkout',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_checkout_button_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'checkout_button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .buttons .button.checkout:hover' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'checkout_button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .buttons .button.checkout:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_control(
			'checkout_button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-mini-cart .buttons .button.checkout:hover' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'checkout_button_box_shadow_hover',
				'selector'  => '{{WRAPPER}} .pp-woo-mini-cart .buttons .button.checkout:hover',
				'condition' => [
					'show_cart_on!' => 'none',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Render the cart items counter.
	 *
	 * @access protected
	 */
	protected function render_counter() {
		?>
		<span class="pp-cart-counter"><?php echo esc_html( WC()->cart->get_cart_contents_count() ); ?></span>
		<?php
	}

	/**
	 * Render the cart counter inside its live region.
	 *
	 * The wrapper is the live region rather than the counter itself. WooCommerce
	 * replaces .pp-cart-counter wholesale through cart fragments, and a live region
	 * that is inserted at the same moment as its content does not get announced.
	 * The wrapper survives the fragment swap, so the new count is.
	 *
	 * @since 3.0.0
	 * @access protected
	 *
	 * @param string $wrap_class Wrapper class for this counter position.
	 */
	protected function render_counter_wrap( $wrap_class ) {
		?>
		<span class="<?php echo esc_attr( $wrap_class ); ?>" aria-live="polite" aria-atomic="true">
			<?php $this->render_counter(); ?>
			<span class="elementor-screen-only"><?php esc_html_e( 'items in cart', 'powerpack' ); ?></span>
		</span>
		<?php
	}

	/**
	 * Render the cart button icon.
	 *
	 * @access protected
	 *
	 * @param array $settings Widget settings, resolved for display so dynamic tags are parsed.
	 */
	protected function render_cart_icon( $settings ) {
		if ( 'icon' === $settings['icon_type'] ) {
			?>
			<span class="pp-mini-cart-button-icon pp-icon">
				<?php
					\Elementor\Icons_Manager::render_icon(
						$settings['icon'],
						[
							'class'       => 'pp-cart-contents-icon',
							'aria-hidden' => 'true',
						]
					);
				?>
			</span>
			<?php
		} elseif ( 'image' === $settings['icon_type'] && $settings['icon_image']['url'] ) {
			?>
			<span class="pp-cart-contents-icon-image pp-icon">
				<?php
					echo wp_kses_post( Group_Control_Image_Size::get_attachment_image_html( $settings, 'icon_image', 'icon_image' ) );
				?>
			</span>
			<?php
		}
	}

	/**
	 * Render the cart button text.
	 *
	 * @access protected
	 *
	 * @param array $settings Widget settings, resolved for display so dynamic tags are parsed.
	 */
	protected function render_text( $settings ) {
		?>
		<span class="pp-cart-contents-text"><?php echo wp_kses_post( $settings['cart_text'] ); ?></span>
		<?php
	}

	/**
	 * Render the cart subtotal.
	 *
	 * @access protected
	 *
	 * @param array $settings Widget settings, resolved for display so dynamic tags are parsed.
	 */
	protected function render_subtotal( $settings ) {
		$sub_total = WC()->cart->get_cart_subtotal();

		if ( 'yes' === $settings['show_subtotal'] ) {
			?>
			<span class="pp-cart-subtotal"><?php echo wp_kses_post( $sub_total ); ?></span>
			<?php
		}
	}

	/**
	 * Render output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		if ( null === WC()->cart ) {
			return;
		}

		$settings  = $this->get_settings_for_display();
		$is_editor = \Elementor\Plugin::instance()->editor->is_edit_mode();

		$this->add_render_attribute( 'container', [
			'class' => [
				'pp-woocommerce',
				'pp-woo-mini-cart-container',
				'pp-woo-menu-cart-counter-' . $settings['counter_position'],
			],
			'data-target' => $settings['show_cart_on'],
		] );

		// The toggle is a link only when it navigates somewhere. When it opens the
		// cart panel it is a real button, so it carries the disclosure state and
		// can be reached and fired from the keyboard.
		$is_toggle   = ( 'none' !== $settings['show_cart_on'] );
		$button_tag  = $is_toggle ? 'button' : 'a';
		$mini_cart_id = 'pp-woo-mini-cart-' . $this->get_id();

		$this->add_render_attribute( 'button', [
			'class' => [
				'pp-woo-cart-contents',
				'pp-woo-cart-' . $settings['icon_style'],
			],
			'title' => esc_attr__( 'View your shopping cart', 'powerpack' ),
		] );

		$this->add_render_attribute( 'cart-button', 'class', 'pp-woo-cart-button' );

		if ( 'floating' === $settings['button_position'] ) {
			$this->add_render_attribute( 'cart-button', 'class', 'pp-floating-element' );
		}

		if ( $is_editor && 'yes' === $settings['show_preview'] ) {
			$this->add_render_attribute( 'container', 'class', 'pp-woo-mini-cart-preview' );
		}

		if ( $is_toggle ) {
			$this->add_render_attribute( 'button', [
				'type'          => 'button',
				'aria-expanded' => 'false',
				'aria-controls' => $mini_cart_id,
			] );

			$this->add_render_attribute( 'mini-cart', [
				'id'    => $mini_cart_id,
				'class' => [ 'pp-woo-mini-cart-wrap', 'pp-v-hidden' ],
			] );
		} elseif ( ! empty( $settings['link']['url'] ) ) {
			$this->add_link_attributes( 'button', $settings['link'] );
		}
		?>
		<?php
		/**
		 * Fires before the Woo - Mini Cart wrapper markup.
		 *
		 * @since 1.4.4
		 */
		do_action( 'pp_woo_before_mini_cart_wrap' );
		?>

		<div <?php $this->print_render_attribute_string( 'container' ); ?>>
			<?php
			if ( 'floating' === $settings['button_position'] ) {
				/* translators: %1$s: Widget title. */
				$placeholder = sprintf( esc_html__( 'Mini Cart button is floating. Click here to edit the "%1$s" settings. This placeholder will not be shown on the live page.', 'powerpack' ), esc_html( $this->get_title() ) );

				$this->render_editor_placeholder(
					[
						'body' => $placeholder,
					]
				);
			}
			?>

			<div <?php $this->print_render_attribute_string( 'cart-button' ); ?>>
				<div class="pp-woo-cart-button-inner">
					<<?php echo esc_html( $button_tag ); ?> <?php $this->print_render_attribute_string( 'button' ); ?>>
						<?php
						// Names the control for assistive tech. Kept outside
						// .pp-cart-button-wrap: the stylesheet puts a gap between
						// adjacent spans in there, so an extra child would shift the
						// visible layout.
						?>
						<span class="elementor-screen-only"><?php esc_html_e( 'View your shopping cart', 'powerpack' ); ?></span>

						<span class="pp-cart-button-wrap">
							<?php
							if ( 'icon' === $settings['icon_style'] ) {

								$this->render_subtotal( $settings );
								$this->render_cart_icon( $settings );

							} elseif ( 'icon_text' === $settings['icon_style'] ) {

								$this->render_text( $settings );
								$this->render_subtotal( $settings );
								$this->render_cart_icon( $settings );

							} else {

								$this->render_text( $settings );
								$this->render_subtotal( $settings );

							}
							?>
						</span>

						<?php if ( 'top' === $settings['counter_position'] ) { ?>
							<?php $this->render_counter_wrap( 'pp-cart-contents-count' ); ?>
						<?php } ?>
					</<?php echo esc_html( $button_tag ); ?>>

					<?php if ( 'after' === $settings['counter_position'] ) { ?>
						<?php $this->render_counter_wrap( 'pp-cart-contents-count-after' ); ?>
					<?php } ?>
				</div>
			</div>

			<?php if ( $is_toggle ) { ?>
				<div <?php $this->print_render_attribute_string( 'mini-cart' ); ?>>
					<div class="pp-woo-mini-cart pp-woo-menu-cart">
						<?php
						if ( $settings['cart_title'] ) {
							$title_tag = PP_Helper::validate_html_tag( $settings['cart_title_html_tag'] );
							?>
							<<?php echo esc_html( $title_tag ); ?> class="pp-woo-mini-cart-title">
								<?php echo wp_kses_post( $settings['cart_title'] ); ?>
							</<?php echo esc_html( $title_tag ); ?>>
						<?php } ?>

						<div class="pp-woo-mini-cart-items">
							<div class="widget_shopping_cart_content"><?php woocommerce_mini_cart(); ?></div>
						</div>

						<?php if ( $settings['cart_message'] ) { ?>
							<div class="pp-woo-mini-cart-message">
								<?php echo wp_kses_post( $this->parse_text_editor( $settings['cart_message'] ) ); ?>
							</div>
						<?php } ?>
					</div>
				</div>
			<?php } ?>
		</div>

		<?php
		/**
		 * Fires after the Woo - Mini Cart wrapper markup.
		 *
		 * @since 1.4.4
		 */
		do_action( 'pp_woo_after_mini_cart_wrap' );
	}
}
