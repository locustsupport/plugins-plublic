<?php
/**
 * PowerPack WooCommerce Products - Template.
 *
 * @package PowerPack
 */

use PowerpackElements\Classes\PP_Woo_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

global $product;

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}

$post_id = $product->get_id();

$sale_badge_position = $settings['sale_badge_position'];
$featured_badge_position = $settings['featured_badge_position'];
$top_rating_badge_position = $settings['top_rating_badge_position'];
$best_selling_badge_position = $settings['best_selling_badge_position'];
$quick_view_type = $settings['quick_view_type'];
$quick_view_text = $settings['quick_view_text'];
if ( '' === $quick_view_text ) {
	$quick_view_text = esc_html__( 'Quick View', 'powerpack' );
}
$add_to_wishlist_text = esc_html__( 'Add to Wishlist', 'powerpack' );
$image_size = $settings['thumbnail_size'];
if ( 'custom' === $image_size ) {
	$image_size = [];
	$custom_image_size = $settings['thumbnail_custom_dimension'];
	$image_size[0] = $custom_image_size['width'];
	$image_size[1] = $custom_image_size['height'];
}
if ( ! $image_size ) {
	$image_size = 'woocommerce_thumbnail';
}

$out_of_stock        = ! $product->is_in_stock();
$out_of_stock_string = apply_filters( 'pp_woo_out_of_stock_string', ( $settings['out_of_stock_text'] ? $settings['out_of_stock_text'] : esc_html__( 'Out of Stock', 'powerpack' ) ) );

$carousel_swiper_class = '';
if ( 'slider' === $settings['products_layout_type'] ) {
	$carousel_swiper_class = 'swiper-slide';
}
?>
<li <?php post_class( $carousel_swiper_class ); ?>>
	<div class="pp-woo-product-wrapper">
		<?php
		echo '<div class="pp-woo-products-thumbnail-wrap">';

		if ( $sale_badge_position || $featured_badge_position || $top_rating_badge_position || $best_selling_badge_position ) {


			if ( 'left' === $sale_badge_position || 'left' === $featured_badge_position || 'left' === $top_rating_badge_position || 'left' === $best_selling_badge_position ) {
				echo '<div class="pp-badge-container pp-left-badge-container">';
				include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/loop/left-badge.php';
				echo '</div>';
			}

			if ( 'right' === $sale_badge_position || 'right' === $featured_badge_position || 'right' === $top_rating_badge_position || 'right' === $best_selling_badge_position ) {
				echo '<div class="pp-badge-container pp-right-badge-container">';
				include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/loop/right-badge.php';
				echo '</div>';
			}
		}

		if ( 'yes' === $settings['link_image'] ) {
			if ( 'yes' === $settings['link_image_target'] ) {
				echo '<a href="' . esc_url( get_the_permalink() ) . '" target="_blank" rel="noopener" class="woocommerce-LoopProduct-link">';
			} else {
				woocommerce_template_loop_product_link_open();
			}
		}

		// WooCommerce returns escaped markup; wp_kses_post() would strip srcset/sizes.
		echo woocommerce_get_product_thumbnail( $image_size ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( 'swap' === $settings['products_hover_style'] ) {
			PP_Woo_Helper::get_instance()->woo_shop_product_flip_image( $image_size );
		}

		if ( 'yes' === $settings['link_image'] ) {
			woocommerce_template_loop_product_link_close();
		}

		/* Out of stock */
		if ( $out_of_stock ) {
			echo '<span class="pp-out-of-stock">' . esc_html( $out_of_stock_string ) . '</span>';
		}


		/* Product Actions */
		$has_actions = ( '' !== $quick_view_type )
			|| ( 'yes' === $settings['show_add_cart'] )
			|| ( class_exists( 'YITH_WCWL' ) && 'yes' === $settings['show_add_to_wishlist'] );

		if ( $has_actions ) {
			echo '<div class="pp-product-actions">';
		}
		if ( '' !== $quick_view_type ) {

			echo '<button type="button" class="pp-action-item-wrap pp-quick-view-btn" data-product_id="' . esc_attr( $post_id ) . '">';

				echo '<span class="pp-action-item pp-icon">';
				self::render_product_icon( 'eye' );
				echo '</span>';
				echo '<span class="pp-action-tooltip">' . wp_kses_post( $quick_view_text ) . '</span>';
			echo '</button>';
		}

		if ( 'yes' === $settings['show_add_cart'] ) {

			$cart_class = $product->is_purchasable() && $product->is_in_stock() ? 'pp-add-to-cart-btn' : '';

			if ( $product->is_type( 'variable' ) ) {
				$product_atc_url = $product->get_permalink();

				$ajax_atc_class       = '';
				$ajax_atc_icon_class  = '';
			} else {
				$product_atc_url = $product->add_to_cart_url();

				$ajax_atc_class       = ' ajax_add_to_cart add_to_cart_button ';
				$ajax_atc_icon_class  = ' pp-ajax-add-cart-icon ';
			}

			echo '<a href="' . esc_url( $product_atc_url ) . '" class="pp-action-item-wrap pp-cart-section ' . esc_attr( $ajax_atc_class ) . esc_attr( $cart_class ) . ' product_type_' . esc_attr( $product->get_type() ) . '" data-quantity="1" data-product_id="' . esc_attr( $post_id ) . '">';
				echo '<span class="pp-action-item ' . esc_attr( $ajax_atc_icon_class ) . ' pp-icon">';
				self::render_product_icon( 'shopping-cart' );
				echo '</span>';
				echo '<span class="pp-action-tooltip">' . wp_kses_post( $product->add_to_cart_text() ) . '</span>';
			echo '</a>';
		}

		if ( class_exists( 'YITH_WCWL' ) && 'yes' === $settings['show_add_to_wishlist'] ) {
			echo '<div class="pp-action-item-wrap pp-add-to-wishlist-btn">';
			echo do_shortcode( '[yith_wcwl_add_to_wishlist label="" link_classes="pp-action-item" already_in_wishslist_text="" product_added_text="" browse_wishlist_text=""]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '<span class="pp-action-tooltip">' . wp_kses_post( $add_to_wishlist_text ) . '</span>';
			echo '</div>';
		}

		if ( $has_actions ) {
			echo '</div>';
		}

		echo '</div>';

		$shop_structure = [];

		if ( 'yes' === $settings['show_category'] ) {

			$shop_structure[] = 'category';
		}
		if ( 'yes' === $settings['show_title'] ) {

			$shop_structure[] = 'title';
		}
		if ( 'yes' === $settings['show_ratings'] ) {

			$shop_structure[] = 'ratings';
		}
		if ( 'yes' === $settings['show_price'] ) {

			$shop_structure[] = 'price';
		}
		if ( 'yes' === $settings['show_short_desc'] ) {

			$shop_structure[] = 'short_desc';
		}

		$shop_structure = apply_filters(
			'pp_woo_products_content_structure',
			$shop_structure
		);

		if ( is_array( $shop_structure ) && ! empty( $shop_structure ) ) {

			do_action( 'pp_woo_products_before_summary_wrap', $post_id, $settings );
			echo '<div class="pp-woo-products-summary-wrap">';
			do_action( 'pp_woo_products_summary_wrap_top', $post_id, $settings );

			include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/loop/summary-structure.php';

			do_action( 'pp_woo_products_summary_wrap_bottom', $post_id, $settings );
			echo '</div>';
			do_action( 'pp_woo_products_after_summary_wrap', $post_id, $settings );
		}
		?>
	</div>
</li>
