<?php
/**
 * PowerPack WooCommerce Category Tile - Template.
 *
 * Renders a single tile. The tile groups around it are opened and closed by
 * Woo_Categories::render_tiles(), so this template never emits an unbalanced
 * wrapper of its own.
 *
 * @var object $category Category object.
 * @var int    $i        1 based index of the tile in the whole list.
 *
 * @package PowerPack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div <?php wc_product_cat_class( 'product pp-woo-cat-' . $i, $category ); ?>>
	<div class="pp-grid-item">
	<?php
	/**
	 * Link Open
	 * woocommerce_before_subcategory hook.
	 *
	 * @hooked woocommerce_template_loop_category_link_open - 10
	 */
	do_action( 'woocommerce_before_subcategory', $category );

	/**
	 * Subcategory Thumbnail
	 * woocommerce_before_subcategory_title hook.
	 *
	 * @hooked woocommerce_subcategory_thumbnail - 10
	 */
	do_action( 'woocommerce_before_subcategory_title', $category );

	/**
	 * Subcategory Title
	 * woocommerce_shop_loop_subcategory_title hook.
	 *
	 * @hooked woocommerce_template_loop_category_title - 10
	 */
	do_action( 'woocommerce_shop_loop_subcategory_title', $category );

	/**
	 * After Subcategory Title
	 * woocommerce_after_subcategory_title hook.
	 */
	do_action( 'woocommerce_after_subcategory_title', $category );

	/**
	 * Link Close
	 * woocommerce_after_subcategory hook.
	 *
	 * @hooked woocommerce_template_loop_category_link_close - 10
	 */
	do_action( 'woocommerce_after_subcategory', $category );
	?>
	</div>
</div>
