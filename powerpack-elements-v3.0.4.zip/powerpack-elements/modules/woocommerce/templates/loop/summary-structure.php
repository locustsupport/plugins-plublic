<?php
/**
 * PowerPack WooCommerce Products - Product Summary.
 *
 * Renders the pieces listed in $shop_structure. Shared by every Woo - Products
 * skin, which is why it carries the union of the cases: a skin simply leaves the
 * entries it does not want out of $shop_structure.
 *
 * Expects $shop_structure, $settings and $post_id to be in scope, plus the
 * global $product that the WooCommerce template functions read.
 *
 * Each entry fires a matching pair of actions so developers can inject markup
 * around it. Every one of them receives the same two arguments:
 *
 *     do_action( 'pp_woo_products_{entry}_before', int $post_id, array $settings );
 *     do_action( 'pp_woo_products_{entry}_after',  int $post_id, array $settings );
 *
 * where {entry} is one of: title, price, rating, short_description,
 * wishlist, add_to_cart, category.
 *
 * @since 3.0.0 The pairs moved here from the five per-skin templates.
 *
 * @package PowerPack
 */

use PowerpackElements\Classes\PP_Woo_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

foreach ( $shop_structure as $value ) {

	switch ( $value ) {
		case 'title':
			/**
			 * Add Product Title on shop page for all products.
			 */
			do_action( 'pp_woo_products_title_before', $post_id, $settings );
			if ( 'yes' === $settings['link_title'] ) {

				/*
				 * Literal markup, not user data. esc_attr() used to be applied to
				 * the whole attribute pair, which entity-encoded the quotes: the
				 * browser then read the value as the string "_blank" rather than
				 * the _blank keyword, so the link opened a named window that kept
				 * a live window.opener instead of a properly isolated tab.
				 */
				$target = ( 'yes' === $settings['link_title_target'] ) ? ' target="_blank" rel="noopener"' : '';

				/**
				 * Filters the URL the product title links to.
				 *
				 * @since 1.3.3
				 *
				 * @param string $permalink Product permalink.
				 */
				$title_link = apply_filters( 'pp_woo_title_link', get_the_permalink() );

				echo '<a href="' . esc_url( $title_link ) . '"' . $target . ' class="pp-loop-product__link">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/loop/product-title.php';
				echo '</a>';
			} else {
				include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/loop/product-title.php';
			}
			do_action( 'pp_woo_products_title_after', $post_id, $settings );
			break;
		case 'price':
			/**
			 * Add Product Price on shop page for all products.
			 */
			do_action( 'pp_woo_products_price_before', $post_id, $settings );
			woocommerce_template_loop_price();
			do_action( 'pp_woo_products_price_after', $post_id, $settings );
			break;
		case 'ratings':
			/**
			 * Add rating on shop page for all products.
			 */
			do_action( 'pp_woo_products_rating_before', $post_id, $settings );
			woocommerce_template_loop_rating();
			do_action( 'pp_woo_products_rating_after', $post_id, $settings );
			break;
		case 'short_desc':
			do_action( 'pp_woo_products_short_description_before', $post_id, $settings );
			PP_Woo_Helper::get_instance()->woo_shop_short_desc();
			do_action( 'pp_woo_products_short_description_after', $post_id, $settings );
			break;
		case 'yith_wishlist':
			do_action( 'pp_woo_products_wishlist_before', $post_id, $settings );
			if ( 'icon' === $settings['add_to_wishlist_type'] ) {
				echo do_shortcode( '[yith_wcwl_add_to_wishlist label=""]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			} else {
				echo do_shortcode( '[yith_wcwl_add_to_wishlist]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			do_action( 'pp_woo_products_wishlist_after', $post_id, $settings );
			break;
		case 'add_cart':
			do_action( 'pp_woo_products_add_to_cart_before', $post_id, $settings );
			woocommerce_template_loop_add_to_cart();
			do_action( 'pp_woo_products_add_to_cart_after', $post_id, $settings );
			break;
		case 'category':
			/**
			 * Add and/or Remove Categories from shop archive page.
			 */
			do_action( 'pp_woo_products_category_before', $post_id, $settings );
			/**
			 * Filters whether every product category is listed.
			 *
			 * Defaults to false, which shows the top level category only.
			 *
			 * @since 2.9.11
			 *
			 * @param bool $all Whether to list all categories.
			 */
			$product_categories_all = apply_filters( 'pp_woo_products_all_categories', false );

			if ( $product_categories_all ) {
				PP_Woo_Helper::get_instance()->woo_shop_product_categories();
			} else {
				PP_Woo_Helper::get_instance()->woo_shop_parent_category();
			}
			do_action( 'pp_woo_products_category_after', $post_id, $settings );
			break;
		default:
			break;
	}
}
