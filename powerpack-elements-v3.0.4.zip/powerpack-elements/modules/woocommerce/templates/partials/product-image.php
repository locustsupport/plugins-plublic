<?php
/**
 * PowerPack WooCommerce Single Product - Image partial.
 *
 * @package PowerPack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Fires before the single product image wrapper.
 *
 * @since 2.7.0
 *
 * @param array       $settings Widget settings.
 * @param \WC_Product $product  Product being rendered.
 */
do_action( 'pp_single_product_before_image_wrap', $settings, $product );
?>

<div class="single-product-image">
	<?php if ( method_exists( $product, 'get_image' ) ) { ?>
		<?php
		/*
		 * No data-no-lazy: that attribute is the opt-out honoured by WP Rocket,
		 * Autoptimize and a3 Lazy Load, and it was forcing the product image to
		 * load eagerly on every site running one of them - including skins 3
		 * and 4, where the image sits below the title, rating and price and is
		 * usually the last thing on screen worth deferring.
		 */
		echo $product->get_image( $image_size, [ 'class' => 'pp-product-featured-image' ] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WooCommerce-generated markup.
		?>
	<?php } else { ?>
		<?php
		/*
		 * alt comes from the attachment, not the product title: the title is
		 * already announced by the heading next to it, and repeating it here
		 * - once in alt and again in a title attribute, as this used to do -
		 * makes screen readers say it three times over.
		 */
		echo wp_get_attachment_image(
			get_post_thumbnail_id( $product_id ),
			$image_size,
			false,
			[ 'class' => 'pp-product-featured-image' ]
		);
		?>
	<?php } ?>
	<?php if ( 'yes' === $settings['show_sale_badge'] && $product->is_on_sale() ) : ?>
		<?php
			$sale_badge = sprintf( '<span class="onsale">%s</span>', esc_html__( 'Sale!', 'powerpack' ) );
			echo apply_filters( 'woocommerce_sale_flash', $sale_badge, $post, $product ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WooCommerce filter, returns markup.
		?>
	<?php endif; ?>
</div>

<?php
/**
 * Fires after the single product image wrapper.
 *
 * @since 2.7.0
 *
 * @param array       $settings Widget settings.
 * @param \WC_Product $product  Product being rendered.
 */
do_action( 'pp_single_product_after_image_wrap', $settings, $product );
