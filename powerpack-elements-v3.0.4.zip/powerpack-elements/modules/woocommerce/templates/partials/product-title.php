<?php
/**
 * PowerPack WooCommerce Single Product - Title partial.
 *
 * @package PowerPack
 */

use PowerpackElements\Classes\PP_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/*
 * Elementor does not validate that a SELECT value is one of its declared
 * options - the value comes back from saved page JSON - so this reached the
 * tag position unchecked. Resolved once so the opening and closing tags
 * cannot diverge.
 */
$title_tag = PP_Helper::validate_html_tag( $settings['product_title_heading_tag'] );

/**
 * Fires before the single product title wrapper.
 *
 * @since 2.7.0
 *
 * @param array       $settings Widget settings.
 * @param \WC_Product $product  Product being rendered.
 */
do_action( 'pp_single_product_before_title_wrap', $settings, $product );
?>

<<?php echo esc_html( $title_tag ); ?> class="pp-product-title"><?php echo wp_kses_post( get_the_title( $product_id ) ); ?></<?php echo esc_html( $title_tag ); ?>>

<?php
/**
 * Fires after the single product title wrapper.
 *
 * @since 2.7.0
 *
 * @param array       $settings Widget settings.
 * @param \WC_Product $product  Product being rendered.
 */
do_action( 'pp_single_product_after_title_wrap', $settings, $product );
