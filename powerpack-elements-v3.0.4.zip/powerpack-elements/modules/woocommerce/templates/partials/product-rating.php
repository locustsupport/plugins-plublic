<?php
/**
 * PowerPack WooCommerce Single Product - Rating partial.
 *
 * @package PowerPack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$rating_count = $product->get_rating_count();
$review_count = $product->get_review_count();
$average      = $product->get_average_rating();

if ( $rating_count > 0 ) :

	/**
	 * Fires before the single product rating wrapper.
	 *
	 * @since 2.7.0
	 *
	 * @param array       $settings Widget settings.
	 * @param \WC_Product $product  Product being rendered.
	 */
	do_action( 'pp_single_product_before_rating_wrap', $settings, $product );
	?>

<div class="woocommerce-product-rating">
	<?php echo wc_get_rating_html( $average, $rating_count ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WooCommerce-generated markup. ?>
	<?php if ( comments_open( $product_id ) && 'yes' === $settings['product_rating_count'] ) : ?>
		<?php
		/*
		 * The reviews list lives on the product page, not in this widget, so a
		 * bare "#reviews" fragment points at nothing wherever the widget is
		 * placed - and collides when two copies sit on one page. Link to the
		 * product and let the fragment resolve there.
		 */
		$reviews_link = get_permalink( $product_id );
		$reviews_link = $reviews_link ? $reviews_link . '#reviews' : '#reviews';
		?>
		<a href="<?php echo esc_url( $reviews_link ); ?>" class="woocommerce-rating-count" rel="nofollow">
			<?php if ( ! empty( $settings['product_rating_text'] ) ) { ?>
			(<span class="count"><?php echo esc_html( $review_count ); ?></span> <?php echo wp_kses_post( $settings['product_rating_text'] ); ?>)
			<?php } else { ?>
			(<?php
				printf(
					/* translators: %s: number of customer reviews, wrapped in a span. */
					esc_html( _n( '%s customer review', '%s customer reviews', $review_count, 'powerpack' ) ),
					'<span class="count">' . esc_html( $review_count ) . '</span>'
				);
			?>)
			<?php } ?>
		</a>
	<?php endif; ?>
</div>

	<?php
	/**
	 * Fires after the single product rating wrapper.
	 *
	 * @since 2.7.0
	 *
	 * @param array       $settings Widget settings.
	 * @param \WC_Product $product  Product being rendered.
	 */
	do_action( 'pp_single_product_after_rating_wrap', $settings, $product );

endif;
