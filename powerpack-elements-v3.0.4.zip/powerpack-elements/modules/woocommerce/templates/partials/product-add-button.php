<?php
/**
 * PowerPack WooCommerce Single Product - Add to cart button partial.
 *
 * @package PowerPack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Fires before the single product button wrapper.
 *
 * @since 2.7.0
 *
 * @param array       $settings Widget settings.
 * @param \WC_Product $product  Product being rendered.
 */
do_action( 'pp_single_product_before_button_wrap', $settings, $product );
?>

<div class="pp-product-action woocommerce-product-add-to-cart">
	<?php woocommerce_template_single_add_to_cart(); ?>
</div>

<?php
/**
 * Fires after the single product button wrapper.
 *
 * @since 2.7.0
 *
 * @param array       $settings Widget settings.
 * @param \WC_Product $product  Product being rendered.
 */
do_action( 'pp_single_product_after_button_wrap', $settings, $product );
