<?php
/**
 * PowerPack WooCommerce Single Product - Price partial.
 *
 * @package PowerPack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Fires before the single product price wrapper.
 *
 * @since 2.7.0
 *
 * @param array       $settings Widget settings.
 * @param \WC_Product $product  Product being rendered.
 */
do_action( 'pp_single_product_before_price_wrap', $settings, $product );
?>

<p class="price"><?php echo $product->get_price_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WooCommerce-generated markup. ?></p>

<?php
/**
 * Fires after the single product price wrapper.
 *
 * @since 2.7.0
 *
 * @param array       $settings Widget settings.
 * @param \WC_Product $product  Product being rendered.
 */
do_action( 'pp_single_product_after_price_wrap', $settings, $product );
