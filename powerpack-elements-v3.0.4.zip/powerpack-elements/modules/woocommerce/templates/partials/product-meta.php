<?php
/**
 * PowerPack WooCommerce Single Product - Product meta partial.
 *
 * @package PowerPack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Fires before the single product meta wrapper.
 *
 * @since 2.7.0
 *
 * @param array       $settings Widget settings.
 * @param \WC_Product $product  Product being rendered.
 */
do_action( 'pp_single_product_before_meta_wrap', $settings, $product );
?>

<div class="product_meta">
	<?php do_action( 'woocommerce_product_meta_start' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WooCommerce hook. ?>

	<?php if ( 'yes' === $settings['show_sku'] && wc_product_sku_enabled() && ( $product->get_sku() || $product->is_type( 'variable' ) ) ) : ?>
		<?php $sku = $product->get_sku(); ?>
		<span class="sku_wrapper"><?php esc_html_e( 'SKU:', 'powerpack' ); ?> <span class="sku"><?php echo $sku ? esc_html( $sku ) : esc_html__( 'N/A', 'powerpack' ); ?></span></span>
	<?php endif; ?>

	<?php if ( 'yes' === $settings['show_taxonomy'] ) : ?>
		<span class="posted_in">
		<?php
			$product_tax = $settings['select_taxonomy'];
			$terms       = '';

			/*
			 * Both guards matter. wp_get_post_terms() returns a WP_Error for an
			 * unregistered or empty taxonomy, and WP_Error is an object, so the
			 * old ! empty() check passed, the foreach walked its properties and
			 * concatenating the result threw "Object of class WP_Error could not
			 * be converted to string" - a fatal, reachable by switching Show
			 * Taxonomy on without picking one.
			 */
			$product_terms = ( $product_tax && taxonomy_exists( $product_tax ) )
				? wp_get_post_terms( $product->get_id(), $product_tax, [ 'fields' => 'all' ] )
				: [];

			if ( is_wp_error( $product_terms ) ) {
				$product_terms = [];
			}

			if ( 'yes' === $settings['show_taxonomy_custom_text'] ) {
				echo wp_kses_post( $settings['taxonomy_custom_text'] );
			} else {
				$tax_label = '';

				if ( 'product_cat' === $product_tax ) {
					$tax_label = __( 'Category', 'powerpack' );
				} elseif ( 'product_tag' === $product_tax ) {
					$tax_label = __( 'Tags', 'powerpack' );
				} else {
					$tax_obj = get_taxonomy( $product_tax );

					if ( $tax_obj ) {
						$tax_label = $tax_obj->label;
					}
				}

				if ( '' !== $tax_label ) {
					printf(
						/* translators: %s: product taxonomy label, for example "Category". */
						esc_html__( '%s:', 'powerpack' ),
						esc_html( $tax_label )
					);
					echo ' ';
				}
			}

			if ( ! empty( $product_terms ) ) {
				foreach ( $product_terms as $term ) {
					$term_link = get_term_link( $term );

					// Same string-conversion fatal as above, one level down.
					if ( is_wp_error( $term_link ) ) {
						continue;
					}

					$terms .= '<a href="' . esc_url( $term_link ) . '">' . esc_html( $term->name ) . '</a>, ';
				}

				$terms = rtrim( $terms, ', ' );

				// Built from esc_url() and esc_html() pieces immediately above.
				echo $terms; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		?>
		</span>
	<?php endif; ?>

	<?php do_action( 'woocommerce_product_meta_end' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WooCommerce hook. ?>
</div>

<?php
/**
 * Fires after the single product meta wrapper.
 *
 * @since 2.7.0
 *
 * @param array       $settings Widget settings.
 * @param \WC_Product $product  Product being rendered.
 */
do_action( 'pp_single_product_after_meta_wrap', $settings, $product );
