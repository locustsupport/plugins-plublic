<?php
/**
 * PowerPack WooCommerce Single Product - Short description partial.
 *
 * @package PowerPack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Fires before the single product short description wrapper.
 *
 * @since 2.7.0
 *
 * @param array       $settings     Widget settings.
 * @param \WC_Product $product      Product being rendered.
 * @param array       $product_data Product data array.
 */
do_action( 'pp_single_product_before_desc_wrap', $settings, $product, $product_data );
?>

<div class="woocommerce-product-details__short-description">
	<?php echo apply_filters( 'woocommerce_short_description', $product_data['short_description'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WooCommerce filter, returns markup. ?>
</div>

<?php
/**
 * Fires after the single product short description wrapper.
 *
 * @since 2.7.0
 *
 * @param array       $settings     Widget settings.
 * @param \WC_Product $product      Product being rendered.
 * @param array       $product_data Product data array.
 */
do_action( 'pp_single_product_after_desc_wrap', $settings, $product, $product_data );
