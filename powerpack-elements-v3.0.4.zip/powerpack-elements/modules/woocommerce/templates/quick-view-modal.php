<?php
/**
 * WooCommerce - Quick View Modal
 *
 * @package PowerPack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="pp-quick-view-<?php echo esc_attr( $widget_id ); ?>">
	<div class="pp-quick-view-bg"><div class="pp-quick-view-loader"></div></div>
	<?php
	/*
	 * These used to be plain ids. Two Woo - Products widgets on one page each
	 * append their modal to the body, so the ids collided. Everything now hangs
	 * off classes, scoped by the .pp-quick-view-{id} wrapper above.
	 */
	?>
	<div class="pp-quick-view-modal" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr__( 'Product quick view', 'powerpack' ); ?>">
		<div class="pp-content-main-wrapper"><?php /*Don't remove this html comment*/ ?><!--
		--><div class="pp-content-main">
				<div class="pp-lightbox-content">
					<div class="pp-content-main-head">
						<button type="button" class="pp-quick-view-close-btn" aria-label="<?php echo esc_attr__( 'Close quick view', 'powerpack' ); ?>"></button>
					</div>
					<div class="pp-quick-view-content woocommerce single-product"></div>
				</div>
			</div>
		</div>
	</div>
</div>
