<?php
/**
 * PowerPack Elements WooCommerce Query.
 *
 * @package PowerPack Elements
 */

namespace PowerpackElements\Modules\QueryPost\Controls;

use Elementor\Base_Data_Control;
use PowerpackElements\Modules\QueryPost\Module;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Query.
 */
class Query extends Base_Data_Control {

	const CONTROL_ID = 'pp-query-posts';

	/**
	 * Get Control Type.
	 *
	 * @since 1.3.3
	 * @access public
	 *
	 * @return string Control type.
	 */
	public function get_type() {
		return self::CONTROL_ID;
	}

	/**
	 * Get Default Settings.
	 *
	 * @since 1.3.3
	 * @access public
	 *
	 * @return array Settings.
	 */
	protected function get_default_settings() {
		return [
			'label_block' => true,
			'multiple'    => false,
			'options'     => [],
			'post_type'   => 'all',
		];
	}

	/**
	 * Enqueue control scripts and styles.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function enqueue() {

		wp_register_script( 'pp-query-control', POWERPACK_ELEMENTS_URL . 'assets/js/query-post.js', [ 'jquery' ], POWERPACK_ELEMENTS_VER );
		wp_enqueue_script( 'pp-query-control' );
	}

	/**
	 * Control content template.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function content_template() {
		$control_uid = $this->get_control_uid();
		?>
		<div class="elementor-control-field">
			<label for="<?php echo $control_uid; ?>" class="elementor-control-title">{{{ data.label }}}</label>
			<div class="elementor-control-input-wrapper">
				<#
				var multiple = ( data.multiple ) ? 'multiple' : '',
					options  = data.options || {},
					value    = data.controlValue,
					selected = [];

				if ( _.isString( value ) || _.isNumber( value ) ) {
					selected = ( '' === value ) ? [] : [ String( value ) ];
				} else if ( ! _.isEmpty( value ) ) {
					selected = _.map( _.values( value ), String );
				}

				/*
				 * The options object is keyed by post ID, and JavaScript iterates integer-like
				 * keys in ascending numeric order, so printing the options as they come loses
				 * the order in which the items were picked. Print the selected items first, in
				 * the stored order, so select2 shows - and Elementor saves back - that order.
				 */
				var ordered = _.filter( selected, function( option_value ) {
					return ! _.isUndefined( options[ option_value ] );
				} );

				_.each( options, function( option_title, option_value ) {
					option_value = String( option_value );

					if ( -1 === _.indexOf( ordered, option_value ) ) {
						ordered.push( option_value );
					}
				} );
				#>
				<select id="<?php echo $control_uid; ?>" class="elementor-select2" type="select2" {{ multiple }} data-setting="{{ data.name }}">
					<# _.each( ordered, function( option_value ) {
						var option_selected = ( -1 !== _.indexOf( selected, option_value ) ) ? 'selected' : '';
						#>
					<option {{ option_selected }} value="{{ option_value }}">{{{ _.escape( options[ option_value ] ) }}}</option>
					<# } ); #>
				</select>
			</div>
		</div>
		<# if ( data.description ) { #>
			<div class="elementor-control-field-description">{{{ data.description }}}</div>
		<# } #>
		<?php
	}
}
