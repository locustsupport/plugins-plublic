<?php
namespace PowerpackElements\Modules\ModalPopup\Widgets;

use PowerpackElements\Base\Powerpack_Widget;
use PowerpackElements\Classes\PP_Helper;
use PowerpackElements\Classes\PP_Config;

// Elementor Classes
use Elementor\Control_Media;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Popup Box Widget
 */
class Modal_Popup extends Powerpack_Widget {

	/**
	 * Retrieve popup box widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Popup_Box' );
	}

	/**
	 * Retrieve popup box widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Popup_Box' );
	}

	/**
	 * Retrieve popup box widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Popup_Box' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 1.3.4
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Popup_Box' );
	}

	protected function is_dynamic_content(): bool {
		return false;
	}

	/**
	 * Retrieve the list of scripts the popup box widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [
			'pp-popup',
		];
	}

	/**
	 * Retrieve the list of scripts the popup box widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_style_depends() {
		return [
			'widget-pp-modal-popup',
		];
	}

	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register popup box widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function register_controls() {
		/* Content Tab */
		$this->register_content_content_controls();
		$this->register_content_layout_controls();
		$this->register_content_trigger_controls();
		$this->register_content_settings_controls();

		/* Style Tab */
		$this->register_style_popup_controls();
		$this->register_style_overlay_controls();
		$this->register_style_title_controls();
		$this->register_style_content_controls();
		$this->register_style_trigger_icon_controls();
		$this->register_style_trigger_button_controls();
		$this->register_style_close_button_controls();
	}

	/*-----------------------------------------------------------------------------------*/
	/*	CONTENT TAB
	/*-----------------------------------------------------------------------------------*/

	protected function register_content_content_controls() {
		/**
		 * Content Tab: Content
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Content', 'powerpack' ),
			)
		);

		$this->add_control(
			'preview_popup',
			array(
				'label'        => esc_html__( 'Preview Popup', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'popup_title',
			[
				'label'        => esc_html__( 'Show Title', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'title',
			array(
				'label'     => esc_html__( 'Title', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'dynamic'   => array(
					'active' => true,
				),
				'default'   => esc_html__( 'Modal Title', 'powerpack' ),
				'condition' => array(
					'popup_title' => 'yes',
				),
			)
		);

		$this->add_control(
			'popup_type',
			[
				'label'     => esc_html__( 'Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'image'       => esc_html__( 'Image', 'powerpack' ),
					'link'        => esc_html__( 'Embed (URL)', 'powerpack' ),
					'content'     => esc_html__( 'Content', 'powerpack' ),
					'template'    => esc_html__( 'Saved Templates', 'powerpack' ),
					'custom-html' => esc_html__( 'Custom HTML', 'powerpack' ),
				],
				'default'   => 'image',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'image',
			array(
				'label'     => esc_html__( 'Choose Image', 'powerpack' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => array(
					'active' => true,
				),
				'default'   => array(
					'url' => Utils::get_placeholder_image_src(),
				),
				'condition' => array(
					'popup_type' => 'image',
				),
			)
		);

		$this->add_control(
			'popup_image_link',
			[
				'label'         => esc_html__( 'Click Action (URL)', 'powerpack' ),
				'description'   => esc_html__( 'Optional. Wraps the popup image in a link.', 'powerpack' ),
				'type'          => Controls_Manager::URL,
				'dynamic'       => [
					'active' => true,
				],
				'show_external' => false, // Show the 'open in new tab' button.
				'condition'     => [
					'popup_type' => 'image',
				],
			]
		);

		$this->add_control(
			'popup_link',
			array(
				'label'         => esc_html__( 'Enter URL', 'powerpack' ),
				'type'          => Controls_Manager::URL,
				'dynamic'       => array(
					'active' => true,
				),
				'show_external' => false, // Show the 'open in new tab' button.
				'condition'     => array(
					'popup_type' => 'link',
				),
			)
		);

		$this->add_control(
			'content',
			array(
				'label'     => esc_html__( 'Content', 'powerpack' ),
				'type'      => Controls_Manager::WYSIWYG,
				'default'   => esc_html__( 'I am the popup Content', 'powerpack' ),
				'dynamic'   => array(
					'active' => true,
				),
				'condition' => array(
					'popup_type' => 'content',
				),
			)
		);

		$this->add_control(
			'templates',
			array(
				'label'       => esc_html__( 'Choose Template', 'powerpack' ),
				'type'        => 'pp-query',
				'label_block' => false,
				'multiple'    => false,
				'query_type'  => 'templates-all',
				'condition'   => array(
					'popup_type' => 'template',
				),
			)
		);

		$this->add_control(
			'custom_html',
			array(
				'label'     => esc_html__( 'Custom HTML', 'powerpack' ),
				'type'      => Controls_Manager::CODE,
				'language'  => 'html',
				'condition' => array(
					'popup_type' => 'custom-html',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_content_layout_controls() {
		/**
		 * Content Tab: Layout
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_layout',
			array(
				'label' => esc_html__( 'Layout', 'powerpack' ),
			)
		);

		$this->add_control(
			'layout_type',
			array(
				'label'              => esc_html__( 'Layout', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'options'            => array(
					'standard'   => esc_html__( 'Standard', 'powerpack' ),
					'fullscreen' => esc_html__( 'Fullscreen', 'powerpack' ),
				),
				'default'            => 'standard',
				'frontend_available' => true,
			)
		);

		$this->add_responsive_control(
			'popup_width',
			array(
				'label'      => esc_html__( 'Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'default'    => array(
					'size' => '550',
					'unit' => 'px',
				),
				'range'      => array(
					'px' => array(
						'min'  => 0,
						'max'  => 1920,
						'step' => 1,
					),
				),
				'selectors'  => array(
					'.pp-modal-popup-window.pp-modal-popup-window-{{ID}}' => 'width: {{SIZE}}{{UNIT}}',
				),
				'condition'  => array(
					'layout_type' => 'standard',
				),
			)
		);

		$this->add_control(
			'auto_height',
			array(
				'label'        => esc_html__( 'Auto Height', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'condition'    => array(
					'layout_type' => 'standard',
				),
			)
		);

		$this->add_responsive_control(
			'popup_height',
			array(
				'label'      => esc_html__( 'Height', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vh', 'custom' ),
				'default'    => array(
					'size' => '450',
					'unit' => 'px',
				),
				'range'      => array(
					'px' => array(
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					),
				),
				'selectors'  => array(
					'.pp-modal-popup-window-{{ID}}' => 'height: {{SIZE}}{{UNIT}}',
				),
				'condition'  => array(
					'auto_height!' => 'yes',
					'layout_type'  => 'standard',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_content_trigger_controls() {
		/**
		 * Content Tab: Trigger
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_trigger',
			array(
				'label' => esc_html__( 'Trigger', 'powerpack' ),
			)
		);

		$this->add_control(
			'trigger',
			[
				'label'              => esc_html__( 'Trigger', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => 'on-click',
				'options'            => [
					'on-click'        => esc_html__( 'On Click', 'powerpack' ),
					'page-load'       => esc_html__( 'On Page Load', 'powerpack' ),
					'exit-intent'     => esc_html__( 'Exit Intent', 'powerpack' ),
					'query_parameter' => esc_html__( 'Query Parameter', 'powerpack' ),
					'other'           => esc_html__( 'Element Class/ID', 'powerpack' ),
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'trigger_type',
			array(
				'label'     => esc_html__( 'Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'button',
				'options'   => array(
					'button' => esc_html__( 'Button', 'powerpack' ),
					'icon'   => esc_html__( 'Icon', 'powerpack' ),
					'image'  => esc_html__( 'Image', 'powerpack' ),
				),
				'condition' => array(
					'trigger' => 'on-click',
				),
			)
		);

		$this->add_control(
			'button_text',
			array(
				'label'     => esc_html__( 'Button Text', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Click Here', 'powerpack' ),
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
				),
			)
		);

		$this->add_control(
			'select_button_icon',
			array(
				'label'            => esc_html__( 'Button Icon', 'powerpack' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'button_icon',
				'condition'        => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
				),
			)
		);

		$this->add_control(
			'button_icon_position',
			array(
				'label'     => esc_html__( 'Icon Position', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'after',
				'options'   => array(
					'after'  => esc_html__( 'After', 'powerpack' ),
					'before' => esc_html__( 'Before', 'powerpack' ),
				),
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
				),
			)
		);

		$this->add_control(
			'select_trigger_icon',
			array(
				'label'            => esc_html__( 'Icon', 'powerpack' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'trigger_icon',
				'condition'        => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'icon',
				),
			)
		);

		$this->add_control(
			'trigger_image',
			array(
				'label'     => esc_html__( 'Choose Image', 'powerpack' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => array(
					'active' => true,
				),
				'default'   => array(
					'url' => Utils::get_placeholder_image_src(),
				),
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'image',
				),
			)
		);

		$this->add_control(
			'delay',
			array(
				'label'     => esc_html__( 'Delay', 'powerpack' ),
				'title'     => esc_html__( 'seconds', 'powerpack' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 1,
				'min'       => 1,
				'step'      => 1,
				'condition' => array(
					'trigger' => 'page-load',
				),
			)
		);

		$this->add_control(
			'display_after_page_load',
			[
				'label'       => esc_html__( 'Don\'t Show Again For (days)', 'powerpack' ),
				'title'       => esc_html__( 'day(s)', 'powerpack' ),
				'description' => esc_html__( 'Once a user closes the popup, it won\'t be shown again for this many days. Set to 0 to show on every visit.', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 1,
				'min'         => 0,
				'step'        => 1,
				'condition'   => [
					'trigger' => 'page-load',
				],
			]
		);

		$this->add_control(
			'display_after_exit_intent',
			[
				'label'       => esc_html__( 'Don\'t Show Again For (days)', 'powerpack' ),
				'title'       => esc_html__( 'day(s)', 'powerpack' ),
				'description' => esc_html__( 'Once a user closes the popup, it won\'t be shown again for this many days. Set to 0 to show on every visit.', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 1,
				'min'         => 0,
				'step'        => 1,
				'condition'   => [
					'trigger' => 'exit-intent',
				],
			]
		);

		$this->add_control(
			'query_parameter_condition',
			[
				'label'     => esc_html__( 'Choose Condition', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'is',
				'options'   => [
					'is'  => esc_html__( 'Is', 'powerpack' ),
					'not' => esc_html__( 'Is not', 'powerpack' ),
				],
				'condition' => [
					'trigger' => 'query_parameter',
				],
			]
		);

		$this->add_control(
			'query_parameter_value',
			[
				'label'       => esc_html__( 'Query Parameter', 'powerpack' ),
				'type'        => Controls_Manager::TEXTAREA,
				'description' => esc_html__( 'Enter each request parameter on a new line as pairs of param=value or param1=value1&amp;param2=value2.', 'powerpack' ),
				'condition'   => [
					'trigger' => 'query_parameter',
				],
			]
		);

		$this->add_control(
			'element_identifier',
			[
				'label'              => esc_html__( 'Element CSS Class/ID', 'powerpack' ),
				'description'        => esc_html__( 'Any click on this selector opens the popup. Use a class with a leading dot (e.g. .open-popup) or an ID with a leading hash (e.g. #signup).', 'powerpack' ),
				'type'               => Controls_Manager::TEXT,
				'label_block'        => true,
				'placeholder'        => '.pp-modal-popup-link',
				'dynamic'            => [
					'active' => true,
				],
				'ai'                 => [
					'active' => false,
				],
				'condition'          => [
					'trigger' => 'other',
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'enable_url_trigger',
			array(
				'label'              => esc_html__( 'Enable URL Trigger', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => '',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'separator'          => 'before',
				'frontend_available' => true,
			)
		);

		$this->add_control(
			'element_url_identifier',
			array(
				'label'       => esc_html__( 'Element ID', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'ai'          => [
					'active' => false,
				],
				'condition'   => array(
					'enable_url_trigger' => 'yes',
				),
				'frontend_available' => true,
			)
		);

		$this->end_controls_section();
	}

	protected function register_content_settings_controls() {
		/**
		 * Content Tab: Behavior
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_settings',
			[
				'label' => esc_html__( 'Behavior', 'powerpack' ),
			]
		);

		$this->add_control(
			'prevent_scroll',
			[
				'label'              => esc_html__( 'Prevent Page Scroll', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'close_button',
			[
				'label'              => esc_html__( 'Show Close Button', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'esc_exit',
			[
				'label'              => esc_html__( 'Close on Esc Keypress', 'powerpack' ),
				'description'        => esc_html__( 'Close the popup when user presses the Esc key', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'click_exit',
			[
				'label'              => esc_html__( 'Close on Overlay Click', 'powerpack' ),
				'description'        => esc_html__( 'Close the popup when user clicks on the overlay', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'content_close',
			[
				'label'              => esc_html__( 'Click Anywhere to Close', 'powerpack' ),
				'description'        => esc_html__( 'Closes the popup on any click inside the content area. Useful for image-only popups.', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => '',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'popup_disable_on',
			[
				'label'     => esc_html__( 'Disable On', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''       => esc_html__( 'None', 'powerpack' ),
					'tablet' => esc_html__( 'Mobile & Tablet', 'powerpack' ),
					'mobile' => esc_html__( 'Mobile', 'powerpack' ),
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_section();

		/**
		 * Content Tab: Animation
		 * -------------------------------------------------
		 *
		 * @since 3.0.0
		 */
		$this->start_controls_section(
			'section_animation',
			[
				'label' => esc_html__( 'Animation', 'powerpack' ),
			]
		);

		$this->add_control(
			'popup_animation_in',
			[
				'label'              => esc_html__( 'Entrance Animation', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => 'mfp-zoom-in',
				'options'            => [
					''                  => esc_html__( 'None', 'powerpack' ),
					'mfp-zoom-in'       => esc_html__( 'Zoom In', 'powerpack' ),
					'mfp-zoom-out'      => esc_html__( 'Zoom Out', 'powerpack' ),
					'mfp-3d-unfold'     => esc_html__( '3D Unfold', 'powerpack' ),
					'mfp-newspaper'     => esc_html__( 'Newspaper', 'powerpack' ),
					'mfp-move-from-top' => esc_html__( 'Move From Top', 'powerpack' ),
					'mfp-move-left'     => esc_html__( 'Move Left', 'powerpack' ),
					'mfp-move-right'    => esc_html__( 'Move Right', 'powerpack' ),
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'popup_animation_out',
			[
				'label'              => esc_html__( 'Exit Animation', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => '',
				'options'            => [
					''                  => esc_html__( 'Reverse Entrance', 'powerpack' ),
					'none'              => esc_html__( 'None', 'powerpack' ),
					'mfp-zoom-in'       => esc_html__( 'Zoom In', 'powerpack' ),
					'mfp-zoom-out'      => esc_html__( 'Zoom Out', 'powerpack' ),
					'mfp-3d-unfold'     => esc_html__( '3D Unfold', 'powerpack' ),
					'mfp-newspaper'     => esc_html__( 'Newspaper', 'powerpack' ),
					'mfp-move-from-top' => esc_html__( 'Move From Top', 'powerpack' ),
					'mfp-move-left'     => esc_html__( 'Move Left', 'powerpack' ),
					'mfp-move-right'    => esc_html__( 'Move Right', 'powerpack' ),
				],
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();
	}

	/*-----------------------------------------------------------------------------------*/
	/*	STYLE TAB
	/*-----------------------------------------------------------------------------------*/

	protected function register_style_popup_controls() {
		/**
		 * Style Tab: Popup
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_popup_window_style',
			array(
				'label' => esc_html__( 'Popup', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'popup_bg',
				'label'    => esc_html__( 'Background', 'powerpack' ),
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '#pp-modal-popup-window-{{ID}}',
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'popup_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '#pp-modal-popup-window-{{ID}}',
			)
		);

		$this->add_control(
			'popup_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'#pp-modal-popup-window-{{ID}}' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'popup_padding',
			array(
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'selectors'  => array(
					'#pp-modal-popup-window-{{ID}}' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'      => 'popup_box_shadow',
				'selector'  => '#pp-modal-popup-window-{{ID}}',
				'separator' => 'before',
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_overlay_controls() {
		/**
		 * Style Tab: Overlay
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_popup_overlay_style',
			array(
				'label' => esc_html__( 'Overlay', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'overlay_switch',
			array(
				'label'              => esc_html__( 'Overlay', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Show', 'powerpack' ),
				'label_off'          => esc_html__( 'Hide', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'      => 'overlay_bg',
				'label'     => esc_html__( 'Background', 'powerpack' ),
				'types'     => array( 'classic', 'gradient' ),
				'exclude'   => array( 'image' ),
				'selector'  => '.pp-modal-popup-{{ID}}',
				'condition' => array(
					'overlay_switch' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_title_controls() {
		/**
		 * Style Tab: Title
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_title_style',
			array(
				'label'     => esc_html__( 'Title', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'popup_title' => 'yes',
				),
			)
		);

		$this->add_responsive_control(
			'title_align',
			array(
				'label'     => esc_html__( 'Alignment', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default'   => '',
				'selectors' => array(
					'.pp-modal-popup-window-{{ID}} .pp-popup-header .pp-popup-title' => 'text-align: {{VALUE}};',
				),
				'condition' => array(
					'popup_title' => 'yes',
				),
			)
		);

		$this->add_control(
			'title_bg',
			array(
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'.pp-modal-popup-window-{{ID}} .pp-popup-header .pp-popup-title' => 'background-color: {{VALUE}}',
				),
				'condition' => array(
					'popup_title' => 'yes',
				),
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'.pp-modal-popup-window-{{ID}} .pp-popup-header .pp-popup-title' => 'color: {{VALUE}}',
				),
				'condition' => array(
					'popup_title' => 'yes',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'title_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '.pp-modal-popup-window-{{ID}} .pp-popup-header .pp-popup-title',
				'condition'   => array(
					'popup_title' => 'yes',
				),
			)
		);

		$this->add_responsive_control(
			'title_padding',
			array(
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'selectors'  => array(
					'.pp-modal-popup-window-{{ID}} .pp-popup-header .pp-popup-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array(
					'popup_title' => 'yes',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => 'title_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector'  => '.pp-modal-popup-window-{{ID}} .pp-popup-header .pp-popup-title',
				'condition' => array(
					'popup_title' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_content_controls() {
		/**
		 * Style Tab: Content
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_popup_content_style',
			array(
				'label'     => esc_html__( 'Content', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'popup_type' => 'content',
				),
			)
		);

		$this->add_responsive_control(
			'content_align',
			array(
				'label'     => esc_html__( 'Alignment', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'    => array(
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center'  => array(
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'   => array(
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					),
					'justify' => array(
						'title' => esc_html__( 'Justified', 'powerpack' ),
						'icon'  => 'eicon-text-align-justify',
					),
				),
				'default'   => '',
				'selectors' => array(
					'.pp-modal-popup-window-{{ID}} .pp-popup-content'   => 'text-align: {{VALUE}};',
				),
				'condition' => array(
					'popup_type' => 'content',
				),
			)
		);

		$this->add_control(
			'content_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'.pp-modal-popup-window-{{ID}} .pp-popup-content' => 'color: {{VALUE}}',
				),
				'condition' => array(
					'popup_type' => 'content',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => 'content_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector'  => '.pp-modal-popup-window-{{ID}} .pp-popup-content',
				'condition' => array(
					'popup_type' => 'content',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_trigger_icon_controls() {
		/**
		 * Style Tab: Trigger Icon
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_icon_style',
			array(
				'label'     => esc_html__( 'Trigger Icon/Image', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'trigger'       => 'on-click',
					'trigger_type!' => 'button',
				),
			)
		);

		$this->add_responsive_control(
			'icon_align',
			array(
				'label'     => esc_html__( 'Alignment', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'left',
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-h-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .pp-modal-popup-wrap .pp-modal-popup'   => 'text-align: {{VALUE}};',
				),
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => array( 'icon', 'image' ),
				),
			)
		);

		$this->add_control(
			'icon_color',
			array(
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .pp-trigger-icon'     => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-trigger-icon svg' => 'fill: {{VALUE}}',
				),
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'icon',
				),
			)
		);

		$this->add_responsive_control(
			'icon_size',
			array(
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em', 'rem', 'custom' ),
				'default'    => array(
					'size' => '28',
					'unit' => 'px',
				),
				'range'      => array(
					'px' => array(
						'min'  => 10,
						'max'  => 80,
						'step' => 1,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .pp-trigger-icon' => 'font-size: {{SIZE}}{{UNIT}}',
				),
				'condition'  => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'icon',
				),
			)
		);

		$this->add_responsive_control(
			'icon_image_width',
			array(
				'label'      => esc_html__( 'Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'range'      => array(
					'px' => array(
						'min'  => 10,
						'max'  => 1200,
						'step' => 1,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .pp-trigger-image' => 'width: {{SIZE}}{{UNIT}}',
				),
				'condition'  => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'image',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function register_style_trigger_button_controls() {
		/**
		 * Style Tab: Trigger Button
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_modal_button_style',
			array(
				'label'     => esc_html__( 'Trigger Button', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_responsive_control(
			'button_align',
			array(
				'label'     => esc_html__( 'Alignment', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'left',
				'options'   => array(
					'left'    => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'powerpack' ),
						'icon' => 'eicon-text-align-justify',
					],
				),
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_control(
			'button_size',
			array(
				'label'     => esc_html__( 'Size', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'md',
				'options'   => array(
					'xs' => esc_html__( 'Extra Small', 'powerpack' ),
					'sm' => esc_html__( 'Small', 'powerpack' ),
					'md' => esc_html__( 'Medium', 'powerpack' ),
					'lg' => esc_html__( 'Large', 'powerpack' ),
					'xl' => esc_html__( 'Extra Large', 'powerpack' ),
				),
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->start_controls_tabs( 'tabs_button_style' );

		$this->start_controls_tab(
			'tab_button_normal',
			array(
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_control(
			'button_bg_color_normal',
			array(
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'global'                => [
					'default' => Global_Colors::COLOR_ACCENT,
				],
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .pp-modal-popup-button' => 'background-color: {{VALUE}}',
				),
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_control(
			'button_text_color_normal',
			array(
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .pp-modal-popup-button' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-modal-popup-button svg' => 'fill: {{VALUE}}',
				),
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-modal-popup-button',
				'condition'   => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_control(
			'button_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .pp-modal-popup-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => 'button_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector'  => '{{WRAPPER}} .pp-modal-popup-button',
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_responsive_control(
			'button_padding',
			array(
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .pp-modal-popup-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'      => 'button_box_shadow',
				'selector'  => '{{WRAPPER}} .pp-modal-popup-button',
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_control(
			'button_icon_heading',
			array(
				'label'     => esc_html__( 'Button Icon', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
				),
			)
		);

		$this->add_responsive_control(
			'button_icon_margin',
			array(
				'label'       => esc_html__( 'Margin', 'powerpack' ),
				'type'        => Controls_Manager::DIMENSIONS,
				'size_units'  => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
				'placeholder' => array(
					'top'    => '',
					'right'  => '',
					'bottom' => '',
					'left'   => '',
				),
				'selectors'   => array(
					'{{WRAPPER}} .pp-modal-popup-button .pp-button-icon' => 'margin-top: {{TOP}}{{UNIT}}; margin-left: {{LEFT}}{{UNIT}}; margin-right: {{RIGHT}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}};',
				),
				'condition'   => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			array(
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_control(
			'button_bg_color_hover',
			array(
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .pp-modal-popup-button:hover' => 'background-color: {{VALUE}}',
				),
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_control(
			'button_text_color_hover',
			array(
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .pp-modal-popup-button:hover' => 'color: {{VALUE}}',
				),
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_control(
			'button_border_color_hover',
			array(
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .pp-modal-popup-button:hover' => 'border-color: {{VALUE}}',
				),
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_control(
			'button_animation',
			array(
				'label'     => esc_html__( 'Animation', 'powerpack' ),
				'type'      => Controls_Manager::HOVER_ANIMATION,
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'      => 'button_box_shadow_hover',
				'selector'  => '{{WRAPPER}} .pp-modal-popup-button:hover',
				'condition' => array(
					'trigger'      => 'on-click',
					'trigger_type' => 'button',
					'button_text!' => '',
				),
			)
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function register_style_close_button_controls() {
		/**
		 * Style Tab: Close Button
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_close_button_style',
			array(
				'label'     => esc_html__( 'Close Button', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'close_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'close_button_position',
			array(
				'label'              => esc_html__( 'Position', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => 'win-top-right',
				'options'            => array(
					'box-top-right' => esc_html__( 'Box - Top Right', 'powerpack' ),
					'box-top-left'  => esc_html__( 'Box - Top Left', 'powerpack' ),
					'win-top-right' => esc_html__( 'Window - Top Right', 'powerpack' ),
					'win-top-left'  => esc_html__( 'Window - Top Left', 'powerpack' ),
				),
				'frontend_available' => true,
				'condition'          => array(
					'close_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'close_button_weight',
			array(
				'label'     => esc_html__( 'Weight', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'normal',
				'options'   => array(
					'normal' => esc_html__( 'Normal', 'powerpack' ),
					'bold'   => esc_html__( 'Bold', 'powerpack' ),
				),
				'condition' => array(
					'close_button' => 'yes',
				),
				'selectors' => array(
					'.pp-modal-popup-{{ID}} .pp-modal-popup-close' => 'font-weight: {{VALUE}}',
				),
			)
		);

		$this->add_responsive_control(
			'close_button_size',
			array(
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em', 'rem', 'custom' ),
				'default'    => array(
					'size' => '28',
					'unit' => 'px',
				),
				'range'      => array(
					'px' => array(
						'min'  => 10,
						'max'  => 80,
						'step' => 1,
					),
				),
				'selectors'  => array(
					'.pp-modal-popup-{{ID}} .pp-modal-popup-close' => 'font-size: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				),
				'condition'  => array(
					'close_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'close_button_z_index',
			array(
				'label'     => esc_html__( 'Z-Index', 'powerpack' ),
				'type'      => Controls_Manager::NUMBER,
				'step'      => 1,
				'selectors' => array(
					'.pp-modal-popup-{{ID}} .pp-modal-popup-close' => 'z-index: {{SIZE}}',
				),
				'condition' => array(
					'close_button' => 'yes',
				),
			)
		);

		$this->start_controls_tabs( 'tabs_close_button_style' );

			$this->start_controls_tab(
				'tab_close_button_normal',
				array(
					'label'     => esc_html__( 'Normal', 'powerpack' ),
					'condition' => array(
						'close_button' => 'yes',
					),
				)
			);

				$this->add_control(
					'close_button_color_normal',
					array(
						'label'     => esc_html__( 'Icon Color', 'powerpack' ),
						'type'      => Controls_Manager::COLOR,
						'default'   => '',
						'selectors' => array(
							'.pp-modal-popup-{{ID}} .pp-modal-popup-close' => 'color: {{VALUE}}',
						),
						'condition' => array(
							'close_button' => 'yes',
						),
					)
				);

				$this->add_group_control(
					Group_Control_Background::get_type(),
					array(
						'name'      => 'close_button_bg',
						'label'     => esc_html__( 'Background', 'powerpack' ),
						'types'     => array( 'classic', 'gradient' ),
						'exclude'   => array( 'image' ),
						'selector'  => '.pp-modal-popup-{{ID}} .pp-modal-popup-close',
						'condition' => array(
							'close_button' => 'yes',
						),
					)
				);

				$this->add_group_control(
					Group_Control_Border::get_type(),
					array(
						'name'        => 'close_button_border_normal',
						'label'       => esc_html__( 'Border', 'powerpack' ),
						'placeholder' => '1px',
						'default'     => '1px',
						'selector'    => '.pp-modal-popup-{{ID}} .pp-modal-popup-close',
						'condition'   => array(
							'close_button' => 'yes',
						),
					)
				);

				$this->add_control(
					'close_button_border_radius',
					array(
						'label'      => esc_html__( 'Border Radius', 'powerpack' ),
						'type'       => Controls_Manager::DIMENSIONS,
						'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
						'selectors'  => array(
							'.pp-modal-popup-{{ID}} .pp-modal-popup-close' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						),
						'condition'  => array(
							'close_button' => 'yes',
						),
					)
				);

				$this->add_responsive_control(
					'close_button_margin',
					array(
						'label'       => esc_html__( 'Margin', 'powerpack' ),
						'type'        => Controls_Manager::DIMENSIONS,
						'size_units'  => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
						'placeholder' => array(
							'top'    => '',
							'right'  => '',
							'bottom' => '',
							'left'   => '',
						),
						'selectors'   => array(
							'.pp-modal-popup-{{ID}} .pp-modal-popup-close' => 'margin-top: {{TOP}}{{UNIT}}; margin-left: {{LEFT}}{{UNIT}}; margin-right: {{RIGHT}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}};',
						),
						'condition'   => array(
							'close_button' => 'yes',
						),
					)
				);

				$this->add_responsive_control(
					'close_button_padding',
					array(
						'label'       => esc_html__( 'Padding', 'powerpack' ),
						'type'        => Controls_Manager::DIMENSIONS,
						'size_units'  => array( 'px', '%', 'em', 'rem', 'vw', 'custom' ),
						'placeholder' => array(
							'top'    => '',
							'right'  => '',
							'bottom' => '',
							'left'   => '',
						),
						'selectors'   => array(
							'.pp-modal-popup-{{ID}} .pp-modal-popup-close' => 'padding-top: {{TOP}}{{UNIT}}; padding-left: {{LEFT}}{{UNIT}}; padding-right: {{RIGHT}}{{UNIT}}; padding-bottom: {{BOTTOM}}{{UNIT}};',
						),
						'condition'   => array(
							'close_button' => 'yes',
						),
					)
				);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'tab_close_button_hover',
				array(
					'label'     => esc_html__( 'Hover', 'powerpack' ),
					'condition' => array(
						'close_button' => 'yes',
					),
				)
			);

				$this->add_control(
					'close_button_color_hover',
					array(
						'label'     => esc_html__( 'Icon Color', 'powerpack' ),
						'type'      => Controls_Manager::COLOR,
						'default'   => '',
						'selectors' => array(
							'.pp-modal-popup-{{ID}} .pp-modal-popup-close:hover' => 'color: {{VALUE}}',
						),
						'condition' => array(
							'close_button' => 'yes',
						),
					)
				);

				$this->add_group_control(
					Group_Control_Background::get_type(),
					array(
						'name'      => 'close_button_bg_hover',
						'label'     => esc_html__( 'Background', 'powerpack' ),
						'types'     => array( 'classic', 'gradient' ),
						'selector'  => '.pp-modal-popup-{{ID}} .pp-modal-popup-close:hover',
						'condition' => array(
							'close_button' => 'yes',
						),
					)
				);

				$this->add_control(
					'close_button_border_hover',
					array(
						'label'     => esc_html__( 'Border Color', 'powerpack' ),
						'type'      => Controls_Manager::COLOR,
						'default'   => '',
						'selectors' => array(
							'.pp-modal-popup-{{ID}} .pp-modal-popup-close:hover' => 'border-color: {{VALUE}}',
						),
						'condition' => array(
							'close_button' => 'yes',
						),
					)
				);

				$this->add_control(
					'close_button_border_radius_hover',
					array(
						'label'      => esc_html__( 'Border Radius', 'powerpack' ),
						'type'       => Controls_Manager::DIMENSIONS,
						'size_units' => array( 'px', '%', 'em', 'rem', 'custom' ),
						'selectors'  => array(
							'.pp-modal-popup-{{ID}} .pp-modal-popup-close:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						),
						'condition'  => array(
							'close_button' => 'yes',
						),
					)
				);

			$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

	}

	/**
	 * Render popup box button icon output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render_button_icon() {
		$settings = $this->get_settings_for_display();

		// Trigger Button Icon
		if ( ! isset( $settings['button_icon'] ) && ! Icons_Manager::is_migration_allowed() ) {
			// add old default
			$settings['button_icon'] = '';
		}

		$has_icon = ! empty( $settings['button_icon'] );

		if ( $has_icon ) {
			$this->add_render_attribute( 'i', 'class', $settings['button_icon'] );
			$this->add_render_attribute( 'i', 'aria-hidden', 'true' );
		}

		if ( ! $has_icon && ! empty( $settings['select_button_icon']['value'] ) ) {
			$has_icon = true;
		}
		$migrated = isset( $settings['__fa4_migrated']['select_button_icon'] );
		$is_new   = ! isset( $settings['button_icon'] ) && Icons_Manager::is_migration_allowed();

		if ( $has_icon ) {
			?>
			<span class="pp-button-icon pp-icon">
				<?php
				if ( $is_new || $migrated ) {
					Icons_Manager::render_icon( $settings['select_button_icon'], array( 'aria-hidden' => 'true' ) );
				} elseif ( ! empty( $settings['button_icon'] ) ) {
					?>
					<i <?php $this->print_render_attribute_string( 'i' ); ?>></i>
					<?php
				}
				?>
			</span>
			<?php
		}
	}

	/**
	 * Render popup box button output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render_trigger_button() {
		$settings  = $this->get_settings_for_display();
		$elementor = \Elementor\Plugin::instance();

		$this->add_render_attribute( 'button-wrap', 'class', 'pp-modal-popup-button-wrap' );

		if ( ! empty( $settings['button_align'] ) ) {
			$this->add_render_attribute( 'button-wrap', 'class', 'elementor-align-' . $settings['button_align'] );
		}

		if ( pp_has_custom_breakpoints() ) {
			$breakpoints = pp_get_breakpoints_config();

			foreach ( $breakpoints as $breakpoint_name => $breakpoint ) :

				if ( isset( $breakpoints[$breakpoint_name]['value'] ) && true === $breakpoints[$breakpoint_name]['is_enabled'] ) {

					if ( isset( $settings['button_align_' . $breakpoint_name] ) && ! empty( $settings['button_align_' . $breakpoint_name] ) ) {
						$alignment = $settings['button_align_' . $breakpoint_name];

						$this->add_render_attribute( 'button-wrap', 'class', 'elementor-' . $breakpoint_name .'-align-' . $alignment );
					}
				}
			endforeach;
		} else {
			if ( ! empty( $settings['button_align_tablet'] ) ) {
				$this->add_render_attribute( 'button-wrap', 'class', 'elementor-tablet-align-' . $settings['button_align_tablet'] );
			}

			if ( ! empty( $settings['button_align_mobile'] ) ) {
				$this->add_render_attribute( 'button-wrap', 'class', 'elementor-mobile-align-' . $settings['button_align_mobile'] );
			}
		}

		$this->add_render_attribute(
			'button',
			'class',
			array(
				'pp-modal-popup-button',
				'pp-modal-popup-link',
				'pp-modal-popup-link-' . esc_attr( $this->get_id() ),
				'elementor-button',
				'elementor-size-' . $settings['button_size'],
			)
		);

		if ( $settings['button_animation'] ) {
			$this->add_render_attribute( 'button', 'class', 'elementor-animation-' . $settings['button_animation'] );
		}

		echo '<div ' . wp_kses_post( $this->get_render_attribute_string( 'button-wrap' ) ) . '>';
			echo '<span ' . wp_kses_post( $this->get_render_attribute_string( 'button' ) ) . '>';

			if ( 'before' === $settings['button_icon_position'] ) {
				$this->render_button_icon();
			}

			if ( ! empty( $settings['button_text'] ) ) {
				printf( '<span %1$s>', wp_kses_post( $this->get_render_attribute_string( 'button_text' ) ) );
					echo esc_html( $settings['button_text'] );
				printf( '</span>' );
			}

			if ( 'after' === $settings['button_icon_position'] ) {
				$this->render_button_icon();
			}

			echo '</span>';
		echo '</div>';
	}

	/**
	 * Render popup box button icon output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render_trigger_icon() {
		$settings = $this->get_settings_for_display();

		// Trigger Button Icon
		if ( ! isset( $settings['trigger_icon'] ) && ! Icons_Manager::is_migration_allowed() ) {
			// add old default
			$settings['trigger_icon'] = '';
		}

		$has_icon = ! empty( $settings['trigger_icon'] );

		if ( $has_icon ) {
			$this->add_render_attribute( 'trigger-i', 'class', $settings['trigger_icon'] );
			$this->add_render_attribute( 'trigger-i', 'aria-hidden', 'true' );
		}

		if ( ! $has_icon && ! empty( $settings['select_trigger_icon']['value'] ) ) {
			$has_icon = true;
		}
		$migrated = isset( $settings['__fa4_migrated']['select_trigger_icon'] );
		$is_new   = ! isset( $settings['trigger_icon'] ) && Icons_Manager::is_migration_allowed();

		if ( $has_icon ) {
			?>
			<span class="pp-trigger-icon pp-icon pp-modal-popup-link pp-modal-popup-link-<?php echo esc_attr( $this->get_id() ); ?>">
				<?php
				if ( $is_new || $migrated ) {
					Icons_Manager::render_icon( $settings['select_trigger_icon'], array( 'aria-hidden' => 'true' ) );
				} elseif ( ! empty( $settings['trigger_icon'] ) ) {
					?>
					<i <?php $this->print_render_attribute_string( 'trigger-i' ); ?>></i>
					<?php
				}
				?>
			</span>
			<?php
		}
	}

	/**
	 * Popup Settings.
	 *
	 * Returns the runtime config consumed by the frontend handler in
	 * assets/js/frontend-popup.js. Only carries values the handler can't derive
	 * from frontend_available controls — trigger timing, breakpoint cutoff,
	 * and the pre-evaluated query-parameter result.
	 *
	 * @access public
	 */
	public function popup_settings() {
		$settings = $this->get_settings_for_display();

		$popup_options = [];

		if ( 'query_parameter' === $settings['trigger'] ) {
			$show_value            = false;
			$query_parameter_value = '';

			if ( ( ! isset( $_SERVER['REQUEST_URI'] ) || empty( $_SERVER['REQUEST_URI'] ) )
				|| ( ! isset( $settings['query_parameter_value'] ) || empty( $settings['query_parameter_value'] ) ) ) {
				$show_value = false;
			} else {
				$query_parameter_value = $settings['query_parameter_value'];

				$url = wp_parse_url(
					sanitize_text_field(
						wp_unslash( $_SERVER['REQUEST_URI'] )
					)
				);

				if ( $url && isset( $url['query'] ) && ! empty( $url['query'] ) ) {
					$query_params = explode( '&', $url['query'] );

					$query_parameter_value = str_replace( '&', "\n", $query_parameter_value );
					$query_parameter_value = explode( "\n", sanitize_textarea_field( $query_parameter_value ) );

					if ( ! empty( $query_parameter_value ) ) {
						foreach ( $query_parameter_value as $index => $param ) {
							if ( ! empty( $param ) ) {
								$is_strict = strpos( $param, '=' );
								if ( ! $is_strict ) {
									$query_parameter_value[ $index ] = $query_parameter_value[ $index ] . '=' . rawurlencode( $_GET[ $param ] );
								}
							}
						}
						$show_value = ! empty( array_intersect( $query_parameter_value, $query_params ) ) ? true : false;
					}
				}
			}

			$query_parameter_condition = $settings['query_parameter_condition'];
			if ( 'is' === $query_parameter_condition ) {
				$compare_result = ( true == $show_value );
			} elseif ( 'not' === $query_parameter_condition ) {
				$compare_result = ( true != $show_value );
			} else {
				$compare_result = ( true == $show_value );
			}

			$popup_options['queryParameter'] = ( true === $compare_result ? 1 : 0 );
		}

		if ( 'page-load' === $settings['trigger'] ) {
			$delay = 1000;

			if ( '' !== $settings['delay'] ) {
				$delay = $settings['delay'] * 1000;
			}

			$popup_options['delay'] = $delay;

			if ( '' !== $settings['display_after_page_load'] ) {
				$popup_options['displayAfter'] = $settings['display_after_page_load'];
			}
		} elseif ( 'exit-intent' === $settings['trigger'] ) {
			if ( '' !== $settings['display_after_exit_intent'] ) {
				$popup_options['displayAfter'] = $settings['display_after_exit_intent'];
			}
		}

		$elementor_bp_tablet = get_option( 'elementor_viewport_lg' );
		$elementor_bp_mobile = get_option( 'elementor_viewport_md' );
		$bp_tablet           = ! empty( $elementor_bp_tablet ) ? $elementor_bp_tablet : 1025;
		$bp_mobile           = ! empty( $elementor_bp_mobile ) ? $elementor_bp_mobile : 768;

		if ( 'tablet' === $settings['popup_disable_on'] ) {
			$popup_disable_on = $bp_tablet;
		} elseif ( 'mobile' === $settings['popup_disable_on'] ) {
			$popup_disable_on = $bp_mobile;
		} else {
			$popup_disable_on = '';
		}

		if ( $popup_disable_on ) {
			$popup_options['disableOn'] = $popup_disable_on;
		}

		return $popup_options;
	}

	/**
	 * Render popup box widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings  = $this->get_settings_for_display();
		$widget_id = esc_attr( $this->get_id() );
		$is_editor = \Elementor\Plugin::instance()->editor->is_edit_mode();

		$popup_options = $this->popup_settings();

		// Wrap holds the trigger element and the runtime config the JS handler reads.
		$this->add_render_attribute(
			'popup-wrap',
			array(
				'class'                => 'pp-modal-popup-wrap',
				'id'                   => 'pp-modal-popup-wrap-' . $widget_id,
				'data-popup-settings'  => wp_json_encode( $popup_options ),
			)
		);

		if ( $is_editor && 'yes' === $settings['preview_popup'] ) {
			$this->add_render_attribute( 'popup-wrap', 'class', 'pp-popup-preview' );
		}

		// Overlay carries layout + animation + close-position classes; visibility toggled by handler.
		$overlay_classes = array(
			'pp-modal-popup-overlay',
			'pp-modal-popup-' . $widget_id,
			'pp-modal-popup-' . $settings['layout_type'],
		);

		if ( 'yes' === $settings['close_button'] && ! empty( $settings['close_button_position'] ) ) {
			$overlay_classes[] = $settings['close_button_position'];
		}

		if ( ! empty( $settings['popup_animation_in'] ) ) {
			$overlay_classes[] = $settings['popup_animation_in'];
		}

		if ( 'yes' !== $settings['overlay_switch'] ) {
			$overlay_classes[] = 'pp-no-overlay';
		}

		$this->add_render_attribute(
			'modal-popup-overlay',
			[
				'class'       => $overlay_classes,
				'id'          => 'pp-modal-popup-overlay-' . $widget_id,
				'aria-hidden' => 'true',
			]
		);

		// Window keeps its existing class/id so style controls continue to match.
		$this->add_render_attribute(
			'modal-popup-window',
			[
				'class'      => [ 'pp-modal-popup-window pp-modal-popup-window-' . $widget_id ],
				'id'         => 'pp-modal-popup-window-' . $widget_id,
				'role'       => 'dialog',
				'aria-modal' => 'true',
				'tabindex'   => '-1',
			]
		);
		?>
		<div <?php $this->print_render_attribute_string( 'popup-wrap' ); ?>>
			<div class="pp-modal-popup">
				<?php
				if ( 'on-click' === $settings['trigger'] ) {
					if ( 'button' === $settings['trigger_type'] ) {

						$this->render_trigger_button();

					} elseif ( 'icon' === $settings['trigger_type'] ) {

						$this->render_trigger_icon();

					} elseif ( 'image' === $settings['trigger_type'] ) {

						$trigger_image = $this->get_settings_for_display( 'trigger_image' );
						if ( ! empty( $trigger_image['url'] ) ) {
							printf(
								'<img class="pp-trigger-image pp-modal-popup-link %1$s" src="%2$s" alt="%3$s">',
								'pp-modal-popup-link-' . $widget_id,
								esc_url( $trigger_image['url'] ),
								esc_attr( Control_Media::get_image_alt( $trigger_image ) )
							);
						}
					}
				} elseif ( $is_editor ) {
					?>
					<div class="pp-editor-message" style="text-align: center;">
						<h5>
							<?php
							/* translators: %s: widget ID. */
							printf( esc_html__( 'Modal Popup ID - %s', 'powerpack' ), esc_html( $widget_id ) );
							?>
						</h5>
						<p>
							<?php esc_html_e( 'Click here to edit the "Popup Box" settings. This text will not be visible on frontend.', 'powerpack' ); ?>
						</p>
					</div>
					<?php
				}
				?>
			</div>
		</div>
		<?php
		$show_close       = ( 'yes' === $settings['close_button'] );
		$close_position   = ! empty( $settings['close_button_position'] ) ? $settings['close_button_position'] : 'win-top-right';
		$is_close_outside = $show_close && in_array( $close_position, array( 'win-top-right', 'win-top-left' ), true );
		$is_close_inside  = $show_close && in_array( $close_position, array( 'box-top-right', 'box-top-left' ), true );
		?>
		<div <?php $this->print_render_attribute_string( 'modal-popup-overlay' ); ?>>
			<?php if ( $is_close_outside ) { ?>
				<button type="button" class="pp-modal-popup-close" aria-label="<?php esc_attr_e( 'Close', 'powerpack' ); ?>">&times;</button>
			<?php } ?>
			<div class="pp-modal-popup-container">
				<div <?php $this->print_render_attribute_string( 'modal-popup-window' ); ?>>
					<?php if ( $is_close_inside ) { ?>
						<button type="button" class="pp-modal-popup-close" aria-label="<?php esc_attr_e( 'Close', 'powerpack' ); ?>">&times;</button>
					<?php } ?>
					<?php if ( 'yes' === $settings['popup_title'] && '' !== $settings['title'] ) { ?>
						<div class="pp-popup-header">
							<h2 class="pp-popup-title">
								<?php echo wp_kses_post( $settings['title'] ); ?>
							</h2>
						</div>
					<?php } ?>
					<div class="pp-popup-content" id="pp-popup-content-<?php echo $widget_id; ?>">
						<?php $this->render_popup_content( $settings ); ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the inner popup body based on the chosen content type.
	 *
	 * For `link`, render an `<iframe>` placeholder with the URL stored in
	 * data-src; the handler swaps it into src on open and clears it on close
	 * so video playback stops and the iframe doesn't preload.
	 *
	 * @since 3.0.0
	 *
	 * @param array $settings Resolved widget settings.
	 */
	protected function render_popup_content( $settings ) {
		switch ( $settings['popup_type'] ) {
			case 'image':
				$image     = $this->get_settings_for_display( 'image' );
				$image_alt = esc_attr( Control_Media::get_image_alt( $image ) );

				$this->add_link_attributes( 'image-link', $settings['popup_image_link'] );

				if ( $settings['popup_image_link']['url'] ) {
					echo '<a ' . wp_kses_post( $this->get_render_attribute_string( 'image-link' ) ) . '><img src="' . esc_url( $image['url'] ) . '" alt="' . $image_alt . '"></a>';
				} else {
					echo '<img src="' . esc_url( $image['url'] ) . '" alt="' . $image_alt . '">';
				}
				break;

			case 'content':
				global $wp_embed;

				$content = wpautop( $wp_embed->autoembed( $settings['content'] ) );
				echo do_shortcode( $content ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				break;

			case 'template':
				if ( ! empty( $settings['templates'] ) ) {
					$template_id = $settings['templates'];
					echo \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $template_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				break;

			case 'custom-html':
				echo wp_kses_post( $settings['custom_html'] );
				break;

			case 'link':
				$url = isset( $settings['popup_link']['url'] ) ? $settings['popup_link']['url'] : '';

				if ( '' === $url ) {
					break;
				}
				?>
				<div class="pp-modal-popup-iframe-scaler">
					<iframe class="pp-modal-popup-iframe" data-src="<?php echo esc_url( $url ); ?>" src="" frameborder="0" allowfullscreen></iframe>
				</div>
				<?php
				break;
		}
	}
}
