=== PowerPack Pro for Elementor ===
Contributors: ideaboxcreations, bloompixel, simrandeep, puneetsahalot, ibachal
Tags: elementor, addons, elementor addon, elementor addons, elementor widgets, elements, powerpack elementor templates, essential addons
Requires at least: 6.3
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

PowerPack for Elementor extends Elementor Page Builder with 90+ Creative Widgets and exciting extensions.