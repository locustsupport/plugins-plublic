<?php
namespace PowerpackElements\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use PowerpackElements\Classes\PP_Helper;

/**
 * Class PP_Config.
 */
class PP_Config {

	/**
	 * Widget List
	 *
	 * @var widget_list
	 */
	public static $widget_info = null;

	/**
	 * Help Docs Links
	 *
	 * @var help_docs
	 */
	public static $help_docs = null;

	/**
	 * Extension Docs Links
	 *
	 * @var extension_docs
	 */
	public static $extension_docs = null;

	/**
	 * Get Widget List.
	 *
	 * A widget that cannot work until credentials are entered carries an
	 * 'integration' key naming the Integration panel section that holds them.
	 * The Elements screen turns it into a link, and reports whether the section
	 * has been filled in — see PP_Settings_REST_Controller::integration_groups().
	 *
	 * @since 1.4.13.1
	 *
	 * @return array The Widget List.
	 */
	public static function get_widget_info() {
		if ( null === self::$widget_info ) {
			$utm_suffix = '?utm_source=widget&utm_medium=panel&utm_campaign=userkb';

			self::$widget_info = [
				'Content Elements'   => [
					'Advanced_Accordion'   => [
						'name'       => 'pp-advanced-accordion',
						'title'      => esc_html__( 'Advanced Accordion', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'icon'       => 'ppicon-advanced-accordion power-pack-admin-icon',
						'keywords'   => [ 'powerpack', 'accordion', 'advanced' ],
						'demo'       => 'https://powerpackelements.com/elementor-widgets/advanced-accordion/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/advanced-accordion/' . $utm_suffix,
						'preset'     => '5',
					],
					'Advanced_Menu'        => [
						'name'       => 'pp-advanced-menu',
						'title'      => esc_html__( 'Advanced Menu', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'menu', 'navigation' ],
						'icon'       => 'ppicon-advanced-menu power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/advanced-menu/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/advanced-menu/' . $utm_suffix,
					],
					'Advanced_Tabs'        => [
						'name'       => 'pp-advanced-tabs',
						'title'      => esc_html__( 'Advanced Tabs', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'tabs' ],
						'icon'       => 'ppicon-tabs power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/advanced-tab/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/advanced-tabs/' . $utm_suffix,
					],
					'Author_List'           => [
						'name'       => 'pp-author-list',
						'title'      => esc_html__( 'Author List', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'author', 'post', 'list' ],
						'icon'       => 'ppicon-author-list power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/author-list/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/author-list/' . $utm_suffix,
					],
					'Breadcrumbs'          => [
						'name'       => 'pp-breadcrumbs',
						'title'      => esc_html__( 'Breadcrumbs', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'breadcrumbs' ],
						'icon'       => 'ppicon-breadcrumbs power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/breadcrumbs/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/breadcrumbs/' . $utm_suffix,
					],
					'Business_Hours'       => [
						'name'       => 'pp-business-hours',
						'title'      => esc_html__( 'Business Hours', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'business', 'hours' ],
						'icon'       => 'ppicon-business-hours power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/business-hours/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/business-hours/' . $utm_suffix,
					],
					'Business_Reviews'       => [
						'name'        => 'pp-business-reviews',
						'title'       => esc_html__( 'Business Reviews', 'powerpack' ),
						'categories'  => [ 'Content Elements' ],
						'keywords'    => [ 'powerpack', 'business', 'reviews', 'google', 'yelp' ],
						'icon'        => 'ppicon-business-reviews power-pack-admin-icon',
						'integration' => 'business-reviews',
						'demo'        => 'https://powerpackelements.com/elementor-widgets/business-reviews/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/business-reviews-widget/' . $utm_suffix,
					],
					'Buttons'              => [
						'name'       => 'pp-buttons',
						'title'      => esc_html__( 'Buttons', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'buttons' ],
						'icon'       => 'ppicon-multi-buttons power-pack-admin-icon',
						'preset'     => '5',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/button-widget/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/buttons/' . $utm_suffix,
					],
					'Card_Slider'          => [
						'name'       => 'pp-card-slider',
						'title'      => esc_html__( 'Card Slider', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'posts', 'cpt', 'item', 'loop', 'query', 'cards', 'custom post type', 'slider' ],
						'icon'       => 'ppicon-card-slider power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/card-slider/' . $utm_suffix,
						'docs'       => '',
					],
					'Categories'           => [
						'name'       => 'pp-categories',
						'title'      => esc_html__( 'Categories', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'categories' ],
						'icon'       => 'ppicon-categories power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/categories/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/category-grid-slider/' . $utm_suffix,
					],
					'Content_Reveal'       => [
						'name'       => 'pp-content-reveal',
						'title'      => esc_html__( 'Content Reveal', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack' ],
						'icon'       => 'ppicon-content-reveal power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/content-reveal/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/content-reveal/' . $utm_suffix,
					],
					'Content_Ticker'       => [
						'name'       => 'pp-content-ticker',
						'title'      => esc_html__( 'Content Ticker', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'posts', 'cpt', 'item', 'loop', 'query', 'cards', 'custom post type', 'slider' ],
						'icon'       => 'ppicon-content-ticker power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/content-ticker/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/content-ticker/' . $utm_suffix,
					],
					'Coupons'              => [
						'name'       => 'pp-coupons',
						'title'      => esc_html__( 'Coupons', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'coupon' ],
						'icon'       => 'ppicon-coupons power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/coupon/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/coupons/' . $utm_suffix,
					],
					'Divider'              => [
						'name'       => 'pp-divider',
						'title'      => esc_html__( 'Divider', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'divider' ],
						'icon'       => 'ppicon-divider power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/divider/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/divider/' . $utm_suffix,
					],
					'Dual_Heading'         => [
						'name'       => 'pp-dual-heading',
						'title'      => esc_html__( 'Dual Heading', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'dual', 'heading' ],
						'icon'       => 'ppicon-dual-heading power-pack-admin-icon',
						'preset'     => '2',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/dual-heading/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/dual-heading/' . $utm_suffix,
					],
					'Event_Calendar'       => [
						'name'        => 'pp-event-calendar',
						'title'       => __( 'Event Calendar', 'powerpack' ),
						'categories'  => [ 'Content Elements' ],
						'keywords'    => [ 'powerpack', 'calendar', 'event', 'events', 'schedule', 'agenda', 'google calendar', 'gcal', 'fullcalendar' ],
						'icon'        => 'ppicon-calendar power-pack-admin-icon',
						'is_new'      => true,
						'default_off' => true,
						'integration' => 'event-calendar',
						'demo'        => 'https://powerpackelements.com/elementor-widgets/event-calendar/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/event-calendar/' . $utm_suffix,
					],
					'Faq'                  => [
						'name'       => 'pp-faq',
						'title'      => esc_html__( 'FAQ', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'faq' ],
						'icon'       => 'ppicon-faq power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/faq/' . $utm_suffix,
						'docs'       => '',
					],
					'How_To'               => [
						'name'        => 'pp-how-to',
						'title'       => esc_html__( 'How To', 'powerpack' ),
						'categories'  => [ 'Content Elements' ],
						'keywords'    => [ 'powerpack', 'how' ],
						'icon'        => 'ppicon-how-to power-pack-admin-icon',
						'default_off' => true,
						'demo'        => 'https://powerpackelements.com/elementor-widgets/how-to/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/how-to/' . $utm_suffix,
					],
					'Icon_List'            => [
						'name'       => 'pp-icon-list',
						'title'      => esc_html__( 'Icon List', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'icon', 'list' ],
						'icon'       => 'ppicon-icon-list power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/icon-list/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/icon-list/' . $utm_suffix,
					],
					'Info_Box'             => [
						'name'       => 'pp-info-box',
						'title'      => esc_html__( 'Info Box', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'info' ],
						'icon'       => 'ppicon-info-box power-pack-admin-icon',
						'preset'     => '5',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/info-box/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/info-box/' . $utm_suffix,
					],
					'Info_Box_Carousel'    => [
						'name'       => 'pp-info-box-carousel',
						'title'      => esc_html__( 'Info Grid & Carousel', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'info box' ],
						'icon'       => 'ppicon-info-box-carousel power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/info-box-carousel/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/info-box-carousel/' . $utm_suffix,
					],
					'Info_List'            => [
						'name'       => 'pp-info-list',
						'title'      => esc_html__( 'Info List', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'info' ],
						'icon'       => 'ppicon-info-list power-pack-admin-icon',
						'preset'     => '2',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/info-list/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/info-list/' . $utm_suffix,
					],
					'Info_Table'           => [
						'name'       => 'pp-info-table',
						'title'      => esc_html__( 'Info Table', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'info' ],
						'icon'       => 'ppicon-info-table power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/info-table/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/info-table/' . $utm_suffix,
					],
					'Login_Form'           => [
						'name'        => 'pp-login-form',
						'title'       => esc_html__( 'Login Form', 'powerpack' ),
						'categories'  => [ 'Content Elements' ],
						'keywords'    => [ 'login', 'form', 'user', 'sign in' ],
						'icon'        => 'ppicon-login-form power-pack-admin-icon',

						// Social sign-in, not reCAPTCHA. This widget can use
						// both, and one link is enough — the section named here
						// is the one that exists for this widget alone.
						'integration' => 'login-form',
						'demo'        => 'https://powerpackelements.com/elementor-widgets/login-form/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/login-form/' . $utm_suffix,
					],
					'Magazine_Slider'      => [
						'name'       => 'pp-magazine-slider',
						'title'      => esc_html__( 'Magazine Slider', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'posts', 'cpt', 'item', 'loop', 'query', 'cards', 'custom post type', 'slider' ],
						'icon'       => 'ppicon-magazine-slider power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/magazine-slider/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/magazine-slider/' . $utm_suffix,
					],
					'Marquee'      => [
						'name'       => 'pp-marquee',
						'title'      => __( 'Marquee', 'powerpack' ),
						'categories' => [ 'powerpack-elements' ],
						'keywords'   => [ 'powerpack', 'marquee', 'image', 'text', 'slider' ],
						'icon'       => 'ppicon-marquee power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/marquee/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/marquee/' . $utm_suffix,
					],
					'Offcanvas_Content'    => [
						'name'       => 'pp-offcanvas-content',
						'title'      => esc_html__( 'Offcanvas Content', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'offcanvas', 'off canvas' ],
						'icon'       => 'ppicon-offcanvas-content power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/offcanvas-content/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/off-canvas-content/' . $utm_suffix,
					],
					'Onepage_Nav'          => [
						'name'        => 'pp-one-page-nav',
						'title'       => esc_html__( 'One Page Navigation', 'powerpack' ),
						'categories'  => [ 'Content Elements' ],
						'keywords'    => [ 'powerpack', 'one', 'page', 'dot' ],
						'icon'        => 'ppicon-page-navigation power-pack-admin-icon',
						'default_off' => true,
						'demo'        => 'https://powerpackelements.com/elementor-widgets/one-page-navigation/' . $utm_suffix,
						'docs'        => '',
					],
					'Popup_Box'            => [
						'name'       => 'pp-modal-popup',
						'title'      => esc_html__( 'Popup Box', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'modal', 'popup' ],
						'icon'       => 'ppicon-popup-box power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/popup-box/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/modal-popup/' . $utm_suffix,
					],
					'Posts'                => [
						'name'       => 'pp-posts',
						'title'      => esc_html__( 'Advanced Posts', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'posts', 'cpt', 'item', 'loop', 'query', 'cards', 'custom post type' ],
						'icon'       => 'ppicon-posts-grid power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/posts/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/posts/' . $utm_suffix,
					],
					'Price_Menu'           => [
						'name'       => 'pp-price-menu',
						'title'      => esc_html__( 'Price Menu', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'price' ],
						'icon'       => 'ppicon-pricing-menu power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/pricing-menu/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/price-menu/' . $utm_suffix,
					],
					'Pricing_Table'        => [
						'name'       => 'pp-pricing-table',
						'title'      => esc_html__( 'Pricing Table', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'price table' ],
						'icon'       => 'ppicon-pricing-table power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/pricing-table/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/pricing-table/' . $utm_suffix,
					],
					'Promo_Box'            => [
						'name'       => 'pp-promo-box',
						'title'      => esc_html__( 'Promo Box', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'info' ],
						'icon'       => 'ppicon-promo-box power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/promo-box/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/promo-box/' . $utm_suffix,
					],
					'Recipe'               => [
						'name'       => 'pp-recipe',
						'title'      => esc_html__( 'Recipe', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'dish' ],
						'icon'       => 'ppicon-recipe power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/recipe/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/recipe/' . $utm_suffix,
					],
					'Registration_Form'    => [
						'name'        => 'pp-registration-form',
						'title'       => esc_html__( 'Registration Form', 'powerpack' ),
						'categories'  => [ 'Content Elements' ],
						'keywords'    => [ 'registration', 'form', 'user' ],
						'icon'        => 'ppicon-registration-form power-pack-admin-icon',
						'integration' => 'recaptcha',
						'demo'        => 'https://powerpackelements.com/elementor-widgets/registration-form/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/registration-form/' . $utm_suffix,
					],
					'Review_Box'           => [
						'name'       => 'pp-review-box',
						'title'      => esc_html__( 'Review Box', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'image' ],
						'icon'       => 'ppicon-review-box power-pack-admin-icon',
						'preset'     => '2',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/review-box/' . $utm_suffix,
						'docs'       => '',
					],
					'Sitemap'              => [
						'name'       => 'pp-sitemap',
						'title'      => esc_html__( 'Sitemap', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'sitemap' ],
						'icon'       => 'ppicon-sitemap power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/sitemap/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/sitemap/' . $utm_suffix,
					],
					'Slide_Menu'        => [
						'name'        => 'pp-slide-menu',
						'title'       => __( 'Slide Menu', 'powerpack' ),
						'categories'  => [ 'powerpack-elements' ],
						'keywords'    => [ 'powerpack', 'menu', 'navigation' ],
						'icon'        => 'ppicon-slide-menu power-pack-admin-icon',
						'is_new'      => true,
						'default_off' => true,
						'demo'       => 'https://powerpackelements.com/elementor-widgets/slide-menu/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/slide-menu/' . $utm_suffix,
					],
					'Table'                => [
						'name'       => 'pp-table',
						'title'      => esc_html__( 'Table', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'table', 'csv' ],
						'icon'       => 'ppicon-table power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/table/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/table/' . $utm_suffix,
					],
					'Table_Of_Contents'    => [
						'name'       => 'pp-table-of-contents',
						'title'      => esc_html__( 'Table of Contents', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'toc' ],
						'icon'       => 'ppicon-toc power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/table-of-content/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/table-of-contents/' . $utm_suffix,
					],
					'Team_Member'          => [
						'name'       => 'pp-team-member',
						'title'      => esc_html__( 'Team Member', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'team', 'member' ],
						'icon'       => 'ppicon-team-member power-pack-admin-icon',
						'preset'     => '4',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/team-member/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/team-member/' . $utm_suffix,
					],
					'Team_Member_Carousel' => [
						'name'       => 'pp-team-member-carousel',
						'title'      => esc_html__( 'Team Member Carousel', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'team', 'member', 'carousel' ],
						'icon'       => 'ppicon-team-member-carousel power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/team-member-carousel/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/team-member-carousel/' . $utm_suffix,
					],
					'Testimonials'         => [
						'name'       => 'pp-testimonials',
						'title'      => esc_html__( 'Testimonials', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'testimonials', 'reviews' ],
						'icon'       => 'ppicon-testimonial-carousel power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/testimonials/' . $utm_suffix,
						'docs'       => '',
					],
					'Tiled_Posts'          => [
						'name'       => 'pp-tiled-posts',
						'title'      => esc_html__( 'Tiled Posts', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'posts', 'cpt', 'item', 'loop', 'query', 'cards', 'custom post type' ],
						'icon'       => 'ppicon-tiled-post power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/tiled-post/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/tiled-posts/' . $utm_suffix,
					],
					'Timeline'             => [
						'name'       => 'pp-timeline',
						'title'      => esc_html__( 'Timeline', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack' ],
						'icon'       => 'ppicon-timeline power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/timeline/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/timeline/' . $utm_suffix,
					],
					'Toggle'               => [
						'name'       => 'pp-toggle',
						'title'      => esc_html__( 'Toggle', 'powerpack' ),
						'categories' => [ 'Content Elements' ],
						'keywords'   => [ 'powerpack', 'toggle', 'youtube', 'dailymotion' ],
						'icon'       => 'ppicon-content-toggle power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/content-toggle/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/toggle/' . $utm_suffix,
					],
				],
				'Media Elements'   => [
					'Album'                => [
						'name'       => 'pp-album',
						'title'      => esc_html__( 'Album', 'powerpack' ),
						'categories' => [ 'Media Elements' ],
						'keywords'   => [ 'powerpack', 'album', 'gallery', 'lightbox' ],
						'icon'       => 'ppicon-album power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/album/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/album/' . $utm_suffix,
					],
					'Devices'              => [
						'name'       => 'pp-devices',
						'title'      => esc_html__( 'Devices', 'powerpack' ),
						'categories' => [ 'Media Elements' ],
						'keywords'   => [ 'powerpack', 'devices' ],
						'icon'       => 'ppicon-device power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/devices/' . $utm_suffix,
						'docs'       => '',
					],
					'Image_Accordion'      => [
						'name'       => 'pp-image-accordion',
						'title'      => esc_html__( 'Image Accordion', 'powerpack' ),
						'categories' => [ 'Media Elements' ],
						'keywords'   => [ 'powerpack' ],
						'icon'       => 'ppicon-image-accordion power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/image-accordion/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/image-accordion/' . $utm_suffix,
					],
					'Image_Comparison'     => [
						'name'       => 'pp-image-comparison',
						'title'      => esc_html__( 'Image Comparison', 'powerpack' ),
						'categories' => [ 'Media Elements' ],
						'keywords'   => [ 'powerpack', 'image', 'comparison', 'before', 'after', 'slider' ],
						'icon'       => 'ppicon-image-comparison power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/image-comparison/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/image-comparison/' . $utm_suffix,
					],
					'Image_Gallery'        => [
						'name'       => 'pp-image-gallery',
						'title'      => esc_html__( 'Image Gallery', 'powerpack' ),
						'categories' => [ 'Media Elements' ],
						'keywords'   => [ 'powerpack', 'image', 'gallery' ],
						'icon'       => 'ppicon-image-gallery power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/image-gallery/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/image-gallery/' . $utm_suffix,
					],
					'Image_Slider'         => [
						'name'       => 'pp-image-slider',
						'title'      => esc_html__( 'Image Slider', 'powerpack' ),
						'categories' => [ 'Media Elements' ],
						'keywords'   => [ 'powerpack', 'image', 'slider', 'slideshow', 'gallery', 'thumbnail', 'carousel', 'image carousel' ],
						'icon'       => 'ppicon-gallery-slider power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/image-slider/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/image-slider/' . $utm_suffix,
					],
					'Random_Image'         => [
						'name'       => 'pp-random-image',
						'title'      => esc_html__( 'Random Image', 'powerpack' ),
						'categories' => [ 'Media Elements' ],
						'keywords'   => [ 'powerpack', 'image' ],
						'icon'       => 'ppicon-random-image power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/random-image/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/random-image/' . $utm_suffix,
					],
					'Scroll_Image'         => [
						'name'        => 'pp-scroll-image',
						'title'       => esc_html__( 'Scroll Image', 'powerpack' ),
						'categories'  => [ 'Media Elements' ],
						'keywords'    => [ 'powerpack', 'image' ],
						'icon'        => 'ppicon-scroll-image power-pack-admin-icon',
						'default_off' => true,
						'demo'        => 'https://powerpackelements.com/elementor-widgets/scroll-image/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/scroll-image/' . $utm_suffix,
					],
					'Showcase'             => [
						'name'       => 'pp-showcase',
						'title'      => esc_html__( 'Showcase', 'powerpack' ),
						'categories' => [ 'Media Elements' ],
						'keywords'   => [ 'powerpack', 'image', 'video', 'embed', 'youtube', 'vimeo', 'dailymotion', 'slider' ],
						'icon'       => 'ppicon-showcase power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/showcase-widget/' . $utm_suffix,
						'docs'       => '',
					],
					'Tabbed_Gallery'       => [
						'name'        => 'pp-tabbed-gallery',
						'title'       => esc_html__( 'Tabbed Gallery', 'powerpack' ),
						'categories'  => [ 'Media Elements' ],
						'keywords'    => [ 'powerpack', 'image', 'gallery', 'carousel', 'tab', 'slider' ],
						'icon'        => 'ppicon-tabbed-gallery power-pack-admin-icon',
						'default_off' => true,
						'demo'        => 'https://powerpackelements.com/elementor-widgets/tabbed-gallery/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/tabbed-gallery/' . $utm_suffix,
					],
					'Video'                => [
						'name'       => 'pp-video',
						'title'      => esc_html__( 'Video', 'powerpack' ),
						'categories' => [ 'Media Elements' ],
						'keywords'   => [ 'powerpack', 'video', 'youtube', 'dailymotion' ],
						'icon'       => 'ppicon-video power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/video/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/video/' . $utm_suffix,
					],
					'Video_Gallery'        => [
						'name'        => 'pp-video-gallery',
						'title'       => esc_html__( 'Video Gallery', 'powerpack' ),
						'categories'  => [ 'Media Elements' ],
						'keywords'    => [ 'powerpack', 'video', 'youtube', 'dailymotion' ],
						'icon'        => 'ppicon-video-gallery power-pack-admin-icon',
						'integration' => 'video-gallery',
						'demo'        => 'https://powerpackelements.com/elementor-widgets/video-gallery/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/video-gallery/' . $utm_suffix,
					],
				],
				'Creative Elements'   => [
					'Charts'      => [
						'name'       => 'pp-charts',
						'title'      => __( 'Advanced Charts', 'powerpack' ),
						'categories' => [ 'Creative Elements' ],
						'keywords'   => [ 'powerpack', 'chart', 'graph' ],
						'icon'       => 'ppicon-advanced-charts power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/advanced-charts/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/advanced-charts/' . $utm_suffix,
					],
					'Countdown'            => [
						'name'       => 'pp-countdown',
						'title'      => esc_html__( 'Countdown Timer', 'powerpack' ),
						'categories' => [ 'Creative Elements' ],
						'keywords'   => [ 'powerpack', 'countdown', 'timer' ],
						'icon'       => 'ppicon-countdown power-pack-admin-icon',
						'preset'     => '4',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/countdown/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/countdown-timer/' . $utm_suffix,
					],
					'Counter'              => [
						'name'       => 'pp-counter',
						'title'      => esc_html__( 'Counter', 'powerpack' ),
						'categories' => [ 'Creative Elements' ],
						'keywords'   => [ 'powerpack', 'counter' ],
						'icon'       => 'ppicon-counter power-pack-admin-icon',
						'preset'     => '3',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/counter/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/counter/' . $utm_suffix,
					],
					'Fancy_Heading'        => [
						'name'       => 'pp-fancy-heading',
						'title'      => esc_html__( 'Fancy Heading', 'powerpack' ),
						'categories' => [ 'Creative Elements' ],
						'keywords'   => [ 'powerpack', 'fancy', 'heading' ],
						'icon'       => 'ppicon-heading power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/fancy-heading/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/fancy-heading/' . $utm_suffix,
					],
					'Flipbox'              => [
						'name'       => 'pp-flipbox',
						'title'      => esc_html__( 'Flip Box', 'powerpack' ),
						'categories' => [ 'Creative Elements' ],
						'keywords'   => [ 'powerpack', 'flip', 'box', 'flipbox' ],
						'icon'       => 'ppicon-flip-box power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/flip-box/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/flip-box/' . $utm_suffix,
					],
					'Google_Maps'          => [
						'name'        => 'pp-google-maps',
						'title'       => esc_html__( 'Google Maps', 'powerpack' ),
						'categories'  => [ 'Creative Elements' ],
						'keywords'    => [ 'powerpack', 'google', 'maps' ],
						'icon'        => 'ppicon-map power-pack-admin-icon',
						'integration' => 'google-maps',
						'demo'        => 'https://powerpackelements.com/elementor-widgets/google-map/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/google-maps/' . $utm_suffix,
					],
					'Hotspots'             => [
						'name'       => 'pp-image-hotspots',
						'title'      => esc_html__( 'Image Hotspots', 'powerpack' ),
						'categories' => [ 'powerpack-elements' ],
						'keywords'   => [ 'powerpack', 'image', 'hotspots' ],
						'icon'       => 'ppicon-image-hotspot power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/image-hotspot/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/image-hotspots/' . $utm_suffix,
					],
					'Interactive_Circle'   => [
						'name'        => 'pp-interactive-circle',
						'title'       => __( 'Interactive Circle', 'powerpack' ),
						'categories'  => [ 'Creative Elements' ],
						'keywords'    => [ 'powerpack', 'interactive circle', 'circle' ],
						'icon'        => 'ppicon-interactive-circle power-pack-admin-icon',
						'default_off' => true,
						'demo'        => 'https://powerpackelements.com/elementor-widgets/interactive-circle/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/interactive-circle/' . $utm_suffix,
					],
					'Link_Effects'         => [
						'name'        => 'pa-link-effects',
						'title'       => esc_html__( 'Link Effects', 'powerpack' ),
						'categories'  => [ 'powerpack-elements' ],
						'keywords'    => [ 'powerpack' ],
						'icon'        => 'ppicon-link-effects power-pack-admin-icon',
						'default_off' => true,
						'demo'        => 'https://powerpackelements.com/elementor-widgets/link-effects/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/link-effects/' . $utm_suffix,
					],
					'Logo_Carousel'        => [
						'name'       => 'pp-logo-carousel',
						'title'      => esc_html__( 'Logo Carousel', 'powerpack' ),
						'categories' => [ 'Creative Elements' ],
						'keywords'   => [ 'powerpack', 'logo', 'carousel', 'image' ],
						'icon'       => 'ppicon-logo-carousel power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/logo-carousel/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/logo-carousel/' . $utm_suffix,
					],
					'Logo_Grid'            => [
						'name'       => 'pp-logo-grid',
						'title'      => esc_html__( 'Logo Grid', 'powerpack' ),
						'categories' => [ 'Creative Elements' ],
						'keywords'   => [ 'powerpack', 'logo', 'image' ],
						'icon'       => 'ppicon-logo-grid power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/elementor-widgets/logo-grid/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/logo-grid/' . $utm_suffix,
					],
					'Progress_Bar'         => [
						'name'        => 'pp-progress-bar',
						'title'       => __( 'Progress Bar', 'powerpack' ),
						'categories'  => [ 'Creative Elements' ],
						'keywords'    => [ 'powerpack', 'chart', 'counter' ],
						'icon'        => 'ppicon-progress-bar power-pack-admin-icon',
						'default_off' => true,
						'demo'        => 'https://powerpackelements.com/elementor-widgets/progress-bar/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/progress-bar/' . $utm_suffix,
					],
				],
				'Social Media Elements'   => [
					'Instafeed'            => [
						'name'        => 'pp-instafeed',
						'title'       => esc_html__( 'Instagram Feed', 'powerpack' ),
						'categories'  => [ 'Social Media Elements' ],
						'keywords'    => [ 'powerpack', 'instagram' ],
						'icon'        => 'ppicon-instagram-feed power-pack-admin-icon',
						'integration' => 'instagram-feed',
						'demo'        => 'https://powerpackelements.com/elementor-widgets/instagram-feed/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/instagram-feed/' . $utm_suffix,
					],
					'Twitter_Buttons'      => [
						'name'        => 'pp-twitter-buttons',
						'title'       => esc_html__( 'Twitter Buttons', 'powerpack' ),
						'categories'  => [ 'Social Media Elements' ],
						'keywords'    => [ 'powerpack' ],
						'icon'        => 'ppicon-twitter-buttons power-pack-admin-icon',
						'default_off' => true,
						'demo'        => 'https://powerpackelements.com/elementor-widgets/twitter-widget/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/twitter/' . $utm_suffix,
					],
					'Twitter_Grid'         => [
						'name'        => 'pp-twitter-grid',
						'title'       => esc_html__( 'Twitter Grid', 'powerpack' ),
						'categories'  => [ 'Social Media Elements' ],
						'keywords'    => [ 'powerpack' ],
						'icon'        => 'ppicon-twitter-grid power-pack-admin-icon',
						'default_off' => true,
						'demo'        => 'https://powerpackelements.com/elementor-widgets/twitter-widget/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/twitter/' . $utm_suffix,
					],
					'Twitter_Timeline'     => [
						'name'        => 'pp-twitter-timeline',
						'title'       => esc_html__( 'Twitter Timeline', 'powerpack' ),
						'categories'  => [ 'Social Media Elements' ],
						'keywords'    => [ 'powerpack' ],
						'icon'        => 'ppicon-twitter-timeline power-pack-admin-icon',
						'default_off' => true,
						'demo'        => 'https://powerpackelements.com/elementor-widgets/twitter-widget/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/twitter/' . $utm_suffix,
					],
					'Twitter_Tweet'        => [
						'name'        => 'pp-twitter-tweet',
						'title'       => esc_html__( 'Twitter Tweet', 'powerpack' ),
						'categories'  => [ 'Social Media Elements' ],
						'keywords'    => [ 'powerpack' ],
						'icon'        => 'ppicon-twitter-tweet power-pack-admin-icon',
						'default_off' => true,
						'demo'        => 'https://powerpackelements.com/elementor-widgets/twitter-widget/' . $utm_suffix,
						'docs'        => 'https://powerpackelements.com/doc-category/twitter/' . $utm_suffix,
					],
				],
			];

			// Form Styler Elements - conditionally added based on active form plugins.
			$form_widgets = [];

			// Contact Form 7.
			if ( function_exists( 'wpcf7' ) ) {
				$form_widgets['Contact_Form_7'] = [
					'name'       => 'pp-contact-form-7',
					'title'      => esc_html__( 'Contact Form 7', 'powerpack' ),
					'categories' => [ 'Form Styler Elements' ],
					'keywords'   => [ 'powerpack', 'contact', 'form' ],
					'icon'       => 'ppicon-contact-form-7 power-pack-admin-icon',
					'demo'       => 'https://powerpackelements.com/elementor-widgets/contact-forms-7/' . $utm_suffix,
					'docs'       => 'https://powerpackelements.com/doc-category/contact-form-7-styler/' . $utm_suffix,
				];
			}

			// Fluent Forms.
			if ( function_exists( 'wpFluentForm' ) ) {
				$form_widgets['Fluent_Forms'] = [
					'name'       => 'pp-fluent-forms',
					'title'      => esc_html__( 'Fluent Forms', 'powerpack' ),
					'categories' => [ 'Form Styler Elements' ],
					'keywords'   => [ 'powerpack', 'contact', 'form' ],
					'icon'       => 'ppicon-fluent-forms power-pack-admin-icon',
					'demo'       => 'https://powerpackelements.com/elementor-widgets/wp-fluent-forms/' . $utm_suffix,
					'docs'       => 'https://powerpackelements.com/doc-category/fluent-forms-styler/' . $utm_suffix,
				];
			}

			// Formidable Forms.
			if ( class_exists( 'FrmForm' ) ) {
				$form_widgets['Formidable_Forms'] = [
					'name'       => 'pp-formidable-forms',
					'title'      => esc_html__( 'Formidable Forms', 'powerpack' ),
					'categories' => [ 'Form Styler Elements' ],
					'keywords'   => [ 'powerpack', 'contact', 'form' ],
					'icon'       => 'ppicon-formidable-forms power-pack-admin-icon',
					'demo'       => 'https://powerpackelements.com/elementor-widgets/formidable-forms/' . $utm_suffix,
					'docs'       => 'https://powerpackelements.com/doc-category/formidable-forms-styler/' . $utm_suffix,
				];
			}

			// Gravity Forms.
			if ( class_exists( 'GFCommon' ) ) {
				$form_widgets['Gravity_Forms'] = [
					'name'       => 'pp-gravity-forms',
					'title'      => esc_html__( 'Gravity Forms', 'powerpack' ),
					'categories' => [ 'Form Styler Elements' ],
					'keywords'   => [ 'powerpack', 'contact', 'form' ],
					'icon'       => 'ppicon-gravity-forms power-pack-admin-icon',
					'demo'       => 'https://powerpackelements.com/elementor-widgets/gravity-forms/' . $utm_suffix,
					'docs'       => 'https://powerpackelements.com/doc-category/gravity-forms-styler/' . $utm_suffix,
				];
			}

			// Ninja Forms.
			if ( class_exists( 'Ninja_Forms' ) ) {
				$form_widgets['Ninja_Forms'] = [
					'name'       => 'pp-ninja-forms',
					'title'      => esc_html__( 'Ninja Forms', 'powerpack' ),
					'categories' => [ 'Form Styler Elements' ],
					'keywords'   => [ 'powerpack', 'contact', 'form' ],
					'icon'       => 'ppicon-ninja-forms power-pack-admin-icon',
					'demo'       => 'https://powerpackelements.com/elementor-widgets/ninja-forms/' . $utm_suffix,
					'docs'       => 'https://powerpackelements.com/doc-category/ninja-forms-styler/' . $utm_suffix,
				];
			}

			// WPForms.
			if ( class_exists( 'WPForms_Pro' ) || class_exists( 'WPForms_Lite' ) ) {
				$form_widgets['WP_Forms'] = [
					'name'       => 'pp-wpforms',
					'title'      => esc_html__( 'WP Forms', 'powerpack' ),
					'categories' => [ 'Form Styler Elements' ],
					'keywords'   => [ 'powerpack', 'contact', 'form', 'wpforms' ],
					'icon'       => 'ppicon-wpforms power-pack-admin-icon',
					'demo'       => 'https://powerpackelements.com/elementor-widgets/wpforms/' . $utm_suffix,
					'docs'       => 'https://powerpackelements.com/doc-category/wpforms-styler/',
				];
			}

			if ( ! empty( $form_widgets ) ) {
				self::$widget_info['Form Styler Elements'] = $form_widgets;
			}

			// WooCommerce Elements - only added if WooCommerce is active.
			if ( is_pp_woocommerce() ) {
				self::$widget_info['WooCommerce Elements'] = [
					'Woo_Add_To_Cart'    => [
						'name'       => 'pp-woo-add-to-cart',
						'title'      => esc_html__( 'Woo - Add To Cart', 'powerpack' ),
						'categories' => [ 'powerpack-woocommerce' ],
						'keywords'   => [ 'powerpack', 'woocommerce' ],
						'icon'       => 'ppicon-woo-add-to-cart power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/woocommerce-elementor-widgets/add-to-cart-button/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/woo-add-to-cart/' . $utm_suffix,
					],
					'Woo_Cart'           => [
						'name'       => 'pp-woo-cart',
						'title'      => esc_html__( 'Woo - Cart', 'powerpack' ),
						'categories' => [ 'powerpack-woocommerce' ],
						'keywords'   => [ 'powerpack', 'woocommerce' ],
						'icon'       => 'ppicon-woo-cart power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/woocommerce-elementor-widgets/cart-widget/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/woo-cart/' . $utm_suffix,
					],
					'Woo_Categories'     => [
						'name'       => 'pp-woo-categories',
						'title'      => esc_html__( 'Woo - Categories', 'powerpack' ),
						'categories' => [ 'powerpack-woocommerce' ],
						'keywords'   => [ 'powerpack', 'woocommerce', 'category' ],
						'icon'       => 'ppicon-woo-categories power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/woocommerce-elementor-widgets/categories-widget/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/woo-categories/' . $utm_suffix,
					],
					'Woo_Checkout'       => [
						'name'       => 'pp-woo-checkout',
						'title'      => esc_html__( 'Woo - Checkout', 'powerpack' ),
						'categories' => [ 'powerpack-woocommerce' ],
						'keywords'   => [ 'powerpack', 'woocommerce' ],
						'icon'       => 'ppicon-woo-checkout power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/woocommerce-elementor-widgets/checkout-widget/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/woo-checkout/' . $utm_suffix,
					],
					'Woo_Mini_Cart'      => [
						'name'       => 'pp-woo-mini-cart',
						'title'      => esc_html__( 'Woo - Mini Cart', 'powerpack' ),
						'categories' => [ 'powerpack-woocommerce' ],
						'keywords'   => [ 'powerpack', 'woocommerce' ],
						'icon'       => 'ppicon-mini-cart power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/woocommerce-elementor-widgets/mini-cart-widget/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/mini-cart/' . $utm_suffix,
					],
					'Woo_Offcanvas_Cart' => [
						'name'       => 'pp-woo-offcanvas-cart',
						'title'      => esc_html__( 'Woo - Off Canvas Cart', 'powerpack' ),
						'categories' => [ 'powerpack-woocommerce' ],
						'keywords'   => [ 'powerpack', 'woocommerce', 'offcanvas' ],
						'icon'       => 'ppicon-offcanvas-cart power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/woocommerce-elementor-widgets/off-canvas-cart-widget/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/off-canvas-cart/' . $utm_suffix,
					],
					'Woo_Products'       => [
						'name'       => 'pp-woo-products',
						'title'      => esc_html__( 'Woo - Products', 'powerpack' ),
						'categories' => [ 'powerpack-woocommerce' ],
						'keywords'   => [ 'powerpack', 'woocommerce' ],
						'icon'       => 'ppicon-woo-products power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/woocommerce-elementor-widgets/product-grid/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/woo-products/' . $utm_suffix,
					],
					'Woo_My_Account'     => [
						'name'       => 'pp-woo-my-account',
						'title'      => esc_html__( 'Woo - My Account', 'powerpack' ),
						'categories' => [ 'powerpack-woocommerce' ],
						'keywords'   => [ 'powerpack', 'woocommerce' ],
						'icon'       => 'ppicon-my-account power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/woocommerce-elementor-widgets/my-account-widget/' . $utm_suffix,
						'docs'       => 'https://powerpackelements.com/doc-category/woo-my-account/' . $utm_suffix,
					],
					'Woo_Single_Product' => [
						'name'       => 'pp-woo-single-product',
						'title'      => esc_html__( 'Woo - Single Product', 'powerpack' ),
						'categories' => [ 'powerpack-woocommerce' ],
						'keywords'   => [ 'powerpack', 'woocommerce' ],
						'icon'       => 'ppicon-woo-single-product power-pack-admin-icon',
						'demo'       => 'https://powerpackelements.com/woocommerce-elementor-widgets/single-product/' . $utm_suffix,
						'docs'       => '',
					],
				];

				/*
				 * WooCommerce builder widgets - only added if the builder is
				 * enabled. Listed as a group of their own rather than folded in
				 * with the store widgets above because they need a product in
				 * context and so only work inside a Single Product or Product
				 * Archive template, which is also why they are switched on
				 * together with the builder rather than one at a time.
				 */
				if ( get_option( 'pp_woo_builder_enable' ) ) {
					self::$widget_info['WooCommerce Builder Elements'] = [
						'Woo_Product_Tabs'              => [
							'name'       => 'pp-woo-product-tabs',
							'title'      => esc_html__( 'Woo - Product Tabs', 'powerpack' ),
							'categories' => [ 'powerpack-woocommerce-builder' ],
							'keywords'   => [ 'powerpack', 'woocommerce' ],
							'icon'       => 'ppicon-product-tabs power-pack-admin-icon',
							'demo'       => 'https://powerpackelements.com/woocommerce-builder/' . $utm_suffix,
							'docs'       => 'https://powerpackelements.com/doc-category/woobuilder/' . $utm_suffix,
						],
						'Woo_Product_Title'             => [
							'name'       => 'pp-woo-product-title',
							'title'      => esc_html__( 'Woo - Product Title', 'powerpack' ),
							'categories' => [ 'powerpack-woocommerce-builder' ],
							'keywords'   => [ 'powerpack', 'woocommerce' ],
							'icon'       => 'ppicon-product-title power-pack-admin-icon',
							'demo'       => 'https://powerpackelements.com/woocommerce-builder/' . $utm_suffix,
							'docs'       => 'https://powerpackelements.com/doc-category/woobuilder/' . $utm_suffix,
						],
						'Woo_Product_Meta'              => [
							'name'       => 'pp-woo-product-meta',
							'title'      => esc_html__( 'Woo - Product Meta', 'powerpack' ),
							'categories' => [ 'powerpack-woocommerce-builder' ],
							'keywords'   => [ 'powerpack', 'woocommerce' ],
							'icon'       => 'ppicon-product-meta power-pack-admin-icon',
							'demo'       => 'https://powerpackelements.com/woocommerce-builder/' . $utm_suffix,
							'docs'       => 'https://powerpackelements.com/doc-category/woobuilder/' . $utm_suffix,
						],
						'Woo_Product_Price'             => [
							'name'       => 'pp-woo-product-price',
							'title'      => esc_html__( 'Woo - Product Price', 'powerpack' ),
							'categories' => [ 'powerpack-woocommerce-builder' ],
							'keywords'   => [ 'powerpack', 'woocommerce' ],
							'icon'       => 'ppicon-product-price power-pack-admin-icon',
							'demo'       => 'https://powerpackelements.com/woocommerce-builder/' . $utm_suffix,
							'docs'       => 'https://powerpackelements.com/doc-category/woobuilder/' . $utm_suffix,
						],
						'Woo_Product_Rating'            => [
							'name'       => 'pp-woo-product-rating',
							'title'      => esc_html__( 'Woo - Product Rating', 'powerpack' ),
							'categories' => [ 'powerpack-woocommerce-builder' ],
							'keywords'   => [ 'powerpack', 'woocommerce' ],
							'icon'       => 'ppicon-product-rating power-pack-admin-icon',
							'demo'       => 'https://powerpackelements.com/woocommerce-builder/' . $utm_suffix,
							'docs'       => 'https://powerpackelements.com/doc-category/woobuilder/' . $utm_suffix,
						],
						'Woo_Product_Stock'             => [
							'name'       => 'pp-woo-product-stock',
							'title'      => esc_html__( 'Woo - Product Stock', 'powerpack' ),
							'categories' => [ 'powerpack-woocommerce-builder' ],
							'keywords'   => [ 'powerpack', 'woocommerce' ],
							'icon'       => 'ppicon-product-stock power-pack-admin-icon',
							'demo'       => 'https://powerpackelements.com/woocommerce-builder/' . $utm_suffix,
							'docs'       => 'https://powerpackelements.com/doc-category/woobuilder/' . $utm_suffix,
						],
						'Woo_Product_Short_Description' => [
							'name'       => 'pp-woo-product-short-description',
							'title'      => esc_html__( 'Woo - Product Short Description', 'powerpack' ),
							'categories' => [ 'powerpack-woocommerce-builder' ],
							'keywords'   => [ 'powerpack', 'woocommerce' ],
							'icon'       => 'ppicon-product-short-desc power-pack-admin-icon',
							'demo'       => 'https://powerpackelements.com/woocommerce-builder/' . $utm_suffix,
							'docs'       => 'https://powerpackelements.com/doc-category/woobuilder/' . $utm_suffix,
						],
						'Woo_Product_Content'           => [
							'name'       => 'pp-woo-product-content',
							'title'      => esc_html__( 'Woo - Product Content', 'powerpack' ),
							'categories' => [ 'powerpack-woocommerce-builder' ],
							'keywords'   => [ 'powerpack', 'woocommerce' ],
							'icon'       => 'ppicon-product-content power-pack-admin-icon',
							'demo'       => 'https://powerpackelements.com/woocommerce-builder/' . $utm_suffix,
							'docs'       => 'https://powerpackelements.com/doc-category/woobuilder/' . $utm_suffix,
						],
						'Woo_Product_Images'            => [
							'name'       => 'pp-woo-product-images',
							'title'      => esc_html__( 'Woo - Product Images', 'powerpack' ),
							'categories' => [ 'powerpack-woocommerce-builder' ],
							'keywords'   => [ 'powerpack', 'woocommerce' ],
							'icon'       => 'ppicon-product-images power-pack-admin-icon',
							'demo'       => 'https://powerpackelements.com/woocommerce-builder/' . $utm_suffix,
							'docs'       => 'https://powerpackelements.com/doc-category/woobuilder/' . $utm_suffix,
						],
						'Woo_Product_Reviews'           => [
							'name'       => 'pp-woo-product-reviews',
							'title'      => esc_html__( 'Woo - Product Reviews', 'powerpack' ),
							'categories' => [ 'powerpack-woocommerce-builder' ],
							'keywords'   => [ 'powerpack', 'woocommerce' ],
							'icon'       => 'ppicon-product-reviews power-pack-admin-icon',
							'demo'       => 'https://powerpackelements.com/woocommerce-builder/' . $utm_suffix,
							'docs'       => 'https://powerpackelements.com/doc-category/woobuilder/' . $utm_suffix,
						],
						'Woo_Product_Upsell'            => [
							'name'       => 'pp-woo-product-upsell',
							'title'      => esc_html__( 'Woo - Product Upsell', 'powerpack' ),
							'categories' => [ 'powerpack-woocommerce-builder' ],
							'keywords'   => [ 'powerpack', 'woocommerce' ],
							'icon'       => 'ppicon-product-upsell power-pack-admin-icon',
							'demo'       => 'https://powerpackelements.com/woocommerce-builder/' . $utm_suffix,
							'docs'       => 'https://powerpackelements.com/doc-category/woobuilder/' . $utm_suffix,
						],
						'Woo_Add_To_Cart_Notification'  => [
							'name'       => 'pp-woo-add-to-cart-notification',
							'title'      => esc_html__( 'Woo - Add to Cart Notification', 'powerpack' ),
							'categories' => [ 'powerpack-woocommerce-builder' ],
							'keywords'   => [ 'powerpack', 'woocommerce' ],
							'icon'       => 'ppicon-woo-add-to-cart-notification power-pack-admin-icon',
							'demo'       => 'https://powerpackelements.com/woocommerce-builder/' . $utm_suffix,
							'docs'       => 'https://powerpackelements.com/doc-category/woobuilder/' . $utm_suffix,
						],
						'Woo_Archive_Description'       => [
							'name'       => 'pp-woo-archive-description',
							'title'      => esc_html__( 'Woo - Archive Description', 'powerpack' ),
							'categories' => [ 'powerpack-woocommerce-builder' ],
							'keywords'   => [ 'powerpack', 'woocommerce' ],
							'icon'       => 'ppicon-woo-archive-description power-pack-admin-icon',
							'demo'       => 'https://powerpackelements.com/woocommerce-builder/' . $utm_suffix,
							'docs'       => 'https://powerpackelements.com/doc-category/woobuilder/' . $utm_suffix,
						],
					];
				}
			}
		}

		return apply_filters( 'pp_elements_widget_info', self::$widget_info );
	}

	/**
	 * Get the documentation URL for each extension.
	 *
	 * Keyed the way pp_get_extensions() keys its list. An extension registered
	 * through the 'pp_elements_extensions' filter has no entry here and simply
	 * shows no link, so the two lists never have to be kept in step.
	 *
	 * @since 3.0.0
	 *
	 * @return array Extension slug => documentation URL.
	 */
	public static function get_extension_docs() {
		if ( null === self::$extension_docs ) {
			$utm_suffix = '?utm_source=widget&utm_medium=panel&utm_campaign=userkb';
			$base       = 'https://powerpackelements.com/doc-category/';

			// Doc category slugs, which do not all match the extension slug.
			$slugs = [
				'pp-display-conditions'           => 'display-conditions',
				'pp-background-effects'           => 'background-effects',
				'pp-animated-gradient-background' => 'animated-gradient-background',
				'pp-wrapper-link'                 => 'wrapper-link',
				'pp-custom-cursor'                => 'custom-cursor',
				'pp-tooltips'                     => 'tooltip',
				'pp-presets-style'                => 'presets',
				'pp-magic-wand'                   => 'magic-wand',
			];

			self::$extension_docs = [];

			foreach ( $slugs as $extension => $slug ) {
				self::$extension_docs[ $extension ] = $base . $slug . '/' . $utm_suffix;
			}
		}

		return apply_filters( 'pp_elements_extension_docs', self::$extension_docs );
	}

	/**
	 * Get widget style files
	 *
	 * @return array list of css files.
	 */
	public static function get_widget_style() {
		$debug_suffix     = ( PP_Helper::is_script_debug() ) ? '' : '.min';
		$direction_suffix = is_rtl() ? '-rtl' : '';
		$suffix           = $direction_suffix . $debug_suffix;

		if ( PP_Helper::is_script_debug() ) {
			$path = 'assets/css/';
		} else {
			$path = 'assets/css/min/';
		}

		$css_files = [
			'powerpack-frontend' => [
				'path' => $path . 'frontend' . $suffix . '.css',
				'dep'  => [],
			],
		];

		return $css_files;
	}

	/**
	 * Widgets with styles.
	 *
	 * This method returns the list of all the PowerPack widgets
	 * that have styles.
	 *
	 * @since 2.11.0
	 * @access public
	 *
	 * @return array The names of the widgets that have styles.
	 */
	public static function widgets_with_styles(): array {
		return [
			'advanced-accordion',
			'author-list',
			'breadcrumbs',
			'business-hours',
			'business-reviews',
			'categories',
			'contact-form-7',
			'content-reveal',
			'counter',
			'coupons',
			'devices',
			'divider',
			'fancy-heading',
			'flipbox',
			'fluent-forms',
			'formidable-forms',
			'google-maps',
			'gravity-forms',
			'info-table',
			'instagram-feed',
			'link-effects',
			'login-form',
			'logo-carousel',
			'logo-grid',
			'modal-popup',
			'ninja-forms',
			'off-canvas-content',
			'one-page-nav',
			'price-menu',
			'pricing-table',
			'promo-box',
			'random-image',
			'registration-form',
			'review-box',
			'scroll-image',
			'sitemap',
			'tabbed-gallery',
			'table',
			'team-member',
			'testimonials',
			'toggle',
			'video',
			'video-gallery',
			// 'divider',
			'advanced-menu',
			'advanced-tabs',
			'album',
			'buttons',
			'card-slider',
			'content-ticker',
			'countdown',
			'hotspots',
			'how-to',
			'image-accordion',
			'image-gallery',
			'image-slider',
			'info-box',
			'info-list',
			'posts',
			'recipe-card',
			'showcase',
			'tiled-posts',
			'timeline',
			'toc',
		];
	}

	/**
	 * Widgets with responsive styles.
	 *
	 * This method returns the list of all the PowerPack widgets
	 * that have responsive styles.
	 *
	 * @since 2.11.0
	 * @access public
	 *
	 * @return array The names of the widgets that have responsive styles.
	 */
	public static function widgets_with_responsive_styles(): array {
		return [
			'advanced-menu',
			'advanced-tabs',
			'album',
			'buttons',
			'card-slider',
			'content-ticker',
			'countdown',
			'hotspots',
			'how-to',
			'image-accordion',
			'image-gallery',
			'image-slider',
			'info-box',
			'info-list',
			'posts',
			'recipe-card',
			'showcase',
			'tiled-posts',
			'timeline',
			'toc',
		];
	}
}
