<?php
/**
 * PowerPack Command Palette Integration
 *
 * Puts the plugin's screens into the WordPress Command Palette, the admin-wide
 * Ctrl/Cmd + K search.
 *
 * @package PowerpackElements
 * @since 3.0.0
 */

namespace PowerpackElements\Classes;

/**
 * Class PP_Command_Palette
 *
 * Handles the registration and enqueuing of command palette scripts
 *
 * @since 3.0.0
 */
class PP_Command_Palette {

	/**
	 * Instance
	 *
	 * @var PP_Command_Palette|null
	 * @since 3.0.0
	 */
	private static $instance = null;

	/**
	 * Get Instance
	 *
	 * @since 3.0.0
	 * @return PP_Command_Palette
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 *
	 * @since 3.0.0
	 */
	private function __construct() {
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_command_palette_scripts' ] );
	}

	/**
	 * Enqueue Command Palette Scripts
	 *
	 * Loads the JavaScript file that registers PowerPack commands with WordPress Command Palette
	 *
	 * @since 3.0.0
	 * @return void
	 */
	public function enqueue_command_palette_scripts() {
		// The settings screen every one of these commands leads to is registered
		// under this capability, so anyone who cannot open it is offered nothing.
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		/*
		 * The palette ships with WordPress, but only reached every admin screen
		 * in 6.9. Asking whether its script is registered says the same thing as
		 * comparing version numbers and goes on being true if the package is
		 * ever backported or moved.
		 */
		if ( ! wp_script_is( 'wp-commands', 'registered' ) ) {
			return;
		}

		$commands = $this->get_commands();

		if ( empty( $commands ) ) {
			return;
		}

		$path = PP_Helper::is_script_debug() ? 'assets/js/pp-command-palette.js' : 'assets/js/min/pp-command-palette.min.js';

		wp_enqueue_script(
			'pp-command-palette',
			POWERPACK_ELEMENTS_URL . $path,
			[ 'wp-commands', 'wp-data' ],
			POWERPACK_ELEMENTS_VER,
			true
		);

		wp_localize_script(
			'pp-command-palette',
			'ppCommandPalette',
			[ 'commands' => $commands ]
		);
	}

	/**
	 * The commands to register, after white label has had its say.
	 *
	 * Each entry carries a finished label and a destination, and the script does
	 * no more than hand them to the palette. Two reasons the list is built here
	 * rather than in the browser: the labels are assembled from the site's own
	 * name for the plugin, and a sentence stitched together out of fragments in
	 * JavaScript cannot be translated. Building them in PHP also means the
	 * ordinary .po catalogue covers them, with no separate JSON build step.
	 *
	 * Panels and links this site has hidden are left out, so the palette never
	 * offers a way to something the settings screen itself no longer shows.
	 *
	 * @since 3.0.0
	 * @return array
	 */
	private function get_commands() {
		$settings = PP_Admin_Settings::get_settings();
		$label    = PP_Admin_Settings::get_admin_label();
		$name     = ! empty( $settings['plugin_name'] ) ? $settings['plugin_name'] : __( 'PowerPack Pro for Elementor', 'powerpack' );
		$base     = admin_url( 'admin.php?page=powerpack-settings' );

		$commands = [
			[
				'name' => 'powerpack/goto-powerpack-dashboard',
				/* translators: %s: the site's name for the plugin. */
				'label'       => sprintf( __( 'Go to: %s', 'powerpack' ), $label ),
				'searchLabel' => $label . ' ' . $name . ' ' . __( 'Dashboard Settings Elementor', 'powerpack' ),
				'url'         => $base,
			],
		];

		/*
		 * The settings screen routes on the fragment, so these are the panel keys
		 * from its navigation order rather than query arguments. A fragment also
		 * moves between panels without a page load when the screen is already
		 * open, which a query argument cannot do.
		 */
		if ( 'on' !== $settings['hide_elements_tab'] ) {
			$commands[] = [
				'name' => 'powerpack/goto-powerpack-elements',
				/* translators: 1: the site's name for the plugin, 2: settings panel name. */
				'label'       => sprintf( __( 'Go to: %1$s > %2$s', 'powerpack' ), $label, __( 'Elements', 'powerpack' ) ),
				'searchLabel' => $label . ' ' . $name . ' ' . __( 'Elements Widgets Enable Disable', 'powerpack' ),
				'url'         => $base . '#elements',
			];
		}

		if ( 'on' !== $settings['hide_integration_tab'] ) {
			$commands[] = [
				'name' => 'powerpack/goto-powerpack-integrations',
				/* translators: 1: the site's name for the plugin, 2: settings panel name. */
				'label'       => sprintf( __( 'Go to: %1$s > %2$s', 'powerpack' ), $label, __( 'Integration', 'powerpack' ) ),
				'searchLabel' => $label . ' ' . $name . ' ' . __( 'Integrations API Settings Google Facebook Recaptcha', 'powerpack' ),
				'url'         => $base . '#integration',
			];
		}

		if ( 'on' !== $settings['hide_docs_links'] ) {
			$docs = ! empty( $settings['docs_link'] ) ? $settings['docs_link'] : 'https://powerpackelements.com/docs/';
			$docs = esc_url_raw( $docs, [ 'http', 'https' ] );

			if ( '' !== $docs ) {
				$commands[] = [
					'name' => 'powerpack/goto-powerpack-docs',
					/* translators: 1: the site's name for the plugin, 2: link name. */
					'label'       => sprintf( __( 'Go to: %1$s > %2$s', 'powerpack' ), $label, __( 'Documentation', 'powerpack' ) ),
					'searchLabel' => $label . ' ' . $name . ' ' . __( 'Help Documentation Docs Knowledge Base', 'powerpack' ),
					'url'         => $docs,
					'external'    => true,
				];
			}
		}

		if ( 'on' !== $settings['hide_support'] ) {
			$support = ! empty( $settings['support_link'] ) ? $settings['support_link'] : 'https://powerpackelements.com/contact/';
			$support = esc_url_raw( $support, [ 'http', 'https' ] );

			if ( '' !== $support ) {
				$commands[] = [
					'name' => 'powerpack/goto-powerpack-support',
					/* translators: 1: the site's name for the plugin, 2: link name. */
					'label'       => sprintf( __( 'Go to: %1$s > %2$s', 'powerpack' ), $label, __( 'Support', 'powerpack' ) ),
					'searchLabel' => $label . ' ' . $name . ' ' . __( 'Support Help Ticket Contact', 'powerpack' ),
					'url'         => $support,
					'external'    => true,
				];
			}
		}

		return $commands;
	}
}

// Initialize the class.
PP_Command_Palette::get_instance();
