<?php

class WPML_PP_Woo_Checkout_Billing extends WPML_Elementor_Module_With_Items {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'billing_details_form_fields';
	}

	public function get_fields() {
		return [
			'label',
			'placeholder',
			'default',
		];
	}

	protected function get_title( $field ) {
		switch ( $field ) {
			case 'label':
				return esc_html__( 'Woo Checkout - Billing Field Label', 'powerpack' );
			case 'placeholder':
				return esc_html__( 'Woo Checkout - Billing Field Placeholder', 'powerpack' );
			case 'default':
				return esc_html__( 'Woo Checkout - Billing Field Default Value', 'powerpack' );
			default:
				return '';
		}
	}

	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'label':
			case 'placeholder':
			case 'default':
				return 'LINE';
			default:
				return '';
		}
	}

}

class WPML_PP_Woo_Checkout_Shipping extends WPML_Elementor_Module_With_Items {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'shipping_details_form_fields';
	}

	public function get_fields() {
		return [
			'label',
			'placeholder',
			'default',
		];
	}

	protected function get_title( $field ) {
		switch ( $field ) {
			case 'label':
				return esc_html__( 'Woo Checkout - Shipping Field Label', 'powerpack' );
			case 'placeholder':
				return esc_html__( 'Woo Checkout - Shipping Field Placeholder', 'powerpack' );
			case 'default':
				return esc_html__( 'Woo Checkout - Shipping Field Default Value', 'powerpack' );
			default:
				return '';
		}
	}

	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'label':
			case 'placeholder':
			case 'default':
				return 'LINE';
			default:
				return '';
		}
	}

}

class WPML_PP_Woo_Checkout_Additional_Information extends WPML_Elementor_Module_With_Items {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'additional_information_form_fields';
	}

	public function get_fields() {
		return [
			'label',
			'placeholder',
			'default',
		];
	}

	protected function get_title( $field ) {
		switch ( $field ) {
			case 'label':
				return esc_html__( 'Woo Checkout - Additional Info Field Label', 'powerpack' );
			case 'placeholder':
				return esc_html__( 'Woo Checkout - Additional Info Field Placeholder', 'powerpack' );
			case 'default':
				return esc_html__( 'Woo Checkout - Additional Info Field Default Value', 'powerpack' );
			default:
				return '';
		}
	}

	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'label':
			case 'placeholder':
			case 'default':
				return 'LINE';
			default:
				return '';
		}
	}

}
