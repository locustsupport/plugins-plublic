<?php

class WPML_PP_Woo_Product_Tabs extends WPML_Elementor_Module_With_Items {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'product_tabs--repeater-section';
	}

	public function get_fields() {
		return [
			'title',
			'custom_content',
		];
	}

	protected function get_title( $field ) {
		switch ( $field ) {
			case 'title':
				return esc_html__( 'Woo Product Tabs - Tab Title', 'powerpack' );
			case 'custom_content':
				return esc_html__( 'Woo Product Tabs - Tab Custom Content', 'powerpack' );
			default:
				return '';
		}
	}

	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'title':
				return 'LINE';
			case 'custom_content':
				return 'VISUAL';
			default:
				return '';
		}
	}

}
