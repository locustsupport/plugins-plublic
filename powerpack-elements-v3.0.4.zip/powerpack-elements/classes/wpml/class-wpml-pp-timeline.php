<?php

class WPML_PP_Timeline extends WPML_Elementor_Module_With_Items {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'items';
	}

	public function get_fields() {
		return [
			'timeline_item_date',
			'timeline_item_title',
			'timeline_item_content',
			'single_marker_text',
			'youtube_url',
			'vimeo_url',
			'dailymotion_url',
			'timeline_item_link' => [ 'url' ],
			'external_url'       => [ 'url' ],
		];
	}

	protected function get_title( $field ) {
		switch ( $field ) {
			case 'timeline_item_date':
				return esc_html__( 'Timeline - Item Date', 'powerpack' );
			case 'timeline_item_title':
				return esc_html__( 'Timeline - Item Title', 'powerpack' );
			case 'timeline_item_content':
				return esc_html__( 'Timeline - Item Content', 'powerpack' );
			case 'single_marker_text':
				return esc_html__( 'Timeline - Item Marker Text', 'powerpack' );
			case 'youtube_url':
				return esc_html__( 'Timeline - Item YouTube URL', 'powerpack' );
			case 'vimeo_url':
				return esc_html__( 'Timeline - Item Vimeo URL', 'powerpack' );
			case 'dailymotion_url':
				return esc_html__( 'Timeline - Item Dailymotion URL', 'powerpack' );
			case 'url':
				return esc_html__( 'Timeline - Item Link', 'powerpack' );
			default:
				return '';
		}
	}

	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'timeline_item_date':
				return 'LINE';
			case 'timeline_item_title':
				return 'LINE';
			case 'timeline_item_content':
				return 'VISUAL';
			case 'single_marker_text':
				return 'LINE';
			case 'youtube_url':
				return 'LINE';
			case 'vimeo_url':
				return 'LINE';
			case 'dailymotion_url':
				return 'LINE';
			case 'url':
				return 'LINK';
			default:
				return '';
		}
	}

}
