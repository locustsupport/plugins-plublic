<?php
namespace PowerpackElements\Classes;

class PP_Elements_WPML {
	/**
	 * Controls added by PowerPack extensions.
	 *
	 * These live on Elementor's 'common' element, so they exist on every widget
	 * rather than on one widget type. WPML keys translatable fields by widget
	 * type, so they are appended to every registered widget instead.
	 *
	 * @since 3.0.1
	 * @var array
	 */
	private $extension_fields = [];

	/**
	 * Widgets whose repeater carries both a link field and an 'external_url'
	 * field. Both store the URL under a 'url' sub-key, which WPML would name
	 * identically. See PP_Elements_WPML::repeater_string_name().
	 *
	 * @since 3.0.1
	 * @var array
	 */
	private static $external_url_widgets = [
		'pp-showcase',
		'pp-timeline',
	];

	public function __construct() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'translate_fields' ) );

		foreach ( self::$external_url_widgets as $widget_type ) {
			add_filter( "wpml_pb_elementor_register_string_name_{$widget_type}", [ $this, 'repeater_string_name' ], 10, 2 );
		}
	}

	/**
	 * Disambiguate repeater sub-fields that share a 'url' sub-key.
	 *
	 * WPML builds repeater string names from the inner sub-key alone, so a
	 * repeater holding both 'link[url]' and 'external_url[url]' registers both
	 * under one name — the second overwrites the first, and a translation saved
	 * against it is written back to the wrong field. Only 'external_url' is
	 * renamed, so names for the link fields and their translations survive.
	 *
	 * @since 3.0.1
	 *
	 * @param string $name Default string name.
	 * @param array  $args Registration context supplied by WPML.
	 * @return string
	 */
	public function repeater_string_name( $name, $args ) {
		if ( ! isset( $args['key'] ) || 'external_url' !== $args['key'] ) {
			return $name;
		}

		$widget_type = isset( $args['element']['widgetType'] ) ? $args['element']['widgetType'] : '';
		$item_id     = isset( $args['item']['_id'] ) ? $args['item']['_id'] : '';

		return $widget_type . '-external_url-' . $args['nodeId'] . '-' . $item_id;
	}

	/**
	 * Get the translatable fields added by PowerPack extensions.
	 *
	 * @since 3.0.1
	 *
	 * @return array
	 */
	private function get_extension_fields() {
		if ( empty( $this->extension_fields ) ) {
			$this->extension_fields = [
				[
					'field'       => 'pp_elements_tooltip_content',
					'type'        => esc_html__( 'PowerPack Tooltip - Content', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				[
					'field'       => 'pp_custom_cursor_text',
					'type'        => esc_html__( 'PowerPack Custom Cursor - Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'pp_wrapper_link' => [
					'field'       => 'url',
					'field_id'    => 'pp_wrapper_link_url',
					'type'        => esc_html__( 'PowerPack Wrapper Link - URL', 'powerpack' ),
					'editor_type' => 'LINK',
				],
			];
		}

		return $this->extension_fields;
	}

	public function translate_fields( $widgets ) {
		$widgets['pp-advanced-accordion'] = [
			'conditions'        => [ 'widgetType' => 'pp-advanced-accordion' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Advanced_Accordion',
		];
		$widgets['pp-advanced-menu'] = [
			'conditions' => [ 'widgetType' => 'pp-advanced-menu' ],
			'fields'     => [
				[
					'field'       => 'toggle_label',
					'type'        => esc_html__( 'Advanced Menu - Toggle Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-advanced-tabs'] = [
			'conditions'        => [ 'widgetType' => 'pp-advanced-tabs' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Advanced_Tabs',
		];
		$widgets['pp-album'] = [
			'conditions' => [ 'widgetType' => 'pp-album' ],
			'fields'     => [
				[
					'field'       => 'album_trigger_button_text',
					'type'        => esc_html__( 'Album - Trigger Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'album_title',
					'type'        => esc_html__( 'Album - Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'album_subtitle',
					'type'        => esc_html__( 'Album - Subtitle', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'album_cover_button_text',
					'type'        => esc_html__( 'Album - Cover Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-author-list'] = [
			'conditions' => [ 'widgetType' => 'pp-author-list' ],
			'fields'     => [
				[
					'field'       => 'author_post_count_text',
					'type'        => esc_html__( 'Author List - Post Count Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-breadcrumbs'] = [
			'conditions' => [ 'widgetType' => 'pp-breadcrumbs' ],
			'fields'     => [
				[
					'field'       => 'home_text',
					'type'        => esc_html__( 'Breadcrumbs - Home Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'blog_text',
					'type'        => esc_html__( 'Breadcrumbs - Blog Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'separator_text',
					'type'        => esc_html__( 'Breadcrumbs - Separator Text', 'powerpack' ),
				],
			],
		];
		$widgets['pp-business-hours'] = [
			'conditions'        => [ 'widgetType' => 'pp-business-hours' ],
			'fields'            => [],
			'integration-class' => [
				'WPML_PP_Business_Hours',
				'WPML_PP_Business_Hours_Custom',
			],
		];
		$widgets['pp-buttons'] = [
			'conditions'        => [ 'widgetType' => 'pp-buttons' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Buttons',
		];
		$widgets['pp-card-slider'] = [
			'conditions'        => [ 'widgetType' => 'pp-card-slider' ],
			'fields'            => [
				[
					'field'       => 'button_text',
					'type'        => esc_html__( 'Card Slider - Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => 'WPML_PP_Card_Slider',
		];
		$widgets['pp-categories'] = [
			'conditions' => [ 'widgetType' => 'pp-categories' ],
			'fields'     => [
				[
					'field'       => 'count_text_singular',
					'type'        => esc_html__( 'Categories - Count Text (Singular)', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'count_text_plural',
					'type'        => esc_html__( 'Categories - Count Text (Plural)', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-charts'] = [
			'conditions'        => [ 'widgetType' => 'pp-charts' ],
			'fields'            => [
				[
					'field'       => 'labels',
					'type'        => esc_html__( 'Charts - Labels', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				[
					'field'       => 'chart_title',
					'type'        => esc_html__( 'Charts - Chart Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'x_axis_title',
					'type'        => esc_html__( 'Charts - X-Axis Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'y_axis_title',
					'type'        => esc_html__( 'Charts - Y-Axis Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'y_axis_labels_prefix',
					'type'        => esc_html__( 'Charts - Y-Axis Labels Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'y_axis_labels_suffix',
					'type'        => esc_html__( 'Charts - Y-Axis Labels Suffix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => [
				'WPML_PP_Charts_Dataset_Colors',
				'WPML_PP_Charts_Dataset',
				'WPML_PP_Charts_Bubble_Dataset',
			],
		];
		$widgets['pp-contact-form-7'] = [
			'conditions' => [ 'widgetType' => 'pp-contact-form-7' ],
			'fields'     => [
				[
					'field'       => 'form_title_text',
					'type'        => esc_html__( 'Contact Form 7 - Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'form_description_text',
					'type'        => esc_html__( 'Contact Form 7 - Description', 'powerpack' ),
					'editor_type' => 'AREA',
				],
			],
		];
		$widgets['pp-content-reveal'] = [
			'conditions' => [ 'widgetType' => 'pp-content-reveal' ],
			'fields'     => [
				[
					'field'       => 'content',
					'type'        => esc_html__( 'Content Reveal - Content Type = Content', 'powerpack' ),
					'editor_type' => 'VISUAL',
				],
				[
					'field'       => 'button_text_closed',
					'type'        => esc_html__( 'Content Reveal - Content Unreveal Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'button_text_open',
					'type'        => esc_html__( 'Content Reveal - Content Reveal Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-content-ticker'] = [
			'conditions'        => [ 'widgetType' => 'pp-content-ticker' ],
			'fields'            => [
				[
					'field'       => 'heading',
					'type'        => esc_html__( 'Content Ticker - Heading Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'datetime_separator',
					'type'        => esc_html__( 'Content Ticker - Date Time Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => 'WPML_PP_Content_Ticker',
		];
		$widgets['pp-countdown'] = [
			'conditions' => [ 'widgetType' => 'pp-countdown' ],
			'fields'     => [
				[
					'field'       => 'fixed_expire_message',
					'type'        => esc_html__( 'Countdown - Fixed Expiry Message', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'fixed_redirect_link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Countdown - Fixed Redirect Link', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'evergreen_expire_message',
					'type'        => esc_html__( 'Countdown - Evergreen Expire Message', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'evergreen_redirect_link' => [
					// Shares the 'url' sub-key with fixed_redirect_link above; without a distinct
					// field_id both register under the same string name and overwrite each other.
					'field'       => 'url',
					'field_id'    => 'evergreen_redirect_url',
					'type'        => esc_html__( 'Countdown - Evergreen Redirect Link', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'label_years_plural',
					'type'        => esc_html__( 'Countdown - Years in Plural', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'label_years_singular',
					'type'        => esc_html__( 'Countdown - Years in Singular', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'label_months_plural',
					'type'        => esc_html__( 'Countdown - Months in Plural', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'label_months_singular',
					'type'        => esc_html__( 'Countdown - Months in Singular', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'label_days_plural',
					'type'        => esc_html__( 'Countdown - Days in Plural', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'label_days_singular',
					'type'        => esc_html__( 'Countdown - Days in Singular', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'label_hours_plural',
					'type'        => esc_html__( 'Countdown - Hours in Plural', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'label_hours_singular',
					'type'        => esc_html__( 'Countdown - Hours in Singular', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'label_minutes_plural',
					'type'        => esc_html__( 'Countdown - Minutes in Plural', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'label_minutes_singular',
					'type'        => esc_html__( 'Countdown - Minutes in Singular', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'label_seconds_plural',
					'type'        => esc_html__( 'Countdown - Seconds in Plural', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'label_seconds_singular',
					'type'        => esc_html__( 'Countdown - Seconds in Singular', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-counter'] = [
			'conditions' => [ 'widgetType' => 'pp-counter' ],
			'fields'     => [
				[
					'field'       => 'starting_number',
					'type'        => esc_html__( 'Counter - Starting Number', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'ending_number',
					'type'        => esc_html__( 'Counter - Ending Number', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'number_prefix',
					'type'        => esc_html__( 'Counter - Number Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'number_suffix',
					'type'        => esc_html__( 'Counter - Number Suffix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'counter_title',
					'type'        => esc_html__( 'Counter - Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'counter_subtitle',
					'type'        => esc_html__( 'Counter - Subtitle', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-coupons'] = [
			'conditions'        => [ 'widgetType' => 'pp-coupons' ],
			'fields'            => [
				[
					'field'       => 'coupon_reveal',
					'type'        => esc_html__( 'Coupons - Coupon Reveal Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'no_code_need',
					'type'        => esc_html__( 'Coupons - No Coupon Code Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'button_text',
					'type'        => esc_html__( 'Coupons - Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'filter_all_label',
					'type'        => esc_html__( 'Coupons - "All" Filter Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => 'WPML_PP_Coupons',
		];
		$widgets['pp-devices'] = [
			'conditions' => [ 'widgetType' => 'pp-devices' ],
			'fields'     => [
				[
					'field'       => 'youtube_url',
					'type'        => esc_html__( 'Devices - Youtube URL', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'vimeo_url',
					'type'        => esc_html__( 'Devices - Vimeo URL', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'dailymotion_url',
					'type'        => esc_html__( 'Devices - Dailymotion URL', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'video_url_mp4',
					'type'        => esc_html__( 'Devices - Video URL MP4', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'video_source_m4v',
					'type'        => esc_html__( 'Devices - Video URL M4V', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'video_url_ogg',
					'type'        => esc_html__( 'Devices - Video URL OGG', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'video_url_webm',
					'type'        => esc_html__( 'Devices - Video URL WEBM', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'start_time',
					'type'        => esc_html__( 'Devices - Start Time', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'end_time',
					'type'        => esc_html__( 'Devices - End Time', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-divider'] = [
			'conditions' => [ 'widgetType' => 'pp-divider' ],
			'fields'     => [
				[
					'field'       => 'divider_text',
					'type'        => esc_html__( 'Divider - Divider Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-dual-heading'] = [
			'conditions' => [ 'widgetType' => 'pp-dual-heading' ],
			'fields'     => [
				[
					'field'       => 'first_text',
					'type'        => esc_html__( 'Dual Heading - First Text', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				[
					'field'       => 'second_text',
					'type'        => esc_html__( 'Dual Heading - Second Text', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				'link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Dual Heading - Link', 'powerpack' ),
					'editor_type' => 'LINK',
				],
			],
		];
		$widgets['pp-event-calendar'] = [
			'conditions'        => [ 'widgetType' => 'pp-event-calendar' ],
			'fields'            => [
				[
					'field'       => 'allday_text',
					'type'        => esc_html__( 'Event Calendar - All Day Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'read_more_text',
					'type'        => esc_html__( 'Event Calendar - Read More Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'no_events_text',
					'type'        => esc_html__( 'Event Calendar - No Events Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'prev_button_text',
					'type'        => esc_html__( 'Event Calendar - Previous Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'next_button_text',
					'type'        => esc_html__( 'Event Calendar - Next Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'prev_year_button_text',
					'type'        => esc_html__( 'Event Calendar - Previous Year Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'next_year_button_text',
					'type'        => esc_html__( 'Event Calendar - Next Year Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => [
				'WPML_PP_Event_Calendar_Events',
				'WPML_PP_Event_Calendar_Popup_Fields',
			],
		];
		$widgets['pp-fancy-heading'] = [
			'conditions' => [ 'widgetType' => 'pp-fancy-heading' ],
			'fields'     => [
				[
					'field'       => 'heading_text',
					'type'        => esc_html__( 'Fancy Heading - Heading Text', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				'link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Fancy Heading - Link', 'powerpack' ),
					'editor_type' => 'LINK',
				],
			],
		];
		$widgets['pp-faq'] = [
			'conditions'        => [ 'widgetType' => 'pp-faq' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Faq',
		];
		$widgets['pp-flipbox'] = [
			'conditions' => [ 'widgetType' => 'pp-flipbox' ],
			'fields'     => [
				[
					'field'       => 'icon_text',
					'type'        => esc_html__( 'Flip Box - Front Icon Text', 'powerpack' ),
					'editor_type' => 'LINE'
				],
				[
					'field'       => 'title_front',
					'type'        => esc_html__( 'Flip Box - Front Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'description_front',
					'type'        => esc_html__( 'Flip Box - Front Description', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'icon_text_back',
					'type'        => esc_html__( 'Flip Box - Back Icon Text', 'powerpack' ),
					'editor_type' => 'LINE'
				],
				[
					'field'       => 'title_back',
					'type'        => esc_html__( 'Flip Box - Back Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'description_back',
					'type'        => esc_html__( 'Flip Box - Back Description', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Flip Box - Link', 'powerpack' ),
					'editor_type' => 'LINK',
				],
				[
					'field'       => 'flipbox_button_text',
					'type'        => esc_html__( 'Flip Box - Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-fluent-forms'] = [
			'conditions' => [ 'widgetType' => 'pp-fluent-forms' ],
			'fields'     => [
				[
					'field'       => 'form_title_custom',
					'type'        => esc_html__( 'Fluent Forms - Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'form_description_custom',
					'type'        => esc_html__( 'Fluent Forms - Description', 'powerpack' ),
					'editor_type' => 'AREA',
				],
			],
		];
		$widgets['pp-formidable-forms'] = [
			'conditions' => [ 'widgetType' => 'pp-formidable-forms' ],
			'fields'     => [
				[
					'field'       => 'form_title_custom',
					'type'        => esc_html__( 'Formidable Forms - Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'form_description_custom',
					'type'        => esc_html__( 'Formidable Forms - Description', 'powerpack' ),
					'editor_type' => 'AREA',
				],
			],
		];
		$widgets['pp-google-maps'] = [
			'conditions'        => [ 'widgetType' => 'pp-google-maps' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Google_Maps',
		];
		$widgets['pp-gravity-forms'] = [
			'conditions' => [ 'widgetType' => 'pp-gravity-forms' ],
			'fields'     => [
				[
					'field'       => 'form_title_custom',
					'type'        => esc_html__( 'Gravity Forms - Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'form_description_custom',
					'type'        => esc_html__( 'Gravity Forms - Description', 'powerpack' ),
					'editor_type' => 'AREA',
				],
			],
		];
		$widgets['pp-how-to'] = [
			'conditions'        => [ 'widgetType' => 'pp-how-to' ],
			'fields'            => [
				[
					'field'       => 'how_to_title',
					'type'        => esc_html__( 'How To - Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'how_to_description',
					'type'        => esc_html__( 'How To - Description', 'powerpack' ),
					'editor_type' => 'VISUAL',
				],
				[
					'field'       => 'total_time_text',
					'type'        => esc_html__( 'How To - Total Time Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'total_time_years',
					'type'        => esc_html__( 'How To - Total Time Years', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'total_time_months',
					'type'        => esc_html__( 'How To - Total Time Months', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'total_time_days',
					'type'        => esc_html__( 'How To - Total Time Days', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'total_time_hours',
					'type'        => esc_html__( 'How To - Total Time Hours', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'total_time_minutes',
					'type'        => esc_html__( 'How To - Total Time Minutes', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'estimated_cost_text',
					'type'        => esc_html__( 'How To - Estimated Cost Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'currency_iso_code',
					'type'        => esc_html__( 'How To - Currency ISO Code', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'estimated_cost',
					'type'        => esc_html__( 'How To - Estimated Cost', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'supply_title',
					'type'        => esc_html__( 'How To - Supply Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'tool_title',
					'type'        => esc_html__( 'How To - Tool Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'step_section_title',
					'type'        => esc_html__( 'How To - Steps Section Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => [
				'WPML_PP_How_To',
				'WPML_PP_How_To_Supply',
				'WPML_PP_How_To_Tools',
			],
		];
		$widgets['pp-icon-list'] = [
			'conditions'        => [ 'widgetType' => 'pp-icon-list' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Icon_List',
		];
		$widgets['pp-image-accordion'] = [
			'conditions'        => [ 'widgetType' => 'pp-image-accordion' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Image_Accordion',
		];
		$widgets['pp-image-comparison'] = [
			'conditions' => [ 'widgetType' => 'pp-image-comparison' ],
			'fields'     => [
				[
					'field'       => 'before_label',
					'type'        => esc_html__( 'Image Comparision - Before Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'after_label',
					'type'        => esc_html__( 'Image Comparision - After Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-image-gallery'] = [
			'conditions' => [ 'widgetType' => 'pp-image-gallery' ],
			'fields'     => [
				[
					'field'       => 'filter_all_label',
					'type'        => esc_html__( 'Image Gallery - "All" Filter Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'load_more_text',
					'type'        => esc_html__( 'Image Gallery - Load More Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => 'WPML_PP_Image_Gallery',
		];
		$widgets['pp-image-hotspots'] = [
			'conditions'        => [ 'widgetType' => 'pp-image-hotspots' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Image_Hotspots',
		];
		$widgets['pp-info-box'] = [
			'conditions' => [ 'widgetType' => 'pp-info-box' ],
			'fields'     => [
				[
					'field'       => 'icon_text',
					'type'        => esc_html__( 'Info Box - Icon Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'heading',
					'type'        => esc_html__( 'Info Box - Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'sub_heading',
					'type'        => esc_html__( 'Info Box - Subtitle', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'description',
					'type'        => esc_html__( 'Info Box - Description', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				'link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Info Box - Link', 'powerpack' ),
					'editor_type' => 'LINK',
				],
				[
					'field'       => 'button_text',
					'type'        => esc_html__( 'Info Box - Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-info-box-carousel'] = [
			'conditions'        => [ 'widgetType' => 'pp-info-box-carousel' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Info_Box_Carousel',
		];
		$widgets['pp-info-list'] = [
			'conditions'        => [ 'widgetType' => 'pp-info-list' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Info_List',
		];
		$widgets['pp-info-table'] = [
			'conditions' => [ 'widgetType' => 'pp-info-table' ],
			'fields'     => [
				[
					'field'       => 'icon_text',
					'type'        => esc_html__( 'Info Table - Icon Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'heading',
					'type'        => esc_html__( 'Info Table - Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'sub_heading',
					'type'        => esc_html__( 'Info Table - Subtitle', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'description',
					'type'        => esc_html__( 'Info Table - Description', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				[
					'field'       => 'sale_badge_text',
					'type'        => esc_html__( 'Info Table - Sale Badge Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Info Table - Link', 'powerpack' ),
					'editor_type' => 'LINK',
				],
				[
					'field'       => 'button_text',
					'type'        => esc_html__( 'Info Table - Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-instafeed'] = [
			'conditions' => [ 'widgetType' => 'pp-instafeed' ],
			'fields'     => [
				[
					'field'       => 'insta_link_title',
					'type'        => esc_html__( 'Instagram Feed - Link Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'insta_profile_url' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Instagram Feed - Instagram Profile URL', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'load_more_button_text',
					'type'        => esc_html__( 'Instagram Feed - Load More Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-interactive-circle'] = [
			'conditions' => [ 'widgetType' => 'pp-interactive-circle' ],
			'fields'     => [],
			'integration-class' => 'WPML_PP_Interactive_Circle',
		];
		$widgets['pa-link-effects'] = [
			'conditions' => [ 'widgetType' => 'pa-link-effects' ],
			'fields'     => [
				[
					'field'       => 'text',
					'type'        => esc_html__( 'Link Effects - Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'secondary_text',
					'type'        => esc_html__( 'Link Effects - Secondary Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Link Effects - link', 'powerpack' ),
					'editor_type' => 'LINK',
				],
			],
		];
		$widgets['pp-login-form'] = [
			'conditions' => [ 'widgetType' => 'pp-login-form' ],
			'fields'     => [
				[
					'field'       => 'user_label',
					'type'        => esc_html__( 'Login Form - Username Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'user_placeholder',
					'type'        => esc_html__( 'Login Form - Username Placeholder', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'password_label',
					'type'        => esc_html__( 'Login Form - Password Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'password_placeholder',
					'type'        => esc_html__( 'Login Form - Password Placeholder', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'button_text',
					'type'        => esc_html__( 'Login Form - Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'facebook_login_label',
					'type'        => esc_html__( 'Login Form - Facebook Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'google_login_label',
					'type'        => esc_html__( 'Login Form - Google Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'separator_text',
					'type'        => esc_html__( 'Login Form - Separator Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'lost_password_text',
					'type'        => esc_html__( 'Login Form - Lost Password Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'register_text',
					'type'        => esc_html__( 'Login Form - Register Link Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'remember_me_text',
					'type'        => esc_html__( 'Login Form - Remember Me Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'social_login_separator_text',
					'type'        => esc_html__( 'Login Form - Social Login Separator Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'lost_password_form_message',
					'type'        => esc_html__( 'Login Form - Lost Password Form Message', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				[
					'field'       => 'reset_password_button_text',
					'type'        => esc_html__( 'Login Form - Reset Password Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'social_login_redirect_url' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Login Form - Social Login Redirect URL', 'powerpack' ),
					'editor_type' => 'LINK',
				],
			],
		];
		$widgets['pp-logo-carousel'] = [
			'conditions'        => [ 'widgetType' => 'pp-logo-carousel' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Logo_Carousel',
		];
		$widgets['pp-logo-grid'] = [
			'conditions'        => [ 'widgetType' => 'pp-logo-grid' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Logo_Grid',
		];
		$widgets['pp-magazine-slider'] = [
			'conditions' => [ 'widgetType' => 'pp-magazine-slider' ],
			'fields'     => [
				[
					'field'       => 'post_meta_divider',
					'type'        => esc_html__( 'Magazine Slider - Post Meta Divider', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'read_more_button_text',
					'type'        => esc_html__( 'Magazine Slider - Read More Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-marquee'] = [
			'conditions'        => [ 'widgetType' => 'pp-marquee' ],
			'fields'            => [
				[
					'field'       => 'separator_text',
					'type'        => esc_html__( 'Marquee - Separator Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'posts_link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Marquee - Posts Link', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => 'WPML_PP_Marquee',
		];
		$widgets['pp-modal-popup'] = [
			'conditions' => [ 'widgetType' => 'pp-modal-popup' ],
			'fields'     => [
				[
					'field'       => 'title',
					'type'        => esc_html__( 'Popup Box - Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'popup_link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Popup Box - URL', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'popup_image_link' => [
					// Shares the 'url' sub-key with popup_link above; see the Countdown note.
					'field'       => 'url',
					'field_id'    => 'popup_image_url',
					'type'        => esc_html__( 'Popup Box - Image Link', 'powerpack' ),
					'editor_type' => 'LINK',
				],
				[
					'field'       => 'content',
					'type'        => esc_html__( 'Popup Box - Content', 'powerpack' ),
					'editor_type' => 'VISUAL',
				],
				[
					'field'       => 'custom_html',
					'type'        => esc_html__( 'Popup Box - Custom HTML', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				[
					'field'       => 'button_text',
					'type'        => esc_html__( 'Popup Box - Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'element_identifier',
					'type'        => esc_html__( 'Popup Box - CSS Class or ID', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-ninja-forms'] = [
			'conditions' => [ 'widgetType' => 'pp-ninja-forms' ],
			'fields'     => [
				[
					'field'       => 'form_title_custom',
					'type'        => esc_html__( 'Ninja Forms - Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'form_description_custom',
					'type'        => esc_html__( 'Ninja Forms - Description', 'powerpack' ),
					'editor_type' => 'AREA',
				],
			],
		];
		$widgets['pp-offcanvas-content'] = [
			'conditions'        => [ 'widgetType' => 'pp-offcanvas-content' ],
			'fields'            => [
				[
					'field'       => 'button_text',
					'type'        => esc_html__( 'Offcanvas Content - Toggle Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'burger_label',
					'type'        => esc_html__( 'Offcanvas Content - Burger Icon Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => 'WPML_PP_Offcanvas_Content',
		];
		$widgets['pp-one-page-nav'] = [
			'conditions'        => [ 'widgetType' => 'pp-one-page-nav' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_One_Page_Nav',
		];
		$widgets['pp-posts'] = [
			'conditions' => [ 'widgetType' => 'pp-posts' ],
			'fields'     => [
				[
					'field'       => 'query_id',
					'type'        => esc_html__( 'Posts - Query Id', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'nothing_found_message',
					'type'        => esc_html__( 'Posts - Nothing Found Message', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				[
					'field'       => 'classic_filter_all_label',
					'type'        => esc_html__( 'Posts: Classic - "All" Filter Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'card_filter_all_label',
					'type'        => esc_html__( 'Posts: Card - "All" Filter Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'checkerboard_filter_all_label',
					'type'        => esc_html__( 'Posts: Checkerboard - "All" Filter Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'creative_filter_all_label',
					'type'        => esc_html__( 'Posts: Creative - "All" Filter Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'event_filter_all_label',
					'type'        => esc_html__( 'Posts: Event - "All" Filter Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'news_filter_all_label',
					'type'        => esc_html__( 'Posts: News - "All" Filter Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'overlap_filter_all_label',
					'type'        => esc_html__( 'Posts: Overlap - "All" Filter Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'portfolio_filter_all_label',
					'type'        => esc_html__( 'Posts: Portfolio - "All" Filter Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'classic_search_form_input_placeholder',
					'type'        => esc_html__( 'Posts: Classic - Search Form Placeholder', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'card_search_form_input_placeholder',
					'type'        => esc_html__( 'Posts: Card - Search Form Placeholder', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'checkerboard_search_form_input_placeholder',
					'type'        => esc_html__( 'Posts: Checkerboard - Search Form Placeholder', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'creative_search_form_input_placeholder',
					'type'        => esc_html__( 'Posts: Creative - Search Form Placeholder', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'event_search_form_input_placeholder',
					'type'        => esc_html__( 'Posts: Event - Search Form Placeholder', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'news_search_form_input_placeholder',
					'type'        => esc_html__( 'Posts: News - Search Form Placeholder', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'overlap_search_form_input_placeholder',
					'type'        => esc_html__( 'Posts: Overlap - Search Form Placeholder', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'portfolio_search_form_input_placeholder',
					'type'        => esc_html__( 'Posts: Portfolio - Search Form Placeholder', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'classic_search_form_button_text',
					'type'        => esc_html__( 'Posts: Classic - Search Form Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'card_search_form_button_text',
					'type'        => esc_html__( 'Posts: Card - Search Form Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'checkerboard_search_form_button_text',
					'type'        => esc_html__( 'Posts: Checkerboard - Search Form Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'creative_search_form_button_text',
					'type'        => esc_html__( 'Posts: Creative - Search Form Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'event_search_form_button_text',
					'type'        => esc_html__( 'Posts: Event - Search Form Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'news_search_form_button_text',
					'type'        => esc_html__( 'Posts: News - Search Form Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'overlap_search_form_button_text',
					'type'        => esc_html__( 'Posts: Overlap - Search Form Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'portfolio_search_form_button_text',
					'type'        => esc_html__( 'Posts: Portfolio - Search Form Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'classic_post_terms_separator',
					'type'        => esc_html__( 'Posts: Classic - Terms Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'card_post_terms_separator',
					'type'        => esc_html__( 'Posts: Card - Terms Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'checkerboard_post_terms_separator',
					'type'        => esc_html__( 'Posts: Checkerboard - Terms Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'creative_post_terms_separator',
					'type'        => esc_html__( 'Posts: Creative - Terms Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'event_post_terms_separator',
					'type'        => esc_html__( 'Posts: Event - Terms Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'news_post_terms_separator',
					'type'        => esc_html__( 'Posts: News - Terms Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'overlap_post_terms_separator',
					'type'        => esc_html__( 'Posts: Overlap - Terms Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'portfolio_post_terms_separator',
					'type'        => esc_html__( 'Posts: Portfolio - Terms Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'classic_post_meta_separator',
					'type'        => esc_html__( 'Posts: Classic - Post Meta Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'card_post_meta_separator',
					'type'        => esc_html__( 'Posts: Card - Post Meta Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'checkerboard_post_meta_separator',
					'type'        => esc_html__( 'Posts: Checkerboard - Post Meta Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'creative_post_meta_separator',
					'type'        => esc_html__( 'Posts: Creative - Post Meta Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'event_post_meta_separator',
					'type'        => esc_html__( 'Posts: Event - Post Meta Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'news_post_meta_separator',
					'type'        => esc_html__( 'Posts: News - Post Meta Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'overlap_post_meta_separator',
					'type'        => esc_html__( 'Posts: Overlap - Post Meta Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'portfolio_post_meta_separator',
					'type'        => esc_html__( 'Posts: Portfolio - Post Meta Separator', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'classic_author_prefix',
					'type'        => esc_html__( 'Posts: Classic - Author Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'card_author_prefix',
					'type'        => esc_html__( 'Posts: Card - Author Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'checkerboard_author_prefix',
					'type'        => esc_html__( 'Posts: Checkerboard - Author Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'creative_author_prefix',
					'type'        => esc_html__( 'Posts: Creative - Author Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'event_author_prefix',
					'type'        => esc_html__( 'Posts: Event - Author Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'news_author_prefix',
					'type'        => esc_html__( 'Posts: News - Author Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'overlap_author_prefix',
					'type'        => esc_html__( 'Posts: Overlap - Author Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'portfolio_author_prefix',
					'type'        => esc_html__( 'Posts: Portfolio - Author Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'classic_date_prefix',
					'type'        => esc_html__( 'Posts: Classic - Date Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'card_date_prefix',
					'type'        => esc_html__( 'Posts: Card - Date Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'checkerboard_date_prefix',
					'type'        => esc_html__( 'Posts: Checkerboard - Date Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'creative_date_prefix',
					'type'        => esc_html__( 'Posts: Creative - Date Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'event_date_prefix',
					'type'        => esc_html__( 'Posts: Event - Date Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'news_date_prefix',
					'type'        => esc_html__( 'Posts: News - Date Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'overlap_date_prefix',
					'type'        => esc_html__( 'Posts: Overlap - Date Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'portfolio_date_prefix',
					'type'        => esc_html__( 'Posts: Portfolio - Date Prefix', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'classic_button_text',
					'type'        => esc_html__( 'Posts: Classic - Read More Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'card_button_text',
					'type'        => esc_html__( 'Posts: Card - Read More Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'checkerboard_button_text',
					'type'        => esc_html__( 'Posts: Checkerboard - Read More Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'creative_button_text',
					'type'        => esc_html__( 'Posts: Creative - Read More Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'event_button_text',
					'type'        => esc_html__( 'Posts: Event - Read More Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'news_button_text',
					'type'        => esc_html__( 'Posts: News - Read More Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'overlap_button_text',
					'type'        => esc_html__( 'Posts: Overlap - Read More Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'portfolio_button_text',
					'type'        => esc_html__( 'Posts: Portfolio - Read More Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'classic_pagination_load_more_label',
					'type'        => esc_html__( 'Posts: Classic - Pagination Load More Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'card_pagination_load_more_label',
					'type'        => esc_html__( 'Posts: Card - Pagination Load More Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'checkerboard_pagination_load_more_label',
					'type'        => esc_html__( 'Posts: Checkerboard - Pagination Load More Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'creative_pagination_load_more_label',
					'type'        => esc_html__( 'Posts: Creative - Pagination Load More Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'event_pagination_load_more_label',
					'type'        => esc_html__( 'Posts: Event - Pagination Load More Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'news_pagination_load_more_label',
					'type'        => esc_html__( 'Posts: News - Pagination Load More Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'overlap_pagination_load_more_label',
					'type'        => esc_html__( 'Posts: Overlap - Pagination Load More Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'portfolio_pagination_load_more_label',
					'type'        => esc_html__( 'Posts: Portfolio - Pagination Load More Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'classic_pagination_prev_label',
					'type'        => esc_html__( 'Posts: Classic - Pagination Prev Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'card_pagination_prev_label',
					'type'        => esc_html__( 'Posts: Card - Pagination Prev Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'checkerboard_pagination_prev_label',
					'type'        => esc_html__( 'Posts: Checkerboard - Pagination Prev Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'creative_pagination_prev_label',
					'type'        => esc_html__( 'Posts: Creative - Pagination Prev Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'event_pagination_prev_label',
					'type'        => esc_html__( 'Posts: Event - Pagination Prev Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'news_pagination_prev_label',
					'type'        => esc_html__( 'Posts: News - Pagination Prev Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'overlap_pagination_prev_label',
					'type'        => esc_html__( 'Posts: Overlap - Pagination Prev Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'portfolio_pagination_prev_label',
					'type'        => esc_html__( 'Posts: Portfolio - Pagination Prev Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'classic_pagination_next_label',
					'type'        => esc_html__( 'Posts: Classic - Pagination Next Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'card_pagination_next_label',
					'type'        => esc_html__( 'Posts: Card - Pagination Next Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'checkerboard_pagination_next_label',
					'type'        => esc_html__( 'Posts: Checkerboard - Pagination Next Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'creative_pagination_next_label',
					'type'        => esc_html__( 'Posts: Creative - Pagination Next Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'event_pagination_next_label',
					'type'        => esc_html__( 'Posts: Event - Pagination Next Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'news_pagination_next_label',
					'type'        => esc_html__( 'Posts: News - Pagination Next Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'overlap_pagination_next_label',
					'type'        => esc_html__( 'Posts: Overlap - Pagination Next Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'portfolio_pagination_next_label',
					'type'        => esc_html__( 'Posts: Portfolio - Pagination Next Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-price-menu'] = [
			'conditions'        => [ 'widgetType' => 'pp-price-menu' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Price_Menu',
		];
		$widgets['pp-pricing-table'] = [
			'conditions'        => [ 'widgetType' => 'pp-pricing-table' ],
			'fields'            => [
				[
					'field'       => 'table_title',
					'type'        => esc_html__( 'Pricing Table - Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'table_subtitle',
					'type'        => esc_html__( 'Pricing Table - Subtitle', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'table_price',
					'type'        => esc_html__( 'Pricing Table - Price', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'table_original_price',
					'type'        => esc_html__( 'Pricing Table - Origibal Price', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'table_duration',
					'type'        => esc_html__( 'Pricing Table - Duration', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'ribbon_title',
					'type'        => esc_html__( 'Pricing Table - Ribbon Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'table_button_text',
					'type'        => esc_html__( 'Pricing Table - Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Pricing Table - Link', 'powerpack' ),
					'editor_type' => 'LINK',
				],
				[
					'field'       => 'table_additional_info',
					'type'        => esc_html__( 'Pricing Table - Additional Info', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				[
					'field'       => 'currency_symbol_custom',
					'type'        => esc_html__( 'Pricing Table - Custom Currency Symbol', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => 'WPML_PP_Pricing_Table',
		];
		$widgets['pp-progress-bar'] = [
			'conditions' => [ 'widgetType' => 'pp-progress-bar' ],
			'fields'     => [
				[
					'field'       => 'bar_label',
					'type'        => esc_html__( 'Progress Bar - Label (Single)', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'half_circle_prefix',
					'type'        => esc_html__( 'Progress Bar - Half Circle Prefix Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'half_circle_suffix',
					'type'        => esc_html__( 'Progress Bar - Half Circle Suffix Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => 'WPML_PP_Progress_Bar',
		];
		$widgets['pp-promo-box'] = [
			'conditions' => [ 'widgetType' => 'pp-promo-box' ],
			'fields'     => [
				[
					'field'       => 'heading',
					'type'        => esc_html__( 'Promo Box - Heading', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'sub_heading',
					'type'        => esc_html__( 'Promo Box - Sub Heading', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'content',
					'type'        => esc_html__( 'Promo Box - Description', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				[
					'field'       => 'button_text',
					'type'        => esc_html__( 'Promo Box - Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Promo Box - link', 'powerpack' ),
					'editor_type' => 'LINK',
				],
			],
		];
		$widgets['pp-random-image'] = [
			'conditions' => [ 'widgetType' => 'pp-random-image' ],
			'fields'     => [
				'link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Random Image - URL', 'powerpack' ),
					'editor_type' => 'LINK',
				],
			],
		];
		$widgets['pp-recipe'] = [
			'conditions'        => [ 'widgetType' => 'pp-recipe' ],
			'fields'            => [
				[
					'field'       => 'recipe_name',
					'type'        => esc_html__( 'Recipe - Name', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'recipe_description',
					'type'        => esc_html__( 'Recipe - Description', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				[
					'field'       => 'prep_time_title',
					'type'        => esc_html__( 'Recipe - Prep Time Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'prep_time',
					'type'        => esc_html__( 'Recipe - Prep Time', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'prep_time_unit',
					'type'        => esc_html__( 'Recipe - Prep Time Unit', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'cook_time_title',
					'type'        => esc_html__( 'Recipe - Cook Time Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'cook_time',
					'type'        => esc_html__( 'Recipe - Cook Time', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'cook_time_unit',
					'type'        => esc_html__( 'Recipe - Cook Time Unit', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'total_time_title',
					'type'        => esc_html__( 'Recipe - Total Time Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'total_time',
					'type'        => esc_html__( 'Recipe - Total Time', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'total_time_unit',
					'type'        => esc_html__( 'Recipe - Total Time Unit', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'servings_title',
					'type'        => esc_html__( 'Recipe - Servings Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'servings',
					'type'        => esc_html__( 'Recipe - Servings', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'servings_unit',
					'type'        => esc_html__( 'Recipe - Servings Unit', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'calories_title',
					'type'        => esc_html__( 'Recipe - Calories Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'calories',
					'type'        => esc_html__( 'Recipe - Calories', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'calories_unit',
					'type'        => esc_html__( 'Recipe - Calories Unit', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'ingredients_title',
					'type'        => esc_html__( 'Recipe - Ingredients Section Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'instructions_title',
					'type'        => esc_html__( 'Recipe - Instructions Section Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'notes_title',
					'type'        => esc_html__( 'Recipe - Notes Section Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'item_notes',
					'type'        => esc_html__( 'Recipe - Item Notes', 'powerpack' ),
					'editor_type' => 'VISUAL',
				],
				[
					'field'       => 'keyword_list',
					'type'        => esc_html__( 'Recipe - Keywords', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'recipe_cuisine',
					'type'        => esc_html__( 'Recipe - Cuisine', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'recipe_category',
					'type'        => esc_html__( 'Recipe - Category', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'print_button_text',
					'type'        => esc_html__( 'Recipe - Print Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => [
				'WPML_PP_Recipe_Ingredients',
				'WPML_PP_Recipe_Instructions',
			],
		];
		$widgets['pp-registration-form'] = [
			'conditions'        => [ 'widgetType' => 'pp-registration-form' ],
			'fields'            => [
				[
					'field'       => 'button_text',
					'type'        => esc_html__( 'Registration Form - Register Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'email_subject',
					'type'        => esc_html__( 'Registration Form - Email Subject (User)', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'email_content',
					'type'        => esc_html__( 'Registration Form - Email Content (User)', 'powerpack' ),
					'editor_type' => 'VISUAL',
				],
				[
					'field'       => 'email_from_name',
					'type'        => esc_html__( 'Registration Form - Email From Name (User)', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'admin_email_subject',
					'type'        => esc_html__( 'Registration Form - Email Subject (Admin)', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'admin_email_content',
					'type'        => esc_html__( 'Registration Form - Email Content (Admin)', 'powerpack' ),
					'editor_type' => 'VISUAL',
				],
				[
					'field'       => 'success_message',
					'type'        => esc_html__( 'Registration Form - Success Message', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'login_text',
					'type'        => esc_html__( 'Registration Form - Login Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'lost_password_text',
					'type'        => esc_html__( 'Registration Form - Lost Password Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'links_divider',
					'type'        => esc_html__( 'Registration Form - Links Divider', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'logged_in_text',
					'type'        => esc_html__( 'Registration Form - Message For Logged In Users', 'powerpack' ),
					'editor_type' => 'VISUAL',
				],
			],
			'integration-class' => 'WPML_PP_Registration_Form',
		];
		$widgets['pp-review-box'] = [
			'conditions'        => [ 'widgetType' => 'pp-review-box' ],
			'fields'            => [
				[
					'field'       => 'box_title',
					'type'        => esc_html__( 'Review Box - Review Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'review_description',
					'type'        => esc_html__( 'Review Box - Review Description', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				[
					'field'       => 'final_rating_title',
					'type'        => esc_html__( 'Review Box - Final Rating Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'pros_title',
					'type'        => esc_html__( 'Review Box - Pros Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'cons_title',
					'type'        => esc_html__( 'Review Box - Cons Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'summary_title',
					'type'        => esc_html__( 'Review Box - Summary Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'summary_text',
					'type'        => esc_html__( 'Review Box - Summary Text', 'powerpack' ),
					'editor_type' => 'AREA',
				],
			],
			'integration-class' => [
				'WPML_PP_Review_Box',
				'WPML_PP_Review_Box_Pros',
				'WPML_PP_Review_Box_Cons',
			],
		];
		$widgets['pp-scroll-image'] = [
			'conditions' => [ 'widgetType' => 'pp-scroll-image' ],
			'fields'     => [
				'link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Scroll Image - URL', 'powerpack' ),
					'editor_type' => 'LINK',
				],
			],
		];
		$widgets['pp-showcase'] = [
			'conditions'        => [ 'widgetType' => 'pp-showcase' ],
			'fields'            => [
				'posts_link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Showcase - Posts Link', 'powerpack' ),
					'editor_type' => 'LINK',
				],
			],
			'integration-class' => 'WPML_PP_Showcase',
		];
		$widgets['pp-sitemap'] = [
			'conditions'        => [ 'widgetType' => 'pp-sitemap' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Sitemap',
		];
		$widgets['pp-slide-menu'] = [
			'conditions' => [ 'widgetType' => 'pp-slide-menu' ],
			'fields'     => [
				[
					'field'       => 'back_text',
					'type'        => esc_html__( 'Slide Menu - Back Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-tabbed-gallery'] = [
			'conditions'        => [ 'widgetType' => 'pp-tabbed-gallery' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Tabbed_Gallery',
		];
		$widgets['pp-table'] = [
			'conditions'        => [ 'widgetType' => 'pp-table' ],
			'fields'            => [],
			'integration-class' => [
				'WPML_PP_Table_Header',
				'WPML_PP_Table_Body',
				'WPML_PP_Table_Footer',
			],
		];
		$widgets['pp-table-of-contents'] = [
			'conditions' => [ 'widgetType' => 'pp-table-of-contents' ],
			'fields'     => [
				[
					'field'       => 'title',
					'type'        => esc_html__( 'Table of Contents - Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-team-member'] = [
			'conditions'        => [ 'widgetType' => 'pp-team-member' ],
			'fields'            => [
				[
					'field'       => 'team_member_name',
					'type'        => esc_html__( 'Team Member - Name', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'team_member_position',
					'type'        => esc_html__( 'Team Member - Position', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'team_member_description',
					'type'        => esc_html__( 'Team Member - Description', 'powerpack' ),
					'editor_type' => 'VISUAL',
				],
				'link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Team Member - URL', 'powerpack' ),
					'editor_type' => 'LINK',
				],
			],
			'integration-class' => 'WPML_PP_Team_Member',
		];
		$widgets['pp-team-member-carousel'] = [
			'conditions'        => [ 'widgetType' => 'pp-team-member-carousel' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Team_Member_Carousel',
		];
		$widgets['pp-testimonials'] = [
			'conditions'        => [ 'widgetType' => 'pp-testimonials' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Testimonials',
		];
		$widgets['pp-tiled-posts'] = [
			'conditions' => [ 'widgetType' => 'pp-tiled-posts' ],
			'fields'     => [
				[
					'field'       => 'post_meta_divider',
					'type'        => esc_html__( 'Tiled Posts - Post Meta Divider', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'read_more_button_text',
					'type'        => esc_html__( 'Tiled Posts - Read More Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-timeline'] = [
			'conditions'        => [ 'widgetType' => 'pp-timeline' ],
			'fields'            => [
				[
					'field'       => 'button_text',
					'type'        => esc_html__( 'Timeline - Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'meta_items_divider',
					'type'        => esc_html__( 'Timeline - Meta Items Divider', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'posts_link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Timeline - Posts Link', 'powerpack' ),
					'editor_type' => 'LINK',
				],
			],
			'integration-class' => 'WPML_PP_Timeline',
		];
		$widgets['pp-toggle'] = [
			'conditions' => [ 'widgetType' => 'pp-toggle' ],
			'fields'     => [
				[
					'field'       => 'primary_label',
					'type'        => esc_html__( 'Toggle - Primary Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'primary_content',
					'type'        => esc_html__( 'Toggle - Primary Content', 'powerpack' ),
					'editor_type' => 'VISUAL',
				],
				[
					'field'       => 'secondary_label',
					'type'        => esc_html__( 'Toggle - Secondary Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'secondary_content',
					'type'        => esc_html__( 'Toggle - Secondary Content', 'powerpack' ),
					'editor_type' => 'VISUAL',
				],
			],
		];
		$widgets['pp-twitter-buttons'] = [
			'conditions' => [ 'widgetType' => 'pp-twitter-buttons' ],
			'fields'     => [
				[
					'field'       => 'profile',
					'type'        => esc_html__( 'Twitter Button - Profile URL or Username', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'recipient_id',
					'type'        => esc_html__( 'Twitter Button - Recipient Id', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'default_text',
					'type'        => esc_html__( 'Twitter Button - Default Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'hashtag_url',
					'type'        => esc_html__( 'Twitter Button - Hashtag URL or #hashtag', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'via',
					'type'        => esc_html__( 'Twitter Button - Via (twitter handler)', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'share_text',
					'type'        => esc_html__( 'Twitter Button - Custom Share Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'share_url',
					'type'        => esc_html__( 'Twitter Button - Custom Share URL', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-twitter-grid'] = [
			'conditions' => [ 'widgetType' => 'pp-twitter-grid' ],
			'fields'     => [
				[
					'field'       => 'url',
					'type'        => esc_html__( 'Twitter Grid - Collection URL', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'tweet_limit',
					'type'        => esc_html__( 'Twitter Grid - Tweet Limit', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-twitter-timeline'] = [
			'conditions' => [ 'widgetType' => 'pp-twitter-timeline' ],
			'fields'     => [
				[
					'field'       => 'username',
					'type'        => esc_html__( 'Twitter Timeline - Username', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'tweet_limit',
					'type'        => esc_html__( 'Twitter Timeline - Tweet Limit', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-twitter-tweet'] = [
			'conditions' => [ 'widgetType' => 'pp-twitter-tweet' ],
			'fields'     => [
				[
					'field'       => 'tweet_url',
					'type'        => esc_html__( 'Twitter Tweet - Tweet URL', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-video'] = [
			'conditions' => [ 'widgetType' => 'pp-video' ],
			'fields'     => [
				[
					'field'       => 'youtube_url',
					'type'        => esc_html__( 'Video - YouTube URL', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'vimeo_url',
					'type'        => esc_html__( 'Video - Vimeo URL', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'dailymotion_url',
					'type'        => esc_html__( 'Video - Dailymotion URL', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'start_time',
					'type'        => esc_html__( 'Video - Start Time', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'end_time',
					'type'        => esc_html__( 'Video - End Time', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'sticky_info_bar_text',
					'type'        => esc_html__( 'Video - Sticky Info Bar Text', 'powerpack' ),
					'editor_type' => 'VISUAL',
				],
				'external_url' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Video - External URL', 'powerpack' ),
					'editor_type' => 'LINK',
				],
			],
		];
		$widgets['pp-video-gallery'] = [
			'conditions'        => [ 'widgetType' => 'pp-video-gallery' ],
			'fields'            => [
				[
					'field'       => 'filter_all_label',
					'type'        => esc_html__( 'Video Gallery - "All" Filter Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'yt_video_title',
					'type'        => esc_html__( 'Video Gallery - YouTube Video Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'yt_video_description',
					'type'        => esc_html__( 'Video Gallery - YouTube Video Description', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				[
					'field'       => 'load_more_text',
					'type'        => esc_html__( 'Video Gallery - Load More Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => 'WPML_PP_Video_Gallery',
		];
		$widgets['pp-woo-add-to-cart'] = [
			'conditions' => [ 'widgetType' => 'pp-woo-add-to-cart' ],
			'fields'     => [
				[
					'field'       => 'btn_text',
					'type'        => esc_html__( 'Woo Add to Cart - Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-woo-cart'] = [
			'conditions' => [ 'widgetType' => 'pp-woo-cart' ],
			'fields'     => [
				[
					'field'       => 'update_cart_button_text',
					'type'        => esc_html__( 'Woo Cart - Update Cart Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'apply_coupon_button_text',
					'type'        => esc_html__( 'Woo Cart - Apply Coupon Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'totals_section_title',
					'type'        => esc_html__( 'Woo Cart - Totals Section Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'update_shipping_button_text',
					'type'        => esc_html__( 'Woo Cart - Update Shipping Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'checkout_button_text',
					'type'        => esc_html__( 'Woo Cart - Checkout Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-woo-checkout'] = [
			'conditions'        => [ 'widgetType' => 'pp-woo-checkout' ],
			'fields'            => [
				[
					'field'       => 'returning_customer_section_title',
					'type'        => esc_html__( 'Woo Checkout - Returning Customer Section Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'returning_customer_link_text',
					'type'        => esc_html__( 'Woo Checkout - Returning Customer Link Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'billing_details_section_title',
					'type'        => esc_html__( 'Woo Checkout - Billing Details Section Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'shipping_details_section_title',
					'type'        => esc_html__( 'Woo Checkout - Shipping Details Section Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'additional_information_section_title',
					'type'        => esc_html__( 'Woo Checkout - Additional Information Section Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'create_account_text',
					'type'        => esc_html__( 'Woo Checkout - Create Account Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'order_summary_section_title',
					'type'        => esc_html__( 'Woo Checkout - Order Summary Section Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'coupon_section_title_text',
					'type'        => esc_html__( 'Woo Checkout - Coupon Section Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'coupon_section_title_link_text',
					'type'        => esc_html__( 'Woo Checkout - Coupon Section Link Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'terms_conditions_message_text',
					'type'        => esc_html__( 'Woo Checkout - Terms & Conditions Message', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'terms_conditions_link_text',
					'type'        => esc_html__( 'Woo Checkout - Terms & Conditions Link Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
			'integration-class' => [
				'WPML_PP_Woo_Checkout_Billing',
				'WPML_PP_Woo_Checkout_Shipping',
				'WPML_PP_Woo_Checkout_Additional_Information',
			],
		];
		$widgets['pp-woo-mini-cart'] = [
			'conditions' => [ 'widgetType' => 'pp-woo-mini-cart' ],
			'fields'     => [
				[
					'field'       => 'cart_text',
					'type'        => esc_html__( 'Woo Mini Cart - Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'cart_title',
					'type'        => esc_html__( 'Woo Mini Cart - Cart Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'cart_message',
					'type'        => esc_html__( 'Woo Mini Cart - Cart Message', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				'link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Woo Mini Cart - Link', 'powerpack' ),
					'editor_type' => 'LINK',
				],
			],
		];
		$widgets['pp-woo-my-account'] = [
			'conditions' => [ 'widgetType' => 'pp-woo-my-account' ],
			'fields'     => [
				[
					'field'       => 'dashboard_tab_name',
					'type'        => esc_html__( 'Woo My Account - Dashboard Tab Name', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'orders_tab_name',
					'type'        => esc_html__( 'Woo My Account - Orders Tab Name', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'downloads_tab_name',
					'type'        => esc_html__( 'Woo My Account - Downloads Tab Name', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'addresses_tab_name',
					'type'        => esc_html__( 'Woo My Account - Addresses Tab Name', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'account_details_tab_name',
					'type'        => esc_html__( 'Woo My Account - Account Details Tab Name', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'logout_link_tab_name',
					'type'        => esc_html__( 'Woo My Account - Logout Link Tab Name', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-woo-offcanvas-cart'] = [
			'conditions' => [ 'widgetType' => 'pp-woo-offcanvas-cart' ],
			'fields'     => [
				[
					'field'       => 'cart_text',
					'type'        => esc_html__( 'Woo Off Canvas Cart - Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'cart_title',
					'type'        => esc_html__( 'Woo Off Canvas Cart - Cart Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'cart_message',
					'type'        => esc_html__( 'Woo Off Canvas Cart - Cart Message', 'powerpack' ),
					'editor_type' => 'AREA',
				],
			],
		];
		$widgets['pp-woo-product-meta'] = [
			'conditions' => [ 'widgetType' => 'pp-woo-product-meta' ],
			'fields'     => [
				[
					'field'       => 'category_caption_single',
					'type'        => esc_html__( 'Woo Product Meta - Category Singular', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'category_caption_plural',
					'type'        => esc_html__( 'Woo Product Meta - Category Plural', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'tag_caption_single',
					'type'        => esc_html__( 'Woo Product Meta - Tag Singular', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'tag_caption_plural',
					'type'        => esc_html__( 'Woo Product Meta - Tag Plural', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'sku_caption',
					'type'        => esc_html__( 'Woo Product Meta - SKU Caption', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'sku_missing_caption',
					'type'        => esc_html__( 'Woo Product Meta - SKU Missing Caption', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-woo-product-tabs'] = [
			'conditions'        => [ 'widgetType' => 'pp-woo-product-tabs' ],
			'fields'            => [],
			'integration-class' => 'WPML_PP_Woo_Product_Tabs',
		];
		$widgets['pp-woo-product-title'] = [
			'conditions' => [ 'widgetType' => 'pp-woo-product-title' ],
			'fields'     => [
				'link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Woo Product Title - Link', 'powerpack' ),
					'editor_type' => 'LINK',
				],
			],
		];
		$widgets['pp-woo-products'] = [
			'conditions' => [ 'widgetType' => 'pp-woo-products' ],
			'fields'     => [
				[
					'field'       => 'sale_badge_custom_text',
					'type'        => esc_html__( 'Woo Products - Sale Badge Custom Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'no_products_message',
					'type'        => esc_html__( 'Woo Products - No Products Message', 'powerpack' ),
					'editor_type' => 'AREA',
				],
				[
					'field'       => 'add_to_cart_simple_text',
					'type'        => esc_html__( 'Woo Products - Add to Cart Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'add_to_cart_variable_text',
					'type'        => esc_html__( 'Woo Products - Select Options Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'add_to_cart_group_text',
					'type'        => esc_html__( 'Woo Products - View Products Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'add_to_cart_read_more_text',
					'type'        => esc_html__( 'Woo Products - Read More Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'out_of_stock_text',
					'type'        => esc_html__( 'Woo Products - Out of Stock Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'featured_badge_custom_text',
					'type'        => esc_html__( 'Woo Products - Featured Badge Custom Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'top_rating_badge_custom_text',
					'type'        => esc_html__( 'Woo Products - Top Rating Badge Custom Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'best_selling_badge_custom_text',
					'type'        => esc_html__( 'Woo Products - Best Selling Badge Custom Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'quick_view_text',
					'type'        => esc_html__( 'Woo Products - Quick View Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-woo-single-product'] = [
			'conditions' => [ 'widgetType' => 'pp-woo-single-product' ],
			'fields'     => [
				[
					'field'       => 'product_rating_text',
					'type'        => esc_html__( 'Woo Single Product - Custom Rating Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'button_text',
					'type'        => esc_html__( 'Woo Single Product - Custom Button Text', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				'button_link' => [
					'field'       => 'url',
					'type'        => esc_html__( 'Woo Single Product - Custom Button Link', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'taxonomy_custom_text',
					'type'        => esc_html__( 'Woo Single Product - Custom Taxonomy Label', 'powerpack' ),
					'editor_type' => 'LINE',
				],
			],
		];
		$widgets['pp-wpforms'] = [
			'conditions' => [ 'widgetType' => 'pp-wpforms' ],
			'fields'     => [
				[
					'field'       => 'form_title_custom',
					'type'        => esc_html__( 'WPForms - Title', 'powerpack' ),
					'editor_type' => 'LINE',
				],
				[
					'field'       => 'form_description_custom',
					'type'        => esc_html__( 'WPForms - Description', 'powerpack' ),
					'editor_type' => 'AREA',
				],
			],
		];

		$this->init_classes();

		// PowerPack extensions attach their controls to Elementor's 'common' element,
		// so they can appear on any widget. WPML matches translatable fields by widget
		// type, so the extension fields are appended to every registered widget. Fields
		// with no value on a given widget are skipped by WPML at registration time.
		$extension_fields = $this->get_extension_fields();

		foreach ( $widgets as $widget_type => $widget ) {
			if ( ! isset( $widget['fields'] ) || ! is_array( $widget['fields'] ) ) {
				continue;
			}

			$widgets[ $widget_type ]['fields'] = array_merge( $widget['fields'], $extension_fields );
		}

		return $widgets;
	}

	private function init_classes() {
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-advanced-accordion.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-advanced-tabs.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-business-hours.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-buttons.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-card-slider.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-content-ticker.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-coupons.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-event-calendar.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-faq.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-google-maps.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-how-to.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-icon-list.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-info-box-carousel.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-info-list.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-image-accordion.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-image-gallery.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-image-hotspots.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-logo-carousel.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-logo-grid.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-offcanvas-content.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-one-page-nav.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-price-menu.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-pricing-table.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-recipe.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-review-box.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-showcase.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-tabbed-gallery.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-team-member.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-team-member-carousel.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-testimonials.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-timeline.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-video-gallery.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-table.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-registration-form.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-sitemap.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-progress-bar.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-interactive-circle.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-charts.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-marquee.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-woo-checkout.php';
		require_once POWERPACK_ELEMENTS_PATH . 'classes/wpml/class-wpml-pp-woo-product-tabs.php';
	}
}

$pp_elements_wpml = new PP_Elements_WPML();
