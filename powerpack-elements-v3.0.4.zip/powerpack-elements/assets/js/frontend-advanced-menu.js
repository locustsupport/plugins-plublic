;(function($) {
	PPAdvancedMenu = function( $scope, elementSettings ) {
		this.node         = $scope;
		this.menu_wrap    = $scope.find( '.pp-advanced-menu-main-wrapper' );
		this.wrap         = $scope.find( '.pp-advanced-menu__container' );
		this.menu         = $scope.find( '.pp-advanced-menu' );
		this.dropdownMenu = $scope.find( '.pp-advanced-menu__container.pp-advanced-menu--dropdown' );
		this.anchorLink   = $scope.find( '.pp-advanced-menu--main .pp-menu-item-anchor' );
		this.menuItemLink = $scope.find( '.pp-advanced-menu--main .pp-menu-item' );
		this.menuToggle   = $scope.find( '.pp-menu-toggle' ); // hamburger icon
		this.settings     = $scope.find( '.pp-advanced-menu__container' ).data( 'settings' );

		if ( ! this.settings ) {
			return;
		}

		this.menuId             = this.settings.menu_id;
		this.menuType           = elementSettings.menu_type;
		this.fullWidth          = elementSettings.full_width;
		this.menuLayout         = elementSettings.layout;
		this.showSubmenuOn      = elementSettings.show_submenu_on;
		this.showSubmenuOnClick = ( this.showSubmenuOn == 'click' );
		this.showResponsiveSubmenuOn = elementSettings.show_responsive_submenu_on ? elementSettings.show_responsive_submenu_on : 'icon';
		this.onepage_menu       = elementSettings.onepage_menu;
		this.duration           = 400;

		//this.iconValue = this.settings.submenu_icon.value;
		this.iconValue            = elementSettings.submenu_icon.value;
		this.subIndicatorsContent = '';

		if ( this.iconValue ) {
			// this.subIndicatorsContent = this.iconValue.indexOf( '<' ) > -1 ? this.iconValue : '<i class="${this.iconValue}"></i>';
			if ( 'svg' === elementSettings.submenu_icon.library && elementorFrontend.isEditMode() ) {
				// var svgimage = this.iconValue.url;
				this.subIndicatorsContent = this.menu_wrap.attr( 'data-subicon-indicator' );
			} else {
				const iconVal = String(this.iconValue);
				this.subIndicatorsContent = iconVal.indexOf('<') > -1 ? iconVal : `<i class="${iconVal}"></i>`;
			}
		}

		this.init();
	};

	PPAdvancedMenu.prototype = {
		stretchElement: null,

		init: function () {

			if ( ! this.menu.length ) {
				return;
			}

			if ( jQuery.fn.smartmenus ) {
				// Override the default stupid detection
				jQuery.SmartMenus.prototype.isCSSOn = function() {
					return true;
				};

				if ( elementorFrontend.config.is_rtl  ) {
					jQuery.fn.smartmenus.defaults.rightToLeftSubMenus = true;
				}
			}

			if ( 'horizontal' === this.menuLayout ) {
				if ('undefined' !== typeof $.fn.smartmenus) {
					var showResponsiveSubmenuOn = this.showResponsiveSubmenuOn,
					subMenuSel;

					if ( 'icon' === this.showResponsiveSubmenuOn ) {
						subMenuSel = 'span.sub-arrow';
					} else {
						subMenuSel = '.pp-menu-item, .pp-sub-item';
					}

					this.menu.smartmenus(
						{
							subIndicators: '' !== this.subIndicatorsContent,
							subIndicatorsText: this.subIndicatorsContent,
							subIndicatorsPos: 'append',
							subMenusMaxWidth: '1000px',
							subMenusMinWidth: '',
							showOnClick: this.showSubmenuOnClick,
							noMouseOver: this.showSubmenuOnClick,
							collapsibleBehavior: 'link',
						}
					).on('click', subMenuSel, function(e) {
						if ( $(this).parents('.pp-advanced-menu--dropdown').length ) {
							var menuToggle = false;

							if ( 'icon' !== showResponsiveSubmenuOn ) {
								if ( $(this).hasClass('has-submenu') ) {
									var ppanchorsubMenuObj = $(this);
									menuToggle = true;
								}
							} else {
								var ppanchorsubMenuObj = $(this).closest( 'a.has-submenu' );
								menuToggle = true;
							}

							if ( menuToggle ) {
								ppanchorsubMenuObj.toggleClass( 'highlighted' );
								ppanchorsubMenuObj.attr( 'aria-expanded',
									ppanchorsubMenuObj.attr( 'aria-expanded' ) == 'false' ? 'true' : 'false'
								);

								var ppsubMenuObj = ppanchorsubMenuObj.siblings( 'ul' );

								ppsubMenuObj.attr( 'aria-hidden',
									ppsubMenuObj.attr( 'aria-hidden' ) == 'false' ? 'true' : 'false'
								);

								ppsubMenuObj.attr( 'aria-expanded',
									ppsubMenuObj.attr( 'aria-expanded' ) == 'false' ? 'true' : 'false'
								);

								if ( 'true' === ppsubMenuObj.attr( 'aria-expanded' ) ) {
									ppsubMenuObj.css( { width: 'auto', display: 'block' } );
								} else {
									ppsubMenuObj.css( { width: 'auto', display: 'none' } );
								}

								e.preventDefault();
								e.stopPropagation();
							}
						}
					});
				}
			}

			if ( 'vertical' === this.menuLayout ) {
				if ('undefined' !== typeof $.fn.smartmenus) {
					var showResponsiveSubmenuOn = this.showResponsiveSubmenuOn,
					subMenuSel;

					if ( 'icon' === this.showResponsiveSubmenuOn ) {
						subMenuSel = 'span.sub-arrow';
					} else {
						subMenuSel = '.pp-menu-item, .pp-sub-item';
					}

					var that = this;

					this.menu.smartmenus(
						{
							subIndicators: '' !== this.subIndicatorsContent,
							subIndicatorsText: this.subIndicatorsContent,
							subIndicatorsPos: 'append',
							subMenusMaxWidth: '',
							subMenusMinWidth: '',
							mainMenuSubOffsetX: '0px',
							mainMenuSubOffsetY: '0px',
							subMenusSubOffsetX: '0px',
							subMenusSubOffsetY: '0px',
							showOnClick: this.showSubmenuOnClick,
							noMouseOver: this.showSubmenuOnClick,
							collapsibleBehavior: 'link',
						}
					).on('click', subMenuSel, function(e) {
						if ( $(this).parents('.pp-advanced-menu--dropdown').length ) {
							var menuToggle = false;

							if ( 'icon' !== showResponsiveSubmenuOn ) {
								if ( $(this).hasClass('has-submenu') ) {
									var ppanchorsubMenuObj = $(this);
									menuToggle = true;
								}
							} else {
								var ppanchorsubMenuObj = $(this).closest( 'a.has-submenu' );
								menuToggle = true;
							}

							if ( menuToggle ) {
								ppanchorsubMenuObj.toggleClass( 'highlighted' );
								ppanchorsubMenuObj.attr( 'aria-expanded',
									ppanchorsubMenuObj.attr( 'aria-expanded' ) == 'false' ? 'true' : 'false'
								);

								var ppsubMenuObj = ppanchorsubMenuObj.siblings( 'ul' );

								ppsubMenuObj.attr( 'aria-hidden',
									ppsubMenuObj.attr( 'aria-hidden' ) == 'false' ? 'true' : 'false'
								);

								ppsubMenuObj.attr( 'aria-expanded',
									ppsubMenuObj.attr( 'aria-expanded' ) == 'false' ? 'true' : 'false'
								);

								if ( 'icon' === that.showResponsiveSubmenuOn ) {
									if ( 'true' === ppsubMenuObj.attr( 'aria-expanded' ) ) {
										ppsubMenuObj.css( { width: 'auto', display: 'block' } );
									} else {
										ppsubMenuObj.css( { width: 'auto', display: 'none' } );
									}
								} else {
									if ( 'false' === ppsubMenuObj.attr( 'aria-expanded' ) ) {
										ppsubMenuObj.css( { width: 'auto', display: 'block' } );
									} else {
										ppsubMenuObj.css( { width: 'auto', display: 'none' } );
									}
								}

								e.preventDefault();
								e.stopPropagation();
							}
						}
					});
				}
			}

			if ( 'default' === this.menuType ) {
				this.initStretchElement();
				this.stretchMenu();
			}

			if ('off-canvas' === this.menuType) {
				this.initOffCanvas();
			}

			if ('full-screen' === this.menuType) {
				this.initFullScreen();
			}

			this.bindEvents();

			if ( ! elementorFrontend.isEditMode() ) {
				this.followMenuAnchors();
			}

			$( window ).on( 'load', $.proxy( this.resetDimensions, this ) );

			this.menu.smartmenus( 'refresh' );

			this.menu.attr( 'aria-label', this.menu.parent().attr( 'aria-label' ) );
			this.menu.attr( 'role', 'menubar' );

			let ulAttrs = this.menu.find( 'ul' );
			ulAttrs.attr( 'role', 'menu' );
			ulAttrs.each( function() {
				$( this ).attr( 'aria-label', $( this ).siblings( 'a' ).text() );
			} );

			this.menu.find( 'li' ).attr( 'role', 'none' );

			this.menu.find( 'a' ).attr( 'role', 'menuitem' );
		},

		getElementSettings: function( setting ) {
			if ( 'undefined' !== typeof this.settings[setting] ) {
				return this.settings[setting];
			}

			return false;
		},

		bindEvents: function () {
			var self = this;

			if ( ! this.menu.length ) {
				return;
			}

			this.menuToggle.on( 'click', $.proxy( this.toggleMenu, this ) );
			this.menuToggle.on( 'keydown', $.proxy( this.handleToggleKeydown, this ) );

			if ( 'yes' === this.onepage_menu ) {
				this.menu.on(
					'click',
					'.menu-item > a[href*="#"]',
					function(e) {

						var $href = $( this ).attr( 'href' ),
						$targetID = '',
						target;

						if ( $href === '#' ) {
							return;
						}

						$targetID = $href.split( '#' )[1];
						target    = self.getAnchorTarget( $targetID );

						if ( target ) {
							e.preventDefault();
							$( this ).toggleClass( 'pp-active' );
						}

						self.closeMenu();

						if ( target ) {
							self.scrollToAnchor( target, $targetID );
						}
					}
				);
			}

			if ('default' === this.menuType) {
				elementorFrontend.addListenerOnce( this.node.data( 'model-cid' ), 'resize', $.proxy( this.stretchMenu, this ) );
			}

			//self.panelUpdate();

			this.closeMenuESC();
		},

		/**
		 * Element a one page link points to, or null when the page has no such ID.
		 *
		 * Resolved with 'getElementById' rather than by building a '#id' selector:
		 * a hash that is not a valid CSS identifier - one starting with a digit,
		 * or holding a dot, a colon or a percent encoded character - matches
		 * nothing as a selector, so those links used to fall through to a plain
		 * browser jump with no smooth scroll and no offset.
		 *
		 * @since x.x.x
		 */
		getAnchorTarget: function( targetID ) {
			var id = targetID;

			if ( ! id ) {
				return null;
			}

			try {
				id = decodeURIComponent( id );
			} catch ( err ) {
				// Malformed escape sequence - fall back to the raw hash.
			}

			return document.getElementById( id ) || document.getElementById( targetID );
		},

		/**
		 * Scroll the page to a one page link's target.
		 *
		 * Deferred by a tick so that it runs after the click has finished being
		 * handled, and queued with 'stop()' so that tapping a second link while
		 * the first scroll is still running retargets it instead of queueing
		 * behind it.
		 *
		 * @since x.x.x
		 */
		scrollToAnchor: function( target, targetID ) {
			var self = this;

			setTimeout( function() {
				var top = $( target ).offset().top - self.getAnchorOffset();

				$( 'html, body' ).stop( true ).animate(
					{
						scrollTop: Math.max( 0, top )
					},
					50,
					'linear',
					function() {
						self.setAnchorHash( targetID );
					}
				);
			}, 0 );
		},

		/**
		 * Put a one page link's target in the address bar.
		 *
		 * Written with 'pushState' rather than by assigning 'location.hash':
		 * assigning it makes the browser jump to the element, which lands it hard
		 * against the top of the viewport and undoes the offset just scrolled to.
		 * Widgets that open from the URL - Popup Box, Accordion, Advanced Tabs -
		 * listen for 'hashchange', which 'pushState' does not fire, so the event
		 * is dispatched here.
		 *
		 * @since x.x.x
		 */
		setAnchorHash: function( targetID ) {
			var hash = '#' + targetID,
				oldURL = window.location.href;

			if ( window.location.hash === hash ) {
				return;
			}

			if ( ! window.history || ! window.history.pushState ) {
				window.location.hash = targetID;
				return;
			}

			window.history.pushState( null, '', hash );

			try {
				window.dispatchEvent( new HashChangeEvent( 'hashchange', {
					oldURL: oldURL,
					newURL: window.location.href
				} ) );
			} catch ( err ) {
				$( window ).trigger( 'hashchange' );
			}
		},

		/**
		 * Height to keep clear above a one page link's target.
		 *
		 * Only elements currently pinned to the top of the viewport are measured,
		 * so sites without a sticky header scroll exactly as they did before.
		 *
		 * @since x.x.x
		 */
		getAnchorOffset: function() {
			var offset = 0;

			$( '#wpadminbar' ).each( function() {
				if ( 'fixed' === $( this ).css( 'position' ) ) {
					offset += $( this ).outerHeight();
				}
			} );

			$( '.elementor-sticky--effects' ).each( function() {
				var $el = $( this ),
					top = $el.offset().top - $( window ).scrollTop();

				// Pinned to the top of the viewport, rather than to the bottom.
				if ( top <= offset ) {
					offset += $el.outerHeight();
				}
			} );

			return offset;
		},

		panelUpdate: function() {
			var self = this;

			if ('undefined' !== typeof elementor && $( 'body' ).hasClass( 'elementor-editor-active' )) {
				elementor.hooks.addAction(
					'panel/open_editor/widget/pp-advanced-menu',
					function (panel, model, view) {
						panel.$el.find( 'select[data-setting="dropdown"]' ).on(
							'change',
							function () {
								if (model.attributes.id === self.menuId) {
									if ($( this ).val() === 'all') {
										self.node.find( '.pp-advanced-menu--main' ).hide();
									}
									if ($( this ).val() !== 'all') {
										self.node.find( '.pp-advanced-menu--main' ).show();
									}
								}
							}
						);

						if (model.attributes.id === self.menuId && 'all' === self.settings.breakpoint) {
							self.toggleMenu();
						}
					}
				);
			}
		},

		initStretchElement: function () {
			this.stretchElement = new elementorFrontend.modules.StretchElement( { element: this.dropdownMenu } );
		},

		stretchMenu: function () {
			if ( 'stretch' == this.fullWidth ) {
				this.stretchElement.stretch();

				this.dropdownMenu.css( 'top', this.menuToggle.outerHeight() );
			} else {
				this.stretchElement.reset();
			}
		},

		initOffCanvas: function () {
			$( '.pp-menu-' + this.settings.menu_id ).each(
				function(id, el) {
					if ($( el ).parent().is( 'body' ) ) {
						$( el ).remove();
					}
				}
			);

			/* if ( $('.pp-offcanvas-container').length === 0 ) {
				$('body').wrapInner( '<div class="pp-offcanvas-container" />' );
				this.node.find( '.pp-menu-' + this.settings.menu_id ).insertBefore('.pp-offcanvas-container');
			} */

			if ( this.menu_wrap.find( '.pp-menu-off-canvas' ).length > 0 ) {
				if ( $( '.pp-offcanvas-container > .pp-menu-' + this.settings.menu_id ).length > 0 ) {
					$( '.pp-offcanvas-container > .pp-menu-' + this.settings.menu_id ).remove();
				}
				if ( $( 'body > .pp-menu-' + this.settings.menu_id ).length > 0 ) {
					$( 'body > .pp-menu-' + this.settings.menu_id ).remove();
				}
				$( 'body' ).prepend( this.node.find( '.pp-menu-' + this.settings.menu_id ) );
			}

			$( '.pp-menu-clear' ).fadeOut(
				400,
				function() {
					$( this ).remove();
				}
			);

			$( '.pp-menu-' + this.settings.menu_id ).css( 'height', window.innerHeight + 150 + 'px' );
			$( '.pp-menu-' + this.settings.menu_id ).find( '.pp-menu-close' )
				.on( 'click', $.proxy( this.closeMenu, this ) )
				.on( 'keydown', $.proxy( this.handleCloseKeydown, this ) );
		},

		initFullScreen: function () {
			$( 'body' ).addClass( 'pp-menu--full-screen' );
			$( '.pp-menu-' + this.settings.menu_id ).css( 'height', window.innerHeight + 150 + 'px' );
			$( '.pp-menu-' + this.settings.menu_id ).find( '.pp-menu-close' )
				.on( 'click', $.proxy( this.closeMenu, this ) )
				.on( 'keydown', $.proxy( this.handleCloseKeydown, this ) );
			//$('.pp-menu-' + this.settings.menu_id).find('.menu-item a').on('click', $.proxy(this.closeMenu, this));
		},

		resetDimensions: function() {
			if ( 'full-screen' === this.menuType ) {
				$( '.pp-menu-' + this.settings.menu_id ).css( 'height', window.innerHeight + 150 + 'px' );
			}
		},

		toggleMenu: function () {
			this.menuToggle.toggleClass( 'pp-active' );

			var menuType = this.menuType;
			var isActive = this.menuToggle.hasClass( 'pp-active' );

			this.menuToggle.attr( 'aria-expanded', isActive ? 'true' : 'false' );

			$( 'html' ).removeClass( 'pp-menu-toggle-open' );

			if ( isActive ) {
				$( 'html' ).addClass( 'pp-menu-toggle-open' );
			}

			if ('default' === menuType) {
				var $dropdownMenu = this.dropdownMenu;

				if (isActive) {
					$dropdownMenu.hide().slideDown(
						250,
						function () {
							$dropdownMenu.css( 'display', '' );
						}
					);

					this.stretchMenu();
				} else {
					$dropdownMenu.show().slideUp(
						250,
						function () {
							$dropdownMenu.css( 'display', '' );
						}
					);
				}
			}

			if ('off-canvas' === menuType) {
				this.toggleOffCanvas();
			}
			if ('full-screen' === menuType) {
				this.toggleFullScreen();
			}
		},

		toggleOffCanvas: function() {
			var isActive = this.menuToggle.hasClass( 'pp-active' ),
				element  = $( 'body' ).find( '.pp-menu-' + this.menuId ),
				time     = this.duration,
				self     = this;

			$( 'html' ).removeClass( 'pp-menu-toggle-open' );

			if ( isActive ) {
				$( 'body' ).addClass( 'pp-menu--off-canvas' );
				$( 'html' ).addClass( 'pp-menu-toggle-open' );
				time = 0;
			} else {
				time = this.duration;
			}

			$( '.pp-menu-open' ).removeClass( 'pp-menu-open' );
			$( '.pp-advanced-menu--toggle .pp-menu-toggle' ).not( this.menuToggle ).removeClass( 'pp-active' );

			setTimeout(
				function() {
					$( '.pp-menu-off-canvas' ).removeAttr( 'style' );

					if (isActive) {
						$( 'body' ).addClass( 'pp-menu-open' );
						element.addClass( 'pp-menu-open' ).css( 'z-index', '999999' );
						if ( $( '.pp-menu-clear' ).length === 0 ) {
							$( 'body' ).append( '<div class="pp-menu-clear" style="transition: none !important;"></div>' );
						}
						$( '.pp-menu-clear' ).off( 'click' ).on( 'click', $.proxy( self.closeMenu, self ) );
						$( '.pp-menu-clear' ).fadeIn();
						self.setPanelOpen();
					} else {
						$( '.pp-menu-open' ).removeClass( 'pp-menu-open' );
						$( 'body' ).removeClass( 'pp-menu--off-canvas' );
						$( 'html' ).removeClass( 'pp-menu-toggle-open' );
						$( '.pp-menu-clear' ).fadeOut();
						self.setPanelClosed();
					}
				},
				time
			);
		},

		toggleFullScreen: function() {
			var isActive = this.menuToggle.hasClass( 'pp-active' ),
				element  = $( 'body' ).find( '.pp-menu-' + this.menuId );

			$( 'html' ).removeClass( 'pp-menu-toggle-open' );

			if ( isActive ) {
				$( 'html' ).addClass( 'pp-menu-toggle-open' );
				this.node.find( '.pp-menu-full-screen' ).addClass( 'pp-menu-open' );
				this.setPanelOpen();
			} else {
				this.setPanelClosed();
			}
		},

		closeMenu: function() {
			if ( 'default' !== this.menuType ) {
				$( '.pp-menu-open' ).removeClass( 'pp-menu-open' );
				this.menuToggle.removeClass( 'pp-active' );

				$( 'html' ).removeClass( 'pp-menu-toggle-open' );

				$( '.pp-menu-clear' ).fadeOut();

				this.setPanelClosed();
			}
		},

		handleToggleKeydown: function( e ) {
			if ( 'Enter' === e.key || ' ' === e.key || 13 === e.keyCode || 32 === e.keyCode ) {
				e.preventDefault();
				this.toggleMenu();
			}
		},

		handleCloseKeydown: function( e ) {
			if ( 'Enter' === e.key || ' ' === e.key || 13 === e.keyCode || 32 === e.keyCode ) {
				e.preventDefault();
				this.closeMenu();
			}
		},

		setPanelOpen: function() {
			if ( 'off-canvas' !== this.menuType && 'full-screen' !== this.menuType ) {
				return;
			}

			this.previouslyFocused = document.activeElement || this.menuToggle[0];

			var $panel = $( '.pp-menu-' + this.menuId );
			$panel.attr( 'aria-hidden', 'false' );
			this.menuToggle.attr( 'aria-expanded', 'true' );

			var $closeBtn = $panel.find( '.pp-menu-close' ).first();
			if ( $closeBtn.length ) {
				$closeBtn.trigger( 'focus' );
			} else {
				var $first = this.getFocusableElements( $panel ).first();
				if ( $first.length ) {
					$first.trigger( 'focus' );
				}
			}

			$( document ).on( 'keydown.ppMenuFocusTrap-' + this.menuId, $.proxy( this.trapFocus, this ) );
		},

		setPanelClosed: function() {
			if ( 'off-canvas' !== this.menuType && 'full-screen' !== this.menuType ) {
				return;
			}

			$( '.pp-menu-' + this.menuId ).attr( 'aria-hidden', 'true' );
			this.menuToggle.attr( 'aria-expanded', 'false' );

			$( document ).off( 'keydown.ppMenuFocusTrap-' + this.menuId );

			// 'preventScroll' so that restoring focus to the toggle does not scroll
			// the page back up to the header - a one page link scrolls away from it.
			if ( this.previouslyFocused && typeof this.previouslyFocused.focus === 'function' ) {
				try {
					this.previouslyFocused.focus( { preventScroll: true } );
				} catch ( err ) {
					if ( this.menuToggle[0] ) {
						this.menuToggle[0].focus( { preventScroll: true } );
					}
				}
			}
			this.previouslyFocused = null;
		},

		getFocusableElements: function( $container ) {
			return $container.find(
				'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"]), input:not([disabled]), select:not([disabled]), textarea:not([disabled])'
			).filter( ':visible' );
		},

		trapFocus: function( e ) {
			if ( 'Tab' !== e.key && 9 !== e.keyCode ) {
				return;
			}

			var $panel = $( '.pp-menu-' + this.menuId );
			if ( ! $panel.length ) {
				return;
			}

			var focusable = this.getFocusableElements( $panel );
			if ( ! focusable.length ) {
				return;
			}

			var first  = focusable[0];
			var last   = focusable[ focusable.length - 1 ];
			var active = document.activeElement;

			if ( e.shiftKey ) {
				if ( active === first || ! $panel[0].contains( active ) ) {
					e.preventDefault();
					last.focus();
				}
			} else {
				if ( active === last ) {
					e.preventDefault();
					first.focus();
				} else if ( ! $panel[0].contains( active ) ) {
					e.preventDefault();
					first.focus();
				}
			}
		},

		closeMenuESC: function() {
			var self = this;

			// menu close on ESC key
			$( document ).on(
				'keydown',
				function (e) {
					if (e.keyCode === 27) { // ESC
						self.closeMenu();
					}
				}
			);
		},

		followMenuAnchors: function() {
			var self = this;
			/* this.menuItemLink.not( '.pp-menu-item-anchor' ).each( function () {
				if ( location.pathname === this.pathname ) {
					$( this ).addClass( 'pp-menu-item-active' );
					$( this ).attr('aria-current', 'location');
				}
			} ); */

			this.anchorLink.each( function () {
				if (location.pathname === this.pathname && '' !== this.hash) {
					self.followMenuAnchorEle( $( this ) );
				}
			} );
		},

		followMenuAnchorEle: function( $element ) {
			const anchorSelector = $element[0].hash,
			activeAnchorClass = 'pp-menu-item-active',
			anchorClass = 'pp-menu-item-anchor',
			$targetElement = $element.hasClass(anchorClass) ? $element : $element.closest(`.${anchorClass}`);
			let rootMargin = '300px 0px -50% 0px',
			$anchor;

			try {
				// 'decodeURIComponent' for UTF8 characters in the hash.
				$anchor = $( decodeURIComponent( anchorSelector ) );
			} catch ( e ) {
				return;
			}

			if ( ! $anchor.length ) {
				return;
			}

			if (!$anchor.hasClass('pp-menu-anchor')) {
				rootMargin = this.calculateRootMargin($anchor);
			  }
			  const threshold = this.buildThreshold($anchor);
			  const options = {
				root: null,
				rootMargin,
				threshold
			  };
			  const observer = this.createObserver($targetElement, activeAnchorClass, $element, options);
			  observer.observe($anchor[0]);
		},

		calculateRootMargin: function( $anchor ) {
			const viewportHeight = jQuery(window).height();
			const anchorHeight = $anchor.outerHeight();
			let rootMargin;
			if (anchorHeight > viewportHeight) {
				rootMargin = 0;
			} else {
				const boxViewport = viewportHeight - anchorHeight;
				rootMargin = boxViewport / 2;
			}
			return `${rootMargin}px`;
		},

		buildThreshold: function( $anchor ) {
			const viewportHeight = jQuery(window).height();
			const anchorHeight = $anchor.outerHeight();
			let threshold = 0.5;
			if (anchorHeight > viewportHeight) {
				const halfViewport = viewportHeight / 2;
				threshold = halfViewport / anchorHeight;
			}
			return threshold;
		},

		createObserver: function($targetElement, activeAnchorClass, $element, options) {
			return new IntersectionObserver(entries => {
				entries.forEach(entry => {
					$targetElement.toggleClass(activeAnchorClass, entry.isIntersecting);
					$element.attr('aria-current', entry.isIntersecting ? 'location' : '');
				});
			}, options);
		}
	};

    var isEditMode = false;

    var getElementSettings = function( $element ) {
		var elementSettings = {},
			modelCID 		= $element.data( 'model-cid' );

		if ( isEditMode && modelCID ) {
			var settings     = elementorFrontend.config.elements.data[ modelCID ],
				settingsKeys = elementorFrontend.config.elements.keys[ settings.attributes.widgetType || settings.attributes.elType ];

			jQuery.each( settings.getActiveControls(), function( controlKey ) {
				if ( -1 !== settingsKeys.indexOf( controlKey ) ) {
					elementSettings[ controlKey ] = settings.attributes[ controlKey ];
				}
			} );
		} else {
			elementSettings = $element.data('settings') || {};
		}

		return elementSettings;
	};

	var AdvancedMenuHandler = function ($scope) {
		var elementSettings  = getElementSettings( $scope );

		new PPAdvancedMenu( $scope, elementSettings );
		
	};

	$(window).on('elementor/frontend/init', function () {
        if ( elementorFrontend.isEditMode() ) {
			isEditMode = true;
		}

		elementorFrontend.hooks.addAction( 'frontend/element_ready/pp-advanced-menu.default', AdvancedMenuHandler );
    });

})( jQuery );
