(function ($) {
	$( window ).on( 'elementor/frontend/init', () => {
		class CountdownWidget extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				const config = JSON.parse( this.$element.find('[name=pp-countdown-settings]').val() ),
				settings = {
					timertype: config.timer_type,
					timer_format: config.timer_format,
					timer_layout: config.timer_layout,
					timer_labels: config.timer_labels,
					timer_labels_singular: config.timer_labels_singular,
					redirect_link: config.redirect_link.url,
					redirect_link_target: config.redirect_link_target,
					fixed_timer_action: config.fixed_timer_action,
					evergreen_timer_action: config.evergreen_timer_action,
					evergreen_date_days: config.days,
					evergreen_date_hour: config.hours,
					evergreen_date_minutes: config.minutes,
					evergreen_date_seconds: config.seconds,
					timezone: config.time_zone,
					variation_data: config.variation_data,
					woo_variation: config.woo_variation,
					id: this.getID()
				}

				if ( 'NULL' === config.time_zone || '' === config.time_zone ) {
					settings.timezone = null;
				}

				if ( 'evergreen' === config.timer_type ) {
					settings.timer_date = new Date();
				} else {
					settings.timer_date = new Date( config.years, (config.months - 1), config.days, config.hours, config.minutes );
				}

				if ( config.timer_exp_text ) {
					settings.timer_exp_text = config.timer_exp_text;
				}

				settings.selectors = {
					wrap: '.pp-countdown-wrapper',
				};

				return settings;
			}
		
			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' );
				return {
					$wrap: this.$element.find( selectors.wrap ),
				};
			}
		
			bindEvents() {
				const settings = this.getSettings();

				if ( 'fixed' == settings.timertype ) {
					var variation_datas = settings.variation_data;

					if ( true === settings.woo_variation && Object.keys( variation_datas ).length > 0 ) {
						var that = this;
						$( ".single_variation_wrap" ).on( "show_variation", function ( event, variation ) {
							if ( '' !== variation.variation_id ) {
								var variation_data =  variation_datas[variation.variation_id];
								if ( Object.keys( variation_data ).length > 0 ) {
									settings.timer_date = new Date( variation_data.years, (variation_data.months - 1), variation_data.days, 0, 0 );
									that.initFixedTimer();
									that.initCountdown();
									that.elements.$wrap.countdown( 'option', { until: settings.timer_date } );
								}
							}
						} );
					} else {
						this.initFixedTimer();
					}
				}

				if ( 'evergreen' == settings.timertype ) {
					var currdate = '',
						timevar = 0;

					if ( undefined == Cookies.get( 'countdown-' + settings.id ) ) {
						Cookies.set( 'countdown-' + settings.id, true );
						Cookies.set( 'countdown-' + settings.id + '-currdate', new Date() );
						Cookies.set( 'countdown-' + settings.id + '-day', settings.evergreen_date_days );
						Cookies.set( 'countdown-' + settings.id + '-hour', settings.evergreen_date_hour );
						Cookies.set( 'countdown-' + settings.id + '-min', settings.evergreen_date_minutes );
						Cookies.set( 'countdown-' + settings.id + '-sec', settings.evergreen_date_seconds );
					}

					currdate = new Date( Cookies.get( 'countdown-' + settings.id + '-currdate' ) );

					timevar = ( parseFloat( settings.evergreen_date_days * 24 * 60 * 60 ) + parseFloat( settings.evergreen_date_hour * 60 * 60 ) + parseFloat( settings.evergreen_date_minutes * 60 ) + parseFloat( settings.evergreen_date_seconds ) ) * 1000;

					currdate.setTime( currdate.getTime() + timevar );

					settings.timer_date = currdate;

					this.initEverGreenTimer();
				}

				this.initCountdown();
			}

			initCountdown() {
				const settings = this.getSettings();
				var action = '';

				if ( 'fixed' === settings.timertype ) {
					action = settings.fixed_timer_action;
				} else {
					action = settings.evergreen_timer_action;
				}

				Cookies.remove( 'countdown-' + settings.id + 'expiremsg');
				Cookies.remove( 'countdown-' + settings.id + 'redirect');
				Cookies.remove( 'countdown-' + settings.id + 'redirectwindow');
				Cookies.remove( 'countdown-' + settings.id + 'hide');
				Cookies.remove( 'countdown-' + settings.id + 'reset');

				Cookies.remove( 'countdown-' + settings.id + 'expiremsg');
				Cookies.remove( 'countdown-' + settings.id + 'redirect');
				Cookies.remove( 'countdown-' + settings.id + 'redirectwindow');
				Cookies.remove( 'countdown-' + settings.id + 'hide');
				Cookies.remove( 'countdown-' + settings.id + 'reset');

				if ( 'msg' === action ) {

					Cookies.set( 'countdown-' + settings.id + 'expiremsg', settings.expire_message, { expires: 365 });

				} else if ( 'redirect' === action ) {

					Cookies.set( 'countdown-' + settings.id + 'redirect', settings.redirect_link, { expires: 365 });
					Cookies.set( 'countdown-' + settings.id + 'redirectwindow', settings.redirect_link_target, { expires: 365 });

				} else if ( 'hide' === action ) {

					Cookies.set( 'countdown-' + settings.id + 'hide', 'yes', { expires: 365 });

				} else if ( 'reset' === action ) {
					Cookies.set( 'countdown-' + settings.id + 'reset', 'yes', { expires: 365 });
				}
			}

			countdownConfig(settings) {
				const config = {
					until: settings.timer_date,
					format: settings.timer_format,
					layout: settings.timer_layout,
					labels: settings.timer_labels.split(','),
					timezone: settings.timezone,
					labels1: settings.timer_labels_singular.split(','),
				};

				return config;
			}

			initFixedTimer() {
				const settings = this.getSettings(),
					dateNow = new Date();

				if ( ( dateNow.getTime() - settings.timer_date.getTime() ) > 0 ) {
					var config = this.countdownConfig(settings);

					if ( 'msg' === settings.fixed_timer_action ) {
						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							this.elements.$wrap.append( settings.timer_exp_text );
						} else {
							config.expiryText = settings.timer_exp_text;

							this.elements.$wrap.countdown(config);
						}

					} else if ( 'redirect' === settings.fixed_timer_action ) {

						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							window.open( settings.redirect_link, settings.redirect_link_target );
						} else {
							config.expiryText = settings.timer_exp_text;

							this.elements.$wrap.countdown(config);
						}

					} else if ( 'hide' === settings.fixed_timer_action ) {
						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							this.elements.$wrap.countdown('destroy');
						} else {
							config.expiryText = settings.timer_exp_text;

							this.elements.$wrap.countdown(config);
						}

					} else {
						this.elements.$wrap.countdown(config);
					}
				} else {
					var config = this.countdownConfig(settings);

					if ( 'msg' === settings.fixed_timer_action ) {

						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							config.expiryText = settings.timer_exp_text;

							this.elements.$wrap.countdown(config);
						} else {
							this.elements.$wrap.countdown(config);
						}
					} else if ( 'redirect' === settings.fixed_timer_action ) {
						config.expiryText = settings.timer_exp_text;
						config.onExpiry = settings.redirectCounter;

						this.elements.$wrap.countdown(config);

					} else if ( 'hide' === settings.fixed_timer_action ) {
						config.expiryText = settings.timer_exp_text;
						config.onExpiry = settings.destroyCounter;

						this.elements.$wrap.countdown(config);

					} else {
						config.expiryText = settings.timer_exp_text;

						this.elements.$wrap.countdown(config);
					}
				}
			}

			initEverGreenTimer() {
				const settings = this.getSettings(),
					dateNow = new Date();

				if ( ( dateNow.getTime() - settings.timer_date.getTime() ) > 0 ) {
					var config = this.countdownConfig(settings);

					if ( 'msg' === settings.evergreen_timer_action ) {
						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							this.elements.$wrap.append( Cookies.get( 'countdown-' + this.settings.id + 'expiremsg' ) );
						} else {
							config.expiryText = Cookies.get( 'countdown-' + settings.settings.id + 'expiremsg');

							this.elements.$wrap.countdown(config);
						}

					} else if ( 'redirect' === settings.evergreen_timer_action ) {

						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							window.open(settings.redirect_link, settings.redirect_link_target);
						} else {
							config.onExpiry = settings.redirectCounter;

							this.elements.$wrap.countdown(config);
						}

					} else if ( 'hide' === settings.evergreen_timer_action ) {
						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							this.elements.$wrap.countdown('destroy');
						} else {
							config.onExpiry = settings.destroyCounter;

							this.elements.$wrap.countdown(config);
						}

					} else if ( 'reset' === settings.evergreen_timer_action ) {
						config.onExpiry = settings.restartCountdown;

						this.elements.$wrap.countdown(config);

					} else {
						this.elements.$wrap.countdown(config);
					}
				} else {
					var config = this.countdownConfig(settings);

					if ( 'msg' === settings.evergreen_timer_action ) {

						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							config.expiryText = Cookies.get( 'countdown-' + settings.settings.id + 'expiremsg');

							this.elements.$wrap.countdown(config);
						} else {
							this.elements.$wrap.countdown(config);
						}

					} else if ( 'redirect' === settings.evergreen_timer_action ) {
						config.onExpiry = settings.redirectCounter;

						this.elements.$wrap.countdown(config);

					} else if ( 'hide' === settings.evergreen_timer_action ) {
						config.onExpiry = settings.destroyCounter;

						this.elements.$wrap.countdown(config);

					} else if ( 'reset' === settings.evergreen_timer_action ) {
						config.onExpiry = settings.restartCountdown;

						this.elements.$wrap.countdown(config);

					} else {
						this.elements.$wrap.countdown(config);
					}
				}
			}

			redirectCounter() {
				var redirect_link = Cookies.get( jQuery(this)[0].id + 'redirect' );
				var redirect_link_target = Cookies.get( jQuery(this)[0].id + 'redirectwindow' );

				if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
					window.open( redirect_link, redirect_link_target );
				} else {
					return;
				}
			}

			destroyCounter() {
				if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
					jQuery(this).countdown('destroy');
				}
			}

			restartCountdown() {
				const settings = this.getSettings();

				Cookies.set( 'countdown-' + settings.id + '-currdate', new Date() );

				currdate = new Date(Cookies.get( 'countdown-' + settings.id + '-currdate') );

				var evergreen_date_days = Cookies.get( 'countdown-' + settings.id + '-day' );
				var evergreen_date_hour = Cookies.get( 'countdown-' + settings.id + '-hour' );
				var evergreen_date_minutes = Cookies.get( 'countdown-' + settings.id + '-min' );
				var evergreen_date_seconds = Cookies.get( 'countdown-' + settings.id + '-sec' );

				var timevar = ( parseFloat( evergreen_date_days * 24 * 60 * 60 ) + parseFloat( evergreen_date_hour * 60 * 60 ) + parseFloat( evergreen_date_minutes * 60 ) + parseFloat( evergreen_date_seconds ) ) * 1000;
				currdate.setTime( currdate.getTime() + timevar );

				settings.timer_date = currdate;

				jQuery(this).countdown('option', { until: settings.timer_date });
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-countdown', CountdownWidget );
    });

})(jQuery);
