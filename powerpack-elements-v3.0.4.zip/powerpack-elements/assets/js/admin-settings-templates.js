(function($) {

	// Template select: toggle between "select" hint and "edit template" link
	$('#pp_header_footer_template_header, #pp_header_footer_template_footer, #pp_woo_template_single_product, #pp_woo_template_product_archive, #pp_woo_template_product_cart, #pp_woo_template_product_checkout, #pp_woo_template_product_thankyou_page, #pp_woo_template_product_myaccount_page').on('change', function() {
		$(this).parent().find('.pp-settings-description span').hide();
		if ( $(this).val() === '' ) {
			$(this).parent().find('.desc--template-select').show();
		} else {
			$(this).parent().find('.desc--template-edit')
				.show()
				.find('a.edit-template').attr('href', ppAdminTemplates.homeUrl + '/wp-admin/post.php?post=' + $(this).val() + '&action=elementor');
		}
	}).trigger('change');

	// Header / Footer: toggle fixed/overlay fields based on header template selection
	$('#pp_header_footer_template_header').on('change', function() {
		if ( $(this).val() === '' ) {
			$('#field-pp_header_footer_fixed_header').hide();
			$('#field-pp_header_footer_shrink_header').hide();
			$('#field-pp_header_footer_fixed_header_breakpoints').hide();
			$('#field-pp_header_footer_overlay_header').hide();
		} else {
			$('#field-pp_header_footer_fixed_header').show();
			$('#field-pp_header_footer_overlay_header').show();
			if ( $( '#pp_header_footer_fixed_header' ).is( ':checked' ) ) {
				$('#field-pp_header_footer_shrink_header').show();
				$('#field-pp_header_footer_fixed_header_breakpoints').show();
			} else {
				$('#field-pp_header_footer_shrink_header').hide();
				$('#field-pp_header_footer_fixed_header_breakpoints').hide();
			}
		}
	}).trigger('change');

	// Header / Footer: toggle shrink header and breakpoints when fixed header is checked
	$('#pp_header_footer_fixed_header').on('change', function() {
		if ( $( '#field-pp_header_footer_fixed_header' ).is( ':visible' ) && $(this).is(':checked') ) {
			$('#field-pp_header_footer_shrink_header').show();
			$('#field-pp_header_footer_fixed_header_breakpoints').show();
			var option = $('#pp_header_footer_fixed_header_breakpoints').attr('data-selected');
			$('#pp_header_footer_fixed_header_breakpoints option[value=' + option + ']').attr('selected', 'selected');
		} else {
			$('#field-pp_header_footer_shrink_header').hide();
			$('#field-pp_header_footer_fixed_header_breakpoints').hide();
		}
	}).trigger('change');

	// Header / Footer: toggle overlay header background when overlay header is checked
	$('#pp_header_footer_overlay_header').on('change', function() {
		if ( $(this).is(':checked') ) {
			$('#field-pp_header_footer_overlay_header_bg').show();
		} else {
			$('#field-pp_header_footer_overlay_header_bg').hide();
		}
	}).trigger('change');

	// WooCommerce Builder: toggle template fields based on enable toggle
	$('#pp_woo_builder_enable').on('change', function() {
		if ( $(this).is(':checked') ) {
			$('#field-pp_woo_template_single_product').show();
			$('#field-pp_woo_template_product_archive').show();
			$('#field-pp_woo_template_product_cart').show();
			$('#field-pp_woo_template_product_checkout').show();
			$('#field-pp_woo_template_product_thankyou_page').show();
			$('#field-pp_woo_template_product_myaccount_page').show();
		} else {
			$('#field-pp_woo_template_single_product').hide();
			$('#field-pp_woo_template_product_archive').hide();
			$('#field-pp_woo_template_product_cart').hide();
			$('#field-pp_woo_template_product_checkout').hide();
			$('#field-pp_woo_template_product_thankyou_page').hide();
			$('#field-pp_woo_template_product_myaccount_page').hide();
		}
	}).trigger('change');

})(jQuery);
