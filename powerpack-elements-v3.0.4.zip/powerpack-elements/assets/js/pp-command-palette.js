/**
 * PowerPack commands for the WordPress Command Palette.
 *
 * The list, its labels, and which entries white label allows are all decided in
 * PHP and handed over whole. Nothing here knows what a PowerPack panel is.
 */
( function () {
	"use strict";

	var wp = window.wp;

	/*
	 * PHP checks for the same package before enqueuing this file, so arriving
	 * here without it means the script was pulled in some other way. Leaving
	 * quietly beats throwing in the console of every admin screen.
	 */
	if ( ! wp || ! wp.commands || ! wp.data ) {
		return;
	}

	var commands = ( window.ppCommandPalette || {} ).commands || [];
	var store    = wp.data.dispatch( wp.commands.store );

	commands.forEach( function ( command ) {
		if ( ! command || ! command.name || ! command.url ) {
			return;
		}

		store.registerCommand( {
			name: command.name,
			label: command.label,
			searchLabel: command.searchLabel,
			callback: function ( args ) {
				if ( command.external ) {
					window.open( command.url, "_blank", "noopener,noreferrer" );
				} else {
					document.location.href = command.url;
				}

				args.close();
			},
		} );
	} );
} )();
