<?php
/**
 * Fallback when Elementor page templates module is unavailable.
 */

use ElementPack\Includes\Builder\Builder_Integration;

defined( 'ABSPATH' ) || exit;

$integration = Builder_Integration::instance();

if ( class_exists( '\Elementor\Plugin' ) ) {
	\Elementor\Plugin::instance()->frontend->add_body_class( 'elementor-template-full-width' );
}

get_header();

$integration->print_page_single_theme_builder_content();

get_footer();
