<?php

use ElementPack\Includes\Builder\Builder_Integration;

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

do_action( 'woocommerce_before_cart' );

if ( class_exists( 'Elementor\Plugin' ) ) {
	echo wp_kses_post( Elementor\Plugin::instance()->frontend->get_builder_content( Builder_Integration::instance()->current_template_id, false ) );
}

do_action( 'woocommerce_after_cart' );

get_footer( 'shop' );
