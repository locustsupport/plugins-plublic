<?php

use ElementPack\Includes\Builder\Builder_Integration;

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

if ( class_exists( 'Elementor\Plugin' ) ) {
	?>
	<form name="checkout" method="post" class="checkout woocommerce-checkout"
		action="<?php echo esc_url( wc_get_checkout_url() ); ?>"
		enctype="multipart/form-data">
		<?php
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted Elementor-rendered builder content.
		echo Elementor\Plugin::instance()->frontend->get_builder_content( Builder_Integration::instance()->current_template_id, false );
		?>
	</form>
	<?php
}

get_footer( 'shop' );
