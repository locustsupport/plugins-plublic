<?php

/**
 * The Template for displaying the WooCommerce Shop page and product archives.
 *
 * This template can be overridden by copying it to yourtheme/bdthemes-element-pack/woocommerce/archive-product.php.
 *
 * @package BDThemes Element Pack
 */

use ElementPack\Includes\Builder\Builder_Integration;

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

do_action( 'woocommerce_before_main_content' );

if ( class_exists( 'Elementor\Plugin' ) ) {
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted Elementor-rendered builder content.
	echo Elementor\Plugin::instance()->frontend->get_builder_content( Builder_Integration::instance()->current_template_id, false );
}

do_action( 'woocommerce_after_main_content' );

get_footer( 'shop' );
