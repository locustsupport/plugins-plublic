<?php
/**
 * Theme Builder card iframe preview template.
 *
 * Renders only the requested template content to avoid context bleed
 * (e.g. active site footer appearing in a header card preview).
 */

defined( 'ABSPATH' ) || exit;

$preview_id = isset( $GLOBALS['bdt_tb_card_embed_preview_id'] ) ? absint( $GLOBALS['bdt_tb_card_embed_preview_id'] ) : 0;
if ( ! $preview_id ) {
	$preview_id = isset( $_GET['elementor-preview'] ) ? absint( $_GET['elementor-preview'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
}
if ( ! $preview_id ) {
	$preview_id = get_queried_object_id();
}

?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'bdt-tb-card-embed-preview' ); ?>>
<?php
if ( function_exists( 'wp_body_open' ) ) {
	wp_body_open();
}
?>
<div class="bdt-tb-card-embed-preview__content">
	<?php
	if ( $preview_id ) {
		$output = '';

		if ( class_exists( '\Elementor\Plugin' ) ) {
			$frontend = \Elementor\Plugin::instance()->frontend;
			$output   = (string) $frontend->get_builder_content_for_display( $preview_id, true );
			if ( '' === trim( $output ) ) {
				$output = (string) $frontend->get_builder_content( $preview_id, true );
			}
		}

		if ( '' === trim( $output ) && function_exists( 'bdt_templates_render_elementor_content' ) ) {
			$output = (string) bdt_templates_render_elementor_content( $preview_id );
		}

		if ( '' === trim( $output ) ) {
			$post = get_post( $preview_id );
			if ( $post instanceof WP_Post ) {
				setup_postdata( $post );
				$output = (string) apply_filters( 'the_content', $post->post_content );
				wp_reset_postdata();
			}
		}

		echo $output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	?>
</div>
<?php wp_footer(); ?>
</body>
</html>
