<?php

namespace ElementPack\Builder;

defined( 'ABSPATH' ) || exit;

use ElementPack\Includes\Builder\Meta;
use ElementPack\Includes\Builder\Template_Conditions;

class Activator {
	public static $instance = null;

	protected $templates;
	public $header_template;
	public $footer_template;

	public $single_template;

	protected $current_theme;
	protected $current_template;

	protected $post_type = 'bdt-template-builder';

	public function __construct() {
		add_action( 'wp', array( $this, 'hooks' ) );
	}

	public function hooks() {
		$this->current_template = basename( get_page_template_slug() );
		if ( $this->current_template == 'elementor_canvas' ) {
			return;
		}

		$this->current_theme = get_template();
		switch ( $this->current_theme ) {
			case 'astra':
				new Themes_Hooks\Astra( self::template_ids() );
				break;

			case 'neve':
				new Themes_Hooks\Neve( self::template_ids() );
				break;

			case 'generatepress':
			case 'generatepress-child':
				new Themes_Hooks\Generatepress( self::template_ids() );
				break;

			case 'oceanwp':
			case 'oceanwp-child':
				new Themes_Hooks\Oceanwp( self::template_ids() );
				break;

			case 'bb-theme':
			case 'bb-theme-child':
				new Themes_Hooks\Bbtheme( self::template_ids() );
				break;

			case 'genesis':
			case 'genesis-child':
				new Themes_Hooks\Genesis( self::template_ids() );
				break;

			default:
				new Themes_Hooks\Themes_Support( self::template_ids() );
				break;
		}
	}

	public static function template_ids() {
		$cached = wp_cache_get( 'bdthemes_template_builder_template_ids' );
		if ( false !== $cached ) {
			return $cached;
		}

		$instance = self::instance();
		$instance->the_filter();

		$ids = array(
			$instance->header_template,
			$instance->footer_template,
			$instance->single_template,
		);
		if ( $instance->header_template != null ) {
			// echo $instance->header_template; exit;
			self::render_elementor_content_css( $instance->header_template );
		}

		if ( $instance->footer_template != null ) {
			self::render_elementor_content_css( $instance->footer_template );
		}
		wp_cache_set( 'bdthemes_template_builder_template_ids', $ids );
		return $ids;
	}

	protected function the_filter() {
		$arg = array(
			'posts_per_page' => -1,
			'orderby'        => 'id',
			'order'          => 'DESC',
			'post_status'    => 'publish',
			'post_type'      => $this->post_type,
			'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- User-configurable Elementor query control.
				array(
					'key'     => '_bdthemes_builder_template_type',
					'value'   => array( 'themes|header', 'themes|footer', 'post|single', 'post|archive' ),
					'compare' => 'IN',
				),
			),
		);

		$this->templates = get_posts( $arg );

		if ( ! is_admin() ) {
			$this->get_header_footer();
		}
	}

	protected function get_header_footer() {
		$template_id = array();

		if ( $this->templates != null ) {
			foreach ( $this->templates as $template ) {
				$template    = $this->dish( $template );
				$match_found = true;

				$meta = get_post_meta( $template['ID'] );

				$templateType        = isset( $meta[ Meta::TEMPLATE_TYPE ][0] ) ? $meta[ Meta::TEMPLATE_TYPE ][0] : '';
				$enabled_template_id = strtolower( Meta::TEMPLATE_ID . $templateType );

				$enabledTemplate = get_option( $enabled_template_id . '__' . $template['ID'] );

				if ( ! $enabledTemplate ) {
					$enabledTemplate = get_option( Meta::TEMPLATE_ID . $templateType );
				}

				if ( defined( 'ICL_LANGUAGE_CODE' ) ) :
					$current_lang = apply_filters( 'wpml_post_language_details', null, $template['ID'] );

					if ( ! empty( $current_lang ) && ! $current_lang['different_language'] && ( $current_lang['language_code'] == ICL_LANGUAGE_CODE ) ) :
						$template_id[ $template['type'] ] = $template['ID'];
					endif;
				endif;

				if ( in_array( $template['type'], array( 'themes|header', 'themes|footer', 'post|single', 'post|archive' ), true ) ) {
					$match_found = Template_Conditions::template_applies_to_current_request( $template['ID'] );
				} else {
					$match_found = false;
				}

				if ( ! $enabledTemplate ) {
					$match_found = false;
				}

				if ( $match_found == true ) {
					if ( $template['type'] == 'themes|header' ) {
						$this->header_template = isset( $template_id['themes|header'] ) ? $template_id['themes|header'] : $template['ID'];
					}

					if ( $template['type'] == 'themes|footer' ) {
						$this->footer_template = isset( $template_id['themes|footer'] ) ? $template_id['themes|footer'] : $template['ID'];
					}
				}
				if ( $template['type'] == 'post|single' ) {
					$this->single_template = isset( $template_id['post|single'] ) ? $template_id['post|single'] : $template['ID'];
				}
			}
		}
	}

	protected function dish( $post ) {
		if ( $post != null ) {
			return array_merge(
				(array) $post,
				array(
					'type'                  => get_post_meta( $post->ID, '_bdthemes_builder_template_type', true ),
					'condition_a'           => get_post_meta( $post->ID, '_bdthemes_builder_template_condition_a', true ),
					'condition_singular'    => get_post_meta( $post->ID, '_bdthemes_builder_template_condition_singular', true ),
					'condition_singular_id' => get_post_meta( $post->ID, '_bdthemes_builder_template_condition_singular_id', true ),
				)
			);
		}
	}

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
	public static function render_elementor_content_css( $content_id ) {
		if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
			$css_file = new \Elementor\Core\Files\CSS\Post( $content_id );
			$css_file->enqueue();

			do_action( 'elementor/post/render', $content_id );

			/**
			 * Enable the header/footer template's widget assets.
			 *
			 * This previously rendered the whole template and threw the output away,
			 * purely as a side effect to get widget style/script depends enqueued before
			 * wp_head(). That double render also consumed any once-per-request output a
			 * widget emits during render (Mega Menu's breakpoint <style> guard, for one),
			 * so the real render came out missing it. Enabling the assets directly gets
			 * the same CSS into <head> without rendering the template twice.
			 */
			if ( class_exists( '\ElementPack\Includes\Builder\Builder_Integration' ) ) {
				\ElementPack\Includes\Builder\Builder_Integration::enable_template_assets( $content_id );
			}
		}
	}
}

Activator::instance();
