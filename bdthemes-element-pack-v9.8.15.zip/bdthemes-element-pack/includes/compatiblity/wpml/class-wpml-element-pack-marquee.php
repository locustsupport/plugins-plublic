<?php
namespace ElementPack\Includes;


if (!defined('ABSPATH')) exit; // Exit if accessed directly
/**
 * Text repeater for bdt-marquee (WPML requires a single items field string for write-back).
 */
class WPML_ElementPack_Marquee_Text extends WPML_Module_With_Items {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'marquee_type_text';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return array(
			'marquee_content',
			'marquee_link' => array( 'url' ),
		);
	}

	/**
	 * @param string $field
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'marquee_content':
				return esc_html__( 'Marquee Content', 'bdthemes-element-pack' );

			case 'marquee_link':
				return esc_html__( 'Marquee Link', 'bdthemes-element-pack' );

			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'marquee_content':
				return 'LINE';

			case 'marquee_link':
				return 'LINK';

			default:
				return '';
		}
	}

}

/**
 * Image repeater links for bdt-marquee.
 */
class WPML_ElementPack_Marquee_Images extends WPML_Module_With_Items {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'marquee_type_images';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return array(
			'marquee_image_link' => array( 'url' ),
		);
	}

	/**
	 * @param string $field
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'marquee_image_link':
				return esc_html__( 'Marquee Image Link', 'bdthemes-element-pack' );

			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'marquee_image_link':
				return 'LINK';

			default:
				return '';
		}
	}

}
