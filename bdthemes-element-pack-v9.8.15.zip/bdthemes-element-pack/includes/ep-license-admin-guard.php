<?php
/**
 * Locks “Add New” and post-new for gated CPTs when Pro license is inactive (Custom Fonts, Custom Icons).
 * List screens use the shared Theme Builder license popover UI.
 *
 * @package ElementPack\Includes
 */

namespace ElementPack\Includes;

defined( 'ABSPATH' ) || exit;

/**
 * @since 9.3.x
 */
final class EP_License_Admin_Guard {

	/**
	 * Register admin hooks (no-op on front end).
	 */
	public static function register_hooks() {
		if ( ! is_admin() ) {
			return;
		}
		add_action( 'admin_init', [ __CLASS__, 'maybe_redirect_pro_cpt_post_new_without_license' ], 5 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'maybe_enqueue_license_popover_assets' ] );
		add_action( 'admin_footer', [ __CLASS__, 'maybe_print_license_popover_markup' ] );
	}

	/**
	 * @return string[]
	 */
	private static function get_gated_create_post_types() {
		return apply_filters(
			'element_pack_pro_license_required_create_post_types',
			[ 'ep_custom_font', 'bdt_custom_icons' ]
		);
	}

	private static function is_gated_list_screen() {
		if ( function_exists( 'element_pack_pro_activated' ) && element_pack_pro_activated() ) {
			return false;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		return $screen && 'edit' === $screen->base
			&& in_array( $screen->post_type, self::get_gated_create_post_types(), true );
	}

	/**
	 * Redirect post-new.php for gated CPTs when the license is not active.
	 */
	public static function maybe_redirect_pro_cpt_post_new_without_license() {
		if ( function_exists( 'element_pack_pro_activated' ) && element_pack_pro_activated() ) {
			return;
		}

		global $pagenow;
		if ( 'post-new.php' !== $pagenow ) {
			return;
		}

		if ( empty( $_GET['post_type'] ) ) {
			return;
		}

		$post_type = sanitize_key( wp_unslash( $_GET['post_type'] ) );
		if ( ! in_array( $post_type, self::get_gated_create_post_types(), true ) ) {
			return;
		}

		$post_type_object = get_post_type_object( $post_type );
		if ( ! $post_type_object || ! current_user_can( $post_type_object->cap->create_posts ) ) {
			return;
		}

		wp_safe_redirect( admin_url( 'admin.php?page=element_pack_options' ) . '#element_pack_license_settings' );
		exit;
	}

	/**
	 * Enqueue Theme Builder–style license popover on gated CPT list screens.
	 */
	public static function maybe_enqueue_license_popover_assets() {
		if ( ! self::is_gated_list_screen() ) {
			return;
		}

		wp_enqueue_style( 'dashicons' );
		wp_enqueue_style(
			'ep-license-popover-admin',
			BDTEP_ADMIN_ASSETS_URL . 'css/ep-license-popover-admin.css',
			[],
			BDTEP_VER
		);

		wp_enqueue_script(
			'ep-admin-license-popover',
			BDTEP_ADMIN_ASSETS_URL . 'js/ep-admin-license-popover.js',
			[ 'jquery' ],
			BDTEP_VER,
			true
		);

		wp_localize_script(
			'ep-admin-license-popover',
			'epPackLicensePopover',
			[
				'packLicenseUrl' => esc_url_raw( admin_url( 'admin.php?page=element_pack_options' ) . '#element_pack_license_settings' ),
				'pricingPageUrl'  => esc_url_raw(
					apply_filters(
						'element_pack_theme_builder_pricing_url',
						'https://www.elementpack.pro/pricing/?utm_source=theme_builder&utm_medium=plugin_admin'
					)
				),
				'i18n'            => [
					'licensePopoverTitle'    => __( 'Pro license required', 'bdthemes-element-pack' ),
					'licensePopoverBody'      => __( 'An active Element Pack Pro license is required to use this feature. Open Element Pack in the WordPress admin menu to activate your license.', 'bdthemes-element-pack' ),
					'licensePopoverActivate'  => __( 'Active License', 'bdthemes-element-pack' ),
					'licensePopoverPricing'    => __( 'Get License', 'bdthemes-element-pack' ),
					'licensePopoverDismiss'    => __( 'Got it', 'bdthemes-element-pack' ),
				],
			]
		);
	}

	/**
	 * Print license popover markup for gated CPT list screens.
	 */
	public static function maybe_print_license_popover_markup() {
		if ( ! self::is_gated_list_screen() ) {
			return;
		}

		require BDTEP_PATH . 'admin/views/license-popover-admin.php';
	}
}
