<?php

use ElementPack\Includes\Controls\SelectInput\Dynamic_Select;

if (! defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Element Pack Dynamic Tag - Post Title
 *
 * Elementor dynamic tag that returns post title with advanced options
 *
 * @since 1.0.0
 */
class ElementPack_Dynamic_Tag_Post_Title extends \Elementor\Core\DynamicTags\Tag
{
    use ElementPack\Includes\Traits\UtilsTrait;

    /**
     * Get dynamic tag name.
     *
     * Retrieve the name of the server variable tag.
     *
     * @since 1.0.0
     * @access public
     * @return string Dynamic tag name.
     */
    public function get_name(): string
    {
        return 'element-pack-post-title';
    }

    /**
     * Get dynamic tag title.
     *
     * Returns the title of the server variable tag.
     *
     * @since 1.0.0
     * @access public
     * @return string Dynamic tag title.
     */
    public function get_title(): string
    {
        return esc_html__('Post Title', 'bdthemes-element-pack');
    }

    /**
     * Get dynamic tag groups.
     *
     * Retrieve the list of groups the server variable tag belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Dynamic tag groups.
     */
    public function get_group(): array
    {
        return ['element-pack-post'];
    }

    /**
     * Atomic editor expects a single group key string.
     */
    public function get_atomic_group(): string
    {
        return 'element-pack-post';
    }

    /**
     * Get dynamic tag categories.
     *
     * Retrieve the list of categories the server variable tag belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Dynamic tag categories.
     */
    public function get_categories(): array
    {
        return [
            \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY,
        ];
    }

    public function is_settings_required() {
		return true;
	}

    protected function register_controls(): void
    {
        $this->add_control(
            'ep_post_type',
            [
                'label' => esc_html__('Post Type', 'bdthemes-element-pack'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'current' => esc_html__('Current Post', 'bdthemes-element-pack'),
                    'selected' => esc_html__('Selected Post', 'bdthemes-element-pack'),
                ],
                'default' => 'current',
            ]
        );

        $this->add_control(
            'ep_posts_selected_id_legacy',
            [
                'label' => esc_html__('Search & Select Post', 'bdthemes-element-pack'),
                'type' => Dynamic_Select::TYPE,
                'multiple' => false,
                'label_block' => true,
                'query_args' => [
                    'query' => 'posts',
                ],
                'condition' => [
                    'ep_post_type' => 'selected',
                ],
            ]
        );
    }

    protected function register_advanced_section()
    {
        $this->start_controls_section(
            'advanced',
            [
                'label' => esc_html__('Advanced', 'bdthemes-element-pack'),
            ]
        );

        $this->add_control(
            'ep_word_limit',
            [
                'label' => esc_html__('Word Limit', 'bdthemes-element-pack'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 0,
                'min' => 0,
                'description' => esc_html__('0 means no limit', 'bdthemes-element-pack'),
            ]
        );

        $this->add_control(
            'before',
            [
                'label' => esc_html__('Before', 'bdthemes-element-pack'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '',
                'ai' => [
                    'active' => false,
                ],
            ]
        );

        $this->add_control(
            'after',
            [
                'label' => esc_html__('After', 'bdthemes-element-pack'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '',
                'ai' => [
                    'active' => false,
                ],
            ]
        );

        $this->add_control(
            'fallback',
            [
                'label' => esc_html__('Fallback', 'bdthemes-element-pack'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '',
                'ai' => [
                    'active' => false,
                ],
            ]
        );

        $this->end_controls_section();
    }
    /**
     * Render tag output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access public
     * @return void
     */
    public function render(): void
    {
        $value = '';
        $settings = $this->get_settings();
        $post_id = 0;

        if (
            ! empty($settings['ep_post_type']) &&
            'selected' === $settings['ep_post_type']
        ) {
            $legacy_id = ! empty($settings['ep_posts_selected_id_legacy']) ? (int) $settings['ep_posts_selected_id_legacy'] : 0;
            $post_id = $legacy_id;
        } else {
            $post_id = get_the_ID();
        }

        // If we have a valid post ID, get the title; otherwise, fallback to an empty value
        if ($post_id) {
            $value = get_the_title($post_id);
        }

        // Output the sanitized value
        echo wp_kses_post($this->apply_word_limit($value));
    }
}
