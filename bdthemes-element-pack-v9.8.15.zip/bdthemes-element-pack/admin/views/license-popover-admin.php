<?php
/**
 * License popover shell for WP CPT list screens — matches Theme Builder markup/classes.
 *
 * @package ElementPack
 */

defined( 'ABSPATH' ) || exit;
?>
<div id="bdt-tb-license-popover-root" class="bdt-tb-license-popover-root bdt-tb-license-popover-root--wp-admin" hidden aria-hidden="true">
	<div class="bdt-tb-license-popover__backdrop" data-ep-license-dismiss="1" tabindex="-1"></div>
	<div
		id="bdt-tb-license-popover"
		class="bdt-tb-license-popover"
		role="dialog"
		aria-modal="false"
		aria-labelledby="bdt-tb-license-popover-title"
		aria-describedby="bdt-tb-license-popover-desc"
	>
		<div class="bdt-tb-license-popover__card">
			<div class="bdt-tb-license-popover__head">
				<span class="bdt-tb-license-popover__lock" aria-hidden="true">
					<span class="dashicons dashicons-lock"></span>
				</span>
				<h3 id="bdt-tb-license-popover-title" class="bdt-tb-license-popover__title"></h3>
			</div>
			<p id="bdt-tb-license-popover-desc" class="bdt-tb-license-popover__desc"></p>
			<div class="bdt-tb-license-popover__actions">
				<a href="#" class="bdt-tb-license-popover__btn bdt-tb-license-popover__btn--primary" id="bdt-tb-license-popover-license"></a>
				<a href="#" class="bdt-tb-license-popover__btn bdt-tb-license-popover__btn--outline" id="bdt-tb-license-popover-pricing" target="_blank" rel="noopener noreferrer"></a>
				<button type="button" class="bdt-tb-license-popover__btn bdt-tb-license-popover__btn--ghost" id="bdt-tb-license-popover-dismiss"></button>
			</div>
		</div>
	</div>
</div>
