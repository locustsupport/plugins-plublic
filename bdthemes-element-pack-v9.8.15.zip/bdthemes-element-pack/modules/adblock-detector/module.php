<?php

namespace ElementPack\Modules\AdblockDetector;
use Elementor\Controls_Manager;
use Elementor\Plugin;
use ElementPack\Base\Element_Pack_Module_Base;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Module extends Element_Pack_Module_Base {

	public function __construct() {
		parent::__construct();
		$this->add_actions();
	}

	public function get_name() {
		return 'bdt-adblock-detector';
	}
 
	public function register_controls($section) {

		$pro_lock = bdt_get_widget_badge( str_replace( 'bdt-', '', $this->get_name() ) );

		$section->start_controls_section(
			'element_pack_adblock_detector_section',
			[
				'tab'   => Controls_Manager::TAB_SETTINGS,
				'label' => BDTEP_CP . esc_html__('AdBlock Detector', 'bdthemes-element-pack') . $pro_lock,
			]
		);

		$section->add_control(
			'ep_adblock_detector_enable',
			[
				'label'              => esc_html__('AdBlock Detector?', 'bdthemes-element-pack'),
				'type'               => Controls_Manager::SWITCHER,
				'render_type'        => 'template',
			]
		);

		$section->end_controls_section();
	}

	public function enqueue_assets() {

		if ( Plugin::instance()->editor->is_edit_mode() || Plugin::instance()->preview->is_preview_mode() ) {
			return;
		}

		$document = Plugin::instance()->documents->get( get_the_ID() );

		if ( ! $document ) {
			return;
		}

		$custom_js = $document->get_settings( 'ep_adblock_detector_enable' );

		if ( empty( $custom_js ) ) {
			return;
		}

		wp_enqueue_style(
			'ep-adblock-detector',
			BDTEP_ASSETS_URL . 'vendor/css/abdetector.style.css',
			[],
			BDTEP_VER
		);

		wp_enqueue_script(
			'ep-adblock-detector',
			BDTEP_ASSETS_URL . 'vendor/js/abdetector.script.min.js',
			[],
			BDTEP_VER,
			true
		);

		wp_add_inline_script(
			'ep-adblock-detector',
			"window.addEventListener('load', function (event) { abDetectorPro.init(); });"
		);
	}

	protected function add_actions() {

		add_action('elementor/documents/register_controls', [$this, 'register_controls'], 1, 1);
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ], 20 );

	}
}
