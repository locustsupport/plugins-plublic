<?php

namespace ElementPack\Modules\Calendly\Widgets;

use Elementor\Plugin;
use ElementPack\Base\Module_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly

class Calendly extends Module_Base {

	public function get_name() {
		return 'bdt-calendly';
	}

	public function get_title() {
		return BDTEP . esc_html__( 'Calendly', 'bdthemes-element-pack' );
	}

	public function get_icon() {
		return 'bdt-wi-calendly';
	}

	public function get_categories() {
		return [ 'element-pack' ];
	}

	public function get_keywords() {
		return [ 'calendly', 'calender', 'booking', 'booked', 'appointment' ];
	}

	public function get_script_depends() {
		if ( $this->ep_is_edit_mode() ) {
			return [ 'calendly', 'ep-scripts' ];
		} else {
			return [ 'calendly' ];
		}
	}

	public function get_custom_help_url() {
		return 'https://youtu.be/nl4zC46SrhY';
	}

	public function has_widget_inner_wrapper(): bool {
        return ! \Elementor\Plugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
    }
	
	protected function register_controls() {
		$this->start_controls_section(
			'section_calendly',
			[ 
				'label' => esc_html__( 'Calendly', 'bdthemes-element-pack' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'calendly_username',
			[ 
				'label'       => esc_html__( 'Username', 'bdthemes-element-pack' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => esc_html__( 'Type calendly username here', 'bdthemes-element-pack' ),
				'dynamic'     => [ 'active' => true ],
				'render_type' => 'template'
			]
		);

		$this->add_control(
			'calendly_time',
			[ 
				'label'   => esc_html__( 'Time in Minutes', 'bdthemes-element-pack' ),
				'description' => esc_html__( "Enter time in minutes, such as 15, 30, or 60. After the slash in your Calendly link, use the time you set (for example: 30-new-meeting for a 30-minute meeting). Example: https://calendly.com/faridbpi10/30-new-meeting", 'bdthemes-element-pack' ),
				'type'    => Controls_Manager::TEXT,
				'placeholder' => esc_html__( '15, 30, 60, etc.', 'bdthemes-element-pack' ),
				'dynamic'     => [ 'active' => true ],
				'render_type' => 'template'
			]
		);

		$this->add_control(
			'event_type_details',
			[ 
				'label' => esc_html__( 'Hide Event Type Details', 'bdthemes-element-pack' ),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$this->add_responsive_control(
			'height',
			[ 
				'label'      => esc_html__( 'Height', 'bdthemes-element-pack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [ 
					'px' => [ 
						'min'  => 10,
						'max'  => 1000,
						'step' => 5,
					],
					'%'  => [ 
						'min' => 5,
						'max' => 100,
					],
				],
				'default'    => [ 
					'unit' => 'px',
					'size' => '680',
				],
				'selectors'  => [ 
					'{{WRAPPER}} .calendly-inline-widget' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .calendly-wrapper'       => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_calendly',
			[ 
				'label' => esc_html__( 'Calendly', 'bdthemes-element-pack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'calendly_pro_notice',
			[ 
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					/* translators: 1: Calendly Pro plan link, 2: Documentation link */
					esc_html__( 'Style option only works with %1$s. Basic plan user can\'t change the color style. For more details please %2$s.', 'bdthemes-element-pack' ),
					'<a href="https://calendly.com/pages/pricing" target="_blank">Calendly Pro plan</a>',
					'<a href="https://calendly.com/pages/pricing" target="_blank">check here</a>'
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			]
		);

		$this->add_control(
			'text_color',
			[ 
				'label' => esc_html__( 'Text Color', 'bdthemes-element-pack' ),
				'type'  => Controls_Manager::COLOR,
				'alpha' => false,
			]
		);

		$this->add_control(
			'button_link_color',
			[ 
				'label' => esc_html__( 'Button & Link Color', 'bdthemes-element-pack' ),
				'type'  => Controls_Manager::COLOR,
				'alpha' => false,
			]
		);

		$this->add_control(
			'background_color',
			[ 
				'label' => esc_html__( 'Background Color', 'bdthemes-element-pack' ),
				'type'  => Controls_Manager::COLOR,
				'alpha' => false,
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Reduce a settings value to a safe Calendly path.
	 *
	 * Both path controls accept dynamic tags, so their value can come from post
	 * meta or any other source a lower privileged user can write to. Everything
	 * outside the slug character set is dropped, which also removes the query and
	 * fragment separators an injected value would need to append its own
	 * parameters (embed_domain, utm_*) to the embed URL.
	 *
	 * @param string $path
	 * @return string
	 */
	private function get_calendly_path( $path ) {
		$path = trim( (string) $path );

		if ( '' === $path ) {
			return '';
		}

		$path = strtok( $path, '?#' );
		$path = preg_replace( '#^(https?:)?//#i', '', $path );
		$path = preg_replace( '#^(www\.)?calendly\.com/#i', '', $path );
		$path = preg_replace( '#[^a-zA-Z0-9\-_/]#', '', $path );
		$path = preg_replace( '#/+#', '/', $path );

		return trim( $path, '/' );
	}

	/**
	 * An event type is always the last segment of its link, so a pasted event link
	 * is reduced to its slug instead of repeating the username in the embed URL.
	 *
	 * @param string $slug
	 * @return string
	 */
	private function get_calendly_event_slug( $slug ) {
		$slug = $this->get_calendly_path( $slug );

		if ( false !== strpos( $slug, '/' ) ) {
			$segments = explode( '/', $slug );
			$slug     = end( $segments );
		}

		return $slug;
	}

	/**
	 * Calendly only accepts plain 6 digit hex values for its color parameters, so
	 * anything else (an Elementor global such as var(--e-global-color-primary),
	 * or an injected string) is dropped instead of being sent along.
	 *
	 * @param string $color
	 * @return string
	 */
	private function get_calendly_color( $color ) {
		$color = ltrim( trim( (string) $color ), '#' );

		if ( preg_match( '/^[0-9a-fA-F]{3}$/', $color ) ) {
			$color = $color[0] . $color[0] . $color[1] . $color[1] . $color[2] . $color[2];
		}

		return preg_match( '/^[0-9a-fA-F]{6}$/', $color ) ? strtolower( $color ) : '';
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$calendly_username = $this->get_calendly_path( isset( $settings['calendly_username'] ) ? $settings['calendly_username'] : '' );

		if ( '' === $calendly_username ) {
			return;
		}

		$calendly_time = $this->get_calendly_event_slug( isset( $settings['calendly_time'] ) ? $settings['calendly_time'] : '' );

		$parameters = [];

		if ( isset( $settings['event_type_details'] ) && 'yes' === $settings['event_type_details'] ) {
			$parameters['hide_event_type_details'] = 1;
		}

		$colors = [
			'text_color'       => isset( $settings['text_color'] ) ? $settings['text_color'] : '',
			'primary_color'    => isset( $settings['button_link_color'] ) ? $settings['button_link_color'] : '',
			'background_color' => isset( $settings['background_color'] ) ? $settings['background_color'] : '',
		];

		foreach ( $colors as $parameter => $color ) {
			$color = $this->get_calendly_color( $color );

			if ( '' !== $color ) {
				$parameters[ $parameter ] = $color;
			}
		}

		$final_url = 'https://calendly.com/' . $calendly_username;

		// A pasted multi segment link (a full event link or a one off link) already
		// points at a single event type, so there is nothing left to append to it.
		if ( '' !== $calendly_time && false === strpos( $calendly_username, '/' ) ) {
			$final_url .= '/' . $calendly_time;
		}

		if ( ! empty( $parameters ) ) {
			$final_url .= '?' . http_build_query( $parameters );
		}

		?>

		<div class="calendly-inline-widget" data-url="<?php echo esc_url( $final_url ); ?>" style="min-width:320px;"></div>
		<?php if ( Plugin::$instance->editor->is_edit_mode() ) : ?>
			<div class="calendly-wrapper" style="width:100%; position:absolute; top:0; left:0; z-index:100;"></div>
		<?php endif; ?>

	<?php
	}
}
