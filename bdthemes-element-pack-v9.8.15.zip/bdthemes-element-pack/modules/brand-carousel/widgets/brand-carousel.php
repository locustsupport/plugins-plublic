<?php

namespace ElementPack\Modules\BrandCarousel\Widgets;

use ElementPack\Base\Module_Base;
use ElementPack\Traits\Global_Controls_Functions;
use ElementPack\Traits\Global_Swiper_Controls;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Brand_Carousel extends Module_Base {

	use Global_Swiper_Controls;
	use Global_Controls_Functions;

	public function get_name() {
		return 'bdt-brand-carousel';
	}

	public function get_title() {
		return BDTEP . esc_html__( 'Brand Carousel', 'bdthemes-element-pack' );
	}

	public function get_icon() {
		return 'bdt-wi-brand-carousel';
	}

	public function get_categories() {
		return [ 'element-pack' ];
	}

	public function get_keywords() {
		return [ 'brand', 'carousel', 'client', 'logo', 'showcase' ];
	}

	public function get_style_depends() {
		if ( $this->ep_is_edit_mode() ) {
			return [ 'swiper', 'ep-styles' ];
		}

		return [ 'swiper', 'ep-font', 'ep-brand-carousel' ];
	}

	public function get_script_depends() {
		if ( $this->ep_is_edit_mode() ) {
			return [ 'swiper', 'ep-scripts' ];
		}

		return [ 'swiper', 'ep-brand-carousel' ];
	}

	public function get_custom_help_url() {
		return 'https://youtu.be/LdCxFzpYuO0';
	}

	public function has_widget_inner_wrapper(): bool {
		return ! \Elementor\Plugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	protected function is_dynamic_content(): bool {
		return false;
	}

	protected function register_controls() {
		$this->register_brand_items_controls();

		$this->start_controls_section(
			'section_additional_settings',
			[
				'label' => esc_html__( 'Additional Settings', 'bdthemes-element-pack' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_carousel_column_gap_controls();

		$this->add_control(
			'item_match_height',
			[
				'label'        => esc_html__( 'Item Match Height', 'bdthemes-element-pack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'prefix_class' => 'bdt-item-match-height--',
				'render_type'  => 'template',
			]
		);

		$this->register_brand_common_settings_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_navigation',
			[
				'label' => esc_html__( 'Navigation', 'bdthemes-element-pack' ),
			]
		);

		$this->register_navigation_controls();

		$this->end_controls_section();

		$this->register_carousel_settings_controls();

		$this->register_brand_style_items_controls( 'brand-carousel', [ 'show_shadow_padding' => true ] );
		$this->register_brand_style_icon_controls( 'brand-carousel' );
		$this->register_brand_style_name_controls( 'brand-carousel' );
		$this->register_brand_style_website_link_controls( 'brand-carousel' );

		$this->start_controls_section(
			'section_style_navigation',
			[
				'label'      => esc_html__( 'Navigation', 'bdthemes-element-pack' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'conditions' => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'     => 'navigation',
							'operator' => '!=',
							'value'    => 'none',
						],
						[
							'name'  => 'show_scrollbar',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$this->register_navigation_style_controls( 'swiper-carousel' );

		$this->end_controls_section();
	}

	public function render_header( $settings ) {
		$this->render_swiper_header_attribute( 'brand-carousel' );
		$this->add_render_attribute( 'carousel', 'class', 'bdt-ep-brand-carousel' );
		?>
		<div <?php $this->print_render_attribute_string( 'carousel' ); ?>>
			<div <?php $this->print_render_attribute_string( 'swiper' ); ?>>
				<div class="swiper-wrapper">
		<?php
	}

	protected function render_carosuel_item( $settings ) {
		if ( empty( $settings['brand_items'] ) ) {
			return;
		}

		foreach ( $settings['brand_items'] as $index => $item ) {
			$this->add_render_attribute(
				'item-wrap',
				'class',
				$this->get_brand_item_classes( $settings, 'brand-carousel', [ 'swiper-slide' ] ),
				true
			);
			?>
			<div <?php $this->print_render_attribute_string( 'item-wrap' ); ?>>
				<?php $this->render_brand_carousel_image( $item, $settings, 'brand-carousel' ); ?>
				<?php
				$this->render_brand_item_content(
					$item,
					$index,
					$settings,
					'brand-carousel',
					[
						'merge_attributes' => true,
					]
				);
				?>
			</div>
			<?php
		}
	}

	public function render() {
		$settings = $this->get_settings_for_display();
		$this->render_header( $settings );
		$this->render_carosuel_item( $settings );
		$this->render_footer();
	}

	protected function content_template() {
		$ep_viewport_lg = ! empty( get_option( 'elementor_viewport_lg' ) ) ? (int) get_option( 'elementor_viewport_lg' ) - 1 : 1023;
		$ep_viewport_md = ! empty( get_option( 'elementor_viewport_md' ) ) ? (int) get_option( 'elementor_viewport_md' ) - 1 : 767;
		?>
		<#
		var carouselId = 'bdt-brand-carousel-' + view.getID();
		var nav = settings.navigation || 'none';
		var carouselClass = 'bdt-ep-brand-carousel';
		if ( nav === 'arrows' ) {
			carouselClass += ' bdt-arrows-align-' + ( settings.arrows_position || 'center' );
		} else if ( nav === 'dots' ) {
			carouselClass += ' bdt-dots-align-' + ( settings.dots_position || 'bottom' );
		} else if ( nav === 'both' ) {
			carouselClass += ' bdt-arrows-dots-align-' + ( settings.both_position || 'center' );
		} else if ( nav === 'arrows-fraction' ) {
			carouselClass += ' bdt-arrows-dots-align-' + ( settings.arrows_fraction_position || 'center' );
		}

		var paginationType = '';
		if ( nav === 'arrows-fraction' ) {
			paginationType = 'fraction';
		} else if ( nav === 'both' || nav === 'dots' ) {
			paginationType = 'bullets';
		} else if ( nav === 'progressbar' ) {
			paginationType = 'progressbar';
		}

		var viewportMd = <?php echo (int) $ep_viewport_md; ?>;
		var viewportLg = <?php echo (int) $ep_viewport_lg; ?>;

		var swiperSettings = {
			loop: settings.loop === 'yes',
			speed: ( settings.speed && settings.speed.size ) ? settings.speed.size : 500,
			pauseOnHover: settings.pauseonhover === 'yes',
			slidesPerView: settings.columns_mobile ? parseInt( settings.columns_mobile, 10 ) : 1,
			slidesPerGroup: settings.slides_to_scroll_mobile ? parseInt( settings.slides_to_scroll_mobile, 10 ) : 1,
			spaceBetween: ( settings.item_gap_mobile && settings.item_gap_mobile.size ) ? parseInt( settings.item_gap_mobile.size, 10 ) : 0,
			centeredSlides: settings.centered_slides === 'yes',
			grabCursor: settings.grab_cursor === 'yes',
			freeMode: settings.free_mode === 'yes',
			effect: settings.skin || 'carousel',
			observer: !! settings.observer,
			observeParents: !! settings.observer,
			watchSlidesVisibility: settings.show_hidden_item === 'yes',
			watchSlidesProgress: settings.show_hidden_item === 'yes',
			mousewheel: !! settings.mousewheel,
			breakpoints: {},
			navigation: {
				nextEl: '#' + carouselId + ' .bdt-navigation-next',
				prevEl: '#' + carouselId + ' .bdt-navigation-prev'
			},
			pagination: {
				el: '#' + carouselId + ' .swiper-pagination',
				type: paginationType,
				clickable: 'true',
				dynamicBullets: settings.dynamic_bullets === 'yes'
			},
			scrollbar: {
				el: '#' + carouselId + ' .swiper-scrollbar',
				hide: 'true'
			},
			coverflowEffect: {
				rotate: ( settings.coverflow_toggle === 'yes' && settings.coverflow_rotate && settings.coverflow_rotate.size ) ? settings.coverflow_rotate.size : 50,
				stretch: ( settings.coverflow_toggle === 'yes' && settings.coverflow_stretch && settings.coverflow_stretch.size ) ? settings.coverflow_stretch.size : 0,
				depth: ( settings.coverflow_toggle === 'yes' && settings.coverflow_depth && settings.coverflow_depth.size ) ? settings.coverflow_depth.size : 100,
				modifier: ( settings.coverflow_toggle === 'yes' && settings.coverflow_modifier && settings.coverflow_modifier.size ) ? settings.coverflow_modifier.size : 1,
				slideShadows: true
			}
		};

		if ( settings.autoplay === 'yes' ) {
			swiperSettings.autoplay = {
				delay: settings.autoplay_speed || 5000,
				disableOnInteraction: false
			};
		}

		swiperSettings.breakpoints[ viewportMd ] = {
			slidesPerView: settings.columns_tablet ? parseInt( settings.columns_tablet, 10 ) : 2,
			spaceBetween: ( settings.item_gap_tablet && settings.item_gap_tablet.size ) ? parseInt( settings.item_gap_tablet.size, 10 ) : 0,
			slidesPerGroup: settings.slides_to_scroll_tablet ? parseInt( settings.slides_to_scroll_tablet, 10 ) : 1
		};
		swiperSettings.breakpoints[ viewportLg ] = {
			slidesPerView: settings.columns ? parseInt( settings.columns, 10 ) : 3,
			spaceBetween: ( settings.item_gap && settings.item_gap.size ) ? parseInt( settings.item_gap.size, 10 ) : 0,
			slidesPerGroup: settings.slides_to_scroll ? parseInt( settings.slides_to_scroll, 10 ) : 1
		};

		var dataSettings = JSON.stringify( swiperSettings );
		var navIcon = settings.nav_arrows_icon || '5';
		var hideArrowMobile = settings.hide_arrow_on_mobile ? ' bdt-visible@m' : '';
		var brandTag = settings.brand_html_tag || 'h3';
		#>
		<div id="{{ carouselId }}" class="{{ carouselClass }}" data-settings="{{ dataSettings }}">
			<div class="swiper-carousel swiper" role="region" aria-roledescription="carousel" aria-label="<?php echo esc_attr( $this->get_title() ); ?>" dir="<?php echo is_rtl() ? 'rtl' : 'ltr'; ?>">
				<div class="swiper-wrapper">
					<# _.each( settings.brand_items, function( item ) {
						var itemClass = 'bdt-ep-brand-carousel-item swiper-slide';
						if ( settings.brand_event === 'hover-item' ) {
							itemClass += ' bdt-ep-brand-carousel-item-hover';
						}
					#>
					<div class="{{ itemClass }}">
						<div class="bdt-ep-brand-carousel-image">
							<# if ( item.image && item.image.url ) { #>
							<img src="{{ item.image.url }}" alt="{{ item.brand_name }}">
							<# } #>
						</div>
						<# if ( settings.brand_event === 'click' ) { #>
						<input class="bdt-ep-brand-carousel-checkbox" type="checkbox">
						<# } #>
						<div class="bdt-ep-brand-carousel-content">
							<div class="bdt-ep-brand-carousel-icon">
								<i class="ep-icon-plus-2" aria-hidden="true"></i>
							</div>
							<div class="bdt-ep-brand-carousel-inner">
								<# if ( item.brand_name && settings.show_brand_name === 'yes' ) { #>
								<{{ brandTag }} class="bdt-ep-brand-carousel-name">{{{ item.brand_name }}}</{{ brandTag }}>
								<# } #>
								<# if ( item.link && item.link.url && settings.show_website_link === 'yes' ) { #>
								<div class="bdt-ep-brand-carousel-text">
									<a href="{{ item.link.url }}" class="bdt-ep-brand-carousel-link"<# if ( item.link.is_external ) { #> target="_blank"<# } #><# if ( item.link.nofollow ) { #> rel="nofollow"<# } #>{{{ item.website_link_text }}}</a>
								</div>
								<# } #>
							</div>
						</div>
					</div>
					<# } ); #>
				</div>
				<# if ( settings.show_scrollbar === 'yes' ) { #>
				<div class="swiper-scrollbar"></div>
				<# } #>
			</div>

			<# if ( nav === 'both' ) { #>
			<div class="bdt-position-z-index bdt-position-{{ settings.both_position }}">
				<div class="bdt-arrows-dots-container bdt-slidenav-container">
					<div class="bdt-flex bdt-flex-middle">
						<div class="{{ hideArrowMobile }}">
							<div class="bdt-navigation-prev bdt-slidenav-previous bdt-icon bdt-slidenav">
								<i class="ep-icon-arrow-left-{{ navIcon }}" aria-hidden="true"></i>
							</div>
						</div>
						<# if ( settings.both_position !== 'center' ) { #>
						<div class="swiper-pagination"></div>
						<# } #>
						<div class="{{ hideArrowMobile }}">
							<div class="bdt-navigation-next bdt-slidenav-next bdt-icon bdt-slidenav">
								<i class="ep-icon-arrow-right-{{ navIcon }}" aria-hidden="true"></i>
							</div>
						</div>
					</div>
				</div>
			</div>
			<# if ( settings.both_position === 'center' ) { #>
			<div class="bdt-position-z-index bdt-position-bottom">
				<div class="bdt-dots-container">
					<div class="swiper-pagination"></div>
				</div>
			</div>
			<# } #>
			<# } else if ( nav === 'arrows-fraction' ) { #>
			<div class="bdt-position-z-index bdt-position-{{ settings.arrows_fraction_position }}">
				<div class="bdt-arrows-fraction-container bdt-slidenav-container">
					<div class="bdt-flex bdt-flex-middle">
						<div class="{{ hideArrowMobile }}">
							<div class="bdt-navigation-prev bdt-slidenav-previous bdt-icon bdt-slidenav">
								<i class="ep-icon-arrow-left-{{ navIcon }}" aria-hidden="true"></i>
							</div>
						</div>
						<# if ( settings.arrows_fraction_position !== 'center' ) { #>
						<div class="swiper-pagination"></div>
						<# } #>
						<div class="{{ hideArrowMobile }}">
							<div class="bdt-navigation-next bdt-slidenav-next bdt-icon bdt-slidenav">
								<i class="ep-icon-arrow-right-{{ navIcon }}" aria-hidden="true"></i>
							</div>
						</div>
					</div>
				</div>
			</div>
			<# if ( settings.arrows_fraction_position === 'center' ) { #>
			<div class="bdt-dots-container">
				<div class="swiper-pagination"></div>
			</div>
			<# } #>
			<# } else { #>
			<# if ( nav === 'dots' ) { #>
			<div class="bdt-position-z-index bdt-position-{{ settings.dots_position }}">
				<div class="bdt-dots-container">
					<div class="swiper-pagination"></div>
				</div>
			</div>
			<# } else if ( nav === 'progressbar' ) { #>
			<div class="swiper-pagination bdt-position-z-index bdt-position-{{ settings.progress_position }}"></div>
			<# } #>
			<# if ( nav === 'arrows' ) { #>
			<div class="bdt-position-z-index bdt-position-{{ settings.arrows_position }}{{ hideArrowMobile }}">
				<div class="bdt-arrows-container bdt-slidenav-container">
					<div class="bdt-navigation-prev bdt-slidenav-previous bdt-icon bdt-slidenav">
						<i class="ep-icon-arrow-left-{{ navIcon }}" aria-hidden="true"></i>
					</div>
					<div class="bdt-navigation-next bdt-slidenav-next bdt-icon bdt-slidenav">
						<i class="ep-icon-arrow-right-{{ navIcon }}" aria-hidden="true"></i>
					</div>
				</div>
			</div>
			<# } #>
			<# } #>
		</div>
		<?php
	}
}
