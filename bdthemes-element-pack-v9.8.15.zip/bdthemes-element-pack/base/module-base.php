<?php

namespace ElementPack\Base;

use ElementPack\Includes\Builder\Builder_Widget_Base;
use ElementPack\Element_Pack_Loader;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

abstract class Module_Base extends Builder_Widget_Base {

	/**
	 * Prevent duplicate Elementor control registration notices.
	 *
	 * Some widgets (or editor hooks) may attempt to register the same control
	 * twice — e.g. "set_api_key" — which triggers _doing_it_wrong in Elementor.
	 */
	public function add_control( $id, array $args, $options = [] ) {
		$options = is_array( $options ) ? $options : [];

		if ( empty( $options['overwrite'] ) && isset( $this->get_controls()[ $id ] ) ) {
			return;
		}

		parent::add_control( $id, $args, $options );
	}

	/**
	 * Show a missing API key notice in the Elementor panel.
	 *
	 * Always pass a unique $control_id per widget/section (never reuse "set_api_key").
	 */
	protected function register_api_key_missing_notice( $control_id, $message, $args = [] ) {
		if ( isset( $this->get_controls()[ $control_id ] ) ) {
			return;
		}

		$this->add_control(
			$control_id,
			array_merge(
				[
					'type'            => \Elementor\Controls_Manager::RAW_HTML,
					'raw'             => $message,
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
				],
				$args
			)
		);
	}

	public function get_style_depends() {

		if ( method_exists( $this, '_get_style_depends' ) ) {
			if ( $this->ep_is_edit_mode() ) {
				return [ 'ep-all-styles' ];
			}
			return $this->_get_style_depends();
		}
		return array();
	}

	protected function ep_is_edit_mode() {

		if ( Element_Pack_Loader::elementor()->preview->is_preview_mode() || Element_Pack_Loader::elementor()->editor->is_edit_mode() ) {
			return true;
		}

		return false;
	}
}

