<?php
namespace WP_Rocket\Engine\CDN\RocketCDN;

use WP_Rocket\Admin\Options;
use WP_Rocket\Admin\Options_Data;

/**
 * Manager for WP Rocket CDN options
 *
 * @since 3.5
 */
class CDNOptionsManager {
	/**
	 * WP Options API instance
	 *
	 * @var Options
	 */
	private $options_api;

	/**
	 * WP Rocket Options instance
	 *
	 * @var Options_Data
	 */
	private $options;

	/**
	 * Constructor
	 *
	 * @param Options      $options_api WP Options API instance.
	 * @param Options_Data $options     WP Rocket Options instance.
	 */
	public function __construct( Options $options_api, Options_Data $options ) {
		$this->options_api = $options_api;
		$this->options     = $options;
	}

	/**
	 * Enable CDN option, save CDN URL & delete RocketCDN status transient
	 *
	 * @since 3.5
	 *
	 * @param bool $clear_cache Clear website whole cache.
	 * @return void
	 */
	public function enable( bool $clear_cache = true ) {
		$this->options->set( 'cdn', 1 );

		$this->options_api->set( 'settings', $this->options->get_options() );

		delete_transient( 'rocketcdn_status' );
		if ( $clear_cache ) {
			rocket_clean_domain();
		}
	}

	/**
	 * Save RocketCDN user token.
	 *
	 * @since 3.20.5
	 *
	 * @param string $token RocketCDN user token.
	 * @return void
	 */
	public function save_token( string $token ): void {
		update_option( 'rocketcdn_user_token', $token );
	}

	/**
	 * Disable CDN option, remove CDN URL & user token, delete RocketCDN status transient
	 *
	 * @since 3.5
	 *
	 * @return void
	 */
	public function disable() {
		$this->options->set( 'cdn', 0 );

		$this->options_api->set( 'settings', $this->options->get_options() );

		delete_option( 'rocketcdn_user_token' );
		delete_transient( 'rocketcdn_status' );
		rocket_clean_domain();
	}

	/**
	 * Get current CDN cnames.
	 *
	 * @return array
	 */
	public function get_cdn_cnames() {
		return $this->options->get( 'cdn_cnames', [] );
	}

	/**
	 * Check if there is saved user token.
	 *
	 * @return bool
	 */
	public function has_token(): bool {
		return ! empty( get_option( 'rocketcdn_user_token' ) );
	}

	/**
	 * Flush subscription cache.
	 *
	 * @return void
	 */
	public function flush_subscription_cache() {
		delete_transient( 'rocketcdn_status' );
		delete_transient( 'rocket_cdn_website_search' );
	}
}
