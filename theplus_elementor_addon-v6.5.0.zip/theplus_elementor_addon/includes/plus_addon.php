<?php 

/**
 * Exit if accessed directly.
 * */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
	
global $theplus_options,$post_type_options;
		
add_image_size( 'tp-image-grid', 700, 700, true);


/*dynamic listing quickview*/

if (! function_exists('tp_get_image_rander') && version_compare( L_THEPLUS_VERSION, '5.0.2', '<' ) ) {
	function tp_get_image_rander( $id ='', $size = 'full', $attr =[], $posttype = 'attachment' ) {
		if( empty($id) ){
			return '';
		}
		
		if(!empty($posttype) && $posttype=='post' ){
			$get_post = get_post( $id );
	 
			if ( ! $get_post ) {
				return '';
			}
			$id = get_post_thumbnail_id( $get_post );
		}
		
		if( ! wp_get_attachment_image_src( $id ) ){
			return '';
		}
		
		$output = '';	
		
		$get_image = wp_get_attachment_image( $id, $size, false, $attr );
		
		$check_srcset = strpos( $get_image, 'srcset' ) !== false;
				
		$output = $get_image . $output;

		return $output;
	}
}

// Check Html Tag
function theplus_validate_html_tag( $check_tag ) {
	$html_tags = array( 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'a', 'span', 'p', 'header', 'footer', 'article', 'aside', 'main', 'nav', 'section' );

	return in_array( strtolower( $check_tag ), $html_tags ) ? $check_tag : 'div';
}

/*pre loader body class*/
$theplus_optionsget = get_option( 'theplus_options');
if(!empty($theplus_optionsget['check_elements']) && isset($theplus_optionsget['check_elements'])){
	if (in_array("tp_pre_loader", $theplus_optionsget['check_elements'])){
		function theplus_body_class($classes) {
			$classes[]="theplus-preloader";
			return $classes;
		}
	add_filter('body_class', 'theplus_body_class');
	}	
}

/** Team Member listing category*/
function theplus_team_member_post_category() {
	$post_type_options = get_option( 'post_type_options' );
	$team_post_type    = ! empty( $post_type_options['team_member_post_type'] ) ? $post_type_options['team_member_post_type'] : '';
	$taxonomy_name     = 'theplus_team_member_cat';

	if ( isset( $team_post_type ) && ! empty( $team_post_type ) ) {
		if ( $team_post_type == 'themes' ) {
			$taxonomy_name = theplus_get_option( 'post_type', 'team_member_category_name' );
		} elseif ( $team_post_type == 'plugin' ) {
			$get_name = theplus_get_option( 'post_type', 'team_member_category_plugin_name' );
			if ( isset( $get_name ) && ! empty( $get_name ) ) {
				$taxonomy_name = theplus_get_option( 'post_type', 'team_member_category_plugin_name' );
			}
		} elseif ( $team_post_type == 'themes_pro' ) {
			$taxonomy_name = 'team_member_category';
		}
	} else {
		$taxonomy_name = 'theplus_team_member_cat';
	}
	return $taxonomy_name;
}

/*woo multi step*/
function woo_checkout_update_order_review() {
	/**
	 * P-003 fix: Verify WooCommerce's own checkout nonce before rendering
	 * the order review HTML. The nopriv registration stays so guest checkout
	 * still works, but the nonce check ensures the request originates from
	 * a real checkout flow, not an unauthenticated probe.
	 */
	if ( ! check_ajax_referer( 'woocommerce-process_checkout', 'woocommerce-process-checkout-nonce', false )
		&& ! check_ajax_referer( 'update-order-review', 'security', false ) ) {
		wp_send_json_error( array( 'message' => 'Invalid security token.' ), 403 );
	}

	ob_start();
	Woo_Checkout::checkout_order_review_default();
	$woo_checkout_order_review = ob_get_clean();

	wp_send_json(
		array(
			'order_review' => $woo_checkout_order_review,
		)
	);
}
add_action('wp_ajax_woo_checkout_update_order_review', 'woo_checkout_update_order_review',10);
add_action('wp_ajax_nopriv_woo_checkout_update_order_review','woo_checkout_update_order_review',10);


//user profile social
function theplus_user_social_links( $user_contact ) {   
   $user_contact['tp_phone_number'] = __('Phone Number', 'theplus');
   $user_contact['tp_profile_facebook'] = __('Facebook Link', 'theplus');
   $user_contact['tp_profile_twitter'] = __('Twitter Link', 'theplus');
   $user_contact['tp_profile_instagram'] = __('Instagram', 'theplus');

   return $user_contact;
}
// user_contactmethods filter only fires on the admin user-profile screen.
if ( is_admin() ) {
	add_filter( 'user_contactmethods', 'theplus_user_social_links', 10 );
}

/* WOOCOMMERCE Mini Cart */
function theplus_woocomerce_ajax_cart_update($fragments) {
	if(class_exists('woocommerce')) {		
		ob_start();
		?>			
			
			<div class="cart-wrap"><span><?php echo WC()->cart->get_cart_contents_count(); ?></span></div>
		<?php
		$fragments['.cart-wrap'] = ob_get_clean();
		return $fragments;
	}
}
add_filter('woocommerce_add_to_cart_fragments', 'theplus_woocomerce_ajax_cart_update', 10, 3);

/*3rd party WC_Product_Subtitle*/
if(!function_exists('product_subtitle_after_title')){
	function product_subtitle_after_title() {
		echo do_shortcode("[product_subtitle]");
	}
}
add_action("theplus_after_product_title","product_subtitle_after_title");
/*3rd party WC_Product_Subtitle*/

/*defer script*/
function tp_defer_scripts( $tag, $handle, $src ) {
	// Handles in this list are rewritten with async+defer. Only add scripts
	// that run lazily on user interaction or via explicit JS triggers — never
	// scripts that need to execute before DOMContentLoaded or that have other
	// scripts depending on synchronous global availability.
	$defer = array(
		'google_platform_js',  // Google sign-in client — already async by design.
		'lottie',              // Vendor lottie.min.js — runs only when widget JS calls loadAnimation().
		'lottieplayer',        // Vendor lottie-player.js — Web Component, no inline init.
		'tp-vis-timeline-js',  // Vis.js timeline — drawn on demand by tp-gsap-timeline.
	);

	if ( in_array( $handle, $defer, true ) ) {
		return '<script src="' . $src . '" async defer type="text/javascript"></script>' . "\n";
	}

	return $tag;
}

add_filter( 'script_loader_tag', 'tp_defer_scripts', 10, 3 );
/*defer script*/

function theplus_get_thumb_url(){
	return THEPLUS_ASSETS_URL .'images/placeholder-grid.jpg';
}

/* Custom Link url attachment Media */
function plus_attachment_field_media( $form_fields, $post ) {
    $form_fields['plus-gallery-url'] = array(
        'label' => esc_html__('Custom URL','theplus'),
        'input' => 'url',
        'value' => get_post_meta( $post->ID, 'plus_gallery_url', true ),
        'helps' => esc_html__('Gallery Listing Widget Used Custom Url Media','theplus'),
    );
    return $form_fields;
}
// Media-library attachment filters fire only in admin context.
if ( is_admin() ) {
	add_filter( 'attachment_fields_to_edit', 'plus_attachment_field_media', 10, 2 );
}
function plus_attachment_field_save( $post, $attachment ) {    
    if( isset( $attachment['plus-gallery-url'] ) )
		update_post_meta( $post['ID'], 'plus_gallery_url', esc_url( $attachment['plus-gallery-url'] ) ); 
    
	return $post;	
}
if ( is_admin() ) {
	add_filter( 'attachment_fields_to_save', 'plus_attachment_field_save', 10, 2 );
}
/* Custom Link url attachment Media */

class Theplus_MetaBox {
	
	public static function get($name) {
		global $post;
		
		if (isset($post) && !empty($post->ID)) {
			return get_post_meta($post->ID, $name, true);
		}
		
		return false;
	}
}
function theplus_get_option($options_type,$field){
	static $cached_options = null;
	static $cached_post_type = null;

	if ( null === $cached_options ) {
		$cached_options = wp_cache_get( 'tpae_pro_theplus_options', 'theplus_addons' );
		if ( false === $cached_options ) {
			$cached_options = get_option( 'theplus_options' );
			wp_cache_set( 'tpae_pro_theplus_options', $cached_options, 'theplus_addons', HOUR_IN_SECONDS );
		}
	}

	if ( null === $cached_post_type ) {
		$cached_post_type = wp_cache_get( 'tpae_pro_post_type_options', 'theplus_addons' );
		if ( false === $cached_post_type ) {
			$cached_post_type = get_option( 'post_type_options' );
			wp_cache_set( 'tpae_pro_post_type_options', $cached_post_type, 'theplus_addons', HOUR_IN_SECONDS );
		}
	}

	$theplus_options = $cached_options;
	$post_type_options = $cached_post_type;
	$values='';
	if($options_type=='general'){
		if(isset($theplus_options[$field]) && !empty($theplus_options[$field])){
			$values=$theplus_options[$field];
		}
	}
	if($options_type=='post_type'){
		if(isset($post_type_options[$field]) && !empty($post_type_options[$field])){
			$values=$post_type_options[$field];
		}
	}
	return $values;
}

/**
 * Invalidate the wp_cache layer of theplus_get_option when the backing
 * wp_options row is written. See l_theplus_invalidate_options_cache() in
 * the Free plugin for full rationale.
 *
 * @since 6.5.0
 */
function theplus_invalidate_options_cache() {
	wp_cache_delete( 'tpae_pro_theplus_options', 'theplus_addons' );
}
add_action( 'update_option_theplus_options', 'theplus_invalidate_options_cache' );
add_action( 'add_option_theplus_options',    'theplus_invalidate_options_cache' );
add_action( 'delete_option_theplus_options', 'theplus_invalidate_options_cache' );

function theplus_invalidate_post_type_options_cache() {
	wp_cache_delete( 'tpae_pro_post_type_options', 'theplus_addons' );
}
add_action( 'update_option_post_type_options', 'theplus_invalidate_post_type_options_cache' );
add_action( 'add_option_post_type_options',    'theplus_invalidate_post_type_options_cache' );
add_action( 'delete_option_post_type_options', 'theplus_invalidate_post_type_options_cache' );

function theplus_scroll_animation(){

	static $cached_api_data = null;
	if ( null === $cached_api_data ) {
		$cached_api_data = get_option( 'theplus_api_connection_data' );
	}
	$theplus_data = $cached_api_data;
		
	if(isset($theplus_data['scroll_animation_offset']) && !empty($theplus_data['scroll_animation_offset']) && $theplus_data['scroll_animation_offset']!=0){
		$value= $theplus_data['scroll_animation_offset'].'%';
	}else if(isset($theplus_data['scroll_animation_offset']) && !empty($theplus_data['scroll_animation_offset']) && $theplus_data['scroll_animation_offset']==0){
		$value= '85%';
	}else{
		$value= '85%';
	}
	
	return $value;
}
function theplus_excerpt($limit) {
	if(method_exists('WPBMap', 'addAllMappedShortcodes')) {
		WPBMap::addAllMappedShortcodes();
	}
		global $post;
		$excerpt = explode(' ', get_the_excerpt(), $limit);
		$content = explode(' ', get_the_content(), $limit);
		
		if(!empty($excerpt)){
			if (count($excerpt)>=$limit) {
				array_pop($excerpt);			
				$excerpt = implode(" ",$excerpt).'...';			
			}else{
				$excerpt = implode(" ",$excerpt);
			}
		}else if(count($content)>=$limit){
			array_pop($content);			
			$excerpt = implode(" ",$content).'...';			
		}else {
			$excerpt = implode(" ",$excerpt);			
		}	
		$excerpt = preg_replace('`[[^]]*]`','',$excerpt);
	
	return $excerpt;
}
function limit_words($string, $word_limit){
	$words = explode(" ",$string);
	return implode(" ",array_splice($words,0,$word_limit));
}	
function theplus_get_title($limit) {
	if(method_exists('WPBMap', 'addAllMappedShortcodes')) {
		WPBMap::addAllMappedShortcodes();
	}
		global $post;
		$title = explode(' ', get_the_title(), $limit);
		if (count($title)>=$limit) {
			array_pop($title);
			$title = implode(" ",$title).'...';
		} else {
			$title = implode(" ",$title);
		}	
		$title = preg_replace('`[[^]]*]`','',$title);
	
	return $title;
}
function theplus_loading_image_grid($postid='',$type=''){
	global $post;
	$content_image='';
	if($type!='background'){		
		$image_url=THEPLUS_ASSETS_URL .'images/placeholder-grid.jpg';
		$content_image='<img src="'.esc_url($image_url).'" alt="'.esc_attr(get_the_title()).'"/>';
		
		return $content_image;
	
	}elseif($type=='background'){
	
		$image_url=THEPLUS_ASSETS_URL .'images/placeholder-grid.jpg';
		$data_src='style="background:url('.esc_url($image_url).') #f7f7f7;" ';
		
		return $data_src;
		
	}
}
function theplus_loading_bg_image($postid=''){
	global $post;
	$content_image='';
	if(!empty($postid)){
		$featured_image=get_the_post_thumbnail_url($postid,'full');
		if(empty($featured_image)){
			$featured_image=theplus_get_thumb_url();
		}
		$content_image='style="background:url('.esc_url($featured_image).') #f7f7f7;"';
		return $content_image;
	}else{
	return $content_image;
	}
}
function theplus_array_flatten($array) {
	  if (!is_array($array)) { 
		return FALSE; 
	  } 
	  $result = array(); 
	  foreach ($array as $key => $value) { 
		if (is_array($value)) { 
		  $result = array_merge($result, theplus_array_flatten($value)); 
		} 
		else { 
		  $result[$key] = $value; 
		} 
	  } 
	  return $result; 
}
function theplus_createSlug($str, $delimiter = '-'){
	
	$slug=preg_replace('/[^A-Za-z0-9-]+/', $delimiter, $str);
	return $slug;
	
} 

function tp_number_short( $n, $precision = 1 ) {
    if ($n < 900) {
        $n_format = number_format($n, $precision);
        $suffix = '';
    } else if ($n < 900000) {
        $n_format = number_format($n / 1000, $precision);
        $suffix = 'K';
    } else if ($n < 900000000) {
        $n_format = number_format($n / 1000000, $precision);
        $suffix = 'M';
    } else if ($n < 900000000000) {
        $n_format = number_format($n / 1000000000, $precision);
        $suffix = 'B';
    } else {
        $n_format = number_format($n / 1000000000000, $precision);
        $suffix = 'T';
	}
	
    if ( $precision > 0 ) {
        $dotzero = '.' . str_repeat( '0', $precision );
        $n_format = str_replace( $dotzero, '', $n_format );
    }
    return $n_format . $suffix;
}

/**
 * It is used for Remove transist for social feed, social remove, table widget
 *
 * @version 5.2.5
 */
function Tp_delete_transient() {
	$result = [];

	// P-011 fix: defense-in-depth capability check inside the handler
	// in case the registration outside ever changes.
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'Insufficient permissions.' ), 403 );
	}

	$delete_transient_nonce = isset($_POST['delete_transient_nonce']) ? $_POST['delete_transient_nonce'] : '';

	if( wp_verify_nonce($delete_transient_nonce, 'delete_transient_nonce') ) {
		global $wpdb;
			$table_name = $wpdb->prefix . "options";
			$DataBash = $wpdb->get_results( "SELECT * FROM $table_name" );
			$blockName = !empty($_POST['blockName']) ? $_POST['blockName'] : '';

			if($blockName == 'SocialFeed'){
				$transient = array(
					// facebook
						'Fb-Url-',
						'Fb-Time-',
						'Data-Fb-',
					// vimeo
						'Vm-Url-',
						'Vm-Time-',
						'Data-Vm-',
					// Instagram basic
						'IG-Url-',
						'IG-Profile-',
						'IG-Time-',
						'Data-IG-',	
					// Instagram Graph
						'IG-GP-Url-',
						'IG-GP-Time-',
						'IG-GP-Data-',
						'IG-GP-UserFeed-Url-',
						'IG-GP-UserFeed-Data-',
						'IG-GP-Hashtag-Url-',
						'IG-GP-HashtagID-data-',
						'IG-GP-HashtagData-Url-',
						'IG-GP-Hashtag-Data-',
						'IG-GP-story-Url-',
						'IG-GP-story-Data-',
						'IG-GP-Tag-Url-',
						'IG-GP-Tag-Data-',
					// Tweeter
						'Tw-BaseUrl-',
						'Tw-Url-',
						'Tw-Time-',
						'Data-tw-',
					// Youtube
						'Yt-user-',
						'Yt-user-Time-',
						'Data-Yt-user-',
						'Yt-Url-',
						'Yt-Time-',
						'Data-Yt-',
						'Yt-C-Url-',
						'Yt-c-Time-',
						'Data-c-Yt-',
						'Data-Yt-handle-',
						'Yt-handle-',
						'Yt-handle-Time-',
					// loadmore
						'SF-Loadmore-',
					// Performance
						'SF-Performance-'
				);
			}else if($blockName == 'SocialReviews'){
				$transient = array(
					// Facebook
						'Fb-R-Url-',
						'Fb-R-Time-',
						'Fb-R-Data-',
					// Google
						'G-R-Url-',
						'G-R-Time-',
						'G-R-Data-',
					// loadmore
						'SR-LoadMore-',
					// Performance
						'SR-Performance-',
					// Beach
						'Beach-Url-',
						'Beach-Time-',
						'Beach-Data-',
				);
			}else if($blockName == 'Table'){
				// Google Sheet and SQL Query
				$transient = array(
					'tp-gs-table-url-',
					'tp-gs-table-time-',
					'tp-gs-table-Data-',
					'tp-custom-query-url-',
                    'tp-custom-query-time-',
                    'tp-custom-query-Data-',
				);
			}

			foreach ($DataBash as $First) {
				foreach ($transient as $second) {
					$Find_Transient = !empty($First->option_name) ? strpos( $First->option_name, $second ) : '';
					if(!empty($Find_Transient)){
						$wpdb->delete( $table_name, array( 'option_name' => $First->option_name ) );
					}
				}
			}
			
		$result['success'] = 1;
		$result['blockName'] = $blockName;
	}else{
		$result['success'] = 0;
	}

	// echo json_encode($result);
	echo wp_send_json($result);
	// exit();
}

/**
 * Remove the nopriv registration of this destructive bulk
 * delete handler. The handler runs $wpdb->delete() against the options
 * table — it must never be reachable without authentication, even by
 * accident through a future refactor.
 */
add_action( 'wp_ajax_Tp_delete_transient', 'Tp_delete_transient' );

function Tp_socialreview_Gettoken() {
	$result = [];
	$delete_transient_nonce = isset($_POST['GetNonce']) ? $_POST['GetNonce'] : '';
	if( wp_verify_nonce($delete_transient_nonce, 'SocialReview_nonce') ) {

		$get_json = wp_remote_get("https://theplusaddons.com/wp-json/template_socialreview_api/v2/socialreviewAPI?time=".time());
		
		if ( is_wp_error( $get_json ) ) {
			wp_send_json_error( array( 'messages' => 'something wrong in API' ) );
		}else{
			$URL_StatusCode = wp_remote_retrieve_response_code($get_json);
			if($URL_StatusCode == 200){
				$getdata = wp_remote_retrieve_body($get_json);
				$result['SocialReview'] = json_decode($getdata, true);
				$result['success'] = 1;
				wp_send_json($result);
			}
		}
	}else{
		$result['success'] = 0;
	}

	exit();
}
add_action( 'wp_ajax_theplus_socialreview_Gettoken', 'Tp_socialreview_Gettoken' );
add_action( 'wp_ajax_nopriv_theplus_socialreview_Gettoken', 'Tp_socialreview_Gettoken' );


function get_current_ID($id){
	$newid = apply_filters( 'wpml_object_id', $id, 'elementor_library', TRUE );

	return $newid ? $newid : $id;
}

function plus_acf_repeater_field_ajax(){
	if(!isset($_POST['security']) || empty($_POST['security']) || ! wp_verify_nonce( $_POST['security'], 'theplus-addons' )){
		die('Invalid Nonce Security checked!');
	} 
	
	$data = [];	
	if(!empty($_POST['post_id']) && isset($_POST['post_id']) && absint($_POST['post_id'])){
	$acf_fields = get_field_objects($_POST['post_id']);
	
		if( $acf_fields ){
			foreach( $acf_fields as $field_name => $field ){
				if($field['type'] == 'repeater'){
					$data[] = [
					  'meta_id' => $field['name'],
					  'text' => $field['label']
					] ;
				}
			}
		}
	}
	wp_send_json_success($data);
}

if( is_admin() &&  current_user_can("manage_options") && class_exists('acf')){	
	add_action('wp_ajax_plus_acf_repeater_field','plus_acf_repeater_field_ajax');
}

function get_acf_repeater_field(){
	
	$data= [];	
	if(class_exists('acf') && isset($_GET['post']) && absint($_GET['post'])){
		$post_id = get_field('tp_preview_post',$_GET['post']);
		$acf_fields = get_field_objects($post_id);
		if( $acf_fields ){
			foreach( $acf_fields as $field_name => $field ){
				if($field['type'] == 'repeater'){
					$data[$field['name']] = $field['label'];
				}
			}
		}
	}
	return $data;
}

/*Wp login ajax*/
function theplus_ajax_login() {
	
	if( (!isset( $_POST['security'] ) || !wp_verify_nonce( $_POST['security'], 'ajax-login-nonce' ) )  ){		
		echo wp_json_encode( ['registered'=>false, 'message'=> esc_html__( 'Ooops, something went wrong, please try again later.', 'theplus' )] );
		exit;
	}
	
	$access_info = [];		
	$access_info['user_login']    = !empty($_POST['username']) ? sanitize_user($_POST['username']) : "";
	$access_info['user_password'] = !empty($_POST['password']) ? $_POST['password'] : "";
	$access_info['rememberme']    = true;
	
	$user_signon = wp_signon( $access_info );
	
	if ( !is_wp_error($user_signon) ){
		
		$userID = $user_signon->ID;
		wp_set_current_user( $userID, $access_info['user_login'] );
		wp_set_auth_cookie( $userID, true, true );
		
		echo wp_json_encode( ['loggedin' => true, 'message'=> esc_html__('Login successful, Redirecting...', 'theplus')] );
		
	} else {
		if ( isset( $user_signon->errors['invalid_email'][0] ) ) {
			
			echo wp_json_encode( ['loggedin' => false, 'message'=> esc_html__('Ops! Invalid Email..!', 'theplus')] );
		} elseif ( isset( $user_signon->errors['invalid_username'][0] ) ) {

			echo wp_json_encode( ['loggedin' => false, 'message'=> esc_html__('Ops! Invalid Username..!', 'theplus')] );
		} elseif ( isset( $user_signon->errors['incorrect_password'][0] ) ) {
			
			echo wp_json_encode( ['loggedin' => false, 'message'=> esc_html__('Ops! Incorrent Password..!', 'theplus')] );
		}
	}
	die();
}
add_action( 'wp_ajax_nopriv_theplus_ajax_login', 'theplus_ajax_login' );
/*Wp login ajax*/

/* login social application facebook/google */
function tp_login_social_app( $name, $email, $type = ''){
	$response	= [];
	$user_data	= get_user_by( 'email', $email ); 

	if ( ! empty( $user_data ) && $user_data !== false ) {
		$user_ID = $user_data->ID;
		wp_set_auth_cookie( $user_ID );
		wp_set_current_user( $user_ID, $name );
		do_action( 'wp_login', $user_data->user_login, $user_data );
		echo wp_json_encode( ['loggedin' => true, 'message'=> esc_html__('Login successful, Redirecting...', 'theplus')] );
	} else {

		/*
		 * Social sign-in previously created an account even on sites with
		 * registration switched off, silently bypassing users_can_register.
		 */
		if ( ! get_option( 'users_can_register' ) ) {
			echo wp_json_encode( ['loggedin' => false, 'message'=> esc_html__( 'Registering new users is currently not allowed.', 'theplus' )] );

			return;
		}

		$password = wp_generate_password( 12, true, false );

		$args = [
			'user_login' => $name,
			'user_pass'  => $password,
			'user_email' => $email,
			'first_name' => $name,
		];
		
		if ( username_exists( $name ) ) {
			$suffix_id = '-' . zeroise( wp_rand( 0, 9999 ), 4 );
			$name  .= $suffix_id;

			$args['user_login'] = strtolower( preg_replace( '/\s+/', '', $name ) );
		}

		$result = wp_insert_user( $args );

		$user_data = get_user_by( 'email', $email );

		if ( $user_data ) {
			$user_ID    = $user_data->ID;
			$user_email = $user_data->user_email;

			$user_meta = array(
				'login_source' => $type,
			);

			update_user_meta( $user_ID, 'theplus_login_form', $user_meta );
						
			if ( wp_check_password( $password, $user_data->user_pass, $user_data->ID ) ) {
				wp_set_auth_cookie( $user_ID );
				wp_set_current_user( $user_ID, $name );
				do_action( 'wp_login', $user_data->user_login, $user_data );
				echo wp_json_encode( ['loggedin' => true, 'message'=> esc_html__('Login successful, Redirecting...', 'theplus')] );
			}
		}
	}
	
	die();
}
/* login social application facebook/google */

/*facebook verify data*/
function tp_facebook_verify_data_user( $fb_token, $fb_id, $fb_secret ) {
	$fb_api = 'https://graph.facebook.com/oauth/access_token';
	$fb_api = add_query_arg( [
		'client_id'     => $fb_id,
		'client_secret' => $fb_secret,
		'grant_type'    => 'client_credentials',
	], $fb_api );

	$fb_res = wp_remote_get( $fb_api );

	if ( is_wp_error( $fb_res ) ) {
		wp_send_json_error();
	}

	$fb_response = json_decode( wp_remote_retrieve_body( $fb_res ), true );

	$app_token = $fb_response['access_token'];

	$debug_token = 'https://graph.facebook.com/debug_token';
	$debug_token = add_query_arg( [
		'input_token'  => $fb_token,
		'access_token' => $app_token,
	], $debug_token );

	$response = wp_remote_get( $debug_token );

	if ( is_wp_error( $response ) ) {
		return false;
	}

	return json_decode( wp_remote_retrieve_body( $response ), true );
}

function tp_facebook_get_user_email( $user_id, $access_token ){
	$fb_url = 'https://graph.facebook.com/' . $user_id;
	$fb_url = add_query_arg( [
		'fields'       => 'email',
		'access_token' => $access_token,
	], $fb_url );

	$response = wp_remote_get( $fb_url );

	if ( is_wp_error( $response ) ) {
		return false;
	}

	return json_decode( wp_remote_retrieve_body( $response ), true );
}
/*facebook verify data*/

/*Wp facebook social login ajax*/
function theplus_ajax_facebook_login() {
	
	if(!get_option('users_can_register')){
		echo wp_json_encode( ['registered'=>false, 'message'=> esc_html__( 'Registration option not enbled in your general settings.', 'theplus' )] );
		die();
	}
	
	if( (!isset( $_POST['nonce'] ) || !wp_verify_nonce( $_POST['nonce'], 'ajax-login-nonce' ) )  ){		
		echo wp_json_encode( ['registered'=>false, 'message'=> esc_html__( 'Ooops, something went wrong, please try again later.', 'theplus' )] );
		die();
	}
	
	$access_token = (!empty( $_POST['accessToken'] )) ? sanitize_text_field( $_POST['accessToken'] ) : '';
	$user_id = (!empty( $_POST['id'] )) ? sanitize_text_field( $_POST['id'] ) : 0;
	$email	=	(isset($_POST['email'])) ? sanitize_email($_POST['email']) : '';
	$name	=	(isset($_POST['name'])) ? sanitize_user( $_POST['name'] ) : '';
	
	$fb_data= get_option( 'theplus_api_connection_data' );
	$fb_app_id = (!empty($fb_data['theplus_facebook_app_id'])) ? $fb_data['theplus_facebook_app_id'] : '';
	$fb_secret_id = (!empty($fb_data['theplus_facebook_app_secret'])) ? $fb_data['theplus_facebook_app_secret'] : '';
				
	$verify_data = tp_facebook_verify_data_user( $access_token, $fb_app_id, $fb_secret_id );
	
	if ( empty( $user_id ) || ( $user_id !== $verify_data['data']['user_id'] ) || empty( $verify_data ) || empty( $fb_app_id ) || empty( $fb_secret_id ) || ( $fb_app_id !== $verify_data['data']['app_id'] ) || ( ! $verify_data['data']['is_valid'] ) ) {
		echo wp_json_encode( ['loggedin' => false, 'message'=> esc_html__('Invalid Authorization', 'theplus')] );
		die();
	}
	
	$email_res = tp_facebook_get_user_email( $verify_data['data']['user_id'], $access_token );
	
	if ( !empty( $email ) && ( empty( $email_res['email'] ) || $email_res['email'] !== $email ) ) {
		echo wp_json_encode( ['loggedin' => false, 'message'=> esc_html__('Facebook email validation failed', 'theplus')] );
		die();
	}

	/*
	 * The verified payload nests the id at ['data']['user_id'], as used above.
	 * Reading ['user_id'] resolved to null, so every login without a verified
	 * email collapsed to the literal '@facebook.com' -- the first such request
	 * created that account and every later caller was signed straight into it.
	 */
	$verify_fb_id = ! empty( $verify_data['data']['user_id'] ) ? $verify_data['data']['user_id'] : '';

	if ( ! empty( $email ) && ! empty( $email_res['email'] ) ) {
		$verify_email = sanitize_email( $email_res['email'] );
	} elseif ( ! empty( $verify_fb_id ) ) {
		$verify_email = sanitize_email( $verify_fb_id . '@facebook.com' );
	} else {
		echo wp_json_encode( ['loggedin' => false, 'message'=> esc_html__('Invalid Authorization', 'theplus')] );
		die();
	}

	tp_login_social_app( $name, $verify_email, 'facebook' );
	
	die();
}

add_action( 'wp_ajax_nopriv_theplus_ajax_facebook_login', 'theplus_ajax_facebook_login' );
/*Wp facebook social login ajax*/

/*Forgot Password*/
function theplus_ajax_forgot_password_ajax() {
	global $wpdb, $wp_hasher;
	$tpforgotdata = isset($_POST['tpforgotdata']) ? $_POST['tpforgotdata'] : '';
	
	$forgotdata = tp_check_decrypt_key($tpforgotdata);
	$forgotdata = json_decode($forgotdata,true);
	
	$nonce = isset($forgotdata['noncesecure']) ? $forgotdata['noncesecure'] : '';
	
	if ( ! wp_verify_nonce( $nonce, 'tp_user_lost_password_action' ) ){
		die ( 'Security checked!');
	}        
		
	$user_login = isset($_POST['user_login']) ? wp_unslash($_POST['user_login']) : '';
	
	$errors = new WP_Error();
 
    if ( empty( $user_login ) || ! is_string( $user_login ) ) {        
		echo wp_json_encode( [ 'lost_pass'=>'empty_username', 'message'=> sprintf(__( '<strong>ERROR</strong>: Enter a username or email address.','theplus' )) ] );
		exit;
    } elseif ( strpos( $user_login, '@' ) ) {
        $user_data = get_user_by( 'email', trim( wp_unslash( $user_login ) ) );
        if ( empty( $user_data ) ) {          
			echo wp_json_encode( [ 'lost_pass'=>'invalid_email', 'message'=> sprintf(__( '<strong>ERROR</strong>: There is no account with that username or email address.','theplus' )) ] );
			exit;
        }
    } else {
        $login     = trim( $user_login );
        $user_data = get_user_by( 'login', $login );
		if ( ! $user_data ) {			
			echo wp_json_encode( [ 'lost_pass'=>'invalidcombo', 'message'=> sprintf(__( '<strong>ERROR</strong>: There is no account with that username or email address.','theplus' )) ] );
			exit;
		}
    }
 
    do_action( 'lostpassword_post', $errors );

    $user_login = $user_data->user_login;
    $user_email = $user_data->user_email;
    $key        = get_password_reset_key( $user_data );

    if ( is_wp_error( $key ) ) {
		return $key;
    }

    if ( is_multisite() ) {
		$site_name = get_network()->site_name;
    } else {
		$site_name = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );
	}
	
	$reset_url = isset($forgotdata['reset_url']) ? $forgotdata['reset_url'] : '';
	$forgot_url = isset($forgotdata['forgot_url']) ? $forgotdata['forgot_url'] : '';
	
	//$forgotdatatceol = json_decode($forgotdata['tceol']);
	
	/*forgot password mail*/
	$message='';
	if(!empty($forgotdata['tceol']) && (!empty($forgotdata['tceol']['tp_cst_email_lost_opt']) && $forgotdata['tceol']['tp_cst_email_lost_opt']=='yes')){
					
		$elsub =  html_entity_decode($forgotdata['tceol']['tp_cst_email_lost_subject']);
		$elmsg =  html_entity_decode($forgotdata['tceol']['tp_cst_email_lost_message']);
		
		if(!empty($forgotdata["f_p_opt"]) && $forgotdata["f_p_opt"]=='default'){		
			$tplr_link_get = network_site_url( "wp-login.php?action=rp&key=$key&login=" . rawurlencode( $user_login ), 'login' );		
		}else if(!empty($forgotdata["f_p_opt"]) && $forgotdata["f_p_opt"]=='f_p_frontend'){
			$data_fp_frontdata = [];
			$data_fp_frontdata['key'] = $key;
			$data_fp_frontdata['redirecturl'] = $reset_url;
			$data_fp_frontdata['forgoturl'] = $forgot_url;
			$data_fp_frontdata['login'] = rawurlencode( $user_login );
			
			$frontdata_key= tp_plus_simple_decrypt( json_encode($data_fp_frontdata), 'ey' );
			
			$tplr_link_get = network_site_url( "wp-login.php?action=theplusrpf&datakey=$frontdata_key", 'login' );
		}
		
		$elfind = array( '/\[tplr_sitename\]/', '/\[tplr_username\]/', '/\[tplr_link\]/' );
		$lrreplacement = array( $site_name,$user_login,$tplr_link_get);		
		$clrmessage = preg_replace( $elfind,$lrreplacement,$elmsg );
		
		$lrheaders = array( 'Content-Type: text/html; charset=UTF-8' );
		 
		wp_mail( $user_email, $elsub, $clrmessage, $lrheaders );
		
	}else{ 
		$message = esc_html__( 'Someone has requested a password reset for the following account:','theplus' ) . "\r\n\r\n";

		/* translators: %s: Site name */
		$message .= sprintf( esc_html__( 'Site Name: %s', 'theplus' ), $site_name ) . "\r\n\r\n";

		/* translators: %s: Username */
		$message .= sprintf( esc_html__( 'Username: %s','theplus' ), $user_login ) . "\r\n\r\n";
		$message .= esc_html__( 'If this was a mistake, just ignore this email and nothing will happen.','theplus' ) . "\r\n\r\n";
		$message .= esc_html__( 'To reset your password, visit the following address:','theplus' ) . "\r\n\r\n";
		
		if(!empty($forgotdata["f_p_opt"]) && $forgotdata["f_p_opt"]=='default'){		
			$message .= '<' . network_site_url( "wp-login.php?action=rp&key=$key&login=" . rawurlencode( $user_login ), 'login' ) . ">\r\n";		
		}else if(!empty($forgotdata["f_p_opt"]) && $forgotdata["f_p_opt"]=='f_p_frontend'){
			$data_fp_frontdata = [];
			$data_fp_frontdata['key'] = $key;
			$data_fp_frontdata['redirecturl'] = $reset_url;
			$data_fp_frontdata['forgoturl'] = $forgot_url;
			$data_fp_frontdata['login'] = rawurlencode( $user_login );
			
			$frontdata_key= tp_plus_simple_decrypt( json_encode($data_fp_frontdata), 'ey' );
			$message .= '<' . network_site_url( "wp-login.php?action=theplusrpf&datakey=$frontdata_key", 'login' ) . ">\r\n";
		}
	}
	

	/* translators: %s: Site name */
	$title = sprintf( esc_html__( '[%s] Password Reset','theplus' ), $site_name );

	$title = apply_filters( 'retrieve_password_title', $title, $user_login, $user_data );

	$message = apply_filters( 'retrieve_password_message', $message, $key, $user_login, $user_data );
	
	$fp_correct_email_text = !empty($forgotdata['fp_correct_email']) ? $forgotdata['fp_correct_email'] : 'Check your e-mail for the reset password link.';
	
	if(!empty($forgotdata['tceol']) && (!empty($forgotdata['tceol']['tp_cst_email_lost_opt']) && $forgotdata['tceol']['tp_cst_email_lost_opt']=='yes')){		
		echo wp_json_encode( [ 'lost_pass'=>'confirm', 'message'=> $fp_correct_email_text ] );
	}else{
		if ( wp_mail( $user_email, wp_specialchars_decode( $title ), $message ) )
		echo wp_json_encode( [ 'lost_pass'=>'confirm', 'message'=> $fp_correct_email_text ] );
	else
		echo wp_json_encode( [ 'lost_pass'=>'could_not_sent', 'message'=> esc_html__('The e-mail could not be sent.','theplus') . "<br />\n" . esc_html__('Possible reason: your host may have disabled the mail() function.','theplus') ] );
	}	

	exit;
}
add_action( 'wp_ajax_nopriv_theplus_ajax_forgot_password', 'theplus_ajax_forgot_password_ajax' );
add_action( 'wp_ajax_theplus_ajax_forgot_password', 'theplus_ajax_forgot_password_ajax' );
/*Forgot Password*/

/*ENCRYPT DECRIPT*/
function tp_check_decrypt_key($key){   	 
	$decrypted = tp_plus_simple_decrypt( $key, 'dy' );

	return $decrypted;
}

function tp_plus_simple_decrypt( $string, $action = 'dy' ) {

	/**
	 * P-007 fix: Refuse to fall back to the publicly-known hardcoded
	 * secret 'PO$_key'. On fresh installs without a license, lazily
	 * generate and persist a per-site random key so encrypted AJAX
	 * payloads cannot be forged by attackers reading the source code.
	 */
	$generated = get_option( 'tp_key_random_generate' );
	if ( empty( $generated ) ) {
		$generated = wp_generate_password( 64, true, true );
		update_option( 'tp_key_random_generate', $generated, false );
	}

	$licence_data = get_option( 'tpaep_licence_data' );
	$secret_key   = ! empty( $licence_data['license_key'] ) ? $licence_data['license_key'] : $generated;

	if ( empty( $secret_key ) ) {
		// Defensive: never proceed with an empty/null secret key.
		return false;
	}

	$secret_iv      = 'PO$_iv';
	$encrypt_method = 'AES-128-CBC';
	$key            = hash( 'sha256', $secret_key );
	$iv             = substr( hash( 'sha256', $secret_iv ), 0, 16 );

	$output = false;

	if ( $action == 'ey' ) {
		$output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
	} else if ( $action == 'dy' ){
		$output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
	}

	return $output;
}

/*reset password start*/
add_action( 'wp_ajax_nopriv_theplus_ajax_reset_password', 'theplus_ajax_reset_password_ajax' );
add_action( 'wp_ajax_theplus_ajax_reset_password', 'theplus_ajax_reset_password_ajax' );
function theplus_ajax_reset_password_ajax() {
	$tpresetdata = isset($_POST['tpresetdata']) ? $_POST['tpresetdata'] : '';
	
	$resetdata = tp_check_decrypt_key($tpresetdata);
	$resetdata = json_decode($resetdata,true);
	$user_login = isset($resetdata['login']) ? $resetdata['login'] : '';	
	$user_login = urldecode($user_login);
    $user_key = isset($resetdata['key']) ? $resetdata['key'] : '';
	$nonce = isset($resetdata['noncesecure']) ? $resetdata['noncesecure'] : '';
	
	if ( ! wp_verify_nonce( $nonce, 'tp_reset_action' ) ){
		die ( 'Security checked!');
	}
	
    if ( 'POST' == $_SERVER['REQUEST_METHOD'] ) {
        $user = check_password_reset_key( $user_key, $user_login );
 
        if ( ! $user || is_wp_error( $user ) ) {
            if ( $user && $user->get_error_code() === 'expired_key' ) {
			   echo wp_json_encode( [ 'reset_pass'=>'expire', 'message'=> esc_html__('The entered key has expired. Please start reset process again.','theplus') ] );
            } else {
				echo wp_json_encode( [ 'reset_pass'=>'invalid', 'message'=> esc_html__('The entered key is invalid. Please start reset process again.','theplus') ] );
            }
            exit;
        }
 
        if ( isset( $_POST['user_pass'] ) ) {
            if ( $_POST['user_pass'] != $_POST['user_pass_conf'] ) {                
				echo wp_json_encode( [ 'reset_pass'=>'mismatch', 'message'=> esc_html__('Password does not match. Please try again.','theplus') ] );
				exit;
            }
 
            if ( empty( $_POST['user_pass'] ) ) {                
                echo wp_json_encode( [ 'reset_pass'=>'empty', 'message'=> esc_html__('Password Field is Empty. Enter Password.','theplus') ] );                
                exit;
            }
			
            reset_password( $user, $_POST['user_pass'] );
			
           echo wp_json_encode( [ 'reset_pass'=>'success', 'message'=> esc_html__('Your password has been changed. Use your new password to sign in.','theplus') ] );
		   
        } else {
            echo "Invalid request.";
        }
 
        exit;
    }
}

add_action( 'login_form_theplusrpf','redirect_to_tp_custom_password_reset');
if(!empty($_GET['action']) && $_GET['action']=='theplusrpf'){
	add_action( 'login_form_resetpass','redirect_to_tp_custom_password_reset' );	
}

function redirect_to_tp_custom_password_reset() {
	
    if ( 'GET' == $_SERVER['REQUEST_METHOD'] ) {
        // Verify key / login combo
		
		if(!empty($_GET['action']) && $_GET['action']=='theplusrpf'){
			$datakey = isset($_GET['datakey']) ? $_GET['datakey'] : '';
			$forgotdata = tp_check_decrypt_key($datakey);
			$forgotdata = json_decode(stripslashes($forgotdata),true);
			$user = check_password_reset_key( $forgotdata['key'], rawurldecode($forgotdata['login']) );
			$forgoturl = $forgotdata['forgoturl'];
			$redirecturl = $forgotdata['redirecturl'];
			$login = $forgotdata['login'];
			$key = $forgotdata['key'];
		}else{
			$forgoturl = isset($_GET['forgoturl']) ? wp_http_validate_url($_GET['forgoturl']) : '';
			$redirecturl ='';
			$login = isset($_GET['login']) ? $_GET['login'] : '';
			$key = isset($_GET['key']) ? $_GET['key'] : '';
			
			$user = check_password_reset_key( $key, $login );			
		}
        	
        if ( ! $user || is_wp_error( $user ) ) {
			
            if ( $user && $user->get_error_code() === 'expired_key' ) {
				$redirect_url = $forgoturl;
				$redirect_url = add_query_arg( 'expired', 'expired', $redirect_url );
				wp_safe_redirect($redirect_url);
            } else {
				$redirect_url = $forgoturl;
				$redirect_url = add_query_arg( 'invalid', 'invalid', $redirect_url );
				wp_safe_redirect($redirect_url);
            }
            exit;
        }
		if(!empty($redirecturl)){	
			$data_res = [];
			$data_res['login'] =  $login;
			$data_res['forgoturl'] = $forgoturl;
			$data_res['key'] = $key;
			
			$data_reskey= tp_plus_simple_decrypt( json_encode($data_res), 'ey' );
			
			$redirect_url = $redirecturl;
			$redirect_url = add_query_arg( 'action', 'theplusrpf', $redirect_url );
			$redirect_url = add_query_arg( 'datakey', $data_reskey, $redirect_url );
			wp_safe_redirect($redirect_url);
		}else{
			wp_safe_redirect(home_url());
		}
        exit;
    }
}
/*reset password end*/

function theplus_ajax_register_user( $email='', $first_name='', $last_name='',$tp_user_role='' ) {
	    $errors = new \WP_Error();
		$result    = '';
	    if ( ! is_email( $email ) ) {
	        $errors->add( 'email', esc_html__( 'The email address you entered is not valid.', 'theplus' ) );
	        return $errors;
	    }
	 
	    if ( username_exists( $email ) || email_exists( $email ) ) {
	        $errors->add( 'email_exists', esc_html__( 'An account exists with this email address.', 'theplus' ) );
	        return $errors;
	    }
		
	    if(!empty($_POST["dis_password"]) && $_POST["dis_password"]=='yes'){
			if(!empty($_POST["dis_password_conf"]) && $_POST["dis_password_conf"]!='yes' && $_POST['password']){
				$password = $_POST['password'];
			}else{
				if($_POST['password'] == $_POST['conf_password']){	
					$password = $_POST['password'];
				}else{
					$errors->add( 'pass_mismatch', esc_html__( 'Password & Confirm Password Not Match!', 'theplus' ) );
					return $errors;
				}
			}			
		}else{
			$password = wp_generate_password( 12, false );
		}
		
		if(!empty($_POST["user_login"])){
			$user_login = !empty($_POST['user_login']) ? sanitize_user($_POST['user_login']) : '';
		}else{
			$user_login = $email;
		}
		
	    $user_data = array(
	        'user_login'    => $user_login,
	        'user_email'    => $email,
	        'user_pass'     => $password,
	        'first_name'    => $first_name,
	        'last_name'     => $last_name,
	        'nickname'      => $first_name,
	    );
		$user_id_get = username_exists( $user_login );
		
		$user_id='';
		if ( ! $user_id_get ) {
			$user_id = wp_insert_user( $user_data );
			if(empty($_POST['tceo'])){
				if(!empty($_POST["dis_password"]) && $_POST["dis_password"]=='no'){
					wp_new_user_notification( $user_id, null, 'both' );
				}else{
					wp_new_user_notification( $user_id, null, 'both' );
				}
			}			
			
			wp_update_user( array ('ID' => $user_id) ) ;
		}
		
	    return $user_id;
}
if(get_option('users_can_register')){
	add_action( 'wp_ajax_nopriv_theplus_ajax_register', 'theplus_ajax_register' );
}

function get_element_widget_data( $elements, $id ) {

	foreach ( $elements as $element ) {
		if ( $id === $element['id'] ) {
			return $element;
		}

		if ( ! empty( $element['elements'] ) ) {
			$element = get_element_widget_data( $element['elements'], $id );

			if ( $element ) {
				return $element;
			}
		}
	}

	return false;
}

function theplus_ajax_register() {
	
	if( !isset( $_POST['security'] ) || !wp_verify_nonce( $_POST['security'], 'ajax-login-nonce' ) ){		
	echo wp_json_encode( ['registered'=>false, 'message'=> esc_html__( 'Ooops, something went wrong, please try again later.', 'theplus' )] );
	exit;
	}
	 
	if ( 'POST' == $_SERVER['REQUEST_METHOD'] ) { 
		if ( ! get_option( 'users_can_register' ) ) {
			echo wp_json_encode( ['registered'=>false, 'message'=> esc_html__( 'Registering new users is currently not allowed.', 'theplus' )] );
		} else {
			$email      = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
			$first_name = isset($_POST['first_name']) ? sanitize_text_field( $_POST['first_name'] ) : '';
			$last_name  = isset($_POST['last_name']) ? sanitize_text_field( $_POST['last_name'] ) : '';
			$user_login  = isset($_POST['user_login']) ? sanitize_text_field( $_POST['user_login'] ) : '';
			$passwordemc = '';
		
			$captcha = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
			$dis_cap = isset( $_POST['dis_cap'] ) ? sanitize_text_field( wp_unslash( $_POST['dis_cap'] ) ) : '';

			$dis_mail_chimp   = isset( $_POST['dis_mail_chimp'] ) ? sanitize_text_field( wp_unslash( $_POST['dis_mail_chimp'] ) ) : '';
			$mail_chimp_check = isset( $_POST['mail_chimp_check'] ) ? sanitize_text_field( wp_unslash( $_POST['mail_chimp_check'] ) ) : '';
			$auto_loggedin    = isset( $_POST['auto_loggedin'] ) ? sanitize_text_field( wp_unslash( $_POST['auto_loggedin'] ) ) : '';
			
			/*
			 * Whether a captcha must be solved is decided SERVER SIDE. This block
			 * previously keyed off $_POST['dis_cap'], so simply omitting that field
			 * (or sending anything other than "yes") skipped verification entirely --
			 * a complete captcha bypass on an unauthenticated registration endpoint.
			 * A reCAPTCHA secret being configured is now the sole trigger, and the
			 * request may only ever ask for MORE checking, never less.
			 */
			$check_recaptcha  = get_option( 'theplus_api_connection_data' );
			$recaptcha_secret = ! empty( $check_recaptcha['theplus_secret_key_recaptcha'] ) ? $check_recaptcha['theplus_secret_key_recaptcha'] : '';
			$captcha_required = ! empty( $recaptcha_secret );

			$resscore      = '';
			$check_captcha = false;

			if ( $captcha_required ) {
				if ( empty( $captcha ) ) {
					$message = esc_html__( 'Please check the the captcha form.', 'theplus' );
					echo wp_json_encode( array( 'registered' => false, 'message' => $message ) );
					exit;
				}

				/* POST the secret in the body -- as a query string it leaked into proxy/CDN access logs. */
				$response = wp_remote_post(
					'https://www.google.com/recaptcha/api/siteverify',
					array(
						'timeout'   => 10,
						'sslverify' => true,
						'body'      => array(
							'secret'   => $recaptcha_secret,
							'response' => $captcha,
							'remoteip' => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
						),
					)
				);

				/* Indexing a WP_Error as an array was a hard fatal on any transport failure. */
				if ( is_wp_error( $response ) ) {
					echo wp_json_encode( array( 'registered' => false, 'message' => esc_html__( 'Could not verify the captcha, please try again.', 'theplus' ), 'recaptcha' => false ) );
					exit;
				}

				$responseKeys = json_decode( wp_remote_retrieve_body( $response ), true );

				if ( empty( $responseKeys['success'] ) ) {
					$message = esc_html__( 'Please check the the reCaptcha form.', 'theplus' );
					echo wp_json_encode( array( 'registered' => false, 'message' => $message, 'recaptcha' => false ) );
					exit;
				}

				$resscore      = isset( $responseKeys['score'] ) ? $responseKeys['score'] : '';
				$check_captcha = true;
			}
			
			$result     = theplus_ajax_register_user( $email, $first_name, $last_name );
			if(empty($result)){				
				echo wp_json_encode( ['registered'=>false, 'message'=> esc_html__( 'Username Already Exists.', 'theplus' )] );				
			}else if ( is_wp_error( $result ) ) {
				// Parse errors into a string and append as parameter to redirect
				$errors  = $result->get_error_message();
				echo wp_json_encode( ['registered' => false, 'message'=> $errors ] );
			} else {
				// Success
				
				if(!empty($_POST['tceo']) && (!empty($_POST['tceo']['tp_cst_email_opt']) && $_POST['tceo']['tp_cst_email_opt']=='yes')){
					
					$esub =  stripslashes(html_entity_decode($_POST['tceo']['tp_cst_email_subject']));
					$emsg =  stripslashes(html_entity_decode($_POST['tceo']['tp_cst_email_message']));
					$find = array( '/\[tp_firstname\]/', '/\[tp_lastname\]/', '/\[tp_username\]/', '/\[tp_email\]/', '/\[tp_password\]/' );
					$replacement = array( $first_name,$last_name, $user_login, $email,$passwordemc );
					$cmessage = preg_replace( $find, $replacement, $emsg );
					$headers = array( 'Content-Type: text/html; charset=UTF-8' );
					 
					wp_mail( $email, $esub, $cmessage, $headers );
				}				
				/* translators: %s: Site name */
				$message = sprintf(__( 'You have successfully registered to %s. We have emailed your account details to the email address you entered.', 'theplus' ), get_bloginfo( 'name' ) );
				$response = ['registered' => true, 'message'=> $message, 'recaptcha' => $check_captcha, 'recaptcha_score' => $resscore ];
				
				//mailchimp subscriber user
				
				if((!empty($dis_mail_chimp) && $dis_mail_chimp=='yes') && (!empty($mail_chimp_check) && $mail_chimp_check=='yes')){
					$sep_cust_mail_chimp_apikey = isset($_POST["mc_custom_apikey"]) ? sanitize_text_field( wp_unslash( $_POST["mc_custom_apikey"] ) ) : '';
					$sep_cust_mail_chimp_listid = isset($_POST["mc_custom_listid"]) ? sanitize_text_field( wp_unslash( $_POST["mc_custom_listid"] ) ) : '';

					/* Refuse anything that is not a genuine Mailchimp key / list id. The key's
					   datacenter suffix ends up in the request host, so a malformed value here
					   would be an unauthenticated SSRF. Falling back to empty makes the callee
					   use the site-level credentials instead. */
					if ( ! preg_match( '/^[a-f0-9]{32}-[a-z]{2}\d{1,3}$/i', $sep_cust_mail_chimp_apikey ) ) {
						$sep_cust_mail_chimp_apikey = '';
					}
					if ( ! preg_match( '/^[a-zA-Z0-9_-]{1,64}$/', $sep_cust_mail_chimp_listid ) ) {
						$sep_cust_mail_chimp_listid = '';
					}
					
					$mc_cst_group_value=$mc_cst_tags_value='';

					if(!empty($_POST['mc_cst_group_value']) && sanitize_text_field($_POST['mc_cst_group_value'])){
						$mc_cst_group_value= sanitize_text_field($_POST['mc_cst_group_value']);
					}
					if(!empty($_POST['mc_cst_tags_value']) && sanitize_text_field($_POST['mc_cst_tags_value'])){
						$mc_cst_tags_value= sanitize_text_field($_POST['mc_cst_tags_value']);
					}
					
					plus_mailchimp_subscribe_using_lr($email, $first_name, $last_name,$dis_mail_chimp,$sep_cust_mail_chimp_apikey,$sep_cust_mail_chimp_listid,$mc_cst_group_value,$mc_cst_tags_value);
				}
				
				if((!empty($auto_loggedin) && $auto_loggedin==true)){
					$access_info = [];
					$access_info['user_login']    = !empty($email) ? $email : "";
					$access_info['user_password'] = !empty($_POST['password']) ? $_POST['password'] : "";
					$access_info['rememberme']    = true;
					$user_signon = wp_signon( $access_info, false );
					if ( !is_wp_error($user_signon) ){				
						$response = ['registered' => true, 'message'=> esc_html__('Login successful, Redirecting...', 'theplus')];
					} else {			
						$response = ['registered' => false, 'message'=> esc_html__('Registered Successfully, Ops! Login Failed...!', 'theplus')];
					}
				}
				echo wp_json_encode($response);
			}
		}

		exit;
	}
}

function plus_mailchimp_subscribe_using_lr($email='', $first_name='', $last_name='',$dis_mail_chimp='',$sep_cust_mail_chimp_apikey='',$sep_cust_mail_chimp_listid='',$mc_cst_group_value='',$mc_cst_tags_value=''){
		
	$list_id=$api_key='';
	if($dis_mail_chimp=='yes' && (!empty($sep_cust_mail_chimp_apikey) && !empty($sep_cust_mail_chimp_listid))){
		$api_key = $sep_cust_mail_chimp_apikey;
		$list_id = $sep_cust_mail_chimp_listid;		
	}else{
		$options = get_option( 'theplus_api_connection_data' );
		$list_id = (!empty($options['theplus_mailchimp_id'])) ? $options['theplus_mailchimp_id'] : '';
		$api_key = (!empty($options['theplus_mailchimp_api'])) ? $options['theplus_mailchimp_api'] : '';
	}
	
	$mc_r_status = 'subscribed';
	if(!empty($_POST['mcl_double_opt_in']) && $_POST['mcl_double_opt_in']=='yes'){
		$mc_r_status = 'pending';
	}
	
	$mc_cst_group_value=$mc_cst_tags_value='';

	if(!empty($_POST['mc_cst_group_value']) && sanitize_text_field($_POST['mc_cst_group_value'])){
		$mc_cst_group_value= sanitize_text_field($_POST['mc_cst_group_value']);
	}
	if(!empty($_POST['mc_cst_tags_value']) && sanitize_text_field($_POST['mc_cst_tags_value'])){
		$mc_cst_tags_value= sanitize_text_field($_POST['mc_cst_tags_value']);
	}
	$result = json_decode( theplus_mailchimp_subscriber_message($email, $mc_r_status, $list_id, $api_key, array('FNAME' => $first_name,'LNAME' => $last_name),$mc_cst_group_value,$mc_cst_tags_value ) );	
	
}

function theplus_load_metro_style_layout($columns='1',$metro_column='3',$metro_style='style-1'){
	$i=($columns!='') ? $columns : 1;
	if(!empty($metro_column)){
		//style-3
		if($metro_column=='3' && $metro_style=='style-1'){
			$i=($i<=10) ? $i : ($i%10);			
		}
		if($metro_column=='3' && $metro_style=='style-2'){
			$i=($i<=9) ? $i : ($i%9);			
		}
		if($metro_column=='3' && $metro_style=='style-3'){
			$i=($i<=15) ? $i : ($i%15);			
		}
		if($metro_column=='3' && $metro_style=='style-4'){
			$i=($i<=8) ? $i : ($i%8);			
		}
		//style-4
		if($metro_column=='4' && $metro_style=='style-1'){
			$i=($i<=12) ? $i : ($i%12);			
		}
		if($metro_column=='4' && $metro_style=='style-2'){
			$i=($i<=14) ? $i : ($i%14);			
		}
		if($metro_column=='4' && $metro_style=='style-3'){
			$i=($i<=12) ? $i : ($i%12);			
		}
		//style-5
		if($metro_column=='5' && $metro_style=='style-1'){
			$i=($i<=18) ? $i : ($i%18);			
		}
		//style-6
		if($metro_column=='6' && $metro_style=='style-1'){
			$i=($i<=16) ? $i : ($i%16);			
		}
	}
	return $i;
}

//post pagination
function theplus_pagination($pages = '', $range = 2, $pagination_next='', $pagination_prev=''){  
	$showitems = ($range * 2)+1;  
	
	global $paged;
	if(empty($paged)) $paged = 1;
	
	if($pages == ''){
		global $wp_query;
		if( $wp_query->max_num_pages <= 1 )
		return;
		
		$pages = $wp_query->max_num_pages;
		/*if(!$pages)
		{
			$pages = 1;
		}*/
		$pages = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;
	}   
	
	if(1 != $pages){
		$paginate ="<div class=\"theplus-pagination\">";
		if ( get_previous_posts_link() ){
			$paginate .= get_previous_posts_link('<i class="fas fa-long-arrow-alt-left" aria-hidden="true"></i>'.$pagination_prev);
		}
		
		for ($i=1; $i <= $pages; $i++){
			if (1 != $pages && ( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
			{
				$paginate .= ($paged == $i)? "<span class=\"current\">".esc_html($i)."</span>":"<a href='".get_pagenum_link($i)."' class=\"inactive\">".esc_html($i)."</a>";
			}
		}
		
		if ( get_next_posts_link() ){
			get_next_posts_link($pagination_next,1);
		}			
		if ( $paged < $pages ) $paginate .= "<a class='paginate-next' href='".get_pagenum_link($paged + 1)."'>".$pagination_next."<i class='fas fa-long-arrow-alt-right' aria-hidden='true'></i></a>";
		
		$paginate .="</div>\n";
		return $paginate;
	}
}

function theplus_mailchimp_subscriber_message( $email, $status, $list_id, $api_key, $merge_fields = array(), $mc_cst_group_value='', $mc_cst_tags_value=''){

	/*
	 * The API key and list id can originate from a widget-level "custom"
	 * setting that reaches us through $_POST, and the key's datacenter suffix
	 * is spliced straight into the request host below. Without a strict format
	 * check that is an unauthenticated SSRF primitive: an arbitrary host would
	 * receive a PUT with an attacker chosen body. A Mailchimp key is always
	 * 32 hex characters, a hyphen, then a datacenter such as "us21", and a
	 * list id is alphanumeric — anything else is refused outright.
	 */
	if ( ! is_string( $api_key ) || ! preg_match( '/^[a-f0-9]{32}-[a-z]{2}\d{1,3}$/i', $api_key ) ) {
		return false;
	}

	if ( ! is_string( $list_id ) || ! preg_match( '/^[a-zA-Z0-9_-]{1,64}$/', $list_id ) ) {
		return false;
	}

    $data = array(
        'apikey'        => $api_key,
        'email_address' => $email,
        'status'        => $status,
    );
	
	if(!empty($merge_fields)){
		$data['merge_fields'] = $merge_fields;
	}
	
	if(!empty($mc_cst_group_value) && sanitize_text_field($mc_cst_group_value)){
		$interests = explode( ' | ', trim( sanitize_text_field($mc_cst_group_value) ) );
		$interests=array_flip($interests);
		
		foreach($interests as $key => $value){
			$data['interests'][$key] = true;
		}
	}
	
	if(!empty($mc_cst_tags_value) && sanitize_text_field($mc_cst_tags_value)){
		$data['tags'] = explode( '|', trim( sanitize_text_field($mc_cst_tags_value)) );
	}
	
	// MEDIUM-4 / P-11 fix: replaced raw curl_init() / curl_setopt() block
	// with wp_remote_request(). wp_remote_* respects WP_HTTP_PROXY_*
	// constants, the pre_http_request filter, and managed-host proxy
	// rules (WP Engine, Kinsta, Cloudways) — all of which the previous
	// direct cURL call bypassed. It is also the only HTTP idiom that
	// passes WP_Plugin_Check, which WP 7.0 tightens enforcement of.
	$mch_url = 'https://' . substr( $api_key, strpos( $api_key, '-' ) + 1 ) . '.api.mailchimp.com/3.0/lists/' . $list_id . '/members/' . md5( strtolower( $data['email_address'] ) );

	$response = wp_remote_request(
		$mch_url,
		array(
			'method'    => 'PUT', // Mailchimp upsert endpoint expects PUT.
			'headers'   => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Basic ' . base64_encode( 'user:' . $api_key ),
				'User-Agent'    => 'PHP-MCAPI/2.0',
			),
			'body'      => wp_json_encode( $data ),
			'timeout'   => 10,
			'sslverify' => true,
		)
	);

	if ( is_wp_error( $response ) ) {
		// Same failure semantics as the previous curl_exec() returning
		// false — the caller (json_decode'd into a stdClass) already
		// handles the "no usable response" path.
		return false;
	}

	return wp_remote_retrieve_body( $response );
}
function plus_mailchimp_subscribe(){
	/**
	 * P-002 fix: Require a valid nonce before this nopriv-registered handler
	 * runs. Without it, any unauthenticated visitor can call Mailchimp's API
	 * through the site and subscribe arbitrary addresses to the configured list.
	 */
	if ( ! check_ajax_referer( 'tp-mailchimp-nonce', 'security', false ) ) {
		wp_send_json_error( array( 'message' => 'Invalid security token.' ), 403 );
	}

	$options = get_option( 'theplus_api_connection_data' );
	$list_id = (!empty($options['theplus_mailchimp_id'])) ? $options['theplus_mailchimp_id'] : '';
	$api_key = (!empty($options['theplus_mailchimp_api'])) ? $options['theplus_mailchimp_api'] : ''; // YOUR MAILCHIMP API KEY HERE
	
	$FNAME=$LNAME=$BIRTHDAY=$PHONE='';	
	$chimp_field = array();
	if(!empty($_POST['FNAME'])){
		$FNAME= sanitize_text_field($_POST['FNAME']);
		$chimp_field['FNAME'] =$FNAME;
	}
	if(!empty($_POST['LNAME'])){
		$LNAME= sanitize_text_field($_POST['LNAME']);
		$chimp_field['LNAME'] =$LNAME;
	}
	if(!empty($_POST['BIRTHDAY']) && !empty($_POST['BIRTHMONTH'])){
		$BIRTHDAY = sanitize_text_field($_POST['BIRTHMONTH']) . '/' . sanitize_text_field($_POST['BIRTHDAY']);
		$chimp_field['BIRTHDAY'] =$BIRTHDAY;
	}
	if(!empty($_POST['PHONE'])){
		$PHONE = sanitize_text_field( wp_unslash( $_POST['PHONE'] ) );
		$chimp_field['PHONE'] =$PHONE;
	}
	
	$mc_status = 'subscribed';
	if(!empty($_POST['mc_double_opt_in']) && $_POST['mc_double_opt_in']=='pending'){
		$mc_status = 'pending';
	}
	
	$mc_cst_group_value = '';
	if(!empty($_POST['mc_cst_group_value']) && sanitize_text_field($_POST['mc_cst_group_value'])){
		$mc_cst_group_value= sanitize_text_field($_POST['mc_cst_group_value']);
	}
	
	$mc_cst_tags_value = '';
	if(!empty($_POST['mc_cst_tags_value']) && sanitize_text_field($_POST['mc_cst_tags_value'])){
		$mc_cst_tags_value= sanitize_text_field($_POST['mc_cst_tags_value']);
	}
	
	$mc_email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	if ( ! is_email( $mc_email ) ) {
		echo 'incorrect';
		die;
	}
	$result = json_decode( theplus_mailchimp_subscriber_message( $mc_email, $mc_status, $list_id, $api_key, $chimp_field, $mc_cst_group_value, $mc_cst_tags_value ) );
	
	if( $result->status == 400 ){
		echo 'incorrect';
	} elseif( $result->status == 'subscribed' ){
		echo 'correct';
	} elseif( $result->status == 'pending' ){
		echo 'pending';
	} else {
		echo 'not-verify';
	}
	die;
}
add_action('wp_ajax_plus_mailchimp_subscribe','plus_mailchimp_subscribe');
add_action('wp_ajax_nopriv_plus_mailchimp_subscribe', 'plus_mailchimp_subscribe');

/*woo thank you page selection start*/
function theplus_thankyou_content_func(){
	$tp_data=get_option( 'theplus_api_connection_data' );
	$tp_thankyoupage_id = $tp_data['theplus_woo_thank_you_page_select'];	
	if(!empty($tp_thankyoupage_id)){
		echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $tp_thankyoupage_id, true );
	}else{
		the_content();
	}
}
add_action( 'theplus_thankyou_content', 'theplus_thankyou_content_func' );

add_filter(	'wc_get_template','theplus_checkout_page_template', 51, 3 );

function theplus_checkout_page_template($located, $name, $args){	
	$tp_data=get_option( 'theplus_api_connection_data' );		
	if($name === 'checkout/thankyou.php' && !empty($tp_data['theplus_woo_thank_you_page_select'])){
		$located = THEPLUS_WSTYLES . 'woo-thankyou/thankyou.php';
	}
	return $located;
}
/*woo thank you page selection end*/

//Woocommerce Products
if( class_exists('woocommerce')) {
	function theplus_out_of_stock() {
		global $post;
		$id = $post->ID;
		$status = get_post_meta($id, '_stock_status',true);
		
		if ($status == 'outofstock') {
			return true;
		} else {
			return false;
		}
	}

	function theplus_product_badge($out_of_stock_val='') {
	global $post, $product;
		if (theplus_out_of_stock()) {
			echo '<span class="badge out-of-stock">'.$out_of_stock_val.'</span>';
		} else if ( $product->is_on_sale() ) {
			if ('discount' == 'discount') {
				if ($product->get_type() == 'variable') {
					$available_variations = $product->get_available_variations();								
					$maximumper = 0;
					for ($i = 0; $i < count($available_variations); ++$i) {
						$variation_id=$available_variations[$i]['variation_id'];
						$variable_product1= new WC_Product_Variation( $variation_id );
						$regular_price = $variable_product1->get_regular_price();
						$sales_price = $variable_product1->get_sale_price();
						$percentage = $sales_price ? round( ( ( $regular_price - $sales_price ) / $regular_price ) * 100) : 0;
						if ($percentage > $maximumper) {
							$maximumper = $percentage;
						}
					}
					echo apply_filters('woocommerce_sale_flash', '<span class="badge onsale perc">&darr; '.$maximumper.'%</span>', $post, $product);
				} else if ($product->get_type() == 'simple'){
					if( !empty($product->get_sale_price()) ){
						$salePrice = $product->get_sale_price();
						$percentage = round( ( ( $product->get_regular_price() - $salePrice ) / $product->get_regular_price() ) * 100 );
						// $output_html = '<span class="badge onsale perc">&darr; '.$percentage.'%</span>';
						echo apply_filters('woocommerce_sale_flash', '<span class="badge onsale perc">&darr; '.$percentage.'%</span>', $post, $product);
					}
				} else if ($product->get_type() == 'external'){
					$percentage = round( ( ( $product->get_regular_price() - $product->get_sale_price() ) / $product->get_regular_price() ) * 100 );
					echo apply_filters('woocommerce_sale_flash', '<span class="badge onsale perc">&darr; '.$percentage.'%</span>', $post, $product);
				}
			} else {
				echo apply_filters('woocommerce_sale_flash', '<span class="badge onsale">'.esc_html__( 'Sale','theplus' ).'</span>', $post, $product);
			}
		}
	}
	add_action( 'theplus_product_badge', 'theplus_product_badge',3 );
}

add_action('elementor/widgets/register', function($widgets_manager){
	$elementor_widget_blacklist = [
		'plus-elementor-widget',
	];
	
	foreach($elementor_widget_blacklist as $widget_name){
		$widgets_manager->unregister($widget_name);
	}
}, 15);

function registered_widgets(){
	$widgets = include THEPLUS_PATH . 'config.php';

	return $widgets;
}