<?php
/**
 * Exit if accessed directly.
 *
 * @link       https://posimyth.com/
 * @since      6.4.8
 *
 * @package    Theplus
 * @subpackage ThePlus/Notices
 * */


/**
 * Exit if accessed directly.
 * */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Tp_Pro_Ability_Main' ) ) {

	/**
	 * This class used for only load widget notice
	 *
	 * @since 6.4.8
	 */
	class Tp_Pro_Ability_Main {

		/**
		 * Instance
		 *
		 * @since 6.4.8
		 * @access private
		 * @static
		 * @var instance of the class.
		 */
		private static $instance = null;

		/**
		 * Instance
		 *
		 * Ensures only one instance of the class is loaded or can be loaded.
		 *
		 * @since 6.4.8
		 * @access public
		 * @static
		 * @return instance of the class.
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor
		 *
		 * Perform some compatibility checks to make sure basic requirements are meet.
		 *
		 * @since 6.4.8
		 */
		public function __construct() {
			add_action( 'wp_abilities_api_init', array( $this, 'tp_pro_register_abilities' ) );
		}

		/**
		 * Dynamically load and register all abilities from the widgets-ability folder.
		 *
		 * @since 6.4.8
		 */
		public function tp_pro_ability_public_flag( $args, $name ) {
			if ( ! is_string( $name ) || 0 !== strpos( $name, 'tpaep/' ) ) {
				return $args;
			}

			if ( ! isset( $args['meta'] ) || ! is_array( $args['meta'] ) ) {
				$args['meta'] = array();
			}

			if ( ! isset( $args['meta']['public'] ) ) {
				$args['meta']['public'] = true;
			}

			return $args;
		}

		public function tp_pro_register_abilities() {
			if ( ! function_exists( 'wp_register_ability' ) || ! function_exists( 'wp_has_ability_category' ) ) {
				return;
			}

			if ( ! wp_has_ability_category( 'tpae' ) ) {
				return;
			}

			/* WP 7.1 added a unified meta.public flag that defaults to false; set it before the ability files register. */
			add_filter( 'wp_register_ability_args', array( $this, 'tp_pro_ability_public_flag' ), 10, 2 );

			require_once THEPLUS_PATH . 'modules/ability/tpaep-mcp-bridge.php';

			$ability_dir = THEPLUS_PATH . 'modules/ability/widgets-ability';

			if ( ! is_dir( $ability_dir ) ) {
				return;
			}

			$ability_files = glob( $ability_dir . '/*.php' );

			if ( empty( $ability_files ) ) {
				return;
			}

			foreach ( $ability_files as $ability_file ) {
				if ( is_file( $ability_file ) ) {
					require_once $ability_file;
				}
			}
		}

	}

	Tp_Pro_Ability_Main::instance();
}