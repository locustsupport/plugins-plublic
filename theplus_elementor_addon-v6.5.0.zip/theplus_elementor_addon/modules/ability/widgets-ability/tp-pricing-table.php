<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-pricing-table', [
'label' => __('Pricing Table (Pro)', 'theplus'),
    'description' => __('Adds The Plus "Pricing Table" widget (tp-pricing-table) to an Elementor container. Pro version with extra styles.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'             => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'           => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'            => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'pricing_table_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'style-1', 'style-2', 'style-3']],
        'title_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['style-1']],
        'pricing_title' => ['type' => 'string', 'description' => 'Title'],
        'pricing_subtitle' => ['type' => 'string', 'description' => 'Sub Title'],
        'image_icon' => ['type' => 'string', 'description' => 'Select Icon', 'enum' => ['icon', 'svg']],
        'svg_icon' => ['type' => 'string', 'description' => 'Svg Select Option', 'enum' => ['image_icon', 'img', 'svg']],
        'svg_image' => ['type' => 'integer', 'description' => 'Only Svg (Image ID)'],
        'svg_d_icon' => ['type' => 'string', 'description' => 'Select Svg Icon', 'enum' => ['image_icon', 'svg_icon']],
        'select_image' => ['type' => 'integer', 'description' => 'Use Image As icon (Image ID)'],
        'icon_font_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['font_awesome', 'font_awesome_5', 'icon_mind', 'image_icon']],
        'font_awesome_toggle' => ['type' => 'string', 'description' => 'Font Awesome', 'enum' => ['yes', 'no']],
        'icon_fontawesome' => ['type' => 'string', 'description' => 'Icon Library'],
        'font_awesome5_toggle' => ['type' => 'string', 'description' => 'Font Awesome 5', 'enum' => ['yes', 'no']],
        'icon_fontawesome_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'icon_mind_toggle' => ['type' => 'string', 'description' => 'Icon Mind', 'enum' => ['yes', 'no']],
        'icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['icon_font_style', 'image_icon']],
        'price_style' => ['type' => 'string', 'description' => 'Price Style', 'enum' => ['style-1', 'style-2', 'style-3']],
        'price_prefix' => ['type' => 'string', 'description' => 'Prefix Text'],
        'price' => ['type' => 'string', 'description' => 'Value Of Price'],
        'price_postfix' => ['type' => 'string', 'description' => 'Postfix Text'],
        'show_previous_price' => ['type' => 'string', 'description' => 'Display Previous Price', 'enum' => ['yes', 'no']],
        'previous_price_prefix' => ['type' => 'string', 'description' => 'Prefix Text'],
        'previous_price' => ['type' => 'string', 'description' => 'Value Of Price'],
        'previous_price_postfix' => ['type' => 'string', 'description' => 'Postfix Text'],
        'content_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['stylist_list', 'wysiwyg_content']],
        'content_list_style' => ['type' => 'string', 'description' => 'List Style', 'enum' => ['content_style', 'style-1', 'style-2']],
        'list_description' => ['type' => 'string', 'description' => 'List Description'],
        'list_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['font_awesome', 'font_awesome_5', 'icon_mind']],
        'fontawesome_toggle' => ['type' => 'string', 'description' => 'Font Awesome', 'enum' => ['yes', 'no']],
        'list_icon_fontawesome' => ['type' => 'string', 'description' => 'Icon Library'],
        'fontawesome5_toggle' => ['type' => 'string', 'description' => 'Font Awesome 5', 'enum' => ['yes', 'no']],
        'list_icon_fontawesome_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'iconmind_toggle' => ['type' => 'string', 'description' => 'Icon Mind', 'enum' => ['yes', 'no']],
        'list_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['list_icon_style']],
        'show_tooltips' => ['type' => 'string', 'description' => 'Tooltip Options', 'enum' => ['yes', 'no']],
        'show_tooltips_on' => ['type' => 'string', 'description' => 'Tooltip On', 'enum' => ['box', 'icon', 'show_tooltips']],
        'content_type' => ['type' => 'string', 'description' => 'Content Type', 'enum' => ['content_wysiwyg', 'normal_desc', 'show_tooltips']],
        'tooltip_content_desc' => ['type' => 'string', 'description' => 'Description'],
        'tooltip_content_wysiwyg' => ['type' => 'string', 'description' => 'Tooltip Content'],
        'tooltip_content_align' => ['type' => 'string', 'description' => 'Text Alignment', 'enum' => ['center', 'content_type', 'icon', 'left', 'right', 'show_tooltips', '{{WRAPPER}} {{CURRENT_ITEM}} .tippy-tooltip .tippy-content']],
        'tooltip_content_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'icon_list' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'icon_list'],
        'load_show_list_toggle' => ['type' => 'string', 'description' => 'List Open Default'],
        'list_style_show_option' => ['type' => 'string', 'description' => 'Expand Section Title'],
        'list_style_less_option' => ['type' => 'string', 'description' => 'Shrink Section Title'],
        'content_wysiwyg_style' => ['type' => 'string', 'description' => 'Content Style', 'enum' => ['content_style', 'style-1', 'style-2']],
        'content_wysiwyg' => ['type' => 'string', 'description' => 'Content'],
        'display_button' => ['type' => 'string', 'description' => 'Button', 'enum' => ['yes', 'no']],
        'button_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'display_button', 'style-7', 'style-8', 'style-9']],
        'button_text' => ['type' => 'string', 'description' => 'Button Text'],
        'button_link' => ['type' => 'object', 'description' => 'Button Link'],
        'button_icon_type' => ['type' => 'string', 'description' => 'Icon Type', 'enum' => ['display_button', 'icon', 'lottie']],
        'lottieUrl' => ['type' => 'object', 'description' => 'Lottie URL'],
        'button_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['button_icon_type', 'button_style!', 'display_button', 'font_awesome', 'font_awesome_5', 'icon_mind']],
        'fontawesometoggle' => ['type' => 'string', 'description' => 'Font Awesome', 'enum' => ['yes', 'no']],
        'button_icon' => ['type' => 'string', 'description' => 'Icon'],
        'fontawesome5toggle' => ['type' => 'string', 'description' => 'Font Awesome 5', 'enum' => ['yes', 'no']],
        'button_icon_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'icon_mindtoggle' => ['type' => 'string', 'description' => 'Icon Mind', 'enum' => ['yes', 'no']],
        'button_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['button_icon_style', 'button_icon_type', 'button_style!', 'display_button']],
        'before_after' => ['type' => 'string', 'description' => 'Icon Position', 'enum' => ['after', 'before', 'button_icon_style!', 'button_icon_type', 'button_style!', 'display_button']],
        'icon_spacing' => ['type' => 'object', 'description' => 'Icon Spacing (Slider/Size Object)'],
        'call_to_action_text' => ['type' => 'string', 'description' => 'Call To Action(CTA) Text'],
        'display_ribbon_pin' => ['type' => 'string', 'description' => 'Display Ribbon', 'enum' => ['yes', 'no']],
        'ribbon_pin_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['display_ribbon_pin', 'style-1', 'style-2', 'style-3']],
        'ribbon_pin_text' => ['type' => 'string', 'description' => 'Ribbon/Pin Text'],
        'svg_type' => ['type' => 'string', 'description' => 'Select Style Image', 'enum' => ['image_icon']],
        'duration' => ['type' => 'object', 'description' => 'Duration (Slider/Size Object)'],
        'max_width' => ['type' => 'object', 'description' => 'Max Width Svg (Slider/Size Object)'],
        'border_stroke_color' => ['type' => 'string', 'description' => 'Border/Stoke Color (Color Hex/RGBA)'],
        'icon_style' => ['type' => 'string', 'description' => 'Icon Style', 'enum' => ['hexagon', 'pentagon', 'rounded', 'square', 'square-rotate']],
        'icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'icon_width' => ['type' => 'object', 'description' => 'Icon Width (Slider/Size Object)'],
        'icon_color_option' => ['type' => 'string', 'description' => 'Icon Color', 'enum' => ['gradient', 'icon', 'solid']],
        'icon_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'icon_gradient_color1' => ['type' => 'string', 'description' => 'Color 1 (Color Hex/RGBA)'],
        'icon_gradient_color1_control' => ['type' => 'object', 'description' => 'Color 1 Location (Slider/Size Object)'],
        'icon_gradient_color2' => ['type' => 'string', 'description' => 'Color 2 (Color Hex/RGBA)'],
        'icon_gradient_color2_control' => ['type' => 'object', 'description' => 'Color 2 Location (Slider/Size Object)'],
        'icon_gradient_style' => ['type' => 'string', 'description' => 'Gradient Style', 'enum' => ['icon_color_option', 'of_type']],
        'icon_gradient_angle' => ['type' => 'object', 'description' => 'Gradient Angle (Slider/Size Object)'],
        'icon_gradient_position' => ['type' => 'string', 'description' => 'Position', 'enum' => ['icon_color_option', 'icon_gradient_style', 'of_type', '{{WRAPPER}} .plus-pricing-table .pricing-table-inner .pricing-icon']],
        'icon_fill_color' => ['type' => 'string', 'description' => 'Fill (Color Hex/RGBA)'],
        'icon_stroke_color' => ['type' => 'string', 'description' => 'Stroke (Color Hex/RGBA)'],
        'icon_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['{{WRAPPER}} .plus-pricing-table .pricing-table-inner .pricing-icon']],
        'icon_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'icon_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'icon_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'icon_hover_color_option' => ['type' => 'string', 'description' => 'Icon Hover Color', 'enum' => ['gradient', 'icon', 'solid']],
        'icon_hover_color' => ['type' => 'string', 'description' => 'Hover Color (Color Hex/RGBA)'],
        'icon_hover_gradient_color1' => ['type' => 'string', 'description' => 'Color 1 (Color Hex/RGBA)'],
        'icon_hover_gradient_color1_control' => ['type' => 'object', 'description' => 'Color 1 Location (Slider/Size Object)'],
        'icon_hover_gradient_color2' => ['type' => 'string', 'description' => 'Color 2 (Color Hex/RGBA)'],
        'icon_hover_gradient_color2_control' => ['type' => 'object', 'description' => 'Color 2 Location (Slider/Size Object)'],
        'icon_hover_gradient_style' => ['type' => 'string', 'description' => 'Gradient Style', 'enum' => ['icon_hover_color_option', 'of_type']],
        'icon_hover_gradient_angle' => ['type' => 'object', 'description' => 'Gradient Angle (Slider/Size Object)'],
        'icon_hover_gradient_position' => ['type' => 'string', 'description' => 'Position', 'enum' => ['icon_hover_color_option', 'icon_hover_gradient_style', 'of_type', '{{WRAPPER}} .plus-pricing-table .pricing-table-inner:hover .pricing-icon']],
        'icon_fill_color_hover' => ['type' => 'string', 'description' => 'Fill (Color Hex/RGBA)'],
        'icon_stroke_color_hover' => ['type' => 'string', 'description' => 'Stroke (Color Hex/RGBA)'],
        'icon_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'icon__hover_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'imagewidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'imageHeight' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'image_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'lottiedisplay' => ['type' => 'string', 'description' => 'Display', 'enum' => ['block', 'flex', 'inherit', 'initial', 'inline-block', 'inline-flex']],
        'lottieMright' => ['type' => 'object', 'description' => 'Margin Right (Slider/Size Object)'],
        'lottieMleft' => ['type' => 'object', 'description' => 'Margin Left (Slider/Size Object)'],
        'lottieWidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'lottieHeight' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'lottieSpeed' => ['type' => 'object', 'description' => 'Speed (Slider/Size Object)'],
        'lottieVertical' => ['type' => 'string', 'description' => 'Vertical Align', 'enum' => ['bottom', 'middle', 'top']],
        'lottieLoop' => ['type' => 'string', 'description' => 'Loop Animation', 'enum' => ['yes', 'no']],
        'lottiehover' => ['type' => 'string', 'description' => 'Hover Animation', 'enum' => ['yes', 'no']],
        'title_alignment' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'icon', 'left', 'right', '{{WRAPPER}} .plus-pricing-table.pricing-style-1 .pricing-title,
					{{WRAPPER}} .plus-pricing-table.pricing-style-2 .pricing-title-wrap .pricing-title,
					{{WRAPPER}} .plus-pricing-table.pricing-style-3 .pricing-title-wrap .pricing-title']],
        'title_color_option' => ['type' => 'string', 'description' => 'Title Color', 'enum' => ['gradient', 'icon', 'solid']],
        'title_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'title_gradient_color1' => ['type' => 'string', 'description' => 'Color 1 (Color Hex/RGBA)'],
        'title_gradient_color1_control' => ['type' => 'object', 'description' => 'Color 1 Location (Slider/Size Object)'],
        'title_gradient_color2' => ['type' => 'string', 'description' => 'Color 2 (Color Hex/RGBA)'],
        'title_gradient_color2_control' => ['type' => 'object', 'description' => 'Color 2 Location (Slider/Size Object)'],
        'title_gradient_style' => ['type' => 'string', 'description' => 'Gradient Style', 'enum' => ['of_type', 'title_color_option']],
        'title_gradient_angle' => ['type' => 'object', 'description' => 'Gradient Angle (Slider/Size Object)'],
        'title_gradient_position' => ['type' => 'string', 'description' => 'Position', 'enum' => ['of_type', 'title_color_option', 'title_gradient_style', '{{WRAPPER}} .plus-pricing-table .pricing-title']],
        'title_hover_color_option' => ['type' => 'string', 'description' => 'Title Hover Color', 'enum' => ['gradient', 'icon', 'solid']],
        'title_hover_color' => ['type' => 'string', 'description' => 'Hover Color (Color Hex/RGBA)'],
        'title_hover_gradient_color1' => ['type' => 'string', 'description' => 'Color 1 (Color Hex/RGBA)'],
        'title_hover_gradient_color1_control' => ['type' => 'object', 'description' => 'Color 1 Location (Slider/Size Object)'],
        'title_hover_gradient_color2' => ['type' => 'string', 'description' => 'Color 2 (Color Hex/RGBA)'],
        'title_hover_gradient_color2_control' => ['type' => 'object', 'description' => 'Color 2 Location (Slider/Size Object)'],
        'title_hover_gradient_style' => ['type' => 'string', 'description' => 'Gradient Style', 'enum' => ['of_type', 'title_hover_color_option']],
        'title_hover_gradient_angle' => ['type' => 'object', 'description' => 'Gradient Angle (Slider/Size Object)'],
        'title_hover_gradient_position' => ['type' => 'string', 'description' => 'Position', 'enum' => ['of_type', 'title_hover_color_option', 'title_hover_gradient_style', '{{WRAPPER}} .plus-pricing-table .pricing-table-inner:hover .pricing-title']],
        'subtitle_alignment' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'icon', 'left', 'right', '{{WRAPPER}} .plus-pricing-table.pricing-style-1 .pricing-subtitle,{{WRAPPER}} .plus-pricing-table.pricing-style-2 .pricing-subtitle,{{WRAPPER}} .plus-pricing-table.pricing-style-3 .pricing-subtitle']],
        'subtitle_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'subtitle_Hover_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'previous_price_align' => ['type' => 'string', 'description' => 'Price Alignment', 'enum' => ['bottom', 'icon', 'middle', 'toggle', 'top', '{{WRAPPER}} .plus-pricing-table .pricing-previous-price-wrap']],
        'previous_price_color' => ['type' => 'string', 'description' => 'Price Color (Color Hex/RGBA)'],
        'previous_price_hover_color' => ['type' => 'string', 'description' => 'Price Hover Color (Color Hex/RGBA)'],
        'prefix_price_color' => ['type' => 'string', 'description' => 'Prefix Color (Color Hex/RGBA)'],
        'prefix_price_hover_color' => ['type' => 'string', 'description' => 'Prefix Hover Color (Color Hex/RGBA)'],
        'price_alignment' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'icon', 'left', 'right', '{{WRAPPER}} .plus-pricing-table.pricing-style-1 .pricing-price-wrap,{{WRAPPER}} .plus-pricing-table.pricing-style-2 .pricing-price-wrap ,{{WRAPPER}} .plus-pricing-table.pricing-style-3 .pricing-price-wrap ']],
        'price_color' => ['type' => 'string', 'description' => 'Price Color (Color Hex/RGBA)'],
        'price_hover_color' => ['type' => 'string', 'description' => 'Price Hover Color (Color Hex/RGBA)'],
        'price_postfix_color' => ['type' => 'string', 'description' => 'Postfix Color (Color Hex/RGBA)'],
        'price_postfix_hover_color' => ['type' => 'string', 'description' => 'Postfix Hover Color (Color Hex/RGBA)'],
        'content_spg' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'list_icon_size' => ['type' => 'object', 'description' => 'List Icon Size (Slider/Size Object)'],
        'content_border_width_color' => ['type' => 'object', 'description' => 'Border Width (Slider/Size Object)'],
        'list_between_space' => ['type' => 'object', 'description' => 'List Between Space (Slider/Size Object)'],
        'icon_between_space' => ['type' => 'object', 'description' => 'Icon Spacing (Slider/Size Object)'],
        'desc_content_alignment' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'content_style', 'icon', 'left', 'right', 'toggle', '{{WRAPPER}} .plus-pricing-table .pricing-content-wrap.content-desc .pricing-content,{{WRAPPER}} .plus-pricing-table .pricing-content-wrap.content-desc .pricing-content p']],
        'listing_content_alignment' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'content_style', 'flex-end', 'flex-start', 'icon', 'toggle', '{{WRAPPER}} .plus-pricing-table ul.plus-icon-list-items li']],
        'content_text_color' => ['type' => 'string', 'description' => 'Content Color (Color Hex/RGBA)'],
        'content_text_color_hover_active' => ['type' => 'string', 'description' => 'Box Hover Color (Color Hex/RGBA)'],
        'content_text_color_hover' => ['type' => 'string', 'description' => 'Content Hover Color (Color Hex/RGBA)'],
        'content_border_top_color' => ['type' => 'string', 'description' => 'Border Top Color (Color Hex/RGBA)'],
        'list_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'list_icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'list_style_2_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'list_text_hover_color_box' => ['type' => 'string', 'description' => 'Hover Text Color (Color Hex/RGBA)'],
        'list_icon_hover_color_box' => ['type' => 'string', 'description' => 'Hover Icon Color (Color Hex/RGBA)'],
        'list_style2_hover_border_color_box' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'list_text_hover_color' => ['type' => 'string', 'description' => 'Hover Text Color (Color Hex/RGBA)'],
        'list_icon_hover_color' => ['type' => 'string', 'description' => 'Hover Icon Color (Color Hex/RGBA)'],
        'list_style2_hover_border_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'toggle_expand_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'toggle_expand_text_hover_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'toggle_expand_border_top' => ['type' => 'string', 'description' => 'Border Top Style', 'enum' => ['yes', 'no']],
        'toggle_expand_border_top_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'content_box_border' => ['type' => 'string', 'description' => 'Content Box Border', 'enum' => ['yes', 'no']],
        'content_box_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'content_box_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'content_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'content_box_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'content_border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'tt_on_icon' => ['type' => 'string', 'description' => 'Tooltip Icon'],
        'tt_on_icon_margin_left' => ['type' => 'object', 'description' => 'Left Offset (Slider/Size Object)'],
        'tt_on_icon_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'tt_on_icon_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'button_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'button_top_space' => ['type' => 'object', 'description' => 'Button Above Space (Slider/Size Object)'],
        'button_svg_icon' => ['type' => 'object', 'description' => 'Button Svg Icon (Slider/Size Object)'],
        'button_alignment' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'icon', 'left', 'right', '{{WRAPPER}} .plus-pricing-table.pricing-style-1 .pt-plus-button-wrapper,{{WRAPPER}} .plus-pricing-table.pricing-style-2 .pt-plus-button-wrapper,{{WRAPPER}} .plus-pricing-table.pricing-style-3 .pt-plus-button-wrapper ']],
        'button_top_bottom' => ['type' => 'string', 'description' => 'Position', 'enum' => ['bottom', 'icon', 'middle']],
        'btn_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'btn_svg_icon_color' => ['type' => 'string', 'description' => 'Svg Icon Color (Color Hex/RGBA)'],
        'button_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['button_style', 'dashed', 'dotted', 'groove', 'none', 'solid', '{{WRAPPER}} .pt_plus_button.button-style-8 .button-link-wrap']],
        'button_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'button_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'button_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'btn_text_box_hover_color' => ['type' => 'string', 'description' => 'Text Hover Color (Color Hex/RGBA)'],
        'btn_svg_icon_color_box_h' => ['type' => 'string', 'description' => 'Svg Icon Color (Color Hex/RGBA)'],
        'btn_border_box_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'box_hover_btn_radius' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        'btn_text_hover_color' => ['type' => 'string', 'description' => 'Text Hover Color (Color Hex/RGBA)'],
        'btn_svg_icon_color_h' => ['type' => 'string', 'description' => 'Svg Icon Color (Color Hex/RGBA)'],
        'button_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'button_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        'cta_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'ribbon_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'ribbon_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'ribbon_bg_style_3' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'ribbon_pin_width' => ['type' => 'object', 'description' => 'Max-Width (Slider/Size Object)'],
        'ribbon_pin_adjust' => ['type' => 'object', 'description' => 'Adjust Pin Text (Slider/Size Object)'],
        'bg_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'bg_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'box_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'box_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'box_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'box_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'bg_hover_animation' => ['type' => 'string', 'description' => 'Hover Animation', 'enum' => ['hover_fadein', 'hover_normal', 'hover_slide_bottom', 'hover_slide_left', 'hover_slide_right', 'hover_slide_top']],
        'box_overlay_bg_color' => ['type' => 'string', 'description' => 'Overlay Background Color (Color Hex/RGBA)'],
        'box_hover_overlay_bg_color' => ['type' => 'string', 'description' => 'Overlay Hover Background Color (Color Hex/RGBA)'],
        'transform_scale' => ['type' => 'object', 'description' => 'Scale Zoom (Slider/Size Object)'],
        'settings'            => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports SVG icons, price toggle logic, and custom feature list tooltips.']
    ], 'required' => ['post_id', 'parent_id', 'pricing_title'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_pro_pricing_table_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pro_pricing_table_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_pro_pricing_table_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_pro_pricing_table_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-pricing-table';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Pricing Table widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    if (empty($input['pricing_title'])) { return new WP_Error('missing_params', __('pricing_title is required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['pricing_table_style'])) { $settings['pricing_table_style'] = sanitize_text_field($input['pricing_table_style']); }
    if (isset($input['title_style'])) { $settings['title_style'] = sanitize_text_field($input['title_style']); }
    if (isset($input['pricing_title'])) { $settings['pricing_title'] = sanitize_text_field($input['pricing_title']); }
    if (isset($input['pricing_subtitle'])) { $settings['pricing_subtitle'] = sanitize_text_field($input['pricing_subtitle']); }
    if (isset($input['image_icon'])) { $settings['image_icon'] = sanitize_text_field($input['image_icon']); }
    if (isset($input['svg_icon'])) { $settings['svg_icon'] = sanitize_text_field($input['svg_icon']); }
    if (!empty($input['svg_image'])) { $settings['svg_image'] = ['id' => absint($input['svg_image'])]; }
    if (isset($input['svg_d_icon'])) { $settings['svg_d_icon'] = sanitize_text_field($input['svg_d_icon']); }
    if (!empty($input['select_image'])) { $settings['select_image'] = ['id' => absint($input['select_image'])]; }
    if (isset($input['icon_font_style'])) { $settings['icon_font_style'] = sanitize_text_field($input['icon_font_style']); }
    if (isset($input['font_awesome_toggle'])) { $settings['font_awesome_toggle'] = sanitize_text_field($input['font_awesome_toggle']); }
    if (isset($input['icon_fontawesome'])) { $settings['icon_fontawesome'] = sanitize_text_field($input['icon_fontawesome']); }
    if (isset($input['font_awesome5_toggle'])) { $settings['font_awesome5_toggle'] = sanitize_text_field($input['font_awesome5_toggle']); }
    if (isset($input['icon_fontawesome_5'])) { $settings['icon_fontawesome_5'] = sanitize_text_field($input['icon_fontawesome_5']); }
    if (isset($input['icon_mind_toggle'])) { $settings['icon_mind_toggle'] = sanitize_text_field($input['icon_mind_toggle']); }
    if (isset($input['icons_mind'])) { $settings['icons_mind'] = sanitize_text_field($input['icons_mind']); }
    if (isset($input['price_style'])) { $settings['price_style'] = sanitize_text_field($input['price_style']); }
    if (isset($input['price_prefix'])) { $settings['price_prefix'] = sanitize_text_field($input['price_prefix']); }
    if (isset($input['price'])) { $settings['price'] = sanitize_text_field($input['price']); }
    if (isset($input['price_postfix'])) { $settings['price_postfix'] = sanitize_text_field($input['price_postfix']); }
    if (isset($input['show_previous_price'])) { $settings['show_previous_price'] = sanitize_text_field($input['show_previous_price']); }
    if (isset($input['previous_price_prefix'])) { $settings['previous_price_prefix'] = sanitize_text_field($input['previous_price_prefix']); }
    if (isset($input['previous_price'])) { $settings['previous_price'] = sanitize_text_field($input['previous_price']); }
    if (isset($input['previous_price_postfix'])) { $settings['previous_price_postfix'] = sanitize_text_field($input['previous_price_postfix']); }
    if (isset($input['content_style'])) { $settings['content_style'] = sanitize_text_field($input['content_style']); }
    if (isset($input['content_list_style'])) { $settings['content_list_style'] = sanitize_text_field($input['content_list_style']); }
    if (isset($input['list_description'])) { $settings['list_description'] = sanitize_text_field($input['list_description']); }
    if (isset($input['list_icon_style'])) { $settings['list_icon_style'] = sanitize_text_field($input['list_icon_style']); }
    if (isset($input['fontawesome_toggle'])) { $settings['fontawesome_toggle'] = sanitize_text_field($input['fontawesome_toggle']); }
    if (isset($input['list_icon_fontawesome'])) { $settings['list_icon_fontawesome'] = sanitize_text_field($input['list_icon_fontawesome']); }
    if (isset($input['fontawesome5_toggle'])) { $settings['fontawesome5_toggle'] = sanitize_text_field($input['fontawesome5_toggle']); }
    if (isset($input['list_icon_fontawesome_5'])) { $settings['list_icon_fontawesome_5'] = sanitize_text_field($input['list_icon_fontawesome_5']); }
    if (isset($input['iconmind_toggle'])) { $settings['iconmind_toggle'] = sanitize_text_field($input['iconmind_toggle']); }
    if (isset($input['list_icons_mind'])) { $settings['list_icons_mind'] = sanitize_text_field($input['list_icons_mind']); }
    if (isset($input['show_tooltips'])) { $settings['show_tooltips'] = sanitize_text_field($input['show_tooltips']); }
    if (isset($input['show_tooltips_on'])) { $settings['show_tooltips_on'] = sanitize_text_field($input['show_tooltips_on']); }
    if (isset($input['content_type'])) { $settings['content_type'] = sanitize_text_field($input['content_type']); }
    if (isset($input['tooltip_content_desc'])) { $settings['tooltip_content_desc'] = sanitize_text_field($input['tooltip_content_desc']); }
    if (isset($input['tooltip_content_wysiwyg'])) { $settings['tooltip_content_wysiwyg'] = sanitize_text_field($input['tooltip_content_wysiwyg']); }
    if (isset($input['tooltip_content_align'])) { $settings['tooltip_content_align'] = sanitize_text_field($input['tooltip_content_align']); }
    if (isset($input['tooltip_content_color'])) { $settings['tooltip_content_color'] = sanitize_text_field($input['tooltip_content_color']); }
    if (isset($input['icon_list'])) { $settings['icon_list'] = $input['icon_list']; }
    if (isset($input['load_show_list_toggle'])) { $settings['load_show_list_toggle'] = sanitize_text_field($input['load_show_list_toggle']); }
    if (isset($input['list_style_show_option'])) { $settings['list_style_show_option'] = sanitize_text_field($input['list_style_show_option']); }
    if (isset($input['list_style_less_option'])) { $settings['list_style_less_option'] = sanitize_text_field($input['list_style_less_option']); }
    if (isset($input['content_wysiwyg_style'])) { $settings['content_wysiwyg_style'] = sanitize_text_field($input['content_wysiwyg_style']); }
    if (isset($input['content_wysiwyg'])) { $settings['content_wysiwyg'] = sanitize_text_field($input['content_wysiwyg']); }
    if (isset($input['display_button'])) { $settings['display_button'] = sanitize_text_field($input['display_button']); }
    if (isset($input['button_style'])) { $settings['button_style'] = sanitize_text_field($input['button_style']); }
    if (isset($input['button_text'])) { $settings['button_text'] = sanitize_text_field($input['button_text']); }
    if (isset($input['button_link'])) { $settings['button_link'] = $input['button_link']; }
    if (isset($input['button_icon_type'])) { $settings['button_icon_type'] = sanitize_text_field($input['button_icon_type']); }
    if (isset($input['lottieUrl'])) { $settings['lottieUrl'] = $input['lottieUrl']; }
    if (isset($input['button_icon_style'])) { $settings['button_icon_style'] = sanitize_text_field($input['button_icon_style']); }
    if (isset($input['fontawesometoggle'])) { $settings['fontawesometoggle'] = sanitize_text_field($input['fontawesometoggle']); }
    if (isset($input['button_icon'])) { $settings['button_icon'] = sanitize_text_field($input['button_icon']); }
    if (isset($input['fontawesome5toggle'])) { $settings['fontawesome5toggle'] = sanitize_text_field($input['fontawesome5toggle']); }
    if (isset($input['button_icon_5'])) { $settings['button_icon_5'] = sanitize_text_field($input['button_icon_5']); }
    if (isset($input['icon_mindtoggle'])) { $settings['icon_mindtoggle'] = sanitize_text_field($input['icon_mindtoggle']); }
    if (isset($input['button_icons_mind'])) { $settings['button_icons_mind'] = sanitize_text_field($input['button_icons_mind']); }
    if (isset($input['before_after'])) { $settings['before_after'] = sanitize_text_field($input['before_after']); }
    if (isset($input['icon_spacing'])) { $settings['icon_spacing'] = $input['icon_spacing']; }
    if (isset($input['call_to_action_text'])) { $settings['call_to_action_text'] = sanitize_text_field($input['call_to_action_text']); }
    if (isset($input['display_ribbon_pin'])) { $settings['display_ribbon_pin'] = sanitize_text_field($input['display_ribbon_pin']); }
    if (isset($input['ribbon_pin_style'])) { $settings['ribbon_pin_style'] = sanitize_text_field($input['ribbon_pin_style']); }
    if (isset($input['ribbon_pin_text'])) { $settings['ribbon_pin_text'] = sanitize_text_field($input['ribbon_pin_text']); }
    if (isset($input['svg_type'])) { $settings['svg_type'] = sanitize_text_field($input['svg_type']); }
    if (isset($input['duration'])) { $settings['duration'] = $input['duration']; }
    if (isset($input['max_width'])) { $settings['max_width'] = $input['max_width']; }
    if (isset($input['border_stroke_color'])) { $settings['border_stroke_color'] = sanitize_text_field($input['border_stroke_color']); }
    if (isset($input['icon_style'])) { $settings['icon_style'] = sanitize_text_field($input['icon_style']); }
    if (isset($input['icon_size'])) { $settings['icon_size'] = $input['icon_size']; }
    if (isset($input['icon_width'])) { $settings['icon_width'] = $input['icon_width']; }
    if (isset($input['icon_color_option'])) { $settings['icon_color_option'] = sanitize_text_field($input['icon_color_option']); }
    if (isset($input['icon_color'])) { $settings['icon_color'] = sanitize_text_field($input['icon_color']); }
    if (isset($input['icon_gradient_color1'])) { $settings['icon_gradient_color1'] = sanitize_text_field($input['icon_gradient_color1']); }
    if (isset($input['icon_gradient_color1_control'])) { $settings['icon_gradient_color1_control'] = $input['icon_gradient_color1_control']; }
    if (isset($input['icon_gradient_color2'])) { $settings['icon_gradient_color2'] = sanitize_text_field($input['icon_gradient_color2']); }
    if (isset($input['icon_gradient_color2_control'])) { $settings['icon_gradient_color2_control'] = $input['icon_gradient_color2_control']; }
    if (isset($input['icon_gradient_style'])) { $settings['icon_gradient_style'] = sanitize_text_field($input['icon_gradient_style']); }
    if (isset($input['icon_gradient_angle'])) { $settings['icon_gradient_angle'] = $input['icon_gradient_angle']; }
    if (isset($input['icon_gradient_position'])) { $settings['icon_gradient_position'] = sanitize_text_field($input['icon_gradient_position']); }
    if (isset($input['icon_fill_color'])) { $settings['icon_fill_color'] = sanitize_text_field($input['icon_fill_color']); }
    if (isset($input['icon_stroke_color'])) { $settings['icon_stroke_color'] = sanitize_text_field($input['icon_stroke_color']); }
    if (isset($input['icon_border_style'])) { $settings['icon_border_style'] = sanitize_text_field($input['icon_border_style']); }
    if (isset($input['icon_border_color'])) { $settings['icon_border_color'] = sanitize_text_field($input['icon_border_color']); }
    if (isset($input['icon_border_radius'])) { $settings['icon_border_radius'] = $input['icon_border_radius']; }
    if (isset($input['icon_border_width'])) { $settings['icon_border_width'] = $input['icon_border_width']; }
    if (isset($input['icon_hover_color_option'])) { $settings['icon_hover_color_option'] = sanitize_text_field($input['icon_hover_color_option']); }
    if (isset($input['icon_hover_color'])) { $settings['icon_hover_color'] = sanitize_text_field($input['icon_hover_color']); }
    if (isset($input['icon_hover_gradient_color1'])) { $settings['icon_hover_gradient_color1'] = sanitize_text_field($input['icon_hover_gradient_color1']); }
    if (isset($input['icon_hover_gradient_color1_control'])) { $settings['icon_hover_gradient_color1_control'] = $input['icon_hover_gradient_color1_control']; }
    if (isset($input['icon_hover_gradient_color2'])) { $settings['icon_hover_gradient_color2'] = sanitize_text_field($input['icon_hover_gradient_color2']); }
    if (isset($input['icon_hover_gradient_color2_control'])) { $settings['icon_hover_gradient_color2_control'] = $input['icon_hover_gradient_color2_control']; }
    if (isset($input['icon_hover_gradient_style'])) { $settings['icon_hover_gradient_style'] = sanitize_text_field($input['icon_hover_gradient_style']); }
    if (isset($input['icon_hover_gradient_angle'])) { $settings['icon_hover_gradient_angle'] = $input['icon_hover_gradient_angle']; }
    if (isset($input['icon_hover_gradient_position'])) { $settings['icon_hover_gradient_position'] = sanitize_text_field($input['icon_hover_gradient_position']); }
    if (isset($input['icon_fill_color_hover'])) { $settings['icon_fill_color_hover'] = sanitize_text_field($input['icon_fill_color_hover']); }
    if (isset($input['icon_stroke_color_hover'])) { $settings['icon_stroke_color_hover'] = sanitize_text_field($input['icon_stroke_color_hover']); }
    if (isset($input['icon_border_hover_color'])) { $settings['icon_border_hover_color'] = sanitize_text_field($input['icon_border_hover_color']); }
    if (isset($input['icon__hover_border_radius'])) { $settings['icon__hover_border_radius'] = $input['icon__hover_border_radius']; }
    if (isset($input['imagewidth'])) { $settings['imagewidth'] = $input['imagewidth']; }
    if (isset($input['imageHeight'])) { $settings['imageHeight'] = $input['imageHeight']; }
    if (isset($input['image_border_radius'])) { $settings['image_border_radius'] = $input['image_border_radius']; }
    if (isset($input['lottiedisplay'])) { $settings['lottiedisplay'] = sanitize_text_field($input['lottiedisplay']); }
    if (isset($input['lottieMright'])) { $settings['lottieMright'] = $input['lottieMright']; }
    if (isset($input['lottieMleft'])) { $settings['lottieMleft'] = $input['lottieMleft']; }
    if (isset($input['lottieWidth'])) { $settings['lottieWidth'] = $input['lottieWidth']; }
    if (isset($input['lottieHeight'])) { $settings['lottieHeight'] = $input['lottieHeight']; }
    if (isset($input['lottieSpeed'])) { $settings['lottieSpeed'] = $input['lottieSpeed']; }
    if (isset($input['lottieVertical'])) { $settings['lottieVertical'] = sanitize_text_field($input['lottieVertical']); }
    if (isset($input['lottieLoop'])) { $settings['lottieLoop'] = sanitize_text_field($input['lottieLoop']); }
    if (isset($input['lottiehover'])) { $settings['lottiehover'] = sanitize_text_field($input['lottiehover']); }
    if (isset($input['title_alignment'])) { $settings['title_alignment'] = $input['title_alignment']; }
    if (isset($input['title_color_option'])) { $settings['title_color_option'] = sanitize_text_field($input['title_color_option']); }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['title_gradient_color1'])) { $settings['title_gradient_color1'] = sanitize_text_field($input['title_gradient_color1']); }
    if (isset($input['title_gradient_color1_control'])) { $settings['title_gradient_color1_control'] = $input['title_gradient_color1_control']; }
    if (isset($input['title_gradient_color2'])) { $settings['title_gradient_color2'] = sanitize_text_field($input['title_gradient_color2']); }
    if (isset($input['title_gradient_color2_control'])) { $settings['title_gradient_color2_control'] = $input['title_gradient_color2_control']; }
    if (isset($input['title_gradient_style'])) { $settings['title_gradient_style'] = sanitize_text_field($input['title_gradient_style']); }
    if (isset($input['title_gradient_angle'])) { $settings['title_gradient_angle'] = $input['title_gradient_angle']; }
    if (isset($input['title_gradient_position'])) { $settings['title_gradient_position'] = sanitize_text_field($input['title_gradient_position']); }
    if (isset($input['title_hover_color_option'])) { $settings['title_hover_color_option'] = sanitize_text_field($input['title_hover_color_option']); }
    if (isset($input['title_hover_color'])) { $settings['title_hover_color'] = sanitize_text_field($input['title_hover_color']); }
    if (isset($input['title_hover_gradient_color1'])) { $settings['title_hover_gradient_color1'] = sanitize_text_field($input['title_hover_gradient_color1']); }
    if (isset($input['title_hover_gradient_color1_control'])) { $settings['title_hover_gradient_color1_control'] = $input['title_hover_gradient_color1_control']; }
    if (isset($input['title_hover_gradient_color2'])) { $settings['title_hover_gradient_color2'] = sanitize_text_field($input['title_hover_gradient_color2']); }
    if (isset($input['title_hover_gradient_color2_control'])) { $settings['title_hover_gradient_color2_control'] = $input['title_hover_gradient_color2_control']; }
    if (isset($input['title_hover_gradient_style'])) { $settings['title_hover_gradient_style'] = sanitize_text_field($input['title_hover_gradient_style']); }
    if (isset($input['title_hover_gradient_angle'])) { $settings['title_hover_gradient_angle'] = $input['title_hover_gradient_angle']; }
    if (isset($input['title_hover_gradient_position'])) { $settings['title_hover_gradient_position'] = sanitize_text_field($input['title_hover_gradient_position']); }
    if (isset($input['subtitle_alignment'])) { $settings['subtitle_alignment'] = $input['subtitle_alignment']; }
    if (isset($input['subtitle_color'])) { $settings['subtitle_color'] = sanitize_text_field($input['subtitle_color']); }
    if (isset($input['subtitle_Hover_color'])) { $settings['subtitle_Hover_color'] = sanitize_text_field($input['subtitle_Hover_color']); }
    if (isset($input['previous_price_align'])) { $settings['previous_price_align'] = sanitize_text_field($input['previous_price_align']); }
    if (isset($input['previous_price_color'])) { $settings['previous_price_color'] = sanitize_text_field($input['previous_price_color']); }
    if (isset($input['previous_price_hover_color'])) { $settings['previous_price_hover_color'] = sanitize_text_field($input['previous_price_hover_color']); }
    if (isset($input['prefix_price_color'])) { $settings['prefix_price_color'] = sanitize_text_field($input['prefix_price_color']); }
    if (isset($input['prefix_price_hover_color'])) { $settings['prefix_price_hover_color'] = sanitize_text_field($input['prefix_price_hover_color']); }
    if (isset($input['price_alignment'])) { $settings['price_alignment'] = $input['price_alignment']; }
    if (isset($input['price_color'])) { $settings['price_color'] = sanitize_text_field($input['price_color']); }
    if (isset($input['price_hover_color'])) { $settings['price_hover_color'] = sanitize_text_field($input['price_hover_color']); }
    if (isset($input['price_postfix_color'])) { $settings['price_postfix_color'] = sanitize_text_field($input['price_postfix_color']); }
    if (isset($input['price_postfix_hover_color'])) { $settings['price_postfix_hover_color'] = sanitize_text_field($input['price_postfix_hover_color']); }
    if (isset($input['content_spg'])) { $settings['content_spg'] = $input['content_spg']; }
    if (isset($input['list_icon_size'])) { $settings['list_icon_size'] = $input['list_icon_size']; }
    if (isset($input['content_border_width_color'])) { $settings['content_border_width_color'] = $input['content_border_width_color']; }
    if (isset($input['list_between_space'])) { $settings['list_between_space'] = $input['list_between_space']; }
    if (isset($input['icon_between_space'])) { $settings['icon_between_space'] = $input['icon_between_space']; }
    if (isset($input['desc_content_alignment'])) { $settings['desc_content_alignment'] = $input['desc_content_alignment']; }
    if (isset($input['listing_content_alignment'])) { $settings['listing_content_alignment'] = $input['listing_content_alignment']; }
    if (isset($input['content_text_color'])) { $settings['content_text_color'] = sanitize_text_field($input['content_text_color']); }
    if (isset($input['content_text_color_hover_active'])) { $settings['content_text_color_hover_active'] = sanitize_text_field($input['content_text_color_hover_active']); }
    if (isset($input['content_text_color_hover'])) { $settings['content_text_color_hover'] = sanitize_text_field($input['content_text_color_hover']); }
    if (isset($input['content_border_top_color'])) { $settings['content_border_top_color'] = sanitize_text_field($input['content_border_top_color']); }
    if (isset($input['list_text_color'])) { $settings['list_text_color'] = sanitize_text_field($input['list_text_color']); }
    if (isset($input['list_icon_color'])) { $settings['list_icon_color'] = sanitize_text_field($input['list_icon_color']); }
    if (isset($input['list_style_2_border_color'])) { $settings['list_style_2_border_color'] = sanitize_text_field($input['list_style_2_border_color']); }
    if (isset($input['list_text_hover_color_box'])) { $settings['list_text_hover_color_box'] = sanitize_text_field($input['list_text_hover_color_box']); }
    if (isset($input['list_icon_hover_color_box'])) { $settings['list_icon_hover_color_box'] = sanitize_text_field($input['list_icon_hover_color_box']); }
    if (isset($input['list_style2_hover_border_color_box'])) { $settings['list_style2_hover_border_color_box'] = sanitize_text_field($input['list_style2_hover_border_color_box']); }
    if (isset($input['list_text_hover_color'])) { $settings['list_text_hover_color'] = sanitize_text_field($input['list_text_hover_color']); }
    if (isset($input['list_icon_hover_color'])) { $settings['list_icon_hover_color'] = sanitize_text_field($input['list_icon_hover_color']); }
    if (isset($input['list_style2_hover_border_color'])) { $settings['list_style2_hover_border_color'] = sanitize_text_field($input['list_style2_hover_border_color']); }
    if (isset($input['toggle_expand_text_color'])) { $settings['toggle_expand_text_color'] = sanitize_text_field($input['toggle_expand_text_color']); }
    if (isset($input['toggle_expand_text_hover_color'])) { $settings['toggle_expand_text_hover_color'] = sanitize_text_field($input['toggle_expand_text_hover_color']); }
    if (isset($input['toggle_expand_border_top'])) { $settings['toggle_expand_border_top'] = sanitize_text_field($input['toggle_expand_border_top']); }
    if (isset($input['toggle_expand_border_top_color'])) { $settings['toggle_expand_border_top_color'] = sanitize_text_field($input['toggle_expand_border_top_color']); }
    if (isset($input['content_box_border'])) { $settings['content_box_border'] = sanitize_text_field($input['content_box_border']); }
    if (isset($input['content_box_border_color'])) { $settings['content_box_border_color'] = sanitize_text_field($input['content_box_border_color']); }
    if (isset($input['content_box_border_width'])) { $settings['content_box_border_width'] = $input['content_box_border_width']; }
    if (isset($input['content_border_radius'])) { $settings['content_border_radius'] = $input['content_border_radius']; }
    if (isset($input['content_box_border_hover_color'])) { $settings['content_box_border_hover_color'] = sanitize_text_field($input['content_box_border_hover_color']); }
    if (isset($input['content_border_hover_radius'])) { $settings['content_border_hover_radius'] = $input['content_border_hover_radius']; }
    if (isset($input['tt_on_icon'])) { $settings['tt_on_icon'] = sanitize_text_field($input['tt_on_icon']); }
    if (isset($input['tt_on_icon_margin_left'])) { $settings['tt_on_icon_margin_left'] = $input['tt_on_icon_margin_left']; }
    if (isset($input['tt_on_icon_size'])) { $settings['tt_on_icon_size'] = $input['tt_on_icon_size']; }
    if (isset($input['tt_on_icon_color'])) { $settings['tt_on_icon_color'] = sanitize_text_field($input['tt_on_icon_color']); }
    if (isset($input['button_padding'])) { $settings['button_padding'] = $input['button_padding']; }
    if (isset($input['button_top_space'])) { $settings['button_top_space'] = $input['button_top_space']; }
    if (isset($input['button_svg_icon'])) { $settings['button_svg_icon'] = $input['button_svg_icon']; }
    if (isset($input['button_alignment'])) { $settings['button_alignment'] = $input['button_alignment']; }
    if (isset($input['button_top_bottom'])) { $settings['button_top_bottom'] = sanitize_text_field($input['button_top_bottom']); }
    if (isset($input['btn_text_color'])) { $settings['btn_text_color'] = sanitize_text_field($input['btn_text_color']); }
    if (isset($input['btn_svg_icon_color'])) { $settings['btn_svg_icon_color'] = sanitize_text_field($input['btn_svg_icon_color']); }
    if (isset($input['button_border_style'])) { $settings['button_border_style'] = sanitize_text_field($input['button_border_style']); }
    if (isset($input['button_border_width'])) { $settings['button_border_width'] = $input['button_border_width']; }
    if (isset($input['button_border_color'])) { $settings['button_border_color'] = sanitize_text_field($input['button_border_color']); }
    if (isset($input['button_radius'])) { $settings['button_radius'] = $input['button_radius']; }
    if (isset($input['btn_text_box_hover_color'])) { $settings['btn_text_box_hover_color'] = sanitize_text_field($input['btn_text_box_hover_color']); }
    if (isset($input['btn_svg_icon_color_box_h'])) { $settings['btn_svg_icon_color_box_h'] = sanitize_text_field($input['btn_svg_icon_color_box_h']); }
    if (isset($input['btn_border_box_hover_color'])) { $settings['btn_border_box_hover_color'] = sanitize_text_field($input['btn_border_box_hover_color']); }
    if (isset($input['box_hover_btn_radius'])) { $settings['box_hover_btn_radius'] = $input['box_hover_btn_radius']; }
    if (isset($input['btn_text_hover_color'])) { $settings['btn_text_hover_color'] = sanitize_text_field($input['btn_text_hover_color']); }
    if (isset($input['btn_svg_icon_color_h'])) { $settings['btn_svg_icon_color_h'] = sanitize_text_field($input['btn_svg_icon_color_h']); }
    if (isset($input['button_border_hover_color'])) { $settings['button_border_hover_color'] = sanitize_text_field($input['button_border_hover_color']); }
    if (isset($input['button_hover_radius'])) { $settings['button_hover_radius'] = $input['button_hover_radius']; }
    if (isset($input['cta_text_color'])) { $settings['cta_text_color'] = sanitize_text_field($input['cta_text_color']); }
    if (isset($input['ribbon_text_color'])) { $settings['ribbon_text_color'] = sanitize_text_field($input['ribbon_text_color']); }
    if (isset($input['ribbon_radius'])) { $settings['ribbon_radius'] = $input['ribbon_radius']; }
    if (isset($input['ribbon_bg_style_3'])) { $settings['ribbon_bg_style_3'] = sanitize_text_field($input['ribbon_bg_style_3']); }
    if (isset($input['ribbon_pin_width'])) { $settings['ribbon_pin_width'] = $input['ribbon_pin_width']; }
    if (isset($input['ribbon_pin_adjust'])) { $settings['ribbon_pin_adjust'] = $input['ribbon_pin_adjust']; }
    if (isset($input['bg_padding'])) { $settings['bg_padding'] = $input['bg_padding']; }
    if (isset($input['bg_margin'])) { $settings['bg_margin'] = $input['bg_margin']; }
    if (isset($input['box_border'])) { $settings['box_border'] = sanitize_text_field($input['box_border']); }
    if (isset($input['box_border_color'])) { $settings['box_border_color'] = sanitize_text_field($input['box_border_color']); }
    if (isset($input['box_border_width'])) { $settings['box_border_width'] = $input['box_border_width']; }
    if (isset($input['border_radius'])) { $settings['border_radius'] = $input['border_radius']; }
    if (isset($input['box_border_hover_color'])) { $settings['box_border_hover_color'] = sanitize_text_field($input['box_border_hover_color']); }
    if (isset($input['border_hover_radius'])) { $settings['border_hover_radius'] = $input['border_hover_radius']; }
    if (isset($input['bg_hover_animation'])) { $settings['bg_hover_animation'] = sanitize_text_field($input['bg_hover_animation']); }
    if (isset($input['box_overlay_bg_color'])) { $settings['box_overlay_bg_color'] = sanitize_text_field($input['box_overlay_bg_color']); }
    if (isset($input['box_hover_overlay_bg_color'])) { $settings['box_hover_overlay_bg_color'] = sanitize_text_field($input['box_hover_overlay_bg_color']); }
    if (isset($input['transform_scale'])) { $settings['transform_scale'] = $input['transform_scale']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
