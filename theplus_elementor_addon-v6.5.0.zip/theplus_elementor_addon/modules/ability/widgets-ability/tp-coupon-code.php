<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-coupon-code', [
'label' => __('Coupon Code', 'theplus'),
    'description' => __('Adds The Plus "Coupon Code" widget (tp-coupon-code) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'       => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'     => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'      => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'couponType' => ['type' => 'string', 'description' => 'Coupon Type', 'enum' => ['columns', 'peel', 'scratch', 'slideOut', 'standard']],
        'standardStyle' => ['type' => 'string', 'description' => 'Standard Style', 'enum' => ['columns', 'couponType', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5']],
        'standardCntAlign' => ['type' => 'object', 'description' => 'Content Alignment'],
        'standardAlign' => ['type' => 'object', 'description' => 'Box Alignment', 'enum' => ['center', 'couponType', 'icon', 'left', 'right', '{{WRAPPER}} .tp-coupon-code,{{WRAPPER}} .tp-coupon-code .coupon-code-outer']],
        'couponText' => ['type' => 'string', 'description' => 'Title'],
        'redirectLink' => ['type' => 'object', 'description' => 'redirectLink'],
        'copyCodeStyle' => ['type' => 'string', 'description' => 'Copy Code Style', 'enum' => ['couponType', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5']],
        'couponCode' => ['type' => 'string', 'description' => 'Code'],
        'actionType' => ['type' => 'string', 'description' => 'Select Action', 'enum' => ['click', 'couponType', 'popup']],
        'hideLink' => ['type' => 'string', 'description' => 'Hide Link', 'enum' => ['yes', 'no']],
        'hideLinkMaskText' => ['type' => 'string', 'description' => 'Link Masking Text'],
        'LinkMaskLabel' => ['type' => 'string', 'description' => 'Label'],
        'LinkMaskLink' => ['type' => 'object', 'description' => 'Link'],
        'LinkMaskList' => ['type' => 'string', 'description' => 'Open URLs : Single/Multiple'],
        'tabReverse' => ['type' => 'string', 'description' => 'Tab Reverse', 'enum' => ['yes', 'no']],
        'tabReverse_Note' => ['type' => 'string', 'description' => 'tabReverse_Note'],
        'copLoop' => ['type' => 'string', 'description' => 'Loop', 'enum' => ['yes', 'no']],
        'popupBgImage' => ['type' => 'integer', 'description' => 'Popup Background Image (Image ID)'],
        'popupTitle' => ['type' => 'string', 'description' => 'Title'],
        'popupDesc' => ['type' => 'string', 'description' => 'Description'],
        'copyBtnText' => ['type' => 'string', 'description' => 'Copy Button'],
        'afterCopyText' => ['type' => 'string', 'description' => 'After Copy'],
        'visitBtnText' => ['type' => 'string', 'description' => 'Visit Button'],
        'modelClsIcon' => ['type' => 'string', 'description' => 'Close Icon'],
        'standardCdAlign' => ['type' => 'object', 'description' => 'Code Alignment', 'enum' => ['actionType', 'center', 'couponType', 'icon', 'left', 'right', '{{WRAPPER}} .tp-coupon-code .coupon-code-outer']],
        'scratchWidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'scratchHeight' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'fillPercent' => ['type' => 'object', 'description' => 'Fill Percent For Reveal (Slider/Size Object)'],
        'slideDirection' => ['type' => 'string', 'description' => 'Slide Out Direction', 'enum' => ['bottom', 'couponType', 'left', 'right', 'top']],
        'slideDirectionhint' => ['type' => 'string', 'description' => 'Direction Hint Icon', 'enum' => ['yes', 'no']],
        'frontContentType' => ['type' => 'string', 'description' => 'Content Type', 'enum' => ['couponType!', 'template']],
        'frontContent' => ['type' => 'string', 'description' => 'Content'],
        'frontContentTag' => ['type' => 'string', 'description' => 'Content Tag', 'enum' => ['couponType!', 'frontContentType']],
        'frontTemp' => ['type' => 'string', 'description' => 'Template', 'enum' => ['couponType!', 'frontContentType']],
        'backContentType' => ['type' => 'string', 'description' => 'Content Type', 'enum' => ['couponType!', 'template']],
        'backTitle' => ['type' => 'string', 'description' => 'Title'],
        'backTitleTag' => ['type' => 'string', 'description' => 'Title Tag', 'enum' => ['backContentType', 'couponType!']],
        'backDesc' => ['type' => 'string', 'description' => 'Description'],
        'backTemp' => ['type' => 'string', 'description' => 'Template', 'enum' => ['backContentType', 'couponType!']],
        'ccd_popup_width' => ['type' => 'object', 'description' => 'Popup Width (Slider/Size Object)'],
        'CdScrollOn' => ['type' => 'string', 'description' => 'On Scroll', 'enum' => ['yes', 'no']],
        'CdScrollHgt' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'buttonPadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'buttonWidth' => ['type' => 'object', 'description' => 'Width (%) (Slider/Size Object)'],
        'ArWBdrColor' => ['type' => 'string', 'description' => 'Arrow Color (Color Hex/RGBA)'],
        'buttonNColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'btns2BdrNmlClr' => ['type' => 'string', 'description' => 'Border Left Color (Color Hex/RGBA)'],
        'btnScratchNColor' => ['type' => 'string', 'description' => 'Border Bottom Color (Color Hex/RGBA)'],
        'btnNmlBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'buttonHColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'btns2BdrHvrClr' => ['type' => 'string', 'description' => 'Border Left Color (Color Hex/RGBA)'],
        'btnScratchHColor' => ['type' => 'string', 'description' => 'Border Bottom Color (Color Hex/RGBA)'],
        'btnHvrBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'btnIconWidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'btnIconSize' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'btnIconNColor' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'btnIconNmlBdrad' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'btnIconHColor' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'btnIconHvrBdrad' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'cCodePadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'cCodebuttonWidth' => ['type' => 'object', 'description' => 'Width (%) (Slider/Size Object)'],
        'CodeArwBdrColor' => ['type' => 'string', 'description' => 'Arrow Color (Color Hex/RGBA)'],
        'cCodeNColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'cCodeNmlBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'cCodeHColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'cCodeHvrBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'cIconPadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'cIconMargin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'cIconWidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'cIconSize' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'cIconNColor' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'cIconNmlBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'cIconHColor' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'cIconHvrBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'TtldescPadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'TtldescMargin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'titlePadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'titleNColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'titleNmlBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'titleHColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'titleHvrBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'descPadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'descAbvSpace' => ['type' => 'object', 'description' => 'Above Space (Slider/Size Object)'],
        'descNColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'descNmlBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'descHColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'descHvrBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'TtlDescAlign' => ['type' => 'string', 'description' => 'Title/Desc Alignment', 'enum' => ['actionType', 'center', 'couponType', 'flex-end', 'flex-start', 'icon', 'toggle', '{{WRAPPER}} .tp-coupon-code .popup-content']],
        'CpTxtPadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'CpTxtMargin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'PopcCodebuttonWidth' => ['type' => 'object', 'description' => 'Width (%) (Slider/Size Object)'],
        'PopArwBdrColor' => ['type' => 'string', 'description' => 'Arrow Color (Color Hex/RGBA)'],
        'PopcCodeNColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'PopcCodeNmlBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'PopcCodeHColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'PopcCodeHvrBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'copyBtnPadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'copyBtnMargin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'copyBtnNColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'copyBtnNBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'copyBtnHColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'copyBtnHBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'VstBtnPadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'VstBtnMargin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'visitBtnNColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'visitBtnNBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'visitBtnHColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'visitBtnHBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'VstBtnAlign' => ['type' => 'string', 'description' => 'Alignment', 'enum' => ['actionType', 'center', 'couponType', 'flex-end', 'flex-start', 'icon', 'toggle', '{{WRAPPER}} .tp-coupon-code .popup-code-modal .coupon-store-visit']],
        'CCdScrollWidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'CCdThumbBrs' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'CCdTrackBRs' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'StndModalPadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'StndModalMargin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'StndModalBRadiusNml' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'StndModalBRadiusHvr' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'mbbf' => ['type' => 'string', 'description' => 'Backdrop Filter', 'enum' => ['yes', 'no']],
        'mbbf_blur' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'mbbf_grayscale' => ['type' => 'object', 'description' => 'Grayscale (Slider/Size Object)'],
        'frontTtlclr' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'frontBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'slidehinticoncolor' => ['type' => 'string', 'description' => 'HInt Icon Color (Color Hex/RGBA)'],
        'backTtlclr' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'backDescclr' => ['type' => 'string', 'description' => 'Description Color (Color Hex/RGBA)'],
        'backBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'boxcontentBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'CCd_overlay_color' => ['type' => 'string', 'description' => 'Overlay Color (Color Hex/RGBA)'],
        'olcbf' => ['type' => 'string', 'description' => 'Overlay Backdrop Filter', 'enum' => ['yes', 'no']],
        'olcbf_blur' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'olcbf_grayscale' => ['type' => 'object', 'description' => 'Grayscale (Slider/Size Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings.']
    ], 'required' => ['post_id', 'parent_id', 'couponCode'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_coupon_code_ability',
    'permission_callback' => 'tpaep_mcp_theplus_coupon_code_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_coupon_code_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_coupon_code_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-coupon-code';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Coupon Code widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['couponType'])) { $settings['couponType'] = sanitize_text_field($input['couponType']); }
    if (isset($input['standardStyle'])) { $settings['standardStyle'] = sanitize_text_field($input['standardStyle']); }
    if (isset($input['standardCntAlign'])) { $settings['standardCntAlign'] = $input['standardCntAlign']; }
    if (isset($input['standardAlign'])) { $settings['standardAlign'] = $input['standardAlign']; }
    if (isset($input['couponText'])) { $settings['couponText'] = sanitize_text_field($input['couponText']); }
    if (isset($input['redirectLink'])) { $settings['redirectLink'] = $input['redirectLink']; }
    if (isset($input['copyCodeStyle'])) { $settings['copyCodeStyle'] = sanitize_text_field($input['copyCodeStyle']); }
    if (isset($input['couponCode'])) { $settings['couponCode'] = sanitize_text_field($input['couponCode']); }
    if (isset($input['actionType'])) { $settings['actionType'] = sanitize_text_field($input['actionType']); }
    if (isset($input['hideLink'])) { $settings['hideLink'] = sanitize_text_field($input['hideLink']); }
    if (isset($input['hideLinkMaskText'])) { $settings['hideLinkMaskText'] = sanitize_text_field($input['hideLinkMaskText']); }
    if (isset($input['LinkMaskLabel'])) { $settings['LinkMaskLabel'] = sanitize_text_field($input['LinkMaskLabel']); }
    if (isset($input['LinkMaskLink'])) { $settings['LinkMaskLink'] = $input['LinkMaskLink']; }
    if (isset($input['LinkMaskList'])) { $settings['LinkMaskList'] = sanitize_text_field($input['LinkMaskList']); }
    if (isset($input['tabReverse'])) { $settings['tabReverse'] = sanitize_text_field($input['tabReverse']); }
    if (isset($input['tabReverse_Note'])) { $settings['tabReverse_Note'] = sanitize_text_field($input['tabReverse_Note']); }
    if (isset($input['copLoop'])) { $settings['copLoop'] = sanitize_text_field($input['copLoop']); }
    if (!empty($input['popupBgImage'])) { $settings['popupBgImage'] = ['id' => absint($input['popupBgImage'])]; }
    if (isset($input['popupTitle'])) { $settings['popupTitle'] = sanitize_text_field($input['popupTitle']); }
    if (isset($input['popupDesc'])) { $settings['popupDesc'] = sanitize_text_field($input['popupDesc']); }
    if (isset($input['copyBtnText'])) { $settings['copyBtnText'] = sanitize_text_field($input['copyBtnText']); }
    if (isset($input['afterCopyText'])) { $settings['afterCopyText'] = sanitize_text_field($input['afterCopyText']); }
    if (isset($input['visitBtnText'])) { $settings['visitBtnText'] = sanitize_text_field($input['visitBtnText']); }
    if (isset($input['modelClsIcon'])) { $settings['modelClsIcon'] = sanitize_text_field($input['modelClsIcon']); }
    if (isset($input['standardCdAlign'])) { $settings['standardCdAlign'] = $input['standardCdAlign']; }
    if (isset($input['scratchWidth'])) { $settings['scratchWidth'] = $input['scratchWidth']; }
    if (isset($input['scratchHeight'])) { $settings['scratchHeight'] = $input['scratchHeight']; }
    if (isset($input['fillPercent'])) { $settings['fillPercent'] = $input['fillPercent']; }
    if (isset($input['slideDirection'])) { $settings['slideDirection'] = sanitize_text_field($input['slideDirection']); }
    if (isset($input['slideDirectionhint'])) { $settings['slideDirectionhint'] = sanitize_text_field($input['slideDirectionhint']); }
    if (isset($input['frontContentType'])) { $settings['frontContentType'] = sanitize_text_field($input['frontContentType']); }
    if (isset($input['frontContent'])) { $settings['frontContent'] = sanitize_text_field($input['frontContent']); }
    if (isset($input['frontContentTag'])) { $settings['frontContentTag'] = sanitize_text_field($input['frontContentTag']); }
    if (isset($input['frontTemp'])) { $settings['frontTemp'] = sanitize_text_field($input['frontTemp']); }
    if (isset($input['backContentType'])) { $settings['backContentType'] = sanitize_text_field($input['backContentType']); }
    if (isset($input['backTitle'])) { $settings['backTitle'] = sanitize_text_field($input['backTitle']); }
    if (isset($input['backTitleTag'])) { $settings['backTitleTag'] = sanitize_text_field($input['backTitleTag']); }
    if (isset($input['backDesc'])) { $settings['backDesc'] = sanitize_text_field($input['backDesc']); }
    if (isset($input['backTemp'])) { $settings['backTemp'] = sanitize_text_field($input['backTemp']); }
    if (isset($input['ccd_popup_width'])) { $settings['ccd_popup_width'] = $input['ccd_popup_width']; }
    if (isset($input['CdScrollOn'])) { $settings['CdScrollOn'] = sanitize_text_field($input['CdScrollOn']); }
    if (isset($input['CdScrollHgt'])) { $settings['CdScrollHgt'] = $input['CdScrollHgt']; }
    if (isset($input['buttonPadding'])) { $settings['buttonPadding'] = $input['buttonPadding']; }
    if (isset($input['buttonWidth'])) { $settings['buttonWidth'] = $input['buttonWidth']; }
    if (isset($input['ArWBdrColor'])) { $settings['ArWBdrColor'] = sanitize_text_field($input['ArWBdrColor']); }
    if (isset($input['buttonNColor'])) { $settings['buttonNColor'] = sanitize_text_field($input['buttonNColor']); }
    if (isset($input['btns2BdrNmlClr'])) { $settings['btns2BdrNmlClr'] = sanitize_text_field($input['btns2BdrNmlClr']); }
    if (isset($input['btnScratchNColor'])) { $settings['btnScratchNColor'] = sanitize_text_field($input['btnScratchNColor']); }
    if (isset($input['btnNmlBRadius'])) { $settings['btnNmlBRadius'] = $input['btnNmlBRadius']; }
    if (isset($input['buttonHColor'])) { $settings['buttonHColor'] = sanitize_text_field($input['buttonHColor']); }
    if (isset($input['btns2BdrHvrClr'])) { $settings['btns2BdrHvrClr'] = sanitize_text_field($input['btns2BdrHvrClr']); }
    if (isset($input['btnScratchHColor'])) { $settings['btnScratchHColor'] = sanitize_text_field($input['btnScratchHColor']); }
    if (isset($input['btnHvrBRadius'])) { $settings['btnHvrBRadius'] = $input['btnHvrBRadius']; }
    if (isset($input['btnIconWidth'])) { $settings['btnIconWidth'] = $input['btnIconWidth']; }
    if (isset($input['btnIconSize'])) { $settings['btnIconSize'] = $input['btnIconSize']; }
    if (isset($input['btnIconNColor'])) { $settings['btnIconNColor'] = sanitize_text_field($input['btnIconNColor']); }
    if (isset($input['btnIconNmlBdrad'])) { $settings['btnIconNmlBdrad'] = $input['btnIconNmlBdrad']; }
    if (isset($input['btnIconHColor'])) { $settings['btnIconHColor'] = sanitize_text_field($input['btnIconHColor']); }
    if (isset($input['btnIconHvrBdrad'])) { $settings['btnIconHvrBdrad'] = $input['btnIconHvrBdrad']; }
    if (isset($input['cCodePadding'])) { $settings['cCodePadding'] = $input['cCodePadding']; }
    if (isset($input['cCodebuttonWidth'])) { $settings['cCodebuttonWidth'] = $input['cCodebuttonWidth']; }
    if (isset($input['CodeArwBdrColor'])) { $settings['CodeArwBdrColor'] = sanitize_text_field($input['CodeArwBdrColor']); }
    if (isset($input['cCodeNColor'])) { $settings['cCodeNColor'] = sanitize_text_field($input['cCodeNColor']); }
    if (isset($input['cCodeNmlBRadius'])) { $settings['cCodeNmlBRadius'] = $input['cCodeNmlBRadius']; }
    if (isset($input['cCodeHColor'])) { $settings['cCodeHColor'] = sanitize_text_field($input['cCodeHColor']); }
    if (isset($input['cCodeHvrBRadius'])) { $settings['cCodeHvrBRadius'] = $input['cCodeHvrBRadius']; }
    if (isset($input['cIconPadding'])) { $settings['cIconPadding'] = $input['cIconPadding']; }
    if (isset($input['cIconMargin'])) { $settings['cIconMargin'] = $input['cIconMargin']; }
    if (isset($input['cIconWidth'])) { $settings['cIconWidth'] = $input['cIconWidth']; }
    if (isset($input['cIconSize'])) { $settings['cIconSize'] = $input['cIconSize']; }
    if (isset($input['cIconNColor'])) { $settings['cIconNColor'] = sanitize_text_field($input['cIconNColor']); }
    if (isset($input['cIconNmlBRadius'])) { $settings['cIconNmlBRadius'] = $input['cIconNmlBRadius']; }
    if (isset($input['cIconHColor'])) { $settings['cIconHColor'] = sanitize_text_field($input['cIconHColor']); }
    if (isset($input['cIconHvrBRadius'])) { $settings['cIconHvrBRadius'] = $input['cIconHvrBRadius']; }
    if (isset($input['TtldescPadding'])) { $settings['TtldescPadding'] = $input['TtldescPadding']; }
    if (isset($input['TtldescMargin'])) { $settings['TtldescMargin'] = $input['TtldescMargin']; }
    if (isset($input['titlePadding'])) { $settings['titlePadding'] = $input['titlePadding']; }
    if (isset($input['titleNColor'])) { $settings['titleNColor'] = sanitize_text_field($input['titleNColor']); }
    if (isset($input['titleNmlBRadius'])) { $settings['titleNmlBRadius'] = $input['titleNmlBRadius']; }
    if (isset($input['titleHColor'])) { $settings['titleHColor'] = sanitize_text_field($input['titleHColor']); }
    if (isset($input['titleHvrBRadius'])) { $settings['titleHvrBRadius'] = $input['titleHvrBRadius']; }
    if (isset($input['descPadding'])) { $settings['descPadding'] = $input['descPadding']; }
    if (isset($input['descAbvSpace'])) { $settings['descAbvSpace'] = $input['descAbvSpace']; }
    if (isset($input['descNColor'])) { $settings['descNColor'] = sanitize_text_field($input['descNColor']); }
    if (isset($input['descNmlBRadius'])) { $settings['descNmlBRadius'] = $input['descNmlBRadius']; }
    if (isset($input['descHColor'])) { $settings['descHColor'] = sanitize_text_field($input['descHColor']); }
    if (isset($input['descHvrBRadius'])) { $settings['descHvrBRadius'] = $input['descHvrBRadius']; }
    if (isset($input['TtlDescAlign'])) { $settings['TtlDescAlign'] = sanitize_text_field($input['TtlDescAlign']); }
    if (isset($input['CpTxtPadding'])) { $settings['CpTxtPadding'] = $input['CpTxtPadding']; }
    if (isset($input['CpTxtMargin'])) { $settings['CpTxtMargin'] = $input['CpTxtMargin']; }
    if (isset($input['PopcCodebuttonWidth'])) { $settings['PopcCodebuttonWidth'] = $input['PopcCodebuttonWidth']; }
    if (isset($input['PopArwBdrColor'])) { $settings['PopArwBdrColor'] = sanitize_text_field($input['PopArwBdrColor']); }
    if (isset($input['PopcCodeNColor'])) { $settings['PopcCodeNColor'] = sanitize_text_field($input['PopcCodeNColor']); }
    if (isset($input['PopcCodeNmlBRadius'])) { $settings['PopcCodeNmlBRadius'] = $input['PopcCodeNmlBRadius']; }
    if (isset($input['PopcCodeHColor'])) { $settings['PopcCodeHColor'] = sanitize_text_field($input['PopcCodeHColor']); }
    if (isset($input['PopcCodeHvrBRadius'])) { $settings['PopcCodeHvrBRadius'] = $input['PopcCodeHvrBRadius']; }
    if (isset($input['copyBtnPadding'])) { $settings['copyBtnPadding'] = $input['copyBtnPadding']; }
    if (isset($input['copyBtnMargin'])) { $settings['copyBtnMargin'] = $input['copyBtnMargin']; }
    if (isset($input['copyBtnNColor'])) { $settings['copyBtnNColor'] = sanitize_text_field($input['copyBtnNColor']); }
    if (isset($input['copyBtnNBRadius'])) { $settings['copyBtnNBRadius'] = $input['copyBtnNBRadius']; }
    if (isset($input['copyBtnHColor'])) { $settings['copyBtnHColor'] = sanitize_text_field($input['copyBtnHColor']); }
    if (isset($input['copyBtnHBRadius'])) { $settings['copyBtnHBRadius'] = $input['copyBtnHBRadius']; }
    if (isset($input['VstBtnPadding'])) { $settings['VstBtnPadding'] = $input['VstBtnPadding']; }
    if (isset($input['VstBtnMargin'])) { $settings['VstBtnMargin'] = $input['VstBtnMargin']; }
    if (isset($input['visitBtnNColor'])) { $settings['visitBtnNColor'] = sanitize_text_field($input['visitBtnNColor']); }
    if (isset($input['visitBtnNBRadius'])) { $settings['visitBtnNBRadius'] = $input['visitBtnNBRadius']; }
    if (isset($input['visitBtnHColor'])) { $settings['visitBtnHColor'] = sanitize_text_field($input['visitBtnHColor']); }
    if (isset($input['visitBtnHBRadius'])) { $settings['visitBtnHBRadius'] = $input['visitBtnHBRadius']; }
    if (isset($input['VstBtnAlign'])) { $settings['VstBtnAlign'] = sanitize_text_field($input['VstBtnAlign']); }
    if (isset($input['CCdScrollWidth'])) { $settings['CCdScrollWidth'] = $input['CCdScrollWidth']; }
    if (isset($input['CCdThumbBrs'])) { $settings['CCdThumbBrs'] = $input['CCdThumbBrs']; }
    if (isset($input['CCdTrackBRs'])) { $settings['CCdTrackBRs'] = $input['CCdTrackBRs']; }
    if (isset($input['StndModalPadding'])) { $settings['StndModalPadding'] = $input['StndModalPadding']; }
    if (isset($input['StndModalMargin'])) { $settings['StndModalMargin'] = $input['StndModalMargin']; }
    if (isset($input['StndModalBRadiusNml'])) { $settings['StndModalBRadiusNml'] = $input['StndModalBRadiusNml']; }
    if (isset($input['StndModalBRadiusHvr'])) { $settings['StndModalBRadiusHvr'] = $input['StndModalBRadiusHvr']; }
    if (isset($input['mbbf'])) { $settings['mbbf'] = sanitize_text_field($input['mbbf']); }
    if (isset($input['mbbf_blur'])) { $settings['mbbf_blur'] = $input['mbbf_blur']; }
    if (isset($input['mbbf_grayscale'])) { $settings['mbbf_grayscale'] = $input['mbbf_grayscale']; }
    if (isset($input['frontTtlclr'])) { $settings['frontTtlclr'] = sanitize_text_field($input['frontTtlclr']); }
    if (isset($input['frontBRadius'])) { $settings['frontBRadius'] = $input['frontBRadius']; }
    if (isset($input['slidehinticoncolor'])) { $settings['slidehinticoncolor'] = sanitize_text_field($input['slidehinticoncolor']); }
    if (isset($input['backTtlclr'])) { $settings['backTtlclr'] = sanitize_text_field($input['backTtlclr']); }
    if (isset($input['backDescclr'])) { $settings['backDescclr'] = sanitize_text_field($input['backDescclr']); }
    if (isset($input['backBRadius'])) { $settings['backBRadius'] = $input['backBRadius']; }
    if (isset($input['boxcontentBRadius'])) { $settings['boxcontentBRadius'] = $input['boxcontentBRadius']; }
    if (isset($input['CCd_overlay_color'])) { $settings['CCd_overlay_color'] = sanitize_text_field($input['CCd_overlay_color']); }
    if (isset($input['olcbf'])) { $settings['olcbf'] = sanitize_text_field($input['olcbf']); }
    if (isset($input['olcbf_blur'])) { $settings['olcbf_blur'] = $input['olcbf_blur']; }
    if (isset($input['olcbf_grayscale'])) { $settings['olcbf_grayscale'] = $input['olcbf_grayscale']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
