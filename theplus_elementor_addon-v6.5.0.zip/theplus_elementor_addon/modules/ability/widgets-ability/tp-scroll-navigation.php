<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-scroll-navigation', [
'label' => __('Scroll Navigation', 'theplus'),
    'description' => __('Adds The Plus "Scroll Navigation" widget (tp-scroll-navigation) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'scroll_navigation_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5']],
        'scroll_navigation_direction' => ['type' => 'string', 'description' => 'Direction', 'enum' => ['bottom', 'bottom_left', 'bottom_right', 'left', 'right', 'scroll_navigation_style', 'top', 'top_left', 'top_right']],
        'scroll_navigation_direction_st4' => ['type' => 'string', 'description' => 'Direction', 'enum' => ['left', 'right', 'scroll_navigation_style']],
        'scroll_navigation_direction_inner' => ['type' => 'string', 'description' => 'Position', 'enum' => ['p_center', 'p_left', 'p_right', 'scroll_navigation_direction', 'scroll_navigation_style!']],
        'scroll_navigation_display_counter' => ['type' => 'string', 'description' => 'Display Counter', 'enum' => ['yes', 'no']],
        'scroll_navigation_display_counter_style' => ['type' => 'string', 'description' => 'Counter Style', 'enum' => ['decimal-leading-zero', 'lower-alpha', 'lower-greek', 'lower-roman', 'number-normal', 'scroll_navigation_display_counter', 'scroll_navigation_style', 'upper-alpha', 'upper-roman']],
        'scroll_navigation_tooltip_display_style' => ['type' => 'string', 'description' => 'Tooltip Display Style', 'enum' => ['on-active-section', 'on-default', 'on-hover']],
        'scroll_navigation_popover' => ['type' => 'string', 'description' => 'Navigation Position', 'enum' => ['yes', 'no']],
        'navigation_left' => ['type' => 'object', 'description' => 'Left (Slider/Size Object)'],
        'navigation_right' => ['type' => 'object', 'description' => 'Right (Slider/Size Object)'],
        'navigation_top' => ['type' => 'object', 'description' => 'Top (Slider/Size Object)'],
        'navigation_bottom' => ['type' => 'object', 'description' => 'Bottom (Slider/Size Object)'],
        'scroll_navigation_section_id' => ['type' => 'string', 'description' => 'Section ID'],
        'display_tool_tip' => ['type' => 'string', 'description' => 'Tooltip', 'enum' => ['yes', 'no']],
        'tooltip_menu_title' => ['type' => 'string', 'description' => 'Tooltip Title'],
        'display_tool_tip_icon' => ['type' => 'string', 'description' => 'Icon', 'enum' => ['yes', 'no']],
        'loop_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['display_tool_tip_icon', 'font_awesome', 'font_awesome_5', 'icon_mind']],
        'icon_fs_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome', 'enum' => ['yes', 'no']],
        'loop_icon_fontawesome' => ['type' => 'string', 'description' => 'Icon Library'],
        'icon_mind_popover_toggle' => ['type' => 'string', 'description' => 'Icons Mind', 'enum' => ['yes', 'no']],
        'loop_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['display_tool_tip_icon', 'loop_icon_style']],
        'icon_f5_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome 5', 'enum' => ['yes', 'no']],
        'icon_fontawesome_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'scroll_navigation_menu_list' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Scroll Navigation List'],
        'pagescroll_connection' => ['type' => 'string', 'description' => 'Page Scroll Connection', 'enum' => ['yes', 'no']],
        'pagescroll_type' => ['type' => 'string', 'description' => 'Page Scroll Type', 'enum' => ['fullpage', 'multiscroll', 'pagepiling', 'pagescroll_connection']],
        'pagescroll_connect_id' => ['type' => 'string', 'description' => 'Page Scroll Connect ID'],
        'navigation_icon_height_width' => ['type' => 'object', 'description' => 'Icon Height/Width (Slider/Size Object)'],
        'navigation_icon_font_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'navigation_icon_spacing_top_bottom__margin' => ['type' => 'object', 'description' => 'Icon Spacing (Slider/Size Object)'],
        'navigation_icon_spacing_left_right_st24__margin' => ['type' => 'object', 'description' => 'Icon Spacing (Slider/Size Object)'],
        'navigation_icon_spacing_other_all_margin' => ['type' => 'object', 'description' => 'Icon Spacing (Slider/Size Object)'],
        'scroll_navigation_icon_color_normal' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'navigation_icon_width' => ['type' => 'object', 'description' => 'Icon Width (Slider/Size Object)'],
        'navigation_icon_height' => ['type' => 'object', 'description' => 'Icon Height (Slider/Size Object)'],
        'scroll_navigation_icon_color_hover' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'navigation_icon_width_hover' => ['type' => 'object', 'description' => 'Hover Icon Width (Slider/Size Object)'],
        'scroll_nav_icon_background_style' => ['type' => 'string', 'description' => 'Navigation Background', 'enum' => ['yes', 'no']],
        'navigation_icon_inner_padding' => ['type' => 'object', 'description' => 'Navigation Inner Padding (Slider/Size Object)'],
        'navigation_icon_inner_padding_st5' => ['type' => 'object', 'description' => 'Navigation Inner Padding (Slider/Size Object)'],
        'scroll_nav_icon_background_border_radious_normal' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'scroll_nav_icon_background_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'scroll_nav_icon_background_border_radious_hover' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'navigation_tooltip_iconsize' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'navigation_tooltip_height' => ['type' => 'object', 'description' => 'Tooltip Height (Slider/Size Object)'],
        'navigation_tooltip_margin' => ['type' => 'object', 'description' => 'Navigation Tooltip Margin (Dimensions Object)'],
        'navigation_tooltip_padding' => ['type' => 'object', 'description' => 'Navigation Tooltip Padding (Dimensions Object)'],
        'scroll_navigation_tooltip_align' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'devices', 'icon', 'left', 'prefix_class', 'right']],
        'navigation_tooltip_font_color_normal' => ['type' => 'string', 'description' => 'Font Color Normal (Color Hex/RGBA)'],
        'navigation_tooltip_font_color_hover' => ['type' => 'string', 'description' => 'Font Color Hover (Color Hex/RGBA)'],
        'navigation_tooltip_background_color' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'scroll_nav_tooltip_arrow' => ['type' => 'string', 'description' => 'Tooltip Arrow', 'enum' => ['yes', 'no']],
        'scroll_nav_tooltip_border_radious' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'navigation_dispaly_counter_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'navigation_dispaly_counter_size' => ['type' => 'object', 'description' => 'Counter Size (Slider/Size Object)'],
        'navigation_dispaly_counter_color_normal' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'navigation_icon_padding' => ['type' => 'object', 'description' => 'Whole Navigation Offset (Dimensions Object)'],
        'scroll_nav_background_padding' => ['type' => 'object', 'description' => 'Whole Navigation Inner Padding (Dimensions Object)'],
        'scroll_nav_background_style' => ['type' => 'string', 'description' => 'Background', 'enum' => ['yes', 'no']],
        'scroll_nav_background_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'scroll_nav_background_border_radious' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'show_scroll_window_offset' => ['type' => 'string', 'description' => 'Show Menu Scroll Offset', 'enum' => ['yes', 'no']],
        'scroll_top_offset_value' => ['type' => 'object', 'description' => 'Scroll Top Offset Value (Slider/Size Object)'],
        'scroll_top_offset' => ['type' => 'object', 'description' => 'Section Top Offset (Slider/Size Object)'],
        'disable_scroll_navigation' => ['type' => 'object', 'description' => 'Hide Scroll Navigation (Slider/Size Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports dot-navigation tooltips, SVG custom bullets, and responsive offset logic.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_pro_scroll_navigation_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pro_scroll_navigation_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_pro_scroll_navigation_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_pro_scroll_navigation_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-scroll-navigation';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Scroll Navigation widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['scroll_navigation_style'])) { $settings['scroll_navigation_style'] = sanitize_text_field($input['scroll_navigation_style']); }
    if (isset($input['scroll_navigation_direction'])) { $settings['scroll_navigation_direction'] = sanitize_text_field($input['scroll_navigation_direction']); }
    if (isset($input['scroll_navigation_direction_st4'])) { $settings['scroll_navigation_direction_st4'] = sanitize_text_field($input['scroll_navigation_direction_st4']); }
    if (isset($input['scroll_navigation_direction_inner'])) { $settings['scroll_navigation_direction_inner'] = sanitize_text_field($input['scroll_navigation_direction_inner']); }
    if (isset($input['scroll_navigation_display_counter'])) { $settings['scroll_navigation_display_counter'] = sanitize_text_field($input['scroll_navigation_display_counter']); }
    if (isset($input['scroll_navigation_display_counter_style'])) { $settings['scroll_navigation_display_counter_style'] = sanitize_text_field($input['scroll_navigation_display_counter_style']); }
    if (isset($input['scroll_navigation_tooltip_display_style'])) { $settings['scroll_navigation_tooltip_display_style'] = sanitize_text_field($input['scroll_navigation_tooltip_display_style']); }
    if (isset($input['scroll_navigation_popover'])) { $settings['scroll_navigation_popover'] = sanitize_text_field($input['scroll_navigation_popover']); }
    if (isset($input['navigation_left'])) { $settings['navigation_left'] = $input['navigation_left']; }
    if (isset($input['navigation_right'])) { $settings['navigation_right'] = $input['navigation_right']; }
    if (isset($input['navigation_top'])) { $settings['navigation_top'] = $input['navigation_top']; }
    if (isset($input['navigation_bottom'])) { $settings['navigation_bottom'] = $input['navigation_bottom']; }
    if (isset($input['scroll_navigation_section_id'])) { $settings['scroll_navigation_section_id'] = sanitize_text_field($input['scroll_navigation_section_id']); }
    if (isset($input['display_tool_tip'])) { $settings['display_tool_tip'] = sanitize_text_field($input['display_tool_tip']); }
    if (isset($input['tooltip_menu_title'])) { $settings['tooltip_menu_title'] = sanitize_text_field($input['tooltip_menu_title']); }
    if (isset($input['display_tool_tip_icon'])) { $settings['display_tool_tip_icon'] = sanitize_text_field($input['display_tool_tip_icon']); }
    if (isset($input['loop_icon_style'])) { $settings['loop_icon_style'] = sanitize_text_field($input['loop_icon_style']); }
    if (isset($input['icon_fs_popover_toggle'])) { $settings['icon_fs_popover_toggle'] = sanitize_text_field($input['icon_fs_popover_toggle']); }
    if (isset($input['loop_icon_fontawesome'])) { $settings['loop_icon_fontawesome'] = sanitize_text_field($input['loop_icon_fontawesome']); }
    if (isset($input['icon_mind_popover_toggle'])) { $settings['icon_mind_popover_toggle'] = sanitize_text_field($input['icon_mind_popover_toggle']); }
    if (isset($input['loop_icons_mind'])) { $settings['loop_icons_mind'] = sanitize_text_field($input['loop_icons_mind']); }
    if (isset($input['icon_f5_popover_toggle'])) { $settings['icon_f5_popover_toggle'] = sanitize_text_field($input['icon_f5_popover_toggle']); }
    if (isset($input['icon_fontawesome_5'])) { $settings['icon_fontawesome_5'] = sanitize_text_field($input['icon_fontawesome_5']); }
    if (isset($input['scroll_navigation_menu_list'])) { $settings['scroll_navigation_menu_list'] = $input['scroll_navigation_menu_list']; }
    if (isset($input['pagescroll_connection'])) { $settings['pagescroll_connection'] = sanitize_text_field($input['pagescroll_connection']); }
    if (isset($input['pagescroll_type'])) { $settings['pagescroll_type'] = sanitize_text_field($input['pagescroll_type']); }
    if (isset($input['pagescroll_connect_id'])) { $settings['pagescroll_connect_id'] = sanitize_text_field($input['pagescroll_connect_id']); }
    if (isset($input['navigation_icon_height_width'])) { $settings['navigation_icon_height_width'] = $input['navigation_icon_height_width']; }
    if (isset($input['navigation_icon_font_size'])) { $settings['navigation_icon_font_size'] = $input['navigation_icon_font_size']; }
    if (isset($input['navigation_icon_spacing_top_bottom__margin'])) { $settings['navigation_icon_spacing_top_bottom__margin'] = $input['navigation_icon_spacing_top_bottom__margin']; }
    if (isset($input['navigation_icon_spacing_left_right_st24__margin'])) { $settings['navigation_icon_spacing_left_right_st24__margin'] = $input['navigation_icon_spacing_left_right_st24__margin']; }
    if (isset($input['navigation_icon_spacing_other_all_margin'])) { $settings['navigation_icon_spacing_other_all_margin'] = $input['navigation_icon_spacing_other_all_margin']; }
    if (isset($input['scroll_navigation_icon_color_normal'])) { $settings['scroll_navigation_icon_color_normal'] = sanitize_text_field($input['scroll_navigation_icon_color_normal']); }
    if (isset($input['navigation_icon_width'])) { $settings['navigation_icon_width'] = $input['navigation_icon_width']; }
    if (isset($input['navigation_icon_height'])) { $settings['navigation_icon_height'] = $input['navigation_icon_height']; }
    if (isset($input['scroll_navigation_icon_color_hover'])) { $settings['scroll_navigation_icon_color_hover'] = sanitize_text_field($input['scroll_navigation_icon_color_hover']); }
    if (isset($input['navigation_icon_width_hover'])) { $settings['navigation_icon_width_hover'] = $input['navigation_icon_width_hover']; }
    if (isset($input['scroll_nav_icon_background_style'])) { $settings['scroll_nav_icon_background_style'] = sanitize_text_field($input['scroll_nav_icon_background_style']); }
    if (isset($input['navigation_icon_inner_padding'])) { $settings['navigation_icon_inner_padding'] = $input['navigation_icon_inner_padding']; }
    if (isset($input['navigation_icon_inner_padding_st5'])) { $settings['navigation_icon_inner_padding_st5'] = $input['navigation_icon_inner_padding_st5']; }
    if (isset($input['scroll_nav_icon_background_border_radious_normal'])) { $settings['scroll_nav_icon_background_border_radious_normal'] = $input['scroll_nav_icon_background_border_radious_normal']; }
    if (isset($input['scroll_nav_icon_background_border_hover_color'])) { $settings['scroll_nav_icon_background_border_hover_color'] = sanitize_text_field($input['scroll_nav_icon_background_border_hover_color']); }
    if (isset($input['scroll_nav_icon_background_border_radious_hover'])) { $settings['scroll_nav_icon_background_border_radious_hover'] = $input['scroll_nav_icon_background_border_radious_hover']; }
    if (isset($input['navigation_tooltip_iconsize'])) { $settings['navigation_tooltip_iconsize'] = $input['navigation_tooltip_iconsize']; }
    if (isset($input['navigation_tooltip_height'])) { $settings['navigation_tooltip_height'] = $input['navigation_tooltip_height']; }
    if (isset($input['navigation_tooltip_margin'])) { $settings['navigation_tooltip_margin'] = $input['navigation_tooltip_margin']; }
    if (isset($input['navigation_tooltip_padding'])) { $settings['navigation_tooltip_padding'] = $input['navigation_tooltip_padding']; }
    if (isset($input['scroll_navigation_tooltip_align'])) { $settings['scroll_navigation_tooltip_align'] = $input['scroll_navigation_tooltip_align']; }
    if (isset($input['navigation_tooltip_font_color_normal'])) { $settings['navigation_tooltip_font_color_normal'] = sanitize_text_field($input['navigation_tooltip_font_color_normal']); }
    if (isset($input['navigation_tooltip_font_color_hover'])) { $settings['navigation_tooltip_font_color_hover'] = sanitize_text_field($input['navigation_tooltip_font_color_hover']); }
    if (isset($input['navigation_tooltip_background_color'])) { $settings['navigation_tooltip_background_color'] = sanitize_text_field($input['navigation_tooltip_background_color']); }
    if (isset($input['scroll_nav_tooltip_arrow'])) { $settings['scroll_nav_tooltip_arrow'] = sanitize_text_field($input['scroll_nav_tooltip_arrow']); }
    if (isset($input['scroll_nav_tooltip_border_radious'])) { $settings['scroll_nav_tooltip_border_radious'] = $input['scroll_nav_tooltip_border_radious']; }
    if (isset($input['navigation_dispaly_counter_margin'])) { $settings['navigation_dispaly_counter_margin'] = $input['navigation_dispaly_counter_margin']; }
    if (isset($input['navigation_dispaly_counter_size'])) { $settings['navigation_dispaly_counter_size'] = $input['navigation_dispaly_counter_size']; }
    if (isset($input['navigation_dispaly_counter_color_normal'])) { $settings['navigation_dispaly_counter_color_normal'] = sanitize_text_field($input['navigation_dispaly_counter_color_normal']); }
    if (isset($input['navigation_icon_padding'])) { $settings['navigation_icon_padding'] = $input['navigation_icon_padding']; }
    if (isset($input['scroll_nav_background_padding'])) { $settings['scroll_nav_background_padding'] = $input['scroll_nav_background_padding']; }
    if (isset($input['scroll_nav_background_style'])) { $settings['scroll_nav_background_style'] = sanitize_text_field($input['scroll_nav_background_style']); }
    if (isset($input['scroll_nav_background_border'])) { $settings['scroll_nav_background_border'] = sanitize_text_field($input['scroll_nav_background_border']); }
    if (isset($input['scroll_nav_background_border_radious'])) { $settings['scroll_nav_background_border_radious'] = $input['scroll_nav_background_border_radious']; }
    if (isset($input['show_scroll_window_offset'])) { $settings['show_scroll_window_offset'] = sanitize_text_field($input['show_scroll_window_offset']); }
    if (isset($input['scroll_top_offset_value'])) { $settings['scroll_top_offset_value'] = $input['scroll_top_offset_value']; }
    if (isset($input['scroll_top_offset'])) { $settings['scroll_top_offset'] = $input['scroll_top_offset']; }
    if (isset($input['disable_scroll_navigation'])) { $settings['disable_scroll_navigation'] = $input['disable_scroll_navigation']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
