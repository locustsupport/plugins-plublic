<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-gallery-listout', [
'label' => __('Gallery Listout (Pro)', 'theplus'),
    'description' => __('Adds The Plus "Gallery Listout" widget (tp-gallery-listout) to an Elementor container. Pro version with metro and carousel layouts.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'       => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'     => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'      => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'style-1', 'style-2', 'style-3', 'style-4']],
        'layout' => ['type' => 'string', 'description' => 'Layout', 'enum' => ['carousel', 'columns', 'grid', 'masonry', 'metro']],
        'popup_style' => ['type' => 'string', 'description' => 'Popup Layout', 'enum' => ['no']],
        'gallery_options' => ['type' => 'string', 'description' => 'Select Option', 'enum' => ['acf_gallery', 'normal', 'repeater']],
        'acf_gallery_field_name' => ['type' => 'string', 'description' => 'Gallery Field Name'],
        'gallery_images' => ['type' => 'string', 'description' => 'Add Images'],
        'loop_image' => ['type' => 'integer', 'description' => 'Choose Image (Image ID)'],
        'loop_title' => ['type' => 'string', 'description' => 'Title'],
        'loop_content_caption' => ['type' => 'string', 'description' => 'Caption'],
        'loop_category' => ['type' => 'string', 'description' => 'Category'],
        'loop_image_icon' => ['type' => 'string', 'description' => 'Select Icon', 'enum' => ['icon']],
        'loop_select_image' => ['type' => 'integer', 'description' => 'Use Image As icon (Image ID)'],
        'loop_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['font_awesome', 'font_awesome_5', 'icon_mind', 'loop_image_icon']],
        'loop_icon_fontawesome' => ['type' => 'string', 'description' => 'Icon Library'],
        'loop_icon_fontawesome_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'loop_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['loop_icon_style', 'loop_image_icon']],
        'style_4_link' => ['type' => 'object', 'description' => 'style_4_link'],
        'loop_gallery' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'loop_gallery'],
        'desktop_column' => ['type' => 'string', 'description' => 'Desktop Column', 'enum' => ['layout!']],
        'tablet_column' => ['type' => 'string', 'description' => 'Tablet Column', 'enum' => ['layout!']],
        'mobile_column' => ['type' => 'string', 'description' => 'Mobile Column', 'enum' => ['layout!']],
        'metro_column' => ['type' => 'string', 'description' => 'Metro Column', 'enum' => ['3', '4', '5', '6', 'layout']],
        'metro_style_3' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_3' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_4' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_4' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_5' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_5' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_6' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_6' => ['type' => 'string', 'description' => 'Custom Layout'],
        'responsive_tablet_metro' => ['type' => 'string', 'description' => 'Tablet Responsive', 'enum' => ['yes', 'no']],
        'tablet_metro_column' => ['type' => 'string', 'description' => 'Metro Column', 'enum' => ['3', '4', '5', '6', 'layout', 'responsive_tablet_metro']],
        'tablet_metro_style_3' => ['type' => 'string', 'description' => 'Tablet Metro Style', 'enum' => ['layout', 'responsive_tablet_metro', 'tablet_metro_column']],
        'metro_custom_col_tab' => ['type' => 'string', 'description' => 'Custom Layout'],
        'columns_gap' => ['type' => 'object', 'description' => 'Columns Gap/Space Between (Dimensions Object)'],
        'display_title' => ['type' => 'string', 'description' => 'Display Title', 'enum' => ['yes', 'no']],
        'post_title_tag' => ['type' => 'string', 'description' => 'Title Tag', 'enum' => ['display_title']],
        'display_thumbnail' => ['type' => 'string', 'description' => 'Display Image Size', 'enum' => ['yes', 'no']],
        'featured_image_type' => ['type' => 'string', 'description' => 'Featured Image Type', 'enum' => ['custom', 'full', 'grid', 'layout']],
        'display_excerpt' => ['type' => 'string', 'description' => 'Display Excerpt/Content', 'enum' => ['yes', 'no']],
        'display_box_link' => ['type' => 'string', 'description' => 'display_box_link', 'enum' => ['yes', 'no']],
        'force_custom_url' => ['type' => 'string', 'description' => 'Force Custom URL', 'enum' => ['yes', 'no']],
        'display_button' => ['type' => 'string', 'description' => 'Display Button', 'enum' => ['yes', 'no']],
        'style_4_button_text' => ['type' => 'string', 'description' => 'Button Text'],
        'style_4_btn_color' => ['type' => 'string', 'description' => 'Button Color (Color Hex/RGBA)'],
        'filter_category' => ['type' => 'string', 'description' => 'Category Wise Filter', 'enum' => ['yes', 'no']],
        'all_filter_category' => ['type' => 'string', 'description' => 'All Filter Category Text'],
        'filter_style' => ['type' => 'string', 'description' => 'Category Filter Style', 'enum' => ['filter_category', 'gallery_options', 'layout!']],
        'filter_hover_style' => ['type' => 'string', 'description' => 'Filter Hover Style', 'enum' => ['filter_category', 'gallery_options', 'layout!']],
        'filter_category_align' => ['type' => 'string', 'description' => 'Filter Alignment', 'enum' => ['center', 'filter_category', 'gallery_options', 'icon', 'layout!', 'left', 'right', 'toggle']],
        'display_icon_zoom' => ['type' => 'string', 'description' => 'Display Icon', 'enum' => ['yes', 'no']],
        'loop_image_icon' => ['type' => 'string', 'description' => 'Select Icon', 'enum' => ['display_icon_zoom', 'icon']],
        'loop_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['display_icon_zoom', 'font_awesome', 'font_awesome_5', 'icon_mind', 'loop_image_icon']],
        'loop_icon_fontawesome' => ['type' => 'string', 'description' => 'Icon Library'],
        'loop_icon_fontawesome_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'loop_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['display_icon_zoom', 'loop_icon_style', 'loop_image_icon']],
        'custom_icon_image' => ['type' => 'integer', 'description' => 'Custom Icon (Image ID)'],
        'icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'icon_bottom_space' => ['type' => 'object', 'description' => 'Bottom Space (Slider/Size Object)'],
        'icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'icon_hover_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'repeat_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'repeat_icon_top_space' => ['type' => 'object', 'description' => 'Top Space (Slider/Size Object)'],
        'repeat_icon_bottom_space' => ['type' => 'object', 'description' => 'Bottom Space (Slider/Size Object)'],
        'repeat_icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'repeat_icon_hover_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'title_top_space' => ['type' => 'object', 'description' => 'Top Space (Slider/Size Object)'],
        'title_bottom_space' => ['type' => 'object', 'description' => 'Bottom Space (Slider/Size Object)'],
        'title_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'title_hover_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'content_top_space' => ['type' => 'object', 'description' => 'Top Space (Slider/Size Object)'],
        'content_bottom_space' => ['type' => 'object', 'description' => 'Bottom Space (Slider/Size Object)'],
        'excerpt_color' => ['type' => 'string', 'description' => 'Content Color (Color Hex/RGBA)'],
        'excerpt_hover_color' => ['type' => 'string', 'description' => 'Content Color (Color Hex/RGBA)'],
        'hover_image_style' => ['type' => 'string', 'description' => 'Image Hover Effect'],
        'image_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'style_4_effect_color' => ['type' => 'string', 'description' => 'Effect Color (Color Hex/RGBA)'],
        'effect_adjust' => ['type' => 'object', 'description' => 'Effects Adjust (Slider/Size Object)'],
        'hover_image_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'filter_category_padding' => ['type' => 'object', 'description' => 'Inner Padding (Dimensions Object)'],
        'filter_category_marign' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'filters_text_color' => ['type' => 'string', 'description' => 'Filters Text Color (Color Hex/RGBA)'],
        'filter_category_color' => ['type' => 'string', 'description' => 'Category Filter Color (Color Hex/RGBA)'],
        'filter_category_4_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'filter_category_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'filter_category_hover_color' => ['type' => 'string', 'description' => 'Category Filter Color (Color Hex/RGBA)'],
        'filter_category_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'filter_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'category_count_color' => ['type' => 'string', 'description' => 'Category Count Color (Color Hex/RGBA)'],
        'category_count_bg_color' => ['type' => 'string', 'description' => 'Count Background Color (Color Hex/RGBA)'],
        'box_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['box_border', '{{WRAPPER}} .gallery-list .post-inner-loop .grid-item .gallery-list-content']],
        'box_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'box_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'box_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'carousel_unique_id' => ['type' => 'string', 'description' => 'Unique Carousel ID'],
        'slider_direction' => ['type' => 'string', 'description' => 'Slider Mode', 'enum' => ['horizontal', 'vertical']],
        'carousel_direction' => ['type' => 'string', 'description' => 'Slide Direction', 'enum' => ['ltr', 'rtl']],
        'slide_speed' => ['type' => 'object', 'description' => 'Slide Speed (Slider/Size Object)'],
        'default_active_slide' => ['type' => 'object', 'description' => 'Active Slide (Slider/Size Object)'],
        'slide_fade_inout' => ['type' => 'string', 'description' => 'Slide Animation', 'enum' => ['fadeinout', 'none', 'slider_direction']],
        'slider_animation' => ['type' => 'string', 'description' => 'Animation Type', 'enum' => ['ease', 'linear']],
        'slider_desktop_column' => ['type' => 'string', 'description' => 'Desktop Columns'],
        'steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_padding' => ['type' => 'object', 'description' => 'Slide Padding (Dimensions Object)'],
        'slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'multi_drag' => ['type' => 'string', 'description' => 'Multi Drag', 'enum' => ['yes', 'no']],
        'slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'slider_pause_hover' => ['type' => 'string', 'description' => 'Pause On Hover', 'enum' => ['yes', 'no']],
        'slider_adaptive_height' => ['type' => 'string', 'description' => 'Adaptive Height', 'enum' => ['yes', 'no']],
        'slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['slider_dots', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['slider_arrows', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'slider_arrows', 'slider_arrows_style', 'top-right']],
        'arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'slider_center_mode' => ['type' => 'string', 'description' => 'slider_center_mode', 'enum' => ['yes', 'no']],
        'center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'slider_center_effects' => ['type' => 'string', 'description' => 'Center Slide Effects', 'enum' => ['slider_center_mode']],
        'scale_center_slide' => ['type' => 'object', 'description' => 'Center Slide Scale (Slider/Size Object)'],
        'scale_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Scale (Slider/Size Object)'],
        'opacity_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Opacity (Slider/Size Object)'],
        'slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3']],
        'slide_row_top_space' => ['type' => 'object', 'description' => 'Row Top Space (Slider/Size Object)'],
        'slider_tablet_column' => ['type' => 'string', 'description' => 'Tablet Columns'],
        'tablet_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_tablet' => ['type' => 'string', 'description' => 'Responsive Tablet', 'enum' => ['yes', 'no']],
        'tablet_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'tablet_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'tablet_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'tablet_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'tablet_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['slider_responsive_tablet', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7', 'tablet_slider_dots']],
        'tablet_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'tablet_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'tablet_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'tablet_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'tablet_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'tablet_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['slider_responsive_tablet', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'tablet_slider_arrows']],
        'tablet_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'slider_responsive_tablet', 'tablet_slider_arrows', 'tablet_slider_arrows_style', 'top-right']],
        'tablet_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'tablet_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'tablet_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'tablet_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'tablet_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'tablet_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'tablet_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3', 'slider_responsive_tablet']],
        'tablet_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'tablet_center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'slider_mobile_column' => ['type' => 'string', 'description' => 'Mobile Columns'],
        'mobile_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_mobile' => ['type' => 'string', 'description' => 'Responsive Mobile', 'enum' => ['yes', 'no']],
        'mobile_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'mobile_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'mobile_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'mobile_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'mobile_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['mobile_slider_dots', 'slider_responsive_mobile', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'mobile_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'mobile_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'mobile_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'mobile_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'mobile_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'mobile_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['mobile_slider_arrows', 'slider_responsive_mobile', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'mobile_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'mobile_slider_arrows', 'mobile_slider_arrows_style', 'slider_responsive_mobile', 'top-right']],
        'mobile_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'mobile_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'mobile_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'mobile_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'mobile_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'mobile_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'mobile_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3', 'slider_responsive_mobile']],
        'mobile_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'mobile_center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'pnf_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'pnf_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'pnf_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'plus_tilt_parallax' => ['type' => 'string', 'description' => 'Tilt 3D Parallax', 'enum' => ['yes', 'no']],
        'plus_mouse_move_parallax' => ['type' => 'string', 'description' => 'Mouse Move Parallax', 'enum' => ['yes', 'no']],
        'messy_column' => ['type' => 'string', 'description' => 'Messy Columns', 'enum' => ['yes', 'no']],
        'desktop_column_1' => ['type' => 'object', 'description' => 'Column 1 (Slider/Size Object)'],
        'desktop_column_2' => ['type' => 'object', 'description' => 'Column 2 (Slider/Size Object)'],
        'desktop_column_3' => ['type' => 'object', 'description' => 'Column 3 (Slider/Size Object)'],
        'desktop_column_4' => ['type' => 'object', 'description' => 'Column 4 (Slider/Size Object)'],
        'desktop_column_5' => ['type' => 'object', 'description' => 'Column 5 (Slider/Size Object)'],
        'desktop_column_6' => ['type' => 'object', 'description' => 'Column 6 (Slider/Size Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports Group Controls and advanced hover styles.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_pro_gallery_listout_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pro_gallery_listout_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_pro_gallery_listout_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_pro_gallery_listout_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-gallery-listout';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Gallery Listout widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['style'])) { $settings['style'] = sanitize_text_field($input['style']); }
    if (isset($input['layout'])) { $settings['layout'] = sanitize_text_field($input['layout']); }
    if (isset($input['popup_style'])) { $settings['popup_style'] = sanitize_text_field($input['popup_style']); }
    if (isset($input['gallery_options'])) { $settings['gallery_options'] = sanitize_text_field($input['gallery_options']); }
    if (isset($input['acf_gallery_field_name'])) { $settings['acf_gallery_field_name'] = sanitize_text_field($input['acf_gallery_field_name']); }
    if (isset($input['gallery_images'])) { $settings['gallery_images'] = sanitize_text_field($input['gallery_images']); }
    if (!empty($input['loop_image'])) { $settings['loop_image'] = ['id' => absint($input['loop_image'])]; }
    if (isset($input['loop_title'])) { $settings['loop_title'] = sanitize_text_field($input['loop_title']); }
    if (isset($input['loop_content_caption'])) { $settings['loop_content_caption'] = sanitize_text_field($input['loop_content_caption']); }
    if (isset($input['loop_category'])) { $settings['loop_category'] = sanitize_text_field($input['loop_category']); }
    if (isset($input['loop_image_icon'])) { $settings['loop_image_icon'] = sanitize_text_field($input['loop_image_icon']); }
    if (!empty($input['loop_select_image'])) { $settings['loop_select_image'] = ['id' => absint($input['loop_select_image'])]; }
    if (isset($input['loop_icon_style'])) { $settings['loop_icon_style'] = sanitize_text_field($input['loop_icon_style']); }
    if (isset($input['loop_icon_fontawesome'])) { $settings['loop_icon_fontawesome'] = sanitize_text_field($input['loop_icon_fontawesome']); }
    if (isset($input['loop_icon_fontawesome_5'])) { $settings['loop_icon_fontawesome_5'] = sanitize_text_field($input['loop_icon_fontawesome_5']); }
    if (isset($input['loop_icons_mind'])) { $settings['loop_icons_mind'] = sanitize_text_field($input['loop_icons_mind']); }
    if (isset($input['style_4_link'])) { $settings['style_4_link'] = $input['style_4_link']; }
    if (isset($input['loop_gallery'])) { $settings['loop_gallery'] = $input['loop_gallery']; }
    if (isset($input['desktop_column'])) { $settings['desktop_column'] = sanitize_text_field($input['desktop_column']); }
    if (isset($input['tablet_column'])) { $settings['tablet_column'] = sanitize_text_field($input['tablet_column']); }
    if (isset($input['mobile_column'])) { $settings['mobile_column'] = sanitize_text_field($input['mobile_column']); }
    if (isset($input['metro_column'])) { $settings['metro_column'] = sanitize_text_field($input['metro_column']); }
    if (isset($input['metro_style_3'])) { $settings['metro_style_3'] = sanitize_text_field($input['metro_style_3']); }
    if (isset($input['metro_custom_col_3'])) { $settings['metro_custom_col_3'] = sanitize_text_field($input['metro_custom_col_3']); }
    if (isset($input['metro_style_4'])) { $settings['metro_style_4'] = sanitize_text_field($input['metro_style_4']); }
    if (isset($input['metro_custom_col_4'])) { $settings['metro_custom_col_4'] = sanitize_text_field($input['metro_custom_col_4']); }
    if (isset($input['metro_style_5'])) { $settings['metro_style_5'] = sanitize_text_field($input['metro_style_5']); }
    if (isset($input['metro_custom_col_5'])) { $settings['metro_custom_col_5'] = sanitize_text_field($input['metro_custom_col_5']); }
    if (isset($input['metro_style_6'])) { $settings['metro_style_6'] = sanitize_text_field($input['metro_style_6']); }
    if (isset($input['metro_custom_col_6'])) { $settings['metro_custom_col_6'] = sanitize_text_field($input['metro_custom_col_6']); }
    if (isset($input['responsive_tablet_metro'])) { $settings['responsive_tablet_metro'] = sanitize_text_field($input['responsive_tablet_metro']); }
    if (isset($input['tablet_metro_column'])) { $settings['tablet_metro_column'] = sanitize_text_field($input['tablet_metro_column']); }
    if (isset($input['tablet_metro_style_3'])) { $settings['tablet_metro_style_3'] = sanitize_text_field($input['tablet_metro_style_3']); }
    if (isset($input['metro_custom_col_tab'])) { $settings['metro_custom_col_tab'] = sanitize_text_field($input['metro_custom_col_tab']); }
    if (isset($input['columns_gap'])) { $settings['columns_gap'] = $input['columns_gap']; }
    if (isset($input['display_title'])) { $settings['display_title'] = sanitize_text_field($input['display_title']); }
    if (isset($input['post_title_tag'])) { $settings['post_title_tag'] = sanitize_text_field($input['post_title_tag']); }
    if (isset($input['display_thumbnail'])) { $settings['display_thumbnail'] = sanitize_text_field($input['display_thumbnail']); }
    if (isset($input['featured_image_type'])) { $settings['featured_image_type'] = sanitize_text_field($input['featured_image_type']); }
    if (isset($input['display_excerpt'])) { $settings['display_excerpt'] = sanitize_text_field($input['display_excerpt']); }
    if (isset($input['display_box_link'])) { $settings['display_box_link'] = sanitize_text_field($input['display_box_link']); }
    if (isset($input['force_custom_url'])) { $settings['force_custom_url'] = sanitize_text_field($input['force_custom_url']); }
    if (isset($input['display_button'])) { $settings['display_button'] = sanitize_text_field($input['display_button']); }
    if (isset($input['style_4_button_text'])) { $settings['style_4_button_text'] = sanitize_text_field($input['style_4_button_text']); }
    if (isset($input['style_4_btn_color'])) { $settings['style_4_btn_color'] = sanitize_text_field($input['style_4_btn_color']); }
    if (isset($input['filter_category'])) { $settings['filter_category'] = sanitize_text_field($input['filter_category']); }
    if (isset($input['all_filter_category'])) { $settings['all_filter_category'] = sanitize_text_field($input['all_filter_category']); }
    if (isset($input['filter_style'])) { $settings['filter_style'] = sanitize_text_field($input['filter_style']); }
    if (isset($input['filter_hover_style'])) { $settings['filter_hover_style'] = sanitize_text_field($input['filter_hover_style']); }
    if (isset($input['filter_category_align'])) { $settings['filter_category_align'] = sanitize_text_field($input['filter_category_align']); }
    if (isset($input['display_icon_zoom'])) { $settings['display_icon_zoom'] = sanitize_text_field($input['display_icon_zoom']); }
    if (isset($input['loop_image_icon'])) { $settings['loop_image_icon'] = sanitize_text_field($input['loop_image_icon']); }
    if (isset($input['loop_icon_style'])) { $settings['loop_icon_style'] = sanitize_text_field($input['loop_icon_style']); }
    if (isset($input['loop_icon_fontawesome'])) { $settings['loop_icon_fontawesome'] = sanitize_text_field($input['loop_icon_fontawesome']); }
    if (isset($input['loop_icon_fontawesome_5'])) { $settings['loop_icon_fontawesome_5'] = sanitize_text_field($input['loop_icon_fontawesome_5']); }
    if (isset($input['loop_icons_mind'])) { $settings['loop_icons_mind'] = sanitize_text_field($input['loop_icons_mind']); }
    if (!empty($input['custom_icon_image'])) { $settings['custom_icon_image'] = ['id' => absint($input['custom_icon_image'])]; }
    if (isset($input['icon_size'])) { $settings['icon_size'] = $input['icon_size']; }
    if (isset($input['icon_bottom_space'])) { $settings['icon_bottom_space'] = $input['icon_bottom_space']; }
    if (isset($input['icon_color'])) { $settings['icon_color'] = sanitize_text_field($input['icon_color']); }
    if (isset($input['icon_hover_color'])) { $settings['icon_hover_color'] = sanitize_text_field($input['icon_hover_color']); }
    if (isset($input['repeat_icon_size'])) { $settings['repeat_icon_size'] = $input['repeat_icon_size']; }
    if (isset($input['repeat_icon_top_space'])) { $settings['repeat_icon_top_space'] = $input['repeat_icon_top_space']; }
    if (isset($input['repeat_icon_bottom_space'])) { $settings['repeat_icon_bottom_space'] = $input['repeat_icon_bottom_space']; }
    if (isset($input['repeat_icon_color'])) { $settings['repeat_icon_color'] = sanitize_text_field($input['repeat_icon_color']); }
    if (isset($input['repeat_icon_hover_color'])) { $settings['repeat_icon_hover_color'] = sanitize_text_field($input['repeat_icon_hover_color']); }
    if (isset($input['title_top_space'])) { $settings['title_top_space'] = $input['title_top_space']; }
    if (isset($input['title_bottom_space'])) { $settings['title_bottom_space'] = $input['title_bottom_space']; }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['title_hover_color'])) { $settings['title_hover_color'] = sanitize_text_field($input['title_hover_color']); }
    if (isset($input['content_top_space'])) { $settings['content_top_space'] = $input['content_top_space']; }
    if (isset($input['content_bottom_space'])) { $settings['content_bottom_space'] = $input['content_bottom_space']; }
    if (isset($input['excerpt_color'])) { $settings['excerpt_color'] = sanitize_text_field($input['excerpt_color']); }
    if (isset($input['excerpt_hover_color'])) { $settings['excerpt_hover_color'] = sanitize_text_field($input['excerpt_hover_color']); }
    if (isset($input['hover_image_style'])) { $settings['hover_image_style'] = sanitize_text_field($input['hover_image_style']); }
    if (isset($input['image_border_radius'])) { $settings['image_border_radius'] = $input['image_border_radius']; }
    if (isset($input['style_4_effect_color'])) { $settings['style_4_effect_color'] = sanitize_text_field($input['style_4_effect_color']); }
    if (isset($input['effect_adjust'])) { $settings['effect_adjust'] = $input['effect_adjust']; }
    if (isset($input['hover_image_border_radius'])) { $settings['hover_image_border_radius'] = $input['hover_image_border_radius']; }
    if (isset($input['filter_category_padding'])) { $settings['filter_category_padding'] = $input['filter_category_padding']; }
    if (isset($input['filter_category_marign'])) { $settings['filter_category_marign'] = $input['filter_category_marign']; }
    if (isset($input['filters_text_color'])) { $settings['filters_text_color'] = sanitize_text_field($input['filters_text_color']); }
    if (isset($input['filter_category_color'])) { $settings['filter_category_color'] = sanitize_text_field($input['filter_category_color']); }
    if (isset($input['filter_category_4_border_color'])) { $settings['filter_category_4_border_color'] = sanitize_text_field($input['filter_category_4_border_color']); }
    if (isset($input['filter_category_radius'])) { $settings['filter_category_radius'] = $input['filter_category_radius']; }
    if (isset($input['filter_category_hover_color'])) { $settings['filter_category_hover_color'] = sanitize_text_field($input['filter_category_hover_color']); }
    if (isset($input['filter_category_hover_radius'])) { $settings['filter_category_hover_radius'] = $input['filter_category_hover_radius']; }
    if (isset($input['filter_border_hover_color'])) { $settings['filter_border_hover_color'] = sanitize_text_field($input['filter_border_hover_color']); }
    if (isset($input['category_count_color'])) { $settings['category_count_color'] = sanitize_text_field($input['category_count_color']); }
    if (isset($input['category_count_bg_color'])) { $settings['category_count_bg_color'] = sanitize_text_field($input['category_count_bg_color']); }
    if (isset($input['box_border'])) { $settings['box_border'] = sanitize_text_field($input['box_border']); }
    if (isset($input['border_style'])) { $settings['border_style'] = sanitize_text_field($input['border_style']); }
    if (isset($input['box_border_width'])) { $settings['box_border_width'] = $input['box_border_width']; }
    if (isset($input['box_border_color'])) { $settings['box_border_color'] = sanitize_text_field($input['box_border_color']); }
    if (isset($input['border_radius'])) { $settings['border_radius'] = $input['border_radius']; }
    if (isset($input['box_border_hover_color'])) { $settings['box_border_hover_color'] = sanitize_text_field($input['box_border_hover_color']); }
    if (isset($input['border_hover_radius'])) { $settings['border_hover_radius'] = $input['border_hover_radius']; }
    if (isset($input['carousel_unique_id'])) { $settings['carousel_unique_id'] = sanitize_text_field($input['carousel_unique_id']); }
    if (isset($input['slider_direction'])) { $settings['slider_direction'] = sanitize_text_field($input['slider_direction']); }
    if (isset($input['carousel_direction'])) { $settings['carousel_direction'] = sanitize_text_field($input['carousel_direction']); }
    if (isset($input['slide_speed'])) { $settings['slide_speed'] = $input['slide_speed']; }
    if (isset($input['default_active_slide'])) { $settings['default_active_slide'] = $input['default_active_slide']; }
    if (isset($input['slide_fade_inout'])) { $settings['slide_fade_inout'] = sanitize_text_field($input['slide_fade_inout']); }
    if (isset($input['slider_animation'])) { $settings['slider_animation'] = sanitize_text_field($input['slider_animation']); }
    if (isset($input['slider_desktop_column'])) { $settings['slider_desktop_column'] = sanitize_text_field($input['slider_desktop_column']); }
    if (isset($input['steps_slide'])) { $settings['steps_slide'] = sanitize_text_field($input['steps_slide']); }
    if (isset($input['slider_padding'])) { $settings['slider_padding'] = $input['slider_padding']; }
    if (isset($input['slider_draggable'])) { $settings['slider_draggable'] = sanitize_text_field($input['slider_draggable']); }
    if (isset($input['multi_drag'])) { $settings['multi_drag'] = sanitize_text_field($input['multi_drag']); }
    if (isset($input['slider_infinite'])) { $settings['slider_infinite'] = sanitize_text_field($input['slider_infinite']); }
    if (isset($input['slider_pause_hover'])) { $settings['slider_pause_hover'] = sanitize_text_field($input['slider_pause_hover']); }
    if (isset($input['slider_adaptive_height'])) { $settings['slider_adaptive_height'] = sanitize_text_field($input['slider_adaptive_height']); }
    if (isset($input['slider_autoplay'])) { $settings['slider_autoplay'] = sanitize_text_field($input['slider_autoplay']); }
    if (isset($input['autoplay_speed'])) { $settings['autoplay_speed'] = $input['autoplay_speed']; }
    if (isset($input['slider_dots'])) { $settings['slider_dots'] = sanitize_text_field($input['slider_dots']); }
    if (isset($input['slider_dots_style'])) { $settings['slider_dots_style'] = sanitize_text_field($input['slider_dots_style']); }
    if (isset($input['dots_border_color'])) { $settings['dots_border_color'] = sanitize_text_field($input['dots_border_color']); }
    if (isset($input['dots_bg_color'])) { $settings['dots_bg_color'] = sanitize_text_field($input['dots_bg_color']); }
    if (isset($input['dots_active_border_color'])) { $settings['dots_active_border_color'] = sanitize_text_field($input['dots_active_border_color']); }
    if (isset($input['dots_active_bg_color'])) { $settings['dots_active_bg_color'] = sanitize_text_field($input['dots_active_bg_color']); }
    if (isset($input['dots_top_padding'])) { $settings['dots_top_padding'] = $input['dots_top_padding']; }
    if (isset($input['hover_show_dots'])) { $settings['hover_show_dots'] = sanitize_text_field($input['hover_show_dots']); }
    if (isset($input['slider_arrows'])) { $settings['slider_arrows'] = sanitize_text_field($input['slider_arrows']); }
    if (isset($input['slider_arrows_style'])) { $settings['slider_arrows_style'] = sanitize_text_field($input['slider_arrows_style']); }
    if (isset($input['arrows_position'])) { $settings['arrows_position'] = sanitize_text_field($input['arrows_position']); }
    if (isset($input['arrow_bg_color'])) { $settings['arrow_bg_color'] = sanitize_text_field($input['arrow_bg_color']); }
    if (isset($input['arrow_icon_color'])) { $settings['arrow_icon_color'] = sanitize_text_field($input['arrow_icon_color']); }
    if (isset($input['arrow_hover_bg_color'])) { $settings['arrow_hover_bg_color'] = sanitize_text_field($input['arrow_hover_bg_color']); }
    if (isset($input['arrow_hover_icon_color'])) { $settings['arrow_hover_icon_color'] = sanitize_text_field($input['arrow_hover_icon_color']); }
    if (isset($input['outer_section_arrow'])) { $settings['outer_section_arrow'] = sanitize_text_field($input['outer_section_arrow']); }
    if (isset($input['hover_show_arrow'])) { $settings['hover_show_arrow'] = sanitize_text_field($input['hover_show_arrow']); }
    if (isset($input['slider_center_mode'])) { $settings['slider_center_mode'] = sanitize_text_field($input['slider_center_mode']); }
    if (isset($input['center_padding'])) { $settings['center_padding'] = $input['center_padding']; }
    if (isset($input['slider_center_effects'])) { $settings['slider_center_effects'] = sanitize_text_field($input['slider_center_effects']); }
    if (isset($input['scale_center_slide'])) { $settings['scale_center_slide'] = $input['scale_center_slide']; }
    if (isset($input['scale_normal_slide'])) { $settings['scale_normal_slide'] = $input['scale_normal_slide']; }
    if (isset($input['opacity_normal_slide'])) { $settings['opacity_normal_slide'] = $input['opacity_normal_slide']; }
    if (isset($input['slider_rows'])) { $settings['slider_rows'] = sanitize_text_field($input['slider_rows']); }
    if (isset($input['slide_row_top_space'])) { $settings['slide_row_top_space'] = $input['slide_row_top_space']; }
    if (isset($input['slider_tablet_column'])) { $settings['slider_tablet_column'] = sanitize_text_field($input['slider_tablet_column']); }
    if (isset($input['tablet_steps_slide'])) { $settings['tablet_steps_slide'] = sanitize_text_field($input['tablet_steps_slide']); }
    if (isset($input['slider_responsive_tablet'])) { $settings['slider_responsive_tablet'] = sanitize_text_field($input['slider_responsive_tablet']); }
    if (isset($input['tablet_slider_draggable'])) { $settings['tablet_slider_draggable'] = sanitize_text_field($input['tablet_slider_draggable']); }
    if (isset($input['tablet_slider_infinite'])) { $settings['tablet_slider_infinite'] = sanitize_text_field($input['tablet_slider_infinite']); }
    if (isset($input['tablet_slider_autoplay'])) { $settings['tablet_slider_autoplay'] = sanitize_text_field($input['tablet_slider_autoplay']); }
    if (isset($input['tablet_autoplay_speed'])) { $settings['tablet_autoplay_speed'] = $input['tablet_autoplay_speed']; }
    if (isset($input['tablet_slider_dots'])) { $settings['tablet_slider_dots'] = sanitize_text_field($input['tablet_slider_dots']); }
    if (isset($input['tablet_slider_dots_style'])) { $settings['tablet_slider_dots_style'] = sanitize_text_field($input['tablet_slider_dots_style']); }
    if (isset($input['tablet_dots_border_color'])) { $settings['tablet_dots_border_color'] = sanitize_text_field($input['tablet_dots_border_color']); }
    if (isset($input['tablet_dots_bg_color'])) { $settings['tablet_dots_bg_color'] = sanitize_text_field($input['tablet_dots_bg_color']); }
    if (isset($input['tablet_dots_active_border_color'])) { $settings['tablet_dots_active_border_color'] = sanitize_text_field($input['tablet_dots_active_border_color']); }
    if (isset($input['tablet_dots_active_bg_color'])) { $settings['tablet_dots_active_bg_color'] = sanitize_text_field($input['tablet_dots_active_bg_color']); }
    if (isset($input['tablet_dots_top_padding'])) { $settings['tablet_dots_top_padding'] = $input['tablet_dots_top_padding']; }
    if (isset($input['tablet_hover_show_dots'])) { $settings['tablet_hover_show_dots'] = sanitize_text_field($input['tablet_hover_show_dots']); }
    if (isset($input['tablet_slider_arrows'])) { $settings['tablet_slider_arrows'] = sanitize_text_field($input['tablet_slider_arrows']); }
    if (isset($input['tablet_slider_arrows_style'])) { $settings['tablet_slider_arrows_style'] = sanitize_text_field($input['tablet_slider_arrows_style']); }
    if (isset($input['tablet_arrows_position'])) { $settings['tablet_arrows_position'] = sanitize_text_field($input['tablet_arrows_position']); }
    if (isset($input['tablet_arrow_bg_color'])) { $settings['tablet_arrow_bg_color'] = sanitize_text_field($input['tablet_arrow_bg_color']); }
    if (isset($input['tablet_arrow_icon_color'])) { $settings['tablet_arrow_icon_color'] = sanitize_text_field($input['tablet_arrow_icon_color']); }
    if (isset($input['tablet_arrow_hover_bg_color'])) { $settings['tablet_arrow_hover_bg_color'] = sanitize_text_field($input['tablet_arrow_hover_bg_color']); }
    if (isset($input['tablet_arrow_hover_icon_color'])) { $settings['tablet_arrow_hover_icon_color'] = sanitize_text_field($input['tablet_arrow_hover_icon_color']); }
    if (isset($input['tablet_outer_section_arrow'])) { $settings['tablet_outer_section_arrow'] = sanitize_text_field($input['tablet_outer_section_arrow']); }
    if (isset($input['tablet_hover_show_arrow'])) { $settings['tablet_hover_show_arrow'] = sanitize_text_field($input['tablet_hover_show_arrow']); }
    if (isset($input['tablet_slider_rows'])) { $settings['tablet_slider_rows'] = sanitize_text_field($input['tablet_slider_rows']); }
    if (isset($input['tablet_center_mode'])) { $settings['tablet_center_mode'] = sanitize_text_field($input['tablet_center_mode']); }
    if (isset($input['tablet_center_padding'])) { $settings['tablet_center_padding'] = $input['tablet_center_padding']; }
    if (isset($input['slider_mobile_column'])) { $settings['slider_mobile_column'] = sanitize_text_field($input['slider_mobile_column']); }
    if (isset($input['mobile_steps_slide'])) { $settings['mobile_steps_slide'] = sanitize_text_field($input['mobile_steps_slide']); }
    if (isset($input['slider_responsive_mobile'])) { $settings['slider_responsive_mobile'] = sanitize_text_field($input['slider_responsive_mobile']); }
    if (isset($input['mobile_slider_draggable'])) { $settings['mobile_slider_draggable'] = sanitize_text_field($input['mobile_slider_draggable']); }
    if (isset($input['mobile_slider_infinite'])) { $settings['mobile_slider_infinite'] = sanitize_text_field($input['mobile_slider_infinite']); }
    if (isset($input['mobile_slider_autoplay'])) { $settings['mobile_slider_autoplay'] = sanitize_text_field($input['mobile_slider_autoplay']); }
    if (isset($input['mobile_autoplay_speed'])) { $settings['mobile_autoplay_speed'] = $input['mobile_autoplay_speed']; }
    if (isset($input['mobile_slider_dots'])) { $settings['mobile_slider_dots'] = sanitize_text_field($input['mobile_slider_dots']); }
    if (isset($input['mobile_slider_dots_style'])) { $settings['mobile_slider_dots_style'] = sanitize_text_field($input['mobile_slider_dots_style']); }
    if (isset($input['mobile_dots_border_color'])) { $settings['mobile_dots_border_color'] = sanitize_text_field($input['mobile_dots_border_color']); }
    if (isset($input['mobile_dots_bg_color'])) { $settings['mobile_dots_bg_color'] = sanitize_text_field($input['mobile_dots_bg_color']); }
    if (isset($input['mobile_dots_active_border_color'])) { $settings['mobile_dots_active_border_color'] = sanitize_text_field($input['mobile_dots_active_border_color']); }
    if (isset($input['mobile_dots_active_bg_color'])) { $settings['mobile_dots_active_bg_color'] = sanitize_text_field($input['mobile_dots_active_bg_color']); }
    if (isset($input['mobile_dots_top_padding'])) { $settings['mobile_dots_top_padding'] = $input['mobile_dots_top_padding']; }
    if (isset($input['mobile_hover_show_dots'])) { $settings['mobile_hover_show_dots'] = sanitize_text_field($input['mobile_hover_show_dots']); }
    if (isset($input['mobile_slider_arrows'])) { $settings['mobile_slider_arrows'] = sanitize_text_field($input['mobile_slider_arrows']); }
    if (isset($input['mobile_slider_arrows_style'])) { $settings['mobile_slider_arrows_style'] = sanitize_text_field($input['mobile_slider_arrows_style']); }
    if (isset($input['mobile_arrows_position'])) { $settings['mobile_arrows_position'] = sanitize_text_field($input['mobile_arrows_position']); }
    if (isset($input['mobile_arrow_bg_color'])) { $settings['mobile_arrow_bg_color'] = sanitize_text_field($input['mobile_arrow_bg_color']); }
    if (isset($input['mobile_arrow_icon_color'])) { $settings['mobile_arrow_icon_color'] = sanitize_text_field($input['mobile_arrow_icon_color']); }
    if (isset($input['mobile_arrow_hover_bg_color'])) { $settings['mobile_arrow_hover_bg_color'] = sanitize_text_field($input['mobile_arrow_hover_bg_color']); }
    if (isset($input['mobile_arrow_hover_icon_color'])) { $settings['mobile_arrow_hover_icon_color'] = sanitize_text_field($input['mobile_arrow_hover_icon_color']); }
    if (isset($input['mobile_outer_section_arrow'])) { $settings['mobile_outer_section_arrow'] = sanitize_text_field($input['mobile_outer_section_arrow']); }
    if (isset($input['mobile_hover_show_arrow'])) { $settings['mobile_hover_show_arrow'] = sanitize_text_field($input['mobile_hover_show_arrow']); }
    if (isset($input['mobile_slider_rows'])) { $settings['mobile_slider_rows'] = sanitize_text_field($input['mobile_slider_rows']); }
    if (isset($input['mobile_center_mode'])) { $settings['mobile_center_mode'] = sanitize_text_field($input['mobile_center_mode']); }
    if (isset($input['mobile_center_padding'])) { $settings['mobile_center_padding'] = $input['mobile_center_padding']; }
    if (isset($input['pnf_padding'])) { $settings['pnf_padding'] = $input['pnf_padding']; }
    if (isset($input['pnf_color'])) { $settings['pnf_color'] = sanitize_text_field($input['pnf_color']); }
    if (isset($input['pnf_br'])) { $settings['pnf_br'] = $input['pnf_br']; }
    if (isset($input['plus_tilt_parallax'])) { $settings['plus_tilt_parallax'] = sanitize_text_field($input['plus_tilt_parallax']); }
    if (isset($input['plus_mouse_move_parallax'])) { $settings['plus_mouse_move_parallax'] = sanitize_text_field($input['plus_mouse_move_parallax']); }
    if (isset($input['messy_column'])) { $settings['messy_column'] = sanitize_text_field($input['messy_column']); }
    if (isset($input['desktop_column_1'])) { $settings['desktop_column_1'] = $input['desktop_column_1']; }
    if (isset($input['desktop_column_2'])) { $settings['desktop_column_2'] = $input['desktop_column_2']; }
    if (isset($input['desktop_column_3'])) { $settings['desktop_column_3'] = $input['desktop_column_3']; }
    if (isset($input['desktop_column_4'])) { $settings['desktop_column_4'] = $input['desktop_column_4']; }
    if (isset($input['desktop_column_5'])) { $settings['desktop_column_5'] = $input['desktop_column_5']; }
    if (isset($input['desktop_column_6'])) { $settings['desktop_column_6'] = $input['desktop_column_6']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
