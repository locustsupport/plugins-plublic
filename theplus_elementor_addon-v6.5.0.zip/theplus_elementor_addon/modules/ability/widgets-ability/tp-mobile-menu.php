<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-mobile-menu', [
'label' => __('Mobile Menu', 'theplus'),
    'description' => __('Adds The Plus "Mobile Menu" widget (tp-mobile-menu) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'mm_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'style_1', 'style_2']],
        'mobile_menu_pos' => ['type' => 'string', 'description' => 'Position', 'enum' => ['absolute', 'fixed']],
        'mobile_menu_pos_po' => ['type' => 'string', 'description' => 'Fixed Position', 'enum' => ['bottom', 'mobile_menu_pos', 'top']],
        'open_mobile_menu' => ['type' => 'object', 'description' => 'Open Mobile Menu (Slider/Size Object)'],
        'mm_st1_icon_image' => ['type' => 'string', 'description' => 'Select Icon', 'enum' => ['mm_st1_icon', 'mm_st1_image']],
        'mm_st1_custom_icon' => ['type' => 'string', 'description' => 'Icon'],
        'mm_st1_custom_image' => ['type' => 'integer', 'description' => 'Image (Image ID)'],
        'mm_st1_text' => ['type' => 'string', 'description' => 'Text'],
        'mm_st1_link' => ['type' => 'object', 'description' => 'Link'],
        'mm_st1_pin_text' => ['type' => 'string', 'description' => 'Pin Text'],
        'mm_st1_content' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Menu 1'],
        'mm_st2_icon_image_r' => ['type' => 'string', 'description' => 'Select Icon', 'enum' => ['mm_st2_icon_r', 'mm_st2_image_r']],
        'mm_st2_custom_icon_r' => ['type' => 'string', 'description' => 'Icon'],
        'mm_st2_custom_image_r' => ['type' => 'integer', 'description' => 'Image (Image ID)'],
        'mm_st2_text_r' => ['type' => 'string', 'description' => 'Text'],
        'mm_st2_link_r' => ['type' => 'object', 'description' => 'Link'],
        'mm_st2_pin_text_r' => ['type' => 'string', 'description' => 'Pin Text'],
        'mm_st2_content_r' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Menu 2'],
        'mm_extra_toggle_switch' => ['type' => 'string', 'description' => 'Extra Toggle', 'enum' => ['yes', 'no']],
        'mm_extra_toggle_icon_image' => ['type' => 'string', 'description' => 'Select Toggle Icon', 'enum' => ['mm_ext_tgl_icon', 'mm_ext_tgl_image', 'mm_extra_toggle_switch']],
        'mm_extra_toggle_custom_icon' => ['type' => 'string', 'description' => 'Icon'],
        'mm_extra_toggle_custom_image' => ['type' => 'integer', 'description' => 'Image (Image ID)'],
        'mm_extra_toggle_text' => ['type' => 'string', 'description' => 'Text'],
        'mm_extra_toggle_link_template' => ['type' => 'string', 'description' => 'Content', 'enum' => ['et_link', 'et_template', 'mm_extra_toggle_switch']],
        'mm_extra_toggle_link' => ['type' => 'object', 'description' => 'Link'],
        'extra_content_template_et' => ['type' => 'string', 'description' => 'Elementor Templates', 'enum' => ['mm_extra_toggle_link_template', 'mm_extra_toggle_switch']],
        'extra_toggle_bar_direction' => ['type' => 'string', 'description' => 'Open Content Direction', 'enum' => ['bottom', 'left', 'mm_extra_toggle_link_template', 'mm_extra_toggle_switch', 'right', 'top']],
        'extra_toggle_style' => ['type' => 'string', 'description' => 'Open Content Style', 'enum' => ['mm-ett-style-1', 'mm-ett-style-2', 'mm_extra_toggle_link_template', 'mm_extra_toggle_switch']],
        'extra_content_width_option' => ['type' => 'string', 'description' => 'Content Width', 'enum' => ['custom', 'fullwidth', 'mm_extra_toggle_link_template', 'mm_extra_toggle_switch']],
        'extra_content_margin' => ['type' => 'object', 'description' => 'Margin (Slider/Size Object)'],
        'extra_content_width' => ['type' => 'object', 'description' => 'Custom Content Width/Height (Slider/Size Object)'],
        'mm_extra_display_mode' => ['type' => 'string', 'description' => 'Display', 'enum' => ['columns', 'swiper']],
        'mm_extra_indicator_switch' => ['type' => 'string', 'description' => 'Active Page Indicator', 'enum' => ['yes', 'no']],
        'mm_extra_indicator_type' => ['type' => 'string', 'description' => 'Style', 'enum' => ['dot', 'line', 'mm_extra_indicator_switch']],
        'mm_extra_indicator' => ['type' => 'string', 'description' => 'Position', 'enum' => ['indi-bottom', 'indi-top', 'mm_extra_indicator_switch', 'mm_extra_indicator_type']],
        'mm_extra_indicator_dot_offset' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'pin_text_overflow' => ['type' => 'string', 'description' => 'Pin Text Overflow', 'enum' => ['hidden', 'visible', '{{WRAPPER}} .tp-mobile-menu.style_2 .tp-mm-l-wrapper .tp-mm-li,
					{{WRAPPER}} .tp-mobile-menu.style_2 .tp-mm-r-wrapper .tp-mm-li,
					{{WRAPPER}} .tp-mobile-menu.style_2 .tp-mm-c-wrapper .tp-mm-c-et-li']],
        'tpaep_theme_builder' => ['type' => 'string', 'description' => 'tpaep_theme_builder'],
        'mm_icon_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'mm_icon_color_n' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'mm_icon_color_a' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'mm_image_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'mm_image_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'mm_image_radius_a' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'mm_et_icon_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'mm_et_icon_color_n' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'mm_et_image_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'mm_et_image_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'mm_indicator_line_width' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'mm_indicator_line_height' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'mm_indicator_line_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'mm_indicator_dot_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'mm_indicator_dot_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'mm_main_menu_margin' => ['type' => 'object', 'description' => 'Outer Padding (Dimensions Object)'],
        'max_width_loop' => ['type' => 'object', 'description' => 'Menu Width (Slider/Size Object)'],
        'max_height_loop' => ['type' => 'object', 'description' => 'Menu Height (Slider/Size Object)'],
        'n_title_color' => ['type' => 'string', 'description' => 'Normal Title Color (Color Hex/RGBA)'],
        'et_title_color' => ['type' => 'string', 'description' => 'Extra Toggle Title Color (Color Hex/RGBA)'],
        'mm_main_menu_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'n_title_color_a' => ['type' => 'string', 'description' => 'Active Title Color (Color Hex/RGBA)'],
        'mm_main_menu_radius_a' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'extra_toggle_equal_height' => ['type' => 'string', 'description' => 'Extra Toggle Equal Height/Width', 'enum' => ['yes', 'no']],
        'extra_toggle_width' => ['type' => 'object', 'description' => 'Extra Toggle Width (Slider/Size Object)'],
        'extra_toggle_width_eq' => ['type' => 'object', 'description' => 'Extra Toggle Size (Slider/Size Object)'],
        'extra_toggle_offset' => ['type' => 'object', 'description' => 'Toggle Offset (Slider/Size Object)'],
        'mm_extra_toggle_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'mm_extra_toggle_temp_overflow' => ['type' => 'string', 'description' => 'Overflow', 'enum' => ['tp-of-h', 'tp-of-v']],
        'content_inner_padding' => ['type' => 'object', 'description' => 'Inner Padding (Dimensions Object)'],
        'extra_toggle_content_fw_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'tab_extra_toggle_close_position' => ['type' => 'string', 'description' => 'Close Icon Position', 'enum' => ['mm-ci-auto', 'mm-ci-bottom-center', 'mm-ci-bottom-left', 'mm-ci-bottom-right', 'mm-ci-top-center', 'mm-ci-top-left', 'mm-ci-top-right']],
        'extra_toggle_icon_close_color' => ['type' => 'string', 'description' => 'Close Icon Color (Color Hex/RGBA)'],
        'extra_toggle_icon_close_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'extra_toggle_icon_close_color_hover' => ['type' => 'string', 'description' => 'Close Icon Hover Color (Color Hex/RGBA)'],
        'extra_toggle_icon_close_bg_hover' => ['type' => 'string', 'description' => 'Close Hover Background Color (Color Hex/RGBA)'],
        'extra_toggle_icon_close_border_radius_hover' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        'mm_cb__padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'mm_cb_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'mm_cb_overflow' => ['type' => 'string', 'description' => 'Overflow', 'enum' => ['hidden', 'visible', '{{WRAPPER}} .tp-mobile-menu']],
        'pin_text_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'pin_text_top_offset' => ['type' => 'object', 'description' => 'Top Offset (Slider/Size Object)'],
        'pin_text_right_offset' => ['type' => 'object', 'description' => 'Right Offset (Slider/Size Object)'],
        'pin_text_size' => ['type' => 'object', 'description' => 'Text Size (Slider/Size Object)'],
        'pin_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'pin_text_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'show_scroll_window_offset' => ['type' => 'string', 'description' => 'Show Mobile Menu Scroll Offset', 'enum' => ['yes', 'no']],
        'scroll_top_offset_value' => ['type' => 'object', 'description' => 'Scroll Top Offset Value (Slider/Size Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports SVG icons, Lottie badges, and swiper transitions.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_mobile_menu_ability',
    'permission_callback' => 'tpaep_mcp_theplus_mobile_menu_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_mobile_menu_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_mobile_menu_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-mobile-menu';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Mobile Menu widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['mm_style'])) { $settings['mm_style'] = sanitize_text_field($input['mm_style']); }
    if (isset($input['mobile_menu_pos'])) { $settings['mobile_menu_pos'] = sanitize_text_field($input['mobile_menu_pos']); }
    if (isset($input['mobile_menu_pos_po'])) { $settings['mobile_menu_pos_po'] = sanitize_text_field($input['mobile_menu_pos_po']); }
    if (isset($input['open_mobile_menu'])) { $settings['open_mobile_menu'] = $input['open_mobile_menu']; }
    if (isset($input['mm_st1_icon_image'])) { $settings['mm_st1_icon_image'] = sanitize_text_field($input['mm_st1_icon_image']); }
    if (isset($input['mm_st1_custom_icon'])) { $settings['mm_st1_custom_icon'] = sanitize_text_field($input['mm_st1_custom_icon']); }
    if (!empty($input['mm_st1_custom_image'])) { $settings['mm_st1_custom_image'] = ['id' => absint($input['mm_st1_custom_image'])]; }
    if (isset($input['mm_st1_text'])) { $settings['mm_st1_text'] = sanitize_text_field($input['mm_st1_text']); }
    if (isset($input['mm_st1_link'])) { $settings['mm_st1_link'] = $input['mm_st1_link']; }
    if (isset($input['mm_st1_pin_text'])) { $settings['mm_st1_pin_text'] = sanitize_text_field($input['mm_st1_pin_text']); }
    if (isset($input['mm_st1_content'])) { $settings['mm_st1_content'] = $input['mm_st1_content']; }
    if (isset($input['mm_st2_icon_image_r'])) { $settings['mm_st2_icon_image_r'] = sanitize_text_field($input['mm_st2_icon_image_r']); }
    if (isset($input['mm_st2_custom_icon_r'])) { $settings['mm_st2_custom_icon_r'] = sanitize_text_field($input['mm_st2_custom_icon_r']); }
    if (!empty($input['mm_st2_custom_image_r'])) { $settings['mm_st2_custom_image_r'] = ['id' => absint($input['mm_st2_custom_image_r'])]; }
    if (isset($input['mm_st2_text_r'])) { $settings['mm_st2_text_r'] = sanitize_text_field($input['mm_st2_text_r']); }
    if (isset($input['mm_st2_link_r'])) { $settings['mm_st2_link_r'] = $input['mm_st2_link_r']; }
    if (isset($input['mm_st2_pin_text_r'])) { $settings['mm_st2_pin_text_r'] = sanitize_text_field($input['mm_st2_pin_text_r']); }
    if (isset($input['mm_st2_content_r'])) { $settings['mm_st2_content_r'] = $input['mm_st2_content_r']; }
    if (isset($input['mm_extra_toggle_switch'])) { $settings['mm_extra_toggle_switch'] = sanitize_text_field($input['mm_extra_toggle_switch']); }
    if (isset($input['mm_extra_toggle_icon_image'])) { $settings['mm_extra_toggle_icon_image'] = sanitize_text_field($input['mm_extra_toggle_icon_image']); }
    if (isset($input['mm_extra_toggle_custom_icon'])) { $settings['mm_extra_toggle_custom_icon'] = sanitize_text_field($input['mm_extra_toggle_custom_icon']); }
    if (!empty($input['mm_extra_toggle_custom_image'])) { $settings['mm_extra_toggle_custom_image'] = ['id' => absint($input['mm_extra_toggle_custom_image'])]; }
    if (isset($input['mm_extra_toggle_text'])) { $settings['mm_extra_toggle_text'] = sanitize_text_field($input['mm_extra_toggle_text']); }
    if (isset($input['mm_extra_toggle_link_template'])) { $settings['mm_extra_toggle_link_template'] = sanitize_text_field($input['mm_extra_toggle_link_template']); }
    if (isset($input['mm_extra_toggle_link'])) { $settings['mm_extra_toggle_link'] = $input['mm_extra_toggle_link']; }
    if (isset($input['extra_content_template_et'])) { $settings['extra_content_template_et'] = sanitize_text_field($input['extra_content_template_et']); }
    if (isset($input['extra_toggle_bar_direction'])) { $settings['extra_toggle_bar_direction'] = sanitize_text_field($input['extra_toggle_bar_direction']); }
    if (isset($input['extra_toggle_style'])) { $settings['extra_toggle_style'] = sanitize_text_field($input['extra_toggle_style']); }
    if (isset($input['extra_content_width_option'])) { $settings['extra_content_width_option'] = sanitize_text_field($input['extra_content_width_option']); }
    if (isset($input['extra_content_margin'])) { $settings['extra_content_margin'] = $input['extra_content_margin']; }
    if (isset($input['extra_content_width'])) { $settings['extra_content_width'] = $input['extra_content_width']; }
    if (isset($input['mm_extra_display_mode'])) { $settings['mm_extra_display_mode'] = sanitize_text_field($input['mm_extra_display_mode']); }
    if (isset($input['mm_extra_indicator_switch'])) { $settings['mm_extra_indicator_switch'] = sanitize_text_field($input['mm_extra_indicator_switch']); }
    if (isset($input['mm_extra_indicator_type'])) { $settings['mm_extra_indicator_type'] = sanitize_text_field($input['mm_extra_indicator_type']); }
    if (isset($input['mm_extra_indicator'])) { $settings['mm_extra_indicator'] = sanitize_text_field($input['mm_extra_indicator']); }
    if (isset($input['mm_extra_indicator_dot_offset'])) { $settings['mm_extra_indicator_dot_offset'] = $input['mm_extra_indicator_dot_offset']; }
    if (isset($input['pin_text_overflow'])) { $settings['pin_text_overflow'] = sanitize_text_field($input['pin_text_overflow']); }
    if (isset($input['tpaep_theme_builder'])) { $settings['tpaep_theme_builder'] = sanitize_text_field($input['tpaep_theme_builder']); }
    if (isset($input['mm_icon_size'])) { $settings['mm_icon_size'] = $input['mm_icon_size']; }
    if (isset($input['mm_icon_color_n'])) { $settings['mm_icon_color_n'] = sanitize_text_field($input['mm_icon_color_n']); }
    if (isset($input['mm_icon_color_a'])) { $settings['mm_icon_color_a'] = sanitize_text_field($input['mm_icon_color_a']); }
    if (isset($input['mm_image_size'])) { $settings['mm_image_size'] = $input['mm_image_size']; }
    if (isset($input['mm_image_radius'])) { $settings['mm_image_radius'] = $input['mm_image_radius']; }
    if (isset($input['mm_image_radius_a'])) { $settings['mm_image_radius_a'] = $input['mm_image_radius_a']; }
    if (isset($input['mm_et_icon_size'])) { $settings['mm_et_icon_size'] = $input['mm_et_icon_size']; }
    if (isset($input['mm_et_icon_color_n'])) { $settings['mm_et_icon_color_n'] = sanitize_text_field($input['mm_et_icon_color_n']); }
    if (isset($input['mm_et_image_size'])) { $settings['mm_et_image_size'] = $input['mm_et_image_size']; }
    if (isset($input['mm_et_image_radius'])) { $settings['mm_et_image_radius'] = $input['mm_et_image_radius']; }
    if (isset($input['mm_indicator_line_width'])) { $settings['mm_indicator_line_width'] = $input['mm_indicator_line_width']; }
    if (isset($input['mm_indicator_line_height'])) { $settings['mm_indicator_line_height'] = $input['mm_indicator_line_height']; }
    if (isset($input['mm_indicator_line_color'])) { $settings['mm_indicator_line_color'] = sanitize_text_field($input['mm_indicator_line_color']); }
    if (isset($input['mm_indicator_dot_size'])) { $settings['mm_indicator_dot_size'] = $input['mm_indicator_dot_size']; }
    if (isset($input['mm_indicator_dot_color'])) { $settings['mm_indicator_dot_color'] = sanitize_text_field($input['mm_indicator_dot_color']); }
    if (isset($input['mm_main_menu_margin'])) { $settings['mm_main_menu_margin'] = $input['mm_main_menu_margin']; }
    if (isset($input['max_width_loop'])) { $settings['max_width_loop'] = $input['max_width_loop']; }
    if (isset($input['max_height_loop'])) { $settings['max_height_loop'] = $input['max_height_loop']; }
    if (isset($input['n_title_color'])) { $settings['n_title_color'] = sanitize_text_field($input['n_title_color']); }
    if (isset($input['et_title_color'])) { $settings['et_title_color'] = sanitize_text_field($input['et_title_color']); }
    if (isset($input['mm_main_menu_radius'])) { $settings['mm_main_menu_radius'] = $input['mm_main_menu_radius']; }
    if (isset($input['n_title_color_a'])) { $settings['n_title_color_a'] = sanitize_text_field($input['n_title_color_a']); }
    if (isset($input['mm_main_menu_radius_a'])) { $settings['mm_main_menu_radius_a'] = $input['mm_main_menu_radius_a']; }
    if (isset($input['extra_toggle_equal_height'])) { $settings['extra_toggle_equal_height'] = sanitize_text_field($input['extra_toggle_equal_height']); }
    if (isset($input['extra_toggle_width'])) { $settings['extra_toggle_width'] = $input['extra_toggle_width']; }
    if (isset($input['extra_toggle_width_eq'])) { $settings['extra_toggle_width_eq'] = $input['extra_toggle_width_eq']; }
    if (isset($input['extra_toggle_offset'])) { $settings['extra_toggle_offset'] = $input['extra_toggle_offset']; }
    if (isset($input['mm_extra_toggle_radius'])) { $settings['mm_extra_toggle_radius'] = $input['mm_extra_toggle_radius']; }
    if (isset($input['mm_extra_toggle_temp_overflow'])) { $settings['mm_extra_toggle_temp_overflow'] = sanitize_text_field($input['mm_extra_toggle_temp_overflow']); }
    if (isset($input['content_inner_padding'])) { $settings['content_inner_padding'] = $input['content_inner_padding']; }
    if (isset($input['extra_toggle_content_fw_radius'])) { $settings['extra_toggle_content_fw_radius'] = $input['extra_toggle_content_fw_radius']; }
    if (isset($input['tab_extra_toggle_close_position'])) { $settings['tab_extra_toggle_close_position'] = sanitize_text_field($input['tab_extra_toggle_close_position']); }
    if (isset($input['extra_toggle_icon_close_color'])) { $settings['extra_toggle_icon_close_color'] = sanitize_text_field($input['extra_toggle_icon_close_color']); }
    if (isset($input['extra_toggle_icon_close_border_radius'])) { $settings['extra_toggle_icon_close_border_radius'] = $input['extra_toggle_icon_close_border_radius']; }
    if (isset($input['extra_toggle_icon_close_color_hover'])) { $settings['extra_toggle_icon_close_color_hover'] = sanitize_text_field($input['extra_toggle_icon_close_color_hover']); }
    if (isset($input['extra_toggle_icon_close_bg_hover'])) { $settings['extra_toggle_icon_close_bg_hover'] = sanitize_text_field($input['extra_toggle_icon_close_bg_hover']); }
    if (isset($input['extra_toggle_icon_close_border_radius_hover'])) { $settings['extra_toggle_icon_close_border_radius_hover'] = $input['extra_toggle_icon_close_border_radius_hover']; }
    if (isset($input['mm_cb__padding'])) { $settings['mm_cb__padding'] = $input['mm_cb__padding']; }
    if (isset($input['mm_cb_border_radius'])) { $settings['mm_cb_border_radius'] = $input['mm_cb_border_radius']; }
    if (isset($input['mm_cb_overflow'])) { $settings['mm_cb_overflow'] = sanitize_text_field($input['mm_cb_overflow']); }
    if (isset($input['pin_text_padding'])) { $settings['pin_text_padding'] = $input['pin_text_padding']; }
    if (isset($input['pin_text_top_offset'])) { $settings['pin_text_top_offset'] = $input['pin_text_top_offset']; }
    if (isset($input['pin_text_right_offset'])) { $settings['pin_text_right_offset'] = $input['pin_text_right_offset']; }
    if (isset($input['pin_text_size'])) { $settings['pin_text_size'] = $input['pin_text_size']; }
    if (isset($input['pin_text_color'])) { $settings['pin_text_color'] = sanitize_text_field($input['pin_text_color']); }
    if (isset($input['pin_text_radius'])) { $settings['pin_text_radius'] = $input['pin_text_radius']; }
    if (isset($input['show_scroll_window_offset'])) { $settings['show_scroll_window_offset'] = sanitize_text_field($input['show_scroll_window_offset']); }
    if (isset($input['scroll_top_offset_value'])) { $settings['scroll_top_offset_value'] = $input['scroll_top_offset_value']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
