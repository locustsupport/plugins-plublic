<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-before-after', [
'label' => __('Before After', 'theplus'),
    'description' => __('Adds The Plus "Before After" widget (tp-before-after) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'           => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'         => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'          => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'type' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'cursor', 'horizontal', 'vertical']],
        'before_image' => ['type' => 'integer', 'description' => 'Image for Before'],
        'before_label' => ['type' => 'string', 'description' => 'Label for Before'],
        'after_image' => ['type' => 'integer', 'description' => 'Image for After'],
        'after_label' => ['type' => 'string', 'description' => 'Label for After'],
        'alignment' => ['type' => 'string', 'description' => 'Alignment', 'enum' => ['center', 'icon', 'left', 'right', 'toggle']],
        'full_switch' => ['type' => 'string', 'description' => 'Full Width', 'enum' => ['yes', 'no']],
        'click_hover_move' => ['type' => 'string', 'description' => 'Mouse Hover option', 'enum' => ['yes', 'no']],
        'separate_switch' => ['type' => 'string', 'description' => 'Separator Line', 'enum' => ['yes', 'no']],
        'separator_style' => ['type' => 'string', 'description' => 'Separator Style', 'enum' => ['bottom', 'middle', 'separate_switch']],
        'separate_width' => ['type' => 'object', 'description' => 'Separator Width'],
        'separate_color' => ['type' => 'string', 'description' => 'Separator Color'],
        'separate_bg_color' => ['type' => 'string', 'description' => 'Separator Bottom Bg Color'],
        'image_separator' => ['type' => 'integer', 'description' => 'Separator Icon'],
        'separate_position' => ['type' => 'object', 'description' => 'Separator Position'],
        'label_option_padding' => ['type' => 'object', 'description' => 'Padding'],
        'label_option_color' => ['type' => 'string', 'description' => 'Label Color'],
        'label_option_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'settings'          => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings.']
    ], 'required' => ['post_id', 'parent_id', 'before_image', 'after_image'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_before_after_ability',
    'permission_callback' => 'tpaep_mcp_theplus_before_after_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_before_after_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_before_after_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-before-after';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Before After widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['type'])) { $settings['type'] = sanitize_text_field($input['type']); }
    if (!empty($input['before_image'])) { $settings['before_image'] = ['id' => absint($input['before_image'])]; }
    if (isset($input['before_label'])) { $settings['before_label'] = sanitize_text_field($input['before_label']); }
    if (!empty($input['after_image'])) { $settings['after_image'] = ['id' => absint($input['after_image'])]; }
    if (isset($input['after_label'])) { $settings['after_label'] = sanitize_text_field($input['after_label']); }
    if (isset($input['alignment'])) { $settings['alignment'] = sanitize_text_field($input['alignment']); }
    if (isset($input['full_switch'])) { $settings['full_switch'] = sanitize_text_field($input['full_switch']); }
    if (isset($input['click_hover_move'])) { $settings['click_hover_move'] = sanitize_text_field($input['click_hover_move']); }
    if (isset($input['separate_switch'])) { $settings['separate_switch'] = sanitize_text_field($input['separate_switch']); }
    if (isset($input['separator_style'])) { $settings['separator_style'] = sanitize_text_field($input['separator_style']); }
    if (isset($input['separate_width'])) { $settings['separate_width'] = $input['separate_width']; }
    if (isset($input['separate_color'])) { $settings['separate_color'] = sanitize_text_field($input['separate_color']); }
    if (isset($input['separate_bg_color'])) { $settings['separate_bg_color'] = sanitize_text_field($input['separate_bg_color']); }
    if (!empty($input['image_separator'])) { $settings['image_separator'] = ['id' => absint($input['image_separator'])]; }
    if (isset($input['separate_position'])) { $settings['separate_position'] = $input['separate_position']; }
    if (isset($input['label_option_padding'])) { $settings['label_option_padding'] = $input['label_option_padding']; }
    if (isset($input['label_option_color'])) { $settings['label_option_color'] = sanitize_text_field($input['label_option_color']); }
    if (isset($input['label_option_radius'])) { $settings['label_option_radius'] = $input['label_option_radius']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
