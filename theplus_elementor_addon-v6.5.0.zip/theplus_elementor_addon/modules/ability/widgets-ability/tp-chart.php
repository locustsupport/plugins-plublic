<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-chart', [
'label' => __('Chart', 'theplus'),
    'description' => __('Adds The Plus "Chart" widget (tp-chart) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'           => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'         => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'          => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'select_chart_type' => ['type' => 'string', 'description' => 'Chart Type', 'enum' => ['csv_file', 'custom', 'frontend_available', 'g_sheet']],
        'csv_url' => ['type' => 'object', 'description' => 'Enter a CSV File URL'],
        'gs_apikey' => ['type' => 'string', 'description' => 'API Key'],
        'gs_sheetid' => ['type' => 'string', 'description' => 'Sheet ID'],
        'gs_tablerange' => ['type' => 'string', 'description' => 'Table Range'],
        'select_chart' => ['type' => 'string', 'description' => 'Select Chart', 'enum' => ['bar', 'bubble', 'columns', 'line', 'pie', 'polarArea', 'radar']],
        'bar_chart_type' => ['type' => 'string', 'description' => 'Orientation', 'enum' => ['horizontal_bar', 'select_chart', 'vertical_bar']],
        'doughnut_pie_chart_type' => ['type' => 'string', 'description' => 'Orientation', 'enum' => ['doughnut', 'pie', 'select_chart']],
        'main_label' => ['type' => 'string', 'description' => 'Label Value'],
        'loop_label' => ['type' => 'string', 'description' => 'Label'],
        'loop_data' => ['type' => 'string', 'description' => 'Data'],
        'multi_dot_bg' => ['type' => 'string', 'description' => 'Multiple Dot Background', 'enum' => ['yes', 'no']],
        'dot_bg' => ['type' => 'string', 'description' => 'Dot Background'],
        'multi_dot_bg_multiple' => ['type' => 'string', 'description' => 'Dot Background'],
        'multi_dot_border' => ['type' => 'string', 'description' => 'Multiple Border', 'enum' => ['yes', 'no']],
        'dot_border' => ['type' => 'string', 'description' => 'Dot Border'],
        'multi_dot_border_multiple' => ['type' => 'string', 'description' => 'Dot Border'],
        'fill_opt' => ['type' => 'string', 'description' => 'Fill', 'enum' => ['yes', 'no']],
        'line_styling_opt' => ['type' => 'string', 'description' => 'Border Dash', 'enum' => ['yes', 'no']],
        'chart_content' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Chart Data Boxes'],
        'alone_data' => ['type' => 'string', 'description' => 'Data'],
        'alone_bg_colors' => ['type' => 'string', 'description' => 'Background Colors'],
        'alone_border_colors' => ['type' => 'string', 'description' => 'Border Colors'],
        'alone_border_colors_polar' => ['type' => 'string', 'description' => 'Border Colors'],
        'doughnut_loop_label' => ['type' => 'string', 'description' => 'Label'],
        'doughnut_loop_data' => ['type' => 'string', 'description' => 'Data'],
        'doughnut_loop_background' => ['type' => 'string', 'description' => 'Background Colors'],
        'doughnut_loop_border' => ['type' => 'string', 'description' => 'Border Colors'],
        'doughnut_chart_datasets' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Chart Data Boxes'],
        'loop_label' => ['type' => 'string', 'description' => 'Label'],
        'bubble_data' => ['type' => 'string', 'description' => 'Data'],
        'multi_dot_bg' => ['type' => 'string', 'description' => 'Multiple Background Colors', 'enum' => ['yes', 'no']],
        'dot_bg' => ['type' => 'string', 'description' => 'Background'],
        'multi_dot_bg_multiple' => ['type' => 'string', 'description' => 'Background'],
        'multi_dot_border' => ['type' => 'string', 'description' => 'Multiple Border Colors', 'enum' => ['yes', 'no']],
        'dot_border' => ['type' => 'string', 'description' => 'Dot Border'],
        'multi_dot_border_multiple' => ['type' => 'string', 'description' => 'Dot Border Colors'],
        'bubble_content' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Chart Data Boxes'],
        'maxbarthickness' => ['type' => 'object', 'description' => 'Bar Size'],
        'barthickness' => ['type' => 'object', 'description' => 'Bar Space'],
        'show_grid_lines' => ['type' => 'string', 'description' => 'Grid Lines', 'enum' => ['yes', 'no']],
        'grid_color' => ['type' => 'string', 'description' => 'Grid Color X-Axis'],
        'zero_linecolor_x' => ['type' => 'string', 'description' => 'Zero Line Color'],
        'draw_border_x' => ['type' => 'string', 'description' => 'Draw Border', 'enum' => ['yes', 'no']],
        'draw_on_chart_area_x' => ['type' => 'string', 'description' => 'Draw Border on Chart Area', 'enum' => ['yes', 'no']],
        'begin_atzero_x' => ['type' => 'string', 'description' => 'Begin At Zero', 'enum' => ['yes', 'no']],
        'grid_color_xAxes' => ['type' => 'string', 'description' => 'Grid Color Y-Axis'],
        'zero_linecolor_y' => ['type' => 'string', 'description' => 'Zero Line Color'],
        'draw_border_y' => ['type' => 'string', 'description' => 'Draw Border', 'enum' => ['yes', 'no']],
        'draw_on_chart_area_y' => ['type' => 'string', 'description' => 'Draw Border on Chart Area', 'enum' => ['yes', 'no']],
        'begin_atzero_y' => ['type' => 'string', 'description' => 'Begin At Zero', 'enum' => ['yes', 'no']],
        'show_legend' => ['type' => 'string', 'description' => 'Legend', 'enum' => ['yes', 'no']],
        'show_legend_color' => ['type' => 'string', 'description' => 'Color'],
        'show_legend_position' => ['type' => 'string', 'description' => 'Position', 'enum' => ['bottom', 'icon', 'left', 'right', 'show_legend', 'top']],
        'show_legend_align' => ['type' => 'string', 'description' => 'Alignment', 'enum' => ['center', 'end', 'icon', 'show_legend', 'start']],
        'show_legend_size' => ['type' => 'object', 'description' => 'Size'],
        'custom_point_styles' => ['type' => 'string', 'description' => 'Custom Point Styles', 'enum' => ['yes', 'no']],
        'point_styles' => ['type' => 'string', 'description' => 'Point Styles', 'enum' => ['circle', 'cross', 'crossRot', 'custom_point_styles', 'dash', 'line', 'rect', 'rectRot', 'rectRounded', 'select_chart', 'star', 'triangle']],
        'point_bg' => ['type' => 'string', 'description' => 'Point Background'],
        'point_n_size' => ['type' => 'object', 'description' => 'Point Normal Size'],
        'point_h_size' => ['type' => 'object', 'description' => 'Point Hover Size'],
        'point_border_color' => ['type' => 'string', 'description' => 'Point Border'],
        'point_border_width' => ['type' => 'object', 'description' => 'Point Border Width'],
        'show_tooltip' => ['type' => 'string', 'description' => 'Tooltip', 'enum' => ['yes', 'no']],
        'tooltip_event' => ['type' => 'string', 'description' => 'Event', 'enum' => ['click', 'mousemove', 'show_tooltip']],
        'tooltip_font_size' => ['type' => 'object', 'description' => 'Font Size'],
        'tooltip_color' => ['type' => 'string', 'description' => 'Title Color'],
        'tooltip_body_color' => ['type' => 'string', 'description' => 'Body Font Color'],
        'tooltip_bg' => ['type' => 'string', 'description' => 'Tooltip Background'],
        'tension' => ['type' => 'string', 'description' => 'Smooth', 'enum' => ['yes', 'no']],
        'aspect_ratio' => ['type' => 'string', 'description' => 'Aspect Ratio', 'enum' => ['yes', 'no']],
        'maintain_aspect_ratio' => ['type' => 'string', 'description' => 'Maintain Aspect Ratio', 'enum' => ['yes', 'no']],
        'c_animation' => ['type' => 'string', 'description' => 'Animation', 'enum' => ['easeInBack', 'easeInBounce', 'easeInCirc', 'easeInCubic', 'easeInElastic', 'easeInExpo', 'easeInOutBack', 'easeInOutBounce', 'easeInOutCirc', 'easeInOutCubic', 'easeInOutElastic', 'easeInOutExpo', 'easeInOutQuad', 'easeInOutQuart', 'easeInOutQuint', 'easeInOutSine', 'easeInQuad', 'easeInQuart', 'easeInQuint', 'easeInSine', 'easeOutBack', 'easeOutBounce', 'easeOutCirc', 'easeOutCubic', 'easeOutElastic', 'easeOutExpo', 'easeOutQuad', 'easeOutQuart', 'easeOutQuint', 'easeOutSine', 'linear']],
        'c_animation_duration' => ['type' => 'object', 'description' => 'Duration'],
        'chartwidth' => ['type' => 'object', 'description' => 'Chart Width'],
        'chartheight' => ['type' => 'object', 'description' => 'Chart Height'],
        'chart_alignment' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'devices', 'flex-end', 'flex-start', 'icon', '{{WRAPPER}} .tp-chart-wrapper']],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings.']
    ], 'required' => ['post_id', 'parent_id', 'select_chart'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_chart_ability',
    'permission_callback' => 'tpaep_mcp_theplus_chart_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_chart_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_chart_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-chart';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Chart widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['select_chart_type'])) { $settings['select_chart_type'] = sanitize_text_field($input['select_chart_type']); }
    if (isset($input['csv_url'])) { $settings['csv_url'] = $input['csv_url']; }
    if (isset($input['gs_apikey'])) { $settings['gs_apikey'] = sanitize_text_field($input['gs_apikey']); }
    if (isset($input['gs_sheetid'])) { $settings['gs_sheetid'] = sanitize_text_field($input['gs_sheetid']); }
    if (isset($input['gs_tablerange'])) { $settings['gs_tablerange'] = sanitize_text_field($input['gs_tablerange']); }
    if (isset($input['select_chart'])) { $settings['select_chart'] = sanitize_text_field($input['select_chart']); }
    if (isset($input['bar_chart_type'])) { $settings['bar_chart_type'] = sanitize_text_field($input['bar_chart_type']); }
    if (isset($input['doughnut_pie_chart_type'])) { $settings['doughnut_pie_chart_type'] = sanitize_text_field($input['doughnut_pie_chart_type']); }
    if (isset($input['main_label'])) { $settings['main_label'] = sanitize_text_field($input['main_label']); }
    if (isset($input['loop_label'])) { $settings['loop_label'] = sanitize_text_field($input['loop_label']); }
    if (isset($input['loop_data'])) { $settings['loop_data'] = sanitize_text_field($input['loop_data']); }
    if (isset($input['multi_dot_bg'])) { $settings['multi_dot_bg'] = sanitize_text_field($input['multi_dot_bg']); }
    if (isset($input['dot_bg'])) { $settings['dot_bg'] = sanitize_text_field($input['dot_bg']); }
    if (isset($input['multi_dot_bg_multiple'])) { $settings['multi_dot_bg_multiple'] = sanitize_text_field($input['multi_dot_bg_multiple']); }
    if (isset($input['multi_dot_border'])) { $settings['multi_dot_border'] = sanitize_text_field($input['multi_dot_border']); }
    if (isset($input['dot_border'])) { $settings['dot_border'] = sanitize_text_field($input['dot_border']); }
    if (isset($input['multi_dot_border_multiple'])) { $settings['multi_dot_border_multiple'] = sanitize_text_field($input['multi_dot_border_multiple']); }
    if (isset($input['fill_opt'])) { $settings['fill_opt'] = sanitize_text_field($input['fill_opt']); }
    if (isset($input['line_styling_opt'])) { $settings['line_styling_opt'] = sanitize_text_field($input['line_styling_opt']); }
    if (isset($input['chart_content'])) { $settings['chart_content'] = $input['chart_content']; }
    if (isset($input['alone_data'])) { $settings['alone_data'] = sanitize_text_field($input['alone_data']); }
    if (isset($input['alone_bg_colors'])) { $settings['alone_bg_colors'] = sanitize_text_field($input['alone_bg_colors']); }
    if (isset($input['alone_border_colors'])) { $settings['alone_border_colors'] = sanitize_text_field($input['alone_border_colors']); }
    if (isset($input['alone_border_colors_polar'])) { $settings['alone_border_colors_polar'] = sanitize_text_field($input['alone_border_colors_polar']); }
    if (isset($input['doughnut_loop_label'])) { $settings['doughnut_loop_label'] = sanitize_text_field($input['doughnut_loop_label']); }
    if (isset($input['doughnut_loop_data'])) { $settings['doughnut_loop_data'] = sanitize_text_field($input['doughnut_loop_data']); }
    if (isset($input['doughnut_loop_background'])) { $settings['doughnut_loop_background'] = sanitize_text_field($input['doughnut_loop_background']); }
    if (isset($input['doughnut_loop_border'])) { $settings['doughnut_loop_border'] = sanitize_text_field($input['doughnut_loop_border']); }
    if (isset($input['doughnut_chart_datasets'])) { $settings['doughnut_chart_datasets'] = $input['doughnut_chart_datasets']; }
    if (isset($input['loop_label'])) { $settings['loop_label'] = sanitize_text_field($input['loop_label']); }
    if (isset($input['bubble_data'])) { $settings['bubble_data'] = sanitize_text_field($input['bubble_data']); }
    if (isset($input['multi_dot_bg'])) { $settings['multi_dot_bg'] = sanitize_text_field($input['multi_dot_bg']); }
    if (isset($input['dot_bg'])) { $settings['dot_bg'] = sanitize_text_field($input['dot_bg']); }
    if (isset($input['multi_dot_bg_multiple'])) { $settings['multi_dot_bg_multiple'] = sanitize_text_field($input['multi_dot_bg_multiple']); }
    if (isset($input['multi_dot_border'])) { $settings['multi_dot_border'] = sanitize_text_field($input['multi_dot_border']); }
    if (isset($input['dot_border'])) { $settings['dot_border'] = sanitize_text_field($input['dot_border']); }
    if (isset($input['multi_dot_border_multiple'])) { $settings['multi_dot_border_multiple'] = sanitize_text_field($input['multi_dot_border_multiple']); }
    if (isset($input['bubble_content'])) { $settings['bubble_content'] = $input['bubble_content']; }
    if (isset($input['maxbarthickness'])) { $settings['maxbarthickness'] = $input['maxbarthickness']; }
    if (isset($input['barthickness'])) { $settings['barthickness'] = $input['barthickness']; }
    if (isset($input['show_grid_lines'])) { $settings['show_grid_lines'] = sanitize_text_field($input['show_grid_lines']); }
    if (isset($input['grid_color'])) { $settings['grid_color'] = sanitize_text_field($input['grid_color']); }
    if (isset($input['zero_linecolor_x'])) { $settings['zero_linecolor_x'] = sanitize_text_field($input['zero_linecolor_x']); }
    if (isset($input['draw_border_x'])) { $settings['draw_border_x'] = sanitize_text_field($input['draw_border_x']); }
    if (isset($input['draw_on_chart_area_x'])) { $settings['draw_on_chart_area_x'] = sanitize_text_field($input['draw_on_chart_area_x']); }
    if (isset($input['begin_atzero_x'])) { $settings['begin_atzero_x'] = sanitize_text_field($input['begin_atzero_x']); }
    if (isset($input['grid_color_xAxes'])) { $settings['grid_color_xAxes'] = sanitize_text_field($input['grid_color_xAxes']); }
    if (isset($input['zero_linecolor_y'])) { $settings['zero_linecolor_y'] = sanitize_text_field($input['zero_linecolor_y']); }
    if (isset($input['draw_border_y'])) { $settings['draw_border_y'] = sanitize_text_field($input['draw_border_y']); }
    if (isset($input['draw_on_chart_area_y'])) { $settings['draw_on_chart_area_y'] = sanitize_text_field($input['draw_on_chart_area_y']); }
    if (isset($input['begin_atzero_y'])) { $settings['begin_atzero_y'] = sanitize_text_field($input['begin_atzero_y']); }
    if (isset($input['show_legend'])) { $settings['show_legend'] = sanitize_text_field($input['show_legend']); }
    if (isset($input['show_legend_color'])) { $settings['show_legend_color'] = sanitize_text_field($input['show_legend_color']); }
    if (isset($input['show_legend_position'])) { $settings['show_legend_position'] = sanitize_text_field($input['show_legend_position']); }
    if (isset($input['show_legend_align'])) { $settings['show_legend_align'] = sanitize_text_field($input['show_legend_align']); }
    if (isset($input['show_legend_size'])) { $settings['show_legend_size'] = $input['show_legend_size']; }
    if (isset($input['custom_point_styles'])) { $settings['custom_point_styles'] = sanitize_text_field($input['custom_point_styles']); }
    if (isset($input['point_styles'])) { $settings['point_styles'] = sanitize_text_field($input['point_styles']); }
    if (isset($input['point_bg'])) { $settings['point_bg'] = sanitize_text_field($input['point_bg']); }
    if (isset($input['point_n_size'])) { $settings['point_n_size'] = $input['point_n_size']; }
    if (isset($input['point_h_size'])) { $settings['point_h_size'] = $input['point_h_size']; }
    if (isset($input['point_border_color'])) { $settings['point_border_color'] = sanitize_text_field($input['point_border_color']); }
    if (isset($input['point_border_width'])) { $settings['point_border_width'] = $input['point_border_width']; }
    if (isset($input['show_tooltip'])) { $settings['show_tooltip'] = sanitize_text_field($input['show_tooltip']); }
    if (isset($input['tooltip_event'])) { $settings['tooltip_event'] = sanitize_text_field($input['tooltip_event']); }
    if (isset($input['tooltip_font_size'])) { $settings['tooltip_font_size'] = $input['tooltip_font_size']; }
    if (isset($input['tooltip_color'])) { $settings['tooltip_color'] = sanitize_text_field($input['tooltip_color']); }
    if (isset($input['tooltip_body_color'])) { $settings['tooltip_body_color'] = sanitize_text_field($input['tooltip_body_color']); }
    if (isset($input['tooltip_bg'])) { $settings['tooltip_bg'] = sanitize_text_field($input['tooltip_bg']); }
    if (isset($input['tension'])) { $settings['tension'] = sanitize_text_field($input['tension']); }
    if (isset($input['aspect_ratio'])) { $settings['aspect_ratio'] = sanitize_text_field($input['aspect_ratio']); }
    if (isset($input['maintain_aspect_ratio'])) { $settings['maintain_aspect_ratio'] = sanitize_text_field($input['maintain_aspect_ratio']); }
    if (isset($input['c_animation'])) { $settings['c_animation'] = sanitize_text_field($input['c_animation']); }
    if (isset($input['c_animation_duration'])) { $settings['c_animation_duration'] = $input['c_animation_duration']; }
    if (isset($input['chartwidth'])) { $settings['chartwidth'] = $input['chartwidth']; }
    if (isset($input['chartheight'])) { $settings['chartheight'] = $input['chartheight']; }
    if (isset($input['chart_alignment'])) { $settings['chart_alignment'] = $input['chart_alignment']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
