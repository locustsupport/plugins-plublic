<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-off-canvas', [
'label' => __('Off Canvas', 'theplus'),
    'description' => __('Adds The Plus "Off Canvas" widget (tp-off-canvas) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'content_open_style' => ['type' => 'string', 'description' => 'content_open_style', 'enum' => ['columns', 'corner-box', 'popup', 'reveal', 'slide']],
        'content_open_direction_popup' => ['type' => 'string', 'description' => 'Open Direction', 'enum' => ['bottom-center', 'bottom-left', 'bottom-right', 'center', 'content_open_style', 'left', 'right', 'top-center', 'top-left', 'top-right']],
        'content_open_height' => ['type' => 'object', 'description' => 'Open Height (Slider/Size Object)'],
        'content_open_direction' => ['type' => 'string', 'description' => 'Open Direction', 'enum' => ['bottom', 'content_open_style!', 'left', 'right', 'top']],
        'content_open_corner_box_direction' => ['type' => 'string', 'description' => 'Corner Box Direction', 'enum' => ['content_open_style', 'top-left', 'top-right']],
        'content_open_width' => ['type' => 'object', 'description' => 'Open Width (Slider/Size Object)'],
        'content_open_popup_width' => ['type' => 'object', 'description' => 'Popup Width (Slider/Size Object)'],
        'content_open_popup_height' => ['type' => 'object', 'description' => 'Popup Height (Slider/Size Object)'],
        'content_open_left_right_padding' => ['type' => 'object', 'description' => 'Popup Left/Right Space (Slider/Size Object)'],
        'content_open_top_botton_padding' => ['type' => 'object', 'description' => 'Popup Top/Bottom Space (Slider/Size Object)'],
        'content_template_type' => ['type' => 'string', 'description' => 'Content Type', 'enum' => ['tp-content', 'tp-manually', 'tp-template']],
        'content_template' => ['type' => 'string', 'description' => 'content_template', 'enum' => ['content_template_type']],
        'content_description' => ['type' => 'string', 'description' => 'Content'],
        'content_template_id' => ['type' => 'string', 'description' => 'Enter Elementor Template Shortcode'],
        'select_toggle_canvas' => ['type' => 'string', 'description' => 'Select Option', 'enum' => ['button', 'hide', 'icon', 'lottie']],
        'toggle_icon_style' => ['type' => 'string', 'description' => 'Icon Style', 'enum' => ['custom', 'select_toggle_canvas', 'style-1', 'style-2', 'style-3']],
        'image_svg_icn' => ['type' => 'integer', 'description' => 'Choose Image/SVG (Image ID)'],
        'toggle_img_svg_size' => ['type' => 'object', 'description' => 'Image/Svg Size (Slider/Size Object)'],
        'toggle_icon_size' => ['type' => 'object', 'description' => 'Icon Width (Slider/Size Object)'],
        'toggle_icon_weight' => ['type' => 'object', 'description' => 'Icon Weight (Slider/Size Object)'],
        'toggle_icon_padding' => ['type' => 'object', 'description' => 'Icon Padding (Dimensions Object)'],
        'button_text' => ['type' => 'string', 'description' => 'Button Text'],
        'button_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['font_awesome', 'font_awesome_5', 'icon_mind', 'none', 'select_toggle_canvas']],
        'icon_fs_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome', 'enum' => ['yes', 'no']],
        'button_icon' => ['type' => 'string', 'description' => 'Select Icon'],
        'icon_f5_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome 5', 'enum' => ['yes', 'no']],
        'button_icon_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'icon_mind_popover_toggle' => ['type' => 'string', 'description' => 'Icons Mind', 'enum' => ['yes', 'no']],
        'button_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['button_icon_style', 'select_toggle_canvas']],
        'button_before_after' => ['type' => 'string', 'description' => 'Icon Position', 'enum' => ['after', 'before', 'button_icon_style!', 'select_toggle_canvas']],
        'button_icon_spacing' => ['type' => 'object', 'description' => 'Icon Spacing (Slider/Size Object)'],
        'button_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'lottieUrl' => ['type' => 'object', 'description' => 'Lottie URL'],
        'button_align' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'devices', 'icon', 'left', 'prefix_class', 'right', 'select_toggle_canvas!']],
        'event_esc_close_content' => ['type' => 'string', 'description' => 'Esc Button Close Content', 'enum' => ['yes', 'no']],
        'event_body_click_close_content' => ['type' => 'string', 'description' => 'Outer Click Close Content', 'enum' => ['yes', 'no']],
        'click_offcanvas_close' => ['type' => 'string', 'description' => 'On Click Link Popup Close', 'enum' => ['yes', 'no']],
        'fixed_toggle_button' => ['type' => 'string', 'description' => 'Fixed Toggle Button', 'enum' => ['yes', 'no']],
        'show_scroll_window_offset' => ['type' => 'string', 'description' => 'Show Menu Scroll Offset', 'enum' => ['yes', 'no']],
        'scroll_top_offset_value' => ['type' => 'object', 'description' => 'Scroll Top Offset Value (Slider/Size Object)'],
        'd_left_auto' => ['type' => 'string', 'description' => 'Left (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_xposition' => ['type' => 'object', 'description' => 'Left (Slider/Size Object)'],
        'd_right_auto' => ['type' => 'string', 'description' => 'Right (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_rightposition' => ['type' => 'object', 'description' => 'Right (Slider/Size Object)'],
        'd_top_auto' => ['type' => 'string', 'description' => 'Top (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_yposition' => ['type' => 'object', 'description' => 'Top (Slider/Size Object)'],
        'd_bottom_auto' => ['type' => 'string', 'description' => 'Bottom (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_bottomposition' => ['type' => 'object', 'description' => 'Bottom (Slider/Size Object)'],
        'contentextraeffect' => ['type' => 'string', 'description' => 'Content Transform', 'enum' => ['yes', 'no']],
        'contentextraeffectrotatex' => ['type' => 'object', 'description' => 'Rotate X (Slider/Size Object)'],
        'contentextraeffectrotatey' => ['type' => 'object', 'description' => 'Rotate Y (Slider/Size Object)'],
        'contentextraeffecttranslatex' => ['type' => 'object', 'description' => 'Translate X (Slider/Size Object)'],
        'contentextraeffecttranslatey' => ['type' => 'object', 'description' => 'Translate Y (Slider/Size Object)'],
        'contentextraeffectsacle' => ['type' => 'object', 'description' => 'Scale (Slider/Size Object)'],
        'contentextraeffectbg' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'popinanimation' => ['type' => 'string', 'description' => 'In Animation', 'enum' => ['content_open_style', 'fadeIn', 'fadeInBottomLeft', 'fadeInBottomRight', 'fadeInDown', 'fadeInDownBig', 'fadeInLeft', 'fadeInLeftBig', 'fadeInRight', 'fadeInRightBig', 'fadeInTopLeft', 'fadeInTopRight', 'fadeInUp', 'fadeInUpBig', 'flipInX', 'flipInY', 'none', 'slideInDown', 'slideInLeft', 'slideInRight', 'slideInUp', 'zoomIn']],
        'popoutanimation' => ['type' => 'string', 'description' => 'Out Animation', 'enum' => ['content_open_style', 'fadeOut', 'fadeOutBottomLeft', 'fadeOutBottomRight', 'fadeOutDown', 'fadeOutDownBig', 'fadeOutLeft', 'fadeOutLeftBig', 'fadeOutRight', 'fadeOutRightBig', 'fadeOutTopLeft', 'fadeOutTopRight', 'fadeOutUp', 'fadeOutUpBig', 'flipOutX', 'flipOutY', 'none', 'slideOutDown', 'slideOutLeft', 'slideOutRight', 'slideOutUp', 'zoomOut']],
        'popoutanimationdelay' => ['type' => 'string', 'description' => 'Delay', 'enum' => ['content_open_style', 'delay-1s', 'delay-2s', 'delay-3s', 'delay-4s', 'delay-5s', 'none']],
        'popoutanimationspeed' => ['type' => 'string', 'description' => 'Speed', 'enum' => ['content_open_style', 'fast', 'faster', 'none', 'slow', 'slower']],
        't_responsive' => ['type' => 'string', 'description' => 'Responsive Values', 'enum' => ['yes', 'no']],
        't_left_auto' => ['type' => 'string', 'description' => 'Left (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_xposition' => ['type' => 'object', 'description' => 'Left (Slider/Size Object)'],
        't_right_auto' => ['type' => 'string', 'description' => 'Right (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_rightposition' => ['type' => 'object', 'description' => 'Right (Slider/Size Object)'],
        't_top_auto' => ['type' => 'string', 'description' => 'Top (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_yposition' => ['type' => 'object', 'description' => 'Top (Slider/Size Object)'],
        't_bottom_auto' => ['type' => 'string', 'description' => 'Bottom (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_bottomposition' => ['type' => 'object', 'description' => 'Bottom (Slider/Size Object)'],
        'm_responsive' => ['type' => 'string', 'description' => 'Responsive Values', 'enum' => ['yes', 'no']],
        'm_left_auto' => ['type' => 'string', 'description' => 'Left (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_xposition' => ['type' => 'object', 'description' => 'Left (Slider/Size Object)'],
        'm_right_auto' => ['type' => 'string', 'description' => 'Right (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_rightposition' => ['type' => 'object', 'description' => 'Right (Slider/Size Object)'],
        'm_top_auto' => ['type' => 'string', 'description' => 'Top (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_yposition' => ['type' => 'object', 'description' => 'Top (Slider/Size Object)'],
        'm_bottom_auto' => ['type' => 'string', 'description' => 'Bottom (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_bottomposition' => ['type' => 'object', 'description' => 'Bottom (Slider/Size Object)'],
        'pageload' => ['type' => 'string', 'description' => 'On Page Load', 'enum' => ['yes', 'no']],
        'exit' => ['type' => 'string', 'description' => 'On Exit Intent', 'enum' => ['yes', 'no']],
        'scroll' => ['type' => 'string', 'description' => 'On Scroll', 'enum' => ['yes', 'no']],
        'scrollHeight' => ['type' => 'object', 'description' => 'Scroll Offset (PX)L (Slider/Size Object)'],
        'inactivity' => ['type' => 'string', 'description' => 'After Inactivity', 'enum' => ['yes', 'no']],
        'inactivitySec' => ['type' => 'string', 'description' => 'Inactivity MilliSecond'],
        'pageviews' => ['type' => 'string', 'description' => 'After X Page Views', 'enum' => ['yes', 'no']],
        'pageViewsCount' => ['type' => 'string', 'description' => 'Page View Count'],
        'prevurl' => ['type' => 'string', 'description' => 'Arriving From Specific URL', 'enum' => ['yes', 'no']],
        'previousUrl' => ['type' => 'object', 'description' => 'Source URL'],
        'extraclick' => ['type' => 'string', 'description' => 'On Any Other Element`s Click', 'enum' => ['yes', 'no']],
        'extraId' => ['type' => 'string', 'description' => 'Unique Class (Open)'],
        'extraIdClose' => ['type' => 'string', 'description' => 'Unique Class (Close)'],
        'showTime' => ['type' => 'string', 'description' => 'Show For Specific Time', 'enum' => ['yes', 'no']],
        'dateStart' => ['type' => 'string', 'description' => 'Start Date'],
        'dateEnd' => ['type' => 'string', 'description' => 'End Date'],
        'showRestricted' => ['type' => 'string', 'description' => 'Show X Times per User', 'enum' => ['yes', 'no']],
        'showXTimes' => ['type' => 'string', 'description' => 'Number of Times'],
        'showXDays' => ['type' => 'string', 'description' => 'Inactive Days'],
        'tpaep_theme_builder' => ['type' => 'string', 'description' => 'tpaep_theme_builder'],
        'open_content_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'content_color' => ['type' => 'string', 'description' => 'Content Text Color (Color Hex/RGBA)'],
        'open_content_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'open_content_close_icon_display' => ['type' => 'string', 'description' => 'Display Close Icon', 'enum' => ['yes', 'no']],
        'close_icon_color' => ['type' => 'string', 'description' => 'Close Icon Color (Color Hex/RGBA)'],
        'close_image_custom' => ['type' => 'string', 'description' => 'Custom Close Icon', 'enum' => ['yes', 'no']],
        'close_image_custom_source' => ['type' => 'integer', 'description' => 'Choose Image (Image ID)'],
        'open_content_close_icon_align' => ['type' => 'string', 'description' => 'Icon Alignment', 'enum' => ['icon', 'left', 'open_content_close_icon_display', 'right', 'toggle']],
        'open_content_close_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'off_cus_close_img' => ['type' => 'object', 'description' => 'Close Image Size (Slider/Size Object)'],
        'open_content_close_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'open_content_close_hover_color' => ['type' => 'string', 'description' => 'Icon Hover Color (Color Hex/RGBA)'],
        'open_content_close_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'open_content_overflow' => ['type' => 'string', 'description' => 'Overflow', 'enum' => ['yes', 'no']],
        'icon_border' => ['type' => 'string', 'description' => 'Border', 'enum' => ['yes', 'no']],
        'icon_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['dashed', 'dotted', 'groove', 'icon_border', 'none', 'solid', '{{WRAPPER}} .plus-offcanvas-wrapper .offcanvas-toggle-btn.humberger-style-1,{{WRAPPER}} .plus-offcanvas-wrapper .offcanvas-toggle-btn.humberger-style-2,{{WRAPPER}} .plus-offcanvas-wrapper .offcanvas-toggle-btn.humberger-style-3,
					{{WRAPPER}} .plus-offcanvas-wrapper .offcanvas-toggle-btn.humberger-custom .off-can-img-svg']],
        'icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'icon_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'icon_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'icon_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'icon_hover_color' => ['type' => 'string', 'description' => 'Icon Hover Color (Color Hex/RGBA)'],
        'icon_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'icon_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        'button_full_width' => ['type' => 'string', 'description' => 'Full Width Button', 'enum' => ['yes', 'no']],
        'button_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'button_border' => ['type' => 'string', 'description' => 'Border', 'enum' => ['yes', 'no']],
        'button_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['button_border', 'dashed', 'dotted', 'groove', 'none', 'solid', '{{WRAPPER}} .plus-offcanvas-wrapper .offcanvas-toggle-btn']],
        'button_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'button_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'button_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'button_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'button_text_hover_color' => ['type' => 'string', 'description' => 'Text Hover Color (Color Hex/RGBA)'],
        'button_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'button_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        'lottiedisplay' => ['type' => 'string', 'description' => 'Display', 'enum' => ['block', 'flex', 'inherit', 'initial', 'inline-block', 'inline-flex']],
        'lottieWidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'lottieHeight' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'lottieSpeed' => ['type' => 'object', 'description' => 'Speed (Slider/Size Object)'],
        'lottieLoop' => ['type' => 'string', 'description' => 'Loop Animation', 'enum' => ['yes', 'no']],
        'lottiehover' => ['type' => 'string', 'description' => 'Hover Animation', 'enum' => ['yes', 'no']],
        'display_scrolling_bar' => ['type' => 'string', 'description' => 'Content Scrolling Bar', 'enum' => ['yes', 'no']],
        'scroll_scrollbar_width' => ['type' => 'object', 'description' => 'ScrollBar Width (Slider/Size Object)'],
        'scroll_scrollbar_height' => ['type' => 'object', 'description' => 'ScrollBar Height (Slider/Size Object)'],
        'scroll_thumb_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'scroll_track_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'sn_button_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'sn_button_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'sn_icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'sn_icon_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'sn_button_text_hover_color' => ['type' => 'string', 'description' => 'Text Hover Color (Color Hex/RGBA)'],
        'sn_button_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'sn_icon_hover_color' => ['type' => 'string', 'description' => 'Icon Hover Color (Color Hex/RGBA)'],
        'sn_icon_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports multi-trigger rules, hover effects, and CSS filters.']
    ], 'required' => ['post_id', 'parent_id', 'content_open_style'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_off_canvas_ability',
    'permission_callback' => 'tpaep_mcp_theplus_off_canvas_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_off_canvas_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_off_canvas_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-off-canvas';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Off Canvas widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['content_open_style'])) { $settings['content_open_style'] = sanitize_text_field($input['content_open_style']); }
    if (isset($input['content_open_direction_popup'])) { $settings['content_open_direction_popup'] = sanitize_text_field($input['content_open_direction_popup']); }
    if (isset($input['content_open_height'])) { $settings['content_open_height'] = $input['content_open_height']; }
    if (isset($input['content_open_direction'])) { $settings['content_open_direction'] = sanitize_text_field($input['content_open_direction']); }
    if (isset($input['content_open_corner_box_direction'])) { $settings['content_open_corner_box_direction'] = sanitize_text_field($input['content_open_corner_box_direction']); }
    if (isset($input['content_open_width'])) { $settings['content_open_width'] = $input['content_open_width']; }
    if (isset($input['content_open_popup_width'])) { $settings['content_open_popup_width'] = $input['content_open_popup_width']; }
    if (isset($input['content_open_popup_height'])) { $settings['content_open_popup_height'] = $input['content_open_popup_height']; }
    if (isset($input['content_open_left_right_padding'])) { $settings['content_open_left_right_padding'] = $input['content_open_left_right_padding']; }
    if (isset($input['content_open_top_botton_padding'])) { $settings['content_open_top_botton_padding'] = $input['content_open_top_botton_padding']; }
    if (isset($input['content_template_type'])) { $settings['content_template_type'] = sanitize_text_field($input['content_template_type']); }
    if (isset($input['content_template'])) { $settings['content_template'] = sanitize_text_field($input['content_template']); }
    if (isset($input['content_description'])) { $settings['content_description'] = sanitize_text_field($input['content_description']); }
    if (isset($input['content_template_id'])) { $settings['content_template_id'] = sanitize_text_field($input['content_template_id']); }
    if (isset($input['select_toggle_canvas'])) { $settings['select_toggle_canvas'] = sanitize_text_field($input['select_toggle_canvas']); }
    if (isset($input['toggle_icon_style'])) { $settings['toggle_icon_style'] = sanitize_text_field($input['toggle_icon_style']); }
    if (!empty($input['image_svg_icn'])) { $settings['image_svg_icn'] = ['id' => absint($input['image_svg_icn'])]; }
    if (isset($input['toggle_img_svg_size'])) { $settings['toggle_img_svg_size'] = $input['toggle_img_svg_size']; }
    if (isset($input['toggle_icon_size'])) { $settings['toggle_icon_size'] = $input['toggle_icon_size']; }
    if (isset($input['toggle_icon_weight'])) { $settings['toggle_icon_weight'] = $input['toggle_icon_weight']; }
    if (isset($input['toggle_icon_padding'])) { $settings['toggle_icon_padding'] = $input['toggle_icon_padding']; }
    if (isset($input['button_text'])) { $settings['button_text'] = sanitize_text_field($input['button_text']); }
    if (isset($input['button_icon_style'])) { $settings['button_icon_style'] = sanitize_text_field($input['button_icon_style']); }
    if (isset($input['icon_fs_popover_toggle'])) { $settings['icon_fs_popover_toggle'] = sanitize_text_field($input['icon_fs_popover_toggle']); }
    if (isset($input['button_icon'])) { $settings['button_icon'] = sanitize_text_field($input['button_icon']); }
    if (isset($input['icon_f5_popover_toggle'])) { $settings['icon_f5_popover_toggle'] = sanitize_text_field($input['icon_f5_popover_toggle']); }
    if (isset($input['button_icon_5'])) { $settings['button_icon_5'] = sanitize_text_field($input['button_icon_5']); }
    if (isset($input['icon_mind_popover_toggle'])) { $settings['icon_mind_popover_toggle'] = sanitize_text_field($input['icon_mind_popover_toggle']); }
    if (isset($input['button_icons_mind'])) { $settings['button_icons_mind'] = sanitize_text_field($input['button_icons_mind']); }
    if (isset($input['button_before_after'])) { $settings['button_before_after'] = sanitize_text_field($input['button_before_after']); }
    if (isset($input['button_icon_spacing'])) { $settings['button_icon_spacing'] = $input['button_icon_spacing']; }
    if (isset($input['button_icon_size'])) { $settings['button_icon_size'] = $input['button_icon_size']; }
    if (isset($input['lottieUrl'])) { $settings['lottieUrl'] = $input['lottieUrl']; }
    if (isset($input['button_align'])) { $settings['button_align'] = $input['button_align']; }
    if (isset($input['event_esc_close_content'])) { $settings['event_esc_close_content'] = sanitize_text_field($input['event_esc_close_content']); }
    if (isset($input['event_body_click_close_content'])) { $settings['event_body_click_close_content'] = sanitize_text_field($input['event_body_click_close_content']); }
    if (isset($input['click_offcanvas_close'])) { $settings['click_offcanvas_close'] = sanitize_text_field($input['click_offcanvas_close']); }
    if (isset($input['fixed_toggle_button'])) { $settings['fixed_toggle_button'] = sanitize_text_field($input['fixed_toggle_button']); }
    if (isset($input['show_scroll_window_offset'])) { $settings['show_scroll_window_offset'] = sanitize_text_field($input['show_scroll_window_offset']); }
    if (isset($input['scroll_top_offset_value'])) { $settings['scroll_top_offset_value'] = $input['scroll_top_offset_value']; }
    if (isset($input['d_left_auto'])) { $settings['d_left_auto'] = sanitize_text_field($input['d_left_auto']); }
    if (isset($input['d_pos_xposition'])) { $settings['d_pos_xposition'] = $input['d_pos_xposition']; }
    if (isset($input['d_right_auto'])) { $settings['d_right_auto'] = sanitize_text_field($input['d_right_auto']); }
    if (isset($input['d_pos_rightposition'])) { $settings['d_pos_rightposition'] = $input['d_pos_rightposition']; }
    if (isset($input['d_top_auto'])) { $settings['d_top_auto'] = sanitize_text_field($input['d_top_auto']); }
    if (isset($input['d_pos_yposition'])) { $settings['d_pos_yposition'] = $input['d_pos_yposition']; }
    if (isset($input['d_bottom_auto'])) { $settings['d_bottom_auto'] = sanitize_text_field($input['d_bottom_auto']); }
    if (isset($input['d_pos_bottomposition'])) { $settings['d_pos_bottomposition'] = $input['d_pos_bottomposition']; }
    if (isset($input['contentextraeffect'])) { $settings['contentextraeffect'] = sanitize_text_field($input['contentextraeffect']); }
    if (isset($input['contentextraeffectrotatex'])) { $settings['contentextraeffectrotatex'] = $input['contentextraeffectrotatex']; }
    if (isset($input['contentextraeffectrotatey'])) { $settings['contentextraeffectrotatey'] = $input['contentextraeffectrotatey']; }
    if (isset($input['contentextraeffecttranslatex'])) { $settings['contentextraeffecttranslatex'] = $input['contentextraeffecttranslatex']; }
    if (isset($input['contentextraeffecttranslatey'])) { $settings['contentextraeffecttranslatey'] = $input['contentextraeffecttranslatey']; }
    if (isset($input['contentextraeffectsacle'])) { $settings['contentextraeffectsacle'] = $input['contentextraeffectsacle']; }
    if (isset($input['contentextraeffectbg'])) { $settings['contentextraeffectbg'] = sanitize_text_field($input['contentextraeffectbg']); }
    if (isset($input['popinanimation'])) { $settings['popinanimation'] = sanitize_text_field($input['popinanimation']); }
    if (isset($input['popoutanimation'])) { $settings['popoutanimation'] = sanitize_text_field($input['popoutanimation']); }
    if (isset($input['popoutanimationdelay'])) { $settings['popoutanimationdelay'] = sanitize_text_field($input['popoutanimationdelay']); }
    if (isset($input['popoutanimationspeed'])) { $settings['popoutanimationspeed'] = sanitize_text_field($input['popoutanimationspeed']); }
    if (isset($input['t_responsive'])) { $settings['t_responsive'] = sanitize_text_field($input['t_responsive']); }
    if (isset($input['t_left_auto'])) { $settings['t_left_auto'] = sanitize_text_field($input['t_left_auto']); }
    if (isset($input['t_pos_xposition'])) { $settings['t_pos_xposition'] = $input['t_pos_xposition']; }
    if (isset($input['t_right_auto'])) { $settings['t_right_auto'] = sanitize_text_field($input['t_right_auto']); }
    if (isset($input['t_pos_rightposition'])) { $settings['t_pos_rightposition'] = $input['t_pos_rightposition']; }
    if (isset($input['t_top_auto'])) { $settings['t_top_auto'] = sanitize_text_field($input['t_top_auto']); }
    if (isset($input['t_pos_yposition'])) { $settings['t_pos_yposition'] = $input['t_pos_yposition']; }
    if (isset($input['t_bottom_auto'])) { $settings['t_bottom_auto'] = sanitize_text_field($input['t_bottom_auto']); }
    if (isset($input['t_pos_bottomposition'])) { $settings['t_pos_bottomposition'] = $input['t_pos_bottomposition']; }
    if (isset($input['m_responsive'])) { $settings['m_responsive'] = sanitize_text_field($input['m_responsive']); }
    if (isset($input['m_left_auto'])) { $settings['m_left_auto'] = sanitize_text_field($input['m_left_auto']); }
    if (isset($input['m_pos_xposition'])) { $settings['m_pos_xposition'] = $input['m_pos_xposition']; }
    if (isset($input['m_right_auto'])) { $settings['m_right_auto'] = sanitize_text_field($input['m_right_auto']); }
    if (isset($input['m_pos_rightposition'])) { $settings['m_pos_rightposition'] = $input['m_pos_rightposition']; }
    if (isset($input['m_top_auto'])) { $settings['m_top_auto'] = sanitize_text_field($input['m_top_auto']); }
    if (isset($input['m_pos_yposition'])) { $settings['m_pos_yposition'] = $input['m_pos_yposition']; }
    if (isset($input['m_bottom_auto'])) { $settings['m_bottom_auto'] = sanitize_text_field($input['m_bottom_auto']); }
    if (isset($input['m_pos_bottomposition'])) { $settings['m_pos_bottomposition'] = $input['m_pos_bottomposition']; }
    if (isset($input['pageload'])) { $settings['pageload'] = sanitize_text_field($input['pageload']); }
    if (isset($input['exit'])) { $settings['exit'] = sanitize_text_field($input['exit']); }
    if (isset($input['scroll'])) { $settings['scroll'] = sanitize_text_field($input['scroll']); }
    if (isset($input['scrollHeight'])) { $settings['scrollHeight'] = $input['scrollHeight']; }
    if (isset($input['inactivity'])) { $settings['inactivity'] = sanitize_text_field($input['inactivity']); }
    if (isset($input['inactivitySec'])) { $settings['inactivitySec'] = sanitize_text_field($input['inactivitySec']); }
    if (isset($input['pageviews'])) { $settings['pageviews'] = sanitize_text_field($input['pageviews']); }
    if (isset($input['pageViewsCount'])) { $settings['pageViewsCount'] = sanitize_text_field($input['pageViewsCount']); }
    if (isset($input['prevurl'])) { $settings['prevurl'] = sanitize_text_field($input['prevurl']); }
    if (isset($input['previousUrl'])) { $settings['previousUrl'] = $input['previousUrl']; }
    if (isset($input['extraclick'])) { $settings['extraclick'] = sanitize_text_field($input['extraclick']); }
    if (isset($input['extraId'])) { $settings['extraId'] = sanitize_text_field($input['extraId']); }
    if (isset($input['extraIdClose'])) { $settings['extraIdClose'] = sanitize_text_field($input['extraIdClose']); }
    if (isset($input['showTime'])) { $settings['showTime'] = sanitize_text_field($input['showTime']); }
    if (isset($input['dateStart'])) { $settings['dateStart'] = sanitize_text_field($input['dateStart']); }
    if (isset($input['dateEnd'])) { $settings['dateEnd'] = sanitize_text_field($input['dateEnd']); }
    if (isset($input['showRestricted'])) { $settings['showRestricted'] = sanitize_text_field($input['showRestricted']); }
    if (isset($input['showXTimes'])) { $settings['showXTimes'] = sanitize_text_field($input['showXTimes']); }
    if (isset($input['showXDays'])) { $settings['showXDays'] = sanitize_text_field($input['showXDays']); }
    if (isset($input['tpaep_theme_builder'])) { $settings['tpaep_theme_builder'] = sanitize_text_field($input['tpaep_theme_builder']); }
    if (isset($input['open_content_padding'])) { $settings['open_content_padding'] = $input['open_content_padding']; }
    if (isset($input['content_color'])) { $settings['content_color'] = sanitize_text_field($input['content_color']); }
    if (isset($input['open_content_radius'])) { $settings['open_content_radius'] = $input['open_content_radius']; }
    if (isset($input['open_content_close_icon_display'])) { $settings['open_content_close_icon_display'] = sanitize_text_field($input['open_content_close_icon_display']); }
    if (isset($input['close_icon_color'])) { $settings['close_icon_color'] = sanitize_text_field($input['close_icon_color']); }
    if (isset($input['close_image_custom'])) { $settings['close_image_custom'] = sanitize_text_field($input['close_image_custom']); }
    if (!empty($input['close_image_custom_source'])) { $settings['close_image_custom_source'] = ['id' => absint($input['close_image_custom_source'])]; }
    if (isset($input['open_content_close_icon_align'])) { $settings['open_content_close_icon_align'] = sanitize_text_field($input['open_content_close_icon_align']); }
    if (isset($input['open_content_close_color'])) { $settings['open_content_close_color'] = sanitize_text_field($input['open_content_close_color']); }
    if (isset($input['off_cus_close_img'])) { $settings['off_cus_close_img'] = $input['off_cus_close_img']; }
    if (isset($input['open_content_close_radius'])) { $settings['open_content_close_radius'] = $input['open_content_close_radius']; }
    if (isset($input['open_content_close_hover_color'])) { $settings['open_content_close_hover_color'] = sanitize_text_field($input['open_content_close_hover_color']); }
    if (isset($input['open_content_close_hover_radius'])) { $settings['open_content_close_hover_radius'] = $input['open_content_close_hover_radius']; }
    if (isset($input['open_content_overflow'])) { $settings['open_content_overflow'] = sanitize_text_field($input['open_content_overflow']); }
    if (isset($input['icon_border'])) { $settings['icon_border'] = sanitize_text_field($input['icon_border']); }
    if (isset($input['icon_border_style'])) { $settings['icon_border_style'] = sanitize_text_field($input['icon_border_style']); }
    if (isset($input['icon_color'])) { $settings['icon_color'] = sanitize_text_field($input['icon_color']); }
    if (isset($input['icon_border_width'])) { $settings['icon_border_width'] = $input['icon_border_width']; }
    if (isset($input['icon_border_color'])) { $settings['icon_border_color'] = sanitize_text_field($input['icon_border_color']); }
    if (isset($input['icon_radius'])) { $settings['icon_radius'] = $input['icon_radius']; }
    if (isset($input['icon_hover_color'])) { $settings['icon_hover_color'] = sanitize_text_field($input['icon_hover_color']); }
    if (isset($input['icon_border_hover_color'])) { $settings['icon_border_hover_color'] = sanitize_text_field($input['icon_border_hover_color']); }
    if (isset($input['icon_hover_radius'])) { $settings['icon_hover_radius'] = $input['icon_hover_radius']; }
    if (isset($input['button_full_width'])) { $settings['button_full_width'] = sanitize_text_field($input['button_full_width']); }
    if (isset($input['button_padding'])) { $settings['button_padding'] = $input['button_padding']; }
    if (isset($input['button_border'])) { $settings['button_border'] = sanitize_text_field($input['button_border']); }
    if (isset($input['button_border_style'])) { $settings['button_border_style'] = sanitize_text_field($input['button_border_style']); }
    if (isset($input['button_text_color'])) { $settings['button_text_color'] = sanitize_text_field($input['button_text_color']); }
    if (isset($input['button_border_width'])) { $settings['button_border_width'] = $input['button_border_width']; }
    if (isset($input['button_border_color'])) { $settings['button_border_color'] = sanitize_text_field($input['button_border_color']); }
    if (isset($input['button_radius'])) { $settings['button_radius'] = $input['button_radius']; }
    if (isset($input['button_text_hover_color'])) { $settings['button_text_hover_color'] = sanitize_text_field($input['button_text_hover_color']); }
    if (isset($input['button_border_hover_color'])) { $settings['button_border_hover_color'] = sanitize_text_field($input['button_border_hover_color']); }
    if (isset($input['button_hover_radius'])) { $settings['button_hover_radius'] = $input['button_hover_radius']; }
    if (isset($input['lottiedisplay'])) { $settings['lottiedisplay'] = sanitize_text_field($input['lottiedisplay']); }
    if (isset($input['lottieWidth'])) { $settings['lottieWidth'] = $input['lottieWidth']; }
    if (isset($input['lottieHeight'])) { $settings['lottieHeight'] = $input['lottieHeight']; }
    if (isset($input['lottieSpeed'])) { $settings['lottieSpeed'] = $input['lottieSpeed']; }
    if (isset($input['lottieLoop'])) { $settings['lottieLoop'] = sanitize_text_field($input['lottieLoop']); }
    if (isset($input['lottiehover'])) { $settings['lottiehover'] = sanitize_text_field($input['lottiehover']); }
    if (isset($input['display_scrolling_bar'])) { $settings['display_scrolling_bar'] = sanitize_text_field($input['display_scrolling_bar']); }
    if (isset($input['scroll_scrollbar_width'])) { $settings['scroll_scrollbar_width'] = $input['scroll_scrollbar_width']; }
    if (isset($input['scroll_scrollbar_height'])) { $settings['scroll_scrollbar_height'] = $input['scroll_scrollbar_height']; }
    if (isset($input['scroll_thumb_border_radius'])) { $settings['scroll_thumb_border_radius'] = $input['scroll_thumb_border_radius']; }
    if (isset($input['scroll_track_border_radius'])) { $settings['scroll_track_border_radius'] = $input['scroll_track_border_radius']; }
    if (isset($input['sn_button_text_color'])) { $settings['sn_button_text_color'] = sanitize_text_field($input['sn_button_text_color']); }
    if (isset($input['sn_button_border_color'])) { $settings['sn_button_border_color'] = sanitize_text_field($input['sn_button_border_color']); }
    if (isset($input['sn_icon_color'])) { $settings['sn_icon_color'] = sanitize_text_field($input['sn_icon_color']); }
    if (isset($input['sn_icon_border_color'])) { $settings['sn_icon_border_color'] = sanitize_text_field($input['sn_icon_border_color']); }
    if (isset($input['sn_button_text_hover_color'])) { $settings['sn_button_text_hover_color'] = sanitize_text_field($input['sn_button_text_hover_color']); }
    if (isset($input['sn_button_border_hover_color'])) { $settings['sn_button_border_hover_color'] = sanitize_text_field($input['sn_button_border_hover_color']); }
    if (isset($input['sn_icon_hover_color'])) { $settings['sn_icon_hover_color'] = sanitize_text_field($input['sn_icon_hover_color']); }
    if (isset($input['sn_icon_border_hover_color'])) { $settings['sn_icon_border_hover_color'] = sanitize_text_field($input['sn_icon_border_hover_color']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
