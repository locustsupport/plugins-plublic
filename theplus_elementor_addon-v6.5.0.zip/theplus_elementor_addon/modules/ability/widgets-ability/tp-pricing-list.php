<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-pricing-list', [
'label' => __('Pricing List', 'theplus'),
    'description' => __('Adds The Plus "Pricing List" widget (tp-pricing-list) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'menu_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'style_1', 'style_2', 'style_3']],
        'title' => ['type' => 'string', 'description' => 'Title'],
        'title_tag' => ['type' => 'string', 'description' => 'Tag'],
        'price' => ['type' => 'string', 'description' => 'Price'],
        'content' => ['type' => 'string', 'description' => 'Description'],
        'icon_type' => ['type' => 'string', 'description' => 'Icon Type', 'enum' => ['lottie', 'menu_style']],
        'image_option' => ['type' => 'integer', 'description' => 'Image (Image ID)'],
        'imglotti_right_space' => ['type' => 'object', 'description' => 'Right Space (Slider/Size Object)'],
        'img_shape' => ['type' => 'string', 'description' => 'Image Shape', 'enum' => ['icon_type', 'img-circle', 'img-rounded', 'menu_style', 'none']],
        'lottieUrl' => ['type' => 'object', 'description' => 'Lottie URL'],
        'box_align' => ['type' => 'string', 'description' => 'Box Align', 'enum' => ['menu_style', 'text-center', 'text-left', 'text-right']],
        'box_align_top' => ['type' => 'string', 'description' => 'Box Align', 'enum' => ['bottom-left', 'bottom-right', 'menu_style', 'top-left', 'top-right']],
        'title_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'title_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'title_border' => ['type' => 'string', 'description' => 'Border', 'enum' => ['yes', 'no']],
        'border_style' => ['type' => 'string', 'description' => 'Border', 'enum' => ['title_border', '{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-menu-title']],
        'bd_title_height' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'title_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'bd_title_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'border_line_style' => ['type' => 'string', 'description' => 'Line Type', 'enum' => ['yes', 'no']],
        'line_style' => ['type' => 'string', 'description' => 'Line', 'enum' => ['border_line_style', '{{WRAPPER}} .pt-plus-food-menu.food-menu-style-3 .food-flex-line .food-menu-divider .menu-divider']],
        'bd_line_height' => ['type' => 'object', 'description' => 'Line Width (Dimensions Object)'],
        'bd_line_color' => ['type' => 'string', 'description' => 'Line Color (Color Hex/RGBA)'],
        'tag_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'tag_right_margin' => ['type' => 'object', 'description' => 'Tag Space (Slider/Size Object)'],
        'tag_color' => ['type' => 'string', 'description' => 'Tag Color (Color Hex/RGBA)'],
        'tag_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'price_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'price_color' => ['type' => 'string', 'description' => 'Price Color (Color Hex/RGBA)'],
        'price_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'dec_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'desc_color' => ['type' => 'string', 'description' => 'Description Color (Color Hex/RGBA)'],
        'dec_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'img_width' => ['type' => 'object', 'description' => 'Image Max Width (Slider/Size Object)'],
        'img_min_width' => ['type' => 'object', 'description' => 'Image Min Width (Slider/Size Object)'],
        'img_border' => ['type' => 'string', 'description' => 'Border', 'enum' => ['yes', 'no']],
        'img_border_style' => ['type' => 'string', 'description' => 'Border', 'enum' => ['img_border', '{{WRAPPER}} .pt-plus-food-menu .food-menu-box .food-flex-imgs .food-img img']],
        'border_height' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'front_bg_border_radious' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'back_bg_border_radious' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'lottiedisplay' => ['type' => 'string', 'description' => 'Display', 'enum' => ['block', 'flex', 'inherit', 'initial', 'inline-block', 'inline-flex']],
        'lottieMright' => ['type' => 'object', 'description' => 'Margin Right (Slider/Size Object)'],
        'lottieWidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'lottieHeight' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'lottieSpeed' => ['type' => 'object', 'description' => 'Speed (Slider/Size Object)'],
        'lottieLoop' => ['type' => 'string', 'description' => 'Loop Animation', 'enum' => ['yes', 'no']],
        'lottiehover' => ['type' => 'string', 'description' => 'Hover Animation', 'enum' => ['yes', 'no']],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports tooltip images, currency switches, and custom background glow effects.']
    ], 'required' => ['post_id', 'parent_id', 'repeater_items'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_pricing_list_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pricing_list_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_pricing_list_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_pricing_list_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-pricing-list';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Pricing List widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['menu_style'])) { $settings['menu_style'] = sanitize_text_field($input['menu_style']); }
    if (isset($input['title'])) { $settings['title'] = sanitize_text_field($input['title']); }
    if (isset($input['title_tag'])) { $settings['title_tag'] = sanitize_text_field($input['title_tag']); }
    if (isset($input['price'])) { $settings['price'] = sanitize_text_field($input['price']); }
    if (isset($input['content'])) { $settings['content'] = sanitize_text_field($input['content']); }
    if (isset($input['icon_type'])) { $settings['icon_type'] = sanitize_text_field($input['icon_type']); }
    if (!empty($input['image_option'])) { $settings['image_option'] = ['id' => absint($input['image_option'])]; }
    if (isset($input['imglotti_right_space'])) { $settings['imglotti_right_space'] = $input['imglotti_right_space']; }
    if (isset($input['img_shape'])) { $settings['img_shape'] = sanitize_text_field($input['img_shape']); }
    if (isset($input['lottieUrl'])) { $settings['lottieUrl'] = $input['lottieUrl']; }
    if (isset($input['box_align'])) { $settings['box_align'] = sanitize_text_field($input['box_align']); }
    if (isset($input['box_align_top'])) { $settings['box_align_top'] = sanitize_text_field($input['box_align_top']); }
    if (isset($input['title_padding'])) { $settings['title_padding'] = $input['title_padding']; }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['title_border'])) { $settings['title_border'] = sanitize_text_field($input['title_border']); }
    if (isset($input['border_style'])) { $settings['border_style'] = sanitize_text_field($input['border_style']); }
    if (isset($input['bd_title_height'])) { $settings['bd_title_height'] = $input['bd_title_height']; }
    if (isset($input['title_border_radius'])) { $settings['title_border_radius'] = $input['title_border_radius']; }
    if (isset($input['bd_title_color'])) { $settings['bd_title_color'] = sanitize_text_field($input['bd_title_color']); }
    if (isset($input['border_line_style'])) { $settings['border_line_style'] = sanitize_text_field($input['border_line_style']); }
    if (isset($input['line_style'])) { $settings['line_style'] = sanitize_text_field($input['line_style']); }
    if (isset($input['bd_line_height'])) { $settings['bd_line_height'] = $input['bd_line_height']; }
    if (isset($input['bd_line_color'])) { $settings['bd_line_color'] = sanitize_text_field($input['bd_line_color']); }
    if (isset($input['tag_padding'])) { $settings['tag_padding'] = $input['tag_padding']; }
    if (isset($input['tag_right_margin'])) { $settings['tag_right_margin'] = $input['tag_right_margin']; }
    if (isset($input['tag_color'])) { $settings['tag_color'] = sanitize_text_field($input['tag_color']); }
    if (isset($input['tag_border_radius'])) { $settings['tag_border_radius'] = $input['tag_border_radius']; }
    if (isset($input['price_padding'])) { $settings['price_padding'] = $input['price_padding']; }
    if (isset($input['price_color'])) { $settings['price_color'] = sanitize_text_field($input['price_color']); }
    if (isset($input['price_border_radius'])) { $settings['price_border_radius'] = $input['price_border_radius']; }
    if (isset($input['dec_padding'])) { $settings['dec_padding'] = $input['dec_padding']; }
    if (isset($input['desc_color'])) { $settings['desc_color'] = sanitize_text_field($input['desc_color']); }
    if (isset($input['dec_border_radius'])) { $settings['dec_border_radius'] = $input['dec_border_radius']; }
    if (isset($input['img_width'])) { $settings['img_width'] = $input['img_width']; }
    if (isset($input['img_min_width'])) { $settings['img_min_width'] = $input['img_min_width']; }
    if (isset($input['img_border'])) { $settings['img_border'] = sanitize_text_field($input['img_border']); }
    if (isset($input['img_border_style'])) { $settings['img_border_style'] = sanitize_text_field($input['img_border_style']); }
    if (isset($input['border_height'])) { $settings['border_height'] = $input['border_height']; }
    if (isset($input['border_color'])) { $settings['border_color'] = sanitize_text_field($input['border_color']); }
    if (isset($input['border_radius'])) { $settings['border_radius'] = $input['border_radius']; }
    if (isset($input['front_bg_border_radious'])) { $settings['front_bg_border_radious'] = $input['front_bg_border_radious']; }
    if (isset($input['back_bg_border_radious'])) { $settings['back_bg_border_radious'] = $input['back_bg_border_radious']; }
    if (isset($input['lottiedisplay'])) { $settings['lottiedisplay'] = sanitize_text_field($input['lottiedisplay']); }
    if (isset($input['lottieMright'])) { $settings['lottieMright'] = $input['lottieMright']; }
    if (isset($input['lottieWidth'])) { $settings['lottieWidth'] = $input['lottieWidth']; }
    if (isset($input['lottieHeight'])) { $settings['lottieHeight'] = $input['lottieHeight']; }
    if (isset($input['lottieSpeed'])) { $settings['lottieSpeed'] = $input['lottieSpeed']; }
    if (isset($input['lottieLoop'])) { $settings['lottieLoop'] = sanitize_text_field($input['lottieLoop']); }
    if (isset($input['lottiehover'])) { $settings['lottiehover'] = sanitize_text_field($input['lottiehover']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
