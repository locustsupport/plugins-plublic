<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-horizontal-scroll-advance', [
'label' => __('Horizontal Scroll Advance', 'theplus'),
    'description' => __('Adds The Plus "Horizontal Scroll Advance" widget (tp-horizontal-scroll-advance) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'fp_content_template' => ['type' => 'string', 'description' => 'Select Template'],
        'scroll_effects' => ['type' => 'string', 'description' => 'Slide Scroll Effects', 'enum' => ['bounce', 'normal', 'scale', 'skew']],
        'scroll_skew_val' => ['type' => 'object', 'description' => 'Skew Value (Slider/Size Object)'],
        'scroll_scale_val' => ['type' => 'object', 'description' => 'Scale Value (Slider/Size Object)'],
        'bg_transition' => ['type' => 'string', 'description' => 'Background Transition', 'enum' => ['yes', 'no']],
        'slide_title' => ['type' => 'string', 'description' => 'Title'],
        'bg_color' => ['type' => 'string', 'description' => 'bg_color (Color Hex/RGBA)'],
        'image' => ['type' => 'integer', 'description' => 'Choose Image (Image ID)'],
        'hs_background' => ['type' => 'string', 'description' => 'Backdrop Filter', 'enum' => ['yes', 'no']],
        'bg_blur' => ['type' => 'object', 'description' => 'Background Blur (Slider/Size Object)'],
        'background_overlay' => ['type' => 'object', 'description' => 'Background Overlay (Color Hex/RGBA)'],
        'bg_transition_content' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Background'],
        'bg_duration' => ['type' => 'object', 'description' => 'Background Transition Duration (Slider/Size Object)'],
        'fixBgtitle' => ['type' => 'string', 'description' => 'Sticky Section', 'enum' => ['yes', 'no']],
        'fixcontent' => ['type' => 'string', 'description' => 'Select Template', 'enum' => ['fixBgtitle']],
        'opacity_scroll' => ['type' => 'string', 'description' => 'Opacity Based Scroll', 'enum' => ['yes', 'no']],
        'opacity_val' => ['type' => 'string', 'description' => 'Value'],
        'fullscroll' => ['type' => 'string', 'description' => 'Full Slide Scroll', 'enum' => ['yes', 'no']],
        'rtl_scroll' => ['type' => 'string', 'description' => 'RTL Compatibility', 'enum' => ['yes', 'no']],
        'h_scroll_speed' => ['type' => 'object', 'description' => 'Scroll Speed'],
        'distance_last_slide' => ['type' => 'object', 'description' => 'Distance after last slide'],
        'customWidth' => ['type' => 'object', 'description' => 'Slides Width'],
        'section_id' => ['type' => 'string', 'description' => 'Section ID'],
        'URLParameter' => ['type' => 'string', 'description' => 'URL Parameter', 'enum' => ['yes', 'no']],
        'horizontal_unique_id' => ['type' => 'string', 'description' => 'Unique Connection ID'],
        'responsive_width' => ['type' => 'string', 'description' => 'Responsive Visibility', 'enum' => ['yes', 'no']],
        'responsive' => ['type' => 'string', 'description' => 'Width'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports snapping, tweening, and custom section widths.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_horizontal_scroll_advance_ability',
    'permission_callback' => 'tpaep_mcp_theplus_horizontal_scroll_advance_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_horizontal_scroll_advance_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_horizontal_scroll_advance_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-horizontal-scroll-advance';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Horizontal Scroll Advance widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['fp_content_template'])) { $settings['fp_content_template'] = sanitize_text_field($input['fp_content_template']); }
    if (isset($input['scroll_effects'])) { $settings['scroll_effects'] = sanitize_text_field($input['scroll_effects']); }
    if (isset($input['scroll_skew_val'])) { $settings['scroll_skew_val'] = $input['scroll_skew_val']; }
    if (isset($input['scroll_scale_val'])) { $settings['scroll_scale_val'] = $input['scroll_scale_val']; }
    if (isset($input['bg_transition'])) { $settings['bg_transition'] = sanitize_text_field($input['bg_transition']); }
    if (isset($input['slide_title'])) { $settings['slide_title'] = sanitize_text_field($input['slide_title']); }
    if (isset($input['bg_color'])) { $settings['bg_color'] = sanitize_text_field($input['bg_color']); }
    if (!empty($input['image'])) { $settings['image'] = ['id' => absint($input['image'])]; }
    if (isset($input['hs_background'])) { $settings['hs_background'] = sanitize_text_field($input['hs_background']); }
    if (isset($input['bg_blur'])) { $settings['bg_blur'] = $input['bg_blur']; }
    if (isset($input['background_overlay'])) { $settings['background_overlay'] = $input['background_overlay']; }
    if (isset($input['bg_transition_content'])) { $settings['bg_transition_content'] = $input['bg_transition_content']; }
    if (isset($input['bg_duration'])) { $settings['bg_duration'] = $input['bg_duration']; }
    if (isset($input['fixBgtitle'])) { $settings['fixBgtitle'] = sanitize_text_field($input['fixBgtitle']); }
    if (isset($input['fixcontent'])) { $settings['fixcontent'] = sanitize_text_field($input['fixcontent']); }
    if (isset($input['opacity_scroll'])) { $settings['opacity_scroll'] = sanitize_text_field($input['opacity_scroll']); }
    if (isset($input['opacity_val'])) { $settings['opacity_val'] = sanitize_text_field($input['opacity_val']); }
    if (isset($input['fullscroll'])) { $settings['fullscroll'] = sanitize_text_field($input['fullscroll']); }
    if (isset($input['rtl_scroll'])) { $settings['rtl_scroll'] = sanitize_text_field($input['rtl_scroll']); }
    if (isset($input['h_scroll_speed'])) { $settings['h_scroll_speed'] = $input['h_scroll_speed']; }
    if (isset($input['distance_last_slide'])) { $settings['distance_last_slide'] = $input['distance_last_slide']; }
    if (isset($input['customWidth'])) { $settings['customWidth'] = $input['customWidth']; }
    if (isset($input['section_id'])) { $settings['section_id'] = sanitize_text_field($input['section_id']); }
    if (isset($input['URLParameter'])) { $settings['URLParameter'] = sanitize_text_field($input['URLParameter']); }
    if (isset($input['horizontal_unique_id'])) { $settings['horizontal_unique_id'] = sanitize_text_field($input['horizontal_unique_id']); }
    if (isset($input['responsive_width'])) { $settings['responsive_width'] = sanitize_text_field($input['responsive_width']); }
    if (isset($input['responsive'])) { $settings['responsive'] = sanitize_text_field($input['responsive']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
