<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-social-sharing', [
'label' => __('Social Sharing', 'theplus'),
    'description' => __('Adds The Plus "Social Sharing" widget (tp-social-sharing) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'sociallayout' => ['type' => 'string', 'description' => 'Layout', 'enum' => ['horizontal', 'toggle', 'vertical']],
        'styleHZ' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'sociallayout', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5']],
        'style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'sociallayout', 'style-1', 'style-2', 'style-3']],
        'toggleStyle' => ['type' => 'string', 'description' => 'Toggle Style', 'enum' => ['columns', 'sociallayout', 'style-1', 'style-2']],
        'hDirection' => ['type' => 'string', 'description' => 'Hover Direction', 'enum' => ['bottom', 'left', 'right', 'sociallayout', 'toggleStyle', 'top']],
        'viewtype' => ['type' => 'string', 'description' => 'View Type', 'enum' => ['icon', 'iconCount', 'iconText', 'iconTextCount', 'sociallayout!', 'text', 'textCount']],
        'column' => ['type' => 'string', 'description' => 'Column', 'enum' => ['1', '2', '3', '4', '5', 'auto', 'sociallayout', '{{WRAPPER}} .tp-social-list .tp-social-menu,
						{{WRAPPER}} .tp-social-list .totalcount']],
        'alignment' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'icon', 'left', 'right', 'sociallayout', 'styleHZ!', '{{WRAPPER}} .tp-social-list', '{{WRAPPER}} .tp-social-sharing']],
        'alignmentV' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'icon', 'left', 'right', 'sociallayout', '{{WRAPPER}} .tp-social-list', '{{WRAPPER}} .tp-social-sharing']],
        'alignmentT' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'icon', 'left', 'right', 'sociallayout', 'toggleStyle', '{{WRAPPER}} .tp-social-list', '{{WRAPPER}} .tp-social-sharing']],
        'style1Align' => ['type' => 'object', 'description' => 'Content Alignment', 'enum' => ['icon', 'sociallayout!', 'text-center', 'text-left', 'text-right']],
        'displayCounter' => ['type' => 'string', 'description' => 'Display Counter', 'enum' => ['yes', 'no']],
        'shareNumber' => ['type' => 'string', 'description' => 'Total Share'],
        'shareLabel' => ['type' => 'string', 'description' => 'Share Label'],
        'socialNtwk' => ['type' => 'string', 'description' => 'Social Network', 'enum' => ['fab fa-amazon', 'fab fa-delicious', 'fab fa-digg', 'fab fa-facebook-f', 'fab fa-facebook-messenger', 'fab fa-get-pocket', 'fab fa-instagram', 'fab fa-linkedin-in', 'fab fa-odnoklassniki', 'fab fa-pinterest-p', 'fab fa-reddit', 'fab fa-skype', 'fab fa-snapchat-ghost', 'fab fa-stumbleupon', 'fab fa-telegram-plane', 'fab fa-tumblr', 'fab fa-twitter', 'fab fa-viber', 'fab fa-vk', 'fab fa-weibo', 'fab fa-whatsapp', 'fab fa-xing', 'far fa-envelope', 'tpmsp']],
        'tpmspIcons' => ['type' => 'string', 'description' => 'Icon'],
        'tpmsp_open' => ['type' => 'object', 'description' => 'Open Mobile Share Panel (Slider/Size Object)'],
        'title' => ['type' => 'string', 'description' => 'Title'],
        'countNumber' => ['type' => 'string', 'description' => 'Count Number'],
        'countLabel' => ['type' => 'string', 'description' => 'Count Label'],
        'socialBtn' => ['type' => 'string', 'description' => 'Social Button'],
        'customURL' => ['type' => 'string', 'description' => 'Custom URL', 'enum' => ['yes', 'no']],
        'customLink' => ['type' => 'object', 'description' => 'Custom URL Link'],
        'titleNmlColor' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'countNmlColor' => ['type' => 'string', 'description' => 'Count Number Color (Color Hex/RGBA)'],
        'countLblNmlColor' => ['type' => 'string', 'description' => 'Count Label Color (Color Hex/RGBA)'],
        'socialbtnNmlColor' => ['type' => 'string', 'description' => 'Social Button Color (Color Hex/RGBA)'],
        'iconNmlColor' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'nmlBColor' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'titleHvrColor' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'countHvrColor' => ['type' => 'string', 'description' => 'Count Number Color (Color Hex/RGBA)'],
        'countLblHvrColor' => ['type' => 'string', 'description' => 'Count Label Color (Color Hex/RGBA)'],
        'socialbtnHvrColor' => ['type' => 'string', 'description' => 'Social Button Color (Color Hex/RGBA)'],
        'iconHvrColor' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'hvrBColor' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'icon_hover_effects' => ['type' => 'string', 'description' => 'Icon Hover Effects'],
        'box_hover_shadow_color' => ['type' => 'string', 'description' => 'Shadow Color (Color Hex/RGBA)'],
        'socialSharing' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Social Sharing'],
        'toggleText' => ['type' => 'string', 'description' => 'Text'],
        'iconStore' => ['type' => 'string', 'description' => 'Select Icon'],
        'titleSpace' => ['type' => 'object', 'description' => 'Title Spacing (Dimensions Object)'],
        'countNumSpace' => ['type' => 'object', 'description' => 'Number Spacing (Dimensions Object)'],
        'countLblSpace' => ['type' => 'object', 'description' => 'Label Spacing (Dimensions Object)'],
        'socialbtnSpace' => ['type' => 'object', 'description' => 'Social Button Spacing (Dimensions Object)'],
        'socialbtnBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'iconBorderBtwn' => ['type' => 'object', 'description' => 'Icon Border (Dimensions Object)'],
        'iconSize' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'iconWidth' => ['type' => 'object', 'description' => 'Icon Width (Slider/Size Object)'],
        'iconGap' => ['type' => 'object', 'description' => 'Icon Between Gap (Slider/Size Object)'],
        'toggleWidth' => ['type' => 'object', 'description' => 'Toggle Width (Slider/Size Object)'],
        'tglIconWidth' => ['type' => 'object', 'description' => 'Icon Width (Slider/Size Object)'],
        'tglIconSize' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'tglTitleNmlColor' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'tglIcnNmlColor' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'tglIcnNmlBG' => ['type' => 'string', 'description' => 'Icon Background (Color Hex/RGBA)'],
        'tglTitleHvrColor' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'tglIcnHvrColor' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'tglIcnHvrBG' => ['type' => 'string', 'description' => 'Icon Background (Color Hex/RGBA)'],
        'totalNumColor' => ['type' => 'string', 'description' => 'Number Color (Color Hex/RGBA)'],
        'totalLblColor' => ['type' => 'string', 'description' => 'Label Color (Color Hex/RGBA)'],
        'totalSpace' => ['type' => 'object', 'description' => 'Space Between (Slider/Size Object)'],
        'bgWidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'bgHeight' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'iconSpaceBtwn' => ['type' => 'object', 'description' => 'Icon Space Between (Dimensions Object)'],
        'bgNmlBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'bgHvrBRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports multi-layout toggle mechanics, dynamic network count sync, and responsive geometry adjustment.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_social_sharing_ability',
    'permission_callback' => 'tpaep_mcp_theplus_social_sharing_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_social_sharing_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_social_sharing_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-social-sharing';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Social Sharing widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['sociallayout'])) { $settings['sociallayout'] = sanitize_text_field($input['sociallayout']); }
    if (isset($input['styleHZ'])) { $settings['styleHZ'] = sanitize_text_field($input['styleHZ']); }
    if (isset($input['style'])) { $settings['style'] = sanitize_text_field($input['style']); }
    if (isset($input['toggleStyle'])) { $settings['toggleStyle'] = sanitize_text_field($input['toggleStyle']); }
    if (isset($input['hDirection'])) { $settings['hDirection'] = sanitize_text_field($input['hDirection']); }
    if (isset($input['viewtype'])) { $settings['viewtype'] = sanitize_text_field($input['viewtype']); }
    if (isset($input['column'])) { $settings['column'] = sanitize_text_field($input['column']); }
    if (isset($input['alignment'])) { $settings['alignment'] = $input['alignment']; }
    if (isset($input['alignmentV'])) { $settings['alignmentV'] = $input['alignmentV']; }
    if (isset($input['alignmentT'])) { $settings['alignmentT'] = $input['alignmentT']; }
    if (isset($input['style1Align'])) { $settings['style1Align'] = $input['style1Align']; }
    if (isset($input['displayCounter'])) { $settings['displayCounter'] = sanitize_text_field($input['displayCounter']); }
    if (isset($input['shareNumber'])) { $settings['shareNumber'] = sanitize_text_field($input['shareNumber']); }
    if (isset($input['shareLabel'])) { $settings['shareLabel'] = sanitize_text_field($input['shareLabel']); }
    if (isset($input['socialNtwk'])) { $settings['socialNtwk'] = sanitize_text_field($input['socialNtwk']); }
    if (isset($input['tpmspIcons'])) { $settings['tpmspIcons'] = sanitize_text_field($input['tpmspIcons']); }
    if (isset($input['tpmsp_open'])) { $settings['tpmsp_open'] = $input['tpmsp_open']; }
    if (isset($input['title'])) { $settings['title'] = sanitize_text_field($input['title']); }
    if (isset($input['countNumber'])) { $settings['countNumber'] = sanitize_text_field($input['countNumber']); }
    if (isset($input['countLabel'])) { $settings['countLabel'] = sanitize_text_field($input['countLabel']); }
    if (isset($input['socialBtn'])) { $settings['socialBtn'] = sanitize_text_field($input['socialBtn']); }
    if (isset($input['customURL'])) { $settings['customURL'] = sanitize_text_field($input['customURL']); }
    if (isset($input['customLink'])) { $settings['customLink'] = $input['customLink']; }
    if (isset($input['titleNmlColor'])) { $settings['titleNmlColor'] = sanitize_text_field($input['titleNmlColor']); }
    if (isset($input['countNmlColor'])) { $settings['countNmlColor'] = sanitize_text_field($input['countNmlColor']); }
    if (isset($input['countLblNmlColor'])) { $settings['countLblNmlColor'] = sanitize_text_field($input['countLblNmlColor']); }
    if (isset($input['socialbtnNmlColor'])) { $settings['socialbtnNmlColor'] = sanitize_text_field($input['socialbtnNmlColor']); }
    if (isset($input['iconNmlColor'])) { $settings['iconNmlColor'] = sanitize_text_field($input['iconNmlColor']); }
    if (isset($input['nmlBColor'])) { $settings['nmlBColor'] = sanitize_text_field($input['nmlBColor']); }
    if (isset($input['titleHvrColor'])) { $settings['titleHvrColor'] = sanitize_text_field($input['titleHvrColor']); }
    if (isset($input['countHvrColor'])) { $settings['countHvrColor'] = sanitize_text_field($input['countHvrColor']); }
    if (isset($input['countLblHvrColor'])) { $settings['countLblHvrColor'] = sanitize_text_field($input['countLblHvrColor']); }
    if (isset($input['socialbtnHvrColor'])) { $settings['socialbtnHvrColor'] = sanitize_text_field($input['socialbtnHvrColor']); }
    if (isset($input['iconHvrColor'])) { $settings['iconHvrColor'] = sanitize_text_field($input['iconHvrColor']); }
    if (isset($input['hvrBColor'])) { $settings['hvrBColor'] = sanitize_text_field($input['hvrBColor']); }
    if (isset($input['icon_hover_effects'])) { $settings['icon_hover_effects'] = sanitize_text_field($input['icon_hover_effects']); }
    if (isset($input['box_hover_shadow_color'])) { $settings['box_hover_shadow_color'] = sanitize_text_field($input['box_hover_shadow_color']); }
    if (isset($input['socialSharing'])) { $settings['socialSharing'] = $input['socialSharing']; }
    if (isset($input['toggleText'])) { $settings['toggleText'] = sanitize_text_field($input['toggleText']); }
    if (isset($input['iconStore'])) { $settings['iconStore'] = sanitize_text_field($input['iconStore']); }
    if (isset($input['titleSpace'])) { $settings['titleSpace'] = $input['titleSpace']; }
    if (isset($input['countNumSpace'])) { $settings['countNumSpace'] = $input['countNumSpace']; }
    if (isset($input['countLblSpace'])) { $settings['countLblSpace'] = $input['countLblSpace']; }
    if (isset($input['socialbtnSpace'])) { $settings['socialbtnSpace'] = $input['socialbtnSpace']; }
    if (isset($input['socialbtnBRadius'])) { $settings['socialbtnBRadius'] = $input['socialbtnBRadius']; }
    if (isset($input['iconBorderBtwn'])) { $settings['iconBorderBtwn'] = $input['iconBorderBtwn']; }
    if (isset($input['iconSize'])) { $settings['iconSize'] = $input['iconSize']; }
    if (isset($input['iconWidth'])) { $settings['iconWidth'] = $input['iconWidth']; }
    if (isset($input['iconGap'])) { $settings['iconGap'] = $input['iconGap']; }
    if (isset($input['toggleWidth'])) { $settings['toggleWidth'] = $input['toggleWidth']; }
    if (isset($input['tglIconWidth'])) { $settings['tglIconWidth'] = $input['tglIconWidth']; }
    if (isset($input['tglIconSize'])) { $settings['tglIconSize'] = $input['tglIconSize']; }
    if (isset($input['tglTitleNmlColor'])) { $settings['tglTitleNmlColor'] = sanitize_text_field($input['tglTitleNmlColor']); }
    if (isset($input['tglIcnNmlColor'])) { $settings['tglIcnNmlColor'] = sanitize_text_field($input['tglIcnNmlColor']); }
    if (isset($input['tglIcnNmlBG'])) { $settings['tglIcnNmlBG'] = sanitize_text_field($input['tglIcnNmlBG']); }
    if (isset($input['tglTitleHvrColor'])) { $settings['tglTitleHvrColor'] = sanitize_text_field($input['tglTitleHvrColor']); }
    if (isset($input['tglIcnHvrColor'])) { $settings['tglIcnHvrColor'] = sanitize_text_field($input['tglIcnHvrColor']); }
    if (isset($input['tglIcnHvrBG'])) { $settings['tglIcnHvrBG'] = sanitize_text_field($input['tglIcnHvrBG']); }
    if (isset($input['totalNumColor'])) { $settings['totalNumColor'] = sanitize_text_field($input['totalNumColor']); }
    if (isset($input['totalLblColor'])) { $settings['totalLblColor'] = sanitize_text_field($input['totalLblColor']); }
    if (isset($input['totalSpace'])) { $settings['totalSpace'] = $input['totalSpace']; }
    if (isset($input['bgWidth'])) { $settings['bgWidth'] = $input['bgWidth']; }
    if (isset($input['bgHeight'])) { $settings['bgHeight'] = $input['bgHeight']; }
    if (isset($input['iconSpaceBtwn'])) { $settings['iconSpaceBtwn'] = $input['iconSpaceBtwn']; }
    if (isset($input['bgNmlBRadius'])) { $settings['bgNmlBRadius'] = $input['bgNmlBRadius']; }
    if (isset($input['bgHvrBRadius'])) { $settings['bgHvrBRadius'] = $input['bgHvrBRadius']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
