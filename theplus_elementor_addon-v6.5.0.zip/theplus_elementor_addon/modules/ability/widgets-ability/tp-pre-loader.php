<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-pre-loader', [
'label' => __('Pre Loader', 'theplus'),
    'description' => __('Adds The Plus "Pre Loader" widget (tp-pre-loader) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'plcSelect' => ['type' => 'string', 'description' => 'plcSelect', 'enum' => ['CustomCode', 'Icon', 'Image', 'Lottie', 'PreDefined', 'Progress', 'Shortcode', 'TextContent']],
        'plcprecentagelayout' => ['type' => 'string', 'description' => 'Layout', 'enum' => ['plcSelect', 'plcper1', 'plcper2', 'plcper3', 'plcper4', 'plcper5', 'plcper6']],
        'plcper3prefix' => ['type' => 'string', 'description' => 'Prefix'],
        'plcper3postfix' => ['type' => 'string', 'description' => 'Postfix'],
        'plcprecentagelayoutpos' => ['type' => 'string', 'description' => 'Position', 'enum' => ['plcSelect', 'plcperposbottom', 'plcperpostop', 'plcprecentagelayout']],
        'plcsImage' => ['type' => 'integer', 'description' => 'Image (Image ID)'],
        'plcsImageLoader' => ['type' => 'string', 'description' => 'Loader on Image', 'enum' => ['yes', 'no']],
        'plcsIcons' => ['type' => 'string', 'description' => 'Icon'],
        'plcsText' => ['type' => 'string', 'description' => 'Content'],
        'plcsTextLoader' => ['type' => 'string', 'description' => 'Loader on Text', 'enum' => ['yes', 'no']],
        'plcsLottieUrl' => ['type' => 'object', 'description' => 'Lottie URL'],
        'plcsLottieWidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'plcsLottieHeight' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'plcsLottieSpeed' => ['type' => 'object', 'description' => 'Speed (Slider/Size Object)'],
        'plcsLottieLoop' => ['type' => 'string', 'description' => 'Loop Animation', 'enum' => ['yes', 'no']],
        'plcsPreAnimation' => ['type' => 'string', 'description' => 'Select', 'enum' => ['animation-1', 'animation-10', 'animation-12', 'animation-14', 'animation-15', 'animation-2', 'animation-3', 'animation-4', 'animation-5', 'animation-6', 'animation-7', 'animation-8', 'animation-9', 'plcSelect']],
        'plcsCustomCode' => ['type' => 'string', 'description' => 'Code'],
        'plcsCustomShortCode' => ['type' => 'string', 'description' => 'Shortcode'],
        'preLoaderContent' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Preloader'],
        'backpreloader' => ['type' => 'string', 'description' => 'Backend Visibility', 'enum' => ['yes', 'no']],
        'alfSwitch' => ['type' => 'string', 'description' => 'Exclude Content', 'enum' => ['yes', 'no']],
        'alfExclude' => ['type' => 'string', 'description' => 'Exclude', 'enum' => ['alfSwitch', 'alfcustom', 'alfheader']],
        'alfExcludecustom' => ['type' => 'string', 'description' => 'Class'],
        'alfExcludeZIndexpos' => ['type' => 'string', 'description' => 'Position', 'enum' => ['alfExclude', 'alfSwitch', 'bottom', 'top']],
        'alfExcludeZIndex' => ['type' => 'object', 'description' => 'Z-Index (Slider/Size Object)'],
        'pageLoadTransition' => ['type' => 'string', 'description' => 'Transition', 'enum' => ['pageloadduomove', 'pageloadfadein', 'pageloadsimple', 'pageloadslidein', 'pageloadtripleswoosh']],
        'pageLoad4InDir' => ['type' => 'string', 'description' => 'Direction', 'enum' => ['bottom', 'bottomleft', 'bottomright', 'left', 'pageLoadTransition', 'right', 'top', 'topleft', 'topright']],
        'pageLoadSlideInDir' => ['type' => 'string', 'description' => 'Direction', 'enum' => ['bottom', 'left', 'pageLoadTransition', 'right', 'top']],
        'outTransition' => ['type' => 'string', 'description' => 'Out Transition', 'enum' => ['yes', 'no']],
        'postLoadTransition' => ['type' => 'string', 'description' => 'Transition', 'enum' => ['outTransition', 'postloadfadeout', 'postloadsduomove', 'postloadslideout', 'postloadssimple', 'postloadstripleswoosh']],
        'postLoad4InDir' => ['type' => 'string', 'description' => 'Direction', 'enum' => ['bottom', 'bottomleft', 'bottomright', 'left', 'outTransition', 'postLoadTransition', 'right', 'top', 'topleft', 'topright']],
        'postLoadSlideInDir' => ['type' => 'string', 'description' => 'Direction', 'enum' => ['bottom', 'left', 'outTransition', 'postLoadTransition', 'right', 'top']],
        'postLoadExcludeCustom' => ['type' => 'string', 'description' => 'Exclude Class'],
        'loadtime' => ['type' => 'string', 'description' => 'Load Time', 'enum' => ['loadtimedefault', 'loadtimemax', 'loadtimemin']],
        'loadmaxtime' => ['type' => 'object', 'description' => 'Time (Second) (Slider/Size Object)'],
        'loadmintime' => ['type' => 'object', 'description' => 'Time (Second) (Slider/Size Object)'],
        'tpaep_theme_builder' => ['type' => 'string', 'description' => 'tpaep_theme_builder'],
        'pr_image_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'pr_image_max_width' => ['type' => 'object', 'description' => 'Max Width (Slider/Size Object)'],
        'pr_imageb_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'if_n_i_opacity' => ['type' => 'object', 'description' => 'Opacity (Slider/Size Object)'],
        'if_f_i_opacity' => ['type' => 'object', 'description' => 'Opacity (Slider/Size Object)'],
        'pr_icon_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'pr_icon_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'pr_icon_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'pr_icon_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'pr_iconb_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'pr_text_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'pr_text_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'pr_text_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'pr_textb_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'textloader_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'pr_predefine_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'pr_predefine_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'pr_predefined_color1' => ['type' => 'string', 'description' => 'Color 1 (Color Hex/RGBA)'],
        'pr_predefined_color2' => ['type' => 'string', 'description' => 'Color 2 (Color Hex/RGBA)'],
        'progressmargin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'progresswidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'progressheight' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'progressbargradiantcolor' => ['type' => 'string', 'description' => 'Gradient Color', 'enum' => ['yes', 'no']],
        'progressbarcolor1' => ['type' => 'string', 'description' => 'Color 1 (Color Hex/RGBA)'],
        'progressbarcolor2' => ['type' => 'string', 'description' => 'Color 2 (Color Hex/RGBA)'],
        'progressbarcolorg1' => ['type' => 'string', 'description' => 'Color 1 (Color Hex/RGBA)'],
        'progressbarcolorg2' => ['type' => 'string', 'description' => 'Color 2 (Color Hex/RGBA)'],
        'progressbarcolorg3' => ['type' => 'string', 'description' => 'Color 3 (Color Hex/RGBA)'],
        'progressbarcolorg4' => ['type' => 'string', 'description' => 'Color 4 (Color Hex/RGBA)'],
        'progressbarcolorg5' => ['type' => 'string', 'description' => 'Color 5 (Color Hex/RGBA)'],
        'progressbarcolorg6' => ['type' => 'string', 'description' => 'Color 6 (Color Hex/RGBA)'],
        'progressbarcolorg7' => ['type' => 'string', 'description' => 'Color 7 (Color Hex/RGBA)'],
        'progressbarcolorempty' => ['type' => 'string', 'description' => 'Empty Color (Layout 4) (Color Hex/RGBA)'],
        'progressbar5size' => ['type' => 'object', 'description' => 'Progress Size (Layout 5) (Slider/Size Object)'],
        'progressborderradious' => ['type' => 'object', 'description' => 'Border Radius (Slider/Size Object)'],
        'progresstextcolor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'progresstextprefixcolor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'progresstextpostfixcolor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'pctextemptycolor' => ['type' => 'string', 'description' => 'Empty Color (Color Hex/RGBA)'],
        'pctextfillcolor' => ['type' => 'string', 'description' => 'Fill Color (Color Hex/RGBA)'],
        'pctextstrocksize' => ['type' => 'object', 'description' => 'Stroke Width (Slider/Size Object)'],
        'pctextcolor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'tp4color1' => ['type' => 'string', 'description' => 'Color 1 (Color Hex/RGBA)'],
        'tp4color2' => ['type' => 'string', 'description' => 'Color 2 (Color Hex/RGBA)'],
        'tp4color3' => ['type' => 'string', 'description' => 'Color 3 (Color Hex/RGBA)'],
        'pr_box_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'pr_box_width' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'pr_box_BRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports Lottie animations, percentage indicators, and custom 3D page transitions.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_pre_loader_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pre_loader_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_pre_loader_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_pre_loader_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-pre-loader';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Pre Loader widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['plcSelect'])) { $settings['plcSelect'] = sanitize_text_field($input['plcSelect']); }
    if (isset($input['plcprecentagelayout'])) { $settings['plcprecentagelayout'] = sanitize_text_field($input['plcprecentagelayout']); }
    if (isset($input['plcper3prefix'])) { $settings['plcper3prefix'] = sanitize_text_field($input['plcper3prefix']); }
    if (isset($input['plcper3postfix'])) { $settings['plcper3postfix'] = sanitize_text_field($input['plcper3postfix']); }
    if (isset($input['plcprecentagelayoutpos'])) { $settings['plcprecentagelayoutpos'] = sanitize_text_field($input['plcprecentagelayoutpos']); }
    if (!empty($input['plcsImage'])) { $settings['plcsImage'] = ['id' => absint($input['plcsImage'])]; }
    if (isset($input['plcsImageLoader'])) { $settings['plcsImageLoader'] = sanitize_text_field($input['plcsImageLoader']); }
    if (isset($input['plcsIcons'])) { $settings['plcsIcons'] = sanitize_text_field($input['plcsIcons']); }
    if (isset($input['plcsText'])) { $settings['plcsText'] = sanitize_text_field($input['plcsText']); }
    if (isset($input['plcsTextLoader'])) { $settings['plcsTextLoader'] = sanitize_text_field($input['plcsTextLoader']); }
    if (isset($input['plcsLottieUrl'])) { $settings['plcsLottieUrl'] = $input['plcsLottieUrl']; }
    if (isset($input['plcsLottieWidth'])) { $settings['plcsLottieWidth'] = $input['plcsLottieWidth']; }
    if (isset($input['plcsLottieHeight'])) { $settings['plcsLottieHeight'] = $input['plcsLottieHeight']; }
    if (isset($input['plcsLottieSpeed'])) { $settings['plcsLottieSpeed'] = $input['plcsLottieSpeed']; }
    if (isset($input['plcsLottieLoop'])) { $settings['plcsLottieLoop'] = sanitize_text_field($input['plcsLottieLoop']); }
    if (isset($input['plcsPreAnimation'])) { $settings['plcsPreAnimation'] = sanitize_text_field($input['plcsPreAnimation']); }
    if (isset($input['plcsCustomCode'])) { $settings['plcsCustomCode'] = sanitize_text_field($input['plcsCustomCode']); }
    if (isset($input['plcsCustomShortCode'])) { $settings['plcsCustomShortCode'] = sanitize_text_field($input['plcsCustomShortCode']); }
    if (isset($input['preLoaderContent'])) { $settings['preLoaderContent'] = $input['preLoaderContent']; }
    if (isset($input['backpreloader'])) { $settings['backpreloader'] = sanitize_text_field($input['backpreloader']); }
    if (isset($input['alfSwitch'])) { $settings['alfSwitch'] = sanitize_text_field($input['alfSwitch']); }
    if (isset($input['alfExclude'])) { $settings['alfExclude'] = sanitize_text_field($input['alfExclude']); }
    if (isset($input['alfExcludecustom'])) { $settings['alfExcludecustom'] = sanitize_text_field($input['alfExcludecustom']); }
    if (isset($input['alfExcludeZIndexpos'])) { $settings['alfExcludeZIndexpos'] = sanitize_text_field($input['alfExcludeZIndexpos']); }
    if (isset($input['alfExcludeZIndex'])) { $settings['alfExcludeZIndex'] = $input['alfExcludeZIndex']; }
    if (isset($input['pageLoadTransition'])) { $settings['pageLoadTransition'] = sanitize_text_field($input['pageLoadTransition']); }
    if (isset($input['pageLoad4InDir'])) { $settings['pageLoad4InDir'] = sanitize_text_field($input['pageLoad4InDir']); }
    if (isset($input['pageLoadSlideInDir'])) { $settings['pageLoadSlideInDir'] = sanitize_text_field($input['pageLoadSlideInDir']); }
    if (isset($input['outTransition'])) { $settings['outTransition'] = sanitize_text_field($input['outTransition']); }
    if (isset($input['postLoadTransition'])) { $settings['postLoadTransition'] = sanitize_text_field($input['postLoadTransition']); }
    if (isset($input['postLoad4InDir'])) { $settings['postLoad4InDir'] = sanitize_text_field($input['postLoad4InDir']); }
    if (isset($input['postLoadSlideInDir'])) { $settings['postLoadSlideInDir'] = sanitize_text_field($input['postLoadSlideInDir']); }
    if (isset($input['postLoadExcludeCustom'])) { $settings['postLoadExcludeCustom'] = sanitize_text_field($input['postLoadExcludeCustom']); }
    if (isset($input['loadtime'])) { $settings['loadtime'] = sanitize_text_field($input['loadtime']); }
    if (isset($input['loadmaxtime'])) { $settings['loadmaxtime'] = $input['loadmaxtime']; }
    if (isset($input['loadmintime'])) { $settings['loadmintime'] = $input['loadmintime']; }
    if (isset($input['tpaep_theme_builder'])) { $settings['tpaep_theme_builder'] = sanitize_text_field($input['tpaep_theme_builder']); }
    if (isset($input['pr_image_margin'])) { $settings['pr_image_margin'] = $input['pr_image_margin']; }
    if (isset($input['pr_image_max_width'])) { $settings['pr_image_max_width'] = $input['pr_image_max_width']; }
    if (isset($input['pr_imageb_radius'])) { $settings['pr_imageb_radius'] = $input['pr_imageb_radius']; }
    if (isset($input['if_n_i_opacity'])) { $settings['if_n_i_opacity'] = $input['if_n_i_opacity']; }
    if (isset($input['if_f_i_opacity'])) { $settings['if_f_i_opacity'] = $input['if_f_i_opacity']; }
    if (isset($input['pr_icon_padding'])) { $settings['pr_icon_padding'] = $input['pr_icon_padding']; }
    if (isset($input['pr_icon_margin'])) { $settings['pr_icon_margin'] = $input['pr_icon_margin']; }
    if (isset($input['pr_icon_size'])) { $settings['pr_icon_size'] = $input['pr_icon_size']; }
    if (isset($input['pr_icon_color'])) { $settings['pr_icon_color'] = sanitize_text_field($input['pr_icon_color']); }
    if (isset($input['pr_iconb_radius'])) { $settings['pr_iconb_radius'] = $input['pr_iconb_radius']; }
    if (isset($input['pr_text_padding'])) { $settings['pr_text_padding'] = $input['pr_text_padding']; }
    if (isset($input['pr_text_margin'])) { $settings['pr_text_margin'] = $input['pr_text_margin']; }
    if (isset($input['pr_text_color'])) { $settings['pr_text_color'] = sanitize_text_field($input['pr_text_color']); }
    if (isset($input['pr_textb_radius'])) { $settings['pr_textb_radius'] = $input['pr_textb_radius']; }
    if (isset($input['textloader_color'])) { $settings['textloader_color'] = sanitize_text_field($input['textloader_color']); }
    if (isset($input['pr_predefine_padding'])) { $settings['pr_predefine_padding'] = $input['pr_predefine_padding']; }
    if (isset($input['pr_predefine_margin'])) { $settings['pr_predefine_margin'] = $input['pr_predefine_margin']; }
    if (isset($input['pr_predefined_color1'])) { $settings['pr_predefined_color1'] = sanitize_text_field($input['pr_predefined_color1']); }
    if (isset($input['pr_predefined_color2'])) { $settings['pr_predefined_color2'] = sanitize_text_field($input['pr_predefined_color2']); }
    if (isset($input['progressmargin'])) { $settings['progressmargin'] = $input['progressmargin']; }
    if (isset($input['progresswidth'])) { $settings['progresswidth'] = $input['progresswidth']; }
    if (isset($input['progressheight'])) { $settings['progressheight'] = $input['progressheight']; }
    if (isset($input['progressbargradiantcolor'])) { $settings['progressbargradiantcolor'] = sanitize_text_field($input['progressbargradiantcolor']); }
    if (isset($input['progressbarcolor1'])) { $settings['progressbarcolor1'] = sanitize_text_field($input['progressbarcolor1']); }
    if (isset($input['progressbarcolor2'])) { $settings['progressbarcolor2'] = sanitize_text_field($input['progressbarcolor2']); }
    if (isset($input['progressbarcolorg1'])) { $settings['progressbarcolorg1'] = sanitize_text_field($input['progressbarcolorg1']); }
    if (isset($input['progressbarcolorg2'])) { $settings['progressbarcolorg2'] = sanitize_text_field($input['progressbarcolorg2']); }
    if (isset($input['progressbarcolorg3'])) { $settings['progressbarcolorg3'] = sanitize_text_field($input['progressbarcolorg3']); }
    if (isset($input['progressbarcolorg4'])) { $settings['progressbarcolorg4'] = sanitize_text_field($input['progressbarcolorg4']); }
    if (isset($input['progressbarcolorg5'])) { $settings['progressbarcolorg5'] = sanitize_text_field($input['progressbarcolorg5']); }
    if (isset($input['progressbarcolorg6'])) { $settings['progressbarcolorg6'] = sanitize_text_field($input['progressbarcolorg6']); }
    if (isset($input['progressbarcolorg7'])) { $settings['progressbarcolorg7'] = sanitize_text_field($input['progressbarcolorg7']); }
    if (isset($input['progressbarcolorempty'])) { $settings['progressbarcolorempty'] = sanitize_text_field($input['progressbarcolorempty']); }
    if (isset($input['progressbar5size'])) { $settings['progressbar5size'] = $input['progressbar5size']; }
    if (isset($input['progressborderradious'])) { $settings['progressborderradious'] = $input['progressborderradious']; }
    if (isset($input['progresstextcolor'])) { $settings['progresstextcolor'] = sanitize_text_field($input['progresstextcolor']); }
    if (isset($input['progresstextprefixcolor'])) { $settings['progresstextprefixcolor'] = sanitize_text_field($input['progresstextprefixcolor']); }
    if (isset($input['progresstextpostfixcolor'])) { $settings['progresstextpostfixcolor'] = sanitize_text_field($input['progresstextpostfixcolor']); }
    if (isset($input['pctextemptycolor'])) { $settings['pctextemptycolor'] = sanitize_text_field($input['pctextemptycolor']); }
    if (isset($input['pctextfillcolor'])) { $settings['pctextfillcolor'] = sanitize_text_field($input['pctextfillcolor']); }
    if (isset($input['pctextstrocksize'])) { $settings['pctextstrocksize'] = $input['pctextstrocksize']; }
    if (isset($input['pctextcolor'])) { $settings['pctextcolor'] = sanitize_text_field($input['pctextcolor']); }
    if (isset($input['tp4color1'])) { $settings['tp4color1'] = sanitize_text_field($input['tp4color1']); }
    if (isset($input['tp4color2'])) { $settings['tp4color2'] = sanitize_text_field($input['tp4color2']); }
    if (isset($input['tp4color3'])) { $settings['tp4color3'] = sanitize_text_field($input['tp4color3']); }
    if (isset($input['pr_box_padding'])) { $settings['pr_box_padding'] = $input['pr_box_padding']; }
    if (isset($input['pr_box_width'])) { $settings['pr_box_width'] = $input['pr_box_width']; }
    if (isset($input['pr_box_BRadius'])) { $settings['pr_box_BRadius'] = $input['pr_box_BRadius']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
