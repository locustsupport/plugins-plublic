<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-audio-player', [
'label' => __('Audio Player', 'theplus'),
    'description' => __('Adds The Plus "Audio Player" widget (tp-audio-player) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'        => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'      => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'       => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'ap_style' => ['type' => 'string', 'description' => 'Styles', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7', 'style-8', 'style-9']],
        'title' => ['type' => 'string', 'description' => 'Song Title'],
        'author' => ['type' => 'string', 'description' => 'Song Author'],
        'audio_source' => ['type' => 'string', 'description' => 'Source', 'enum' => ['file', 'url']],
        'source_mp3' => ['type' => 'object', 'description' => 'File'],
        'source_mp3_url' => ['type' => 'string', 'description' => 'URL'],
        'audio_track_image' => ['type' => 'object', 'description' => 'Image'],
        'playlist' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'playlist'],
        'audio_track_image_c' => ['type' => 'object', 'description' => 'Image'],
        'split_text' => ['type' => 'string', 'description' => 'Split Text'],
        'ap_max_width' => ['type' => 'object', 'description' => 'Max-width'],
        's_volume' => ['type' => 'object', 'description' => 'Default Volume'],
        'title_color' => ['type' => 'string', 'description' => 'Title Color'],
        'author_color' => ['type' => 'string', 'description' => 'Author Color'],
        'splittext_color' => ['type' => 'string', 'description' => 'Split Text Color'],
        'player_control_bg_st9' => ['type' => 'string', 'description' => 'Background Color'],
        'st_9_br' => ['type' => 'object', 'description' => 'Border Radius'],
        'player_control_color' => ['type' => 'string', 'description' => 'Icon Color'],
        'player_control_size' => ['type' => 'object', 'description' => 'Size'],
        'player_control_play_size' => ['type' => 'object', 'description' => 'Play/Pause Icon Size'],
        'player_control_play_color' => ['type' => 'string', 'description' => 'Play/Pause Icon Color'],
        'player_control_play_bg_size1' => ['type' => 'object', 'description' => 'Background Size'],
        'player_control_play_bg_br' => ['type' => 'object', 'description' => 'Border Radius'],
        'pl_list_c_playlist_i_size' => ['type' => 'object', 'description' => 'Size'],
        'pl_list_c_playlist_i_color' => ['type' => 'string', 'description' => 'Playlist Icon Color'],
        'pl_list_c_volume_i_size' => ['type' => 'object', 'description' => 'Size'],
        'pl_list_c_volume_i_color' => ['type' => 'string', 'description' => 'Volume Icon Color'],
        'pl_list_c_volume_slider_rng_color' => ['type' => 'string', 'description' => 'Volume Slider Range Color'],
        'pl_list_c_volume_slider_color' => ['type' => 'string', 'description' => 'Volume Slider Color'],
        'pl_list_c_volume_slider_bg' => ['type' => 'string', 'description' => 'Volume Slider Background'],
        'player_tracker_time' => ['type' => 'object', 'description' => 'Time Size'],
        'player_tracker_time_color' => ['type' => 'string', 'description' => 'Time Color'],
        'tracker_width' => ['type' => 'object', 'description' => 'Tracker width'],
        'player_tracker_dot_color' => ['type' => 'string', 'description' => 'Dot Color'],
        'player_track_color' => ['type' => 'string', 'description' => 'Track Color'],
        'player_track_fill_color' => ['type' => 'string', 'description' => 'Track Fill Color'],
        'background_size_st9' => ['type' => 'string', 'description' => 'Background Size', 'enum' => ['ap_style', '{{WRAPPER}} .tp-audio-player-wrapper.style-9 .tp-player .tp-player-hover .tp-player-bg-img']],
        'background_position_st9' => ['type' => 'string', 'description' => 'Background Position', 'enum' => ['ap_style', '{{WRAPPER}} .tp-audio-player-wrapper.style-9 .tp-player .tp-player-hover .tp-player-bg-img']],
        'background_repeat_st9' => ['type' => 'string', 'description' => 'Background Repeat', 'enum' => ['ap_style', '{{WRAPPER}} .tp-audio-player-wrapper.style-9 .tp-player .tp-player-hover .tp-player-bg-img']],
        'trackimg_border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'playlist_padding' => ['type' => 'object', 'description' => 'Padding'],
        'playlist_margin' => ['type' => 'object', 'description' => 'Inner Margin'],
        'playlist_outer_margin' => ['type' => 'object', 'description' => 'Outer Margin'],
        'pl_bg_top_offset' => ['type' => 'object', 'description' => 'Top Offset'],
        'pl_n_color' => ['type' => 'string', 'description' => 'Color'],
        'pl_a_color' => ['type' => 'string', 'description' => 'Color'],
        'pl_a_bg' => ['type' => 'string', 'description' => 'Background'],
        'pl_bg_border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'player_padding' => ['type' => 'object', 'description' => 'Padding'],
        'player_margin' => ['type' => 'object', 'description' => 'Margin'],
        'player_bg_overlay' => ['type' => 'string', 'description' => 'Background Overlay Color'],
        'player_img_bg_overlay' => ['type' => 'string', 'description' => 'Background Image Overlay Color'],
        'background_position' => ['type' => 'string', 'description' => 'Background Position', 'enum' => ['ap_style', '{{WRAPPER}} .tp-audio-player-wrapper.style-4 .tp-player,
					{{WRAPPER}} .tp-audio-player-wrapper.style-6 .ap-st5-content,
					{{WRAPPER}} .tp-audio-player-wrapper.style-8 .tp-player-bg-img']],
        'background_repeat' => ['type' => 'string', 'description' => 'Background Repeat', 'enum' => ['ap_style', '{{WRAPPER}} .tp-audio-player-wrapper.style-4 .tp-player,
					{{WRAPPER}} .tp-audio-player-wrapper.style-6 .ap-st5-content,
					{{WRAPPER}} .tp-audio-player-wrapper.style-8 .tp-player-bg-img']],
        'background_size' => ['type' => 'string', 'description' => 'Background Size', 'enum' => ['ap_style', '{{WRAPPER}} .tp-audio-player-wrapper.style-4 .tp-player,
					{{WRAPPER}} .tp-audio-player-wrapper.style-6 .ap-st5-content,
					{{WRAPPER}} .tp-audio-player-wrapper.style-8 .tp-player-bg-img']],
        'player_border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'eo_autoplay' => ['type' => 'string', 'description' => 'Autoplay Loop', 'enum' => ['yes', 'no']],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings.']
    ], 'required' => ['post_id', 'parent_id', 'audio_source'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_audio_player_ability',
    'permission_callback' => 'tpaep_mcp_theplus_audio_player_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_audio_player_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_audio_player_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-audio-player';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Audio Player widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['ap_style'])) { $settings['ap_style'] = sanitize_text_field($input['ap_style']); }
    if (isset($input['title'])) { $settings['title'] = sanitize_text_field($input['title']); }
    if (isset($input['author'])) { $settings['author'] = sanitize_text_field($input['author']); }
    if (isset($input['audio_source'])) { $settings['audio_source'] = sanitize_text_field($input['audio_source']); }
    if (isset($input['source_mp3'])) { $settings['source_mp3'] = $input['source_mp3']; }
    if (isset($input['source_mp3_url'])) { $settings['source_mp3_url'] = sanitize_text_field($input['source_mp3_url']); }
    if (isset($input['audio_track_image'])) { $settings['audio_track_image'] = $input['audio_track_image']; }
    if (isset($input['playlist'])) { $settings['playlist'] = $input['playlist']; }
    if (isset($input['audio_track_image_c'])) { $settings['audio_track_image_c'] = $input['audio_track_image_c']; }
    if (isset($input['split_text'])) { $settings['split_text'] = sanitize_text_field($input['split_text']); }
    if (isset($input['ap_max_width'])) { $settings['ap_max_width'] = $input['ap_max_width']; }
    if (isset($input['s_volume'])) { $settings['s_volume'] = $input['s_volume']; }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['author_color'])) { $settings['author_color'] = sanitize_text_field($input['author_color']); }
    if (isset($input['splittext_color'])) { $settings['splittext_color'] = sanitize_text_field($input['splittext_color']); }
    if (isset($input['player_control_bg_st9'])) { $settings['player_control_bg_st9'] = sanitize_text_field($input['player_control_bg_st9']); }
    if (isset($input['st_9_br'])) { $settings['st_9_br'] = $input['st_9_br']; }
    if (isset($input['player_control_color'])) { $settings['player_control_color'] = sanitize_text_field($input['player_control_color']); }
    if (isset($input['player_control_size'])) { $settings['player_control_size'] = $input['player_control_size']; }
    if (isset($input['player_control_play_size'])) { $settings['player_control_play_size'] = $input['player_control_play_size']; }
    if (isset($input['player_control_play_color'])) { $settings['player_control_play_color'] = sanitize_text_field($input['player_control_play_color']); }
    if (isset($input['player_control_play_bg_size1'])) { $settings['player_control_play_bg_size1'] = $input['player_control_play_bg_size1']; }
    if (isset($input['player_control_play_bg_br'])) { $settings['player_control_play_bg_br'] = $input['player_control_play_bg_br']; }
    if (isset($input['pl_list_c_playlist_i_size'])) { $settings['pl_list_c_playlist_i_size'] = $input['pl_list_c_playlist_i_size']; }
    if (isset($input['pl_list_c_playlist_i_color'])) { $settings['pl_list_c_playlist_i_color'] = sanitize_text_field($input['pl_list_c_playlist_i_color']); }
    if (isset($input['pl_list_c_volume_i_size'])) { $settings['pl_list_c_volume_i_size'] = $input['pl_list_c_volume_i_size']; }
    if (isset($input['pl_list_c_volume_i_color'])) { $settings['pl_list_c_volume_i_color'] = sanitize_text_field($input['pl_list_c_volume_i_color']); }
    if (isset($input['pl_list_c_volume_slider_rng_color'])) { $settings['pl_list_c_volume_slider_rng_color'] = sanitize_text_field($input['pl_list_c_volume_slider_rng_color']); }
    if (isset($input['pl_list_c_volume_slider_color'])) { $settings['pl_list_c_volume_slider_color'] = sanitize_text_field($input['pl_list_c_volume_slider_color']); }
    if (isset($input['pl_list_c_volume_slider_bg'])) { $settings['pl_list_c_volume_slider_bg'] = sanitize_text_field($input['pl_list_c_volume_slider_bg']); }
    if (isset($input['player_tracker_time'])) { $settings['player_tracker_time'] = $input['player_tracker_time']; }
    if (isset($input['player_tracker_time_color'])) { $settings['player_tracker_time_color'] = sanitize_text_field($input['player_tracker_time_color']); }
    if (isset($input['tracker_width'])) { $settings['tracker_width'] = $input['tracker_width']; }
    if (isset($input['player_tracker_dot_color'])) { $settings['player_tracker_dot_color'] = sanitize_text_field($input['player_tracker_dot_color']); }
    if (isset($input['player_track_color'])) { $settings['player_track_color'] = sanitize_text_field($input['player_track_color']); }
    if (isset($input['player_track_fill_color'])) { $settings['player_track_fill_color'] = sanitize_text_field($input['player_track_fill_color']); }
    if (isset($input['background_size_st9'])) { $settings['background_size_st9'] = sanitize_text_field($input['background_size_st9']); }
    if (isset($input['background_position_st9'])) { $settings['background_position_st9'] = sanitize_text_field($input['background_position_st9']); }
    if (isset($input['background_repeat_st9'])) { $settings['background_repeat_st9'] = sanitize_text_field($input['background_repeat_st9']); }
    if (isset($input['trackimg_border_radius'])) { $settings['trackimg_border_radius'] = $input['trackimg_border_radius']; }
    if (isset($input['playlist_padding'])) { $settings['playlist_padding'] = $input['playlist_padding']; }
    if (isset($input['playlist_margin'])) { $settings['playlist_margin'] = $input['playlist_margin']; }
    if (isset($input['playlist_outer_margin'])) { $settings['playlist_outer_margin'] = $input['playlist_outer_margin']; }
    if (isset($input['pl_bg_top_offset'])) { $settings['pl_bg_top_offset'] = $input['pl_bg_top_offset']; }
    if (isset($input['pl_n_color'])) { $settings['pl_n_color'] = sanitize_text_field($input['pl_n_color']); }
    if (isset($input['pl_a_color'])) { $settings['pl_a_color'] = sanitize_text_field($input['pl_a_color']); }
    if (isset($input['pl_a_bg'])) { $settings['pl_a_bg'] = sanitize_text_field($input['pl_a_bg']); }
    if (isset($input['pl_bg_border_radius'])) { $settings['pl_bg_border_radius'] = $input['pl_bg_border_radius']; }
    if (isset($input['player_padding'])) { $settings['player_padding'] = $input['player_padding']; }
    if (isset($input['player_margin'])) { $settings['player_margin'] = $input['player_margin']; }
    if (isset($input['player_bg_overlay'])) { $settings['player_bg_overlay'] = sanitize_text_field($input['player_bg_overlay']); }
    if (isset($input['player_img_bg_overlay'])) { $settings['player_img_bg_overlay'] = sanitize_text_field($input['player_img_bg_overlay']); }
    if (isset($input['background_position'])) { $settings['background_position'] = sanitize_text_field($input['background_position']); }
    if (isset($input['background_repeat'])) { $settings['background_repeat'] = sanitize_text_field($input['background_repeat']); }
    if (isset($input['background_size'])) { $settings['background_size'] = sanitize_text_field($input['background_size']); }
    if (isset($input['player_border_radius'])) { $settings['player_border_radius'] = $input['player_border_radius']; }
    if (isset($input['eo_autoplay'])) { $settings['eo_autoplay'] = sanitize_text_field($input['eo_autoplay']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
