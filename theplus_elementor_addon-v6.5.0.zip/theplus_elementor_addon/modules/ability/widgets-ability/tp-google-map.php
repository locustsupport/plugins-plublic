<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-google-map', [
'label' => __('Google Map', 'theplus'),
    'description' => __('Adds The Plus "Google Map" widget (tp-google-map) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'MapType' => ['type' => 'string', 'description' => 'MapType', 'enum' => ['googlemap', 'osmmap']],
        'latitude' => ['type' => 'string', 'description' => 'Latitude Value'],
        'longitude' => ['type' => 'string', 'description' => 'Longitude Value'],
        'address' => ['type' => 'string', 'description' => 'Address text for Tooltip'],
        'pin_icon' => ['type' => 'integer', 'description' => 'pin_icon (Image ID)'],
        'map_locations' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'map_locations'],
        'min_height' => ['type' => 'object', 'description' => 'Minimum Height (Slider/Size Object)'],
        'zoom' => ['type' => 'object', 'description' => 'Map Zoom (Slider/Size Object)'],
        'gmap_option' => ['type' => 'string', 'description' => 'Map Options', 'enum' => ['draggable', 'fullscreen_control', 'map_type_control', 'marker_clustering', 'multiple', 'pan_control', 'scale_control', 'scroll_wheel', 'streetview_control', 'zoom_control']],
        'map_type' => ['type' => 'string', 'description' => 'Google Map Variations', 'enum' => ['HYBRID', 'ROADMAP', 'SATELLITE', 'TERRAIN']],
        'adv_modify_json' => ['type' => 'string', 'description' => 'Custom Style Maps', 'enum' => ['yes', 'no']],
        'map_style' => ['type' => 'string', 'description' => 'Creative Map Style', 'enum' => ['adv_modify_json']],
        'modify_coloring' => ['type' => 'string', 'description' => 'Modify Google Maps', 'enum' => ['yes', 'no']],
        'hue' => ['type' => 'string', 'description' => 'Hue (Color Hex/RGBA)'],
        'saturation' => ['type' => 'object', 'description' => 'Saturation (Slider/Size Object)'],
        'lightness' => ['type' => 'object', 'description' => 'Lightness (Slider/Size Object)'],
        'overlay_toggle' => ['type' => 'string', 'description' => 'Content Over the Map', 'enum' => ['yes', 'no']],
        'title_text' => ['type' => 'string', 'description' => 'Title'],
        'overlay_content' => ['type' => 'string', 'description' => 'Description'],
        'title_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'desc_color' => ['type' => 'string', 'description' => 'Description Color (Color Hex/RGBA)'],
        'toggle_btn_color' => ['type' => 'string', 'description' => 'Toggle Button Color (Color Hex/RGBA)'],
        'toggle_ative_color' => ['type' => 'string', 'description' => 'Toggle Active Color (Color Hex/RGBA)'],
        'Maplisting' => ['type' => 'string', 'description' => 'Override for WP Search Filter', 'enum' => ['yes', 'no']],
        'mapattrtitlehide' => ['type' => 'string', 'description' => 'Hide Title', 'enum' => ['yes', 'no']],
        'maponhover' => ['type' => 'string', 'description' => 'Content on Hover', 'enum' => ['yes', 'no']],
        'Default_OSMmap' => ['type' => 'string', 'description' => 'Default_OSMmap'],
        'OSM_PointType' => ['type' => 'object', 'description' => 'OSM_PointType', 'enum' => ['circle', 'geoJSON', 'marker']],
        'OSM_PopupType' => ['type' => 'object', 'description' => 'OSM_PopupType', 'enum' => ['none', 'popup', 'tooltip']],
        'OSM_Name' => ['type' => 'string', 'description' => 'OSM_Name'],
        'OSM_latitude' => ['type' => 'string', 'description' => 'Latitude & Longitude'],
        'OSM_Massage' => ['type' => 'string', 'description' => 'OSM_Massage'],
        'OSM_MarkON' => ['type' => 'object', 'description' => 'OSM_MarkON', 'enum' => ['yes', 'no']],
        'Osm_PolylinePen' => ['type' => 'string', 'description' => 'Osm_PolylinePen', 'enum' => ['yes', 'no']],
        'Osm_Polyline' => ['type' => 'string', 'description' => 'Osm_Polyline', 'enum' => ['yes', 'no']],
        'Osm_PolylineCon' => ['type' => 'string', 'description' => 'Osm_PolylineCon'],
        'OsmCustomIcon' => ['type' => 'string', 'description' => 'OsmCustomIcon', 'enum' => ['yes', 'no']],
        'OsmCusImgEnable' => ['type' => 'string', 'description' => 'OsmCusImgEnable', 'enum' => ['yes', 'no']],
        'Osm_imageSelect' => ['type' => 'integer', 'description' => 'Osm_imageSelect (Image ID)'],
        'Osm_iconSize' => ['type' => 'string', 'description' => 'Osm_iconSize'],
        'Osm_PTAnchor' => ['type' => 'string', 'description' => 'Osm_PTAnchor'],
        'GeoJsonSource' => ['type' => 'string', 'description' => 'GeoJsonSource'],
        'OSM_repeater' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Add Location Point'],
        'OSM_MapHeight' => ['type' => 'object', 'description' => 'OSM_MapHeight (Slider/Size Object)'],
        'OSM_ZoomLevel' => ['type' => 'object', 'description' => 'OSM_ZoomLevel (Slider/Size Object)'],
        'OSM_control' => ['type' => 'string', 'description' => 'OSM_control', 'enum' => ['Scalecontrol', 'collapsed', 'doubleClickZoom', 'mapdragging', 'multiple', 'scrollWheelZoom', 'zoomControl']],
        'OSM_collapsed' => ['type' => 'object', 'description' => 'OSM_collapsed', 'enum' => ['yes', 'no']],
        'OSM_Def_TileLayer' => ['type' => 'string', 'description' => 'OSM_Def_TileLayer'],
        'OSM_PolylineCr' => ['type' => 'string', 'description' => 'OSM_PolylineCr (Color Hex/RGBA)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports Snazzy Maps and custom JSON.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_google_map_ability',
    'permission_callback' => 'tpaep_mcp_theplus_google_map_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_google_map_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_google_map_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-google-map';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Google Map widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['MapType'])) { $settings['MapType'] = sanitize_text_field($input['MapType']); }
    if (isset($input['latitude'])) { $settings['latitude'] = sanitize_text_field($input['latitude']); }
    if (isset($input['longitude'])) { $settings['longitude'] = sanitize_text_field($input['longitude']); }
    if (isset($input['address'])) { $settings['address'] = sanitize_text_field($input['address']); }
    if (!empty($input['pin_icon'])) { $settings['pin_icon'] = ['id' => absint($input['pin_icon'])]; }
    if (isset($input['map_locations'])) { $settings['map_locations'] = $input['map_locations']; }
    if (isset($input['min_height'])) { $settings['min_height'] = $input['min_height']; }
    if (isset($input['zoom'])) { $settings['zoom'] = $input['zoom']; }
    if (isset($input['gmap_option'])) { $settings['gmap_option'] = sanitize_text_field($input['gmap_option']); }
    if (isset($input['map_type'])) { $settings['map_type'] = sanitize_text_field($input['map_type']); }
    if (isset($input['adv_modify_json'])) { $settings['adv_modify_json'] = sanitize_text_field($input['adv_modify_json']); }
    if (isset($input['map_style'])) { $settings['map_style'] = sanitize_text_field($input['map_style']); }
    if (isset($input['modify_coloring'])) { $settings['modify_coloring'] = sanitize_text_field($input['modify_coloring']); }
    if (isset($input['hue'])) { $settings['hue'] = sanitize_text_field($input['hue']); }
    if (isset($input['saturation'])) { $settings['saturation'] = $input['saturation']; }
    if (isset($input['lightness'])) { $settings['lightness'] = $input['lightness']; }
    if (isset($input['overlay_toggle'])) { $settings['overlay_toggle'] = sanitize_text_field($input['overlay_toggle']); }
    if (isset($input['title_text'])) { $settings['title_text'] = sanitize_text_field($input['title_text']); }
    if (isset($input['overlay_content'])) { $settings['overlay_content'] = sanitize_text_field($input['overlay_content']); }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['desc_color'])) { $settings['desc_color'] = sanitize_text_field($input['desc_color']); }
    if (isset($input['toggle_btn_color'])) { $settings['toggle_btn_color'] = sanitize_text_field($input['toggle_btn_color']); }
    if (isset($input['toggle_ative_color'])) { $settings['toggle_ative_color'] = sanitize_text_field($input['toggle_ative_color']); }
    if (isset($input['Maplisting'])) { $settings['Maplisting'] = sanitize_text_field($input['Maplisting']); }
    if (isset($input['mapattrtitlehide'])) { $settings['mapattrtitlehide'] = sanitize_text_field($input['mapattrtitlehide']); }
    if (isset($input['maponhover'])) { $settings['maponhover'] = sanitize_text_field($input['maponhover']); }
    if (isset($input['Default_OSMmap'])) { $settings['Default_OSMmap'] = sanitize_text_field($input['Default_OSMmap']); }
    if (isset($input['OSM_PointType'])) { $settings['OSM_PointType'] = $input['OSM_PointType']; }
    if (isset($input['OSM_PopupType'])) { $settings['OSM_PopupType'] = $input['OSM_PopupType']; }
    if (isset($input['OSM_Name'])) { $settings['OSM_Name'] = sanitize_text_field($input['OSM_Name']); }
    if (isset($input['OSM_latitude'])) { $settings['OSM_latitude'] = sanitize_text_field($input['OSM_latitude']); }
    if (isset($input['OSM_Massage'])) { $settings['OSM_Massage'] = sanitize_text_field($input['OSM_Massage']); }
    if (isset($input['OSM_MarkON'])) { $settings['OSM_MarkON'] = $input['OSM_MarkON']; }
    if (isset($input['Osm_PolylinePen'])) { $settings['Osm_PolylinePen'] = sanitize_text_field($input['Osm_PolylinePen']); }
    if (isset($input['Osm_Polyline'])) { $settings['Osm_Polyline'] = sanitize_text_field($input['Osm_Polyline']); }
    if (isset($input['Osm_PolylineCon'])) { $settings['Osm_PolylineCon'] = sanitize_text_field($input['Osm_PolylineCon']); }
    if (isset($input['OsmCustomIcon'])) { $settings['OsmCustomIcon'] = sanitize_text_field($input['OsmCustomIcon']); }
    if (isset($input['OsmCusImgEnable'])) { $settings['OsmCusImgEnable'] = sanitize_text_field($input['OsmCusImgEnable']); }
    if (!empty($input['Osm_imageSelect'])) { $settings['Osm_imageSelect'] = ['id' => absint($input['Osm_imageSelect'])]; }
    if (isset($input['Osm_iconSize'])) { $settings['Osm_iconSize'] = sanitize_text_field($input['Osm_iconSize']); }
    if (isset($input['Osm_PTAnchor'])) { $settings['Osm_PTAnchor'] = sanitize_text_field($input['Osm_PTAnchor']); }
    if (isset($input['GeoJsonSource'])) { $settings['GeoJsonSource'] = sanitize_text_field($input['GeoJsonSource']); }
    if (isset($input['OSM_repeater'])) { $settings['OSM_repeater'] = $input['OSM_repeater']; }
    if (isset($input['OSM_MapHeight'])) { $settings['OSM_MapHeight'] = $input['OSM_MapHeight']; }
    if (isset($input['OSM_ZoomLevel'])) { $settings['OSM_ZoomLevel'] = $input['OSM_ZoomLevel']; }
    if (isset($input['OSM_control'])) { $settings['OSM_control'] = sanitize_text_field($input['OSM_control']); }
    if (isset($input['OSM_collapsed'])) { $settings['OSM_collapsed'] = $input['OSM_collapsed']; }
    if (isset($input['OSM_Def_TileLayer'])) { $settings['OSM_Def_TileLayer'] = sanitize_text_field($input['OSM_Def_TileLayer']); }
    if (isset($input['OSM_PolylineCr'])) { $settings['OSM_PolylineCr'] = sanitize_text_field($input['OSM_PolylineCr']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
