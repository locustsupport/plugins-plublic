<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-draw-svg', [
'label' => __('Draw SVG', 'theplus'),
    'description' => __('Adds The Plus "Draw SVG" widget (tp-draw-svg) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'           => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'         => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'          => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'select_svg_option' => ['type' => 'string', 'description' => 'Select SVG Option', 'enum' => ['svg_icons']],
        'svg_d_icon' => ['type' => 'string', 'description' => 'Select Svg Icon', 'enum' => ['select_svg_option']],
        'svg_image' => ['type' => 'integer', 'description' => 'Choose SVG (Image ID)'],
        'alignment' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'devices', 'icon', 'left', 'prefix_class', 'right']],
        'on_hover_draw' => ['type' => 'string', 'description' => 'On Hover Draw', 'enum' => ['yes', 'no']],
        'on_loop_draw' => ['type' => 'string', 'description' => 'Loop Draw', 'enum' => ['yes', 'no']],
        'connect_interaction' => ['type' => 'string', 'description' => 'Connect GSAP Interaction', 'enum' => ['yes', 'no']],
        'svg_type' => ['type' => 'string', 'description' => 'Select Style Image'],
        'duration' => ['type' => 'object', 'description' => 'Duration (Slider/Size Object)'],
        'width' => ['type' => 'object', 'description' => 'SVG Width  (Slider/Size Object)'],
        'max_width' => ['type' => 'object', 'description' => 'Max Width Svg (Slider/Size Object)'],
        'min_width_switch' => ['type' => 'string', 'description' => 'Min Width Svg', 'enum' => ['yes', 'no']],
        'min_width' => ['type' => 'object', 'description' => 'Min Width Svg (Slider/Size Object)'],
        'border_stroke_color' => ['type' => 'string', 'description' => 'Border/Stoke Color (Color Hex/RGBA)'],
        'svg_fill_enable' => ['type' => 'string', 'description' => 'Fill Color', 'enum' => ['yes', 'no']],
        'svg_fill_color' => ['type' => 'string', 'description' => 'Fill Color (Color Hex/RGBA)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_draw_svg_ability',
    'permission_callback' => 'tpaep_mcp_theplus_draw_svg_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_draw_svg_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_draw_svg_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-draw-svg';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Draw SVG widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['select_svg_option'])) { $settings['select_svg_option'] = sanitize_text_field($input['select_svg_option']); }
    if (isset($input['svg_d_icon'])) { $settings['svg_d_icon'] = sanitize_text_field($input['svg_d_icon']); }
    if (!empty($input['svg_image'])) { $settings['svg_image'] = ['id' => absint($input['svg_image'])]; }
    if (isset($input['alignment'])) { $settings['alignment'] = $input['alignment']; }
    if (isset($input['on_hover_draw'])) { $settings['on_hover_draw'] = sanitize_text_field($input['on_hover_draw']); }
    if (isset($input['on_loop_draw'])) { $settings['on_loop_draw'] = sanitize_text_field($input['on_loop_draw']); }
    if (isset($input['connect_interaction'])) { $settings['connect_interaction'] = sanitize_text_field($input['connect_interaction']); }
    if (isset($input['svg_type'])) { $settings['svg_type'] = sanitize_text_field($input['svg_type']); }
    if (isset($input['duration'])) { $settings['duration'] = $input['duration']; }
    if (isset($input['width'])) { $settings['width'] = $input['width']; }
    if (isset($input['max_width'])) { $settings['max_width'] = $input['max_width']; }
    if (isset($input['min_width_switch'])) { $settings['min_width_switch'] = sanitize_text_field($input['min_width_switch']); }
    if (isset($input['min_width'])) { $settings['min_width'] = $input['min_width']; }
    if (isset($input['border_stroke_color'])) { $settings['border_stroke_color'] = sanitize_text_field($input['border_stroke_color']); }
    if (isset($input['svg_fill_enable'])) { $settings['svg_fill_enable'] = sanitize_text_field($input['svg_fill_enable']); }
    if (isset($input['svg_fill_color'])) { $settings['svg_fill_color'] = sanitize_text_field($input['svg_fill_color']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
