<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-mouse-cursor', [
'label' => __('Mouse Cursor', 'theplus'),
    'description' => __('Adds The Plus "Mouse Cursor" widget (tp-mouse-cursor) for interactive custom pointers.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'           => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'         => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'          => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'cursor_effect' => ['type' => 'string', 'description' => 'Cursor Area', 'enum' => ['mc-body', 'mc-column', 'mc-container', 'mc-section', 'mc-widget']],
        'mouse_cursor_type' => ['type' => 'string', 'description' => 'Type', 'enum' => ['columns', 'mouse-cursor-icon', 'mouse-follow-circle', 'mouse-follow-image', 'mouse-follow-text', 'mouse-move-image']],
        'mc_move_image' => ['type' => 'integer', 'description' => 'Image (Image ID)'],
        'mc_move_width' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'mc_move_offset_x' => ['type' => 'object', 'description' => 'Offset X (Slider/Size Object)'],
        'mc_move_offset_y' => ['type' => 'object', 'description' => 'Offset Y (Slider/Size Object)'],
        'mc_move_image_list' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Image List'],
        'mc_move_duration' => ['type' => 'object', 'description' => 'Duration (Slider/Size Object)'],
        'mc_trail_distance' => ['type' => 'object', 'description' => 'Distance Threshold (Slider/Size Object)'],
        'mc_trail_swipe' => ['type' => 'string', 'description' => 'Swipe Effect', 'enum' => ['yes', 'no']],
        'Icon_cursor_type' => ['type' => 'string', 'description' => 'Icon Type', 'enum' => ['cursor-Icon-custom', 'cursor-Icon-predefine', 'mouse_cursor_type']],
        'mc_cursor_icon_symbol' => ['type' => 'string', 'description' => 'Select', 'enum' => ['Icon_cursor_type', 'alias', 'all-scroll', 'auto', 'cell', 'col-resize', 'context-menu', 'copy', 'crosshair', 'e-resize', 'ew-resize', 'grab', 'grabbing', 'help', 'mouse_cursor_type', 'move', 'n-resize', 'ne-resize', 'nesw-resize', 'no-drop', 'none', 'not-allowed', 'ns-resize', 'nw-resize', 'nwse-resize', 'pointer', 'progress', 'row-resize', 's-resize', 'se-resize', 'sw-resize', 'text', 'w-resize', 'wait', 'zoom-in', 'zoom-out']],
        'circle_cursor_type' => ['type' => 'string', 'description' => 'Pointer Type', 'enum' => ['cursor-custom', 'cursor-predefine', 'mouse_cursor_type']],
        'mc_cursor_symbol' => ['type' => 'string', 'description' => 'Select Pointer', 'enum' => ['alias', 'all-scroll', 'auto', 'cell', 'circle_cursor_type', 'col-resize', 'context-menu', 'copy', 'crosshair', 'e-resize', 'ew-resize', 'grab', 'grabbing', 'help', 'mouse_cursor_type', 'move', 'n-resize', 'ne-resize', 'nesw-resize', 'no-drop', 'none', 'not-allowed', 'ns-resize', 'nw-resize', 'nwse-resize', 'pointer', 'progress', 'row-resize', 's-resize', 'se-resize', 'sw-resize', 'text', 'w-resize', 'wait', 'zoom-in', 'zoom-out', '{{WRAPPER}} .plus-cursor-follow-circle']],
        'circle_style' => ['type' => 'string', 'description' => 'Follow Circle Style', 'enum' => ['circle_cursor_type', 'mc-cs1', 'mc-cs2', 'mc-cs3', 'mouse_cursor_type']],
        'mc_pointer_icon' => ['type' => 'integer', 'description' => 'Cursor Icon (Image ID)'],
        'mc_pointer_content_type' => ['type' => 'string', 'description' => 'Content Type', 'enum' => ['circle_cursor_type', 'mouse_cursor_type']],
        'mc_pointer_icon_cir_cst' => ['type' => 'integer', 'description' => 'Cursor Icon (Image ID)'],
        'mc_pointer_color_cst' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'mc_pointer_radius_cst' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'mc_pointer_size_cst' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'mc_pointer_blur_cst' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'mc_pointer_blend_mode_cst' => ['type' => 'string', 'description' => 'Mix Blend Mode', 'enum' => ['circle_cursor_type', 'color-burn', 'color-dodge', 'darken', 'difference', 'exclusion', 'hard-light', 'hue', 'lighten', 'luminosity', 'mc_pointer_content_type', 'mouse_cursor_type', 'multiply', 'normal', 'overlay', 'saturation', 'screen', 'soft-light', '{{WRAPPER}} .plus-cursor-follow-circle']],
        'mc_pointer_icon_width' => ['type' => 'object', 'description' => 'Icon Max Width (Slider/Size Object)'],
        'mc_follow_circle_width' => ['type' => 'object', 'description' => 'Circle Max Width (Slider/Size Object)'],
        'mc_follow_circle_height' => ['type' => 'object', 'description' => 'Circle Max Height (Slider/Size Object)'],
        'mc_2_first_circle_size' => ['type' => 'object', 'description' => 'First Circle Size (Slider/Size Object)'],
        'mc_2_second_circle_size' => ['type' => 'object', 'description' => 'Second Circle Size (Slider/Size Object)'],
        'mc_pointer_text' => ['type' => 'string', 'description' => 'Follow Text'],
        'mc_pointer_left_offset' => ['type' => 'object', 'description' => 'Cursor Left Offset (Slider/Size Object)'],
        'mc_pointer_top_offset' => ['type' => 'object', 'description' => 'Cursor Top Offset (Slider/Size Object)'],
        'mc_circle_z_index' => ['type' => 'object', 'description' => 'Circle Z-Index (Slider/Size Object)'],
        'mc_click_cursor' => ['type' => 'string', 'description' => 'Mouse Cursor Click', 'enum' => ['yes', 'no']],
        'mc_pointer_click_icon' => ['type' => 'integer', 'description' => 'Cursor Click Icon (Image ID)'],
        'mc_pointer_click_text' => ['type' => 'string', 'description' => 'Click Follow Text'],
        'mc_click_cursor_cir_cst' => ['type' => 'string', 'description' => 'Mouse Cursor Click', 'enum' => ['yes', 'no']],
        'mc_pointer_click_icon_cst' => ['type' => 'integer', 'description' => 'Cursor Click Icon (Image ID)'],
        'stl_tag_select' => ['type' => 'string', 'description' => 'List of Tags for Hover Effect'],
        'tpaep_theme_builder' => ['type' => 'string', 'description' => 'tpaep_theme_builder'],
        'mc_follow_text_padding' => ['type' => 'object', 'description' => 'Text Padding (Dimensions Object)'],
        'mc_follow_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'mc_follow_text_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'widget_follow_text_size' => ['type' => 'object', 'description' => 'Text Size (Slider/Size Object)'],
        'widget_follow_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'circle_stltwo_mxbndmd' => ['type' => 'string', 'description' => 'Mix Blend Mode', 'enum' => ['circle_cursor_type', 'circle_style', 'color-burn', 'color-dodge', 'darken', 'difference', 'exclusion', 'hue', 'lighten', 'luminosity', 'mouse_cursor_type', 'multiply', 'normal', 'overlay', 'saturation', 'screen', '{{WRAPPER}} .plus-cursor-follow-circle']],
        'circle_stltwo_background' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'circle_opacity' => ['type' => 'string', 'description' => 'Opacity'],
        'circle_stlone_stroke' => ['type' => 'string', 'description' => 'Circle Color (Color Hex/RGBA)'],
        'circle_stlone_stroke_width' => ['type' => 'object', 'description' => 'Circle Stroke Width (Slider/Size Object)'],
        'circle_stlone_fill' => ['type' => 'string', 'description' => 'Fill Color (Color Hex/RGBA)'],
        'circle_stlone_opacity' => ['type' => 'string', 'description' => 'Opacity'],
        'circle_stlone_stroke_progress' => ['type' => 'string', 'description' => 'Circle Progress Color (Color Hex/RGBA)'],
        'circle_stlone_stroke_progress_width' => ['type' => 'object', 'description' => 'Circle Stroke Progress Width (Slider/Size Object)'],
        'circle_transformNml' => ['type' => 'string', 'description' => 'Transform CSS'],
        'circle_transition_Nml' => ['type' => 'object', 'description' => 'Transition Duration (Slider/Size Object)'],
        'circle_scale' => ['type' => 'string', 'description' => 'Circle Scale ( 0.5 - 2 )'],
        'circle_stltwo_background_h' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'circle_stlone_stroke_h' => ['type' => 'string', 'description' => 'Circle Color (Color Hex/RGBA)'],
        'circle_stlone_stroke_width_h' => ['type' => 'object', 'description' => 'Circle Stroke Width (Slider/Size Object)'],
        'circle_stlone_fill_h' => ['type' => 'string', 'description' => 'Fill Color (Color Hex/RGBA)'],
        'circle_stlone_stroke_progress_h' => ['type' => 'string', 'description' => 'Circle Progress Color (Color Hex/RGBA)'],
        'circle_stlone_stroke_progress_width_h' => ['type' => 'object', 'description' => 'Circle Stroke Progress Width (Slider/Size Object)'],
        'circle_transformHvr' => ['type' => 'string', 'description' => 'Transform CSS'],
        'circle_transition_Hvr' => ['type' => 'object', 'description' => 'Transition Duration (Slider/Size Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports blend modes, backdrop filters, and image masking.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_mouse_cursor_ability',
    'permission_callback' => 'tpaep_mcp_theplus_mouse_cursor_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_mouse_cursor_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_mouse_cursor_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-mouse-cursor';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Mouse Cursor widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }

    if (isset($input['cursor_effect'])) { $settings['cursor_effect'] = sanitize_text_field($input['cursor_effect']); }
    if (isset($input['mouse_cursor_type'])) { $settings['mouse_cursor_type'] = sanitize_text_field($input['mouse_cursor_type']); }
    if (!empty($input['mc_move_image'])) { $settings['mc_move_image'] = ['id' => absint($input['mc_move_image'])]; }
    if (isset($input['mc_move_width'])) { $settings['mc_move_width'] = $input['mc_move_width']; }
    if (isset($input['mc_move_offset_x'])) { $settings['mc_move_offset_x'] = $input['mc_move_offset_x']; }
    if (isset($input['mc_move_offset_y'])) { $settings['mc_move_offset_y'] = $input['mc_move_offset_y']; }
    if (isset($input['mc_move_image_list'])) { $settings['mc_move_image_list'] = $input['mc_move_image_list']; }
    if (isset($input['mc_move_duration'])) { $settings['mc_move_duration'] = $input['mc_move_duration']; }
    if (isset($input['mc_trail_distance'])) { $settings['mc_trail_distance'] = $input['mc_trail_distance']; }
    if (isset($input['mc_trail_swipe'])) { $settings['mc_trail_swipe'] = sanitize_text_field($input['mc_trail_swipe']); }
    if (isset($input['Icon_cursor_type'])) { $settings['Icon_cursor_type'] = sanitize_text_field($input['Icon_cursor_type']); }
    if (isset($input['mc_cursor_icon_symbol'])) { $settings['mc_cursor_icon_symbol'] = sanitize_text_field($input['mc_cursor_icon_symbol']); }
    if (isset($input['circle_cursor_type'])) { $settings['circle_cursor_type'] = sanitize_text_field($input['circle_cursor_type']); }
    if (isset($input['mc_cursor_symbol'])) { $settings['mc_cursor_symbol'] = sanitize_text_field($input['mc_cursor_symbol']); }
    if (isset($input['circle_style'])) { $settings['circle_style'] = sanitize_text_field($input['circle_style']); }
    if (!empty($input['mc_pointer_icon'])) { $settings['mc_pointer_icon'] = ['id' => absint($input['mc_pointer_icon'])]; }
    if (isset($input['mc_pointer_content_type'])) { $settings['mc_pointer_content_type'] = sanitize_text_field($input['mc_pointer_content_type']); }
    if (!empty($input['mc_pointer_icon_cir_cst'])) { $settings['mc_pointer_icon_cir_cst'] = ['id' => absint($input['mc_pointer_icon_cir_cst'])]; }
    if (isset($input['mc_pointer_color_cst'])) { $settings['mc_pointer_color_cst'] = sanitize_text_field($input['mc_pointer_color_cst']); }
    if (isset($input['mc_pointer_radius_cst'])) { $settings['mc_pointer_radius_cst'] = $input['mc_pointer_radius_cst']; }
    if (isset($input['mc_pointer_size_cst'])) { $settings['mc_pointer_size_cst'] = $input['mc_pointer_size_cst']; }
    if (isset($input['mc_pointer_blur_cst'])) { $settings['mc_pointer_blur_cst'] = $input['mc_pointer_blur_cst']; }
    if (isset($input['mc_pointer_blend_mode_cst'])) { $settings['mc_pointer_blend_mode_cst'] = sanitize_text_field($input['mc_pointer_blend_mode_cst']); }
    if (isset($input['mc_pointer_icon_width'])) { $settings['mc_pointer_icon_width'] = $input['mc_pointer_icon_width']; }
    if (isset($input['mc_follow_circle_width'])) { $settings['mc_follow_circle_width'] = $input['mc_follow_circle_width']; }
    if (isset($input['mc_follow_circle_height'])) { $settings['mc_follow_circle_height'] = $input['mc_follow_circle_height']; }
    if (isset($input['mc_2_first_circle_size'])) { $settings['mc_2_first_circle_size'] = $input['mc_2_first_circle_size']; }
    if (isset($input['mc_2_second_circle_size'])) { $settings['mc_2_second_circle_size'] = $input['mc_2_second_circle_size']; }
    if (isset($input['mc_pointer_text'])) { $settings['mc_pointer_text'] = sanitize_text_field($input['mc_pointer_text']); }
    if (isset($input['mc_pointer_left_offset'])) { $settings['mc_pointer_left_offset'] = $input['mc_pointer_left_offset']; }
    if (isset($input['mc_pointer_top_offset'])) { $settings['mc_pointer_top_offset'] = $input['mc_pointer_top_offset']; }
    if (isset($input['mc_circle_z_index'])) { $settings['mc_circle_z_index'] = $input['mc_circle_z_index']; }
    if (isset($input['mc_click_cursor'])) { $settings['mc_click_cursor'] = sanitize_text_field($input['mc_click_cursor']); }
    if (!empty($input['mc_pointer_click_icon'])) { $settings['mc_pointer_click_icon'] = ['id' => absint($input['mc_pointer_click_icon'])]; }
    if (isset($input['mc_pointer_click_text'])) { $settings['mc_pointer_click_text'] = sanitize_text_field($input['mc_pointer_click_text']); }
    if (isset($input['mc_click_cursor_cir_cst'])) { $settings['mc_click_cursor_cir_cst'] = sanitize_text_field($input['mc_click_cursor_cir_cst']); }
    if (!empty($input['mc_pointer_click_icon_cst'])) { $settings['mc_pointer_click_icon_cst'] = ['id' => absint($input['mc_pointer_click_icon_cst'])]; }
    if (isset($input['stl_tag_select'])) { $settings['stl_tag_select'] = sanitize_text_field($input['stl_tag_select']); }
    if (isset($input['tpaep_theme_builder'])) { $settings['tpaep_theme_builder'] = sanitize_text_field($input['tpaep_theme_builder']); }
    if (isset($input['mc_follow_text_padding'])) { $settings['mc_follow_text_padding'] = $input['mc_follow_text_padding']; }
    if (isset($input['mc_follow_text_color'])) { $settings['mc_follow_text_color'] = sanitize_text_field($input['mc_follow_text_color']); }
    if (isset($input['mc_follow_text_border_radius'])) { $settings['mc_follow_text_border_radius'] = $input['mc_follow_text_border_radius']; }
    if (isset($input['widget_follow_text_size'])) { $settings['widget_follow_text_size'] = $input['widget_follow_text_size']; }
    if (isset($input['widget_follow_text_color'])) { $settings['widget_follow_text_color'] = sanitize_text_field($input['widget_follow_text_color']); }
    if (isset($input['circle_stltwo_mxbndmd'])) { $settings['circle_stltwo_mxbndmd'] = sanitize_text_field($input['circle_stltwo_mxbndmd']); }
    if (isset($input['circle_stltwo_background'])) { $settings['circle_stltwo_background'] = sanitize_text_field($input['circle_stltwo_background']); }
    if (isset($input['circle_opacity'])) { $settings['circle_opacity'] = sanitize_text_field($input['circle_opacity']); }
    if (isset($input['circle_stlone_stroke'])) { $settings['circle_stlone_stroke'] = sanitize_text_field($input['circle_stlone_stroke']); }
    if (isset($input['circle_stlone_stroke_width'])) { $settings['circle_stlone_stroke_width'] = $input['circle_stlone_stroke_width']; }
    if (isset($input['circle_stlone_fill'])) { $settings['circle_stlone_fill'] = sanitize_text_field($input['circle_stlone_fill']); }
    if (isset($input['circle_stlone_opacity'])) { $settings['circle_stlone_opacity'] = sanitize_text_field($input['circle_stlone_opacity']); }
    if (isset($input['circle_stlone_stroke_progress'])) { $settings['circle_stlone_stroke_progress'] = sanitize_text_field($input['circle_stlone_stroke_progress']); }
    if (isset($input['circle_stlone_stroke_progress_width'])) { $settings['circle_stlone_stroke_progress_width'] = $input['circle_stlone_stroke_progress_width']; }
    if (isset($input['circle_transformNml'])) { $settings['circle_transformNml'] = sanitize_text_field($input['circle_transformNml']); }
    if (isset($input['circle_transition_Nml'])) { $settings['circle_transition_Nml'] = $input['circle_transition_Nml']; }
    if (isset($input['circle_scale'])) { $settings['circle_scale'] = sanitize_text_field($input['circle_scale']); }
    if (isset($input['circle_stltwo_background_h'])) { $settings['circle_stltwo_background_h'] = sanitize_text_field($input['circle_stltwo_background_h']); }
    if (isset($input['circle_stlone_stroke_h'])) { $settings['circle_stlone_stroke_h'] = sanitize_text_field($input['circle_stlone_stroke_h']); }
    if (isset($input['circle_stlone_stroke_width_h'])) { $settings['circle_stlone_stroke_width_h'] = $input['circle_stlone_stroke_width_h']; }
    if (isset($input['circle_stlone_fill_h'])) { $settings['circle_stlone_fill_h'] = sanitize_text_field($input['circle_stlone_fill_h']); }
    if (isset($input['circle_stlone_stroke_progress_h'])) { $settings['circle_stlone_stroke_progress_h'] = sanitize_text_field($input['circle_stlone_stroke_progress_h']); }
    if (isset($input['circle_stlone_stroke_progress_width_h'])) { $settings['circle_stlone_stroke_progress_width_h'] = $input['circle_stlone_stroke_progress_width_h']; }
    if (isset($input['circle_transformHvr'])) { $settings['circle_transformHvr'] = sanitize_text_field($input['circle_transformHvr']); }
    if (isset($input['circle_transition_Hvr'])) { $settings['circle_transition_Hvr'] = $input['circle_transition_Hvr']; }

    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
