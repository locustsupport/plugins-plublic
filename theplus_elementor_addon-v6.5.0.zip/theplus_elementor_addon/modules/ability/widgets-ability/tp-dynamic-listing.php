<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-dynamic-listing', [
'label' => __('Dynamic Listing', 'theplus'),
    'description' => __('Adds The Plus "Dynamic Listing" widget (tp-dynamic-listing) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'       => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'     => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'      => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'blogs_post_listing' => ['type' => 'string', 'description' => 'Post Listing Types', 'enum' => ['acf_repeater', 'archive_listing', 'custom_query', 'page_listing', 'related_post', 'search_list', 'wishlist']],
        'uniquename' => ['type' => 'string', 'description' => 'Unique Name'],
        'extra_query_id' => ['type' => 'string', 'description' => 'Query ID'],
        'query' => ['type' => 'string', 'description' => 'Post Type', 'enum' => ['blogs_post_listing!']],
        'related_post_by' => ['type' => 'string', 'description' => 'Related Post Type', 'enum' => ['blogs_post_listing', 'both', 'category', 'tags', 'taxonomy']],
        'style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['blogs_post_listing!', 'columns', 'custom', 'smart-loop-builder', 'style-1', 'style-2', 'style-3', 'style-4']],
        'skin_template' => ['type' => 'string', 'description' => 'Select a template', 'enum' => ['conditions', 'name', 'operator', 'relation', 'terms', 'value']],
        'acf_repeater_field' => ['type' => 'string', 'description' => 'acf_repeater_field', 'enum' => ['blogs_post_listing', 'custom']],
        'acf_repeater_field_list' => ['type' => 'string', 'description' => 'acf_repeater_field_list', 'enum' => ['acf_repeater_field', 'blogs_post_listing']],
        'acf_filed_name' => ['type' => 'string', 'description' => 'acf_filed_name'],
        'acf_repeater_field_conditions' => ['type' => 'string', 'description' => 'ACF Repeater Boolean Conditions', 'enum' => ['yes', 'no']],
        'acf_rf_name' => ['type' => 'string', 'description' => 'acf_rf_name'],
        'multiple_skin_enable' => ['type' => 'string', 'description' => 'Multiple Loops', 'enum' => ['yes', 'no']],
        'skin_template2' => ['type' => 'string', 'description' => 'Loop Template 2', 'enum' => ['blogs_post_listing!', 'multiple_skin_enable', 'style']],
        'skin_template3' => ['type' => 'string', 'description' => 'Loop Template 3', 'enum' => ['blogs_post_listing!', 'multiple_skin_enable', 'style']],
        'skin_template4' => ['type' => 'string', 'description' => 'Loop Template 4', 'enum' => ['blogs_post_listing!', 'multiple_skin_enable', 'style']],
        'skin_template5' => ['type' => 'string', 'description' => 'Loop Template 5', 'enum' => ['blogs_post_listing!', 'multiple_skin_enable', 'style']],
        'layout' => ['type' => 'string', 'description' => 'Layout', 'enum' => ['carousel', 'columns', 'grid', 'masonry', 'metro']],
        'template_order' => ['type' => 'string', 'description' => 'Template Order', 'enum' => ['blogs_post_listing!', 'random', 'reverse', 'style']],
        'content_alignment' => ['type' => 'string', 'description' => 'Content Alignment', 'enum' => ['blogs_post_listing!', 'center', 'icon', 'layout!', 'left', 'style', 'toggle']],
        'content_alignment_3' => ['type' => 'string', 'description' => 'Content Alignment', 'enum' => ['blogs_post_listing!', 'icon', 'layout!', 'left', 'left-right', 'right', 'style', 'toggle']],
        'style_layout' => ['type' => 'string', 'description' => 'Style Layout', 'enum' => ['blogs_post_listing!', 'style']],
        'column_min_height' => ['type' => 'object', 'description' => 'Minimum Height (Slider/Size Object)'],
        'search_list_customQ' => ['type' => 'string', 'description' => 'search_list_customQ', 'enum' => ['yes', 'no']],
        'extra_query_id_search' => ['type' => 'string', 'description' => 'Custom Query ID'],
        'post_category' => ['type' => 'string', 'description' => 'Select Category', 'enum' => ['blogs_post_listing!', 'multiple', 'query']],
        'post_tags' => ['type' => 'string', 'description' => 'Select Tags', 'enum' => ['blogs_post_listing!', 'multiple', 'query']],
        'post_taxonomies' => ['type' => 'string', 'description' => 'Taxonomies', 'enum' => ['blogs_post_listing!', 'query!']],
        'include_slug' => ['type' => 'string', 'description' => 'Taxonomies Slug'],
        'include_posts' => ['type' => 'string', 'description' => 'Include Post(s)'],
        'exclude_posts' => ['type' => 'string', 'description' => 'Exclude Post(s)'],
        'display_posts' => ['type' => 'string', 'description' => 'Maximum Posts Display'],
        'post_offset' => ['type' => 'string', 'description' => 'Offset Posts'],
        'post_order_by' => ['type' => 'string', 'description' => 'post_order_by', 'enum' => ['blogs_post_listing!']],
        'post_order' => ['type' => 'string', 'description' => 'Order', 'enum' => ['blogs_post_listing!']],
        'desktop_column' => ['type' => 'string', 'description' => 'Desktop Column', 'enum' => ['layout!']],
        'tablet_column' => ['type' => 'string', 'description' => 'Tablet Column', 'enum' => ['layout!']],
        'mobile_column' => ['type' => 'string', 'description' => 'Mobile Column', 'enum' => ['layout!']],
        'metro_column' => ['type' => 'string', 'description' => 'Metro Column', 'enum' => ['3', '4', '5', '6', 'layout']],
        'metro_style_3' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_3' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_4' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_4' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_5' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_5' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_6' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_6' => ['type' => 'string', 'description' => 'Custom Layout'],
        'responsive_tablet_metro' => ['type' => 'string', 'description' => 'Tablet Responsive', 'enum' => ['yes', 'no']],
        'tablet_metro_column' => ['type' => 'string', 'description' => 'Metro Column', 'enum' => ['3', '4', '5', '6', 'layout', 'responsive_tablet_metro']],
        'tablet_metro_style_3' => ['type' => 'string', 'description' => 'Tablet Metro Style', 'enum' => ['layout', 'responsive_tablet_metro', 'tablet_metro_column']],
        'metro_custom_col_tab' => ['type' => 'string', 'description' => 'Custom Layout'],
        'columns_gap' => ['type' => 'object', 'description' => 'Columns Gap/Space Between (Dimensions Object)'],
        'filter_category' => ['type' => 'string', 'description' => 'Category Wise Filter', 'enum' => ['yes', 'no']],
        'filter_category_image' => ['type' => 'string', 'description' => 'Feature Image', 'enum' => ['yes', 'no']],
        'child_filter_category' => ['type' => 'string', 'description' => 'Child Category Filter', 'enum' => ['yes', 'no']],
        'filter_category_image_child' => ['type' => 'string', 'description' => 'Child Feature Image', 'enum' => ['yes', 'no']],
        'filter_by' => ['type' => 'string', 'description' => 'Filter by', 'enum' => ['blogs_post_listing!', 'filter_by_category', 'filter_by_tag', 'filter_category', 'layout!', 'query']],
        'filter_type' => ['type' => 'string', 'description' => 'Filter Type', 'enum' => ['ajax_base', 'filter_category', 'normal']],
        'filter_search_type' => ['type' => 'string', 'description' => 'Search Type', 'enum' => ['filter_category', 'slug', 'term_id']],
        'all_filter_category_switch' => ['type' => 'string', 'description' => 'All Filter', 'enum' => ['yes', 'no']],
        'all_filter_category' => ['type' => 'string', 'description' => 'All Filter Category Text'],
        'all_filter_category_filter' => ['type' => 'string', 'description' => 'Filters Text'],
        'filter_style' => ['type' => 'string', 'description' => 'Category Filter Style', 'enum' => ['blogs_post_listing!', 'filter_category', 'layout!']],
        'filter_hover_style' => ['type' => 'string', 'description' => 'Filter Hover Style', 'enum' => ['blogs_post_listing!', 'filter_category', 'layout!']],
        'filter_category_align' => ['type' => 'string', 'description' => 'Filter Alignment', 'enum' => ['blogs_post_listing!', 'center', 'filter_category', 'icon', 'layout!', 'left', 'right', 'toggle']],
        'post_extra_option' => ['type' => 'string', 'description' => 'More Post Loading Options', 'enum' => ['blogs_post_listing!']],
        'paginationType' => ['type' => 'string', 'description' => 'Pagination Type', 'enum' => ['ajaxbased', 'post_extra_option', 'standard']],
        'pagination_next' => ['type' => 'string', 'description' => 'Pagination Next'],
        'pagination_prev' => ['type' => 'string', 'description' => 'Pagination Previous'],
        'pagination_align' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['blogs_post_listing!', 'center', 'devices', 'flex-end', 'flex-start', 'icon', 'post_extra_option', '{{WRAPPER}} .theplus-pagination']],
        'pagination_color' => ['type' => 'string', 'description' => 'Pagination Text Color (Color Hex/RGBA)'],
        'pagination_hover_color' => ['type' => 'string', 'description' => 'Pagination Hover Color (Color Hex/RGBA)'],
        'cqid_pagination' => ['type' => 'string', 'description' => 'Pagination', 'enum' => ['yes', 'no']],
        'cqid_pagination_color' => ['type' => 'string', 'description' => 'Pagination Text Color (Color Hex/RGBA)'],
        'cqid_pagination_hover_color' => ['type' => 'string', 'description' => 'Pagination Hover Color (Color Hex/RGBA)'],
        'load_more_btn_text' => ['type' => 'string', 'description' => 'Button Text'],
        'tp_loading_text' => ['type' => 'string', 'description' => 'Loading Text'],
        'loaded_posts_text' => ['type' => 'string', 'description' => 'All Posts Loaded Text'],
        'load_more_post' => ['type' => 'string', 'description' => 'More posts on click/scroll'],
        'load_more_border' => ['type' => 'string', 'description' => 'Load More Border', 'enum' => ['yes', 'no']],
        'load_more_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['blogs_post_listing!', 'load_more_border', 'post_extra_option', '{{WRAPPER}} .ajax_load_more .post-load-more,{{WRAPPER}} .ajax_load_more .tp-morefilter']],
        'load_more_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'load_more_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'load_more_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'load_more_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'load_more_border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'loaded_posts_color' => ['type' => 'string', 'description' => 'Loaded Posts Text Color (Color Hex/RGBA)'],
        'load_more_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'loading_spin_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'loading_spin_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'loading_spin_border_size' => ['type' => 'object', 'description' => 'Border Size (Slider/Size Object)'],
        'load_more_color_hover' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'post_title_tag' => ['type' => 'string', 'description' => 'Title Tag', 'enum' => ['style!']],
        'display_title_limit' => ['type' => 'string', 'description' => 'Title Limit', 'enum' => ['yes', 'no']],
        'display_title_by' => ['type' => 'string', 'description' => 'Limit on', 'enum' => ['char', 'display_title_limit', 'word']],
        'display_title_input' => ['type' => 'string', 'description' => 'Title Count'],
        'display_title_3_dots' => ['type' => 'string', 'description' => 'Display Dots', 'enum' => ['yes', 'no']],
        'featured_image_type' => ['type' => 'string', 'description' => 'Featured Image Type', 'enum' => ['custom', 'full', 'grid', 'layout']],
        'feature_image' => ['type' => 'string', 'description' => 'Display Featured Image', 'enum' => ['yes', 'no']],
        'title_desc_word_break' => ['type' => 'string', 'description' => 'Title & Description Word Break', 'enum' => ['break-all', 'keep-all', 'normal']],
        'display_post_category' => ['type' => 'string', 'description' => 'Display Category Post', 'enum' => ['yes', 'no']],
        'post_category_style' => ['type' => 'string', 'description' => 'Post Category Style', 'enum' => ['display_post_category', 'style!']],
        'display_post_category_all' => ['type' => 'string', 'description' => 'Display All Category', 'enum' => ['yes', 'no']],
        'display_excerpt' => ['type' => 'string', 'description' => 'Display Excerpt/Content', 'enum' => ['yes', 'no']],
        'post_excerpt_count' => ['type' => 'string', 'description' => 'Excerpt/Content Count'],
        'display_thumbnail' => ['type' => 'string', 'description' => 'Display Image Size', 'enum' => ['yes', 'no']],
        'display_post_meta' => ['type' => 'string', 'description' => 'Display Post Meta', 'enum' => ['yes', 'no']],
        'post_meta_tag_style' => ['type' => 'string', 'description' => 'Post Meta Tag', 'enum' => ['display_post_meta', 'style!']],
        'author_prefix' => ['type' => 'string', 'description' => 'Author Prefix'],
        'display_post_meta_date' => ['type' => 'string', 'description' => 'Display Date', 'enum' => ['yes', 'no']],
        'date_type' => ['type' => 'string', 'description' => 'Type', 'enum' => ['display_post_meta_date', 'post_modified', 'post_published']],
        'display_post_meta_author' => ['type' => 'string', 'description' => 'Display Author', 'enum' => ['yes', 'no']],
        'display_post_meta_author_pic' => ['type' => 'string', 'description' => 'Display Author Picture', 'enum' => ['yes', 'no']],
        'display_button' => ['type' => 'string', 'description' => 'Button', 'enum' => ['yes', 'no']],
        'button_style' => ['type' => 'string', 'description' => 'Button Style', 'enum' => ['display_button', 'style', 'style-7', 'style-8', 'style-9']],
        'button_text' => ['type' => 'string', 'description' => 'Text'],
        'button_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['button_style!', 'display_button', 'font_awesome', 'icon_mind', 'style']],
        'button_icon' => ['type' => 'string', 'description' => 'Icon'],
        'button_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['button_icon_style', 'button_style!', 'display_button', 'style']],
        'before_after' => ['type' => 'string', 'description' => 'Icon Position', 'enum' => ['after', 'before', 'button_icon_style!', 'button_style!', 'display_button', 'style']],
        'icon_spacing' => ['type' => 'object', 'description' => 'Icon Spacing (Slider/Size Object)'],
        'display_theplus_quickview' => ['type' => 'string', 'description' => 'Display TP Quickview', 'enum' => ['yes', 'no']],
        'tpqc' => ['type' => 'string', 'description' => 'tpqc', 'enum' => ['blogs_post_listing!', 'custom_template', 'display_theplus_quickview', 'layout!']],
        'custom_template_select' => ['type' => 'string', 'description' => 'Template', 'enum' => ['blogs_post_listing!', 'display_theplus_quickview', 'layout!', 'tpqc']],
        'tp_list_preloader' => ['type' => 'string', 'description' => 'tp_list_preloader', 'enum' => ['yes', 'no']],
        'tp_list_preloader_hw' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'tp_list_preloader_size' => ['type' => 'object', 'description' => 'Border Size (Slider/Size Object)'],
        'tp_list_preloader_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'loading_options' => ['type' => 'string', 'description' => 'Loading Options', 'enum' => ['blogs_post_listing!', 'layout!', 'skeleton']],
        'filter_url' => ['type' => 'string', 'description' => 'URL Enable', 'enum' => ['yes', 'no']],
        'empty_posts_message' => ['type' => 'string', 'description' => 'No Posts Message'],
        'tpaep_theme_builder' => ['type' => 'string', 'description' => 'tpaep_theme_builder'],
        'post_meta_color' => ['type' => 'string', 'description' => 'Post Meta Color (Color Hex/RGBA)'],
        'post_meta_color_hover' => ['type' => 'string', 'description' => 'Post Meta Color (Color Hex/RGBA)'],
        'post_meta_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'category_inner_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'category_color' => ['type' => 'string', 'description' => 'Category Color (Color Hex/RGBA)'],
        'category_hover_color' => ['type' => 'string', 'description' => 'Category Color (Color Hex/RGBA)'],
        'category_2_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'category_border' => ['type' => 'string', 'description' => 'Category Border', 'enum' => ['yes', 'no']],
        'category_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['category_border', 'display_post_category', 'post_category_style', '{{WRAPPER}} .dynamic-listing .post-inner-loop .post-category-list span a']],
        'box_category_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'category_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'category_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'category_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'category_border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'title_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'title_hover_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'excerpt_color' => ['type' => 'string', 'description' => 'Content Color (Color Hex/RGBA)'],
        'excerpt_hover_color' => ['type' => 'string', 'description' => 'Content Color (Color Hex/RGBA)'],
        'content_between_space' => ['type' => 'object', 'description' => 'Content Space (Slider/Size Object)'],
        'hover_image_style' => ['type' => 'string', 'description' => 'Image Hover Effect'],
        'featured_image_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'full_image_size' => ['type' => 'string', 'description' => 'Full Image', 'enum' => ['yes', 'no']],
        'full_image_size_min_height' => ['type' => 'object', 'description' => 'Image Height (Slider/Size Object)'],
        'qv_align' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'flex-end', 'flex-start', 'icon', 'toggle', '{{WRAPPER}} .tp-dl-quickview']],
        'qv_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'qv_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'qv_hover_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'qv_br_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'button_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'btn_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'button_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['button_style', 'dashed', 'dotted', 'groove', 'none', 'solid', '{{WRAPPER}} .pt_plus_button.button-style-8 .button-link-wrap']],
        'button_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'button_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'button_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'btn_text_hover_color' => ['type' => 'string', 'description' => 'Text Hover Color (Color Hex/RGBA)'],
        'button_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'button_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        'filter_category_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'filter_category_marign' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'filter_category_4_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'filters_text_color' => ['type' => 'string', 'description' => 'Filters Text Color (Color Hex/RGBA)'],
        'filter_category_color' => ['type' => 'string', 'description' => 'Category Filter Color (Color Hex/RGBA)'],
        'filter_category_4_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'filter_category_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'filter_category_hover_color' => ['type' => 'string', 'description' => 'Category Filter Color (Color Hex/RGBA)'],
        'filter_category_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'filter_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'category_count_color' => ['type' => 'string', 'description' => 'Category Count Color (Color Hex/RGBA)'],
        'category_count_bg_color' => ['type' => 'string', 'description' => 'Count Background Color (Color Hex/RGBA)'],
        'fc_max_width' => ['type' => 'object', 'description' => 'Max Width (Slider/Size Object)'],
        'fc_margin_bottom' => ['type' => 'object', 'description' => 'Bottom Space (Slider/Size Object)'],
        'fc__br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'fcc__margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'fcc__padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'fcc_fi_max_width' => ['type' => 'object', 'description' => 'Max Width (Slider/Size Object)'],
        'fcc_fi_margin_bottom' => ['type' => 'object', 'description' => 'Bottom Space (Slider/Size Object)'],
        'fcc_fi__br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'fcc__cat_n_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'fcc__cat_n__br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'fcc__cat_ha_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'fcc__cat_ha__br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'content_inner_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'box_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['box_border', '{{WRAPPER}} .dynamic-listing .post-inner-loop .grid-item .blog-list-content']],
        'box_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'box_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'box_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'carousel_unique_id' => ['type' => 'string', 'description' => 'Unique Carousel ID'],
        'slider_direction' => ['type' => 'string', 'description' => 'Slider Mode', 'enum' => ['horizontal', 'vertical']],
        'carousel_direction' => ['type' => 'string', 'description' => 'Slide Direction', 'enum' => ['ltr', 'rtl']],
        'slide_speed' => ['type' => 'object', 'description' => 'Slide Speed (Slider/Size Object)'],
        'slider_desktop_column' => ['type' => 'string', 'description' => 'Desktop Columns'],
        'steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_padding' => ['type' => 'object', 'description' => 'Slide Padding (Dimensions Object)'],
        'slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'multi_drag' => ['type' => 'string', 'description' => 'Multi Drag', 'enum' => ['yes', 'no']],
        'slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'slider_pause_hover' => ['type' => 'string', 'description' => 'Pause On Hover', 'enum' => ['yes', 'no']],
        'slider_adaptive_height' => ['type' => 'string', 'description' => 'Adaptive Height', 'enum' => ['yes', 'no']],
        'slide_fade_inout' => ['type' => 'string', 'description' => 'Slide Animation', 'enum' => ['fadeinout', 'none', 'slider_direction']],
        'slider_animation' => ['type' => 'string', 'description' => 'Animation Type', 'enum' => ['ease', 'linear']],
        'slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['slider_dots', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['slider_arrows', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'slider_arrows', 'slider_arrows_style', 'top-right']],
        'arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'slider_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'slider_center_effects' => ['type' => 'string', 'description' => 'Center Slide Effects', 'enum' => ['slider_center_mode']],
        'scale_center_slide' => ['type' => 'object', 'description' => 'Center Slide Scale (Slider/Size Object)'],
        'scale_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Scale (Slider/Size Object)'],
        'opacity_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Opacity (Slider/Size Object)'],
        'slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3']],
        'slide_row_top_space' => ['type' => 'object', 'description' => 'Row Top Space (Slider/Size Object)'],
        'slider_tablet_column' => ['type' => 'string', 'description' => 'Tablet Columns'],
        'tablet_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_tablet' => ['type' => 'string', 'description' => 'Responsive Tablet', 'enum' => ['yes', 'no']],
        'tablet_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'tablet_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'tablet_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'tablet_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'tablet_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['slider_responsive_tablet', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7', 'tablet_slider_dots']],
        'tablet_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'tablet_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'tablet_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'tablet_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'tablet_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'tablet_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['slider_responsive_tablet', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'tablet_slider_arrows']],
        'tablet_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'slider_responsive_tablet', 'tablet_slider_arrows', 'tablet_slider_arrows_style', 'top-right']],
        'tablet_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'tablet_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'tablet_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'tablet_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'tablet_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'tablet_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'tablet_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3', 'slider_responsive_tablet']],
        'tablet_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'tablet_center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'slider_mobile_column' => ['type' => 'string', 'description' => 'Mobile Columns'],
        'mobile_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_mobile' => ['type' => 'string', 'description' => 'Responsive Mobile', 'enum' => ['yes', 'no']],
        'mobile_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'mobile_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'mobile_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'mobile_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'mobile_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['mobile_slider_dots', 'slider_responsive_mobile', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'mobile_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'mobile_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'mobile_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'mobile_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'mobile_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'mobile_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['mobile_slider_arrows', 'slider_responsive_mobile', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'mobile_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'mobile_slider_arrows', 'mobile_slider_arrows_style', 'slider_responsive_mobile', 'top-right']],
        'mobile_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'mobile_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'mobile_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'mobile_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'mobile_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'mobile_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'mobile_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3', 'slider_responsive_mobile']],
        'mobile_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'mobile_center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'pnf_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'pnf_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'pnf_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'messy_column' => ['type' => 'string', 'description' => 'Messy Columns', 'enum' => ['yes', 'no']],
        'desktop_column_1' => ['type' => 'object', 'description' => 'Column 1 (Slider/Size Object)'],
        'desktop_column_2' => ['type' => 'object', 'description' => 'Column 2 (Slider/Size Object)'],
        'desktop_column_3' => ['type' => 'object', 'description' => 'Column 3 (Slider/Size Object)'],
        'desktop_column_4' => ['type' => 'object', 'description' => 'Column 4 (Slider/Size Object)'],
        'desktop_column_5' => ['type' => 'object', 'description' => 'Column 5 (Slider/Size Object)'],
        'desktop_column_6' => ['type' => 'object', 'description' => 'Column 6 (Slider/Size Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_dynamic_listing_ability',
    'permission_callback' => 'tpaep_mcp_theplus_dynamic_listing_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_dynamic_listing_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_dynamic_listing_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-dynamic-listing';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Dynamic Listing widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['blogs_post_listing'])) { $settings['blogs_post_listing'] = sanitize_text_field($input['blogs_post_listing']); }
    if (isset($input['uniquename'])) { $settings['uniquename'] = sanitize_text_field($input['uniquename']); }
    if (isset($input['extra_query_id'])) { $settings['extra_query_id'] = sanitize_text_field($input['extra_query_id']); }
    if (isset($input['query'])) { $settings['query'] = sanitize_text_field($input['query']); }
    if (isset($input['related_post_by'])) { $settings['related_post_by'] = sanitize_text_field($input['related_post_by']); }
    if (isset($input['style'])) { $settings['style'] = sanitize_text_field($input['style']); }
    if (isset($input['skin_template'])) { $settings['skin_template'] = sanitize_text_field($input['skin_template']); }
    if (isset($input['acf_repeater_field'])) { $settings['acf_repeater_field'] = sanitize_text_field($input['acf_repeater_field']); }
    if (isset($input['acf_repeater_field_list'])) { $settings['acf_repeater_field_list'] = sanitize_text_field($input['acf_repeater_field_list']); }
    if (isset($input['acf_filed_name'])) { $settings['acf_filed_name'] = sanitize_text_field($input['acf_filed_name']); }
    if (isset($input['acf_repeater_field_conditions'])) { $settings['acf_repeater_field_conditions'] = sanitize_text_field($input['acf_repeater_field_conditions']); }
    if (isset($input['acf_rf_name'])) { $settings['acf_rf_name'] = sanitize_text_field($input['acf_rf_name']); }
    if (isset($input['multiple_skin_enable'])) { $settings['multiple_skin_enable'] = sanitize_text_field($input['multiple_skin_enable']); }
    if (isset($input['skin_template2'])) { $settings['skin_template2'] = sanitize_text_field($input['skin_template2']); }
    if (isset($input['skin_template3'])) { $settings['skin_template3'] = sanitize_text_field($input['skin_template3']); }
    if (isset($input['skin_template4'])) { $settings['skin_template4'] = sanitize_text_field($input['skin_template4']); }
    if (isset($input['skin_template5'])) { $settings['skin_template5'] = sanitize_text_field($input['skin_template5']); }
    if (isset($input['layout'])) { $settings['layout'] = sanitize_text_field($input['layout']); }
    if (isset($input['template_order'])) { $settings['template_order'] = sanitize_text_field($input['template_order']); }
    if (isset($input['content_alignment'])) { $settings['content_alignment'] = sanitize_text_field($input['content_alignment']); }
    if (isset($input['content_alignment_3'])) { $settings['content_alignment_3'] = sanitize_text_field($input['content_alignment_3']); }
    if (isset($input['style_layout'])) { $settings['style_layout'] = sanitize_text_field($input['style_layout']); }
    if (isset($input['column_min_height'])) { $settings['column_min_height'] = $input['column_min_height']; }
    if (isset($input['search_list_customQ'])) { $settings['search_list_customQ'] = sanitize_text_field($input['search_list_customQ']); }
    if (isset($input['extra_query_id_search'])) { $settings['extra_query_id_search'] = sanitize_text_field($input['extra_query_id_search']); }
    if (isset($input['post_category'])) { $settings['post_category'] = sanitize_text_field($input['post_category']); }
    if (isset($input['post_tags'])) { $settings['post_tags'] = sanitize_text_field($input['post_tags']); }
    if (isset($input['post_taxonomies'])) { $settings['post_taxonomies'] = sanitize_text_field($input['post_taxonomies']); }
    if (isset($input['include_slug'])) { $settings['include_slug'] = sanitize_text_field($input['include_slug']); }
    if (isset($input['include_posts'])) { $settings['include_posts'] = sanitize_text_field($input['include_posts']); }
    if (isset($input['exclude_posts'])) { $settings['exclude_posts'] = sanitize_text_field($input['exclude_posts']); }
    if (isset($input['display_posts'])) { $settings['display_posts'] = sanitize_text_field($input['display_posts']); }
    if (isset($input['post_offset'])) { $settings['post_offset'] = sanitize_text_field($input['post_offset']); }
    if (isset($input['post_order_by'])) { $settings['post_order_by'] = sanitize_text_field($input['post_order_by']); }
    if (isset($input['post_order'])) { $settings['post_order'] = sanitize_text_field($input['post_order']); }
    if (isset($input['desktop_column'])) { $settings['desktop_column'] = sanitize_text_field($input['desktop_column']); }
    if (isset($input['tablet_column'])) { $settings['tablet_column'] = sanitize_text_field($input['tablet_column']); }
    if (isset($input['mobile_column'])) { $settings['mobile_column'] = sanitize_text_field($input['mobile_column']); }
    if (isset($input['metro_column'])) { $settings['metro_column'] = sanitize_text_field($input['metro_column']); }
    if (isset($input['metro_style_3'])) { $settings['metro_style_3'] = sanitize_text_field($input['metro_style_3']); }
    if (isset($input['metro_custom_col_3'])) { $settings['metro_custom_col_3'] = sanitize_text_field($input['metro_custom_col_3']); }
    if (isset($input['metro_style_4'])) { $settings['metro_style_4'] = sanitize_text_field($input['metro_style_4']); }
    if (isset($input['metro_custom_col_4'])) { $settings['metro_custom_col_4'] = sanitize_text_field($input['metro_custom_col_4']); }
    if (isset($input['metro_style_5'])) { $settings['metro_style_5'] = sanitize_text_field($input['metro_style_5']); }
    if (isset($input['metro_custom_col_5'])) { $settings['metro_custom_col_5'] = sanitize_text_field($input['metro_custom_col_5']); }
    if (isset($input['metro_style_6'])) { $settings['metro_style_6'] = sanitize_text_field($input['metro_style_6']); }
    if (isset($input['metro_custom_col_6'])) { $settings['metro_custom_col_6'] = sanitize_text_field($input['metro_custom_col_6']); }
    if (isset($input['responsive_tablet_metro'])) { $settings['responsive_tablet_metro'] = sanitize_text_field($input['responsive_tablet_metro']); }
    if (isset($input['tablet_metro_column'])) { $settings['tablet_metro_column'] = sanitize_text_field($input['tablet_metro_column']); }
    if (isset($input['tablet_metro_style_3'])) { $settings['tablet_metro_style_3'] = sanitize_text_field($input['tablet_metro_style_3']); }
    if (isset($input['metro_custom_col_tab'])) { $settings['metro_custom_col_tab'] = sanitize_text_field($input['metro_custom_col_tab']); }
    if (isset($input['columns_gap'])) { $settings['columns_gap'] = $input['columns_gap']; }
    if (isset($input['filter_category'])) { $settings['filter_category'] = sanitize_text_field($input['filter_category']); }
    if (isset($input['filter_category_image'])) { $settings['filter_category_image'] = sanitize_text_field($input['filter_category_image']); }
    if (isset($input['child_filter_category'])) { $settings['child_filter_category'] = sanitize_text_field($input['child_filter_category']); }
    if (isset($input['filter_category_image_child'])) { $settings['filter_category_image_child'] = sanitize_text_field($input['filter_category_image_child']); }
    if (isset($input['filter_by'])) { $settings['filter_by'] = sanitize_text_field($input['filter_by']); }
    if (isset($input['filter_type'])) { $settings['filter_type'] = sanitize_text_field($input['filter_type']); }
    if (isset($input['filter_search_type'])) { $settings['filter_search_type'] = sanitize_text_field($input['filter_search_type']); }
    if (isset($input['all_filter_category_switch'])) { $settings['all_filter_category_switch'] = sanitize_text_field($input['all_filter_category_switch']); }
    if (isset($input['all_filter_category'])) { $settings['all_filter_category'] = sanitize_text_field($input['all_filter_category']); }
    if (isset($input['all_filter_category_filter'])) { $settings['all_filter_category_filter'] = sanitize_text_field($input['all_filter_category_filter']); }
    if (isset($input['filter_style'])) { $settings['filter_style'] = sanitize_text_field($input['filter_style']); }
    if (isset($input['filter_hover_style'])) { $settings['filter_hover_style'] = sanitize_text_field($input['filter_hover_style']); }
    if (isset($input['filter_category_align'])) { $settings['filter_category_align'] = sanitize_text_field($input['filter_category_align']); }
    if (isset($input['post_extra_option'])) { $settings['post_extra_option'] = sanitize_text_field($input['post_extra_option']); }
    if (isset($input['paginationType'])) { $settings['paginationType'] = sanitize_text_field($input['paginationType']); }
    if (isset($input['pagination_next'])) { $settings['pagination_next'] = sanitize_text_field($input['pagination_next']); }
    if (isset($input['pagination_prev'])) { $settings['pagination_prev'] = sanitize_text_field($input['pagination_prev']); }
    if (isset($input['pagination_align'])) { $settings['pagination_align'] = $input['pagination_align']; }
    if (isset($input['pagination_color'])) { $settings['pagination_color'] = sanitize_text_field($input['pagination_color']); }
    if (isset($input['pagination_hover_color'])) { $settings['pagination_hover_color'] = sanitize_text_field($input['pagination_hover_color']); }
    if (isset($input['cqid_pagination'])) { $settings['cqid_pagination'] = sanitize_text_field($input['cqid_pagination']); }
    if (isset($input['cqid_pagination_color'])) { $settings['cqid_pagination_color'] = sanitize_text_field($input['cqid_pagination_color']); }
    if (isset($input['cqid_pagination_hover_color'])) { $settings['cqid_pagination_hover_color'] = sanitize_text_field($input['cqid_pagination_hover_color']); }
    if (isset($input['load_more_btn_text'])) { $settings['load_more_btn_text'] = sanitize_text_field($input['load_more_btn_text']); }
    if (isset($input['tp_loading_text'])) { $settings['tp_loading_text'] = sanitize_text_field($input['tp_loading_text']); }
    if (isset($input['loaded_posts_text'])) { $settings['loaded_posts_text'] = sanitize_text_field($input['loaded_posts_text']); }
    if (isset($input['load_more_post'])) { $settings['load_more_post'] = sanitize_text_field($input['load_more_post']); }
    if (isset($input['load_more_border'])) { $settings['load_more_border'] = sanitize_text_field($input['load_more_border']); }
    if (isset($input['load_more_border_style'])) { $settings['load_more_border_style'] = sanitize_text_field($input['load_more_border_style']); }
    if (isset($input['load_more_border_width'])) { $settings['load_more_border_width'] = $input['load_more_border_width']; }
    if (isset($input['load_more_border_color'])) { $settings['load_more_border_color'] = sanitize_text_field($input['load_more_border_color']); }
    if (isset($input['load_more_border_radius'])) { $settings['load_more_border_radius'] = $input['load_more_border_radius']; }
    if (isset($input['load_more_border_hover_color'])) { $settings['load_more_border_hover_color'] = sanitize_text_field($input['load_more_border_hover_color']); }
    if (isset($input['load_more_border_hover_radius'])) { $settings['load_more_border_hover_radius'] = $input['load_more_border_hover_radius']; }
    if (isset($input['loaded_posts_color'])) { $settings['loaded_posts_color'] = sanitize_text_field($input['loaded_posts_color']); }
    if (isset($input['load_more_color'])) { $settings['load_more_color'] = sanitize_text_field($input['load_more_color']); }
    if (isset($input['loading_spin_color'])) { $settings['loading_spin_color'] = sanitize_text_field($input['loading_spin_color']); }
    if (isset($input['loading_spin_size'])) { $settings['loading_spin_size'] = $input['loading_spin_size']; }
    if (isset($input['loading_spin_border_size'])) { $settings['loading_spin_border_size'] = $input['loading_spin_border_size']; }
    if (isset($input['load_more_color_hover'])) { $settings['load_more_color_hover'] = sanitize_text_field($input['load_more_color_hover']); }
    if (isset($input['post_title_tag'])) { $settings['post_title_tag'] = sanitize_text_field($input['post_title_tag']); }
    if (isset($input['display_title_limit'])) { $settings['display_title_limit'] = sanitize_text_field($input['display_title_limit']); }
    if (isset($input['display_title_by'])) { $settings['display_title_by'] = sanitize_text_field($input['display_title_by']); }
    if (isset($input['display_title_input'])) { $settings['display_title_input'] = sanitize_text_field($input['display_title_input']); }
    if (isset($input['display_title_3_dots'])) { $settings['display_title_3_dots'] = sanitize_text_field($input['display_title_3_dots']); }
    if (isset($input['featured_image_type'])) { $settings['featured_image_type'] = sanitize_text_field($input['featured_image_type']); }
    if (isset($input['feature_image'])) { $settings['feature_image'] = sanitize_text_field($input['feature_image']); }
    if (isset($input['title_desc_word_break'])) { $settings['title_desc_word_break'] = sanitize_text_field($input['title_desc_word_break']); }
    if (isset($input['display_post_category'])) { $settings['display_post_category'] = sanitize_text_field($input['display_post_category']); }
    if (isset($input['post_category_style'])) { $settings['post_category_style'] = sanitize_text_field($input['post_category_style']); }
    if (isset($input['display_post_category_all'])) { $settings['display_post_category_all'] = sanitize_text_field($input['display_post_category_all']); }
    if (isset($input['display_excerpt'])) { $settings['display_excerpt'] = sanitize_text_field($input['display_excerpt']); }
    if (isset($input['post_excerpt_count'])) { $settings['post_excerpt_count'] = sanitize_text_field($input['post_excerpt_count']); }
    if (isset($input['display_thumbnail'])) { $settings['display_thumbnail'] = sanitize_text_field($input['display_thumbnail']); }
    if (isset($input['display_post_meta'])) { $settings['display_post_meta'] = sanitize_text_field($input['display_post_meta']); }
    if (isset($input['post_meta_tag_style'])) { $settings['post_meta_tag_style'] = sanitize_text_field($input['post_meta_tag_style']); }
    if (isset($input['author_prefix'])) { $settings['author_prefix'] = sanitize_text_field($input['author_prefix']); }
    if (isset($input['display_post_meta_date'])) { $settings['display_post_meta_date'] = sanitize_text_field($input['display_post_meta_date']); }
    if (isset($input['date_type'])) { $settings['date_type'] = sanitize_text_field($input['date_type']); }
    if (isset($input['display_post_meta_author'])) { $settings['display_post_meta_author'] = sanitize_text_field($input['display_post_meta_author']); }
    if (isset($input['display_post_meta_author_pic'])) { $settings['display_post_meta_author_pic'] = sanitize_text_field($input['display_post_meta_author_pic']); }
    if (isset($input['display_button'])) { $settings['display_button'] = sanitize_text_field($input['display_button']); }
    if (isset($input['button_style'])) { $settings['button_style'] = sanitize_text_field($input['button_style']); }
    if (isset($input['button_text'])) { $settings['button_text'] = sanitize_text_field($input['button_text']); }
    if (isset($input['button_icon_style'])) { $settings['button_icon_style'] = sanitize_text_field($input['button_icon_style']); }
    if (isset($input['button_icon'])) { $settings['button_icon'] = sanitize_text_field($input['button_icon']); }
    if (isset($input['button_icons_mind'])) { $settings['button_icons_mind'] = sanitize_text_field($input['button_icons_mind']); }
    if (isset($input['before_after'])) { $settings['before_after'] = sanitize_text_field($input['before_after']); }
    if (isset($input['icon_spacing'])) { $settings['icon_spacing'] = $input['icon_spacing']; }
    if (isset($input['display_theplus_quickview'])) { $settings['display_theplus_quickview'] = sanitize_text_field($input['display_theplus_quickview']); }
    if (isset($input['tpqc'])) { $settings['tpqc'] = sanitize_text_field($input['tpqc']); }
    if (isset($input['custom_template_select'])) { $settings['custom_template_select'] = sanitize_text_field($input['custom_template_select']); }
    if (isset($input['tp_list_preloader'])) { $settings['tp_list_preloader'] = sanitize_text_field($input['tp_list_preloader']); }
    if (isset($input['tp_list_preloader_hw'])) { $settings['tp_list_preloader_hw'] = $input['tp_list_preloader_hw']; }
    if (isset($input['tp_list_preloader_size'])) { $settings['tp_list_preloader_size'] = $input['tp_list_preloader_size']; }
    if (isset($input['tp_list_preloader_color'])) { $settings['tp_list_preloader_color'] = sanitize_text_field($input['tp_list_preloader_color']); }
    if (isset($input['loading_options'])) { $settings['loading_options'] = sanitize_text_field($input['loading_options']); }
    if (isset($input['filter_url'])) { $settings['filter_url'] = sanitize_text_field($input['filter_url']); }
    if (isset($input['empty_posts_message'])) { $settings['empty_posts_message'] = sanitize_text_field($input['empty_posts_message']); }
    if (isset($input['tpaep_theme_builder'])) { $settings['tpaep_theme_builder'] = sanitize_text_field($input['tpaep_theme_builder']); }
    if (isset($input['post_meta_color'])) { $settings['post_meta_color'] = sanitize_text_field($input['post_meta_color']); }
    if (isset($input['post_meta_color_hover'])) { $settings['post_meta_color_hover'] = sanitize_text_field($input['post_meta_color_hover']); }
    if (isset($input['post_meta_border_color'])) { $settings['post_meta_border_color'] = sanitize_text_field($input['post_meta_border_color']); }
    if (isset($input['category_inner_padding'])) { $settings['category_inner_padding'] = $input['category_inner_padding']; }
    if (isset($input['category_color'])) { $settings['category_color'] = sanitize_text_field($input['category_color']); }
    if (isset($input['category_hover_color'])) { $settings['category_hover_color'] = sanitize_text_field($input['category_hover_color']); }
    if (isset($input['category_2_border_hover_color'])) { $settings['category_2_border_hover_color'] = sanitize_text_field($input['category_2_border_hover_color']); }
    if (isset($input['category_border'])) { $settings['category_border'] = sanitize_text_field($input['category_border']); }
    if (isset($input['category_border_style'])) { $settings['category_border_style'] = sanitize_text_field($input['category_border_style']); }
    if (isset($input['box_category_border_width'])) { $settings['box_category_border_width'] = $input['box_category_border_width']; }
    if (isset($input['category_border_color'])) { $settings['category_border_color'] = sanitize_text_field($input['category_border_color']); }
    if (isset($input['category_border_radius'])) { $settings['category_border_radius'] = $input['category_border_radius']; }
    if (isset($input['category_border_hover_color'])) { $settings['category_border_hover_color'] = sanitize_text_field($input['category_border_hover_color']); }
    if (isset($input['category_border_hover_radius'])) { $settings['category_border_hover_radius'] = $input['category_border_hover_radius']; }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['title_hover_color'])) { $settings['title_hover_color'] = sanitize_text_field($input['title_hover_color']); }
    if (isset($input['excerpt_color'])) { $settings['excerpt_color'] = sanitize_text_field($input['excerpt_color']); }
    if (isset($input['excerpt_hover_color'])) { $settings['excerpt_hover_color'] = sanitize_text_field($input['excerpt_hover_color']); }
    if (isset($input['content_between_space'])) { $settings['content_between_space'] = $input['content_between_space']; }
    if (isset($input['hover_image_style'])) { $settings['hover_image_style'] = sanitize_text_field($input['hover_image_style']); }
    if (isset($input['featured_image_radius'])) { $settings['featured_image_radius'] = $input['featured_image_radius']; }
    if (isset($input['full_image_size'])) { $settings['full_image_size'] = sanitize_text_field($input['full_image_size']); }
    if (isset($input['full_image_size_min_height'])) { $settings['full_image_size_min_height'] = $input['full_image_size_min_height']; }
    if (isset($input['qv_align'])) { $settings['qv_align'] = $input['qv_align']; }
    if (isset($input['qv_color'])) { $settings['qv_color'] = sanitize_text_field($input['qv_color']); }
    if (isset($input['qv_br'])) { $settings['qv_br'] = $input['qv_br']; }
    if (isset($input['qv_hover_color'])) { $settings['qv_hover_color'] = sanitize_text_field($input['qv_hover_color']); }
    if (isset($input['qv_br_h'])) { $settings['qv_br_h'] = $input['qv_br_h']; }
    if (isset($input['button_padding'])) { $settings['button_padding'] = $input['button_padding']; }
    if (isset($input['btn_text_color'])) { $settings['btn_text_color'] = sanitize_text_field($input['btn_text_color']); }
    if (isset($input['button_border_style'])) { $settings['button_border_style'] = sanitize_text_field($input['button_border_style']); }
    if (isset($input['button_border_width'])) { $settings['button_border_width'] = $input['button_border_width']; }
    if (isset($input['button_border_color'])) { $settings['button_border_color'] = sanitize_text_field($input['button_border_color']); }
    if (isset($input['button_radius'])) { $settings['button_radius'] = $input['button_radius']; }
    if (isset($input['btn_text_hover_color'])) { $settings['btn_text_hover_color'] = sanitize_text_field($input['btn_text_hover_color']); }
    if (isset($input['button_border_hover_color'])) { $settings['button_border_hover_color'] = sanitize_text_field($input['button_border_hover_color']); }
    if (isset($input['button_hover_radius'])) { $settings['button_hover_radius'] = $input['button_hover_radius']; }
    if (isset($input['filter_category_padding'])) { $settings['filter_category_padding'] = $input['filter_category_padding']; }
    if (isset($input['filter_category_marign'])) { $settings['filter_category_marign'] = $input['filter_category_marign']; }
    if (isset($input['filter_category_4_icon_size'])) { $settings['filter_category_4_icon_size'] = $input['filter_category_4_icon_size']; }
    if (isset($input['filters_text_color'])) { $settings['filters_text_color'] = sanitize_text_field($input['filters_text_color']); }
    if (isset($input['filter_category_color'])) { $settings['filter_category_color'] = sanitize_text_field($input['filter_category_color']); }
    if (isset($input['filter_category_4_border_color'])) { $settings['filter_category_4_border_color'] = sanitize_text_field($input['filter_category_4_border_color']); }
    if (isset($input['filter_category_radius'])) { $settings['filter_category_radius'] = $input['filter_category_radius']; }
    if (isset($input['filter_category_hover_color'])) { $settings['filter_category_hover_color'] = sanitize_text_field($input['filter_category_hover_color']); }
    if (isset($input['filter_category_hover_radius'])) { $settings['filter_category_hover_radius'] = $input['filter_category_hover_radius']; }
    if (isset($input['filter_border_hover_color'])) { $settings['filter_border_hover_color'] = sanitize_text_field($input['filter_border_hover_color']); }
    if (isset($input['category_count_color'])) { $settings['category_count_color'] = sanitize_text_field($input['category_count_color']); }
    if (isset($input['category_count_bg_color'])) { $settings['category_count_bg_color'] = sanitize_text_field($input['category_count_bg_color']); }
    if (isset($input['fc_max_width'])) { $settings['fc_max_width'] = $input['fc_max_width']; }
    if (isset($input['fc_margin_bottom'])) { $settings['fc_margin_bottom'] = $input['fc_margin_bottom']; }
    if (isset($input['fc__br'])) { $settings['fc__br'] = $input['fc__br']; }
    if (isset($input['fcc__margin'])) { $settings['fcc__margin'] = $input['fcc__margin']; }
    if (isset($input['fcc__padding'])) { $settings['fcc__padding'] = $input['fcc__padding']; }
    if (isset($input['fcc_fi_max_width'])) { $settings['fcc_fi_max_width'] = $input['fcc_fi_max_width']; }
    if (isset($input['fcc_fi_margin_bottom'])) { $settings['fcc_fi_margin_bottom'] = $input['fcc_fi_margin_bottom']; }
    if (isset($input['fcc_fi__br'])) { $settings['fcc_fi__br'] = $input['fcc_fi__br']; }
    if (isset($input['fcc__cat_n_color'])) { $settings['fcc__cat_n_color'] = sanitize_text_field($input['fcc__cat_n_color']); }
    if (isset($input['fcc__cat_n__br'])) { $settings['fcc__cat_n__br'] = $input['fcc__cat_n__br']; }
    if (isset($input['fcc__cat_ha_color'])) { $settings['fcc__cat_ha_color'] = sanitize_text_field($input['fcc__cat_ha_color']); }
    if (isset($input['fcc__cat_ha__br'])) { $settings['fcc__cat_ha__br'] = $input['fcc__cat_ha__br']; }
    if (isset($input['content_inner_padding'])) { $settings['content_inner_padding'] = $input['content_inner_padding']; }
    if (isset($input['box_border'])) { $settings['box_border'] = sanitize_text_field($input['box_border']); }
    if (isset($input['border_style'])) { $settings['border_style'] = sanitize_text_field($input['border_style']); }
    if (isset($input['box_border_width'])) { $settings['box_border_width'] = $input['box_border_width']; }
    if (isset($input['box_border_color'])) { $settings['box_border_color'] = sanitize_text_field($input['box_border_color']); }
    if (isset($input['border_radius'])) { $settings['border_radius'] = $input['border_radius']; }
    if (isset($input['box_border_hover_color'])) { $settings['box_border_hover_color'] = sanitize_text_field($input['box_border_hover_color']); }
    if (isset($input['border_hover_radius'])) { $settings['border_hover_radius'] = $input['border_hover_radius']; }
    if (isset($input['carousel_unique_id'])) { $settings['carousel_unique_id'] = sanitize_text_field($input['carousel_unique_id']); }
    if (isset($input['slider_direction'])) { $settings['slider_direction'] = sanitize_text_field($input['slider_direction']); }
    if (isset($input['carousel_direction'])) { $settings['carousel_direction'] = sanitize_text_field($input['carousel_direction']); }
    if (isset($input['slide_speed'])) { $settings['slide_speed'] = $input['slide_speed']; }
    if (isset($input['slider_desktop_column'])) { $settings['slider_desktop_column'] = sanitize_text_field($input['slider_desktop_column']); }
    if (isset($input['steps_slide'])) { $settings['steps_slide'] = sanitize_text_field($input['steps_slide']); }
    if (isset($input['slider_padding'])) { $settings['slider_padding'] = $input['slider_padding']; }
    if (isset($input['slider_draggable'])) { $settings['slider_draggable'] = sanitize_text_field($input['slider_draggable']); }
    if (isset($input['multi_drag'])) { $settings['multi_drag'] = sanitize_text_field($input['multi_drag']); }
    if (isset($input['slider_infinite'])) { $settings['slider_infinite'] = sanitize_text_field($input['slider_infinite']); }
    if (isset($input['slider_pause_hover'])) { $settings['slider_pause_hover'] = sanitize_text_field($input['slider_pause_hover']); }
    if (isset($input['slider_adaptive_height'])) { $settings['slider_adaptive_height'] = sanitize_text_field($input['slider_adaptive_height']); }
    if (isset($input['slide_fade_inout'])) { $settings['slide_fade_inout'] = sanitize_text_field($input['slide_fade_inout']); }
    if (isset($input['slider_animation'])) { $settings['slider_animation'] = sanitize_text_field($input['slider_animation']); }
    if (isset($input['slider_autoplay'])) { $settings['slider_autoplay'] = sanitize_text_field($input['slider_autoplay']); }
    if (isset($input['autoplay_speed'])) { $settings['autoplay_speed'] = $input['autoplay_speed']; }
    if (isset($input['slider_dots'])) { $settings['slider_dots'] = sanitize_text_field($input['slider_dots']); }
    if (isset($input['slider_dots_style'])) { $settings['slider_dots_style'] = sanitize_text_field($input['slider_dots_style']); }
    if (isset($input['dots_border_color'])) { $settings['dots_border_color'] = sanitize_text_field($input['dots_border_color']); }
    if (isset($input['dots_bg_color'])) { $settings['dots_bg_color'] = sanitize_text_field($input['dots_bg_color']); }
    if (isset($input['dots_active_border_color'])) { $settings['dots_active_border_color'] = sanitize_text_field($input['dots_active_border_color']); }
    if (isset($input['dots_active_bg_color'])) { $settings['dots_active_bg_color'] = sanitize_text_field($input['dots_active_bg_color']); }
    if (isset($input['dots_top_padding'])) { $settings['dots_top_padding'] = $input['dots_top_padding']; }
    if (isset($input['hover_show_dots'])) { $settings['hover_show_dots'] = sanitize_text_field($input['hover_show_dots']); }
    if (isset($input['slider_arrows'])) { $settings['slider_arrows'] = sanitize_text_field($input['slider_arrows']); }
    if (isset($input['slider_arrows_style'])) { $settings['slider_arrows_style'] = sanitize_text_field($input['slider_arrows_style']); }
    if (isset($input['arrows_position'])) { $settings['arrows_position'] = sanitize_text_field($input['arrows_position']); }
    if (isset($input['arrow_bg_color'])) { $settings['arrow_bg_color'] = sanitize_text_field($input['arrow_bg_color']); }
    if (isset($input['arrow_icon_color'])) { $settings['arrow_icon_color'] = sanitize_text_field($input['arrow_icon_color']); }
    if (isset($input['arrow_hover_bg_color'])) { $settings['arrow_hover_bg_color'] = sanitize_text_field($input['arrow_hover_bg_color']); }
    if (isset($input['arrow_hover_icon_color'])) { $settings['arrow_hover_icon_color'] = sanitize_text_field($input['arrow_hover_icon_color']); }
    if (isset($input['outer_section_arrow'])) { $settings['outer_section_arrow'] = sanitize_text_field($input['outer_section_arrow']); }
    if (isset($input['hover_show_arrow'])) { $settings['hover_show_arrow'] = sanitize_text_field($input['hover_show_arrow']); }
    if (isset($input['slider_center_mode'])) { $settings['slider_center_mode'] = sanitize_text_field($input['slider_center_mode']); }
    if (isset($input['center_padding'])) { $settings['center_padding'] = $input['center_padding']; }
    if (isset($input['slider_center_effects'])) { $settings['slider_center_effects'] = sanitize_text_field($input['slider_center_effects']); }
    if (isset($input['scale_center_slide'])) { $settings['scale_center_slide'] = $input['scale_center_slide']; }
    if (isset($input['scale_normal_slide'])) { $settings['scale_normal_slide'] = $input['scale_normal_slide']; }
    if (isset($input['opacity_normal_slide'])) { $settings['opacity_normal_slide'] = $input['opacity_normal_slide']; }
    if (isset($input['slider_rows'])) { $settings['slider_rows'] = sanitize_text_field($input['slider_rows']); }
    if (isset($input['slide_row_top_space'])) { $settings['slide_row_top_space'] = $input['slide_row_top_space']; }
    if (isset($input['slider_tablet_column'])) { $settings['slider_tablet_column'] = sanitize_text_field($input['slider_tablet_column']); }
    if (isset($input['tablet_steps_slide'])) { $settings['tablet_steps_slide'] = sanitize_text_field($input['tablet_steps_slide']); }
    if (isset($input['slider_responsive_tablet'])) { $settings['slider_responsive_tablet'] = sanitize_text_field($input['slider_responsive_tablet']); }
    if (isset($input['tablet_slider_draggable'])) { $settings['tablet_slider_draggable'] = sanitize_text_field($input['tablet_slider_draggable']); }
    if (isset($input['tablet_slider_infinite'])) { $settings['tablet_slider_infinite'] = sanitize_text_field($input['tablet_slider_infinite']); }
    if (isset($input['tablet_slider_autoplay'])) { $settings['tablet_slider_autoplay'] = sanitize_text_field($input['tablet_slider_autoplay']); }
    if (isset($input['tablet_autoplay_speed'])) { $settings['tablet_autoplay_speed'] = $input['tablet_autoplay_speed']; }
    if (isset($input['tablet_slider_dots'])) { $settings['tablet_slider_dots'] = sanitize_text_field($input['tablet_slider_dots']); }
    if (isset($input['tablet_slider_dots_style'])) { $settings['tablet_slider_dots_style'] = sanitize_text_field($input['tablet_slider_dots_style']); }
    if (isset($input['tablet_dots_border_color'])) { $settings['tablet_dots_border_color'] = sanitize_text_field($input['tablet_dots_border_color']); }
    if (isset($input['tablet_dots_bg_color'])) { $settings['tablet_dots_bg_color'] = sanitize_text_field($input['tablet_dots_bg_color']); }
    if (isset($input['tablet_dots_active_border_color'])) { $settings['tablet_dots_active_border_color'] = sanitize_text_field($input['tablet_dots_active_border_color']); }
    if (isset($input['tablet_dots_active_bg_color'])) { $settings['tablet_dots_active_bg_color'] = sanitize_text_field($input['tablet_dots_active_bg_color']); }
    if (isset($input['tablet_dots_top_padding'])) { $settings['tablet_dots_top_padding'] = $input['tablet_dots_top_padding']; }
    if (isset($input['tablet_hover_show_dots'])) { $settings['tablet_hover_show_dots'] = sanitize_text_field($input['tablet_hover_show_dots']); }
    if (isset($input['tablet_slider_arrows'])) { $settings['tablet_slider_arrows'] = sanitize_text_field($input['tablet_slider_arrows']); }
    if (isset($input['tablet_slider_arrows_style'])) { $settings['tablet_slider_arrows_style'] = sanitize_text_field($input['tablet_slider_arrows_style']); }
    if (isset($input['tablet_arrows_position'])) { $settings['tablet_arrows_position'] = sanitize_text_field($input['tablet_arrows_position']); }
    if (isset($input['tablet_arrow_bg_color'])) { $settings['tablet_arrow_bg_color'] = sanitize_text_field($input['tablet_arrow_bg_color']); }
    if (isset($input['tablet_arrow_icon_color'])) { $settings['tablet_arrow_icon_color'] = sanitize_text_field($input['tablet_arrow_icon_color']); }
    if (isset($input['tablet_arrow_hover_bg_color'])) { $settings['tablet_arrow_hover_bg_color'] = sanitize_text_field($input['tablet_arrow_hover_bg_color']); }
    if (isset($input['tablet_arrow_hover_icon_color'])) { $settings['tablet_arrow_hover_icon_color'] = sanitize_text_field($input['tablet_arrow_hover_icon_color']); }
    if (isset($input['tablet_outer_section_arrow'])) { $settings['tablet_outer_section_arrow'] = sanitize_text_field($input['tablet_outer_section_arrow']); }
    if (isset($input['tablet_hover_show_arrow'])) { $settings['tablet_hover_show_arrow'] = sanitize_text_field($input['tablet_hover_show_arrow']); }
    if (isset($input['tablet_slider_rows'])) { $settings['tablet_slider_rows'] = sanitize_text_field($input['tablet_slider_rows']); }
    if (isset($input['tablet_center_mode'])) { $settings['tablet_center_mode'] = sanitize_text_field($input['tablet_center_mode']); }
    if (isset($input['tablet_center_padding'])) { $settings['tablet_center_padding'] = $input['tablet_center_padding']; }
    if (isset($input['slider_mobile_column'])) { $settings['slider_mobile_column'] = sanitize_text_field($input['slider_mobile_column']); }
    if (isset($input['mobile_steps_slide'])) { $settings['mobile_steps_slide'] = sanitize_text_field($input['mobile_steps_slide']); }
    if (isset($input['slider_responsive_mobile'])) { $settings['slider_responsive_mobile'] = sanitize_text_field($input['slider_responsive_mobile']); }
    if (isset($input['mobile_slider_draggable'])) { $settings['mobile_slider_draggable'] = sanitize_text_field($input['mobile_slider_draggable']); }
    if (isset($input['mobile_slider_infinite'])) { $settings['mobile_slider_infinite'] = sanitize_text_field($input['mobile_slider_infinite']); }
    if (isset($input['mobile_slider_autoplay'])) { $settings['mobile_slider_autoplay'] = sanitize_text_field($input['mobile_slider_autoplay']); }
    if (isset($input['mobile_autoplay_speed'])) { $settings['mobile_autoplay_speed'] = $input['mobile_autoplay_speed']; }
    if (isset($input['mobile_slider_dots'])) { $settings['mobile_slider_dots'] = sanitize_text_field($input['mobile_slider_dots']); }
    if (isset($input['mobile_slider_dots_style'])) { $settings['mobile_slider_dots_style'] = sanitize_text_field($input['mobile_slider_dots_style']); }
    if (isset($input['mobile_dots_border_color'])) { $settings['mobile_dots_border_color'] = sanitize_text_field($input['mobile_dots_border_color']); }
    if (isset($input['mobile_dots_bg_color'])) { $settings['mobile_dots_bg_color'] = sanitize_text_field($input['mobile_dots_bg_color']); }
    if (isset($input['mobile_dots_active_border_color'])) { $settings['mobile_dots_active_border_color'] = sanitize_text_field($input['mobile_dots_active_border_color']); }
    if (isset($input['mobile_dots_active_bg_color'])) { $settings['mobile_dots_active_bg_color'] = sanitize_text_field($input['mobile_dots_active_bg_color']); }
    if (isset($input['mobile_dots_top_padding'])) { $settings['mobile_dots_top_padding'] = $input['mobile_dots_top_padding']; }
    if (isset($input['mobile_hover_show_dots'])) { $settings['mobile_hover_show_dots'] = sanitize_text_field($input['mobile_hover_show_dots']); }
    if (isset($input['mobile_slider_arrows'])) { $settings['mobile_slider_arrows'] = sanitize_text_field($input['mobile_slider_arrows']); }
    if (isset($input['mobile_slider_arrows_style'])) { $settings['mobile_slider_arrows_style'] = sanitize_text_field($input['mobile_slider_arrows_style']); }
    if (isset($input['mobile_arrows_position'])) { $settings['mobile_arrows_position'] = sanitize_text_field($input['mobile_arrows_position']); }
    if (isset($input['mobile_arrow_bg_color'])) { $settings['mobile_arrow_bg_color'] = sanitize_text_field($input['mobile_arrow_bg_color']); }
    if (isset($input['mobile_arrow_icon_color'])) { $settings['mobile_arrow_icon_color'] = sanitize_text_field($input['mobile_arrow_icon_color']); }
    if (isset($input['mobile_arrow_hover_bg_color'])) { $settings['mobile_arrow_hover_bg_color'] = sanitize_text_field($input['mobile_arrow_hover_bg_color']); }
    if (isset($input['mobile_arrow_hover_icon_color'])) { $settings['mobile_arrow_hover_icon_color'] = sanitize_text_field($input['mobile_arrow_hover_icon_color']); }
    if (isset($input['mobile_outer_section_arrow'])) { $settings['mobile_outer_section_arrow'] = sanitize_text_field($input['mobile_outer_section_arrow']); }
    if (isset($input['mobile_hover_show_arrow'])) { $settings['mobile_hover_show_arrow'] = sanitize_text_field($input['mobile_hover_show_arrow']); }
    if (isset($input['mobile_slider_rows'])) { $settings['mobile_slider_rows'] = sanitize_text_field($input['mobile_slider_rows']); }
    if (isset($input['mobile_center_mode'])) { $settings['mobile_center_mode'] = sanitize_text_field($input['mobile_center_mode']); }
    if (isset($input['mobile_center_padding'])) { $settings['mobile_center_padding'] = $input['mobile_center_padding']; }
    if (isset($input['pnf_padding'])) { $settings['pnf_padding'] = $input['pnf_padding']; }
    if (isset($input['pnf_color'])) { $settings['pnf_color'] = sanitize_text_field($input['pnf_color']); }
    if (isset($input['pnf_br'])) { $settings['pnf_br'] = $input['pnf_br']; }
    if (isset($input['messy_column'])) { $settings['messy_column'] = sanitize_text_field($input['messy_column']); }
    if (isset($input['desktop_column_1'])) { $settings['desktop_column_1'] = $input['desktop_column_1']; }
    if (isset($input['desktop_column_2'])) { $settings['desktop_column_2'] = $input['desktop_column_2']; }
    if (isset($input['desktop_column_3'])) { $settings['desktop_column_3'] = $input['desktop_column_3']; }
    if (isset($input['desktop_column_4'])) { $settings['desktop_column_4'] = $input['desktop_column_4']; }
    if (isset($input['desktop_column_5'])) { $settings['desktop_column_5'] = $input['desktop_column_5']; }
    if (isset($input['desktop_column_6'])) { $settings['desktop_column_6'] = $input['desktop_column_6']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
