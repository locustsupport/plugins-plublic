<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-circle-menu', [
'label' => __('Circle Menu', 'theplus'),
    'description' => __('Adds The Plus "Circle Menu" widget (tp-circle-menu) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'            => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'          => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'           => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'icon_layout_open' => ['type' => 'string', 'description' => 'Icon Layout', 'enum' => ['circle', 'columns', 'straight']],
        'icon_layout_straight_style' => ['type' => 'string', 'description' => 'Menu Style', 'enum' => ['columns', 'icon_layout_open', 'style-1', 'style-2']],
        'icon_direction' => ['type' => 'string', 'description' => 'Icon Direction', 'enum' => ['bottom', 'bottom-half', 'bottom-left', 'bottom-right', 'full', 'icon_layout_open', 'left', 'left-half', 'none', 'right', 'right-half', 'top', 'top-half', 'top-left', 'top-right']],
        'layout_straight_menu_direction' => ['type' => 'string', 'description' => 'Menu Direction', 'enum' => ['bottom', 'icon_layout_open', 'left', 'right', 'top']],
        'tooltip_menu_title' => ['type' => 'string', 'description' => 'Tooltip Title'],
        'loop_image_icon' => ['type' => 'string', 'description' => 'Select Icon', 'enum' => ['icon']],
        'loop_select_image' => ['type' => 'integer', 'description' => 'Use Image As icon'],
        'loop_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['font_awesome', 'font_awesome_5', 'icon_mind', 'loop_image_icon']],
        'loop_icon_fontawesome' => ['type' => 'string', 'description' => 'Icon Library'],
        'loop_icon_fontawesome_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'loop_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['loop_icon_style', 'loop_image_icon']],
        'loop_icon_link_type' => ['type' => 'string', 'description' => 'Select Link Type', 'enum' => ['email', 'nolink', 'phone', 'url']],
        'icons_url' => ['type' => 'object', 'description' => 'Url'],
        'email' => ['type' => 'string', 'description' => 'Email'],
        'phone' => ['type' => 'string', 'description' => 'Phone'],
        'icon_color' => ['type' => 'string', 'description' => 'Color'],
        'icon_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'icon_hover_color' => ['type' => 'string', 'description' => 'Color'],
        'icon_border_hover_color' => ['type' => 'string', 'description' => 'Border Color'],
        'tooltip_default_hover' => ['type' => 'string', 'description' => 'Tooltip Visibility', 'enum' => ['yes', 'no']],
        'tooltip_text_rotate' => ['type' => 'object', 'description' => 'Tooltip Text Rotate'],
        'tooltip_text_top' => ['type' => 'object', 'description' => 'Tooltip Text Top'],
        'tooltip_text_left' => ['type' => 'object', 'description' => 'Tooltip Text Left'],
        'tooltip_text_arrow' => ['type' => 'string', 'description' => 'Arrow Style', 'enum' => ['arrow-bottom', 'arrow-left', 'arrow-none', 'arrow-right', 'arrow-top']],
        'circle_menu_list' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Menu List'],
        'loop_image_main_icon' => ['type' => 'string', 'description' => 'Select Icon', 'enum' => ['icon']],
        'loop_max_main_width' => ['type' => 'object', 'description' => 'Max Width Svg'],
        'loop_select_main_image' => ['type' => 'integer', 'description' => 'Use Image As icon'],
        'loop_icon_main_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['font_awesome', 'font_awesome_5', 'icon_mind', 'loop_image_main_icon']],
        'loop_icon_main_fontawesome' => ['type' => 'string', 'description' => 'Icon Library'],
        'loop_icon_main_fontawesome_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'loop_icons_main_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['loop_icon_main_style', 'loop_image_main_icon']],
        'toggle_open_icon_style' => ['type' => 'string', 'description' => 'Menu Open Icon Style', 'enum' => ['style-1', 'style-2', 'style-3']],
        'main_icon_position' => ['type' => 'string', 'description' => 'Position', 'enum' => ['absolute', 'fixed']],
        'd_left_auto' => ['type' => 'string', 'description' => 'Left (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_xposition' => ['type' => 'object', 'description' => 'Left'],
        'd_right_auto' => ['type' => 'string', 'description' => 'Right (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_rightposition' => ['type' => 'object', 'description' => 'Right'],
        'd_top_auto' => ['type' => 'string', 'description' => 'Top (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_yposition' => ['type' => 'object', 'description' => 'Top'],
        'd_bottom_auto' => ['type' => 'string', 'description' => 'Bottom (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_bottomposition' => ['type' => 'object', 'description' => 'Bottom'],
        't_responsive' => ['type' => 'string', 'description' => 'Responsive Values', 'enum' => ['yes', 'no']],
        't_left_auto' => ['type' => 'string', 'description' => 'Left (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_xposition' => ['type' => 'object', 'description' => 'Left'],
        't_right_auto' => ['type' => 'string', 'description' => 'Right (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_rightposition' => ['type' => 'object', 'description' => 'Right'],
        't_top_auto' => ['type' => 'string', 'description' => 'Top (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_yposition' => ['type' => 'object', 'description' => 'Top'],
        't_bottom_auto' => ['type' => 'string', 'description' => 'Bottom (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_bottomposition' => ['type' => 'object', 'description' => 'Bottom'],
        'm_responsive' => ['type' => 'string', 'description' => 'Responsive Values', 'enum' => ['yes', 'no']],
        'm_left_auto' => ['type' => 'string', 'description' => 'Left (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_xposition' => ['type' => 'object', 'description' => 'Left'],
        'm_right_auto' => ['type' => 'string', 'description' => 'Right (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_rightposition' => ['type' => 'object', 'description' => 'Right'],
        'm_top_auto' => ['type' => 'string', 'description' => 'Top (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_yposition' => ['type' => 'object', 'description' => 'Top'],
        'm_bottom_auto' => ['type' => 'string', 'description' => 'Bottom (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_bottomposition' => ['type' => 'object', 'description' => 'Bottom'],
        'angle_start' => ['type' => 'object', 'description' => 'Angle Start'],
        'angle_end' => ['type' => 'object', 'description' => 'Angle End'],
        'circle_radius' => ['type' => 'object', 'description' => 'Circle Radius'],
        'icon_delay' => ['type' => 'object', 'description' => 'Icon Delay'],
        'icon_speed' => ['type' => 'object', 'description' => 'Menu Open Speed'],
        'icon_step_in' => ['type' => 'object', 'description' => 'Icon Step In'],
        'icon_step_out' => ['type' => 'object', 'description' => 'Icon Step Out'],
        'layout_straight_menu_gap' => ['type' => 'object', 'description' => 'Menu Between Gap'],
        'layout_straight_menu_transition_duration' => ['type' => 'object', 'description' => 'Menu Open Speed'],
        'icon_transition' => ['type' => 'string', 'description' => 'Icon Transition', 'enum' => ['cubic-bezier(n,n,n,n)', 'ease', 'ease-in', 'ease-in-out', 'ease-out', 'linear', '{{WRAPPER}} .plus-circle-menu-wrapper.layout-straight .plus-circle-menu .plus-circle-menu-list:not(.plus-circle-main-menu-list)']],
        'icon_trigger' => ['type' => 'string', 'description' => 'Icon Trigger', 'enum' => ['click', 'hover', 'icon_layout_open']],
        'repeater_icon_size' => ['type' => 'object', 'description' => 'Icon Size'],
        'repeater_circle_width' => ['type' => 'object', 'description' => 'Icon Width'],
        'repeater_icon_image_width' => ['type' => 'object', 'description' => 'Image Width'],
        'repeater_icon_border' => ['type' => 'string', 'description' => 'Icon Border', 'enum' => ['yes', 'no']],
        'icon_border_radius_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['repeater_icon_border', '{{WRAPPER}} .plus-circle-menu-inner-wrapper .plus-circle-menu-list .menu_icon']],
        'repeater_icon_border_width' => ['type' => 'object', 'description' => 'Border Width'],
        'icon_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'icon_border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'icon_border_hover_color' => ['type' => 'string', 'description' => 'Border Hover Color'],
        'icon_border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'toggle_size' => ['type' => 'object', 'description' => 'Icon Size'],
        'toggle_icon_width' => ['type' => 'object', 'description' => 'Toggle Icon Width'],
        'toggle_image_width' => ['type' => 'object', 'description' => 'Image Width'],
        'circle_menu_border_option' => ['type' => 'string', 'description' => 'Circle Menu Border', 'enum' => ['yes', 'no']],
        'toggle_icon_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['circle_menu_border_option', 'repeater_icon_border', '{{WRAPPER}} .plus-circle-menu-inner-wrapper .plus-circle-menu-list .main_menu_icon']],
        'toggle_icon_border_width' => ['type' => 'object', 'description' => 'Icon Border Width'],
        'icon_color' => ['type' => 'string', 'description' => 'Icon Color'],
        'toggle_icon_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'toggle_icon_border_radius_normal' => ['type' => 'object', 'description' => 'Border Radius'],
        'icon_hover_color' => ['type' => 'string', 'description' => 'Icon Hover Color'],
        'icon_hover_border' => ['type' => 'string', 'description' => 'Icon Hover Border'],
        'toggle_icon_border_radius_hover' => ['type' => 'object', 'description' => 'Border Radius'],
        'straight_text_padding' => ['type' => 'object', 'description' => 'Padding'],
        'straight_text_border_option' => ['type' => 'string', 'description' => 'Circle Menu Border', 'enum' => ['yes', 'no']],
        'straight_text_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['icon_layout_open', 'icon_layout_straight_style', 'repeater_icon_border', 'straight_text_border_option', '{{WRAPPER}} .plus-circle-menu-inner-wrapper .plus-circle-menu-list .menu-tooltip-title']],
        'straight_text_border_width' => ['type' => 'object', 'description' => 'Border Width'],
        'tooltip_text_color' => ['type' => 'string', 'description' => 'Text Color'],
        'straight_text_border' => ['type' => 'string', 'description' => 'Border Color'],
        'tooltip_text_normal_bgcolor' => ['type' => 'string', 'description' => 'Background Color'],
        'straight_text_hover_color' => ['type' => 'string', 'description' => 'Hover Color'],
        'straight_text_hover_border' => ['type' => 'string', 'description' => 'Hover Border'],
        'straight_text_border_radius_hover' => ['type' => 'object', 'description' => 'Border Radius'],
        'straight_text_hover_bgcolor' => ['type' => 'string', 'description' => 'Background Hover Color'],
        'tooltip_display_desktop' => ['type' => 'string', 'description' => 'Visibility Desktop', 'enum' => ['yes', 'no']],
        'tooltip_display_tablet' => ['type' => 'string', 'description' => 'Visibility Tablet', 'enum' => ['yes', 'no']],
        'tooltip_display_mobile' => ['type' => 'string', 'description' => 'Visibility Mobile', 'enum' => ['yes', 'no']],
        'show_scroll_window_offset' => ['type' => 'string', 'description' => 'Show Menu Scroll Offset', 'enum' => ['yes', 'no']],
        'scroll_top_offset_value' => ['type' => 'object', 'description' => 'Scroll Top Offset Value'],
        'show_bg_overlay_color' => ['type' => 'string', 'description' => 'Overlay Color', 'enum' => ['yes', 'no']],
        'show_bg_overlay_color_value' => ['type' => 'string', 'description' => 'Color'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_circle_menu_ability',
    'permission_callback' => 'tpaep_mcp_theplus_circle_menu_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_circle_menu_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_circle_menu_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-circle-menu';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Circle Menu widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['icon_layout_open'])) { $settings['icon_layout_open'] = sanitize_text_field($input['icon_layout_open']); }
    if (isset($input['icon_layout_straight_style'])) { $settings['icon_layout_straight_style'] = sanitize_text_field($input['icon_layout_straight_style']); }
    if (isset($input['icon_direction'])) { $settings['icon_direction'] = sanitize_text_field($input['icon_direction']); }
    if (isset($input['layout_straight_menu_direction'])) { $settings['layout_straight_menu_direction'] = sanitize_text_field($input['layout_straight_menu_direction']); }
    if (isset($input['tooltip_menu_title'])) { $settings['tooltip_menu_title'] = sanitize_text_field($input['tooltip_menu_title']); }
    if (isset($input['loop_image_icon'])) { $settings['loop_image_icon'] = sanitize_text_field($input['loop_image_icon']); }
    if (!empty($input['loop_select_image'])) { $settings['loop_select_image'] = ['id' => absint($input['loop_select_image'])]; }
    if (isset($input['loop_icon_style'])) { $settings['loop_icon_style'] = sanitize_text_field($input['loop_icon_style']); }
    if (isset($input['loop_icon_fontawesome'])) { $settings['loop_icon_fontawesome'] = sanitize_text_field($input['loop_icon_fontawesome']); }
    if (isset($input['loop_icon_fontawesome_5'])) { $settings['loop_icon_fontawesome_5'] = sanitize_text_field($input['loop_icon_fontawesome_5']); }
    if (isset($input['loop_icons_mind'])) { $settings['loop_icons_mind'] = sanitize_text_field($input['loop_icons_mind']); }
    if (isset($input['loop_icon_link_type'])) { $settings['loop_icon_link_type'] = sanitize_text_field($input['loop_icon_link_type']); }
    if (isset($input['icons_url'])) { $settings['icons_url'] = $input['icons_url']; }
    if (isset($input['email'])) { $settings['email'] = sanitize_text_field($input['email']); }
    if (isset($input['phone'])) { $settings['phone'] = sanitize_text_field($input['phone']); }
    if (isset($input['icon_color'])) { $settings['icon_color'] = sanitize_text_field($input['icon_color']); }
    if (isset($input['icon_border_color'])) { $settings['icon_border_color'] = sanitize_text_field($input['icon_border_color']); }
    if (isset($input['icon_hover_color'])) { $settings['icon_hover_color'] = sanitize_text_field($input['icon_hover_color']); }
    if (isset($input['icon_border_hover_color'])) { $settings['icon_border_hover_color'] = sanitize_text_field($input['icon_border_hover_color']); }
    if (isset($input['tooltip_default_hover'])) { $settings['tooltip_default_hover'] = sanitize_text_field($input['tooltip_default_hover']); }
    if (isset($input['tooltip_text_rotate'])) { $settings['tooltip_text_rotate'] = $input['tooltip_text_rotate']; }
    if (isset($input['tooltip_text_top'])) { $settings['tooltip_text_top'] = $input['tooltip_text_top']; }
    if (isset($input['tooltip_text_left'])) { $settings['tooltip_text_left'] = $input['tooltip_text_left']; }
    if (isset($input['tooltip_text_arrow'])) { $settings['tooltip_text_arrow'] = sanitize_text_field($input['tooltip_text_arrow']); }
    if (isset($input['circle_menu_list'])) { $settings['circle_menu_list'] = $input['circle_menu_list']; }
    if (isset($input['loop_image_main_icon'])) { $settings['loop_image_main_icon'] = sanitize_text_field($input['loop_image_main_icon']); }
    if (isset($input['loop_max_main_width'])) { $settings['loop_max_main_width'] = $input['loop_max_main_width']; }
    if (!empty($input['loop_select_main_image'])) { $settings['loop_select_main_image'] = ['id' => absint($input['loop_select_main_image'])]; }
    if (isset($input['loop_icon_main_style'])) { $settings['loop_icon_main_style'] = sanitize_text_field($input['loop_icon_main_style']); }
    if (isset($input['loop_icon_main_fontawesome'])) { $settings['loop_icon_main_fontawesome'] = sanitize_text_field($input['loop_icon_main_fontawesome']); }
    if (isset($input['loop_icon_main_fontawesome_5'])) { $settings['loop_icon_main_fontawesome_5'] = sanitize_text_field($input['loop_icon_main_fontawesome_5']); }
    if (isset($input['loop_icons_main_mind'])) { $settings['loop_icons_main_mind'] = sanitize_text_field($input['loop_icons_main_mind']); }
    if (isset($input['toggle_open_icon_style'])) { $settings['toggle_open_icon_style'] = sanitize_text_field($input['toggle_open_icon_style']); }
    if (isset($input['main_icon_position'])) { $settings['main_icon_position'] = sanitize_text_field($input['main_icon_position']); }
    if (isset($input['d_left_auto'])) { $settings['d_left_auto'] = sanitize_text_field($input['d_left_auto']); }
    if (isset($input['d_pos_xposition'])) { $settings['d_pos_xposition'] = $input['d_pos_xposition']; }
    if (isset($input['d_right_auto'])) { $settings['d_right_auto'] = sanitize_text_field($input['d_right_auto']); }
    if (isset($input['d_pos_rightposition'])) { $settings['d_pos_rightposition'] = $input['d_pos_rightposition']; }
    if (isset($input['d_top_auto'])) { $settings['d_top_auto'] = sanitize_text_field($input['d_top_auto']); }
    if (isset($input['d_pos_yposition'])) { $settings['d_pos_yposition'] = $input['d_pos_yposition']; }
    if (isset($input['d_bottom_auto'])) { $settings['d_bottom_auto'] = sanitize_text_field($input['d_bottom_auto']); }
    if (isset($input['d_pos_bottomposition'])) { $settings['d_pos_bottomposition'] = $input['d_pos_bottomposition']; }
    if (isset($input['t_responsive'])) { $settings['t_responsive'] = sanitize_text_field($input['t_responsive']); }
    if (isset($input['t_left_auto'])) { $settings['t_left_auto'] = sanitize_text_field($input['t_left_auto']); }
    if (isset($input['t_pos_xposition'])) { $settings['t_pos_xposition'] = $input['t_pos_xposition']; }
    if (isset($input['t_right_auto'])) { $settings['t_right_auto'] = sanitize_text_field($input['t_right_auto']); }
    if (isset($input['t_pos_rightposition'])) { $settings['t_pos_rightposition'] = $input['t_pos_rightposition']; }
    if (isset($input['t_top_auto'])) { $settings['t_top_auto'] = sanitize_text_field($input['t_top_auto']); }
    if (isset($input['t_pos_yposition'])) { $settings['t_pos_yposition'] = $input['t_pos_yposition']; }
    if (isset($input['t_bottom_auto'])) { $settings['t_bottom_auto'] = sanitize_text_field($input['t_bottom_auto']); }
    if (isset($input['t_pos_bottomposition'])) { $settings['t_pos_bottomposition'] = $input['t_pos_bottomposition']; }
    if (isset($input['m_responsive'])) { $settings['m_responsive'] = sanitize_text_field($input['m_responsive']); }
    if (isset($input['m_left_auto'])) { $settings['m_left_auto'] = sanitize_text_field($input['m_left_auto']); }
    if (isset($input['m_pos_xposition'])) { $settings['m_pos_xposition'] = $input['m_pos_xposition']; }
    if (isset($input['m_right_auto'])) { $settings['m_right_auto'] = sanitize_text_field($input['m_right_auto']); }
    if (isset($input['m_pos_rightposition'])) { $settings['m_pos_rightposition'] = $input['m_pos_rightposition']; }
    if (isset($input['m_top_auto'])) { $settings['m_top_auto'] = sanitize_text_field($input['m_top_auto']); }
    if (isset($input['m_pos_yposition'])) { $settings['m_pos_yposition'] = $input['m_pos_yposition']; }
    if (isset($input['m_bottom_auto'])) { $settings['m_bottom_auto'] = sanitize_text_field($input['m_bottom_auto']); }
    if (isset($input['m_pos_bottomposition'])) { $settings['m_pos_bottomposition'] = $input['m_pos_bottomposition']; }
    if (isset($input['angle_start'])) { $settings['angle_start'] = $input['angle_start']; }
    if (isset($input['angle_end'])) { $settings['angle_end'] = $input['angle_end']; }
    if (isset($input['circle_radius'])) { $settings['circle_radius'] = $input['circle_radius']; }
    if (isset($input['icon_delay'])) { $settings['icon_delay'] = $input['icon_delay']; }
    if (isset($input['icon_speed'])) { $settings['icon_speed'] = $input['icon_speed']; }
    if (isset($input['icon_step_in'])) { $settings['icon_step_in'] = $input['icon_step_in']; }
    if (isset($input['icon_step_out'])) { $settings['icon_step_out'] = $input['icon_step_out']; }
    if (isset($input['layout_straight_menu_gap'])) { $settings['layout_straight_menu_gap'] = $input['layout_straight_menu_gap']; }
    if (isset($input['layout_straight_menu_transition_duration'])) { $settings['layout_straight_menu_transition_duration'] = $input['layout_straight_menu_transition_duration']; }
    if (isset($input['icon_transition'])) { $settings['icon_transition'] = sanitize_text_field($input['icon_transition']); }
    if (isset($input['icon_trigger'])) { $settings['icon_trigger'] = sanitize_text_field($input['icon_trigger']); }
    if (isset($input['repeater_icon_size'])) { $settings['repeater_icon_size'] = $input['repeater_icon_size']; }
    if (isset($input['repeater_circle_width'])) { $settings['repeater_circle_width'] = $input['repeater_circle_width']; }
    if (isset($input['repeater_icon_image_width'])) { $settings['repeater_icon_image_width'] = $input['repeater_icon_image_width']; }
    if (isset($input['repeater_icon_border'])) { $settings['repeater_icon_border'] = sanitize_text_field($input['repeater_icon_border']); }
    if (isset($input['icon_border_radius_style'])) { $settings['icon_border_radius_style'] = sanitize_text_field($input['icon_border_radius_style']); }
    if (isset($input['repeater_icon_border_width'])) { $settings['repeater_icon_border_width'] = $input['repeater_icon_border_width']; }
    if (isset($input['icon_border_color'])) { $settings['icon_border_color'] = sanitize_text_field($input['icon_border_color']); }
    if (isset($input['icon_border_radius'])) { $settings['icon_border_radius'] = $input['icon_border_radius']; }
    if (isset($input['icon_border_hover_color'])) { $settings['icon_border_hover_color'] = sanitize_text_field($input['icon_border_hover_color']); }
    if (isset($input['icon_border_hover_radius'])) { $settings['icon_border_hover_radius'] = $input['icon_border_hover_radius']; }
    if (isset($input['toggle_size'])) { $settings['toggle_size'] = $input['toggle_size']; }
    if (isset($input['toggle_icon_width'])) { $settings['toggle_icon_width'] = $input['toggle_icon_width']; }
    if (isset($input['toggle_image_width'])) { $settings['toggle_image_width'] = $input['toggle_image_width']; }
    if (isset($input['circle_menu_border_option'])) { $settings['circle_menu_border_option'] = sanitize_text_field($input['circle_menu_border_option']); }
    if (isset($input['toggle_icon_border_style'])) { $settings['toggle_icon_border_style'] = sanitize_text_field($input['toggle_icon_border_style']); }
    if (isset($input['toggle_icon_border_width'])) { $settings['toggle_icon_border_width'] = $input['toggle_icon_border_width']; }
    if (isset($input['icon_color'])) { $settings['icon_color'] = sanitize_text_field($input['icon_color']); }
    if (isset($input['toggle_icon_border_color'])) { $settings['toggle_icon_border_color'] = sanitize_text_field($input['toggle_icon_border_color']); }
    if (isset($input['toggle_icon_border_radius_normal'])) { $settings['toggle_icon_border_radius_normal'] = $input['toggle_icon_border_radius_normal']; }
    if (isset($input['icon_hover_color'])) { $settings['icon_hover_color'] = sanitize_text_field($input['icon_hover_color']); }
    if (isset($input['icon_hover_border'])) { $settings['icon_hover_border'] = sanitize_text_field($input['icon_hover_border']); }
    if (isset($input['toggle_icon_border_radius_hover'])) { $settings['toggle_icon_border_radius_hover'] = $input['toggle_icon_border_radius_hover']; }
    if (isset($input['straight_text_padding'])) { $settings['straight_text_padding'] = $input['straight_text_padding']; }
    if (isset($input['straight_text_border_option'])) { $settings['straight_text_border_option'] = sanitize_text_field($input['straight_text_border_option']); }
    if (isset($input['straight_text_border_style'])) { $settings['straight_text_border_style'] = sanitize_text_field($input['straight_text_border_style']); }
    if (isset($input['straight_text_border_width'])) { $settings['straight_text_border_width'] = $input['straight_text_border_width']; }
    if (isset($input['tooltip_text_color'])) { $settings['tooltip_text_color'] = sanitize_text_field($input['tooltip_text_color']); }
    if (isset($input['straight_text_border'])) { $settings['straight_text_border'] = sanitize_text_field($input['straight_text_border']); }
    if (isset($input['tooltip_text_normal_bgcolor'])) { $settings['tooltip_text_normal_bgcolor'] = sanitize_text_field($input['tooltip_text_normal_bgcolor']); }
    if (isset($input['straight_text_hover_color'])) { $settings['straight_text_hover_color'] = sanitize_text_field($input['straight_text_hover_color']); }
    if (isset($input['straight_text_hover_border'])) { $settings['straight_text_hover_border'] = sanitize_text_field($input['straight_text_hover_border']); }
    if (isset($input['straight_text_border_radius_hover'])) { $settings['straight_text_border_radius_hover'] = $input['straight_text_border_radius_hover']; }
    if (isset($input['straight_text_hover_bgcolor'])) { $settings['straight_text_hover_bgcolor'] = sanitize_text_field($input['straight_text_hover_bgcolor']); }
    if (isset($input['tooltip_display_desktop'])) { $settings['tooltip_display_desktop'] = sanitize_text_field($input['tooltip_display_desktop']); }
    if (isset($input['tooltip_display_tablet'])) { $settings['tooltip_display_tablet'] = sanitize_text_field($input['tooltip_display_tablet']); }
    if (isset($input['tooltip_display_mobile'])) { $settings['tooltip_display_mobile'] = sanitize_text_field($input['tooltip_display_mobile']); }
    if (isset($input['show_scroll_window_offset'])) { $settings['show_scroll_window_offset'] = sanitize_text_field($input['show_scroll_window_offset']); }
    if (isset($input['scroll_top_offset_value'])) { $settings['scroll_top_offset_value'] = $input['scroll_top_offset_value']; }
    if (isset($input['show_bg_overlay_color'])) { $settings['show_bg_overlay_color'] = sanitize_text_field($input['show_bg_overlay_color']); }
    if (isset($input['show_bg_overlay_color_value'])) { $settings['show_bg_overlay_color_value'] = sanitize_text_field($input['show_bg_overlay_color_value']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
