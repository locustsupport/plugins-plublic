<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-unfold', [
'label' => __('Unfold', 'theplus'),
    'description' => __('Adds The Plus "Unfold" widget (tp-unfold) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'content_title' => ['type' => 'string', 'description' => 'Title'],
        'content_a_source' => ['type' => 'string', 'description' => 'Select Source', 'enum' => ['containerbased', 'content', 'innersectionbased', 'template']],
        'content_description' => ['type' => 'string', 'description' => 'Content'],
        'content_a_template' => ['type' => 'string', 'description' => 'content_a_template', 'enum' => ['content_a_source']],
        'icon_type' => ['type' => 'string', 'description' => 'Icon Type', 'enum' => ['icon', 'lottie']],
        'content_readmore' => ['type' => 'string', 'description' => 'Expand Button Text'],
        'icon_position' => ['type' => 'string', 'description' => 'Icon Position', 'enum' => ['icon_type', 'tp_ic_pos_after', 'tp_ic_pos_before']],
        'lottieUrl' => ['type' => 'object', 'description' => 'Lottie URL'],
        'content_readmore_icon' => ['type' => 'string', 'description' => 'Expand Button Icon'],
        'content_readless' => ['type' => 'string', 'description' => 'Collapse Button Text'],
        'content_readless_icon' => ['type' => 'string', 'description' => 'Collapse Button Icon'],
        'extra_link' => ['type' => 'string', 'description' => 'Extra Button', 'enum' => ['yes', 'no']],
        'eb_text' => ['type' => 'string', 'description' => 'Text'],
        'eb_link' => ['type' => 'object', 'description' => 'eb_link'],
        'content_eb_icon' => ['type' => 'string', 'description' => 'Extra Button Icon'],
        'con_pos' => ['type' => 'string', 'description' => 'Content Expand Direction', 'enum' => ['after_button']],
        'content_max_height' => ['type' => 'object', 'description' => 'Max Height (Slider/Size Object)'],
        'co_custom' => ['type' => 'string', 'description' => 'Custom Opacity', 'enum' => ['yes', 'no']],
        'co_c_min_height' => ['type' => 'object', 'description' => 'Opacity Height (Slider/Size Object)'],
        'co_c_opacity_color' => ['type' => 'string', 'description' => 'Opacity Color (Color Hex/RGBA)'],
        'transition_duration' => ['type' => 'string', 'description' => 'Transition Duration (0 - 5000)'],
        'content_align' => ['type' => 'object', 'description' => 'Toggle Alignment', 'enum' => ['center', 'flex-end', 'flex-start', 'icon', 'space-around', 'space-between', '{{WRAPPER}} .tp-unfold-wrapper .tp-unfold-last-toggle']],
        'unfold_scroll_top' => ['type' => 'string', 'description' => 'Scroll Top', 'enum' => ['yes', 'no']],
        'title_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'uf_title_tag' => ['type' => 'string', 'description' => 'Title Tag'],
        'title_align' => ['type' => 'object', 'description' => 'Title Alignment', 'enum' => ['center', 'icon', 'left', 'right', '{{WRAPPER}} .tp-unfold-wrapper .tp-unfold-title']],
        'title_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'description_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'description_align' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'content_a_source', 'icon', 'justify', 'left', 'right', '{{WRAPPER}} .tp-unfold-wrapper .tp-unfold-description,{{WRAPPER}} .tp-unfold-wrapper .tp-unfold-description p']],
        'description_color' => ['type' => 'string', 'description' => 'Description Color (Color Hex/RGBA)'],
        'tb_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'tb_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'tb_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'tb_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'tb_color_h' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'tb_br_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'tb_icn_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'tb_icn_space' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'tb_icn_space_left' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'tb_icn_color_n' => ['type' => 'string', 'description' => 'Normal Color (Color Hex/RGBA)'],
        'tb_icn_color_h' => ['type' => 'string', 'description' => 'Hover Color (Color Hex/RGBA)'],
        'tbw_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'lottieMright' => ['type' => 'object', 'description' => 'Margin Right (Slider/Size Object)'],
        'lottieMleft' => ['type' => 'object', 'description' => 'Margin Left (Slider/Size Object)'],
        'lottieWidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'lottieHeight' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'lottieSpeed' => ['type' => 'object', 'description' => 'Speed (Slider/Size Object)'],
        'lottieLoop' => ['type' => 'string', 'description' => 'Loop Animation', 'enum' => ['yes', 'no']],
        'lottiehover' => ['type' => 'string', 'description' => 'Hover Animation', 'enum' => ['yes', 'no']],
        'etb_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'etb_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'etb_color_h' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'etb_br_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'etb_icn_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'etb_icn_space' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'etb_icn_space_left' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'etb_icn_color_n' => ['type' => 'string', 'description' => 'Normal Color (Color Hex/RGBA)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports multi-source templates, custom opacity transitions, and dynamic separator heights.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_unfold_ability',
    'permission_callback' => 'tpaep_mcp_theplus_unfold_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_unfold_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_unfold_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-unfold';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Unfold widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['content_title'])) { $settings['content_title'] = sanitize_text_field($input['content_title']); }
    if (isset($input['content_a_source'])) { $settings['content_a_source'] = sanitize_text_field($input['content_a_source']); }
    if (isset($input['content_description'])) { $settings['content_description'] = sanitize_text_field($input['content_description']); }
    if (isset($input['content_a_template'])) { $settings['content_a_template'] = sanitize_text_field($input['content_a_template']); }
    if (isset($input['icon_type'])) { $settings['icon_type'] = sanitize_text_field($input['icon_type']); }
    if (isset($input['content_readmore'])) { $settings['content_readmore'] = sanitize_text_field($input['content_readmore']); }
    if (isset($input['icon_position'])) { $settings['icon_position'] = sanitize_text_field($input['icon_position']); }
    if (isset($input['lottieUrl'])) { $settings['lottieUrl'] = $input['lottieUrl']; }
    if (isset($input['content_readmore_icon'])) { $settings['content_readmore_icon'] = sanitize_text_field($input['content_readmore_icon']); }
    if (isset($input['content_readless'])) { $settings['content_readless'] = sanitize_text_field($input['content_readless']); }
    if (isset($input['content_readless_icon'])) { $settings['content_readless_icon'] = sanitize_text_field($input['content_readless_icon']); }
    if (isset($input['extra_link'])) { $settings['extra_link'] = sanitize_text_field($input['extra_link']); }
    if (isset($input['eb_text'])) { $settings['eb_text'] = sanitize_text_field($input['eb_text']); }
    if (isset($input['eb_link'])) { $settings['eb_link'] = $input['eb_link']; }
    if (isset($input['content_eb_icon'])) { $settings['content_eb_icon'] = sanitize_text_field($input['content_eb_icon']); }
    if (isset($input['con_pos'])) { $settings['con_pos'] = sanitize_text_field($input['con_pos']); }
    if (isset($input['content_max_height'])) { $settings['content_max_height'] = $input['content_max_height']; }
    if (isset($input['co_custom'])) { $settings['co_custom'] = sanitize_text_field($input['co_custom']); }
    if (isset($input['co_c_min_height'])) { $settings['co_c_min_height'] = $input['co_c_min_height']; }
    if (isset($input['co_c_opacity_color'])) { $settings['co_c_opacity_color'] = sanitize_text_field($input['co_c_opacity_color']); }
    if (isset($input['transition_duration'])) { $settings['transition_duration'] = sanitize_text_field($input['transition_duration']); }
    if (isset($input['content_align'])) { $settings['content_align'] = $input['content_align']; }
    if (isset($input['unfold_scroll_top'])) { $settings['unfold_scroll_top'] = sanitize_text_field($input['unfold_scroll_top']); }
    if (isset($input['title_margin'])) { $settings['title_margin'] = $input['title_margin']; }
    if (isset($input['uf_title_tag'])) { $settings['uf_title_tag'] = sanitize_text_field($input['uf_title_tag']); }
    if (isset($input['title_align'])) { $settings['title_align'] = $input['title_align']; }
    if (isset($input['title_text_color'])) { $settings['title_text_color'] = sanitize_text_field($input['title_text_color']); }
    if (isset($input['description_margin'])) { $settings['description_margin'] = $input['description_margin']; }
    if (isset($input['description_align'])) { $settings['description_align'] = $input['description_align']; }
    if (isset($input['description_color'])) { $settings['description_color'] = sanitize_text_field($input['description_color']); }
    if (isset($input['tb_padding'])) { $settings['tb_padding'] = $input['tb_padding']; }
    if (isset($input['tb_margin'])) { $settings['tb_margin'] = $input['tb_margin']; }
    if (isset($input['tb_color'])) { $settings['tb_color'] = sanitize_text_field($input['tb_color']); }
    if (isset($input['tb_br'])) { $settings['tb_br'] = $input['tb_br']; }
    if (isset($input['tb_color_h'])) { $settings['tb_color_h'] = sanitize_text_field($input['tb_color_h']); }
    if (isset($input['tb_br_h'])) { $settings['tb_br_h'] = $input['tb_br_h']; }
    if (isset($input['tb_icn_size'])) { $settings['tb_icn_size'] = $input['tb_icn_size']; }
    if (isset($input['tb_icn_space'])) { $settings['tb_icn_space'] = $input['tb_icn_space']; }
    if (isset($input['tb_icn_space_left'])) { $settings['tb_icn_space_left'] = $input['tb_icn_space_left']; }
    if (isset($input['tb_icn_color_n'])) { $settings['tb_icn_color_n'] = sanitize_text_field($input['tb_icn_color_n']); }
    if (isset($input['tb_icn_color_h'])) { $settings['tb_icn_color_h'] = sanitize_text_field($input['tb_icn_color_h']); }
    if (isset($input['tbw_margin'])) { $settings['tbw_margin'] = $input['tbw_margin']; }
    if (isset($input['lottieMright'])) { $settings['lottieMright'] = $input['lottieMright']; }
    if (isset($input['lottieMleft'])) { $settings['lottieMleft'] = $input['lottieMleft']; }
    if (isset($input['lottieWidth'])) { $settings['lottieWidth'] = $input['lottieWidth']; }
    if (isset($input['lottieHeight'])) { $settings['lottieHeight'] = $input['lottieHeight']; }
    if (isset($input['lottieSpeed'])) { $settings['lottieSpeed'] = $input['lottieSpeed']; }
    if (isset($input['lottieLoop'])) { $settings['lottieLoop'] = sanitize_text_field($input['lottieLoop']); }
    if (isset($input['lottiehover'])) { $settings['lottiehover'] = sanitize_text_field($input['lottiehover']); }
    if (isset($input['etb_color'])) { $settings['etb_color'] = sanitize_text_field($input['etb_color']); }
    if (isset($input['etb_br'])) { $settings['etb_br'] = $input['etb_br']; }
    if (isset($input['etb_color_h'])) { $settings['etb_color_h'] = sanitize_text_field($input['etb_color_h']); }
    if (isset($input['etb_br_h'])) { $settings['etb_br_h'] = $input['etb_br_h']; }
    if (isset($input['etb_icn_size'])) { $settings['etb_icn_size'] = $input['etb_icn_size']; }
    if (isset($input['etb_icn_space'])) { $settings['etb_icn_space'] = $input['etb_icn_space']; }
    if (isset($input['etb_icn_space_left'])) { $settings['etb_icn_space_left'] = $input['etb_icn_space_left']; }
    if (isset($input['etb_icn_color_n'])) { $settings['etb_icn_color_n'] = sanitize_text_field($input['etb_icn_color_n']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
