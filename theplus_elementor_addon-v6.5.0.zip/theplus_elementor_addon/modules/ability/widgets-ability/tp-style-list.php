<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-style-list', [
'label' => __('Style Lists', 'theplus'),
    'description' => __('Adds The Plus "Style Lists" widget (tp-style-list) with icon and description items.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'          => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'        => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'         => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'content_description' => ['type' => 'string', 'description' => 'Description'],
        'icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['font_awesome', 'font_awesome_5', 'icon_mind']],
        'icon_fs_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome', 'enum' => ['yes', 'no']],
        'icon_fontawesome' => ['type' => 'string', 'description' => 'Icon Library'],
        'icon_f5_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome 5', 'enum' => ['yes', 'no']],
        'icon_fontawesome_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'icon_mind_popover_toggle' => ['type' => 'string', 'description' => 'Icons Mind', 'enum' => ['yes', 'no']],
        'icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['icon_style']],
        'link' => ['type' => 'object', 'description' => 'Link'],
        'show_pin_hint' => ['type' => 'string', 'description' => 'Pin Hint', 'enum' => ['yes', 'no']],
        'hint_text' => ['type' => 'string', 'description' => 'Hint Text'],
        'hint_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'hint_bg_color' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'hint_left_space' => ['type' => 'object', 'description' => 'Horizontal Adjust (Slider/Size Object)'],
        'hint_top_space' => ['type' => 'object', 'description' => 'Vertical Adjust (Slider/Size Object)'],
        'show_background_style' => ['type' => 'string', 'description' => 'Interactive Hover Bg Style', 'enum' => ['yes', 'no']],
        'show_tooltips' => ['type' => 'string', 'description' => 'Tooltip', 'enum' => ['yes', 'no']],
        'content_type' => ['type' => 'string', 'description' => 'Content Type', 'enum' => ['content_wysiwyg', 'normal_desc', 'show_tooltips', 'template']],
        'tooltip_content_desc' => ['type' => 'string', 'description' => 'Description'],
        'tooltip_content_wysiwyg' => ['type' => 'string', 'description' => 'Tooltip Content'],
        'tooltip_content_align' => ['type' => 'string', 'description' => 'Text Alignment', 'enum' => ['center', 'content_type', 'icon', 'left', 'right', 'show_tooltips', '{{WRAPPER}} {{CURRENT_ITEM}} .tippy-tooltip .tippy-content']],
        'tooltip_content_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'tooltip_content_template' => ['type' => 'string', 'description' => 'Elementor Templates', 'enum' => ['content_type', 'show_tooltips']],
        'icon_list' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'icon_list'],
        'icon_align' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'flex-end', 'flex-start', 'icon', '{{WRAPPER}} .plus-stylist-list-wrapper', '{{WRAPPER}} .plus-stylist-list-wrapper .plus-icon-list-items', '{{WRAPPER}} .plus-stylist-list-wrapper.tp-sl-l-horizontal .plus-icon-list-items']],
        'read_more_toggle' => ['type' => 'string', 'description' => 'Read More Toggle', 'enum' => ['yes', 'no']],
        'load_show_list_toggle' => ['type' => 'string', 'description' => 'List Open Default'],
        'read_show_option' => ['type' => 'string', 'description' => 'Expand Section Title'],
        'read_less_option' => ['type' => 'string', 'description' => 'Shrink Section Title'],
        'read_toggle_direction' => ['type' => 'string', 'description' => 'Toggle Direction', 'enum' => ['read_more_toggle', 'vertical']],
        'hover_background_style' => ['type' => 'string', 'description' => 'Interactive Links', 'enum' => ['yes', 'no']],
        'sl_display_counter' => ['type' => 'string', 'description' => 'Display Counter', 'enum' => ['yes', 'no']],
        'sl_display_counter_style' => ['type' => 'string', 'description' => 'Counter Style', 'enum' => ['decimal-leading-zero', 'lower-alpha', 'lower-greek', 'lower-roman', 'number-normal', 'sl_display_counter', 'upper-alpha', 'upper-roman']],
        'layout' => ['type' => 'string', 'description' => 'Desktop Layout', 'enum' => ['tp_sl_l_horizontal']],
        'tablet_layout' => ['type' => 'string', 'description' => 'Tablet Layout', 'enum' => ['tp_sl_l_horizontal']],
        'mobile_layout' => ['type' => 'string', 'description' => 'Mobile Layout', 'enum' => ['tp_sl_l_horizontal']],
        'stylishlist_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'icon_border_bottom_color' => ['type' => 'string', 'description' => 'Separate Color (Color Hex/RGBA)'],
        'space_between' => ['type' => 'object', 'description' => 'Space Between (Slider/Size Object)'],
        'space_between_h_right' => ['type' => 'object', 'description' => 'Space Between (Slider/Size Object)'],
        'space_between_h_bottom' => ['type' => 'object', 'description' => 'Bottom Space (Slider/Size Object)'],
        'min_width_h_list' => ['type' => 'object', 'description' => 'Min. Width (Slider/Size Object)'],
        'stylishlist_br_n' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'stylishlist_br_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'icon_position' => ['type' => 'string', 'description' => 'Position', 'enum' => ['after', 'before']],
        'icon_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'icon_color_stroke' => ['type' => 'string', 'description' => 'Stroke Color (Color Hex/RGBA)'],
        'icon_color_fill' => ['type' => 'string', 'description' => 'Fill Color (Color Hex/RGBA)'],
        'icon_color_hover' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'icon_color_h_fill' => ['type' => 'string', 'description' => 'Fill Color (Color Hex/RGBA)'],
        'icon_color_h_stroke' => ['type' => 'string', 'description' => 'Stroke Color (Color Hex/RGBA)'],
        'icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'icon_indent' => ['type' => 'object', 'description' => 'Icon Indent (Slider/Size Object)'],
        'vertical_center' => ['type' => 'object', 'description' => 'Vertical Center', 'enum' => ['yes', 'no']],
        'adv_icon_style' => ['type' => 'string', 'description' => 'Advanced Style', 'enum' => ['yes', 'no']],
        'icon_inner_width' => ['type' => 'object', 'description' => 'Icon Width (Slider/Size Object)'],
        'icon_adv_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'icon_border_hover' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'icon_adv_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'display_counter_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'display_counter_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'dc_box_size' => ['type' => 'object', 'description' => 'Box Size (Slider/Size Object)'],
        'dc_align' => ['type' => 'string', 'description' => 'Alignment', 'enum' => ['center', 'flex-end', 'flex-start', 'icon', '{{WRAPPER}} .plus-stylist-list-wrapper ul li .tp-sl-dc']],
        'display_counter_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'display_counter_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'display_counter_color_h' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'display_counter_radius_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'text_indent' => ['type' => 'object', 'description' => 'Text Indent (Slider/Size Object)'],
        'contant_height' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'text_color_hover' => ['type' => 'string', 'description' => 'Text Hover Color (Color Hex/RGBA)'],
        'read_more_align' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'icon', 'left', 'read_toggle_direction', 'right', '{{WRAPPER}} .plus-stylist-list-wrapper.tp-sl-readtog-verti a.read-more-options']],
        'toggle_expand_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'toggle_expand_text_hover' => ['type' => 'string', 'description' => 'Text Hover Color (Color Hex/RGBA)'],
        'top_toggle_indent' => ['type' => 'object', 'description' => 'Top Indent (Slider/Size Object)'],
        'hint_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'hint_left_space' => ['type' => 'object', 'description' => 'Horizontal Adjust (Slider/Size Object)'],
        'hint_left_width' => ['type' => 'object', 'description' => 'Min Width Adjust (Slider/Size Object)'],
        'hint_right_width' => ['type' => 'object', 'description' => 'Min Width Adjust (Slider/Size Object)'],
        'hint_top_space' => ['type' => 'object', 'description' => 'Vertical Adjust (Slider/Size Object)'],
        'hint_align' => ['type' => 'object', 'description' => 'Hint Text Alignment', 'enum' => ['icon', 'left', 'right']],
        'hint_bf' => ['type' => 'string', 'description' => 'Backdrop Filter', 'enum' => ['yes', 'no']],
        'hint_bf_blur' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'hint_bf_grayscale' => ['type' => 'object', 'description' => 'Grayscale (Slider/Size Object)'],
        'hint_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'tooltip_bf' => ['type' => 'string', 'description' => 'Backdrop Filter', 'enum' => ['yes', 'no']],
        'tooltip_bf_blur' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'tooltip_bf_grayscale' => ['type' => 'object', 'description' => 'Grayscale (Slider/Size Object)'],
        'hover_inverse_effect' => ['type' => 'string', 'description' => 'On Hover Inverse Effect', 'enum' => ['yes', 'no']],
        'unhover_item_opacity' => ['type' => 'object', 'description' => 'Not Selected Item Opacity (Slider/Size Object)'],
        'hover_effect_area' => ['type' => 'string', 'description' => 'Effect Area', 'enum' => ['hover_inverse_effect', 'individual']],
        'global_hover_item_id' => ['type' => 'string', 'description' => 'Global List Connection Id'],
        'animation_effects' => ['type' => 'string', 'description' => 'Choose Animation Effect'],
        'animation_delay' => ['type' => 'object', 'description' => 'Animation Delay (Slider/Size Object)'],
        'animated_column_list' => ['type' => 'string', 'description' => 'List Load Animation', 'enum' => ['animation_effects!', 'stagger']],
        'animation_stagger' => ['type' => 'object', 'description' => 'Animation Stagger (Slider/Size Object)'],
        'animation_duration_default' => ['type' => 'string', 'description' => 'Animation Duration', 'enum' => ['yes', 'no']],
        'animate_duration' => ['type' => 'object', 'description' => 'Duration Speed (Slider/Size Object)'],
        'animation_out_effects' => ['type' => 'string', 'description' => 'Out Animation Effect', 'enum' => ['animation_effects!']],
        'animation_out_delay' => ['type' => 'object', 'description' => 'Out Animation Delay (Slider/Size Object)'],
        'animation_out_duration_default' => ['type' => 'string', 'description' => 'Out Animation Duration', 'enum' => ['yes', 'no']],
        'animation_out_duration' => ['type' => 'object', 'description' => 'Duration Speed (Slider/Size Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports Lottie icon animations, dynamic content counters, and responsive multi-column stacking.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_style_list_ability',
    'permission_callback' => 'tpaep_mcp_theplus_style_list_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_style_list_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_style_list_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-style-list';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Style List widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }

    if (isset($input['content_description'])) { $settings['content_description'] = sanitize_text_field($input['content_description']); }
    if (isset($input['icon_style'])) { $settings['icon_style'] = sanitize_text_field($input['icon_style']); }
    if (isset($input['icon_fs_popover_toggle'])) { $settings['icon_fs_popover_toggle'] = sanitize_text_field($input['icon_fs_popover_toggle']); }
    if (isset($input['icon_fontawesome'])) { $settings['icon_fontawesome'] = sanitize_text_field($input['icon_fontawesome']); }
    if (isset($input['icon_f5_popover_toggle'])) { $settings['icon_f5_popover_toggle'] = sanitize_text_field($input['icon_f5_popover_toggle']); }
    if (isset($input['icon_fontawesome_5'])) { $settings['icon_fontawesome_5'] = sanitize_text_field($input['icon_fontawesome_5']); }
    if (isset($input['icon_mind_popover_toggle'])) { $settings['icon_mind_popover_toggle'] = sanitize_text_field($input['icon_mind_popover_toggle']); }
    if (isset($input['icons_mind'])) { $settings['icons_mind'] = sanitize_text_field($input['icons_mind']); }
    if (isset($input['link'])) { $settings['link'] = $input['link']; }
    if (isset($input['show_pin_hint'])) { $settings['show_pin_hint'] = sanitize_text_field($input['show_pin_hint']); }
    if (isset($input['hint_text'])) { $settings['hint_text'] = sanitize_text_field($input['hint_text']); }
    if (isset($input['hint_text_color'])) { $settings['hint_text_color'] = sanitize_text_field($input['hint_text_color']); }
    if (isset($input['hint_bg_color'])) { $settings['hint_bg_color'] = sanitize_text_field($input['hint_bg_color']); }
    if (isset($input['hint_left_space'])) { $settings['hint_left_space'] = $input['hint_left_space']; }
    if (isset($input['hint_top_space'])) { $settings['hint_top_space'] = $input['hint_top_space']; }
    if (isset($input['show_background_style'])) { $settings['show_background_style'] = sanitize_text_field($input['show_background_style']); }
    if (isset($input['show_tooltips'])) { $settings['show_tooltips'] = sanitize_text_field($input['show_tooltips']); }
    if (isset($input['content_type'])) { $settings['content_type'] = sanitize_text_field($input['content_type']); }
    if (isset($input['tooltip_content_desc'])) { $settings['tooltip_content_desc'] = sanitize_text_field($input['tooltip_content_desc']); }
    if (isset($input['tooltip_content_wysiwyg'])) { $settings['tooltip_content_wysiwyg'] = sanitize_text_field($input['tooltip_content_wysiwyg']); }
    if (isset($input['tooltip_content_align'])) { $settings['tooltip_content_align'] = sanitize_text_field($input['tooltip_content_align']); }
    if (isset($input['tooltip_content_color'])) { $settings['tooltip_content_color'] = sanitize_text_field($input['tooltip_content_color']); }
    if (isset($input['tooltip_content_template'])) { $settings['tooltip_content_template'] = sanitize_text_field($input['tooltip_content_template']); }
    if (isset($input['icon_list'])) { $settings['icon_list'] = $input['icon_list']; }
    if (isset($input['icon_align'])) { $settings['icon_align'] = $input['icon_align']; }
    if (isset($input['read_more_toggle'])) { $settings['read_more_toggle'] = sanitize_text_field($input['read_more_toggle']); }
    if (isset($input['load_show_list_toggle'])) { $settings['load_show_list_toggle'] = sanitize_text_field($input['load_show_list_toggle']); }
    if (isset($input['read_show_option'])) { $settings['read_show_option'] = sanitize_text_field($input['read_show_option']); }
    if (isset($input['read_less_option'])) { $settings['read_less_option'] = sanitize_text_field($input['read_less_option']); }
    if (isset($input['read_toggle_direction'])) { $settings['read_toggle_direction'] = sanitize_text_field($input['read_toggle_direction']); }
    if (isset($input['hover_background_style'])) { $settings['hover_background_style'] = sanitize_text_field($input['hover_background_style']); }
    if (isset($input['sl_display_counter'])) { $settings['sl_display_counter'] = sanitize_text_field($input['sl_display_counter']); }
    if (isset($input['sl_display_counter_style'])) { $settings['sl_display_counter_style'] = sanitize_text_field($input['sl_display_counter_style']); }
    if (isset($input['layout'])) { $settings['layout'] = sanitize_text_field($input['layout']); }
    if (isset($input['tablet_layout'])) { $settings['tablet_layout'] = sanitize_text_field($input['tablet_layout']); }
    if (isset($input['mobile_layout'])) { $settings['mobile_layout'] = sanitize_text_field($input['mobile_layout']); }
    if (isset($input['stylishlist_padding'])) { $settings['stylishlist_padding'] = $input['stylishlist_padding']; }
    if (isset($input['icon_border_bottom_color'])) { $settings['icon_border_bottom_color'] = sanitize_text_field($input['icon_border_bottom_color']); }
    if (isset($input['space_between'])) { $settings['space_between'] = $input['space_between']; }
    if (isset($input['space_between_h_right'])) { $settings['space_between_h_right'] = $input['space_between_h_right']; }
    if (isset($input['space_between_h_bottom'])) { $settings['space_between_h_bottom'] = $input['space_between_h_bottom']; }
    if (isset($input['min_width_h_list'])) { $settings['min_width_h_list'] = $input['min_width_h_list']; }
    if (isset($input['stylishlist_br_n'])) { $settings['stylishlist_br_n'] = $input['stylishlist_br_n']; }
    if (isset($input['stylishlist_br_h'])) { $settings['stylishlist_br_h'] = $input['stylishlist_br_h']; }
    if (isset($input['icon_position'])) { $settings['icon_position'] = sanitize_text_field($input['icon_position']); }
    if (isset($input['icon_color'])) { $settings['icon_color'] = sanitize_text_field($input['icon_color']); }
    if (isset($input['icon_color_stroke'])) { $settings['icon_color_stroke'] = sanitize_text_field($input['icon_color_stroke']); }
    if (isset($input['icon_color_fill'])) { $settings['icon_color_fill'] = sanitize_text_field($input['icon_color_fill']); }
    if (isset($input['icon_color_hover'])) { $settings['icon_color_hover'] = sanitize_text_field($input['icon_color_hover']); }
    if (isset($input['icon_color_h_fill'])) { $settings['icon_color_h_fill'] = sanitize_text_field($input['icon_color_h_fill']); }
    if (isset($input['icon_color_h_stroke'])) { $settings['icon_color_h_stroke'] = sanitize_text_field($input['icon_color_h_stroke']); }
    if (isset($input['icon_size'])) { $settings['icon_size'] = $input['icon_size']; }
    if (isset($input['icon_indent'])) { $settings['icon_indent'] = $input['icon_indent']; }
    if (isset($input['vertical_center'])) { $settings['vertical_center'] = $input['vertical_center']; }
    if (isset($input['adv_icon_style'])) { $settings['adv_icon_style'] = sanitize_text_field($input['adv_icon_style']); }
    if (isset($input['icon_inner_width'])) { $settings['icon_inner_width'] = $input['icon_inner_width']; }
    if (isset($input['icon_adv_radius'])) { $settings['icon_adv_radius'] = $input['icon_adv_radius']; }
    if (isset($input['icon_border_hover'])) { $settings['icon_border_hover'] = sanitize_text_field($input['icon_border_hover']); }
    if (isset($input['icon_adv_hover_radius'])) { $settings['icon_adv_hover_radius'] = $input['icon_adv_hover_radius']; }
    if (isset($input['display_counter_padding'])) { $settings['display_counter_padding'] = $input['display_counter_padding']; }
    if (isset($input['display_counter_margin'])) { $settings['display_counter_margin'] = $input['display_counter_margin']; }
    if (isset($input['dc_box_size'])) { $settings['dc_box_size'] = $input['dc_box_size']; }
    if (isset($input['dc_align'])) { $settings['dc_align'] = sanitize_text_field($input['dc_align']); }
    if (isset($input['display_counter_color'])) { $settings['display_counter_color'] = sanitize_text_field($input['display_counter_color']); }
    if (isset($input['display_counter_radius'])) { $settings['display_counter_radius'] = $input['display_counter_radius']; }
    if (isset($input['display_counter_color_h'])) { $settings['display_counter_color_h'] = sanitize_text_field($input['display_counter_color_h']); }
    if (isset($input['display_counter_radius_h'])) { $settings['display_counter_radius_h'] = $input['display_counter_radius_h']; }
    if (isset($input['text_indent'])) { $settings['text_indent'] = $input['text_indent']; }
    if (isset($input['contant_height'])) { $settings['contant_height'] = $input['contant_height']; }
    if (isset($input['text_color'])) { $settings['text_color'] = sanitize_text_field($input['text_color']); }
    if (isset($input['text_color_hover'])) { $settings['text_color_hover'] = sanitize_text_field($input['text_color_hover']); }
    if (isset($input['read_more_align'])) { $settings['read_more_align'] = $input['read_more_align']; }
    if (isset($input['toggle_expand_text_color'])) { $settings['toggle_expand_text_color'] = sanitize_text_field($input['toggle_expand_text_color']); }
    if (isset($input['toggle_expand_text_hover'])) { $settings['toggle_expand_text_hover'] = sanitize_text_field($input['toggle_expand_text_hover']); }
    if (isset($input['top_toggle_indent'])) { $settings['top_toggle_indent'] = $input['top_toggle_indent']; }
    if (isset($input['hint_padding'])) { $settings['hint_padding'] = $input['hint_padding']; }
    if (isset($input['hint_left_space'])) { $settings['hint_left_space'] = $input['hint_left_space']; }
    if (isset($input['hint_left_width'])) { $settings['hint_left_width'] = $input['hint_left_width']; }
    if (isset($input['hint_right_width'])) { $settings['hint_right_width'] = $input['hint_right_width']; }
    if (isset($input['hint_top_space'])) { $settings['hint_top_space'] = $input['hint_top_space']; }
    if (isset($input['hint_align'])) { $settings['hint_align'] = $input['hint_align']; }
    if (isset($input['hint_bf'])) { $settings['hint_bf'] = sanitize_text_field($input['hint_bf']); }
    if (isset($input['hint_bf_blur'])) { $settings['hint_bf_blur'] = $input['hint_bf_blur']; }
    if (isset($input['hint_bf_grayscale'])) { $settings['hint_bf_grayscale'] = $input['hint_bf_grayscale']; }
    if (isset($input['hint_border_radius'])) { $settings['hint_border_radius'] = $input['hint_border_radius']; }
    if (isset($input['tooltip_bf'])) { $settings['tooltip_bf'] = sanitize_text_field($input['tooltip_bf']); }
    if (isset($input['tooltip_bf_blur'])) { $settings['tooltip_bf_blur'] = $input['tooltip_bf_blur']; }
    if (isset($input['tooltip_bf_grayscale'])) { $settings['tooltip_bf_grayscale'] = $input['tooltip_bf_grayscale']; }
    if (isset($input['hover_inverse_effect'])) { $settings['hover_inverse_effect'] = sanitize_text_field($input['hover_inverse_effect']); }
    if (isset($input['unhover_item_opacity'])) { $settings['unhover_item_opacity'] = $input['unhover_item_opacity']; }
    if (isset($input['hover_effect_area'])) { $settings['hover_effect_area'] = sanitize_text_field($input['hover_effect_area']); }
    if (isset($input['global_hover_item_id'])) { $settings['global_hover_item_id'] = sanitize_text_field($input['global_hover_item_id']); }
    if (isset($input['animation_effects'])) { $settings['animation_effects'] = sanitize_text_field($input['animation_effects']); }
    if (isset($input['animation_delay'])) { $settings['animation_delay'] = $input['animation_delay']; }
    if (isset($input['animated_column_list'])) { $settings['animated_column_list'] = sanitize_text_field($input['animated_column_list']); }
    if (isset($input['animation_stagger'])) { $settings['animation_stagger'] = $input['animation_stagger']; }
    if (isset($input['animation_duration_default'])) { $settings['animation_duration_default'] = sanitize_text_field($input['animation_duration_default']); }
    if (isset($input['animate_duration'])) { $settings['animate_duration'] = $input['animate_duration']; }
    if (isset($input['animation_out_effects'])) { $settings['animation_out_effects'] = sanitize_text_field($input['animation_out_effects']); }
    if (isset($input['animation_out_delay'])) { $settings['animation_out_delay'] = $input['animation_out_delay']; }
    if (isset($input['animation_out_duration_default'])) { $settings['animation_out_duration_default'] = sanitize_text_field($input['animation_out_duration_default']); }
    if (isset($input['animation_out_duration'])) { $settings['animation_out_duration'] = $input['animation_out_duration']; }

    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
