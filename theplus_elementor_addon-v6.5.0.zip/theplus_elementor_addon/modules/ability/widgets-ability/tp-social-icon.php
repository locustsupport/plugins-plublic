<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-social-icon', [
'label' => __('Social Icon', 'theplus'),
    'description' => __('Adds The Plus "Social Icon" widget (tp-social-icon) with multiple professional styles.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'         => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'       => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'        => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'styles' => ['type' => 'string', 'description' => 'Style', 'enum' => ['custom', 'style-1', 'style-10', 'style-11', 'style-12', 'style-13', 'style-14', 'style-15', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7', 'style-8', 'style-9']],
        'hover_animation' => ['type' => 'string', 'description' => 'Select Hover Style', 'enum' => ['hover-1', 'hover-2', 'styles']],
        'pt_plus_social_icons' => ['type' => 'string', 'description' => 'Social Network Select'],
        'custom_icons_opt' => ['type' => 'string', 'description' => 'Icon Options', 'enum' => ['custom-svg', 'icon', 'pt_plus_social_icons']],
        'pt_plus_social_icon_custom' => ['type' => 'string', 'description' => 'Icon'],
        'select_custom_svg' => ['type' => 'string', 'description' => 'Choose Icon'],
        'social_url' => ['type' => 'object', 'description' => 'Link'],
        'social_text' => ['type' => 'string', 'description' => 'Title'],
        'icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'icon_hover_color' => ['type' => 'string', 'description' => 'Icon Hover Color (Color Hex/RGBA)'],
        'svg_fill_color' => ['type' => 'string', 'description' => 'Fill (Color Hex/RGBA)'],
        'svg_stroke_color' => ['type' => 'string', 'description' => 'Stroke (Color Hex/RGBA)'],
        'bg_color' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'bg_hover_color' => ['type' => 'string', 'description' => 'Background Hover Color (Color Hex/RGBA)'],
        'border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'border_hover_color' => ['type' => 'string', 'description' => 'Border Hover Color (Color Hex/RGBA)'],
        'loop_magic_scroll' => ['type' => 'string', 'description' => 'Magic Scroll', 'enum' => ['yes', 'no']],
        'plus_tooltip' => ['type' => 'string', 'description' => 'Tooltip', 'enum' => ['yes', 'no']],
        'plus_tooltip_content_type' => ['type' => 'string', 'description' => 'Content Type', 'enum' => ['content_wysiwyg', 'normal_desc', 'plus_tooltip', 'render_type']],
        'plus_tooltip_content_desc' => ['type' => 'string', 'description' => 'Description'],
        'plus_tooltip_content_wysiwyg' => ['type' => 'string', 'description' => 'Tooltip Content'],
        'plus_tooltip_content_align' => ['type' => 'string', 'description' => 'Text Alignment', 'enum' => ['center', 'icon', 'left', 'plus_tooltip', 'plus_tooltip_content_type', 'right', '{{WRAPPER}} .tippy-tooltip .tippy-content']],
        'plus_tooltip_content_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'plus_mouse_move_parallax' => ['type' => 'string', 'description' => 'Mouse Move Parallax', 'enum' => ['yes', 'no']],
        'plus_continuous_animation' => ['type' => 'string', 'description' => 'Continuous Animation', 'enum' => ['yes', 'no']],
        'plus_animation_effect' => ['type' => 'string', 'description' => 'Animation Effect', 'enum' => ['floating', 'plus_continuous_animation', 'pulse', 'rotating', 'tossing']],
        'plus_animation_hover' => ['type' => 'string', 'description' => 'Hover Animation', 'enum' => ['yes', 'no']],
        'plus_animation_duration' => ['type' => 'object', 'description' => 'Duration Time (Slider/Size Object)'],
        'plus_transform_origin' => ['type' => 'string', 'description' => 'Transform Origin', 'enum' => ['bottom center', 'bottom left', 'bottom right', 'center center', 'center left', 'center right', 'plus_animation_effect', 'plus_continuous_animation', 'render_type', 'top left', 'top right', '{{WRAPPER}} {{CURRENT_ITEM}}']],
        'pt_plus_social_networks' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Social Network Select'],
        'social_align' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['icon', 'text-center', 'text-left', 'text-right']],
        'social_icon_verical' => ['type' => 'string', 'description' => 'Vertical Layout', 'enum' => ['yes', 'no']],
        'vl_max_width' => ['type' => 'object', 'description' => 'Max. Width (Slider/Size Object)'],
        'social_icon_gap_margin' => ['type' => 'object', 'description' => 'Icons Between Gap (Dimensions Object)'],
        'social_icon_gap_padding' => ['type' => 'object', 'description' => 'Icons Gap (Dimensions Object)'],
        'height_social' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'icon_size' => ['type' => 'object', 'description' => 'Icon Font Size (Slider/Size Object)'],
        'social_icon_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'social_icon_width' => ['type' => 'object', 'description' => 'Icon Width (Slider/Size Object)'],
        'social_icon_height' => ['type' => 'object', 'description' => 'Icon Height (Slider/Size Object)'],
        'social_icon_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'social_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['dashed', 'dotted', 'groove', 'none', 'social_icon_border', 'solid', 'styles', '{{WRAPPER}} .pt_plus_social_list.custom ul.social_list li a']],
        'social_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'social_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'social_border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports multi-state hover physics, dynamic brand palette extraction, and responsive geometric scaling.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_social_icon_ability',
    'permission_callback' => 'tpaep_mcp_theplus_social_icon_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_social_icon_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_social_icon_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-social-icon';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Social Icon widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }

    if (isset($input['styles'])) { $settings['styles'] = sanitize_text_field($input['styles']); }
    if (isset($input['hover_animation'])) { $settings['hover_animation'] = sanitize_text_field($input['hover_animation']); }
    if (isset($input['pt_plus_social_icons'])) { $settings['pt_plus_social_icons'] = sanitize_text_field($input['pt_plus_social_icons']); }
    if (isset($input['custom_icons_opt'])) { $settings['custom_icons_opt'] = sanitize_text_field($input['custom_icons_opt']); }
    if (isset($input['pt_plus_social_icon_custom'])) { $settings['pt_plus_social_icon_custom'] = sanitize_text_field($input['pt_plus_social_icon_custom']); }
    if (isset($input['select_custom_svg'])) { $settings['select_custom_svg'] = sanitize_text_field($input['select_custom_svg']); }
    if (isset($input['social_url'])) { $settings['social_url'] = $input['social_url']; }
    if (isset($input['social_text'])) { $settings['social_text'] = sanitize_text_field($input['social_text']); }
    if (isset($input['icon_color'])) { $settings['icon_color'] = sanitize_text_field($input['icon_color']); }
    if (isset($input['icon_hover_color'])) { $settings['icon_hover_color'] = sanitize_text_field($input['icon_hover_color']); }
    if (isset($input['svg_fill_color'])) { $settings['svg_fill_color'] = sanitize_text_field($input['svg_fill_color']); }
    if (isset($input['svg_stroke_color'])) { $settings['svg_stroke_color'] = sanitize_text_field($input['svg_stroke_color']); }
    if (isset($input['bg_color'])) { $settings['bg_color'] = sanitize_text_field($input['bg_color']); }
    if (isset($input['bg_hover_color'])) { $settings['bg_hover_color'] = sanitize_text_field($input['bg_hover_color']); }
    if (isset($input['border_color'])) { $settings['border_color'] = sanitize_text_field($input['border_color']); }
    if (isset($input['border_hover_color'])) { $settings['border_hover_color'] = sanitize_text_field($input['border_hover_color']); }
    if (isset($input['loop_magic_scroll'])) { $settings['loop_magic_scroll'] = sanitize_text_field($input['loop_magic_scroll']); }
    if (isset($input['plus_tooltip'])) { $settings['plus_tooltip'] = sanitize_text_field($input['plus_tooltip']); }
    if (isset($input['plus_tooltip_content_type'])) { $settings['plus_tooltip_content_type'] = sanitize_text_field($input['plus_tooltip_content_type']); }
    if (isset($input['plus_tooltip_content_desc'])) { $settings['plus_tooltip_content_desc'] = sanitize_text_field($input['plus_tooltip_content_desc']); }
    if (isset($input['plus_tooltip_content_wysiwyg'])) { $settings['plus_tooltip_content_wysiwyg'] = sanitize_text_field($input['plus_tooltip_content_wysiwyg']); }
    if (isset($input['plus_tooltip_content_align'])) { $settings['plus_tooltip_content_align'] = sanitize_text_field($input['plus_tooltip_content_align']); }
    if (isset($input['plus_tooltip_content_color'])) { $settings['plus_tooltip_content_color'] = sanitize_text_field($input['plus_tooltip_content_color']); }
    if (isset($input['plus_mouse_move_parallax'])) { $settings['plus_mouse_move_parallax'] = sanitize_text_field($input['plus_mouse_move_parallax']); }
    if (isset($input['plus_continuous_animation'])) { $settings['plus_continuous_animation'] = sanitize_text_field($input['plus_continuous_animation']); }
    if (isset($input['plus_animation_effect'])) { $settings['plus_animation_effect'] = sanitize_text_field($input['plus_animation_effect']); }
    if (isset($input['plus_animation_hover'])) { $settings['plus_animation_hover'] = sanitize_text_field($input['plus_animation_hover']); }
    if (isset($input['plus_animation_duration'])) { $settings['plus_animation_duration'] = $input['plus_animation_duration']; }
    if (isset($input['plus_transform_origin'])) { $settings['plus_transform_origin'] = sanitize_text_field($input['plus_transform_origin']); }
    if (isset($input['pt_plus_social_networks'])) { $settings['pt_plus_social_networks'] = $input['pt_plus_social_networks']; }
    if (isset($input['social_align'])) { $settings['social_align'] = $input['social_align']; }
    if (isset($input['social_icon_verical'])) { $settings['social_icon_verical'] = sanitize_text_field($input['social_icon_verical']); }
    if (isset($input['vl_max_width'])) { $settings['vl_max_width'] = $input['vl_max_width']; }
    if (isset($input['social_icon_gap_margin'])) { $settings['social_icon_gap_margin'] = $input['social_icon_gap_margin']; }
    if (isset($input['social_icon_gap_padding'])) { $settings['social_icon_gap_padding'] = $input['social_icon_gap_padding']; }
    if (isset($input['height_social'])) { $settings['height_social'] = $input['height_social']; }
    if (isset($input['icon_size'])) { $settings['icon_size'] = $input['icon_size']; }
    if (isset($input['social_icon_radius'])) { $settings['social_icon_radius'] = $input['social_icon_radius']; }
    if (isset($input['social_icon_width'])) { $settings['social_icon_width'] = $input['social_icon_width']; }
    if (isset($input['social_icon_height'])) { $settings['social_icon_height'] = $input['social_icon_height']; }
    if (isset($input['social_icon_border'])) { $settings['social_icon_border'] = sanitize_text_field($input['social_icon_border']); }
    if (isset($input['social_border_style'])) { $settings['social_border_style'] = sanitize_text_field($input['social_border_style']); }
    if (isset($input['social_border_width'])) { $settings['social_border_width'] = $input['social_border_width']; }
    if (isset($input['social_border_radius'])) { $settings['social_border_radius'] = $input['social_border_radius']; }
    if (isset($input['social_border_hover_radius'])) { $settings['social_border_hover_radius'] = $input['social_border_hover_radius']; }

    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
