<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-animated-service-boxes', [
'label' => __('Animated Service Boxes', 'theplus'),
    'description' => __('Adds The Plus "Animated Service Boxes" widget (tp-animated-service-boxes) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'          => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'        => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'         => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'main_style' => ['type' => 'string', 'description' => 'Main Style', 'enum' => ['article-box', 'fancy-box', 'hover-section', 'image-accordion', 'info-banner', 'portfolio', 'services-element', 'sliding-boxes']],
        'image_accordion_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['accordion-style-1', 'accordion-style-2', 'classes', 'columns', 'image', 'label_block', 'main_style', 'title']],
        'orientation_type' => ['type' => 'string', 'description' => 'Orientation', 'enum' => ['accordion-horizontal', 'accordion-vertical', 'main_style']],
        'sliding_boxes_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['main_style', 'sliding-style-1']],
        'article_box_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['article-box-style-1', 'article-box-style-2', 'classes', 'columns', 'image', 'label_block', 'main_style', 'title']],
        'active_slide' => ['type' => 'string', 'description' => 'Active Slide', 'enum' => ['main_style']],
        'image_accordion_flex_grow' => ['type' => 'string', 'description' => 'Active Slide Width(0-15)'],
        'info_banner_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['classes', 'columns', 'image', 'info-banner-style-1', 'info-banner-style-2', 'label_block', 'main_style', 'title']],
        'hover_orientation' => ['type' => 'string', 'description' => 'Hover Orientation', 'enum' => ['info-banner-bottom', 'info-banner-left', 'info-banner-right', 'info-banner-top', 'info_banner_style', 'main_style']],
        'hover_section_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['hover-section-style-1', 'main_style']],
        'hover_section_image_preload' => ['type' => 'string', 'description' => 'Image Preload', 'enum' => ['no', 'yes']],
        'fancy_box_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['fancy-box-style-1', 'main_style']],
        'services_element_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['classes', 'columns', 'image', 'label_block', 'main_style', 'services-element-style-1', 'services-element-style-2', 'title']],
        'portfolio_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['classes', 'columns', 'image', 'label_block', 'main_style', 'portfolio-style-1', 'portfolio-style-2', 'title']],
        'loop_display_button' => ['type' => 'string', 'description' => 'Button', 'enum' => ['no', 'yes']],
        'loop_button_style' => ['type' => 'string', 'description' => 'Button Style', 'enum' => ['loop_display_button', 'main_style!', 'style-7', 'style-8', 'style-9']],
        'loop_display_icon_image' => ['type' => 'string', 'description' => 'Image/Icon', 'enum' => ['no', 'yes']],
        'loop_title' => ['type' => 'string', 'description' => 'Title'],
        'loop_image_icon' => ['type' => 'string', 'description' => 'Select Icon', 'enum' => ['icon', 'image', 'lottie']],
        'lottieUrl' => ['type' => 'string', 'description' => 'Lottie URL'],
        'loop_select_image' => ['type' => 'integer', 'description' => 'Use Image As Icon'],
        'loop_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['font_awesome', 'font_awesome_5', 'icon_mind', 'loop_image_icon']],
        'font_awesome_toggle' => ['type' => 'string', 'description' => 'Font Awesome', 'enum' => ['no', 'yes']],
        'loop_icon_fontawesome' => ['type' => 'string', 'description' => 'Icon Library'],
        'font_awesome5_toggle' => ['type' => 'string', 'description' => 'Font Awesome 5', 'enum' => ['no', 'yes']],
        'loop_icon_fontawesome_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'icon_mind_toggle' => ['type' => 'string', 'description' => 'Icon Mind', 'enum' => ['no', 'yes']],
        'loop_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['label_block', 'loop_icon_style', 'loop_image_icon']],
        'loop_sub_title' => ['type' => 'string', 'description' => 'Sub Title'],
        'loop_content_desc' => ['type' => 'string', 'description' => 'Description'],
        'featured_image' => ['type' => 'integer', 'description' => 'Featured Image'],
        'loop_button_text' => ['type' => 'string', 'description' => 'Button Text'],
        'loop_button_link' => ['type' => 'string', 'description' => 'Button Link'],
        'loop_content_list' => ['type' => 'string', 'description' => 'List Content'],
        'loop_content' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Animated Service Boxes'],
        'transform_normal_css' => ['type' => 'string', 'description' => 'Transform CSS'],
        'transform_hover_css' => ['type' => 'string', 'description' => 'Transform CSS'],
        'text_align' => ['type' => 'object', 'description' => 'Text Alignment', 'enum' => ['center', 'conditions', 'icon', 'left', 'name', 'operator', 'relation', 'right', 'terms', 'title', 'toggle', 'value', '{{WRAPPER}} .pt_plus_asb_wrapper.image-accordion .asb-content,
					{{WRAPPER}} .pt_plus_asb_wrapper.info-banner.info-banner-style-1 .info-banner-content-wrapper,
					{{WRAPPER}} .pt_plus_asb_wrapper.info-banner-style-2 .info-front-content,{{WRAPPER}} .pt_plus_asb_wrapper.hover-section .asb_wrap_list.tp-row.hover-section-extra,
					{{WRAPPER}} .pt_plus_asb_wrapper.portfolio.portfolio-style-1 .asb_wrap_list']],
        'text_align_port' => ['type' => 'object', 'description' => 'Text Alignment', 'enum' => ['center', 'flex-end', 'flex-start', 'icon', 'portfolio_style', 'title', 'toggle', '{{WRAPPER}} .pt_plus_asb_wrapper.portfolio.portfolio-style-2 .portfolio-wrapper']],
        'align_offset' => ['type' => 'object', 'description' => 'Offset', 'enum' => ['center', 'conditions', 'flex-end', 'flex-start', 'icon', 'name', 'operator', 'relation', 'separator', 'space-between', 'terms', 'title', 'toggle', 'value', '{{WRAPPER}} .pt_plus_asb_wrapper.image-accordion .asb-content,{{WRAPPER}} .pt_plus_asb_wrapper.portfolio.portfolio-style-2 .portfolio-wrapper', '{{WRAPPER}} .pt_plus_asb_wrapper.info-banner-style-2 .info-front-content']],
        'align_offset_port1' => ['type' => 'string', 'description' => 'Offset', 'enum' => ['center', 'flex-end', 'flex-start', 'icon', 'main_style', 'portfolio_style', 'separator', 'title', 'toggle', '{{WRAPPER}} .pt_plus_asb_wrapper.portfolio.portfolio-style-1 .asb_wrap_list.tp-row']],
        'align_offset_slidingbox' => ['type' => 'object', 'description' => 'Offset', 'enum' => ['center', 'flex-start', 'icon', 'main_style', 'title', 'toggle', '{{WRAPPER}} .sliding-boxes .service-item-loop .asb-content']],
        'layout_height' => ['type' => 'object', 'description' => 'Height'],
        'port_mobile_text' => ['type' => 'string', 'description' => 'Title On Click Text'],
        'sb_tablet_column' => ['type' => 'string', 'description' => 'Tablet Column', 'enum' => ['sb_t_1', 'sb_t_2', 'sb_t_3']],
        'sb_mobile_column' => ['type' => 'string', 'description' => 'Mobile Column', 'enum' => ['sb_m_1', 'sb_m_2', 'sb_m_3']],
        'slide_columns_gap' => ['type' => 'object', 'description' => 'Columns Gap/Space Between'],
        'desktop_column' => ['type' => 'string', 'description' => 'Desktop Column'],
        'tablet_column' => ['type' => 'string', 'description' => 'Tablet Column'],
        'mobile_column' => ['type' => 'string', 'description' => 'Mobile Column'],
        'columns_gap' => ['type' => 'object', 'description' => 'Columns Gap/Space Between'],
        'title_color' => ['type' => 'string', 'description' => 'Color'],
        'title_stroke_color' => ['type' => 'string', 'description' => 'Stroke Color'],
        'title_stroke_size' => ['type' => 'object', 'description' => 'Stroke Size'],
        'title_hover_color' => ['type' => 'string', 'description' => 'Color'],
        'title_stroke_color_hover' => ['type' => 'string', 'description' => 'Stroke Color'],
        'title_stroke_size_hover' => ['type' => 'object', 'description' => 'Stroke Size'],
        'title_link_color' => ['type' => 'string', 'description' => 'Color'],
        'title_tag' => ['type' => 'string', 'description' => 'Tag', 'enum' => ['separator']],
        'sub_title_color' => ['type' => 'string', 'description' => 'Color'],
        'sub_title_tag' => ['type' => 'string', 'description' => 'Tag', 'enum' => ['separator']],
        'desc_color' => ['type' => 'string', 'description' => 'Color'],
        'icon_style' => ['type' => 'string', 'description' => 'Icon Styles', 'enum' => ['hexagon', 'pentagon', 'rounded', 'square', 'square-rotate']],
        'icon_size' => ['type' => 'object', 'description' => 'Icon/Image Size'],
        'icon_width' => ['type' => 'object', 'description' => 'Icon Width'],
        'icon_color_option' => ['type' => 'string', 'description' => 'Icon Color', 'enum' => ['gradient', 'icon', 'label_block', 'solid', 'title']],
        'icon_color' => ['type' => 'string', 'description' => 'Color'],
        'icon_gradient_color1' => ['type' => 'string', 'description' => 'Color 1'],
        'icon_gradient_color1_control' => ['type' => 'object', 'description' => 'Color 1 Location'],
        'icon_gradient_color2' => ['type' => 'string', 'description' => 'Color 2'],
        'icon_gradient_color2_control' => ['type' => 'object', 'description' => 'Color 2 Location'],
        'icon_gradient_style' => ['type' => 'string', 'description' => 'Gradient Style', 'enum' => ['icon_color_option', 'of_type']],
        'icon_gradient_angle' => ['type' => 'object', 'description' => 'Gradient Angle'],
        'icon_gradient_position' => ['type' => 'string', 'description' => 'Position', 'enum' => ['icon_color_option', 'icon_gradient_style', 'of_type', 'separator', '{{WRAPPER}} .pt_plus_asb_wrapper .asb-icon-image:before,{{WRAPPER}} .pt_plus_asb_wrapper .asb-icon-image i:before']],
        'icon_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'icon_border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'icon_border_width' => ['type' => 'object', 'description' => 'icon_border_width'],
        'icon_se_size' => ['type' => 'object', 'description' => 'Icon/Image Size'],
        'icon_se_bg_border_color' => ['type' => 'string', 'description' => 'Icon Inset Color'],
        'icon_se_normal_color' => ['type' => 'string', 'description' => 'Icon Color'],
        'icon_se_hover_color' => ['type' => 'string', 'description' => 'Icon Color'],
        'lottiedisplay' => ['type' => 'string', 'description' => 'Display', 'enum' => ['block', 'flex', 'inherit', 'initial', 'inline-block', 'inline-flex']],
        'lottieWidth' => ['type' => 'object', 'description' => 'Width'],
        'lottieHeight' => ['type' => 'object', 'description' => 'Height'],
        'lottieSpeed' => ['type' => 'object', 'description' => 'Speed'],
        'lottieLoop' => ['type' => 'string', 'description' => 'Loop Animation', 'enum' => ['no', 'yes']],
        'lottiehover' => ['type' => 'string', 'description' => 'Hover Animation', 'enum' => ['no', 'yes']],
        'content_se_margin_st1' => ['type' => 'object', 'description' => 'Margin Bottom'],
        'se_listing_text_color' => ['type' => 'string', 'description' => 'Text Color'],
        'se_listing_dot_color' => ['type' => 'string', 'description' => 'Dot Color'],
        'button_padding' => ['type' => 'object', 'description' => 'Padding'],
        'button_top_space' => ['type' => 'object', 'description' => 'Button Above Space'],
        'btn_text_color' => ['type' => 'string', 'description' => 'Text Color'],
        'button_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['dashed', 'dotted', 'groove', 'loop_button_style', 'none', 'solid', '{{WRAPPER}} .pt_plus_asb_wrapper .pt_plus_button.button-style-8 .button-link-wrap']],
        'button_border_width' => ['type' => 'object', 'description' => 'Border Width'],
        'button_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'button_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'btn_text_hover_color' => ['type' => 'string', 'description' => 'Text Color'],
        'button_border_hover_color' => ['type' => 'string', 'description' => 'Border Color'],
        'button_hover_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'feature_image_margin' => ['type' => 'object', 'description' => 'Margin'],
        'feature_image_padding' => ['type' => 'object', 'description' => 'Padding'],
        'featured_img_height_width' => ['type' => 'object', 'description' => 'Size'],
        'feature_image_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'content_padding' => ['type' => 'object', 'description' => 'Padding'],
        'content_se_padding' => ['type' => 'object', 'description' => 'Padding'],
        'content_margin' => ['type' => 'object', 'description' => 'Margin'],
        'content_article_box_margin' => ['type' => 'object', 'description' => 'Margin'],
        'hover_sec_bg_overlay' => ['type' => 'string', 'description' => 'Background Overlay'],
        'hover_sec_bg_overlay_opacity' => ['type' => 'string', 'description' => 'Opacity (0-100)'],
        'content_button_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'fb_hover_overlay_color_n' => ['type' => 'string', 'description' => 'Normal Overlay Color'],
        'fb_hover_overlay_color_h' => ['type' => 'string', 'description' => 'Hover Overlay Color'],
        'fb_hover_underline_color' => ['type' => 'string', 'description' => 'Bottom Line Color'],
        'fb_hover_underline_height' => ['type' => 'object', 'description' => 'Bottom Line Height'],
        'content_service_border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'content_service_hover_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'overlay_color_bg' => ['type' => 'string', 'description' => 'Overlay Color'],
        'oc_br' => ['type' => 'object', 'description' => 'Border Radius'],
        'settings'         => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_animated_service_boxes_ability',
    'permission_callback' => 'tpaep_mcp_theplus_animated_service_boxes_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_animated_service_boxes_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_animated_service_boxes_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-animated-service-boxes';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Animated Service Boxes widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['main_style'])) { $settings['main_style'] = sanitize_text_field($input['main_style']); }
    if (isset($input['image_accordion_style'])) { $settings['image_accordion_style'] = sanitize_text_field($input['image_accordion_style']); }
    if (isset($input['orientation_type'])) { $settings['orientation_type'] = sanitize_text_field($input['orientation_type']); }
    if (isset($input['sliding_boxes_style'])) { $settings['sliding_boxes_style'] = sanitize_text_field($input['sliding_boxes_style']); }
    if (isset($input['article_box_style'])) { $settings['article_box_style'] = sanitize_text_field($input['article_box_style']); }
    if (isset($input['active_slide'])) { $settings['active_slide'] = sanitize_text_field($input['active_slide']); }
    if (isset($input['image_accordion_flex_grow'])) { $settings['image_accordion_flex_grow'] = sanitize_text_field($input['image_accordion_flex_grow']); }
    if (isset($input['info_banner_style'])) { $settings['info_banner_style'] = sanitize_text_field($input['info_banner_style']); }
    if (isset($input['hover_orientation'])) { $settings['hover_orientation'] = sanitize_text_field($input['hover_orientation']); }
    if (isset($input['hover_section_style'])) { $settings['hover_section_style'] = sanitize_text_field($input['hover_section_style']); }
    if (isset($input['hover_section_image_preload'])) { $settings['hover_section_image_preload'] = sanitize_text_field($input['hover_section_image_preload']); }
    if (isset($input['fancy_box_style'])) { $settings['fancy_box_style'] = sanitize_text_field($input['fancy_box_style']); }
    if (isset($input['services_element_style'])) { $settings['services_element_style'] = sanitize_text_field($input['services_element_style']); }
    if (isset($input['portfolio_style'])) { $settings['portfolio_style'] = sanitize_text_field($input['portfolio_style']); }
    if (isset($input['loop_display_button'])) { $settings['loop_display_button'] = sanitize_text_field($input['loop_display_button']); }
    if (isset($input['loop_button_style'])) { $settings['loop_button_style'] = sanitize_text_field($input['loop_button_style']); }
    if (isset($input['loop_display_icon_image'])) { $settings['loop_display_icon_image'] = sanitize_text_field($input['loop_display_icon_image']); }
    if (isset($input['loop_title'])) { $settings['loop_title'] = sanitize_text_field($input['loop_title']); }
    if (isset($input['loop_image_icon'])) { $settings['loop_image_icon'] = sanitize_text_field($input['loop_image_icon']); }
    if (!empty($input['lottieUrl'])) { $settings['lottieUrl'] = ['url' => esc_url_raw($input['lottieUrl'])]; }
    if (!empty($input['loop_select_image'])) { $settings['loop_select_image'] = ['id' => absint($input['loop_select_image'])]; }
    if (isset($input['loop_icon_style'])) { $settings['loop_icon_style'] = sanitize_text_field($input['loop_icon_style']); }
    if (isset($input['font_awesome_toggle'])) { $settings['font_awesome_toggle'] = sanitize_text_field($input['font_awesome_toggle']); }
    if (isset($input['loop_icon_fontawesome'])) { $settings['loop_icon_fontawesome'] = sanitize_text_field($input['loop_icon_fontawesome']); }
    if (isset($input['font_awesome5_toggle'])) { $settings['font_awesome5_toggle'] = sanitize_text_field($input['font_awesome5_toggle']); }
    if (isset($input['loop_icon_fontawesome_5'])) { $settings['loop_icon_fontawesome_5'] = sanitize_text_field($input['loop_icon_fontawesome_5']); }
    if (isset($input['icon_mind_toggle'])) { $settings['icon_mind_toggle'] = sanitize_text_field($input['icon_mind_toggle']); }
    if (isset($input['loop_icons_mind'])) { $settings['loop_icons_mind'] = sanitize_text_field($input['loop_icons_mind']); }
    if (isset($input['loop_sub_title'])) { $settings['loop_sub_title'] = sanitize_text_field($input['loop_sub_title']); }
    if (isset($input['loop_content_desc'])) { $settings['loop_content_desc'] = sanitize_text_field($input['loop_content_desc']); }
    if (!empty($input['featured_image'])) { $settings['featured_image'] = ['id' => absint($input['featured_image'])]; }
    if (isset($input['loop_button_text'])) { $settings['loop_button_text'] = sanitize_text_field($input['loop_button_text']); }
    if (!empty($input['loop_button_link'])) { $settings['loop_button_link'] = ['url' => esc_url_raw($input['loop_button_link'])]; }
    if (isset($input['loop_content_list'])) { $settings['loop_content_list'] = sanitize_text_field($input['loop_content_list']); }
    if (isset($input['loop_content'])) { $settings['loop_content'] = $input['loop_content']; }
    if (isset($input['transform_normal_css'])) { $settings['transform_normal_css'] = sanitize_text_field($input['transform_normal_css']); }
    if (isset($input['transform_hover_css'])) { $settings['transform_hover_css'] = sanitize_text_field($input['transform_hover_css']); }
    if (isset($input['text_align'])) { $settings['text_align'] = $input['text_align']; }
    if (isset($input['text_align_port'])) { $settings['text_align_port'] = $input['text_align_port']; }
    if (isset($input['align_offset'])) { $settings['align_offset'] = $input['align_offset']; }
    if (isset($input['align_offset_port1'])) { $settings['align_offset_port1'] = sanitize_text_field($input['align_offset_port1']); }
    if (isset($input['align_offset_slidingbox'])) { $settings['align_offset_slidingbox'] = $input['align_offset_slidingbox']; }
    if (isset($input['layout_height'])) { $settings['layout_height'] = $input['layout_height']; }
    if (isset($input['port_mobile_text'])) { $settings['port_mobile_text'] = sanitize_text_field($input['port_mobile_text']); }
    if (isset($input['sb_tablet_column'])) { $settings['sb_tablet_column'] = sanitize_text_field($input['sb_tablet_column']); }
    if (isset($input['sb_mobile_column'])) { $settings['sb_mobile_column'] = sanitize_text_field($input['sb_mobile_column']); }
    if (isset($input['slide_columns_gap'])) { $settings['slide_columns_gap'] = $input['slide_columns_gap']; }
    if (isset($input['desktop_column'])) { $settings['desktop_column'] = sanitize_text_field($input['desktop_column']); }
    if (isset($input['tablet_column'])) { $settings['tablet_column'] = sanitize_text_field($input['tablet_column']); }
    if (isset($input['mobile_column'])) { $settings['mobile_column'] = sanitize_text_field($input['mobile_column']); }
    if (isset($input['columns_gap'])) { $settings['columns_gap'] = $input['columns_gap']; }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['title_stroke_color'])) { $settings['title_stroke_color'] = sanitize_text_field($input['title_stroke_color']); }
    if (isset($input['title_stroke_size'])) { $settings['title_stroke_size'] = $input['title_stroke_size']; }
    if (isset($input['title_hover_color'])) { $settings['title_hover_color'] = sanitize_text_field($input['title_hover_color']); }
    if (isset($input['title_stroke_color_hover'])) { $settings['title_stroke_color_hover'] = sanitize_text_field($input['title_stroke_color_hover']); }
    if (isset($input['title_stroke_size_hover'])) { $settings['title_stroke_size_hover'] = $input['title_stroke_size_hover']; }
    if (isset($input['title_link_color'])) { $settings['title_link_color'] = sanitize_text_field($input['title_link_color']); }
    if (isset($input['title_tag'])) { $settings['title_tag'] = sanitize_text_field($input['title_tag']); }
    if (isset($input['sub_title_color'])) { $settings['sub_title_color'] = sanitize_text_field($input['sub_title_color']); }
    if (isset($input['sub_title_tag'])) { $settings['sub_title_tag'] = sanitize_text_field($input['sub_title_tag']); }
    if (isset($input['desc_color'])) { $settings['desc_color'] = sanitize_text_field($input['desc_color']); }
    if (isset($input['icon_style'])) { $settings['icon_style'] = sanitize_text_field($input['icon_style']); }
    if (isset($input['icon_size'])) { $settings['icon_size'] = $input['icon_size']; }
    if (isset($input['icon_width'])) { $settings['icon_width'] = $input['icon_width']; }
    if (isset($input['icon_color_option'])) { $settings['icon_color_option'] = sanitize_text_field($input['icon_color_option']); }
    if (isset($input['icon_color'])) { $settings['icon_color'] = sanitize_text_field($input['icon_color']); }
    if (isset($input['icon_gradient_color1'])) { $settings['icon_gradient_color1'] = sanitize_text_field($input['icon_gradient_color1']); }
    if (isset($input['icon_gradient_color1_control'])) { $settings['icon_gradient_color1_control'] = $input['icon_gradient_color1_control']; }
    if (isset($input['icon_gradient_color2'])) { $settings['icon_gradient_color2'] = sanitize_text_field($input['icon_gradient_color2']); }
    if (isset($input['icon_gradient_color2_control'])) { $settings['icon_gradient_color2_control'] = $input['icon_gradient_color2_control']; }
    if (isset($input['icon_gradient_style'])) { $settings['icon_gradient_style'] = sanitize_text_field($input['icon_gradient_style']); }
    if (isset($input['icon_gradient_angle'])) { $settings['icon_gradient_angle'] = $input['icon_gradient_angle']; }
    if (isset($input['icon_gradient_position'])) { $settings['icon_gradient_position'] = sanitize_text_field($input['icon_gradient_position']); }
    if (isset($input['icon_border_color'])) { $settings['icon_border_color'] = sanitize_text_field($input['icon_border_color']); }
    if (isset($input['icon_border_radius'])) { $settings['icon_border_radius'] = $input['icon_border_radius']; }
    if (isset($input['icon_border_width'])) { $settings['icon_border_width'] = $input['icon_border_width']; }
    if (isset($input['icon_se_size'])) { $settings['icon_se_size'] = $input['icon_se_size']; }
    if (isset($input['icon_se_bg_border_color'])) { $settings['icon_se_bg_border_color'] = sanitize_text_field($input['icon_se_bg_border_color']); }
    if (isset($input['icon_se_normal_color'])) { $settings['icon_se_normal_color'] = sanitize_text_field($input['icon_se_normal_color']); }
    if (isset($input['icon_se_hover_color'])) { $settings['icon_se_hover_color'] = sanitize_text_field($input['icon_se_hover_color']); }
    if (isset($input['lottiedisplay'])) { $settings['lottiedisplay'] = sanitize_text_field($input['lottiedisplay']); }
    if (isset($input['lottieWidth'])) { $settings['lottieWidth'] = $input['lottieWidth']; }
    if (isset($input['lottieHeight'])) { $settings['lottieHeight'] = $input['lottieHeight']; }
    if (isset($input['lottieSpeed'])) { $settings['lottieSpeed'] = $input['lottieSpeed']; }
    if (isset($input['lottieLoop'])) { $settings['lottieLoop'] = sanitize_text_field($input['lottieLoop']); }
    if (isset($input['lottiehover'])) { $settings['lottiehover'] = sanitize_text_field($input['lottiehover']); }
    if (isset($input['content_se_margin_st1'])) { $settings['content_se_margin_st1'] = $input['content_se_margin_st1']; }
    if (isset($input['se_listing_text_color'])) { $settings['se_listing_text_color'] = sanitize_text_field($input['se_listing_text_color']); }
    if (isset($input['se_listing_dot_color'])) { $settings['se_listing_dot_color'] = sanitize_text_field($input['se_listing_dot_color']); }
    if (isset($input['button_padding'])) { $settings['button_padding'] = $input['button_padding']; }
    if (isset($input['button_top_space'])) { $settings['button_top_space'] = $input['button_top_space']; }
    if (isset($input['btn_text_color'])) { $settings['btn_text_color'] = sanitize_text_field($input['btn_text_color']); }
    if (isset($input['button_border_style'])) { $settings['button_border_style'] = sanitize_text_field($input['button_border_style']); }
    if (isset($input['button_border_width'])) { $settings['button_border_width'] = $input['button_border_width']; }
    if (isset($input['button_border_color'])) { $settings['button_border_color'] = sanitize_text_field($input['button_border_color']); }
    if (isset($input['button_radius'])) { $settings['button_radius'] = $input['button_radius']; }
    if (isset($input['btn_text_hover_color'])) { $settings['btn_text_hover_color'] = sanitize_text_field($input['btn_text_hover_color']); }
    if (isset($input['button_border_hover_color'])) { $settings['button_border_hover_color'] = sanitize_text_field($input['button_border_hover_color']); }
    if (isset($input['button_hover_radius'])) { $settings['button_hover_radius'] = $input['button_hover_radius']; }
    if (isset($input['feature_image_margin'])) { $settings['feature_image_margin'] = $input['feature_image_margin']; }
    if (isset($input['feature_image_padding'])) { $settings['feature_image_padding'] = $input['feature_image_padding']; }
    if (isset($input['featured_img_height_width'])) { $settings['featured_img_height_width'] = $input['featured_img_height_width']; }
    if (isset($input['feature_image_radius'])) { $settings['feature_image_radius'] = $input['feature_image_radius']; }
    if (isset($input['content_padding'])) { $settings['content_padding'] = $input['content_padding']; }
    if (isset($input['content_se_padding'])) { $settings['content_se_padding'] = $input['content_se_padding']; }
    if (isset($input['content_margin'])) { $settings['content_margin'] = $input['content_margin']; }
    if (isset($input['content_article_box_margin'])) { $settings['content_article_box_margin'] = $input['content_article_box_margin']; }
    if (isset($input['hover_sec_bg_overlay'])) { $settings['hover_sec_bg_overlay'] = sanitize_text_field($input['hover_sec_bg_overlay']); }
    if (isset($input['hover_sec_bg_overlay_opacity'])) { $settings['hover_sec_bg_overlay_opacity'] = sanitize_text_field($input['hover_sec_bg_overlay_opacity']); }
    if (isset($input['content_button_radius'])) { $settings['content_button_radius'] = $input['content_button_radius']; }
    if (isset($input['fb_hover_overlay_color_n'])) { $settings['fb_hover_overlay_color_n'] = sanitize_text_field($input['fb_hover_overlay_color_n']); }
    if (isset($input['fb_hover_overlay_color_h'])) { $settings['fb_hover_overlay_color_h'] = sanitize_text_field($input['fb_hover_overlay_color_h']); }
    if (isset($input['fb_hover_underline_color'])) { $settings['fb_hover_underline_color'] = sanitize_text_field($input['fb_hover_underline_color']); }
    if (isset($input['fb_hover_underline_height'])) { $settings['fb_hover_underline_height'] = $input['fb_hover_underline_height']; }
    if (isset($input['content_service_border_radius'])) { $settings['content_service_border_radius'] = $input['content_service_border_radius']; }
    if (isset($input['content_service_hover_border_color'])) { $settings['content_service_hover_border_color'] = sanitize_text_field($input['content_service_hover_border_color']); }
    if (isset($input['overlay_color_bg'])) { $settings['overlay_color_bg'] = sanitize_text_field($input['overlay_color_bg']); }
    if (isset($input['oc_br'])) { $settings['oc_br'] = $input['oc_br']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
