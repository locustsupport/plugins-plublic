<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-page-scroll', [
'label' => __('Page Scroll', 'theplus'),
    'description' => __('Adds The Plus "Page Scroll" widget (tp-page-scroll) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'page_scroll_opt' => ['type' => 'string', 'description' => 'Option', 'enum' => ['tp_full_page', 'tp_horizontal_scroll', 'tp_multi_scroll', 'tp_page_pilling']],
        'fp_content_template' => ['type' => 'string', 'description' => 'Elementor Templates'],
        'fp-slideid' => ['type' => 'string', 'description' => 'Slide ID'],
        'fp_content' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'fp_content'],
        'hslide_template' => ['type' => 'string', 'description' => 'Elementor Templates'],
        'hslide_id' => ['type' => 'string', 'description' => 'Slide/Anchor ID'],
        'hslide_width' => ['type' => 'object', 'description' => 'Slide Width (Slider/Size Object)'],
        'hslide_align' => ['type' => 'string', 'description' => 'Slide Align'],
        'hslide_padding' => ['type' => 'object', 'description' => 'Slide Padding (Dimensions Object)'],
        'hslide_margin' => ['type' => 'object', 'description' => 'Slide Margin (Dimensions Object)'],
        'scroll_bg_color' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'scroll_bg_image' => ['type' => 'integer', 'description' => 'scroll_bg_image (Image ID)'],
        'hscroll_content' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'hscroll_content'],
        'hscroll_bg' => ['type' => 'string', 'description' => 'Horizontal Scroll Background', 'enum' => ['yes', 'no']],
        'hscroll_page_full' => ['type' => 'string', 'description' => 'Position', 'enum' => ['hscroll_bg', 'inherit', 'relative']],
        'hscroll_bg_duration' => ['type' => 'object', 'description' => 'Background Transition Duration (Slider/Size Object)'],
        'hscroll_speed' => ['type' => 'object', 'description' => 'Horizontal Scroll Speed (Slider/Size Object)'],
        'hscroll_sec_id_transition' => ['type' => 'object', 'description' => 'Section Id/Anchor Transition Duration (ms) (Slider/Size Object)'],
        'hscroll_draggable' => ['type' => 'string', 'description' => 'Mouse Draggable Scrollbar', 'enum' => ['yes', 'no']],
        'hscroll_scrollbar' => ['type' => 'string', 'description' => 'Scrollbar Rail', 'enum' => ['yes', 'no']],
        'hscroll_footer' => ['type' => 'string', 'description' => 'Horizontal Scroll Footer', 'enum' => ['yes', 'no']],
        'hscroll_footer_height' => ['type' => 'object', 'description' => 'Footer Height (Slider/Size Object)'],
        'hscroll_responsive' => ['type' => 'string', 'description' => 'Horizontal Scroll Responsive', 'enum' => ['yes', 'no']],
        'hscroll_res_minwidth' => ['type' => 'object', 'description' => 'Min Width (Slider/Size Object)'],
        'fp-slideid' => ['type' => 'string', 'description' => 'Slide ID'],
        'multi_left_template' => ['type' => 'string', 'description' => 'Left Template'],
        'multi_right_template' => ['type' => 'string', 'description' => 'Right Template'],
        'multi_left_right_repeater' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Sections'],
        'show_dots' => ['type' => 'string', 'description' => 'Dots'],
        'nav_postion' => ['type' => 'string', 'description' => 'Dots Positions', 'enum' => ['left', 'page_scroll_opt!', 'right', 'show_dots']],
        'nav_dots_tooltips' => ['type' => 'string', 'description' => 'Dots Tooltips Text'],
        'multi_navigation_dots' => ['type' => 'string', 'description' => 'Navigation Dots', 'enum' => ['yes', 'no']],
        'multi_navigation_dots_pos' => ['type' => 'string', 'description' => 'Dots Horizontal Position', 'enum' => ['left', 'multi_navigation_dots', 'page_scroll_opt', 'right']],
        'multi_navigation_verti_dots_pos' => ['type' => 'string', 'description' => 'Dots Vertical Position', 'enum' => ['bottom', 'middle', 'multi_navigation_dots', 'page_scroll_opt', 'top']],
        'multi_dots_tooltips' => ['type' => 'string', 'description' => 'Dots Tooltip\\'],
        'scroll_nav_connection' => ['type' => 'string', 'description' => 'Scroll Navigation Connection', 'enum' => ['yes', 'no']],
        'scrollnav_connect_id' => ['type' => 'string', 'description' => 'Scroll Navigation Connect ID'],
        'show_next_prev' => ['type' => 'string', 'description' => 'Next Previous Button'],
        'next_prev_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['custom', 'show_next_prev', 'style-1', 'style-2', 'style-3']],
        'nav_prev_image' => ['type' => 'string', 'description' => 'Previous Icon'],
        'nav_next_image' => ['type' => 'string', 'description' => 'Next Icon'],
        'np_gap' => ['type' => 'object', 'description' => 'Gap (Slider/Size Object)'],
        'next_prev_direction' => ['type' => 'string', 'description' => 'Direction', 'enum' => ['horizontal', 'show_next_prev', 'vertical']],
        'fp_nav_position' => ['type' => 'string', 'description' => 'Position', 'enum' => ['bottom-center', 'bottom-left', 'bottom-right', 'left-center', 'left-top', 'right-center', 'right-top', 'show_next_prev']],
        'fp_offset_left' => ['type' => 'object', 'description' => 'Offset Left (Slider/Size Object)'],
        'fp_offset_right' => ['type' => 'object', 'description' => 'Offset Right (Slider/Size Object)'],
        'fp_offset_bottom' => ['type' => 'object', 'description' => 'Offset Bottom (Slider/Size Object)'],
        'fp_offset_top' => ['type' => 'object', 'description' => 'Offset Top (Slider/Size Object)'],
        'next_size' => ['type' => 'string', 'description' => 'Next Icon Size', 'enum' => ['large', 'medium', 'next_prev_style!', 'show_next_prev', 'small']],
        'prev_size' => ['type' => 'string', 'description' => 'Prev Icon Size', 'enum' => ['large', 'medium', 'next_prev_style!', 'show_next_prev', 'small']],
        'nxt_txt' => ['type' => 'string', 'description' => 'Next Button Text'],
        'prev_txt' => ['type' => 'string', 'description' => 'Previous Button Text'],
        'show_paginate' => ['type' => 'string', 'description' => 'Show Paginate', 'enum' => ['yes', 'no']],
        'paginate_style' => ['type' => 'string', 'description' => 'Pagination Styles', 'enum' => ['bounceIn', 'fadeIn', 'fadeInDown', 'fadeInUp', 'flipInX', 'flipInY', 'rollIn', 'rotateInDownRight', 'rotateInUpRight', 'show_paginate', 'zoomIn']],
        'paginate_position' => ['type' => 'string', 'description' => 'Pagination Position', 'enum' => ['bottom-center', 'bottom-left', 'bottom-right', 'left-center', 'left-top', 'right-center', 'right-top', 'show_paginate']],
        'paginate_offset_left' => ['type' => 'object', 'description' => 'Offset Left (Slider/Size Object)'],
        'paginate_offset_right' => ['type' => 'object', 'description' => 'Offset Right (Slider/Size Object)'],
        'paginate_offset_bottom' => ['type' => 'object', 'description' => 'Offset Bottom (Slider/Size Object)'],
        'paginate_offset_top' => ['type' => 'object', 'description' => 'Offset Top (Slider/Size Object)'],
        'tp_show_header_footer_note' => ['type' => 'string', 'description' => 'Footer template count in Paginate.'],
        'tp_show_footer' => ['type' => 'string', 'description' => 'Footer', 'enum' => ['yes', 'no']],
        'tp_direction' => ['type' => 'string', 'description' => 'Direction', 'enum' => ['horizontal', 'page_scroll_opt!', 'vertical']],
        'tp_fp_hide_hash_id' => ['type' => 'string', 'description' => 'Hide Hash/id in URL', 'enum' => ['yes', 'no']],
        'tp_keyboard_scrolling' => ['type' => 'string', 'description' => 'Keyboard Scrolling', 'enum' => ['yes', 'no']],
        'tp_reset_scrolling' => ['type' => 'string', 'description' => 'Reset Scroll Top', 'enum' => ['yes', 'no']],
        'tp_overflow_scrolling' => ['type' => 'string', 'description' => 'Content Overflow Scroll', 'enum' => ['yes', 'no']],
        'tp_scrolling_speed' => ['type' => 'string', 'description' => 'Scrolling Speed'],
        'tp_loop_bottom' => ['type' => 'string', 'description' => 'Loop Bottom', 'enum' => ['yes', 'no']],
        'tp_loop_top' => ['type' => 'string', 'description' => 'Loop Top', 'enum' => ['yes', 'no']],
        'tp_tablet_off' => ['type' => 'string', 'description' => 'Page Pilling in Tablet', 'enum' => ['yes', 'no']],
        'tp_mobile_off' => ['type' => 'string', 'description' => 'Page Pilling in Mobile', 'enum' => ['yes', 'no']],
        'tp_continuous_vertical' => ['type' => 'string', 'description' => 'Continuous Vertical', 'enum' => ['yes', 'no']],
        'tp_responsive_width' => ['type' => 'string', 'description' => 'Responsive Width', 'enum' => ['yes', 'no']],
        'res_width_value' => ['type' => 'string', 'description' => 'Responsive Width'],
        'multi_left_width' => ['type' => 'object', 'description' => 'Left Section Width (Slider/Size Object)'],
        'multi_right_width' => ['type' => 'object', 'description' => 'Right Section Width (Slider/Size Object)'],
        'multi_keyboard_scrolling' => ['type' => 'string', 'description' => 'Keyboard Scrolling', 'enum' => ['yes', 'no']],
        'multi_loop_top' => ['type' => 'string', 'description' => 'Loop Top', 'enum' => ['yes', 'no']],
        'multi_loop_bottom' => ['type' => 'string', 'description' => 'Loop Bottom', 'enum' => ['yes', 'no']],
        'multi_scrolling_speed' => ['type' => 'string', 'description' => 'Scroll Speed'],
        'multi_scroll_responsive_tabs' => ['type' => 'string', 'description' => 'Disable on Tablet', 'enum' => ['yes', 'no']],
        'multi_scroll_responsive_mobile' => ['type' => 'string', 'description' => 'Disable on Mobiles', 'enum' => ['yes', 'no']],
        'dots_color_n' => ['type' => 'string', 'description' => 'Dots Color (Color Hex/RGBA)'],
        'dots_color_h' => ['type' => 'string', 'description' => 'Dots Color (Color Hex/RGBA)'],
        'dots_tt_head' => ['type' => 'string', 'description' => 'Tooltip Text Option'],
        'dots_text_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'dots_text_color_n' => ['type' => 'string', 'description' => 'Tooltip Color (Color Hex/RGBA)'],
        'dots_text_bg_color_n' => ['type' => 'string', 'description' => 'Tooltip Background (Color Hex/RGBA)'],
        'dots_tt_border' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'np_icon_color_n' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'np_st3_n_color_n' => ['type' => 'string', 'description' => 'Next Color (Color Hex/RGBA)'],
        'np_st3_p_color_n' => ['type' => 'string', 'description' => 'Previous Color (Color Hex/RGBA)'],
        'np_icon_bg_n' => ['type' => 'string', 'description' => 'Background (Color Hex/RGBA)'],
        'np_icon_n_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'np_icon_color_h' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'np_st3_n_color_h' => ['type' => 'string', 'description' => 'Next Color (Color Hex/RGBA)'],
        'np_st3_p_color_h' => ['type' => 'string', 'description' => 'Previous Color (Color Hex/RGBA)'],
        'np_icon_bg_h' => ['type' => 'string', 'description' => 'Background (Color Hex/RGBA)'],
        'fp_nxt_btn' => ['type' => 'object', 'description' => 'Next Button Size (Slider/Size Object)'],
        'fp_prev_btn' => ['type' => 'object', 'description' => 'Preview Button Size (Slider/Size Object)'],
        'paginate_color' => ['type' => 'string', 'description' => 'Current Paginate Color (Color Hex/RGBA)'],
        'paginate_last_color' => ['type' => 'string', 'description' => 'Total Paginate Color (Color Hex/RGBA)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports snapping physics, full-page navigation, and multi-scroll synchronized panels.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_pro_page_scroll_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pro_page_scroll_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_pro_page_scroll_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_pro_page_scroll_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-page-scroll';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Page Scroll widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['page_scroll_opt'])) { $settings['page_scroll_opt'] = sanitize_text_field($input['page_scroll_opt']); }
    if (isset($input['fp_content_template'])) { $settings['fp_content_template'] = sanitize_text_field($input['fp_content_template']); }
    if (isset($input['fp-slideid'])) { $settings['fp-slideid'] = sanitize_text_field($input['fp-slideid']); }
    if (isset($input['fp_content'])) { $settings['fp_content'] = $input['fp_content']; }
    if (isset($input['hslide_template'])) { $settings['hslide_template'] = sanitize_text_field($input['hslide_template']); }
    if (isset($input['hslide_id'])) { $settings['hslide_id'] = sanitize_text_field($input['hslide_id']); }
    if (isset($input['hslide_width'])) { $settings['hslide_width'] = $input['hslide_width']; }
    if (isset($input['hslide_align'])) { $settings['hslide_align'] = sanitize_text_field($input['hslide_align']); }
    if (isset($input['hslide_padding'])) { $settings['hslide_padding'] = $input['hslide_padding']; }
    if (isset($input['hslide_margin'])) { $settings['hslide_margin'] = $input['hslide_margin']; }
    if (isset($input['scroll_bg_color'])) { $settings['scroll_bg_color'] = sanitize_text_field($input['scroll_bg_color']); }
    if (!empty($input['scroll_bg_image'])) { $settings['scroll_bg_image'] = ['id' => absint($input['scroll_bg_image'])]; }
    if (isset($input['hscroll_content'])) { $settings['hscroll_content'] = $input['hscroll_content']; }
    if (isset($input['hscroll_bg'])) { $settings['hscroll_bg'] = sanitize_text_field($input['hscroll_bg']); }
    if (isset($input['hscroll_page_full'])) { $settings['hscroll_page_full'] = sanitize_text_field($input['hscroll_page_full']); }
    if (isset($input['hscroll_bg_duration'])) { $settings['hscroll_bg_duration'] = $input['hscroll_bg_duration']; }
    if (isset($input['hscroll_speed'])) { $settings['hscroll_speed'] = $input['hscroll_speed']; }
    if (isset($input['hscroll_sec_id_transition'])) { $settings['hscroll_sec_id_transition'] = $input['hscroll_sec_id_transition']; }
    if (isset($input['hscroll_draggable'])) { $settings['hscroll_draggable'] = sanitize_text_field($input['hscroll_draggable']); }
    if (isset($input['hscroll_scrollbar'])) { $settings['hscroll_scrollbar'] = sanitize_text_field($input['hscroll_scrollbar']); }
    if (isset($input['hscroll_footer'])) { $settings['hscroll_footer'] = sanitize_text_field($input['hscroll_footer']); }
    if (isset($input['hscroll_footer_height'])) { $settings['hscroll_footer_height'] = $input['hscroll_footer_height']; }
    if (isset($input['hscroll_responsive'])) { $settings['hscroll_responsive'] = sanitize_text_field($input['hscroll_responsive']); }
    if (isset($input['hscroll_res_minwidth'])) { $settings['hscroll_res_minwidth'] = $input['hscroll_res_minwidth']; }
    if (isset($input['fp-slideid'])) { $settings['fp-slideid'] = sanitize_text_field($input['fp-slideid']); }
    if (isset($input['multi_left_template'])) { $settings['multi_left_template'] = sanitize_text_field($input['multi_left_template']); }
    if (isset($input['multi_right_template'])) { $settings['multi_right_template'] = sanitize_text_field($input['multi_right_template']); }
    if (isset($input['multi_left_right_repeater'])) { $settings['multi_left_right_repeater'] = $input['multi_left_right_repeater']; }
    if (isset($input['show_dots'])) { $settings['show_dots'] = sanitize_text_field($input['show_dots']); }
    if (isset($input['nav_postion'])) { $settings['nav_postion'] = sanitize_text_field($input['nav_postion']); }
    if (isset($input['nav_dots_tooltips'])) { $settings['nav_dots_tooltips'] = sanitize_text_field($input['nav_dots_tooltips']); }
    if (isset($input['multi_navigation_dots'])) { $settings['multi_navigation_dots'] = sanitize_text_field($input['multi_navigation_dots']); }
    if (isset($input['multi_navigation_dots_pos'])) { $settings['multi_navigation_dots_pos'] = sanitize_text_field($input['multi_navigation_dots_pos']); }
    if (isset($input['multi_navigation_verti_dots_pos'])) { $settings['multi_navigation_verti_dots_pos'] = sanitize_text_field($input['multi_navigation_verti_dots_pos']); }
    if (isset($input['multi_dots_tooltips'])) { $settings['multi_dots_tooltips'] = sanitize_text_field($input['multi_dots_tooltips']); }
    if (isset($input['scroll_nav_connection'])) { $settings['scroll_nav_connection'] = sanitize_text_field($input['scroll_nav_connection']); }
    if (isset($input['scrollnav_connect_id'])) { $settings['scrollnav_connect_id'] = sanitize_text_field($input['scrollnav_connect_id']); }
    if (isset($input['show_next_prev'])) { $settings['show_next_prev'] = sanitize_text_field($input['show_next_prev']); }
    if (isset($input['next_prev_style'])) { $settings['next_prev_style'] = sanitize_text_field($input['next_prev_style']); }
    if (isset($input['nav_prev_image'])) { $settings['nav_prev_image'] = sanitize_text_field($input['nav_prev_image']); }
    if (isset($input['nav_next_image'])) { $settings['nav_next_image'] = sanitize_text_field($input['nav_next_image']); }
    if (isset($input['np_gap'])) { $settings['np_gap'] = $input['np_gap']; }
    if (isset($input['next_prev_direction'])) { $settings['next_prev_direction'] = sanitize_text_field($input['next_prev_direction']); }
    if (isset($input['fp_nav_position'])) { $settings['fp_nav_position'] = sanitize_text_field($input['fp_nav_position']); }
    if (isset($input['fp_offset_left'])) { $settings['fp_offset_left'] = $input['fp_offset_left']; }
    if (isset($input['fp_offset_right'])) { $settings['fp_offset_right'] = $input['fp_offset_right']; }
    if (isset($input['fp_offset_bottom'])) { $settings['fp_offset_bottom'] = $input['fp_offset_bottom']; }
    if (isset($input['fp_offset_top'])) { $settings['fp_offset_top'] = $input['fp_offset_top']; }
    if (isset($input['next_size'])) { $settings['next_size'] = sanitize_text_field($input['next_size']); }
    if (isset($input['prev_size'])) { $settings['prev_size'] = sanitize_text_field($input['prev_size']); }
    if (isset($input['nxt_txt'])) { $settings['nxt_txt'] = sanitize_text_field($input['nxt_txt']); }
    if (isset($input['prev_txt'])) { $settings['prev_txt'] = sanitize_text_field($input['prev_txt']); }
    if (isset($input['show_paginate'])) { $settings['show_paginate'] = sanitize_text_field($input['show_paginate']); }
    if (isset($input['paginate_style'])) { $settings['paginate_style'] = sanitize_text_field($input['paginate_style']); }
    if (isset($input['paginate_position'])) { $settings['paginate_position'] = sanitize_text_field($input['paginate_position']); }
    if (isset($input['paginate_offset_left'])) { $settings['paginate_offset_left'] = $input['paginate_offset_left']; }
    if (isset($input['paginate_offset_right'])) { $settings['paginate_offset_right'] = $input['paginate_offset_right']; }
    if (isset($input['paginate_offset_bottom'])) { $settings['paginate_offset_bottom'] = $input['paginate_offset_bottom']; }
    if (isset($input['paginate_offset_top'])) { $settings['paginate_offset_top'] = $input['paginate_offset_top']; }
    if (isset($input['tp_show_header_footer_note'])) { $settings['tp_show_header_footer_note'] = sanitize_text_field($input['tp_show_header_footer_note']); }
    if (isset($input['tp_show_footer'])) { $settings['tp_show_footer'] = sanitize_text_field($input['tp_show_footer']); }
    if (isset($input['tp_direction'])) { $settings['tp_direction'] = sanitize_text_field($input['tp_direction']); }
    if (isset($input['tp_fp_hide_hash_id'])) { $settings['tp_fp_hide_hash_id'] = sanitize_text_field($input['tp_fp_hide_hash_id']); }
    if (isset($input['tp_keyboard_scrolling'])) { $settings['tp_keyboard_scrolling'] = sanitize_text_field($input['tp_keyboard_scrolling']); }
    if (isset($input['tp_reset_scrolling'])) { $settings['tp_reset_scrolling'] = sanitize_text_field($input['tp_reset_scrolling']); }
    if (isset($input['tp_overflow_scrolling'])) { $settings['tp_overflow_scrolling'] = sanitize_text_field($input['tp_overflow_scrolling']); }
    if (isset($input['tp_scrolling_speed'])) { $settings['tp_scrolling_speed'] = sanitize_text_field($input['tp_scrolling_speed']); }
    if (isset($input['tp_loop_bottom'])) { $settings['tp_loop_bottom'] = sanitize_text_field($input['tp_loop_bottom']); }
    if (isset($input['tp_loop_top'])) { $settings['tp_loop_top'] = sanitize_text_field($input['tp_loop_top']); }
    if (isset($input['tp_tablet_off'])) { $settings['tp_tablet_off'] = sanitize_text_field($input['tp_tablet_off']); }
    if (isset($input['tp_mobile_off'])) { $settings['tp_mobile_off'] = sanitize_text_field($input['tp_mobile_off']); }
    if (isset($input['tp_continuous_vertical'])) { $settings['tp_continuous_vertical'] = sanitize_text_field($input['tp_continuous_vertical']); }
    if (isset($input['tp_responsive_width'])) { $settings['tp_responsive_width'] = sanitize_text_field($input['tp_responsive_width']); }
    if (isset($input['res_width_value'])) { $settings['res_width_value'] = sanitize_text_field($input['res_width_value']); }
    if (isset($input['multi_left_width'])) { $settings['multi_left_width'] = $input['multi_left_width']; }
    if (isset($input['multi_right_width'])) { $settings['multi_right_width'] = $input['multi_right_width']; }
    if (isset($input['multi_keyboard_scrolling'])) { $settings['multi_keyboard_scrolling'] = sanitize_text_field($input['multi_keyboard_scrolling']); }
    if (isset($input['multi_loop_top'])) { $settings['multi_loop_top'] = sanitize_text_field($input['multi_loop_top']); }
    if (isset($input['multi_loop_bottom'])) { $settings['multi_loop_bottom'] = sanitize_text_field($input['multi_loop_bottom']); }
    if (isset($input['multi_scrolling_speed'])) { $settings['multi_scrolling_speed'] = sanitize_text_field($input['multi_scrolling_speed']); }
    if (isset($input['multi_scroll_responsive_tabs'])) { $settings['multi_scroll_responsive_tabs'] = sanitize_text_field($input['multi_scroll_responsive_tabs']); }
    if (isset($input['multi_scroll_responsive_mobile'])) { $settings['multi_scroll_responsive_mobile'] = sanitize_text_field($input['multi_scroll_responsive_mobile']); }
    if (isset($input['dots_color_n'])) { $settings['dots_color_n'] = sanitize_text_field($input['dots_color_n']); }
    if (isset($input['dots_color_h'])) { $settings['dots_color_h'] = sanitize_text_field($input['dots_color_h']); }
    if (isset($input['dots_tt_head'])) { $settings['dots_tt_head'] = sanitize_text_field($input['dots_tt_head']); }
    if (isset($input['dots_text_padding'])) { $settings['dots_text_padding'] = $input['dots_text_padding']; }
    if (isset($input['dots_text_color_n'])) { $settings['dots_text_color_n'] = sanitize_text_field($input['dots_text_color_n']); }
    if (isset($input['dots_text_bg_color_n'])) { $settings['dots_text_bg_color_n'] = sanitize_text_field($input['dots_text_bg_color_n']); }
    if (isset($input['dots_tt_border'])) { $settings['dots_tt_border'] = $input['dots_tt_border']; }
    if (isset($input['np_icon_color_n'])) { $settings['np_icon_color_n'] = sanitize_text_field($input['np_icon_color_n']); }
    if (isset($input['np_st3_n_color_n'])) { $settings['np_st3_n_color_n'] = sanitize_text_field($input['np_st3_n_color_n']); }
    if (isset($input['np_st3_p_color_n'])) { $settings['np_st3_p_color_n'] = sanitize_text_field($input['np_st3_p_color_n']); }
    if (isset($input['np_icon_bg_n'])) { $settings['np_icon_bg_n'] = sanitize_text_field($input['np_icon_bg_n']); }
    if (isset($input['np_icon_n_br'])) { $settings['np_icon_n_br'] = $input['np_icon_n_br']; }
    if (isset($input['np_icon_color_h'])) { $settings['np_icon_color_h'] = sanitize_text_field($input['np_icon_color_h']); }
    if (isset($input['np_st3_n_color_h'])) { $settings['np_st3_n_color_h'] = sanitize_text_field($input['np_st3_n_color_h']); }
    if (isset($input['np_st3_p_color_h'])) { $settings['np_st3_p_color_h'] = sanitize_text_field($input['np_st3_p_color_h']); }
    if (isset($input['np_icon_bg_h'])) { $settings['np_icon_bg_h'] = sanitize_text_field($input['np_icon_bg_h']); }
    if (isset($input['fp_nxt_btn'])) { $settings['fp_nxt_btn'] = $input['fp_nxt_btn']; }
    if (isset($input['fp_prev_btn'])) { $settings['fp_prev_btn'] = $input['fp_prev_btn']; }
    if (isset($input['paginate_color'])) { $settings['paginate_color'] = sanitize_text_field($input['paginate_color']); }
    if (isset($input['paginate_last_color'])) { $settings['paginate_last_color'] = sanitize_text_field($input['paginate_last_color']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
