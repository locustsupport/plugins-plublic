<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-switcher', [
'label' => __('Switcher', 'theplus'),
    'description' => __('Adds The Plus "Switcher" widget (tp-switcher) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'switch_a_title' => ['type' => 'string', 'description' => 'Title'],
        'content_a_source' => ['type' => 'string', 'description' => 'Select Source', 'enum' => ['content', 'template']],
        'content_a_desc' => ['type' => 'string', 'description' => 'Content'],
        'content_template_type' => ['type' => 'string', 'description' => 'Content Type', 'enum' => ['content_a_source', 'dropdown', 'manually']],
        'content_a_template' => ['type' => 'string', 'description' => 'content_a_template', 'enum' => ['content_a_source', 'content_template_type']],
        'content_template_id' => ['type' => 'string', 'description' => 'Enter Elementor Template Shortcode'],
        'switch_a_icon' => ['type' => 'string', 'description' => 'Icon'],
        'con1_hashid' => ['type' => 'string', 'description' => 'Unique ID'],
        'switch_b_title' => ['type' => 'string', 'description' => 'Title'],
        'content_b_source' => ['type' => 'string', 'description' => 'Select Source', 'enum' => ['content', 'template']],
        'content_b_desc' => ['type' => 'string', 'description' => 'Content'],
        'content_b_template_type' => ['type' => 'string', 'description' => 'Content Type', 'enum' => ['content_b_source', 'dropdown', 'manually']],
        'content_b_template' => ['type' => 'string', 'description' => 'Elementor Templates', 'enum' => ['content_b_source', 'content_b_template_type']],
        'content_b_template_id' => ['type' => 'string', 'description' => 'Enter Elementor Template Shortcode'],
        'switch_b_icon' => ['type' => 'string', 'description' => 'Icon'],
        'con2_hashid' => ['type' => 'string', 'description' => 'Unique ID'],
        'switcher_unique_id' => ['type' => 'string', 'description' => 'Unique Switcher ID'],
        'show_switcher_button' => ['type' => 'string', 'description' => 'Display Switcher Toggle', 'enum' => ['yes', 'no']],
        'show_switcher_label' => ['type' => 'string', 'description' => 'Switcher Label', 'enum' => ['yes', 'no']],
        'switcher_style' => ['type' => 'string', 'description' => 'Switcher Style', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4']],
        'show_tooltip' => ['type' => 'string', 'description' => 'Tooltip', 'enum' => ['yes', 'no']],
        'tooltip_con_1' => ['type' => 'string', 'description' => 'Content 1'],
        'tooltip_con_2' => ['type' => 'string', 'description' => 'Content 2'],
        'switcher_title_tag' => ['type' => 'string', 'description' => 'Title Tag'],
        'switch-align' => ['type' => 'string', 'description' => 'Alignment'],
        'switch_label_space' => ['type' => 'object', 'description' => 'Label Spacing (Slider/Size Object)'],
        'switch_toggle_size' => ['type' => 'object', 'description' => 'Switch/Toggle Size (Slider/Size Object)'],
        'switch_4_width' => ['type' => 'object', 'description' => 'Switch Max-Width (Slider/Size Object)'],
        'normal_label_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'switch_color' => ['type' => 'string', 'description' => 'Switch Color (Color Hex/RGBA)'],
        'normal_bg_color' => ['type' => 'string', 'description' => 'Toggle Background Color (Color Hex/RGBA)'],
        'normal_label_color' => ['type' => 'string', 'description' => 'Label Color (Color Hex/RGBA)'],
        'normal_label_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'normal_label_padding_a' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'active_bg_color' => ['type' => 'string', 'description' => 'Toggle Background Color (Color Hex/RGBA)'],
        'active_label_color' => ['type' => 'string', 'description' => 'Label Color (Color Hex/RGBA)'],
        'normal_label_br_a' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'label_max_width' => ['type' => 'object', 'description' => 'Label Width (Slider/Size Object)'],
        'label_word_break' => ['type' => 'string', 'description' => 'Word Break', 'enum' => ['break-all', 'keep-all', '{{WRAPPER}} .theplus-switcher .switch-label-text']],
        'switcher_iconsize' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'switcher_iconA_gap' => ['type' => 'object', 'description' => 'Content 1 Icon Gap (Slider/Size Object)'],
        'switcher_iconB_gap' => ['type' => 'object', 'description' => 'Content 2 Icon Gap (Slider/Size Object)'],
        'normal_icon_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'active_icon_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'underline_color' => ['type' => 'string', 'description' => 'Underline Color (Color Hex/RGBA)'],
        'line_bottom_offset' => ['type' => 'object', 'description' => 'Bottom Offset (Slider/Size Object)'],
        'underline_height' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'content_underline_position' => ['type' => 'string', 'description' => 'Content Position'],
        'underline_pos_content1' => ['type' => 'object', 'description' => 'Position (Slider/Size Object)'],
        'underline_pos_content2' => ['type' => 'object', 'description' => 'Position (Slider/Size Object)'],
        'tt1Padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'tt1Left' => ['type' => 'object', 'description' => 'Left (Slider/Size Object)'],
        'tt1top' => ['type' => 'object', 'description' => 'Top (Slider/Size Object)'],
        'tt1Color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'tt1Arrow' => ['type' => 'string', 'description' => 'Arrow (Color Hex/RGBA)'],
        'tt1Bg' => ['type' => 'string', 'description' => 'Background (Color Hex/RGBA)'],
        'tt1Br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'tt1ColorA' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'tt1ArrowA' => ['type' => 'string', 'description' => 'Arrow (Color Hex/RGBA)'],
        'tt1BgA' => ['type' => 'string', 'description' => 'Background (Color Hex/RGBA)'],
        'tt1BrA' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'tt2Padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'tt2Left' => ['type' => 'object', 'description' => 'Left (Slider/Size Object)'],
        'tt2top' => ['type' => 'object', 'description' => 'Top (Slider/Size Object)'],
        'tt2Color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'tt2Arrow' => ['type' => 'string', 'description' => 'Arrow (Color Hex/RGBA)'],
        'tt2Bg' => ['type' => 'string', 'description' => 'Background (Color Hex/RGBA)'],
        'tt2Br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'tt2ColorA' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'tt2ArrowA' => ['type' => 'string', 'description' => 'Arrow (Color Hex/RGBA)'],
        'tt2BgA' => ['type' => 'string', 'description' => 'Background (Color Hex/RGBA)'],
        'tt2BrA' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'content_section_a_color' => ['type' => 'string', 'description' => 'Content 1 Color (Color Hex/RGBA)'],
        'content_section_b_color' => ['type' => 'string', 'description' => 'Content 2 Color (Color Hex/RGBA)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports Lottie animation triggers, template dynamic sync, and interactive physics.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_pro_switcher_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pro_switcher_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_pro_switcher_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_pro_switcher_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-switcher';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Switcher widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['switch_a_title'])) { $settings['switch_a_title'] = sanitize_text_field($input['switch_a_title']); }
    if (isset($input['content_a_source'])) { $settings['content_a_source'] = sanitize_text_field($input['content_a_source']); }
    if (isset($input['content_a_desc'])) { $settings['content_a_desc'] = sanitize_text_field($input['content_a_desc']); }
    if (isset($input['content_template_type'])) { $settings['content_template_type'] = sanitize_text_field($input['content_template_type']); }
    if (isset($input['content_a_template'])) { $settings['content_a_template'] = sanitize_text_field($input['content_a_template']); }
    if (isset($input['content_template_id'])) { $settings['content_template_id'] = sanitize_text_field($input['content_template_id']); }
    if (isset($input['switch_a_icon'])) { $settings['switch_a_icon'] = sanitize_text_field($input['switch_a_icon']); }
    if (isset($input['con1_hashid'])) { $settings['con1_hashid'] = sanitize_text_field($input['con1_hashid']); }
    if (isset($input['switch_b_title'])) { $settings['switch_b_title'] = sanitize_text_field($input['switch_b_title']); }
    if (isset($input['content_b_source'])) { $settings['content_b_source'] = sanitize_text_field($input['content_b_source']); }
    if (isset($input['content_b_desc'])) { $settings['content_b_desc'] = sanitize_text_field($input['content_b_desc']); }
    if (isset($input['content_b_template_type'])) { $settings['content_b_template_type'] = sanitize_text_field($input['content_b_template_type']); }
    if (isset($input['content_b_template'])) { $settings['content_b_template'] = sanitize_text_field($input['content_b_template']); }
    if (isset($input['content_b_template_id'])) { $settings['content_b_template_id'] = sanitize_text_field($input['content_b_template_id']); }
    if (isset($input['switch_b_icon'])) { $settings['switch_b_icon'] = sanitize_text_field($input['switch_b_icon']); }
    if (isset($input['con2_hashid'])) { $settings['con2_hashid'] = sanitize_text_field($input['con2_hashid']); }
    if (isset($input['switcher_unique_id'])) { $settings['switcher_unique_id'] = sanitize_text_field($input['switcher_unique_id']); }
    if (isset($input['show_switcher_button'])) { $settings['show_switcher_button'] = sanitize_text_field($input['show_switcher_button']); }
    if (isset($input['show_switcher_label'])) { $settings['show_switcher_label'] = sanitize_text_field($input['show_switcher_label']); }
    if (isset($input['switcher_style'])) { $settings['switcher_style'] = sanitize_text_field($input['switcher_style']); }
    if (isset($input['show_tooltip'])) { $settings['show_tooltip'] = sanitize_text_field($input['show_tooltip']); }
    if (isset($input['tooltip_con_1'])) { $settings['tooltip_con_1'] = sanitize_text_field($input['tooltip_con_1']); }
    if (isset($input['tooltip_con_2'])) { $settings['tooltip_con_2'] = sanitize_text_field($input['tooltip_con_2']); }
    if (isset($input['switcher_title_tag'])) { $settings['switcher_title_tag'] = sanitize_text_field($input['switcher_title_tag']); }
    if (isset($input['switch-align'])) { $settings['switch-align'] = sanitize_text_field($input['switch-align']); }
    if (isset($input['switch_label_space'])) { $settings['switch_label_space'] = $input['switch_label_space']; }
    if (isset($input['switch_toggle_size'])) { $settings['switch_toggle_size'] = $input['switch_toggle_size']; }
    if (isset($input['switch_4_width'])) { $settings['switch_4_width'] = $input['switch_4_width']; }
    if (isset($input['normal_label_padding'])) { $settings['normal_label_padding'] = $input['normal_label_padding']; }
    if (isset($input['switch_color'])) { $settings['switch_color'] = sanitize_text_field($input['switch_color']); }
    if (isset($input['normal_bg_color'])) { $settings['normal_bg_color'] = sanitize_text_field($input['normal_bg_color']); }
    if (isset($input['normal_label_color'])) { $settings['normal_label_color'] = sanitize_text_field($input['normal_label_color']); }
    if (isset($input['normal_label_br'])) { $settings['normal_label_br'] = $input['normal_label_br']; }
    if (isset($input['normal_label_padding_a'])) { $settings['normal_label_padding_a'] = $input['normal_label_padding_a']; }
    if (isset($input['active_bg_color'])) { $settings['active_bg_color'] = sanitize_text_field($input['active_bg_color']); }
    if (isset($input['active_label_color'])) { $settings['active_label_color'] = sanitize_text_field($input['active_label_color']); }
    if (isset($input['normal_label_br_a'])) { $settings['normal_label_br_a'] = $input['normal_label_br_a']; }
    if (isset($input['label_max_width'])) { $settings['label_max_width'] = $input['label_max_width']; }
    if (isset($input['label_word_break'])) { $settings['label_word_break'] = sanitize_text_field($input['label_word_break']); }
    if (isset($input['switcher_iconsize'])) { $settings['switcher_iconsize'] = $input['switcher_iconsize']; }
    if (isset($input['switcher_iconA_gap'])) { $settings['switcher_iconA_gap'] = $input['switcher_iconA_gap']; }
    if (isset($input['switcher_iconB_gap'])) { $settings['switcher_iconB_gap'] = $input['switcher_iconB_gap']; }
    if (isset($input['normal_icon_color'])) { $settings['normal_icon_color'] = sanitize_text_field($input['normal_icon_color']); }
    if (isset($input['active_icon_color'])) { $settings['active_icon_color'] = sanitize_text_field($input['active_icon_color']); }
    if (isset($input['underline_color'])) { $settings['underline_color'] = sanitize_text_field($input['underline_color']); }
    if (isset($input['line_bottom_offset'])) { $settings['line_bottom_offset'] = $input['line_bottom_offset']; }
    if (isset($input['underline_height'])) { $settings['underline_height'] = $input['underline_height']; }
    if (isset($input['content_underline_position'])) { $settings['content_underline_position'] = sanitize_text_field($input['content_underline_position']); }
    if (isset($input['underline_pos_content1'])) { $settings['underline_pos_content1'] = $input['underline_pos_content1']; }
    if (isset($input['underline_pos_content2'])) { $settings['underline_pos_content2'] = $input['underline_pos_content2']; }
    if (isset($input['tt1Padding'])) { $settings['tt1Padding'] = $input['tt1Padding']; }
    if (isset($input['tt1Left'])) { $settings['tt1Left'] = $input['tt1Left']; }
    if (isset($input['tt1top'])) { $settings['tt1top'] = $input['tt1top']; }
    if (isset($input['tt1Color'])) { $settings['tt1Color'] = sanitize_text_field($input['tt1Color']); }
    if (isset($input['tt1Arrow'])) { $settings['tt1Arrow'] = sanitize_text_field($input['tt1Arrow']); }
    if (isset($input['tt1Bg'])) { $settings['tt1Bg'] = sanitize_text_field($input['tt1Bg']); }
    if (isset($input['tt1Br'])) { $settings['tt1Br'] = $input['tt1Br']; }
    if (isset($input['tt1ColorA'])) { $settings['tt1ColorA'] = sanitize_text_field($input['tt1ColorA']); }
    if (isset($input['tt1ArrowA'])) { $settings['tt1ArrowA'] = sanitize_text_field($input['tt1ArrowA']); }
    if (isset($input['tt1BgA'])) { $settings['tt1BgA'] = sanitize_text_field($input['tt1BgA']); }
    if (isset($input['tt1BrA'])) { $settings['tt1BrA'] = $input['tt1BrA']; }
    if (isset($input['tt2Padding'])) { $settings['tt2Padding'] = $input['tt2Padding']; }
    if (isset($input['tt2Left'])) { $settings['tt2Left'] = $input['tt2Left']; }
    if (isset($input['tt2top'])) { $settings['tt2top'] = $input['tt2top']; }
    if (isset($input['tt2Color'])) { $settings['tt2Color'] = sanitize_text_field($input['tt2Color']); }
    if (isset($input['tt2Arrow'])) { $settings['tt2Arrow'] = sanitize_text_field($input['tt2Arrow']); }
    if (isset($input['tt2Bg'])) { $settings['tt2Bg'] = sanitize_text_field($input['tt2Bg']); }
    if (isset($input['tt2Br'])) { $settings['tt2Br'] = $input['tt2Br']; }
    if (isset($input['tt2ColorA'])) { $settings['tt2ColorA'] = sanitize_text_field($input['tt2ColorA']); }
    if (isset($input['tt2ArrowA'])) { $settings['tt2ArrowA'] = sanitize_text_field($input['tt2ArrowA']); }
    if (isset($input['tt2BgA'])) { $settings['tt2BgA'] = sanitize_text_field($input['tt2BgA']); }
    if (isset($input['tt2BrA'])) { $settings['tt2BrA'] = $input['tt2BrA']; }
    if (isset($input['content_section_a_color'])) { $settings['content_section_a_color'] = sanitize_text_field($input['content_section_a_color']); }
    if (isset($input['content_section_b_color'])) { $settings['content_section_b_color'] = sanitize_text_field($input['content_section_b_color']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
