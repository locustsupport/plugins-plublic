<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-blog-listout', [
'label' => __('Blog Listout (Pro)', 'theplus'),
    'description' => __('Adds The Plus "Blog Listout" widget (tp-blog-listout) to an Elementor container with full professional layouts and query options.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'        => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'      => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'       => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'blogs_post_listing' => ['type' => 'string', 'description' => 'Post Listing Types', 'enum' => ['archive_listing', 'page_listing', 'related_post']],
        'related_post_by' => ['type' => 'string', 'description' => 'related_post_by', 'enum' => ['blogs_post_listing', 'both', 'category', 'tags']],
        'style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'smart-loop-builder', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5']],
        'layout' => ['type' => 'string', 'description' => 'Layout', 'enum' => ['carousel', 'columns', 'grid', 'masonry', 'metro']],
        'content_alignment' => ['type' => 'string', 'description' => 'Content Alignment', 'enum' => ['center', 'icon', 'layout!', 'left', 'style', 'toggle']],
        'content_alignment_3' => ['type' => 'string', 'description' => 'Content Alignment', 'enum' => ['icon', 'layout!', 'left', 'left-right', 'right', 'style', 'toggle']],
        'style_layout' => ['type' => 'string', 'description' => 'Style Layout', 'enum' => ['style']],
        'column_min_height' => ['type' => 'object', 'description' => 'Minimum Height'],
        'content_html' => ['type' => 'string', 'description' => 'HTML'],
        'content_css' => ['type' => 'string', 'description' => 'CSS'],
        'display_posts' => ['type' => 'string', 'description' => 'Maximum Post Display'],
        'post_offset' => ['type' => 'string', 'description' => 'post_offset'],
        'post_category' => ['type' => 'string', 'description' => 'Select Category', 'enum' => ['blogs_post_listing!', 'multiple']],
        'post_tags' => ['type' => 'string', 'description' => 'Select Tags', 'enum' => ['blogs_post_listing!', 'multiple']],
        'ex_cat' => ['type' => 'string', 'description' => 'ex_cat', 'enum' => ['blogs_post_listing!', 'multiple']],
        'ex_tag' => ['type' => 'string', 'description' => 'ex_tag', 'enum' => ['blogs_post_listing!', 'multiple']],
        'post_order_by' => ['type' => 'string', 'description' => 'post_order_by'],
        'post_order' => ['type' => 'string', 'description' => 'Order'],
        'desktop_column' => ['type' => 'string', 'description' => 'Desktop Column', 'enum' => ['layout!']],
        'tablet_column' => ['type' => 'string', 'description' => 'Tablet Column', 'enum' => ['layout!']],
        'mobile_column' => ['type' => 'string', 'description' => 'Mobile Column', 'enum' => ['layout!']],
        'metro_column' => ['type' => 'string', 'description' => 'Metro Column', 'enum' => ['3', '4', '5', '6', 'layout']],
        'metro_style_3' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_3' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_4' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_4' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_5' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_5' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_6' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_6' => ['type' => 'string', 'description' => 'Custom Layout'],
        'responsive_tablet_metro' => ['type' => 'string', 'description' => 'Tablet Responsive', 'enum' => ['yes', 'no']],
        'tablet_metro_column' => ['type' => 'string', 'description' => 'Metro Column', 'enum' => ['3', '4', '5', '6', 'layout', 'responsive_tablet_metro']],
        'tablet_metro_style_3' => ['type' => 'string', 'description' => 'Tablet Metro Style', 'enum' => ['layout', 'responsive_tablet_metro', 'tablet_metro_column']],
        'metro_custom_col_tab' => ['type' => 'string', 'description' => 'Custom Layout'],
        'columns_gap' => ['type' => 'object', 'description' => 'Column Spacing'],
        'filter_category' => ['type' => 'string', 'description' => 'filter_category', 'enum' => ['yes', 'no']],
        'filter_category_align' => ['type' => 'string', 'description' => 'Filter Alignment', 'enum' => ['blogs_post_listing!', 'center', 'filter_category', 'icon', 'layout!', 'left', 'right', 'toggle']],
        'TaxonomyType' => ['type' => 'string', 'description' => 'Select Taxonomy', 'enum' => ['filter_category']],
        'filter_type' => ['type' => 'string', 'description' => 'Filter Type', 'enum' => ['ajax_base', 'filter_category', 'normal']],
        'filter_search_type' => ['type' => 'string', 'description' => 'Search Type', 'enum' => ['filter_category', 'slug', 'term_id']],
        'all_filter_category_switch' => ['type' => 'string', 'description' => 'All Filter', 'enum' => ['yes', 'no']],
        'all_filter_category' => ['type' => 'string', 'description' => 'Category Text'],
        'filter_style' => ['type' => 'string', 'description' => 'Category Filter Style', 'enum' => ['blogs_post_listing!', 'filter_category', 'layout!']],
        'filter_hover_style' => ['type' => 'string', 'description' => 'Filter Hover Style', 'enum' => ['blogs_post_listing!', 'filter_category', 'layout!']],
        'post_extra_option' => ['type' => 'string', 'description' => 'Post Loading Options', 'enum' => ['blogs_post_listing!', 'columns', 'layout!', 'lazy_load', 'load_more', 'none', 'pagination']],
        'pagination_next' => ['type' => 'string', 'description' => 'Pagination Next'],
        'pagination_prev' => ['type' => 'string', 'description' => 'Pagination Previous'],
        'pagination_color' => ['type' => 'string', 'description' => 'Pagination Text Color'],
        'pagination_hover_color' => ['type' => 'string', 'description' => 'Pagination Hover Color'],
        'load_more_btn_text' => ['type' => 'string', 'description' => 'Button Text'],
        'tp_loading_text' => ['type' => 'string', 'description' => 'Loading Text'],
        'loaded_posts_text' => ['type' => 'string', 'description' => 'All Posts Loaded Text'],
        'load_more_post' => ['type' => 'string', 'description' => 'More posts on click/scroll'],
        'load_more_border' => ['type' => 'string', 'description' => 'Load More Border', 'enum' => ['yes', 'no']],
        'load_more_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['blogs_post_listing!', 'layout!', 'load_more_border', 'post_extra_option', '{{WRAPPER}} .ajax_load_more .post-load-more']],
        'load_more_border_width' => ['type' => 'object', 'description' => 'Border Width'],
        'load_more_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'load_more_border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'load_more_border_hover_color' => ['type' => 'string', 'description' => 'Border Color'],
        'load_more_border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'load_more_color' => ['type' => 'string', 'description' => 'Text Color'],
        'loaded_posts_color' => ['type' => 'string', 'description' => 'Loaded Post Text Color'],
        'loading_spin_color' => ['type' => 'string', 'description' => 'Color'],
        'loading_spin_size' => ['type' => 'object', 'description' => 'Size'],
        'loading_spin_border_size' => ['type' => 'object', 'description' => 'Border Size'],
        'load_more_color_hover' => ['type' => 'string', 'description' => 'Text Hover Color'],
        'loading_options' => ['type' => 'string', 'description' => 'loading_options', 'enum' => ['blogs_post_listing!', 'layout!', 'skeleton']],
        'tp_list_preloader' => ['type' => 'string', 'description' => 'tp_list_preloader', 'enum' => ['yes', 'no']],
        'tp_list_preloader_hw' => ['type' => 'object', 'description' => 'Width'],
        'tp_list_preloader_size' => ['type' => 'object', 'description' => 'Border Size'],
        'tp_list_preloader_color' => ['type' => 'string', 'description' => 'Color'],
        'display_title_limit' => ['type' => 'string', 'description' => 'display_title_limit', 'enum' => ['yes', 'no']],
        'display_title_by' => ['type' => 'string', 'description' => 'Limit on', 'enum' => ['char', 'display_title_limit', 'word']],
        'display_title_input' => ['type' => 'string', 'description' => 'Title Count'],
        'display_title_3_dots' => ['type' => 'string', 'description' => 'Display Dots', 'enum' => ['yes', 'no']],
        'filter_url' => ['type' => 'string', 'description' => 'filter_url', 'enum' => ['yes', 'no']],
        'post_title_tag' => ['type' => 'string', 'description' => 'Title Tag'],
        'featured_image_type' => ['type' => 'string', 'description' => 'Featured Image Type', 'enum' => ['custom', 'full', 'grid', 'layout']],
        'title_desc_word_break' => ['type' => 'string', 'description' => 'Word Break', 'enum' => ['break-all', 'keep-all', 'normal']],
        'display_post_category' => ['type' => 'string', 'description' => 'Display Category Post', 'enum' => ['yes', 'no']],
        'post_category_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['display_post_category', 'style!']],
        'display_post_category_all' => ['type' => 'string', 'description' => 'Display All Category', 'enum' => ['yes', 'no']],
        'display_excerpt' => ['type' => 'string', 'description' => 'Display Content', 'enum' => ['yes', 'no']],
        'post_excerpt_count' => ['type' => 'string', 'description' => 'post_excerpt_count'],
        'show_post_date' => ['type' => 'string', 'description' => 'Date & Time', 'enum' => ['yes', 'no']],
        'show_post_author' => ['type' => 'string', 'description' => 'Author Name', 'enum' => ['yes', 'no']],
        'show_read_time' => ['type' => 'string', 'description' => 'Read Time', 'enum' => ['yes', 'no']],
        'display_thumbnail' => ['type' => 'string', 'description' => 'Display Image Size', 'enum' => ['yes', 'no']],
        'display_post_meta' => ['type' => 'string', 'description' => 'Display Post Meta', 'enum' => ['yes', 'no']],
        'post_meta_tag_style' => ['type' => 'string', 'description' => 'Post Meta Tag', 'enum' => ['display_post_meta']],
        'author_prefix' => ['type' => 'string', 'description' => 'Author Prefix'],
        'display_post_meta_date' => ['type' => 'string', 'description' => 'display_post_meta_date', 'enum' => ['yes', 'no']],
        'date_type' => ['type' => 'string', 'description' => 'Type', 'enum' => ['display_post_meta_date', 'post_modified', 'post_published']],
        'display_post_meta_author' => ['type' => 'string', 'description' => 'display_post_meta_author', 'enum' => ['yes', 'no']],
        'display_post_meta_author_pic' => ['type' => 'string', 'description' => 'Display Author Picture', 'enum' => ['yes', 'no']],
        'display_button' => ['type' => 'string', 'description' => 'Button', 'enum' => ['yes', 'no']],
        'button_style' => ['type' => 'string', 'description' => 'Button Style', 'enum' => ['display_button', 'style', 'style-7', 'style-8', 'style-9']],
        'button_text' => ['type' => 'string', 'description' => 'Text'],
        'button_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['button_style!', 'display_button', 'font_awesome', 'icon_mind', 'style']],
        'button_icon' => ['type' => 'string', 'description' => 'Icon'],
        'button_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['button_icon_style', 'button_style!', 'display_button', 'style']],
        'before_after' => ['type' => 'string', 'description' => 'Icon Position', 'enum' => ['after', 'before', 'button_icon_style!', 'button_style!', 'display_button', 'style']],
        'icon_spacing' => ['type' => 'object', 'description' => 'Icon Spacing'],
        'tpaep_theme_builder' => ['type' => 'string', 'description' => 'tpaep_theme_builder'],
        'post_meta_color' => ['type' => 'string', 'description' => 'Post Meta Color'],
        'post_meta_color_hover' => ['type' => 'string', 'description' => 'Post Meta Color'],
        'post_meta_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'blog_card_layout' => ['type' => 'string', 'description' => 'blog_card_layout', 'enum' => ['yes', 'no']],
        'wrap_flex_direction' => ['type' => 'object', 'description' => 'Layout Direction', 'enum' => ['column', 'column-reverse', 'icon', 'row', 'row-reverse', 'toggle', '{{WRAPPER}} .tpae-compect-blog-wrap']],
        'tp_row_one_width' => ['type' => 'object', 'description' => 'Image Box'],
        'tp_row_two_width' => ['type' => 'object', 'description' => 'Content Box'],
        'tp_content_alignment' => ['type' => 'object', 'description' => 'Text Alignment', 'enum' => ['center', 'icon', 'left', 'right', 'toggle', '{{WRAPPER}} .tpae-blog-content']],
        'tp_item_content_alignment' => ['type' => 'object', 'description' => 'Layout Alignment', 'enum' => ['center', 'flex-end', 'flex-start', 'icon', 'toggle', '{{WRAPPER}} .tpae-blog-content']],
        'wrap_gap' => ['type' => 'object', 'description' => 'Item Gap'],
        'tp_absolute_layout' => ['type' => 'string', 'description' => 'Layout Position', 'enum' => ['yes', 'no']],
        'tp_top_card' => ['type' => 'object', 'description' => 'Left/Right'],
        'tp_bottom_card' => ['type' => 'object', 'description' => 'bottom'],
        'tp_width_card' => ['type' => 'object', 'description' => 'Width'],
        'content_direction' => ['type' => 'object', 'description' => 'Content Direction', 'enum' => ['column', 'column-reverse', 'icon', 'row', 'row-reverse', 'toggle', '{{WRAPPER}} .tpae-blog-content']],
        'content_vertical_justify' => ['type' => 'object', 'description' => 'Vertical Alignment', 'enum' => ['center', 'content_direction', 'flex-end', 'flex-start', 'icon', 'space-around', 'space-between', '{{WRAPPER}} .tpae-blog-content']],
        'blog_content_padding' => ['type' => 'object', 'description' => 'Padding'],
        'blog_content_margin' => ['type' => 'object', 'description' => 'Margin'],
        'blog_border_post' => ['type' => 'string', 'description' => 'blog_border_post', 'enum' => ['yes', 'no']],
        'blog_content_border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'blog_meta_layout_post' => ['type' => 'string', 'description' => 'blog_meta_layout_post', 'enum' => ['yes', 'no']],
        'meta_flex_direction' => ['type' => 'string', 'description' => 'Meta Direction', 'enum' => ['column', 'column-reverse', 'icon', 'row', 'row-reverse', 'toggle', '{{WRAPPER}} .tpae-blog-meta ,
					{{WRAPPER}} .tpae-blog-meta-overflow ']],
        'meta_align_items' => ['type' => 'object', 'description' => 'Meta Align', 'enum' => ['center', 'content_direction', 'flex-end', 'flex-start', 'icon', 'toggle', '{{WRAPPER}} .tpae-blog-meta']],
        'meta_gap' => ['type' => 'object', 'description' => 'Item Gap'],
        'tp_meta_inner_padding' => ['type' => 'object', 'description' => 'Padding'],
        'tp_meta_border_r' => ['type' => 'object', 'description' => 'Border Radius'],
        'date_overflow' => ['type' => 'string', 'description' => 'Date Position', 'enum' => ['yes', 'no']],
        'category_date_inner_padding' => ['type' => 'object', 'description' => 'Padding'],
        'date_style_margin_tb' => ['type' => 'object', 'description' => 'Top/Bottom Spacing'],
        'date_style_margin_lr' => ['type' => 'object', 'description' => 'Left/Right Spacing'],
        'overflow_date_br' => ['type' => 'object', 'description' => 'Border Radius'],
        'meta_overflow' => ['type' => 'string', 'description' => 'Author Position', 'enum' => ['yes', 'no']],
        'category_meta_inner_padding' => ['type' => 'object', 'description' => 'Padding'],
        'meta_style_margin_tb' => ['type' => 'object', 'description' => 'Top/Bottom Spacing'],
        'meta_style_margin_lr' => ['type' => 'object', 'description' => 'Left/Right Spacing'],
        'overflow_meta_br' => ['type' => 'object', 'description' => 'Border Radius'],
        'post_tima_overflow' => ['type' => 'string', 'description' => 'Post Time Position', 'enum' => ['yes', 'no']],
        'category_post_time_inner_padding' => ['type' => 'object', 'description' => 'Padding'],
        'post_style_margin_tb' => ['type' => 'object', 'description' => 'Top/Bottom Spacing'],
        'post_style_margin_lr' => ['type' => 'object', 'description' => 'Left/Right Spacing'],
        'overflow_post_time_br' => ['type' => 'object', 'description' => 'Border Radius'],
        'button_overflow' => ['type' => 'string', 'description' => 'Button Absolute', 'enum' => ['yes', 'no']],
        'button_style_margin_tb' => ['type' => 'object', 'description' => 'Top/Bottom Spacing'],
        'button_style_margin_lr' => ['type' => 'object', 'description' => 'Left/Right Spacing'],
        'blog_category_post' => ['type' => 'string', 'description' => 'blog_category_post', 'enum' => ['yes', 'no']],
        'category_style_margin_tb' => ['type' => 'object', 'description' => 'Top/Bottom Spacing'],
        'category_style_margin_lr' => ['type' => 'object', 'description' => 'Left/Right Spacing'],
        'category_inner_padding' => ['type' => 'object', 'description' => 'Padding'],
        'category_color' => ['type' => 'string', 'description' => 'Color'],
        'category_hover_color' => ['type' => 'string', 'description' => 'Color'],
        'category_2_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color'],
        'category_border' => ['type' => 'string', 'description' => 'Border', 'enum' => ['yes', 'no']],
        'category_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['category_border', 'display_post_category', 'post_category_style', '{{WRAPPER}} .blog-list .post-inner-loop .post-category-list span a']],
        'box_category_border_width' => ['type' => 'object', 'description' => 'Border Width'],
        'category_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'category_border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'category_border_hover_color' => ['type' => 'string', 'description' => 'Border Color'],
        'category_border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        's_title_pg' => ['type' => 'object', 'description' => 'Padding'],
        'title_margin' => ['type' => 'object', 'description' => 'Margin'],
        'title_color' => ['type' => 'string', 'description' => 'Color'],
        'title_hover_color' => ['type' => 'string', 'description' => 'Color'],
        'title_boxhover_color' => ['type' => 'string', 'description' => 'Title Color'],
        's_excerpt_content_pg' => ['type' => 'object', 'description' => 'Padding'],
        'excerpt_margin' => ['type' => 'object', 'description' => 'Margin'],
        'excerpt_color' => ['type' => 'string', 'description' => 'Content Color'],
        'excerpt_hover_color' => ['type' => 'string', 'description' => 'Content Color'],
        'content_between_space' => ['type' => 'object', 'description' => 'Content Space'],
        'blog_featured_image_width' => ['type' => 'object', 'description' => 'Image width'],
        'blog_featured_image_height' => ['type' => 'object', 'description' => 'Image Height'],
        'hover_image_style' => ['type' => 'string', 'description' => 'Image Hover Effect'],
        'featured_image_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'tpae_enable_overlay' => ['type' => 'string', 'description' => 'Enable Overlay', 'enum' => ['yes', 'no']],
        'tpae_overlay_color' => ['type' => 'string', 'description' => 'Overlay Color'],
        'full_image_size' => ['type' => 'string', 'description' => 'Full Image', 'enum' => ['yes', 'no']],
        'full_image_size_min_height' => ['type' => 'object', 'description' => 'Image Height'],
        'button_padding' => ['type' => 'object', 'description' => 'Padding'],
        'btn_text_color' => ['type' => 'string', 'description' => 'Text Color'],
        'button_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['button_style', 'dashed', 'dotted', 'groove', 'none', 'solid', '{{WRAPPER}} .pt_plus_button.button-style-8 .button-link-wrap']],
        'button_border_width' => ['type' => 'object', 'description' => 'Border Width'],
        'button_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'button_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'btn_text_hover_color' => ['type' => 'string', 'description' => 'Text Hover Color'],
        'button_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color'],
        'button_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius'],
        'filter_category_padding' => ['type' => 'object', 'description' => 'Padding'],
        'filter_category_marign' => ['type' => 'object', 'description' => 'Margin'],
        'filters_text_color' => ['type' => 'string', 'description' => 'Filters Text Color'],
        'filter_category_color' => ['type' => 'string', 'description' => 'Category Filter Color'],
        'filter_category_4_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'filter_category_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'filter_category_hover_color' => ['type' => 'string', 'description' => 'Category Filter Color'],
        'filter_category_hover_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'filter_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color'],
        'category_count_color' => ['type' => 'string', 'description' => 'Category Count Color'],
        'category_count_bg_color' => ['type' => 'string', 'description' => 'Count Background Color'],
        'content_inner_padding' => ['type' => 'object', 'description' => 'Padding'],
        'box_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['box_border', '{{WRAPPER}} .blog-list .post-inner-loop .grid-item .blog-list-content,
					{{WRAPPER}} .blog-list .post-inner-loop .grid-item .tpae-compect-blog-wrap,
					{{WRAPPER}} .blog-list .post-inner-loop .grid-item .tpae-preset-blog']],
        'box_border_width' => ['type' => 'object', 'description' => 'Border Width'],
        'box_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'box_border_hover_color' => ['type' => 'string', 'description' => 'Border Color'],
        'border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'carousel_unique_id' => ['type' => 'string', 'description' => 'Unique Carousel ID'],
        'slider_direction' => ['type' => 'string', 'description' => 'Slider Mode', 'enum' => ['horizontal', 'vertical']],
        'carousel_direction' => ['type' => 'string', 'description' => 'Slide Direction', 'enum' => ['ltr', 'rtl']],
        'slide_speed' => ['type' => 'object', 'description' => 'Slide Speed'],
        'slider_desktop_column' => ['type' => 'string', 'description' => 'Desktop Columns'],
        'steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_padding' => ['type' => 'object', 'description' => 'Slide Padding'],
        'slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'multi_drag' => ['type' => 'string', 'description' => 'Multi Drag', 'enum' => ['yes', 'no']],
        'slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'slider_pause_hover' => ['type' => 'string', 'description' => 'Pause On Hover', 'enum' => ['yes', 'no']],
        'slider_adaptive_height' => ['type' => 'string', 'description' => 'Adaptive Height', 'enum' => ['yes', 'no']],
        'slider_animation' => ['type' => 'string', 'description' => 'Animation Type', 'enum' => ['ease', 'linear']],
        'slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed'],
        'slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['slider_dots', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color'],
        'dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color'],
        'dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color'],
        'dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color'],
        'dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding'],
        'hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['slider_arrows', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'slider_arrows', 'slider_arrows_style', 'top-right']],
        'arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color'],
        'arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color'],
        'arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color'],
        'arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color'],
        'outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'slider_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'center_padding' => ['type' => 'object', 'description' => 'Center Padding'],
        'slider_center_effects' => ['type' => 'string', 'description' => 'Center Slide Effects', 'enum' => ['slider_center_mode']],
        'scale_center_slide' => ['type' => 'object', 'description' => 'Center Slide Scale'],
        'scale_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Scale'],
        'opacity_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Opacity'],
        'slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3']],
        'slide_row_top_space' => ['type' => 'object', 'description' => 'Row Top Space'],
        'slider_tablet_column' => ['type' => 'string', 'description' => 'Tablet Columns'],
        'tablet_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_tablet' => ['type' => 'string', 'description' => 'Responsive Tablet', 'enum' => ['yes', 'no']],
        'tablet_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'tablet_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'tablet_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'tablet_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed'],
        'tablet_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['slider_responsive_tablet', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7', 'tablet_slider_dots']],
        'tablet_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color'],
        'tablet_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color'],
        'tablet_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color'],
        'tablet_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color'],
        'tablet_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding'],
        'tablet_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['slider_responsive_tablet', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'tablet_slider_arrows']],
        'tablet_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'slider_responsive_tablet', 'tablet_slider_arrows', 'tablet_slider_arrows_style', 'top-right']],
        'tablet_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color'],
        'tablet_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color'],
        'tablet_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color'],
        'tablet_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color'],
        'tablet_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'tablet_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'tablet_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3', 'slider_responsive_tablet']],
        'tablet_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'tablet_center_padding' => ['type' => 'object', 'description' => 'Center Padding'],
        'slider_mobile_column' => ['type' => 'string', 'description' => 'Mobile Columns'],
        'mobile_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_mobile' => ['type' => 'string', 'description' => 'Responsive Mobile', 'enum' => ['yes', 'no']],
        'mobile_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'mobile_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'mobile_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'mobile_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed'],
        'mobile_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['mobile_slider_dots', 'slider_responsive_mobile', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'mobile_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color'],
        'mobile_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color'],
        'mobile_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color'],
        'mobile_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color'],
        'mobile_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding'],
        'mobile_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['mobile_slider_arrows', 'slider_responsive_mobile', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'mobile_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'mobile_slider_arrows', 'mobile_slider_arrows_style', 'slider_responsive_mobile', 'top-right']],
        'mobile_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color'],
        'mobile_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color'],
        'mobile_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color'],
        'mobile_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color'],
        'mobile_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'mobile_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'mobile_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3', 'slider_responsive_mobile']],
        'mobile_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'mobile_center_padding' => ['type' => 'object', 'description' => 'Center Padding'],
        'pnf_padding' => ['type' => 'object', 'description' => 'Padding'],
        'pnf_color' => ['type' => 'string', 'description' => 'Color'],
        'pnf_br' => ['type' => 'object', 'description' => 'Border Radius'],
        'messy_column' => ['type' => 'string', 'description' => 'Messy Columns'],
        'desktop_column_1' => ['type' => 'object', 'description' => 'Column 1'],
        'desktop_column_2' => ['type' => 'object', 'description' => 'Column 2'],
        'desktop_column_3' => ['type' => 'object', 'description' => 'Column 3'],
        'desktop_column_4' => ['type' => 'object', 'description' => 'Column 4'],
        'desktop_column_5' => ['type' => 'object', 'description' => 'Column 5'],
        'desktop_column_6' => ['type' => 'object', 'description' => 'Column 6'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_pro_blog_listout_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pro_blog_listout_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_pro_blog_listout_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_pro_blog_listout_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-blog-listout';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Blog Listout widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }

$settings = [];
    if (isset($input['blogs_post_listing'])) { $settings['blogs_post_listing'] = sanitize_text_field($input['blogs_post_listing']); }
    if (isset($input['related_post_by'])) { $settings['related_post_by'] = sanitize_text_field($input['related_post_by']); }
    if (isset($input['style'])) { $settings['style'] = sanitize_text_field($input['style']); }
    if (isset($input['layout'])) { $settings['layout'] = sanitize_text_field($input['layout']); }
    if (isset($input['content_alignment'])) { $settings['content_alignment'] = sanitize_text_field($input['content_alignment']); }
    if (isset($input['content_alignment_3'])) { $settings['content_alignment_3'] = sanitize_text_field($input['content_alignment_3']); }
    if (isset($input['style_layout'])) { $settings['style_layout'] = sanitize_text_field($input['style_layout']); }
    if (isset($input['column_min_height'])) { $settings['column_min_height'] = $input['column_min_height']; }
    if (isset($input['content_html'])) { $settings['content_html'] = sanitize_text_field($input['content_html']); }
    if (isset($input['content_css'])) { $settings['content_css'] = sanitize_text_field($input['content_css']); }
    if (isset($input['display_posts'])) { $settings['display_posts'] = sanitize_text_field($input['display_posts']); }
    if (isset($input['post_offset'])) { $settings['post_offset'] = sanitize_text_field($input['post_offset']); }
    if (isset($input['post_category'])) { $settings['post_category'] = sanitize_text_field($input['post_category']); }
    if (isset($input['post_tags'])) { $settings['post_tags'] = sanitize_text_field($input['post_tags']); }
    if (isset($input['ex_cat'])) { $settings['ex_cat'] = sanitize_text_field($input['ex_cat']); }
    if (isset($input['ex_tag'])) { $settings['ex_tag'] = sanitize_text_field($input['ex_tag']); }
    if (isset($input['post_order_by'])) { $settings['post_order_by'] = sanitize_text_field($input['post_order_by']); }
    if (isset($input['post_order'])) { $settings['post_order'] = sanitize_text_field($input['post_order']); }
    if (isset($input['desktop_column'])) { $settings['desktop_column'] = sanitize_text_field($input['desktop_column']); }
    if (isset($input['tablet_column'])) { $settings['tablet_column'] = sanitize_text_field($input['tablet_column']); }
    if (isset($input['mobile_column'])) { $settings['mobile_column'] = sanitize_text_field($input['mobile_column']); }
    if (isset($input['metro_column'])) { $settings['metro_column'] = sanitize_text_field($input['metro_column']); }
    if (isset($input['metro_style_3'])) { $settings['metro_style_3'] = sanitize_text_field($input['metro_style_3']); }
    if (isset($input['metro_custom_col_3'])) { $settings['metro_custom_col_3'] = sanitize_text_field($input['metro_custom_col_3']); }
    if (isset($input['metro_style_4'])) { $settings['metro_style_4'] = sanitize_text_field($input['metro_style_4']); }
    if (isset($input['metro_custom_col_4'])) { $settings['metro_custom_col_4'] = sanitize_text_field($input['metro_custom_col_4']); }
    if (isset($input['metro_style_5'])) { $settings['metro_style_5'] = sanitize_text_field($input['metro_style_5']); }
    if (isset($input['metro_custom_col_5'])) { $settings['metro_custom_col_5'] = sanitize_text_field($input['metro_custom_col_5']); }
    if (isset($input['metro_style_6'])) { $settings['metro_style_6'] = sanitize_text_field($input['metro_style_6']); }
    if (isset($input['metro_custom_col_6'])) { $settings['metro_custom_col_6'] = sanitize_text_field($input['metro_custom_col_6']); }
    if (isset($input['responsive_tablet_metro'])) { $settings['responsive_tablet_metro'] = sanitize_text_field($input['responsive_tablet_metro']); }
    if (isset($input['tablet_metro_column'])) { $settings['tablet_metro_column'] = sanitize_text_field($input['tablet_metro_column']); }
    if (isset($input['tablet_metro_style_3'])) { $settings['tablet_metro_style_3'] = sanitize_text_field($input['tablet_metro_style_3']); }
    if (isset($input['metro_custom_col_tab'])) { $settings['metro_custom_col_tab'] = sanitize_text_field($input['metro_custom_col_tab']); }
    if (isset($input['columns_gap'])) { $settings['columns_gap'] = $input['columns_gap']; }
    if (isset($input['filter_category'])) { $settings['filter_category'] = sanitize_text_field($input['filter_category']); }
    if (isset($input['filter_category_align'])) { $settings['filter_category_align'] = sanitize_text_field($input['filter_category_align']); }
    if (isset($input['TaxonomyType'])) { $settings['TaxonomyType'] = sanitize_text_field($input['TaxonomyType']); }
    if (isset($input['filter_type'])) { $settings['filter_type'] = sanitize_text_field($input['filter_type']); }
    if (isset($input['filter_search_type'])) { $settings['filter_search_type'] = sanitize_text_field($input['filter_search_type']); }
    if (isset($input['all_filter_category_switch'])) { $settings['all_filter_category_switch'] = sanitize_text_field($input['all_filter_category_switch']); }
    if (isset($input['all_filter_category'])) { $settings['all_filter_category'] = sanitize_text_field($input['all_filter_category']); }
    if (isset($input['filter_style'])) { $settings['filter_style'] = sanitize_text_field($input['filter_style']); }
    if (isset($input['filter_hover_style'])) { $settings['filter_hover_style'] = sanitize_text_field($input['filter_hover_style']); }
    if (isset($input['post_extra_option'])) { $settings['post_extra_option'] = sanitize_text_field($input['post_extra_option']); }
    if (isset($input['pagination_next'])) { $settings['pagination_next'] = sanitize_text_field($input['pagination_next']); }
    if (isset($input['pagination_prev'])) { $settings['pagination_prev'] = sanitize_text_field($input['pagination_prev']); }
    if (isset($input['pagination_color'])) { $settings['pagination_color'] = sanitize_text_field($input['pagination_color']); }
    if (isset($input['pagination_hover_color'])) { $settings['pagination_hover_color'] = sanitize_text_field($input['pagination_hover_color']); }
    if (isset($input['load_more_btn_text'])) { $settings['load_more_btn_text'] = sanitize_text_field($input['load_more_btn_text']); }
    if (isset($input['tp_loading_text'])) { $settings['tp_loading_text'] = sanitize_text_field($input['tp_loading_text']); }
    if (isset($input['loaded_posts_text'])) { $settings['loaded_posts_text'] = sanitize_text_field($input['loaded_posts_text']); }
    if (isset($input['load_more_post'])) { $settings['load_more_post'] = sanitize_text_field($input['load_more_post']); }
    if (isset($input['load_more_border'])) { $settings['load_more_border'] = sanitize_text_field($input['load_more_border']); }
    if (isset($input['load_more_border_style'])) { $settings['load_more_border_style'] = sanitize_text_field($input['load_more_border_style']); }
    if (isset($input['load_more_border_width'])) { $settings['load_more_border_width'] = $input['load_more_border_width']; }
    if (isset($input['load_more_border_color'])) { $settings['load_more_border_color'] = sanitize_text_field($input['load_more_border_color']); }
    if (isset($input['load_more_border_radius'])) { $settings['load_more_border_radius'] = $input['load_more_border_radius']; }
    if (isset($input['load_more_border_hover_color'])) { $settings['load_more_border_hover_color'] = sanitize_text_field($input['load_more_border_hover_color']); }
    if (isset($input['load_more_border_hover_radius'])) { $settings['load_more_border_hover_radius'] = $input['load_more_border_hover_radius']; }
    if (isset($input['load_more_color'])) { $settings['load_more_color'] = sanitize_text_field($input['load_more_color']); }
    if (isset($input['loaded_posts_color'])) { $settings['loaded_posts_color'] = sanitize_text_field($input['loaded_posts_color']); }
    if (isset($input['loading_spin_color'])) { $settings['loading_spin_color'] = sanitize_text_field($input['loading_spin_color']); }
    if (isset($input['loading_spin_size'])) { $settings['loading_spin_size'] = $input['loading_spin_size']; }
    if (isset($input['loading_spin_border_size'])) { $settings['loading_spin_border_size'] = $input['loading_spin_border_size']; }
    if (isset($input['load_more_color_hover'])) { $settings['load_more_color_hover'] = sanitize_text_field($input['load_more_color_hover']); }
    if (isset($input['loading_options'])) { $settings['loading_options'] = sanitize_text_field($input['loading_options']); }
    if (isset($input['tp_list_preloader'])) { $settings['tp_list_preloader'] = sanitize_text_field($input['tp_list_preloader']); }
    if (isset($input['tp_list_preloader_hw'])) { $settings['tp_list_preloader_hw'] = $input['tp_list_preloader_hw']; }
    if (isset($input['tp_list_preloader_size'])) { $settings['tp_list_preloader_size'] = $input['tp_list_preloader_size']; }
    if (isset($input['tp_list_preloader_color'])) { $settings['tp_list_preloader_color'] = sanitize_text_field($input['tp_list_preloader_color']); }
    if (isset($input['display_title_limit'])) { $settings['display_title_limit'] = sanitize_text_field($input['display_title_limit']); }
    if (isset($input['display_title_by'])) { $settings['display_title_by'] = sanitize_text_field($input['display_title_by']); }
    if (isset($input['display_title_input'])) { $settings['display_title_input'] = sanitize_text_field($input['display_title_input']); }
    if (isset($input['display_title_3_dots'])) { $settings['display_title_3_dots'] = sanitize_text_field($input['display_title_3_dots']); }
    if (isset($input['filter_url'])) { $settings['filter_url'] = sanitize_text_field($input['filter_url']); }
    if (isset($input['post_title_tag'])) { $settings['post_title_tag'] = sanitize_text_field($input['post_title_tag']); }
    if (isset($input['featured_image_type'])) { $settings['featured_image_type'] = sanitize_text_field($input['featured_image_type']); }
    if (isset($input['title_desc_word_break'])) { $settings['title_desc_word_break'] = sanitize_text_field($input['title_desc_word_break']); }
    if (isset($input['display_post_category'])) { $settings['display_post_category'] = sanitize_text_field($input['display_post_category']); }
    if (isset($input['post_category_style'])) { $settings['post_category_style'] = sanitize_text_field($input['post_category_style']); }
    if (isset($input['display_post_category_all'])) { $settings['display_post_category_all'] = sanitize_text_field($input['display_post_category_all']); }
    if (isset($input['display_excerpt'])) { $settings['display_excerpt'] = sanitize_text_field($input['display_excerpt']); }
    if (isset($input['post_excerpt_count'])) { $settings['post_excerpt_count'] = sanitize_text_field($input['post_excerpt_count']); }
    if (isset($input['show_post_date'])) { $settings['show_post_date'] = sanitize_text_field($input['show_post_date']); }
    if (isset($input['show_post_author'])) { $settings['show_post_author'] = sanitize_text_field($input['show_post_author']); }
    if (isset($input['show_read_time'])) { $settings['show_read_time'] = sanitize_text_field($input['show_read_time']); }
    if (isset($input['display_thumbnail'])) { $settings['display_thumbnail'] = sanitize_text_field($input['display_thumbnail']); }
    if (isset($input['display_post_meta'])) { $settings['display_post_meta'] = sanitize_text_field($input['display_post_meta']); }
    if (isset($input['post_meta_tag_style'])) { $settings['post_meta_tag_style'] = sanitize_text_field($input['post_meta_tag_style']); }
    if (isset($input['author_prefix'])) { $settings['author_prefix'] = sanitize_text_field($input['author_prefix']); }
    if (isset($input['display_post_meta_date'])) { $settings['display_post_meta_date'] = sanitize_text_field($input['display_post_meta_date']); }
    if (isset($input['date_type'])) { $settings['date_type'] = sanitize_text_field($input['date_type']); }
    if (isset($input['display_post_meta_author'])) { $settings['display_post_meta_author'] = sanitize_text_field($input['display_post_meta_author']); }
    if (isset($input['display_post_meta_author_pic'])) { $settings['display_post_meta_author_pic'] = sanitize_text_field($input['display_post_meta_author_pic']); }
    if (isset($input['display_button'])) { $settings['display_button'] = sanitize_text_field($input['display_button']); }
    if (isset($input['button_style'])) { $settings['button_style'] = sanitize_text_field($input['button_style']); }
    if (isset($input['button_text'])) { $settings['button_text'] = sanitize_text_field($input['button_text']); }
    if (isset($input['button_icon_style'])) { $settings['button_icon_style'] = sanitize_text_field($input['button_icon_style']); }
    if (isset($input['button_icon'])) { $settings['button_icon'] = sanitize_text_field($input['button_icon']); }
    if (isset($input['button_icons_mind'])) { $settings['button_icons_mind'] = sanitize_text_field($input['button_icons_mind']); }
    if (isset($input['before_after'])) { $settings['before_after'] = sanitize_text_field($input['before_after']); }
    if (isset($input['icon_spacing'])) { $settings['icon_spacing'] = $input['icon_spacing']; }
    if (isset($input['tpaep_theme_builder'])) { $settings['tpaep_theme_builder'] = sanitize_text_field($input['tpaep_theme_builder']); }
    if (isset($input['post_meta_color'])) { $settings['post_meta_color'] = sanitize_text_field($input['post_meta_color']); }
    if (isset($input['post_meta_color_hover'])) { $settings['post_meta_color_hover'] = sanitize_text_field($input['post_meta_color_hover']); }
    if (isset($input['post_meta_border_color'])) { $settings['post_meta_border_color'] = sanitize_text_field($input['post_meta_border_color']); }
    if (isset($input['blog_card_layout'])) { $settings['blog_card_layout'] = sanitize_text_field($input['blog_card_layout']); }
    if (isset($input['wrap_flex_direction'])) { $settings['wrap_flex_direction'] = $input['wrap_flex_direction']; }
    if (isset($input['tp_row_one_width'])) { $settings['tp_row_one_width'] = $input['tp_row_one_width']; }
    if (isset($input['tp_row_two_width'])) { $settings['tp_row_two_width'] = $input['tp_row_two_width']; }
    if (isset($input['tp_content_alignment'])) { $settings['tp_content_alignment'] = $input['tp_content_alignment']; }
    if (isset($input['tp_item_content_alignment'])) { $settings['tp_item_content_alignment'] = $input['tp_item_content_alignment']; }
    if (isset($input['wrap_gap'])) { $settings['wrap_gap'] = $input['wrap_gap']; }
    if (isset($input['tp_absolute_layout'])) { $settings['tp_absolute_layout'] = sanitize_text_field($input['tp_absolute_layout']); }
    if (isset($input['tp_top_card'])) { $settings['tp_top_card'] = $input['tp_top_card']; }
    if (isset($input['tp_bottom_card'])) { $settings['tp_bottom_card'] = $input['tp_bottom_card']; }
    if (isset($input['tp_width_card'])) { $settings['tp_width_card'] = $input['tp_width_card']; }
    if (isset($input['content_direction'])) { $settings['content_direction'] = $input['content_direction']; }
    if (isset($input['content_vertical_justify'])) { $settings['content_vertical_justify'] = $input['content_vertical_justify']; }
    if (isset($input['blog_content_padding'])) { $settings['blog_content_padding'] = $input['blog_content_padding']; }
    if (isset($input['blog_content_margin'])) { $settings['blog_content_margin'] = $input['blog_content_margin']; }
    if (isset($input['blog_border_post'])) { $settings['blog_border_post'] = sanitize_text_field($input['blog_border_post']); }
    if (isset($input['blog_content_border_radius'])) { $settings['blog_content_border_radius'] = $input['blog_content_border_radius']; }
    if (isset($input['blog_meta_layout_post'])) { $settings['blog_meta_layout_post'] = sanitize_text_field($input['blog_meta_layout_post']); }
    if (isset($input['meta_flex_direction'])) { $settings['meta_flex_direction'] = sanitize_text_field($input['meta_flex_direction']); }
    if (isset($input['meta_align_items'])) { $settings['meta_align_items'] = $input['meta_align_items']; }
    if (isset($input['meta_gap'])) { $settings['meta_gap'] = $input['meta_gap']; }
    if (isset($input['tp_meta_inner_padding'])) { $settings['tp_meta_inner_padding'] = $input['tp_meta_inner_padding']; }
    if (isset($input['tp_meta_border_r'])) { $settings['tp_meta_border_r'] = $input['tp_meta_border_r']; }
    if (isset($input['date_overflow'])) { $settings['date_overflow'] = sanitize_text_field($input['date_overflow']); }
    if (isset($input['category_date_inner_padding'])) { $settings['category_date_inner_padding'] = $input['category_date_inner_padding']; }
    if (isset($input['date_style_margin_tb'])) { $settings['date_style_margin_tb'] = $input['date_style_margin_tb']; }
    if (isset($input['date_style_margin_lr'])) { $settings['date_style_margin_lr'] = $input['date_style_margin_lr']; }
    if (isset($input['overflow_date_br'])) { $settings['overflow_date_br'] = $input['overflow_date_br']; }
    if (isset($input['meta_overflow'])) { $settings['meta_overflow'] = sanitize_text_field($input['meta_overflow']); }
    if (isset($input['category_meta_inner_padding'])) { $settings['category_meta_inner_padding'] = $input['category_meta_inner_padding']; }
    if (isset($input['meta_style_margin_tb'])) { $settings['meta_style_margin_tb'] = $input['meta_style_margin_tb']; }
    if (isset($input['meta_style_margin_lr'])) { $settings['meta_style_margin_lr'] = $input['meta_style_margin_lr']; }
    if (isset($input['overflow_meta_br'])) { $settings['overflow_meta_br'] = $input['overflow_meta_br']; }
    if (isset($input['post_tima_overflow'])) { $settings['post_tima_overflow'] = sanitize_text_field($input['post_tima_overflow']); }
    if (isset($input['category_post_time_inner_padding'])) { $settings['category_post_time_inner_padding'] = $input['category_post_time_inner_padding']; }
    if (isset($input['post_style_margin_tb'])) { $settings['post_style_margin_tb'] = $input['post_style_margin_tb']; }
    if (isset($input['post_style_margin_lr'])) { $settings['post_style_margin_lr'] = $input['post_style_margin_lr']; }
    if (isset($input['overflow_post_time_br'])) { $settings['overflow_post_time_br'] = $input['overflow_post_time_br']; }
    if (isset($input['button_overflow'])) { $settings['button_overflow'] = sanitize_text_field($input['button_overflow']); }
    if (isset($input['button_style_margin_tb'])) { $settings['button_style_margin_tb'] = $input['button_style_margin_tb']; }
    if (isset($input['button_style_margin_lr'])) { $settings['button_style_margin_lr'] = $input['button_style_margin_lr']; }
    if (isset($input['blog_category_post'])) { $settings['blog_category_post'] = sanitize_text_field($input['blog_category_post']); }
    if (isset($input['category_style_margin_tb'])) { $settings['category_style_margin_tb'] = $input['category_style_margin_tb']; }
    if (isset($input['category_style_margin_lr'])) { $settings['category_style_margin_lr'] = $input['category_style_margin_lr']; }
    if (isset($input['category_inner_padding'])) { $settings['category_inner_padding'] = $input['category_inner_padding']; }
    if (isset($input['category_color'])) { $settings['category_color'] = sanitize_text_field($input['category_color']); }
    if (isset($input['category_hover_color'])) { $settings['category_hover_color'] = sanitize_text_field($input['category_hover_color']); }
    if (isset($input['category_2_border_hover_color'])) { $settings['category_2_border_hover_color'] = sanitize_text_field($input['category_2_border_hover_color']); }
    if (isset($input['category_border'])) { $settings['category_border'] = sanitize_text_field($input['category_border']); }
    if (isset($input['category_border_style'])) { $settings['category_border_style'] = sanitize_text_field($input['category_border_style']); }
    if (isset($input['box_category_border_width'])) { $settings['box_category_border_width'] = $input['box_category_border_width']; }
    if (isset($input['category_border_color'])) { $settings['category_border_color'] = sanitize_text_field($input['category_border_color']); }
    if (isset($input['category_border_radius'])) { $settings['category_border_radius'] = $input['category_border_radius']; }
    if (isset($input['category_border_hover_color'])) { $settings['category_border_hover_color'] = sanitize_text_field($input['category_border_hover_color']); }
    if (isset($input['category_border_hover_radius'])) { $settings['category_border_hover_radius'] = $input['category_border_hover_radius']; }
    if (isset($input['s_title_pg'])) { $settings['s_title_pg'] = $input['s_title_pg']; }
    if (isset($input['title_margin'])) { $settings['title_margin'] = $input['title_margin']; }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['title_hover_color'])) { $settings['title_hover_color'] = sanitize_text_field($input['title_hover_color']); }
    if (isset($input['title_boxhover_color'])) { $settings['title_boxhover_color'] = sanitize_text_field($input['title_boxhover_color']); }
    if (isset($input['s_excerpt_content_pg'])) { $settings['s_excerpt_content_pg'] = $input['s_excerpt_content_pg']; }
    if (isset($input['excerpt_margin'])) { $settings['excerpt_margin'] = $input['excerpt_margin']; }
    if (isset($input['excerpt_color'])) { $settings['excerpt_color'] = sanitize_text_field($input['excerpt_color']); }
    if (isset($input['excerpt_hover_color'])) { $settings['excerpt_hover_color'] = sanitize_text_field($input['excerpt_hover_color']); }
    if (isset($input['content_between_space'])) { $settings['content_between_space'] = $input['content_between_space']; }
    if (isset($input['blog_featured_image_width'])) { $settings['blog_featured_image_width'] = $input['blog_featured_image_width']; }
    if (isset($input['blog_featured_image_height'])) { $settings['blog_featured_image_height'] = $input['blog_featured_image_height']; }
    if (isset($input['hover_image_style'])) { $settings['hover_image_style'] = sanitize_text_field($input['hover_image_style']); }
    if (isset($input['featured_image_radius'])) { $settings['featured_image_radius'] = $input['featured_image_radius']; }
    if (isset($input['tpae_enable_overlay'])) { $settings['tpae_enable_overlay'] = sanitize_text_field($input['tpae_enable_overlay']); }
    if (isset($input['tpae_overlay_color'])) { $settings['tpae_overlay_color'] = sanitize_text_field($input['tpae_overlay_color']); }
    if (isset($input['full_image_size'])) { $settings['full_image_size'] = sanitize_text_field($input['full_image_size']); }
    if (isset($input['full_image_size_min_height'])) { $settings['full_image_size_min_height'] = $input['full_image_size_min_height']; }
    if (isset($input['button_padding'])) { $settings['button_padding'] = $input['button_padding']; }
    if (isset($input['btn_text_color'])) { $settings['btn_text_color'] = sanitize_text_field($input['btn_text_color']); }
    if (isset($input['button_border_style'])) { $settings['button_border_style'] = sanitize_text_field($input['button_border_style']); }
    if (isset($input['button_border_width'])) { $settings['button_border_width'] = $input['button_border_width']; }
    if (isset($input['button_border_color'])) { $settings['button_border_color'] = sanitize_text_field($input['button_border_color']); }
    if (isset($input['button_radius'])) { $settings['button_radius'] = $input['button_radius']; }
    if (isset($input['btn_text_hover_color'])) { $settings['btn_text_hover_color'] = sanitize_text_field($input['btn_text_hover_color']); }
    if (isset($input['button_border_hover_color'])) { $settings['button_border_hover_color'] = sanitize_text_field($input['button_border_hover_color']); }
    if (isset($input['button_hover_radius'])) { $settings['button_hover_radius'] = $input['button_hover_radius']; }
    if (isset($input['filter_category_padding'])) { $settings['filter_category_padding'] = $input['filter_category_padding']; }
    if (isset($input['filter_category_marign'])) { $settings['filter_category_marign'] = $input['filter_category_marign']; }
    if (isset($input['filters_text_color'])) { $settings['filters_text_color'] = sanitize_text_field($input['filters_text_color']); }
    if (isset($input['filter_category_color'])) { $settings['filter_category_color'] = sanitize_text_field($input['filter_category_color']); }
    if (isset($input['filter_category_4_border_color'])) { $settings['filter_category_4_border_color'] = sanitize_text_field($input['filter_category_4_border_color']); }
    if (isset($input['filter_category_radius'])) { $settings['filter_category_radius'] = $input['filter_category_radius']; }
    if (isset($input['filter_category_hover_color'])) { $settings['filter_category_hover_color'] = sanitize_text_field($input['filter_category_hover_color']); }
    if (isset($input['filter_category_hover_radius'])) { $settings['filter_category_hover_radius'] = $input['filter_category_hover_radius']; }
    if (isset($input['filter_border_hover_color'])) { $settings['filter_border_hover_color'] = sanitize_text_field($input['filter_border_hover_color']); }
    if (isset($input['category_count_color'])) { $settings['category_count_color'] = sanitize_text_field($input['category_count_color']); }
    if (isset($input['category_count_bg_color'])) { $settings['category_count_bg_color'] = sanitize_text_field($input['category_count_bg_color']); }
    if (isset($input['content_inner_padding'])) { $settings['content_inner_padding'] = $input['content_inner_padding']; }
    if (isset($input['box_border'])) { $settings['box_border'] = sanitize_text_field($input['box_border']); }
    if (isset($input['border_style'])) { $settings['border_style'] = sanitize_text_field($input['border_style']); }
    if (isset($input['box_border_width'])) { $settings['box_border_width'] = $input['box_border_width']; }
    if (isset($input['box_border_color'])) { $settings['box_border_color'] = sanitize_text_field($input['box_border_color']); }
    if (isset($input['border_radius'])) { $settings['border_radius'] = $input['border_radius']; }
    if (isset($input['box_border_hover_color'])) { $settings['box_border_hover_color'] = sanitize_text_field($input['box_border_hover_color']); }
    if (isset($input['border_hover_radius'])) { $settings['border_hover_radius'] = $input['border_hover_radius']; }
    if (isset($input['carousel_unique_id'])) { $settings['carousel_unique_id'] = sanitize_text_field($input['carousel_unique_id']); }
    if (isset($input['slider_direction'])) { $settings['slider_direction'] = sanitize_text_field($input['slider_direction']); }
    if (isset($input['carousel_direction'])) { $settings['carousel_direction'] = sanitize_text_field($input['carousel_direction']); }
    if (isset($input['slide_speed'])) { $settings['slide_speed'] = $input['slide_speed']; }
    if (isset($input['slider_desktop_column'])) { $settings['slider_desktop_column'] = sanitize_text_field($input['slider_desktop_column']); }
    if (isset($input['steps_slide'])) { $settings['steps_slide'] = sanitize_text_field($input['steps_slide']); }
    if (isset($input['slider_padding'])) { $settings['slider_padding'] = $input['slider_padding']; }
    if (isset($input['slider_draggable'])) { $settings['slider_draggable'] = sanitize_text_field($input['slider_draggable']); }
    if (isset($input['multi_drag'])) { $settings['multi_drag'] = sanitize_text_field($input['multi_drag']); }
    if (isset($input['slider_infinite'])) { $settings['slider_infinite'] = sanitize_text_field($input['slider_infinite']); }
    if (isset($input['slider_pause_hover'])) { $settings['slider_pause_hover'] = sanitize_text_field($input['slider_pause_hover']); }
    if (isset($input['slider_adaptive_height'])) { $settings['slider_adaptive_height'] = sanitize_text_field($input['slider_adaptive_height']); }
    if (isset($input['slider_animation'])) { $settings['slider_animation'] = sanitize_text_field($input['slider_animation']); }
    if (isset($input['slider_autoplay'])) { $settings['slider_autoplay'] = sanitize_text_field($input['slider_autoplay']); }
    if (isset($input['autoplay_speed'])) { $settings['autoplay_speed'] = $input['autoplay_speed']; }
    if (isset($input['slider_dots'])) { $settings['slider_dots'] = sanitize_text_field($input['slider_dots']); }
    if (isset($input['slider_dots_style'])) { $settings['slider_dots_style'] = sanitize_text_field($input['slider_dots_style']); }
    if (isset($input['dots_border_color'])) { $settings['dots_border_color'] = sanitize_text_field($input['dots_border_color']); }
    if (isset($input['dots_bg_color'])) { $settings['dots_bg_color'] = sanitize_text_field($input['dots_bg_color']); }
    if (isset($input['dots_active_border_color'])) { $settings['dots_active_border_color'] = sanitize_text_field($input['dots_active_border_color']); }
    if (isset($input['dots_active_bg_color'])) { $settings['dots_active_bg_color'] = sanitize_text_field($input['dots_active_bg_color']); }
    if (isset($input['dots_top_padding'])) { $settings['dots_top_padding'] = $input['dots_top_padding']; }
    if (isset($input['hover_show_dots'])) { $settings['hover_show_dots'] = sanitize_text_field($input['hover_show_dots']); }
    if (isset($input['slider_arrows'])) { $settings['slider_arrows'] = sanitize_text_field($input['slider_arrows']); }
    if (isset($input['slider_arrows_style'])) { $settings['slider_arrows_style'] = sanitize_text_field($input['slider_arrows_style']); }
    if (isset($input['arrows_position'])) { $settings['arrows_position'] = sanitize_text_field($input['arrows_position']); }
    if (isset($input['arrow_bg_color'])) { $settings['arrow_bg_color'] = sanitize_text_field($input['arrow_bg_color']); }
    if (isset($input['arrow_icon_color'])) { $settings['arrow_icon_color'] = sanitize_text_field($input['arrow_icon_color']); }
    if (isset($input['arrow_hover_bg_color'])) { $settings['arrow_hover_bg_color'] = sanitize_text_field($input['arrow_hover_bg_color']); }
    if (isset($input['arrow_hover_icon_color'])) { $settings['arrow_hover_icon_color'] = sanitize_text_field($input['arrow_hover_icon_color']); }
    if (isset($input['outer_section_arrow'])) { $settings['outer_section_arrow'] = sanitize_text_field($input['outer_section_arrow']); }
    if (isset($input['hover_show_arrow'])) { $settings['hover_show_arrow'] = sanitize_text_field($input['hover_show_arrow']); }
    if (isset($input['slider_center_mode'])) { $settings['slider_center_mode'] = sanitize_text_field($input['slider_center_mode']); }
    if (isset($input['center_padding'])) { $settings['center_padding'] = $input['center_padding']; }
    if (isset($input['slider_center_effects'])) { $settings['slider_center_effects'] = sanitize_text_field($input['slider_center_effects']); }
    if (isset($input['scale_center_slide'])) { $settings['scale_center_slide'] = $input['scale_center_slide']; }
    if (isset($input['scale_normal_slide'])) { $settings['scale_normal_slide'] = $input['scale_normal_slide']; }
    if (isset($input['opacity_normal_slide'])) { $settings['opacity_normal_slide'] = $input['opacity_normal_slide']; }
    if (isset($input['slider_rows'])) { $settings['slider_rows'] = sanitize_text_field($input['slider_rows']); }
    if (isset($input['slide_row_top_space'])) { $settings['slide_row_top_space'] = $input['slide_row_top_space']; }
    if (isset($input['slider_tablet_column'])) { $settings['slider_tablet_column'] = sanitize_text_field($input['slider_tablet_column']); }
    if (isset($input['tablet_steps_slide'])) { $settings['tablet_steps_slide'] = sanitize_text_field($input['tablet_steps_slide']); }
    if (isset($input['slider_responsive_tablet'])) { $settings['slider_responsive_tablet'] = sanitize_text_field($input['slider_responsive_tablet']); }
    if (isset($input['tablet_slider_draggable'])) { $settings['tablet_slider_draggable'] = sanitize_text_field($input['tablet_slider_draggable']); }
    if (isset($input['tablet_slider_infinite'])) { $settings['tablet_slider_infinite'] = sanitize_text_field($input['tablet_slider_infinite']); }
    if (isset($input['tablet_slider_autoplay'])) { $settings['tablet_slider_autoplay'] = sanitize_text_field($input['tablet_slider_autoplay']); }
    if (isset($input['tablet_autoplay_speed'])) { $settings['tablet_autoplay_speed'] = $input['tablet_autoplay_speed']; }
    if (isset($input['tablet_slider_dots'])) { $settings['tablet_slider_dots'] = sanitize_text_field($input['tablet_slider_dots']); }
    if (isset($input['tablet_slider_dots_style'])) { $settings['tablet_slider_dots_style'] = sanitize_text_field($input['tablet_slider_dots_style']); }
    if (isset($input['tablet_dots_border_color'])) { $settings['tablet_dots_border_color'] = sanitize_text_field($input['tablet_dots_border_color']); }
    if (isset($input['tablet_dots_bg_color'])) { $settings['tablet_dots_bg_color'] = sanitize_text_field($input['tablet_dots_bg_color']); }
    if (isset($input['tablet_dots_active_border_color'])) { $settings['tablet_dots_active_border_color'] = sanitize_text_field($input['tablet_dots_active_border_color']); }
    if (isset($input['tablet_dots_active_bg_color'])) { $settings['tablet_dots_active_bg_color'] = sanitize_text_field($input['tablet_dots_active_bg_color']); }
    if (isset($input['tablet_dots_top_padding'])) { $settings['tablet_dots_top_padding'] = $input['tablet_dots_top_padding']; }
    if (isset($input['tablet_hover_show_dots'])) { $settings['tablet_hover_show_dots'] = sanitize_text_field($input['tablet_hover_show_dots']); }
    if (isset($input['tablet_slider_arrows'])) { $settings['tablet_slider_arrows'] = sanitize_text_field($input['tablet_slider_arrows']); }
    if (isset($input['tablet_slider_arrows_style'])) { $settings['tablet_slider_arrows_style'] = sanitize_text_field($input['tablet_slider_arrows_style']); }
    if (isset($input['tablet_arrows_position'])) { $settings['tablet_arrows_position'] = sanitize_text_field($input['tablet_arrows_position']); }
    if (isset($input['tablet_arrow_bg_color'])) { $settings['tablet_arrow_bg_color'] = sanitize_text_field($input['tablet_arrow_bg_color']); }
    if (isset($input['tablet_arrow_icon_color'])) { $settings['tablet_arrow_icon_color'] = sanitize_text_field($input['tablet_arrow_icon_color']); }
    if (isset($input['tablet_arrow_hover_bg_color'])) { $settings['tablet_arrow_hover_bg_color'] = sanitize_text_field($input['tablet_arrow_hover_bg_color']); }
    if (isset($input['tablet_arrow_hover_icon_color'])) { $settings['tablet_arrow_hover_icon_color'] = sanitize_text_field($input['tablet_arrow_hover_icon_color']); }
    if (isset($input['tablet_outer_section_arrow'])) { $settings['tablet_outer_section_arrow'] = sanitize_text_field($input['tablet_outer_section_arrow']); }
    if (isset($input['tablet_hover_show_arrow'])) { $settings['tablet_hover_show_arrow'] = sanitize_text_field($input['tablet_hover_show_arrow']); }
    if (isset($input['tablet_slider_rows'])) { $settings['tablet_slider_rows'] = sanitize_text_field($input['tablet_slider_rows']); }
    if (isset($input['tablet_center_mode'])) { $settings['tablet_center_mode'] = sanitize_text_field($input['tablet_center_mode']); }
    if (isset($input['tablet_center_padding'])) { $settings['tablet_center_padding'] = $input['tablet_center_padding']; }
    if (isset($input['slider_mobile_column'])) { $settings['slider_mobile_column'] = sanitize_text_field($input['slider_mobile_column']); }
    if (isset($input['mobile_steps_slide'])) { $settings['mobile_steps_slide'] = sanitize_text_field($input['mobile_steps_slide']); }
    if (isset($input['slider_responsive_mobile'])) { $settings['slider_responsive_mobile'] = sanitize_text_field($input['slider_responsive_mobile']); }
    if (isset($input['mobile_slider_draggable'])) { $settings['mobile_slider_draggable'] = sanitize_text_field($input['mobile_slider_draggable']); }
    if (isset($input['mobile_slider_infinite'])) { $settings['mobile_slider_infinite'] = sanitize_text_field($input['mobile_slider_infinite']); }
    if (isset($input['mobile_slider_autoplay'])) { $settings['mobile_slider_autoplay'] = sanitize_text_field($input['mobile_slider_autoplay']); }
    if (isset($input['mobile_autoplay_speed'])) { $settings['mobile_autoplay_speed'] = $input['mobile_autoplay_speed']; }
    if (isset($input['mobile_slider_dots'])) { $settings['mobile_slider_dots'] = sanitize_text_field($input['mobile_slider_dots']); }
    if (isset($input['mobile_slider_dots_style'])) { $settings['mobile_slider_dots_style'] = sanitize_text_field($input['mobile_slider_dots_style']); }
    if (isset($input['mobile_dots_border_color'])) { $settings['mobile_dots_border_color'] = sanitize_text_field($input['mobile_dots_border_color']); }
    if (isset($input['mobile_dots_bg_color'])) { $settings['mobile_dots_bg_color'] = sanitize_text_field($input['mobile_dots_bg_color']); }
    if (isset($input['mobile_dots_active_border_color'])) { $settings['mobile_dots_active_border_color'] = sanitize_text_field($input['mobile_dots_active_border_color']); }
    if (isset($input['mobile_dots_active_bg_color'])) { $settings['mobile_dots_active_bg_color'] = sanitize_text_field($input['mobile_dots_active_bg_color']); }
    if (isset($input['mobile_dots_top_padding'])) { $settings['mobile_dots_top_padding'] = $input['mobile_dots_top_padding']; }
    if (isset($input['mobile_hover_show_dots'])) { $settings['mobile_hover_show_dots'] = sanitize_text_field($input['mobile_hover_show_dots']); }
    if (isset($input['mobile_slider_arrows'])) { $settings['mobile_slider_arrows'] = sanitize_text_field($input['mobile_slider_arrows']); }
    if (isset($input['mobile_slider_arrows_style'])) { $settings['mobile_slider_arrows_style'] = sanitize_text_field($input['mobile_slider_arrows_style']); }
    if (isset($input['mobile_arrows_position'])) { $settings['mobile_arrows_position'] = sanitize_text_field($input['mobile_arrows_position']); }
    if (isset($input['mobile_arrow_bg_color'])) { $settings['mobile_arrow_bg_color'] = sanitize_text_field($input['mobile_arrow_bg_color']); }
    if (isset($input['mobile_arrow_icon_color'])) { $settings['mobile_arrow_icon_color'] = sanitize_text_field($input['mobile_arrow_icon_color']); }
    if (isset($input['mobile_arrow_hover_bg_color'])) { $settings['mobile_arrow_hover_bg_color'] = sanitize_text_field($input['mobile_arrow_hover_bg_color']); }
    if (isset($input['mobile_arrow_hover_icon_color'])) { $settings['mobile_arrow_hover_icon_color'] = sanitize_text_field($input['mobile_arrow_hover_icon_color']); }
    if (isset($input['mobile_outer_section_arrow'])) { $settings['mobile_outer_section_arrow'] = sanitize_text_field($input['mobile_outer_section_arrow']); }
    if (isset($input['mobile_hover_show_arrow'])) { $settings['mobile_hover_show_arrow'] = sanitize_text_field($input['mobile_hover_show_arrow']); }
    if (isset($input['mobile_slider_rows'])) { $settings['mobile_slider_rows'] = sanitize_text_field($input['mobile_slider_rows']); }
    if (isset($input['mobile_center_mode'])) { $settings['mobile_center_mode'] = sanitize_text_field($input['mobile_center_mode']); }
    if (isset($input['mobile_center_padding'])) { $settings['mobile_center_padding'] = $input['mobile_center_padding']; }
    if (isset($input['pnf_padding'])) { $settings['pnf_padding'] = $input['pnf_padding']; }
    if (isset($input['pnf_color'])) { $settings['pnf_color'] = sanitize_text_field($input['pnf_color']); }
    if (isset($input['pnf_br'])) { $settings['pnf_br'] = $input['pnf_br']; }
    if (isset($input['messy_column'])) { $settings['messy_column'] = sanitize_text_field($input['messy_column']); }
    if (isset($input['desktop_column_1'])) { $settings['desktop_column_1'] = $input['desktop_column_1']; }
    if (isset($input['desktop_column_2'])) { $settings['desktop_column_2'] = $input['desktop_column_2']; }
    if (isset($input['desktop_column_3'])) { $settings['desktop_column_3'] = $input['desktop_column_3']; }
    if (isset($input['desktop_column_4'])) { $settings['desktop_column_4'] = $input['desktop_column_4']; }
    if (isset($input['desktop_column_5'])) { $settings['desktop_column_5'] = $input['desktop_column_5']; }
    if (isset($input['desktop_column_6'])) { $settings['desktop_column_6'] = $input['desktop_column_6']; }

    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
