<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-dynamic-device', [
'label' => __('Dynamic Device', 'theplus'),
    'description' => __('Adds The Plus "Dynamic Device" widget (tp-dynamic-device) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'       => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'     => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'      => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'device_mode' => ['type' => 'string', 'description' => 'Layout', 'enum' => ['carousal', 'normal']],
        'device_mockup' => ['type' => 'string', 'description' => 'Type', 'enum' => ['custom', 'desktop', 'device_mode', 'icon', 'laptop', 'mobile', 'tablet', 'toggle']],
        'custom_image' => ['type' => 'integer', 'description' => 'Custom Mockup (Image ID)'],
        'device_mockup_carousal' => ['type' => 'string', 'description' => 'Type', 'enum' => ['custom', 'desktop', 'device_mode', 'laptop', 'mobile', 'toggle']],
        'device_mockup_carousal_image' => ['type' => 'integer', 'description' => 'Media Image (Image ID)'],
        'device_mobile' => ['type' => 'string', 'description' => 'Mobile Device', 'enum' => ['device_mockup', 'device_mode', 'iphone-browser', 'iphone-minimal', 'iphone-minimal-white', 'iphone-white-flat', 'iphone-x-black', 's9-black', 's9-jet-black', 's9-white']],
        'device_mobile_carousal' => ['type' => 'string', 'description' => 'Mobile Device', 'enum' => ['device_mockup_carousal', 'device_mode', 'iphone-browser', 'iphone-minimal', 'iphone-minimal-white', 'iphone-white-flat-carousal', 'iphone-x-black', 's9-black', 's9-jet-black', 's9-white']],
        'device_tablet' => ['type' => 'string', 'description' => 'Tablet Device', 'enum' => ['device_mockup', 'device_mode', 'ipad-browser', 'ipad-horizontal-white', 'ipad-vertical-white']],
        'device_laptop' => ['type' => 'string', 'description' => 'Laptop Device', 'enum' => ['device_mockup', 'device_mode', 'laptop-macbook-black', 'laptop-macbook-minimal', 'laptop-macbook-white', 'laptop-macbook-white-minimal', 'laptop-windows']],
        'device_desktop' => ['type' => 'string', 'description' => 'Desktop Device', 'enum' => ['desktop-imac-minimal', 'device_mockup', 'device_mode']],
        'device_laptop_carousal' => ['type' => 'string', 'description' => 'Laptop Device', 'enum' => ['device_mockup_carousal', 'device_mode', 'laptop-macbook-black', 'laptop-macbook-minimal', 'laptop-macbook-white', 'laptop-macbook-white-minimal', 'laptop-windows']],
        'device_desktop_carousal' => ['type' => 'string', 'description' => 'Desktop Device', 'enum' => ['desktop-imac-minimal', 'device_mockup_carousal', 'device_mode']],
        'content_type' => ['type' => 'string', 'description' => 'Content', 'enum' => ['device_mode', 'iframe', 'template']],
        'iframe_link' => ['type' => 'object', 'description' => 'iframe_link'],
        'media_image' => ['type' => 'integer', 'description' => 'media_image (Image ID)'],
        'content_template' => ['type' => 'string', 'description' => 'content_template', 'enum' => ['content_type', 'device_mode']],
        'slider_gallery' => ['type' => 'string', 'description' => 'slider_gallery'],
        'device_link_popup' => ['type' => 'string', 'description' => 'Select Link/Popup', 'enum' => ['content_type', 'device_mode', 'link', 'popup']],
        'device_link' => ['type' => 'object', 'description' => 'Link'],
        'icon_show' => ['type' => 'string', 'description' => 'Show Icon', 'enum' => ['yes', 'no']],
        'icon_image' => ['type' => 'integer', 'description' => 'Upload Icon (Image ID)'],
        'icon_continuous_animation' => ['type' => 'string', 'description' => 'Continuous Animation', 'enum' => ['yes', 'no']],
        'icon_animation_effect' => ['type' => 'string', 'description' => 'Animation Effect', 'enum' => ['drop_waves', 'floating', 'icon_continuous_animation', 'pulse', 'render_type', 'rotating', 'tossing']],
        'icon_animation_hover' => ['type' => 'string', 'description' => 'Hover Animation', 'enum' => ['yes', 'no']],
        'icon_animation_duration' => ['type' => 'object', 'description' => 'Duration Time (Slider/Size Object)'],
        'icon_transform_origin' => ['type' => 'string', 'description' => 'Transform Origin', 'enum' => ['bottom center', 'bottom left', 'bottom right', 'center center', 'center left', 'center right', 'icon_animation_effect', 'icon_continuous_animation', 'render_type', 'top left', 'top right', '{{WRAPPER}} .plus-device-wrapper .plus-device-icon .plus-device-icon-inner']],
        'drop_waves_color' => ['type' => 'string', 'description' => 'Drop Wave Color (Color Hex/RGBA)'],
        'icon_radius' => ['type' => 'object', 'description' => 'Icon Radius (Dimensions Object)'],
        'icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'carousal_columns' => ['type' => 'string', 'description' => 'Carousal Column', 'enum' => ['multiple', 'single']],
        'carousal_infinite' => ['type' => 'string', 'description' => 'Infinite', 'enum' => ['yes', 'no']],
        'carousal_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'carousal_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'carousal_speed' => ['type' => 'object', 'description' => 'Slide Speed (Slider/Size Object)'],
        'carousal_dots' => ['type' => 'string', 'description' => 'Dots', 'enum' => ['yes', 'no']],
        'carousal_arrows' => ['type' => 'string', 'description' => 'Arrows', 'enum' => ['yes', 'no']],
        'carousal_slide_gap' => ['type' => 'object', 'description' => 'Slide Gap/Space (Slider/Size Object)'],
        'carousal_slide_margin' => ['type' => 'object', 'description' => 'List Margin (Dimensions Object)'],
        'carousal_slide_vertical' => ['type' => 'object', 'description' => 'Adjust Slide Space (Slider/Size Object)'],
        'carousal_width' => ['type' => 'object', 'description' => 'Carousal Width (Slider/Size Object)'],
        'carousal_mockup_width' => ['type' => 'object', 'description' => 'Mockup Width (Slider/Size Object)'],
        'carousal_mockup_height' => ['type' => 'object', 'description' => 'Mockup Height (Slider/Size Object)'],
        'carousal_mockup_top_offset' => ['type' => 'object', 'description' => 'Mockup Offset (Slider/Size Object)'],
        'mockup_zindex' => ['type' => 'string', 'description' => 'Z-Index'],
        'slide_opacity_normal' => ['type' => 'object', 'description' => 'Slide Opacity (Slider/Size Object)'],
        'slide_opacity_scale' => ['type' => 'object', 'description' => 'Slide Scale (Slider/Size Object)'],
        'slide_opacity_hover' => ['type' => 'object', 'description' => 'Slide Hover Opacity (Slider/Size Object)'],
        'cd_font_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'cd_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'cd_font_size_ah' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'cd_color_ah' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'cd_gap' => ['type' => 'object', 'description' => 'Gap (Slider/Size Object)'],
        'cd_offset' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'ca_offset' => ['type' => 'object', 'description' => 'Gap (Slider/Size Object)'],
        'ca_offset_up_down' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'ca_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'ca_bg_size' => ['type' => 'object', 'description' => 'Background Size (Slider/Size Object)'],
        'can_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'can_background' => ['type' => 'string', 'description' => 'Background (Color Hex/RGBA)'],
        'can_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'cah_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'cah_background' => ['type' => 'string', 'description' => 'Background (Color Hex/RGBA)'],
        'cah_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'device_width' => ['type' => 'object', 'description' => 'Width Adjust(%) (Slider/Size Object)'],
        'device_alignment' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['devices', 'icon', 'left', 'right', 'unset', '{{WRAPPER}} .plus-device-wrapper']],
        'device_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'device_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'scroll_image_effect' => ['type' => 'string', 'description' => 'Scroll Image', 'enum' => ['yes', 'no']],
        'scroll_image_effect_manual' => ['type' => 'string', 'description' => 'Manual Scroll', 'enum' => ['yes', 'no']],
        'scroll_image_effect_manual_image' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'transition_duration' => ['type' => 'object', 'description' => 'transition_duration (Slider/Size Object)'],
        'dd_unique_id' => ['type' => 'string', 'description' => 'Dynamic Device Connection ID'],
        'drop_shadow' => ['type' => 'string', 'description' => 'drop_shadow', 'enum' => ['yes', 'no']],
        'dd_ds_x' => ['type' => 'object', 'description' => 'X (Slider/Size Object)'],
        'dd_ds_y' => ['type' => 'object', 'description' => 'Y (Slider/Size Object)'],
        'dd_ds_blur' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'dd_ds_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'drop_shadow_h' => ['type' => 'string', 'description' => 'drop_shadow_h', 'enum' => ['yes', 'no']],
        'dd_ds_x_h' => ['type' => 'object', 'description' => 'X (Slider/Size Object)'],
        'dd_ds_y_h' => ['type' => 'object', 'description' => 'Y (Slider/Size Object)'],
        'dd_ds_blur_h' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'dd_ds_color_h' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'image_border_radius_slide' => ['type' => 'object', 'description' => 'Image Border Radius (Dimensions Object)'],
        'cimage_width' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'cimage_height' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'cimage_offset' => ['type' => 'object', 'description' => 'Top Offset (Slider/Size Object)'],
        'cimage_l_offset' => ['type' => 'object', 'description' => 'Left Offset (Slider/Size Object)'],
        'cmedia_transform' => ['type' => 'string', 'description' => 'Transform', 'enum' => ['yes', 'no']],
        'ctransform_x' => ['type' => 'object', 'description' => 'X (Slider/Size Object)'],
        'ctransform_y' => ['type' => 'object', 'description' => 'Y (Slider/Size Object)'],
        'ctransform_rotate' => ['type' => 'object', 'description' => 'Rotate (Slider/Size Object)'],
        'image_zindex_slide' => ['type' => 'string', 'description' => 'Z-Index'],
        'image_border_radius' => ['type' => 'object', 'description' => 'Image Border Radius (Dimensions Object)'],
        'image_outer_border_radius' => ['type' => 'object', 'description' => 'Scroll Image Outer Border Radius (Dimensions Object)'],
        'image_width' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'image_height' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'image_offset' => ['type' => 'object', 'description' => 'Top Offset (Slider/Size Object)'],
        'image_l_offset' => ['type' => 'object', 'description' => 'Left Offset (Slider/Size Object)'],
        'image_s_width' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'image_s_height' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'image_s_offset' => ['type' => 'object', 'description' => 'Top Offset (Slider/Size Object)'],
        'image_s_l_offset' => ['type' => 'object', 'description' => 'Left Offset (Slider/Size Object)'],
        'image_zindex' => ['type' => 'string', 'description' => 'Z-Index'],
        'media_transform' => ['type' => 'string', 'description' => 'Transform', 'enum' => ['yes', 'no']],
        'transform_x' => ['type' => 'object', 'description' => 'X (Slider/Size Object)'],
        'transform_y' => ['type' => 'object', 'description' => 'Y (Slider/Size Object)'],
        'transform_rotate' => ['type' => 'object', 'description' => 'Rotate (Slider/Size Object)'],
        'template_width' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'template_height' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'template_offset' => ['type' => 'object', 'description' => 'Top Offset (Slider/Size Object)'],
        'template_l_offset' => ['type' => 'object', 'description' => 'Left Offset (Slider/Size Object)'],
        'template_zindex' => ['type' => 'string', 'description' => 'Z-Index'],
        'scroll_template_effect' => ['type' => 'string', 'description' => 'On Hover Scroll', 'enum' => ['yes', 'no']],
        'temp_transition_duration' => ['type' => 'object', 'description' => 'Transition Duration (Slider/Size Object)'],
        'scroll_scrollbar_width' => ['type' => 'object', 'description' => 'ScrollBar Width (Slider/Size Object)'],
        'scroll_thumb_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'scroll_track_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_dynamic_device_ability',
    'permission_callback' => 'tpaep_mcp_theplus_dynamic_device_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_dynamic_device_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_dynamic_device_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-dynamic-device';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Dynamic Device widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['device_mode'])) { $settings['device_mode'] = sanitize_text_field($input['device_mode']); }
    if (isset($input['device_mockup'])) { $settings['device_mockup'] = sanitize_text_field($input['device_mockup']); }
    if (!empty($input['custom_image'])) { $settings['custom_image'] = ['id' => absint($input['custom_image'])]; }
    if (isset($input['device_mockup_carousal'])) { $settings['device_mockup_carousal'] = sanitize_text_field($input['device_mockup_carousal']); }
    if (!empty($input['device_mockup_carousal_image'])) { $settings['device_mockup_carousal_image'] = ['id' => absint($input['device_mockup_carousal_image'])]; }
    if (isset($input['device_mobile'])) { $settings['device_mobile'] = sanitize_text_field($input['device_mobile']); }
    if (isset($input['device_mobile_carousal'])) { $settings['device_mobile_carousal'] = sanitize_text_field($input['device_mobile_carousal']); }
    if (isset($input['device_tablet'])) { $settings['device_tablet'] = sanitize_text_field($input['device_tablet']); }
    if (isset($input['device_laptop'])) { $settings['device_laptop'] = sanitize_text_field($input['device_laptop']); }
    if (isset($input['device_desktop'])) { $settings['device_desktop'] = sanitize_text_field($input['device_desktop']); }
    if (isset($input['device_laptop_carousal'])) { $settings['device_laptop_carousal'] = sanitize_text_field($input['device_laptop_carousal']); }
    if (isset($input['device_desktop_carousal'])) { $settings['device_desktop_carousal'] = sanitize_text_field($input['device_desktop_carousal']); }
    if (isset($input['content_type'])) { $settings['content_type'] = sanitize_text_field($input['content_type']); }
    if (isset($input['iframe_link'])) { $settings['iframe_link'] = $input['iframe_link']; }
    if (!empty($input['media_image'])) { $settings['media_image'] = ['id' => absint($input['media_image'])]; }
    if (isset($input['content_template'])) { $settings['content_template'] = sanitize_text_field($input['content_template']); }
    if (isset($input['slider_gallery'])) { $settings['slider_gallery'] = sanitize_text_field($input['slider_gallery']); }
    if (isset($input['device_link_popup'])) { $settings['device_link_popup'] = sanitize_text_field($input['device_link_popup']); }
    if (isset($input['device_link'])) { $settings['device_link'] = $input['device_link']; }
    if (isset($input['icon_show'])) { $settings['icon_show'] = sanitize_text_field($input['icon_show']); }
    if (!empty($input['icon_image'])) { $settings['icon_image'] = ['id' => absint($input['icon_image'])]; }
    if (isset($input['icon_continuous_animation'])) { $settings['icon_continuous_animation'] = sanitize_text_field($input['icon_continuous_animation']); }
    if (isset($input['icon_animation_effect'])) { $settings['icon_animation_effect'] = sanitize_text_field($input['icon_animation_effect']); }
    if (isset($input['icon_animation_hover'])) { $settings['icon_animation_hover'] = sanitize_text_field($input['icon_animation_hover']); }
    if (isset($input['icon_animation_duration'])) { $settings['icon_animation_duration'] = $input['icon_animation_duration']; }
    if (isset($input['icon_transform_origin'])) { $settings['icon_transform_origin'] = sanitize_text_field($input['icon_transform_origin']); }
    if (isset($input['drop_waves_color'])) { $settings['drop_waves_color'] = sanitize_text_field($input['drop_waves_color']); }
    if (isset($input['icon_radius'])) { $settings['icon_radius'] = $input['icon_radius']; }
    if (isset($input['icon_size'])) { $settings['icon_size'] = $input['icon_size']; }
    if (isset($input['carousal_columns'])) { $settings['carousal_columns'] = sanitize_text_field($input['carousal_columns']); }
    if (isset($input['carousal_infinite'])) { $settings['carousal_infinite'] = sanitize_text_field($input['carousal_infinite']); }
    if (isset($input['carousal_autoplay'])) { $settings['carousal_autoplay'] = sanitize_text_field($input['carousal_autoplay']); }
    if (isset($input['carousal_autoplay_speed'])) { $settings['carousal_autoplay_speed'] = $input['carousal_autoplay_speed']; }
    if (isset($input['carousal_speed'])) { $settings['carousal_speed'] = $input['carousal_speed']; }
    if (isset($input['carousal_dots'])) { $settings['carousal_dots'] = sanitize_text_field($input['carousal_dots']); }
    if (isset($input['carousal_arrows'])) { $settings['carousal_arrows'] = sanitize_text_field($input['carousal_arrows']); }
    if (isset($input['carousal_slide_gap'])) { $settings['carousal_slide_gap'] = $input['carousal_slide_gap']; }
    if (isset($input['carousal_slide_margin'])) { $settings['carousal_slide_margin'] = $input['carousal_slide_margin']; }
    if (isset($input['carousal_slide_vertical'])) { $settings['carousal_slide_vertical'] = $input['carousal_slide_vertical']; }
    if (isset($input['carousal_width'])) { $settings['carousal_width'] = $input['carousal_width']; }
    if (isset($input['carousal_mockup_width'])) { $settings['carousal_mockup_width'] = $input['carousal_mockup_width']; }
    if (isset($input['carousal_mockup_height'])) { $settings['carousal_mockup_height'] = $input['carousal_mockup_height']; }
    if (isset($input['carousal_mockup_top_offset'])) { $settings['carousal_mockup_top_offset'] = $input['carousal_mockup_top_offset']; }
    if (isset($input['mockup_zindex'])) { $settings['mockup_zindex'] = sanitize_text_field($input['mockup_zindex']); }
    if (isset($input['slide_opacity_normal'])) { $settings['slide_opacity_normal'] = $input['slide_opacity_normal']; }
    if (isset($input['slide_opacity_scale'])) { $settings['slide_opacity_scale'] = $input['slide_opacity_scale']; }
    if (isset($input['slide_opacity_hover'])) { $settings['slide_opacity_hover'] = $input['slide_opacity_hover']; }
    if (isset($input['cd_font_size'])) { $settings['cd_font_size'] = $input['cd_font_size']; }
    if (isset($input['cd_color'])) { $settings['cd_color'] = sanitize_text_field($input['cd_color']); }
    if (isset($input['cd_font_size_ah'])) { $settings['cd_font_size_ah'] = $input['cd_font_size_ah']; }
    if (isset($input['cd_color_ah'])) { $settings['cd_color_ah'] = sanitize_text_field($input['cd_color_ah']); }
    if (isset($input['cd_gap'])) { $settings['cd_gap'] = $input['cd_gap']; }
    if (isset($input['cd_offset'])) { $settings['cd_offset'] = $input['cd_offset']; }
    if (isset($input['ca_offset'])) { $settings['ca_offset'] = $input['ca_offset']; }
    if (isset($input['ca_offset_up_down'])) { $settings['ca_offset_up_down'] = $input['ca_offset_up_down']; }
    if (isset($input['ca_icon_size'])) { $settings['ca_icon_size'] = $input['ca_icon_size']; }
    if (isset($input['ca_bg_size'])) { $settings['ca_bg_size'] = $input['ca_bg_size']; }
    if (isset($input['can_color'])) { $settings['can_color'] = sanitize_text_field($input['can_color']); }
    if (isset($input['can_background'])) { $settings['can_background'] = sanitize_text_field($input['can_background']); }
    if (isset($input['can_br'])) { $settings['can_br'] = $input['can_br']; }
    if (isset($input['cah_color'])) { $settings['cah_color'] = sanitize_text_field($input['cah_color']); }
    if (isset($input['cah_background'])) { $settings['cah_background'] = sanitize_text_field($input['cah_background']); }
    if (isset($input['cah_br'])) { $settings['cah_br'] = $input['cah_br']; }
    if (isset($input['device_width'])) { $settings['device_width'] = $input['device_width']; }
    if (isset($input['device_alignment'])) { $settings['device_alignment'] = $input['device_alignment']; }
    if (isset($input['device_margin'])) { $settings['device_margin'] = $input['device_margin']; }
    if (isset($input['device_padding'])) { $settings['device_padding'] = $input['device_padding']; }
    if (isset($input['scroll_image_effect'])) { $settings['scroll_image_effect'] = sanitize_text_field($input['scroll_image_effect']); }
    if (isset($input['scroll_image_effect_manual'])) { $settings['scroll_image_effect_manual'] = sanitize_text_field($input['scroll_image_effect_manual']); }
    if (isset($input['scroll_image_effect_manual_image'])) { $settings['scroll_image_effect_manual_image'] = $input['scroll_image_effect_manual_image']; }
    if (isset($input['transition_duration'])) { $settings['transition_duration'] = $input['transition_duration']; }
    if (isset($input['dd_unique_id'])) { $settings['dd_unique_id'] = sanitize_text_field($input['dd_unique_id']); }
    if (isset($input['drop_shadow'])) { $settings['drop_shadow'] = sanitize_text_field($input['drop_shadow']); }
    if (isset($input['dd_ds_x'])) { $settings['dd_ds_x'] = $input['dd_ds_x']; }
    if (isset($input['dd_ds_y'])) { $settings['dd_ds_y'] = $input['dd_ds_y']; }
    if (isset($input['dd_ds_blur'])) { $settings['dd_ds_blur'] = $input['dd_ds_blur']; }
    if (isset($input['dd_ds_color'])) { $settings['dd_ds_color'] = sanitize_text_field($input['dd_ds_color']); }
    if (isset($input['drop_shadow_h'])) { $settings['drop_shadow_h'] = sanitize_text_field($input['drop_shadow_h']); }
    if (isset($input['dd_ds_x_h'])) { $settings['dd_ds_x_h'] = $input['dd_ds_x_h']; }
    if (isset($input['dd_ds_y_h'])) { $settings['dd_ds_y_h'] = $input['dd_ds_y_h']; }
    if (isset($input['dd_ds_blur_h'])) { $settings['dd_ds_blur_h'] = $input['dd_ds_blur_h']; }
    if (isset($input['dd_ds_color_h'])) { $settings['dd_ds_color_h'] = sanitize_text_field($input['dd_ds_color_h']); }
    if (isset($input['image_border_radius_slide'])) { $settings['image_border_radius_slide'] = $input['image_border_radius_slide']; }
    if (isset($input['cimage_width'])) { $settings['cimage_width'] = $input['cimage_width']; }
    if (isset($input['cimage_height'])) { $settings['cimage_height'] = $input['cimage_height']; }
    if (isset($input['cimage_offset'])) { $settings['cimage_offset'] = $input['cimage_offset']; }
    if (isset($input['cimage_l_offset'])) { $settings['cimage_l_offset'] = $input['cimage_l_offset']; }
    if (isset($input['cmedia_transform'])) { $settings['cmedia_transform'] = sanitize_text_field($input['cmedia_transform']); }
    if (isset($input['ctransform_x'])) { $settings['ctransform_x'] = $input['ctransform_x']; }
    if (isset($input['ctransform_y'])) { $settings['ctransform_y'] = $input['ctransform_y']; }
    if (isset($input['ctransform_rotate'])) { $settings['ctransform_rotate'] = $input['ctransform_rotate']; }
    if (isset($input['image_zindex_slide'])) { $settings['image_zindex_slide'] = sanitize_text_field($input['image_zindex_slide']); }
    if (isset($input['image_border_radius'])) { $settings['image_border_radius'] = $input['image_border_radius']; }
    if (isset($input['image_outer_border_radius'])) { $settings['image_outer_border_radius'] = $input['image_outer_border_radius']; }
    if (isset($input['image_width'])) { $settings['image_width'] = $input['image_width']; }
    if (isset($input['image_height'])) { $settings['image_height'] = $input['image_height']; }
    if (isset($input['image_offset'])) { $settings['image_offset'] = $input['image_offset']; }
    if (isset($input['image_l_offset'])) { $settings['image_l_offset'] = $input['image_l_offset']; }
    if (isset($input['image_s_width'])) { $settings['image_s_width'] = $input['image_s_width']; }
    if (isset($input['image_s_height'])) { $settings['image_s_height'] = $input['image_s_height']; }
    if (isset($input['image_s_offset'])) { $settings['image_s_offset'] = $input['image_s_offset']; }
    if (isset($input['image_s_l_offset'])) { $settings['image_s_l_offset'] = $input['image_s_l_offset']; }
    if (isset($input['image_zindex'])) { $settings['image_zindex'] = sanitize_text_field($input['image_zindex']); }
    if (isset($input['media_transform'])) { $settings['media_transform'] = sanitize_text_field($input['media_transform']); }
    if (isset($input['transform_x'])) { $settings['transform_x'] = $input['transform_x']; }
    if (isset($input['transform_y'])) { $settings['transform_y'] = $input['transform_y']; }
    if (isset($input['transform_rotate'])) { $settings['transform_rotate'] = $input['transform_rotate']; }
    if (isset($input['template_width'])) { $settings['template_width'] = $input['template_width']; }
    if (isset($input['template_height'])) { $settings['template_height'] = $input['template_height']; }
    if (isset($input['template_offset'])) { $settings['template_offset'] = $input['template_offset']; }
    if (isset($input['template_l_offset'])) { $settings['template_l_offset'] = $input['template_l_offset']; }
    if (isset($input['template_zindex'])) { $settings['template_zindex'] = sanitize_text_field($input['template_zindex']); }
    if (isset($input['scroll_template_effect'])) { $settings['scroll_template_effect'] = sanitize_text_field($input['scroll_template_effect']); }
    if (isset($input['temp_transition_duration'])) { $settings['temp_transition_duration'] = $input['temp_transition_duration']; }
    if (isset($input['scroll_scrollbar_width'])) { $settings['scroll_scrollbar_width'] = $input['scroll_scrollbar_width']; }
    if (isset($input['scroll_thumb_border_radius'])) { $settings['scroll_thumb_border_radius'] = $input['scroll_thumb_border_radius']; }
    if (isset($input['scroll_track_border_radius'])) { $settings['scroll_track_border_radius'] = $input['scroll_track_border_radius']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
