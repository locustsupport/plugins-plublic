<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-cascading-image', [
'label' => __('Cascading Image', 'theplus'),
    'description' => __('Adds The Plus "Cascading Image" widget (tp-cascading-image) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'   => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'  => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'd_left_auto' => ['type' => 'string', 'description' => 'Left (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_xposition' => ['type' => 'object', 'description' => 'Left'],
        'd_right_auto' => ['type' => 'string', 'description' => 'Right (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_rightposition' => ['type' => 'object', 'description' => 'Right'],
        'd_top_auto' => ['type' => 'string', 'description' => 'Top (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_yposition' => ['type' => 'object', 'description' => 'Top'],
        'd_bottom_auto' => ['type' => 'string', 'description' => 'Bottom (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_bottomposition' => ['type' => 'object', 'description' => 'Bottom'],
        'd_pos_width' => ['type' => 'object', 'description' => 'Width'],
        't_responsive' => ['type' => 'string', 'description' => 'Responsive Values', 'enum' => ['yes', 'no']],
        't_left_auto' => ['type' => 'string', 'description' => 'Left (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_xposition' => ['type' => 'object', 'description' => 'Left'],
        't_right_auto' => ['type' => 'string', 'description' => 'Right (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_rightposition' => ['type' => 'object', 'description' => 'Right'],
        't_top_auto' => ['type' => 'string', 'description' => 'Top (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_yposition' => ['type' => 'object', 'description' => 'Top'],
        't_bottom_auto' => ['type' => 'string', 'description' => 'Bottom (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_bottomposition' => ['type' => 'object', 'description' => 'Bottom'],
        't_pos_width' => ['type' => 'object', 'description' => 'Width'],
        'm_responsive' => ['type' => 'string', 'description' => 'Responsive Values', 'enum' => ['yes', 'no']],
        'm_left_auto' => ['type' => 'string', 'description' => 'Left (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_xposition' => ['type' => 'object', 'description' => 'Left'],
        'm_right_auto' => ['type' => 'string', 'description' => 'Right (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_rightposition' => ['type' => 'object', 'description' => 'Right'],
        'm_top_auto' => ['type' => 'string', 'description' => 'Top (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_yposition' => ['type' => 'object', 'description' => 'Top'],
        'm_bottom_auto' => ['type' => 'string', 'description' => 'Bottom (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_bottomposition' => ['type' => 'object', 'description' => 'Bottom'],
        'm_pos_width' => ['type' => 'object', 'description' => 'Width'],
        'select_option' => ['type' => 'string', 'description' => 'Layer Type', 'enum' => ['lottie', 'text']],
        'lottieUrl' => ['type' => 'object', 'description' => 'Lottie URL'],
        'multiple_image' => ['type' => 'integer', 'description' => 'Image Select'],
        'text_content' => ['type' => 'string', 'description' => 'Text Content'],
        'text_content_color' => ['type' => 'string', 'description' => 'Text Color'],
        'text_content_hover_color' => ['type' => 'string', 'description' => 'Text Hover Color'],
        'text_content_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'image_effect' => ['type' => 'string', 'description' => 'Continues Effect', 'enum' => ['continue-scale', 'drop-waves', 'floating', 'hover-drop-waves', 'hover-scale', 'pulse', 'rotate-continue', 'select_option', 'tossing']],
        'drop_waves_color' => ['type' => 'string', 'description' => 'Drop Wave Color'],
        'mask_image_display' => ['type' => 'string', 'description' => 'Mask Image Shape', 'enum' => ['yes', 'no']],
        'mask_shape_image' => ['type' => 'integer', 'description' => 'Mask Image'],
        'mask_image_shadow' => ['type' => 'string', 'description' => 'Image Shadow'],
        'css_background_filter' => ['type' => 'string', 'description' => 'CSS Background Filter', 'enum' => ['yes', 'no']],
        'css_background_width' => ['type' => 'object', 'description' => 'Width'],
        'css_background_height' => ['type' => 'object', 'description' => 'Height'],
        'box_bg_bf_blur' => ['type' => 'object', 'description' => 'Blur'],
        'box_bg_bf_grayscale' => ['type' => 'object', 'description' => 'Grayscale'],
        'loop_magic_scroll' => ['type' => 'string', 'description' => 'Magic Scroll', 'enum' => ['yes', 'no']],
        'plus_tooltip' => ['type' => 'string', 'description' => 'Tooltip', 'enum' => ['yes', 'no']],
        'plus_tooltip_content_type' => ['type' => 'string', 'description' => 'Content Type', 'enum' => ['content_wysiwyg', 'normal_desc', 'plus_tooltip']],
        'plus_tooltip_content_desc' => ['type' => 'string', 'description' => 'Description'],
        'plus_tooltip_content_wysiwyg' => ['type' => 'string', 'description' => 'Tooltip Content'],
        'plus_tooltip_content_align' => ['type' => 'string', 'description' => 'Text Alignment', 'enum' => ['center', 'icon', 'left', 'plus_tooltip', 'plus_tooltip_content_type', 'right', '{{WRAPPER}} .cascading-image{{CURRENT_ITEM}} .tippy-tooltip .tippy-content,{{WRAPPER}} .cascading-text{{CURRENT_ITEM}} .tippy-tooltip .tippy-content']],
        'plus_tooltip_content_color' => ['type' => 'string', 'description' => 'Text Color'],
        'special_effect' => ['type' => 'string', 'description' => 'Special Effect', 'enum' => ['yes', 'no']],
        'effect_color_1' => ['type' => 'string', 'description' => 'Effect Color 1'],
        'effect_color_2' => ['type' => 'string', 'description' => 'Effect Color 2'],
        'cascading_move_parallax' => ['type' => 'string', 'description' => 'Parallax Move', 'enum' => ['yes', 'no']],
        'cascading_move_speed_x' => ['type' => 'object', 'description' => 'Move Parallax (X)'],
        'cascading_move_speed_y' => ['type' => 'object', 'description' => 'Move Parallax (Y)'],
        'hover_parallax' => ['type' => 'string', 'description' => 'On Hover Tilt', 'enum' => ['yes', 'no']],
        'parallax_translatez' => ['type' => 'object', 'description' => 'TranslateZ'],
        'link_option' => ['type' => 'string', 'description' => 'Link /Popup', 'enum' => ['normal_link', 'popup_link']],
        'image_link' => ['type' => 'object', 'description' => 'Link'],
        'popup_content' => ['type' => 'object', 'description' => 'Popup Content'],
        'overlay_background' => ['type' => 'string', 'description' => 'Overlay Background'],
        'opacity_normal' => ['type' => 'object', 'description' => 'Opacity'],
        'transform_css' => ['type' => 'string', 'description' => 'Transform css'],
        'border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'hover_overlay_background' => ['type' => 'string', 'description' => 'Overlay Background'],
        'opacity_hover' => ['type' => 'object', 'description' => 'Hover Opacity'],
        'transform_hover_css' => ['type' => 'string', 'description' => 'Transform Hover css'],
        'border_radius_hover' => ['type' => 'object', 'description' => 'Border Radius Hover'],
        'responsive_visible_opt' => ['type' => 'string', 'description' => 'Responsive Visibility', 'enum' => ['yes', 'no']],
        'desktop_opt' => ['type' => 'string', 'description' => 'Desktop', 'enum' => ['yes', 'no']],
        'tablet_opt' => ['type' => 'string', 'description' => 'Tablet', 'enum' => ['yes', 'no']],
        'mobile_opt' => ['type' => 'string', 'description' => 'Mobile', 'enum' => ['yes', 'no']],
        'image_cascading' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Add Multiple Cascading Sections'],
        'min_height' => ['type' => 'object', 'description' => 'Minimum Height'],
        'slide_show' => ['type' => 'string', 'description' => 'Slide Show', 'enum' => ['yes', 'no']],
        'slide_change_opt' => ['type' => 'string', 'description' => 'SlideShow Type', 'enum' => ['onclick', 'setinterval', 'slide_show']],
        'interval_time' => ['type' => 'string', 'description' => 'Autoplay Duration'],
        'section_overflow_desktop' => ['type' => 'string', 'description' => 'Overflow Hidden (Desktop)', 'enum' => ['yes', 'no']],
        'section_overflow_tablet' => ['type' => 'string', 'description' => 'Overflow Hidden (Tablet)', 'enum' => ['yes', 'no']],
        'section_overflow_mobile' => ['type' => 'string', 'description' => 'Overflow Hidden (Mobile)', 'enum' => ['yes', 'no']],
        'lottieWidth' => ['type' => 'object', 'description' => 'Width'],
        'lottieHeight' => ['type' => 'object', 'description' => 'Height'],
        'lottieSpeed' => ['type' => 'object', 'description' => 'Speed'],
        'lottieLoop' => ['type' => 'string', 'description' => 'Loop Animation', 'enum' => ['yes', 'no']],
        'lottiehover' => ['type' => 'string', 'description' => 'Hover Animation', 'enum' => ['yes', 'no']],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_cascading_image_ability',
    'permission_callback' => 'tpaep_mcp_theplus_cascading_image_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_cascading_image_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_cascading_image_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-cascading-image';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Cascading Image widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['d_left_auto'])) { $settings['d_left_auto'] = sanitize_text_field($input['d_left_auto']); }
    if (isset($input['d_pos_xposition'])) { $settings['d_pos_xposition'] = $input['d_pos_xposition']; }
    if (isset($input['d_right_auto'])) { $settings['d_right_auto'] = sanitize_text_field($input['d_right_auto']); }
    if (isset($input['d_pos_rightposition'])) { $settings['d_pos_rightposition'] = $input['d_pos_rightposition']; }
    if (isset($input['d_top_auto'])) { $settings['d_top_auto'] = sanitize_text_field($input['d_top_auto']); }
    if (isset($input['d_pos_yposition'])) { $settings['d_pos_yposition'] = $input['d_pos_yposition']; }
    if (isset($input['d_bottom_auto'])) { $settings['d_bottom_auto'] = sanitize_text_field($input['d_bottom_auto']); }
    if (isset($input['d_pos_bottomposition'])) { $settings['d_pos_bottomposition'] = $input['d_pos_bottomposition']; }
    if (isset($input['d_pos_width'])) { $settings['d_pos_width'] = $input['d_pos_width']; }
    if (isset($input['t_responsive'])) { $settings['t_responsive'] = sanitize_text_field($input['t_responsive']); }
    if (isset($input['t_left_auto'])) { $settings['t_left_auto'] = sanitize_text_field($input['t_left_auto']); }
    if (isset($input['t_pos_xposition'])) { $settings['t_pos_xposition'] = $input['t_pos_xposition']; }
    if (isset($input['t_right_auto'])) { $settings['t_right_auto'] = sanitize_text_field($input['t_right_auto']); }
    if (isset($input['t_pos_rightposition'])) { $settings['t_pos_rightposition'] = $input['t_pos_rightposition']; }
    if (isset($input['t_top_auto'])) { $settings['t_top_auto'] = sanitize_text_field($input['t_top_auto']); }
    if (isset($input['t_pos_yposition'])) { $settings['t_pos_yposition'] = $input['t_pos_yposition']; }
    if (isset($input['t_bottom_auto'])) { $settings['t_bottom_auto'] = sanitize_text_field($input['t_bottom_auto']); }
    if (isset($input['t_pos_bottomposition'])) { $settings['t_pos_bottomposition'] = $input['t_pos_bottomposition']; }
    if (isset($input['t_pos_width'])) { $settings['t_pos_width'] = $input['t_pos_width']; }
    if (isset($input['m_responsive'])) { $settings['m_responsive'] = sanitize_text_field($input['m_responsive']); }
    if (isset($input['m_left_auto'])) { $settings['m_left_auto'] = sanitize_text_field($input['m_left_auto']); }
    if (isset($input['m_pos_xposition'])) { $settings['m_pos_xposition'] = $input['m_pos_xposition']; }
    if (isset($input['m_right_auto'])) { $settings['m_right_auto'] = sanitize_text_field($input['m_right_auto']); }
    if (isset($input['m_pos_rightposition'])) { $settings['m_pos_rightposition'] = $input['m_pos_rightposition']; }
    if (isset($input['m_top_auto'])) { $settings['m_top_auto'] = sanitize_text_field($input['m_top_auto']); }
    if (isset($input['m_pos_yposition'])) { $settings['m_pos_yposition'] = $input['m_pos_yposition']; }
    if (isset($input['m_bottom_auto'])) { $settings['m_bottom_auto'] = sanitize_text_field($input['m_bottom_auto']); }
    if (isset($input['m_pos_bottomposition'])) { $settings['m_pos_bottomposition'] = $input['m_pos_bottomposition']; }
    if (isset($input['m_pos_width'])) { $settings['m_pos_width'] = $input['m_pos_width']; }
    if (isset($input['select_option'])) { $settings['select_option'] = sanitize_text_field($input['select_option']); }
    if (isset($input['lottieUrl'])) { $settings['lottieUrl'] = $input['lottieUrl']; }
    if (!empty($input['multiple_image'])) { $settings['multiple_image'] = ['id' => absint($input['multiple_image'])]; }
    if (isset($input['text_content'])) { $settings['text_content'] = sanitize_text_field($input['text_content']); }
    if (isset($input['text_content_color'])) { $settings['text_content_color'] = sanitize_text_field($input['text_content_color']); }
    if (isset($input['text_content_hover_color'])) { $settings['text_content_hover_color'] = sanitize_text_field($input['text_content_hover_color']); }
    if (isset($input['text_content_radius'])) { $settings['text_content_radius'] = $input['text_content_radius']; }
    if (isset($input['image_effect'])) { $settings['image_effect'] = sanitize_text_field($input['image_effect']); }
    if (isset($input['drop_waves_color'])) { $settings['drop_waves_color'] = sanitize_text_field($input['drop_waves_color']); }
    if (isset($input['mask_image_display'])) { $settings['mask_image_display'] = sanitize_text_field($input['mask_image_display']); }
    if (!empty($input['mask_shape_image'])) { $settings['mask_shape_image'] = ['id' => absint($input['mask_shape_image'])]; }
    if (isset($input['mask_image_shadow'])) { $settings['mask_image_shadow'] = sanitize_text_field($input['mask_image_shadow']); }
    if (isset($input['css_background_filter'])) { $settings['css_background_filter'] = sanitize_text_field($input['css_background_filter']); }
    if (isset($input['css_background_width'])) { $settings['css_background_width'] = $input['css_background_width']; }
    if (isset($input['css_background_height'])) { $settings['css_background_height'] = $input['css_background_height']; }
    if (isset($input['box_bg_bf_blur'])) { $settings['box_bg_bf_blur'] = $input['box_bg_bf_blur']; }
    if (isset($input['box_bg_bf_grayscale'])) { $settings['box_bg_bf_grayscale'] = $input['box_bg_bf_grayscale']; }
    if (isset($input['loop_magic_scroll'])) { $settings['loop_magic_scroll'] = sanitize_text_field($input['loop_magic_scroll']); }
    if (isset($input['plus_tooltip'])) { $settings['plus_tooltip'] = sanitize_text_field($input['plus_tooltip']); }
    if (isset($input['plus_tooltip_content_type'])) { $settings['plus_tooltip_content_type'] = sanitize_text_field($input['plus_tooltip_content_type']); }
    if (isset($input['plus_tooltip_content_desc'])) { $settings['plus_tooltip_content_desc'] = sanitize_text_field($input['plus_tooltip_content_desc']); }
    if (isset($input['plus_tooltip_content_wysiwyg'])) { $settings['plus_tooltip_content_wysiwyg'] = sanitize_text_field($input['plus_tooltip_content_wysiwyg']); }
    if (isset($input['plus_tooltip_content_align'])) { $settings['plus_tooltip_content_align'] = sanitize_text_field($input['plus_tooltip_content_align']); }
    if (isset($input['plus_tooltip_content_color'])) { $settings['plus_tooltip_content_color'] = sanitize_text_field($input['plus_tooltip_content_color']); }
    if (isset($input['special_effect'])) { $settings['special_effect'] = sanitize_text_field($input['special_effect']); }
    if (isset($input['effect_color_1'])) { $settings['effect_color_1'] = sanitize_text_field($input['effect_color_1']); }
    if (isset($input['effect_color_2'])) { $settings['effect_color_2'] = sanitize_text_field($input['effect_color_2']); }
    if (isset($input['cascading_move_parallax'])) { $settings['cascading_move_parallax'] = sanitize_text_field($input['cascading_move_parallax']); }
    if (isset($input['cascading_move_speed_x'])) { $settings['cascading_move_speed_x'] = $input['cascading_move_speed_x']; }
    if (isset($input['cascading_move_speed_y'])) { $settings['cascading_move_speed_y'] = $input['cascading_move_speed_y']; }
    if (isset($input['hover_parallax'])) { $settings['hover_parallax'] = sanitize_text_field($input['hover_parallax']); }
    if (isset($input['parallax_translatez'])) { $settings['parallax_translatez'] = $input['parallax_translatez']; }
    if (isset($input['link_option'])) { $settings['link_option'] = sanitize_text_field($input['link_option']); }
    if (isset($input['image_link'])) { $settings['image_link'] = $input['image_link']; }
    if (isset($input['popup_content'])) { $settings['popup_content'] = $input['popup_content']; }
    if (isset($input['overlay_background'])) { $settings['overlay_background'] = sanitize_text_field($input['overlay_background']); }
    if (isset($input['opacity_normal'])) { $settings['opacity_normal'] = $input['opacity_normal']; }
    if (isset($input['transform_css'])) { $settings['transform_css'] = sanitize_text_field($input['transform_css']); }
    if (isset($input['border_radius'])) { $settings['border_radius'] = $input['border_radius']; }
    if (isset($input['hover_overlay_background'])) { $settings['hover_overlay_background'] = sanitize_text_field($input['hover_overlay_background']); }
    if (isset($input['opacity_hover'])) { $settings['opacity_hover'] = $input['opacity_hover']; }
    if (isset($input['transform_hover_css'])) { $settings['transform_hover_css'] = sanitize_text_field($input['transform_hover_css']); }
    if (isset($input['border_radius_hover'])) { $settings['border_radius_hover'] = $input['border_radius_hover']; }
    if (isset($input['responsive_visible_opt'])) { $settings['responsive_visible_opt'] = sanitize_text_field($input['responsive_visible_opt']); }
    if (isset($input['desktop_opt'])) { $settings['desktop_opt'] = sanitize_text_field($input['desktop_opt']); }
    if (isset($input['tablet_opt'])) { $settings['tablet_opt'] = sanitize_text_field($input['tablet_opt']); }
    if (isset($input['mobile_opt'])) { $settings['mobile_opt'] = sanitize_text_field($input['mobile_opt']); }
    if (isset($input['image_cascading'])) { $settings['image_cascading'] = $input['image_cascading']; }
    if (isset($input['min_height'])) { $settings['min_height'] = $input['min_height']; }
    if (isset($input['slide_show'])) { $settings['slide_show'] = sanitize_text_field($input['slide_show']); }
    if (isset($input['slide_change_opt'])) { $settings['slide_change_opt'] = sanitize_text_field($input['slide_change_opt']); }
    if (isset($input['interval_time'])) { $settings['interval_time'] = sanitize_text_field($input['interval_time']); }
    if (isset($input['section_overflow_desktop'])) { $settings['section_overflow_desktop'] = sanitize_text_field($input['section_overflow_desktop']); }
    if (isset($input['section_overflow_tablet'])) { $settings['section_overflow_tablet'] = sanitize_text_field($input['section_overflow_tablet']); }
    if (isset($input['section_overflow_mobile'])) { $settings['section_overflow_mobile'] = sanitize_text_field($input['section_overflow_mobile']); }
    if (isset($input['lottieWidth'])) { $settings['lottieWidth'] = $input['lottieWidth']; }
    if (isset($input['lottieHeight'])) { $settings['lottieHeight'] = $input['lottieHeight']; }
    if (isset($input['lottieSpeed'])) { $settings['lottieSpeed'] = $input['lottieSpeed']; }
    if (isset($input['lottieLoop'])) { $settings['lottieLoop'] = sanitize_text_field($input['lottieLoop']); }
    if (isset($input['lottiehover'])) { $settings['lottiehover'] = sanitize_text_field($input['lottiehover']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
