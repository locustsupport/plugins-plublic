<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-header-extras', [
'label' => __('Header Extras', 'theplus'),
    'description' => __('Adds The Plus "Header Extras" widget (tp-header-extras) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'select_icon_list' => ['type' => 'string', 'description' => 'Select Options', 'enum' => ['action_1', 'action_2', 'cart', 'extra_toggle', 'music', 'search', 'wpml_lang']],
        'icon_left_space' => ['type' => 'object', 'description' => 'Icon Left Space (Slider/Size Object)'],
        'icon_right_space' => ['type' => 'object', 'description' => 'Icon Right Space (Slider/Size Object)'],
        'responsive_hidden_desktop' => ['type' => 'string', 'description' => 'Hide On Desktop', 'enum' => ['yes', 'no']],
        'responsive_hidden_tablet' => ['type' => 'string', 'description' => 'Hide On Tablet', 'enum' => ['yes', 'no']],
        'responsive_hidden_mobile' => ['type' => 'string', 'description' => 'Hide On Mobile', 'enum' => ['yes', 'no']],
        'sequence_icons' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'sequence_icons'],
        'display_search_bar' => ['type' => 'string', 'description' => 'Display Search Bar', 'enum' => ['yes', 'no']],
        'search_icon_style' => ['type' => 'string', 'description' => 'Icon Style', 'enum' => ['display_search_bar', 'style-1', 'style-custom-icon', 'style-custom-image']],
        'search_custom_icon' => ['type' => 'string', 'description' => 'Custom Icon'],
        'search_custom_image' => ['type' => 'integer', 'description' => 'Custom Image (Image ID)'],
        'search_bar_content_style' => ['type' => 'string', 'description' => 'Search Content Style', 'enum' => ['display_search_bar', 'style-1', 'style-2', 'style-3', 'style-4']],
        'search_bar_open_content_style' => ['type' => 'string', 'description' => 'Open Content Position', 'enum' => ['display_search_bar', 'sboc_left', 'sboc_right', 'search_bar_content_style']],
        'search_placeholder_text' => ['type' => 'string', 'description' => 'Search Placeholder Text'],
        'search_icon_svg_size' => ['type' => 'object', 'description' => 'Svg Icon Size (Slider/Size Object)'],
        'search_icon_color' => ['type' => 'string', 'description' => 'Search Color (Color Hex/RGBA)'],
        'form_content_background_2' => ['type' => 'string', 'description' => 'Content Background Color (Color Hex/RGBA)'],
        'search_icon_color_hover' => ['type' => 'string', 'description' => 'Search Hover Color (Color Hex/RGBA)'],
        'search_field_placeholder_color' => ['type' => 'string', 'description' => 'Placeholder Text Color (Color Hex/RGBA)'],
        'search_field_color' => ['type' => 'string', 'description' => 'Field Text Color (Color Hex/RGBA)'],
        'search_field_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'field_border_color_1' => ['type' => 'string', 'description' => 'Border Bottom Color (Color Hex/RGBA)'],
        'search_field_bg_2' => ['type' => 'string', 'description' => 'Field Background Color (Color Hex/RGBA)'],
        'search_field_placeholder_focus_color' => ['type' => 'string', 'description' => 'Placeholder Text Color (Color Hex/RGBA)'],
        'search_field_focus_color' => ['type' => 'string', 'description' => 'Field Text Color (Color Hex/RGBA)'],
        'field_focus_border_color_1' => ['type' => 'string', 'description' => 'Border Bottom Color (Color Hex/RGBA)'],
        'search_field_focus_bg_2' => ['type' => 'string', 'description' => 'Field Background Color (Color Hex/RGBA)'],
        'search_field_border_bottom_1' => ['type' => 'object', 'description' => 'Search Field Border Width (Slider/Size Object)'],
        'search_submit_btn_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'search_submit_btn_color_hover' => ['type' => 'string', 'description' => 'Icon Hover Color (Color Hex/RGBA)'],
        'close_btn_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'close_btn_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'close_btn_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['close_btn_border', 'dashed', 'dotted', 'groove', 'none', 'search_bar_content_style', 'solid', '{{WRAPPER}} .plus-search-form .plus-search-close']],
        'search_close_color' => ['type' => 'string', 'description' => 'Close Icon Color (Color Hex/RGBA)'],
        'close_btn_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'close_btn_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'search_close_color_hover' => ['type' => 'string', 'description' => 'Close Icon Hover Color (Color Hex/RGBA)'],
        'close_btn_border_hover_color' => ['type' => 'string', 'description' => 'Border Hover Color (Color Hex/RGBA)'],
        'close_btn_border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'search_custom_img_width' => ['type' => 'object', 'description' => 'Image Size (Slider/Size Object)'],
        'search_custom_img_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'search_custom_img_top_offset' => ['type' => 'object', 'description' => 'Open Content Top Offset (Slider/Size Object)'],
        'display_mini_cart' => ['type' => 'string', 'description' => 'Display Cart', 'enum' => ['yes', 'no']],
        'cart_icon_style' => ['type' => 'string', 'description' => 'Toggle Style', 'enum' => ['display_mini_cart', 'style-1', 'style-2']],
        'cart_icon_direction' => ['type' => 'string', 'description' => 'Open Content Direction', 'enum' => ['cart_icon_style', 'display_mini_cart', 'left', 'right']],
        'cart_icon_width_option' => ['type' => 'string', 'description' => 'Content Width', 'enum' => ['cart_icon_style', 'custom', 'display_mini_cart', 'fullwidth']],
        'cart_extra_content_width' => ['type' => 'object', 'description' => 'Custom Content Width (Slider/Size Object)'],
        'cart_extra_content_width_st1' => ['type' => 'object', 'description' => 'Open Content Width (Slider/Size Object)'],
        'cart_extra_content_height_st1' => ['type' => 'object', 'description' => 'Open Content Height (Slider/Size Object)'],
        'cart_pro_ani_speed' => ['type' => 'object', 'description' => 'Cart Product Transition Duration (Slider/Size Object)'],
        'cart_icon' => ['type' => 'string', 'description' => 'Cart Icon', 'enum' => ['cart_custom_icon', 'cart_custom_image', 'display_mini_cart']],
        'cart_icon_icon' => ['type' => 'string', 'description' => 'Custom Icon'],
        'cart_icon_custom_image' => ['type' => 'integer', 'description' => 'Custom Image (Image ID)'],
        'cart_offer_text' => ['type' => 'string', 'description' => 'Mini Cart Offer Text'],
        'cart_offer_text_offset' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'cart_icon_size_img_icn' => ['type' => 'object', 'description' => 'Cart Size (Slider/Size Object)'],
        'cart_icon_color' => ['type' => 'string', 'description' => 'Cart Color (Color Hex/RGBA)'],
        'cart_icon_size_img_icn_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'cart_icon_color_hover' => ['type' => 'string', 'description' => 'Cart Hover Color (Color Hex/RGBA)'],
        'cart_count_color' => ['type' => 'string', 'description' => 'Count Color (Color Hex/RGBA)'],
        'cart_count_color_hover' => ['type' => 'string', 'description' => 'Count Hover Color (Color Hex/RGBA)'],
        'min_cart_box_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'min_cart_box_radius_hover' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'cart_etext_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'min_cart_box_radius_bt' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'cart_etext_color_h' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'min_cart_box_radius_hover_bt' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'cart_inner_padding' => ['type' => 'object', 'description' => 'Open Content Inner Padding (Dimensions Object)'],
        'mini_cart_empty_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'mini_cart_empty_text_size' => ['type' => 'object', 'description' => 'Text Size (Slider/Size Object)'],
        'mini_cart_empty_icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'mini_cart_empty_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'cart_title_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'cart_title_color_hover' => ['type' => 'string', 'description' => 'Count Title Color (Color Hex/RGBA)'],
        'cart_variation_title_color' => ['type' => 'string', 'description' => 'Variation Title Color (Color Hex/RGBA)'],
        'cart_variation_content_color' => ['type' => 'string', 'description' => 'Variation Content Color (Color Hex/RGBA)'],
        'cart_quantity_color' => ['type' => 'string', 'description' => 'Quantity Color (Color Hex/RGBA)'],
        'cart_remove_color' => ['type' => 'string', 'description' => 'Remove Cart Color (Color Hex/RGBA)'],
        'cart_quantity_color_hover' => ['type' => 'string', 'description' => 'Count Quantity Color (Color Hex/RGBA)'],
        'cart_remove_color_hover' => ['type' => 'string', 'description' => 'Remove Cart Color (Color Hex/RGBA)'],
        'mini_cart_sep_border_style' => ['type' => 'string', 'description' => 'Separator Style', 'enum' => ['{{WRAPPER}} .header-extra-icons .mini-cart-icon .widget_shopping_cart .cart_list > li']],
        'mini_cart_sep_border_width' => ['type' => 'object', 'description' => 'Separator Width (Slider/Size Object)'],
        'mini_cart_sep_border_color' => ['type' => 'string', 'description' => 'Separator Color (Color Hex/RGBA)'],
        'mini_cart_in_img_size' => ['type' => 'object', 'description' => 'Image Size (Slider/Size Object)'],
        'mini_cart_in_img_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'cart_subtotal_color' => ['type' => 'string', 'description' => 'Sub-Total Color (Color Hex/RGBA)'],
        'cart_price_color' => ['type' => 'string', 'description' => 'Total Price Color (Color Hex/RGBA)'],
        'min_cart_btn_border_style' => ['type' => 'string', 'description' => 'Border Type', 'enum' => ['dashed', 'dotted', 'groove', 'none', 'solid', '{{WRAPPER}} .header-extra-icons .mini-cart-icon .widget_shopping_cart a.button']],
        'min_cart_btn_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'min_cart_btn_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'min_cart_btn_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'min_cart_btn_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'mini_cart_view_btn_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'min_cart_view_btn_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'min_cart_view_btn_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'min_cart_view_btn_text_color_hover' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'min_cart_view_btn_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'mini_cart_checkout_btn_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'min_cart_checkout_btn_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'min_cart_checkout_btn_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'min_cart_checkout_btn_text_color_hover' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'min_cart_checkout_btn_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'display_scrolling_bar' => ['type' => 'string', 'description' => 'Content Scrolling Bar', 'enum' => ['yes', 'no']],
        'scroll_scrollbar_width' => ['type' => 'object', 'description' => 'ScrollBar Width (Slider/Size Object)'],
        'scroll_thumb_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'scroll_track_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'mc_toggle_icon_close_color' => ['type' => 'string', 'description' => 'Close Icon Color (Color Hex/RGBA)'],
        'mc_toggle_icon_close_bg' => ['type' => 'string', 'description' => 'Close Background Color (Color Hex/RGBA)'],
        'mc_toggle_icon_close_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'mc_toggle_icon_close_color_hover' => ['type' => 'string', 'description' => 'Close Icon Hover Color (Color Hex/RGBA)'],
        'mc_toggle_icon_close_bg_hover' => ['type' => 'string', 'description' => 'Close Hover Background Color (Color Hex/RGBA)'],
        'mc_toggle_icon_close_border_radius_hover' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        'display_extra_toggle_bar' => ['type' => 'string', 'description' => 'Display Toggle Bar', 'enum' => ['yes', 'no']],
        'extra_toggle_style' => ['type' => 'string', 'description' => 'Toggle Style', 'enum' => ['display_extra_toggle_bar', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5']],
        'extra_toggle_style_custom' => ['type' => 'string', 'description' => 'Custom', 'enum' => ['custom_icon', 'custom_img', 'extra_toggle_style']],
        'extra_toggle_custom_icon' => ['type' => 'string', 'description' => 'Custom Icon'],
        'extra_toggle_custom_image' => ['type' => 'integer', 'description' => 'Custom Image (Image ID)'],
        'extra_content_template' => ['type' => 'string', 'description' => 'Elementor Templates', 'enum' => ['display_extra_toggle_bar']],
        'extra_toggle_bar_direction' => ['type' => 'string', 'description' => 'Open Content Direction', 'enum' => ['bottom', 'display_extra_toggle_bar', 'left', 'right', 'top']],
        'extra_content_width_option' => ['type' => 'string', 'description' => 'Content Width', 'enum' => ['custom', 'display_extra_toggle_bar', 'fullwidth']],
        'extra_content_width' => ['type' => 'object', 'description' => 'Custom Content Width (Slider/Size Object)'],
        'extra_toggle_icon_size' => ['type' => 'object', 'description' => 'Toggle Icon Size (Slider/Size Object)'],
        'extra_toggle_custom_img_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'extra_toggle_icon_color' => ['type' => 'string', 'description' => 'Toggle Color (Color Hex/RGBA)'],
        'extra_toggle_icon_color_hover' => ['type' => 'string', 'description' => 'Toggle Hover Color (Color Hex/RGBA)'],
        'content_inner_padding' => ['type' => 'object', 'description' => 'Content Inner Padding (Dimensions Object)'],
        'extra_toggle_icon_close_color' => ['type' => 'string', 'description' => 'Close Icon Color (Color Hex/RGBA)'],
        'extra_toggle_icon_close_bg' => ['type' => 'string', 'description' => 'Close Background Color (Color Hex/RGBA)'],
        'extra_toggle_icon_close_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'extra_toggle_icon_close_color_hover' => ['type' => 'string', 'description' => 'Close Icon Color (Color Hex/RGBA)'],
        'extra_toggle_icon_close_bg_hover' => ['type' => 'string', 'description' => 'Close Background Color (Color Hex/RGBA)'],
        'extra_toggle_icon_close_border_radius_hover' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'wpml_ls_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'wpml_ls_max_width' => ['type' => 'object', 'description' => 'Max Width (Slider/Size Object)'],
        'wpml_ls_min_width' => ['type' => 'object', 'description' => 'Min Width (Slider/Size Object)'],
        'wpml_ls_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'wpml_ls_color_n' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'wpml_ls_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'wpml_ls_color_a' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'wpml_ls_br_a' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'wpml_ba_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'wpml_ba_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'wpml_ba_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'wpml_ba_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'transp_bg_color' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'transp_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'transp_text_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'transp_text_bg' => ['type' => 'string', 'description' => 'Background (Color Hex/RGBA)'],
        'transp_text_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'transp_text_color_h' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'transp_text_bg_h' => ['type' => 'string', 'description' => 'Background (Color Hex/RGBA)'],
        'transp_text_br_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'transp_image_size' => ['type' => 'object', 'description' => 'Image Width (Slider/Size Object)'],
        'transp_image_height_size' => ['type' => 'object', 'description' => 'Image Height (Slider/Size Object)'],
        'transp_bottom_space' => ['type' => 'object', 'description' => 'Bottom Space (Slider/Size Object)'],
        'transp_ba_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'transp_ba_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'transp_ba_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'transp_ba_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'display_language_switcher' => ['type' => 'string', 'description' => 'Display Language Switcher', 'enum' => ['yes', 'no']],
        'select_trans' => ['type' => 'string', 'description' => 'Select', 'enum' => ['display_language_switcher', 'p_translatepress', 'p_wpml']],
        'wpml_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['display_language_switcher', 'select_trans', 'wpml_style_1', 'wpml_style_2']],
        'wpml_style_layout' => ['type' => 'string', 'description' => 'Layout', 'enum' => ['display_language_switcher', 'select_trans', 'tp-wpml-layout-h', 'tp-wpml-layout-v', 'wpml_style']],
        'skip_language' => ['type' => 'string', 'description' => 'Skip Language', 'enum' => ['yes', 'no']],
        'display_country_flag' => ['type' => 'string', 'description' => 'Country Flag', 'enum' => ['yes', 'no']],
        'display_native_name' => ['type' => 'string', 'description' => 'Native Name', 'enum' => ['yes', 'no']],
        'display_translated_name' => ['type' => 'string', 'description' => 'Translated Name', 'enum' => ['yes', 'no']],
        'display_language_code' => ['type' => 'string', 'description' => 'Language Code', 'enum' => ['yes', 'no']],
        'before_language_text' => ['type' => 'string', 'description' => 'Before Text'],
        'after_language_text' => ['type' => 'string', 'description' => 'After Text'],
        'display_music_bar' => ['type' => 'string', 'description' => 'Display Music', 'enum' => ['yes', 'no']],
        'music_icon_style' => ['type' => 'string', 'description' => 'Icon Style', 'enum' => ['display_music_bar', 'style-1', 'style-2']],
        'music_audio_file' => ['type' => 'object', 'description' => 'Audio .Mp3/.Ogg'],
        'music_volume' => ['type' => 'object', 'description' => 'Music Volume (Slider/Size Object)'],
        'music_bar_icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'music_bar_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['dashed', 'dotted', 'groove', 'music_icon_style!', 'none', 'solid', '{{WRAPPER}} .header-extra-icons .header-music-bar .header-plus-music-toggle']],
        'music_bar_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'music_bar_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'music_bar_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'music_bar_icon_hover_color' => ['type' => 'string', 'description' => 'Icon Hover Color (Color Hex/RGBA)'],
        'music_bar_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'music_bar_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        'display_call_to_action_1' => ['type' => 'string', 'description' => 'Display Call To Action', 'enum' => ['yes', 'no']],
        'button_1_text' => ['type' => 'string', 'description' => 'Button Text'],
        'button_1_link' => ['type' => 'object', 'description' => 'Link'],
        'button_1_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['display_call_to_action_1', 'font_awesome', 'font_awesome_5', 'icon_mind', 'none']],
        'button_1_icon' => ['type' => 'string', 'description' => 'Icon'],
        'button_1_icon_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'button_1_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['button_1_icon_style', 'display_call_to_action_1']],
        'button_1_before_after' => ['type' => 'string', 'description' => 'Icon Position', 'enum' => ['after', 'before', 'button_1_icon_style!', 'display_call_to_action_1']],
        'button_1_icon_spacing' => ['type' => 'object', 'description' => 'Icon Spacing (Slider/Size Object)'],
        'button_1_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'button_1_css_id' => ['type' => 'string', 'description' => 'Button ID'],
        'button_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'button_1_svg_icon' => ['type' => 'object', 'description' => 'Svg Icon Size (Slider/Size Object)'],
        'button_1_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'button_1_icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'button_1_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['dashed', 'dotted', 'groove', 'none', 'solid', '{{WRAPPER}} .header-extra-icons .call-to-action-1 .plus-action-button']],
        'button_1_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'button_1_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'button_1_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'button_1_text_hover_color' => ['type' => 'string', 'description' => 'Text Hover Color (Color Hex/RGBA)'],
        'button_1_icon_hover' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'button_1_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'button_1_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        'display_call_to_action_2' => ['type' => 'string', 'description' => 'Display Call To Action', 'enum' => ['yes', 'no']],
        'button_2_text' => ['type' => 'string', 'description' => 'Button Text'],
        'button_2_link' => ['type' => 'object', 'description' => 'Link'],
        'button_2_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['display_call_to_action_2', 'font_awesome', 'font_awesome_5', 'icon_mind', 'none']],
        'button_2_icon' => ['type' => 'string', 'description' => 'Icon'],
        'button_2_icon_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'button_2_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['button_2_icon_style', 'display_call_to_action_2']],
        'button_2_before_after' => ['type' => 'string', 'description' => 'Icon Position', 'enum' => ['after', 'before', 'button_2_icon_style!', 'display_call_to_action_2']],
        'button_2_icon_spacing' => ['type' => 'object', 'description' => 'Icon Spacing (Slider/Size Object)'],
        'button_2_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'button_2_css_id' => ['type' => 'string', 'description' => 'Button ID'],
        'button_2_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'button_2_svg_icon' => ['type' => 'object', 'description' => 'Svg Icon Size (Slider/Size Object)'],
        'button_2_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'button_2_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['dashed', 'dotted', 'groove', 'none', 'solid', '{{WRAPPER}} .header-extra-icons .call-to-action-2 .plus-action-button']],
        'button_2_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'button_2_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'button_2_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'button_2_text_hover_color' => ['type' => 'string', 'description' => 'Text Hover Color (Color Hex/RGBA)'],
        'button_2_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'button_2_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        'icon_alignment' => ['type' => 'string', 'description' => 'Alignment', 'enum' => ['center', 'flex-end', 'flex-left', 'icon', 'toggle', '{{WRAPPER}} .header-extra-icons ul.icons-content-list']],
        'icon_between_padding' => ['type' => 'object', 'description' => 'Icon Padding (Dimensions Object)'],
        'tpaep_theme_builder' => ['type' => 'string', 'description' => 'tpaep_theme_builder'],
        'sticky_options' => ['type' => 'string', 'description' => 'Sticky Options', 'enum' => ['yes', 'no']],
        's_search_icon_color' => ['type' => 'string', 'description' => 'Search Color (Color Hex/RGBA)'],
        's_cart_icon_color' => ['type' => 'string', 'description' => 'Cart Color (Color Hex/RGBA)'],
        's_cart_count_color' => ['type' => 'string', 'description' => 'Count Color (Color Hex/RGBA)'],
        's_extra_toggle_icon_color' => ['type' => 'string', 'description' => 'Toggle Color (Color Hex/RGBA)'],
        's_music_bar_icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        's_button_1_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        's_button_1_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        's_button_2_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        's_button_2_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        's_search_icon_color_hover' => ['type' => 'string', 'description' => 'Search Hover Color (Color Hex/RGBA)'],
        's_cart_icon_color_hover' => ['type' => 'string', 'description' => 'Cart Hover Color (Color Hex/RGBA)'],
        's_cart_count_color_hover' => ['type' => 'string', 'description' => 'Count Hover Color (Color Hex/RGBA)'],
        's_extra_toggle_icon_color_hover' => ['type' => 'string', 'description' => 'Toggle Hover Color (Color Hex/RGBA)'],
        's_music_bar_icon_hover_color' => ['type' => 'string', 'description' => 'Icon Hover Color (Color Hex/RGBA)'],
        's_button_1_text_hover_color' => ['type' => 'string', 'description' => 'Text Hover Color (Color Hex/RGBA)'],
        's_button_1_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        's_button_2_text_hover_color' => ['type' => 'string', 'description' => 'Text Hover Color (Color Hex/RGBA)'],
        's_button_2_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports WooCommerce Cart, WPML, and custom AJAX Search.']
    ], 'required' => ['post_id', 'parent_id', 'select_icon_list'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_pro_header_extras_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pro_header_extras_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_pro_header_extras_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_pro_header_extras_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-header-extras';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Header Extras widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['select_icon_list'])) { $settings['select_icon_list'] = sanitize_text_field($input['select_icon_list']); }
    if (isset($input['icon_left_space'])) { $settings['icon_left_space'] = $input['icon_left_space']; }
    if (isset($input['icon_right_space'])) { $settings['icon_right_space'] = $input['icon_right_space']; }
    if (isset($input['responsive_hidden_desktop'])) { $settings['responsive_hidden_desktop'] = sanitize_text_field($input['responsive_hidden_desktop']); }
    if (isset($input['responsive_hidden_tablet'])) { $settings['responsive_hidden_tablet'] = sanitize_text_field($input['responsive_hidden_tablet']); }
    if (isset($input['responsive_hidden_mobile'])) { $settings['responsive_hidden_mobile'] = sanitize_text_field($input['responsive_hidden_mobile']); }
    if (isset($input['sequence_icons'])) { $settings['sequence_icons'] = $input['sequence_icons']; }
    if (isset($input['display_search_bar'])) { $settings['display_search_bar'] = sanitize_text_field($input['display_search_bar']); }
    if (isset($input['search_icon_style'])) { $settings['search_icon_style'] = sanitize_text_field($input['search_icon_style']); }
    if (isset($input['search_custom_icon'])) { $settings['search_custom_icon'] = sanitize_text_field($input['search_custom_icon']); }
    if (!empty($input['search_custom_image'])) { $settings['search_custom_image'] = ['id' => absint($input['search_custom_image'])]; }
    if (isset($input['search_bar_content_style'])) { $settings['search_bar_content_style'] = sanitize_text_field($input['search_bar_content_style']); }
    if (isset($input['search_bar_open_content_style'])) { $settings['search_bar_open_content_style'] = sanitize_text_field($input['search_bar_open_content_style']); }
    if (isset($input['search_placeholder_text'])) { $settings['search_placeholder_text'] = sanitize_text_field($input['search_placeholder_text']); }
    if (isset($input['search_icon_svg_size'])) { $settings['search_icon_svg_size'] = $input['search_icon_svg_size']; }
    if (isset($input['search_icon_color'])) { $settings['search_icon_color'] = sanitize_text_field($input['search_icon_color']); }
    if (isset($input['form_content_background_2'])) { $settings['form_content_background_2'] = sanitize_text_field($input['form_content_background_2']); }
    if (isset($input['search_icon_color_hover'])) { $settings['search_icon_color_hover'] = sanitize_text_field($input['search_icon_color_hover']); }
    if (isset($input['search_field_placeholder_color'])) { $settings['search_field_placeholder_color'] = sanitize_text_field($input['search_field_placeholder_color']); }
    if (isset($input['search_field_color'])) { $settings['search_field_color'] = sanitize_text_field($input['search_field_color']); }
    if (isset($input['search_field_radius'])) { $settings['search_field_radius'] = $input['search_field_radius']; }
    if (isset($input['field_border_color_1'])) { $settings['field_border_color_1'] = sanitize_text_field($input['field_border_color_1']); }
    if (isset($input['search_field_bg_2'])) { $settings['search_field_bg_2'] = sanitize_text_field($input['search_field_bg_2']); }
    if (isset($input['search_field_placeholder_focus_color'])) { $settings['search_field_placeholder_focus_color'] = sanitize_text_field($input['search_field_placeholder_focus_color']); }
    if (isset($input['search_field_focus_color'])) { $settings['search_field_focus_color'] = sanitize_text_field($input['search_field_focus_color']); }
    if (isset($input['field_focus_border_color_1'])) { $settings['field_focus_border_color_1'] = sanitize_text_field($input['field_focus_border_color_1']); }
    if (isset($input['search_field_focus_bg_2'])) { $settings['search_field_focus_bg_2'] = sanitize_text_field($input['search_field_focus_bg_2']); }
    if (isset($input['search_field_border_bottom_1'])) { $settings['search_field_border_bottom_1'] = $input['search_field_border_bottom_1']; }
    if (isset($input['search_submit_btn_color'])) { $settings['search_submit_btn_color'] = sanitize_text_field($input['search_submit_btn_color']); }
    if (isset($input['search_submit_btn_color_hover'])) { $settings['search_submit_btn_color_hover'] = sanitize_text_field($input['search_submit_btn_color_hover']); }
    if (isset($input['close_btn_border'])) { $settings['close_btn_border'] = sanitize_text_field($input['close_btn_border']); }
    if (isset($input['close_btn_border_width'])) { $settings['close_btn_border_width'] = $input['close_btn_border_width']; }
    if (isset($input['close_btn_border_style'])) { $settings['close_btn_border_style'] = sanitize_text_field($input['close_btn_border_style']); }
    if (isset($input['search_close_color'])) { $settings['search_close_color'] = sanitize_text_field($input['search_close_color']); }
    if (isset($input['close_btn_border_color'])) { $settings['close_btn_border_color'] = sanitize_text_field($input['close_btn_border_color']); }
    if (isset($input['close_btn_border_radius'])) { $settings['close_btn_border_radius'] = $input['close_btn_border_radius']; }
    if (isset($input['search_close_color_hover'])) { $settings['search_close_color_hover'] = sanitize_text_field($input['search_close_color_hover']); }
    if (isset($input['close_btn_border_hover_color'])) { $settings['close_btn_border_hover_color'] = sanitize_text_field($input['close_btn_border_hover_color']); }
    if (isset($input['close_btn_border_hover_radius'])) { $settings['close_btn_border_hover_radius'] = $input['close_btn_border_hover_radius']; }
    if (isset($input['search_custom_img_width'])) { $settings['search_custom_img_width'] = $input['search_custom_img_width']; }
    if (isset($input['search_custom_img_radius'])) { $settings['search_custom_img_radius'] = $input['search_custom_img_radius']; }
    if (isset($input['search_custom_img_top_offset'])) { $settings['search_custom_img_top_offset'] = $input['search_custom_img_top_offset']; }
    if (isset($input['display_mini_cart'])) { $settings['display_mini_cart'] = sanitize_text_field($input['display_mini_cart']); }
    if (isset($input['cart_icon_style'])) { $settings['cart_icon_style'] = sanitize_text_field($input['cart_icon_style']); }
    if (isset($input['cart_icon_direction'])) { $settings['cart_icon_direction'] = sanitize_text_field($input['cart_icon_direction']); }
    if (isset($input['cart_icon_width_option'])) { $settings['cart_icon_width_option'] = sanitize_text_field($input['cart_icon_width_option']); }
    if (isset($input['cart_extra_content_width'])) { $settings['cart_extra_content_width'] = $input['cart_extra_content_width']; }
    if (isset($input['cart_extra_content_width_st1'])) { $settings['cart_extra_content_width_st1'] = $input['cart_extra_content_width_st1']; }
    if (isset($input['cart_extra_content_height_st1'])) { $settings['cart_extra_content_height_st1'] = $input['cart_extra_content_height_st1']; }
    if (isset($input['cart_pro_ani_speed'])) { $settings['cart_pro_ani_speed'] = $input['cart_pro_ani_speed']; }
    if (isset($input['cart_icon'])) { $settings['cart_icon'] = sanitize_text_field($input['cart_icon']); }
    if (isset($input['cart_icon_icon'])) { $settings['cart_icon_icon'] = sanitize_text_field($input['cart_icon_icon']); }
    if (!empty($input['cart_icon_custom_image'])) { $settings['cart_icon_custom_image'] = ['id' => absint($input['cart_icon_custom_image'])]; }
    if (isset($input['cart_offer_text'])) { $settings['cart_offer_text'] = sanitize_text_field($input['cart_offer_text']); }
    if (isset($input['cart_offer_text_offset'])) { $settings['cart_offer_text_offset'] = $input['cart_offer_text_offset']; }
    if (isset($input['cart_icon_size_img_icn'])) { $settings['cart_icon_size_img_icn'] = $input['cart_icon_size_img_icn']; }
    if (isset($input['cart_icon_color'])) { $settings['cart_icon_color'] = sanitize_text_field($input['cart_icon_color']); }
    if (isset($input['cart_icon_size_img_icn_radius'])) { $settings['cart_icon_size_img_icn_radius'] = $input['cart_icon_size_img_icn_radius']; }
    if (isset($input['cart_icon_color_hover'])) { $settings['cart_icon_color_hover'] = sanitize_text_field($input['cart_icon_color_hover']); }
    if (isset($input['cart_count_color'])) { $settings['cart_count_color'] = sanitize_text_field($input['cart_count_color']); }
    if (isset($input['cart_count_color_hover'])) { $settings['cart_count_color_hover'] = sanitize_text_field($input['cart_count_color_hover']); }
    if (isset($input['min_cart_box_radius'])) { $settings['min_cart_box_radius'] = $input['min_cart_box_radius']; }
    if (isset($input['min_cart_box_radius_hover'])) { $settings['min_cart_box_radius_hover'] = $input['min_cart_box_radius_hover']; }
    if (isset($input['cart_etext_color'])) { $settings['cart_etext_color'] = sanitize_text_field($input['cart_etext_color']); }
    if (isset($input['min_cart_box_radius_bt'])) { $settings['min_cart_box_radius_bt'] = $input['min_cart_box_radius_bt']; }
    if (isset($input['cart_etext_color_h'])) { $settings['cart_etext_color_h'] = sanitize_text_field($input['cart_etext_color_h']); }
    if (isset($input['min_cart_box_radius_hover_bt'])) { $settings['min_cart_box_radius_hover_bt'] = $input['min_cart_box_radius_hover_bt']; }
    if (isset($input['cart_inner_padding'])) { $settings['cart_inner_padding'] = $input['cart_inner_padding']; }
    if (isset($input['mini_cart_empty_icon_size'])) { $settings['mini_cart_empty_icon_size'] = $input['mini_cart_empty_icon_size']; }
    if (isset($input['mini_cart_empty_text_size'])) { $settings['mini_cart_empty_text_size'] = $input['mini_cart_empty_text_size']; }
    if (isset($input['mini_cart_empty_icon_color'])) { $settings['mini_cart_empty_icon_color'] = sanitize_text_field($input['mini_cart_empty_icon_color']); }
    if (isset($input['mini_cart_empty_text_color'])) { $settings['mini_cart_empty_text_color'] = sanitize_text_field($input['mini_cart_empty_text_color']); }
    if (isset($input['cart_title_color'])) { $settings['cart_title_color'] = sanitize_text_field($input['cart_title_color']); }
    if (isset($input['cart_title_color_hover'])) { $settings['cart_title_color_hover'] = sanitize_text_field($input['cart_title_color_hover']); }
    if (isset($input['cart_variation_title_color'])) { $settings['cart_variation_title_color'] = sanitize_text_field($input['cart_variation_title_color']); }
    if (isset($input['cart_variation_content_color'])) { $settings['cart_variation_content_color'] = sanitize_text_field($input['cart_variation_content_color']); }
    if (isset($input['cart_quantity_color'])) { $settings['cart_quantity_color'] = sanitize_text_field($input['cart_quantity_color']); }
    if (isset($input['cart_remove_color'])) { $settings['cart_remove_color'] = sanitize_text_field($input['cart_remove_color']); }
    if (isset($input['cart_quantity_color_hover'])) { $settings['cart_quantity_color_hover'] = sanitize_text_field($input['cart_quantity_color_hover']); }
    if (isset($input['cart_remove_color_hover'])) { $settings['cart_remove_color_hover'] = sanitize_text_field($input['cart_remove_color_hover']); }
    if (isset($input['mini_cart_sep_border_style'])) { $settings['mini_cart_sep_border_style'] = sanitize_text_field($input['mini_cart_sep_border_style']); }
    if (isset($input['mini_cart_sep_border_width'])) { $settings['mini_cart_sep_border_width'] = $input['mini_cart_sep_border_width']; }
    if (isset($input['mini_cart_sep_border_color'])) { $settings['mini_cart_sep_border_color'] = sanitize_text_field($input['mini_cart_sep_border_color']); }
    if (isset($input['mini_cart_in_img_size'])) { $settings['mini_cart_in_img_size'] = $input['mini_cart_in_img_size']; }
    if (isset($input['mini_cart_in_img_radius'])) { $settings['mini_cart_in_img_radius'] = $input['mini_cart_in_img_radius']; }
    if (isset($input['cart_subtotal_color'])) { $settings['cart_subtotal_color'] = sanitize_text_field($input['cart_subtotal_color']); }
    if (isset($input['cart_price_color'])) { $settings['cart_price_color'] = sanitize_text_field($input['cart_price_color']); }
    if (isset($input['min_cart_btn_border_style'])) { $settings['min_cart_btn_border_style'] = sanitize_text_field($input['min_cart_btn_border_style']); }
    if (isset($input['min_cart_btn_border_width'])) { $settings['min_cart_btn_border_width'] = $input['min_cart_btn_border_width']; }
    if (isset($input['min_cart_btn_border_color'])) { $settings['min_cart_btn_border_color'] = sanitize_text_field($input['min_cart_btn_border_color']); }
    if (isset($input['min_cart_btn_radius'])) { $settings['min_cart_btn_radius'] = $input['min_cart_btn_radius']; }
    if (isset($input['min_cart_btn_hover_radius'])) { $settings['min_cart_btn_hover_radius'] = $input['min_cart_btn_hover_radius']; }
    if (isset($input['mini_cart_view_btn_padding'])) { $settings['mini_cart_view_btn_padding'] = $input['mini_cart_view_btn_padding']; }
    if (isset($input['min_cart_view_btn_text_color'])) { $settings['min_cart_view_btn_text_color'] = sanitize_text_field($input['min_cart_view_btn_text_color']); }
    if (isset($input['min_cart_view_btn_border_color'])) { $settings['min_cart_view_btn_border_color'] = sanitize_text_field($input['min_cart_view_btn_border_color']); }
    if (isset($input['min_cart_view_btn_text_color_hover'])) { $settings['min_cart_view_btn_text_color_hover'] = sanitize_text_field($input['min_cart_view_btn_text_color_hover']); }
    if (isset($input['min_cart_view_btn_border_hover_color'])) { $settings['min_cart_view_btn_border_hover_color'] = sanitize_text_field($input['min_cart_view_btn_border_hover_color']); }
    if (isset($input['mini_cart_checkout_btn_padding'])) { $settings['mini_cart_checkout_btn_padding'] = $input['mini_cart_checkout_btn_padding']; }
    if (isset($input['min_cart_checkout_btn_text_color'])) { $settings['min_cart_checkout_btn_text_color'] = sanitize_text_field($input['min_cart_checkout_btn_text_color']); }
    if (isset($input['min_cart_checkout_btn_border_color'])) { $settings['min_cart_checkout_btn_border_color'] = sanitize_text_field($input['min_cart_checkout_btn_border_color']); }
    if (isset($input['min_cart_checkout_btn_text_color_hover'])) { $settings['min_cart_checkout_btn_text_color_hover'] = sanitize_text_field($input['min_cart_checkout_btn_text_color_hover']); }
    if (isset($input['min_cart_checkout_btn_border_hover_color'])) { $settings['min_cart_checkout_btn_border_hover_color'] = sanitize_text_field($input['min_cart_checkout_btn_border_hover_color']); }
    if (isset($input['display_scrolling_bar'])) { $settings['display_scrolling_bar'] = sanitize_text_field($input['display_scrolling_bar']); }
    if (isset($input['scroll_scrollbar_width'])) { $settings['scroll_scrollbar_width'] = $input['scroll_scrollbar_width']; }
    if (isset($input['scroll_thumb_border_radius'])) { $settings['scroll_thumb_border_radius'] = $input['scroll_thumb_border_radius']; }
    if (isset($input['scroll_track_border_radius'])) { $settings['scroll_track_border_radius'] = $input['scroll_track_border_radius']; }
    if (isset($input['mc_toggle_icon_close_color'])) { $settings['mc_toggle_icon_close_color'] = sanitize_text_field($input['mc_toggle_icon_close_color']); }
    if (isset($input['mc_toggle_icon_close_bg'])) { $settings['mc_toggle_icon_close_bg'] = sanitize_text_field($input['mc_toggle_icon_close_bg']); }
    if (isset($input['mc_toggle_icon_close_border_radius'])) { $settings['mc_toggle_icon_close_border_radius'] = $input['mc_toggle_icon_close_border_radius']; }
    if (isset($input['mc_toggle_icon_close_color_hover'])) { $settings['mc_toggle_icon_close_color_hover'] = sanitize_text_field($input['mc_toggle_icon_close_color_hover']); }
    if (isset($input['mc_toggle_icon_close_bg_hover'])) { $settings['mc_toggle_icon_close_bg_hover'] = sanitize_text_field($input['mc_toggle_icon_close_bg_hover']); }
    if (isset($input['mc_toggle_icon_close_border_radius_hover'])) { $settings['mc_toggle_icon_close_border_radius_hover'] = $input['mc_toggle_icon_close_border_radius_hover']; }
    if (isset($input['display_extra_toggle_bar'])) { $settings['display_extra_toggle_bar'] = sanitize_text_field($input['display_extra_toggle_bar']); }
    if (isset($input['extra_toggle_style'])) { $settings['extra_toggle_style'] = sanitize_text_field($input['extra_toggle_style']); }
    if (isset($input['extra_toggle_style_custom'])) { $settings['extra_toggle_style_custom'] = sanitize_text_field($input['extra_toggle_style_custom']); }
    if (isset($input['extra_toggle_custom_icon'])) { $settings['extra_toggle_custom_icon'] = sanitize_text_field($input['extra_toggle_custom_icon']); }
    if (!empty($input['extra_toggle_custom_image'])) { $settings['extra_toggle_custom_image'] = ['id' => absint($input['extra_toggle_custom_image'])]; }
    if (isset($input['extra_content_template'])) { $settings['extra_content_template'] = sanitize_text_field($input['extra_content_template']); }
    if (isset($input['extra_toggle_bar_direction'])) { $settings['extra_toggle_bar_direction'] = sanitize_text_field($input['extra_toggle_bar_direction']); }
    if (isset($input['extra_content_width_option'])) { $settings['extra_content_width_option'] = sanitize_text_field($input['extra_content_width_option']); }
    if (isset($input['extra_content_width'])) { $settings['extra_content_width'] = $input['extra_content_width']; }
    if (isset($input['extra_toggle_icon_size'])) { $settings['extra_toggle_icon_size'] = $input['extra_toggle_icon_size']; }
    if (isset($input['extra_toggle_custom_img_radius'])) { $settings['extra_toggle_custom_img_radius'] = $input['extra_toggle_custom_img_radius']; }
    if (isset($input['extra_toggle_icon_color'])) { $settings['extra_toggle_icon_color'] = sanitize_text_field($input['extra_toggle_icon_color']); }
    if (isset($input['extra_toggle_icon_color_hover'])) { $settings['extra_toggle_icon_color_hover'] = sanitize_text_field($input['extra_toggle_icon_color_hover']); }
    if (isset($input['content_inner_padding'])) { $settings['content_inner_padding'] = $input['content_inner_padding']; }
    if (isset($input['extra_toggle_icon_close_color'])) { $settings['extra_toggle_icon_close_color'] = sanitize_text_field($input['extra_toggle_icon_close_color']); }
    if (isset($input['extra_toggle_icon_close_bg'])) { $settings['extra_toggle_icon_close_bg'] = sanitize_text_field($input['extra_toggle_icon_close_bg']); }
    if (isset($input['extra_toggle_icon_close_border_radius'])) { $settings['extra_toggle_icon_close_border_radius'] = $input['extra_toggle_icon_close_border_radius']; }
    if (isset($input['extra_toggle_icon_close_color_hover'])) { $settings['extra_toggle_icon_close_color_hover'] = sanitize_text_field($input['extra_toggle_icon_close_color_hover']); }
    if (isset($input['extra_toggle_icon_close_bg_hover'])) { $settings['extra_toggle_icon_close_bg_hover'] = sanitize_text_field($input['extra_toggle_icon_close_bg_hover']); }
    if (isset($input['extra_toggle_icon_close_border_radius_hover'])) { $settings['extra_toggle_icon_close_border_radius_hover'] = $input['extra_toggle_icon_close_border_radius_hover']; }
    if (isset($input['wpml_ls_padding'])) { $settings['wpml_ls_padding'] = $input['wpml_ls_padding']; }
    if (isset($input['wpml_ls_max_width'])) { $settings['wpml_ls_max_width'] = $input['wpml_ls_max_width']; }
    if (isset($input['wpml_ls_min_width'])) { $settings['wpml_ls_min_width'] = $input['wpml_ls_min_width']; }
    if (isset($input['wpml_ls_size'])) { $settings['wpml_ls_size'] = $input['wpml_ls_size']; }
    if (isset($input['wpml_ls_color_n'])) { $settings['wpml_ls_color_n'] = sanitize_text_field($input['wpml_ls_color_n']); }
    if (isset($input['wpml_ls_br'])) { $settings['wpml_ls_br'] = $input['wpml_ls_br']; }
    if (isset($input['wpml_ls_color_a'])) { $settings['wpml_ls_color_a'] = sanitize_text_field($input['wpml_ls_color_a']); }
    if (isset($input['wpml_ls_br_a'])) { $settings['wpml_ls_br_a'] = $input['wpml_ls_br_a']; }
    if (isset($input['wpml_ba_padding'])) { $settings['wpml_ba_padding'] = $input['wpml_ba_padding']; }
    if (isset($input['wpml_ba_margin'])) { $settings['wpml_ba_margin'] = $input['wpml_ba_margin']; }
    if (isset($input['wpml_ba_color'])) { $settings['wpml_ba_color'] = sanitize_text_field($input['wpml_ba_color']); }
    if (isset($input['wpml_ba_br'])) { $settings['wpml_ba_br'] = $input['wpml_ba_br']; }
    if (isset($input['transp_bg_color'])) { $settings['transp_bg_color'] = sanitize_text_field($input['transp_bg_color']); }
    if (isset($input['transp_br'])) { $settings['transp_br'] = $input['transp_br']; }
    if (isset($input['transp_text_color'])) { $settings['transp_text_color'] = sanitize_text_field($input['transp_text_color']); }
    if (isset($input['transp_text_bg'])) { $settings['transp_text_bg'] = sanitize_text_field($input['transp_text_bg']); }
    if (isset($input['transp_text_br'])) { $settings['transp_text_br'] = $input['transp_text_br']; }
    if (isset($input['transp_text_color_h'])) { $settings['transp_text_color_h'] = sanitize_text_field($input['transp_text_color_h']); }
    if (isset($input['transp_text_bg_h'])) { $settings['transp_text_bg_h'] = sanitize_text_field($input['transp_text_bg_h']); }
    if (isset($input['transp_text_br_h'])) { $settings['transp_text_br_h'] = $input['transp_text_br_h']; }
    if (isset($input['transp_image_size'])) { $settings['transp_image_size'] = $input['transp_image_size']; }
    if (isset($input['transp_image_height_size'])) { $settings['transp_image_height_size'] = $input['transp_image_height_size']; }
    if (isset($input['transp_bottom_space'])) { $settings['transp_bottom_space'] = $input['transp_bottom_space']; }
    if (isset($input['transp_ba_padding'])) { $settings['transp_ba_padding'] = $input['transp_ba_padding']; }
    if (isset($input['transp_ba_margin'])) { $settings['transp_ba_margin'] = $input['transp_ba_margin']; }
    if (isset($input['transp_ba_color'])) { $settings['transp_ba_color'] = sanitize_text_field($input['transp_ba_color']); }
    if (isset($input['transp_ba_br'])) { $settings['transp_ba_br'] = $input['transp_ba_br']; }
    if (isset($input['display_language_switcher'])) { $settings['display_language_switcher'] = sanitize_text_field($input['display_language_switcher']); }
    if (isset($input['select_trans'])) { $settings['select_trans'] = sanitize_text_field($input['select_trans']); }
    if (isset($input['wpml_style'])) { $settings['wpml_style'] = sanitize_text_field($input['wpml_style']); }
    if (isset($input['wpml_style_layout'])) { $settings['wpml_style_layout'] = sanitize_text_field($input['wpml_style_layout']); }
    if (isset($input['skip_language'])) { $settings['skip_language'] = sanitize_text_field($input['skip_language']); }
    if (isset($input['display_country_flag'])) { $settings['display_country_flag'] = sanitize_text_field($input['display_country_flag']); }
    if (isset($input['display_native_name'])) { $settings['display_native_name'] = sanitize_text_field($input['display_native_name']); }
    if (isset($input['display_translated_name'])) { $settings['display_translated_name'] = sanitize_text_field($input['display_translated_name']); }
    if (isset($input['display_language_code'])) { $settings['display_language_code'] = sanitize_text_field($input['display_language_code']); }
    if (isset($input['before_language_text'])) { $settings['before_language_text'] = sanitize_text_field($input['before_language_text']); }
    if (isset($input['after_language_text'])) { $settings['after_language_text'] = sanitize_text_field($input['after_language_text']); }
    if (isset($input['display_music_bar'])) { $settings['display_music_bar'] = sanitize_text_field($input['display_music_bar']); }
    if (isset($input['music_icon_style'])) { $settings['music_icon_style'] = sanitize_text_field($input['music_icon_style']); }
    if (isset($input['music_audio_file'])) { $settings['music_audio_file'] = $input['music_audio_file']; }
    if (isset($input['music_volume'])) { $settings['music_volume'] = $input['music_volume']; }
    if (isset($input['music_bar_icon_color'])) { $settings['music_bar_icon_color'] = sanitize_text_field($input['music_bar_icon_color']); }
    if (isset($input['music_bar_border_style'])) { $settings['music_bar_border_style'] = sanitize_text_field($input['music_bar_border_style']); }
    if (isset($input['music_bar_border_width'])) { $settings['music_bar_border_width'] = $input['music_bar_border_width']; }
    if (isset($input['music_bar_border_color'])) { $settings['music_bar_border_color'] = sanitize_text_field($input['music_bar_border_color']); }
    if (isset($input['music_bar_radius'])) { $settings['music_bar_radius'] = $input['music_bar_radius']; }
    if (isset($input['music_bar_icon_hover_color'])) { $settings['music_bar_icon_hover_color'] = sanitize_text_field($input['music_bar_icon_hover_color']); }
    if (isset($input['music_bar_border_hover_color'])) { $settings['music_bar_border_hover_color'] = sanitize_text_field($input['music_bar_border_hover_color']); }
    if (isset($input['music_bar_hover_radius'])) { $settings['music_bar_hover_radius'] = $input['music_bar_hover_radius']; }
    if (isset($input['display_call_to_action_1'])) { $settings['display_call_to_action_1'] = sanitize_text_field($input['display_call_to_action_1']); }
    if (isset($input['button_1_text'])) { $settings['button_1_text'] = sanitize_text_field($input['button_1_text']); }
    if (isset($input['button_1_link'])) { $settings['button_1_link'] = $input['button_1_link']; }
    if (isset($input['button_1_icon_style'])) { $settings['button_1_icon_style'] = sanitize_text_field($input['button_1_icon_style']); }
    if (isset($input['button_1_icon'])) { $settings['button_1_icon'] = sanitize_text_field($input['button_1_icon']); }
    if (isset($input['button_1_icon_5'])) { $settings['button_1_icon_5'] = sanitize_text_field($input['button_1_icon_5']); }
    if (isset($input['button_1_icons_mind'])) { $settings['button_1_icons_mind'] = sanitize_text_field($input['button_1_icons_mind']); }
    if (isset($input['button_1_before_after'])) { $settings['button_1_before_after'] = sanitize_text_field($input['button_1_before_after']); }
    if (isset($input['button_1_icon_spacing'])) { $settings['button_1_icon_spacing'] = $input['button_1_icon_spacing']; }
    if (isset($input['button_1_icon_size'])) { $settings['button_1_icon_size'] = $input['button_1_icon_size']; }
    if (isset($input['button_1_css_id'])) { $settings['button_1_css_id'] = sanitize_text_field($input['button_1_css_id']); }
    if (isset($input['button_padding'])) { $settings['button_padding'] = $input['button_padding']; }
    if (isset($input['button_1_svg_icon'])) { $settings['button_1_svg_icon'] = $input['button_1_svg_icon']; }
    if (isset($input['button_1_text_color'])) { $settings['button_1_text_color'] = sanitize_text_field($input['button_1_text_color']); }
    if (isset($input['button_1_icon_color'])) { $settings['button_1_icon_color'] = sanitize_text_field($input['button_1_icon_color']); }
    if (isset($input['button_1_border_style'])) { $settings['button_1_border_style'] = sanitize_text_field($input['button_1_border_style']); }
    if (isset($input['button_1_border_width'])) { $settings['button_1_border_width'] = $input['button_1_border_width']; }
    if (isset($input['button_1_border_color'])) { $settings['button_1_border_color'] = sanitize_text_field($input['button_1_border_color']); }
    if (isset($input['button_1_radius'])) { $settings['button_1_radius'] = $input['button_1_radius']; }
    if (isset($input['button_1_text_hover_color'])) { $settings['button_1_text_hover_color'] = sanitize_text_field($input['button_1_text_hover_color']); }
    if (isset($input['button_1_icon_hover'])) { $settings['button_1_icon_hover'] = sanitize_text_field($input['button_1_icon_hover']); }
    if (isset($input['button_1_border_hover_color'])) { $settings['button_1_border_hover_color'] = sanitize_text_field($input['button_1_border_hover_color']); }
    if (isset($input['button_1_hover_radius'])) { $settings['button_1_hover_radius'] = $input['button_1_hover_radius']; }
    if (isset($input['display_call_to_action_2'])) { $settings['display_call_to_action_2'] = sanitize_text_field($input['display_call_to_action_2']); }
    if (isset($input['button_2_text'])) { $settings['button_2_text'] = sanitize_text_field($input['button_2_text']); }
    if (isset($input['button_2_link'])) { $settings['button_2_link'] = $input['button_2_link']; }
    if (isset($input['button_2_icon_style'])) { $settings['button_2_icon_style'] = sanitize_text_field($input['button_2_icon_style']); }
    if (isset($input['button_2_icon'])) { $settings['button_2_icon'] = sanitize_text_field($input['button_2_icon']); }
    if (isset($input['button_2_icon_5'])) { $settings['button_2_icon_5'] = sanitize_text_field($input['button_2_icon_5']); }
    if (isset($input['button_2_icons_mind'])) { $settings['button_2_icons_mind'] = sanitize_text_field($input['button_2_icons_mind']); }
    if (isset($input['button_2_before_after'])) { $settings['button_2_before_after'] = sanitize_text_field($input['button_2_before_after']); }
    if (isset($input['button_2_icon_spacing'])) { $settings['button_2_icon_spacing'] = $input['button_2_icon_spacing']; }
    if (isset($input['button_2_icon_size'])) { $settings['button_2_icon_size'] = $input['button_2_icon_size']; }
    if (isset($input['button_2_css_id'])) { $settings['button_2_css_id'] = sanitize_text_field($input['button_2_css_id']); }
    if (isset($input['button_2_padding'])) { $settings['button_2_padding'] = $input['button_2_padding']; }
    if (isset($input['button_2_svg_icon'])) { $settings['button_2_svg_icon'] = $input['button_2_svg_icon']; }
    if (isset($input['button_2_text_color'])) { $settings['button_2_text_color'] = sanitize_text_field($input['button_2_text_color']); }
    if (isset($input['button_2_border_style'])) { $settings['button_2_border_style'] = sanitize_text_field($input['button_2_border_style']); }
    if (isset($input['button_2_border_width'])) { $settings['button_2_border_width'] = $input['button_2_border_width']; }
    if (isset($input['button_2_border_color'])) { $settings['button_2_border_color'] = sanitize_text_field($input['button_2_border_color']); }
    if (isset($input['button_2_radius'])) { $settings['button_2_radius'] = $input['button_2_radius']; }
    if (isset($input['button_2_text_hover_color'])) { $settings['button_2_text_hover_color'] = sanitize_text_field($input['button_2_text_hover_color']); }
    if (isset($input['button_2_border_hover_color'])) { $settings['button_2_border_hover_color'] = sanitize_text_field($input['button_2_border_hover_color']); }
    if (isset($input['button_2_hover_radius'])) { $settings['button_2_hover_radius'] = $input['button_2_hover_radius']; }
    if (isset($input['icon_alignment'])) { $settings['icon_alignment'] = sanitize_text_field($input['icon_alignment']); }
    if (isset($input['icon_between_padding'])) { $settings['icon_between_padding'] = $input['icon_between_padding']; }
    if (isset($input['tpaep_theme_builder'])) { $settings['tpaep_theme_builder'] = sanitize_text_field($input['tpaep_theme_builder']); }
    if (isset($input['sticky_options'])) { $settings['sticky_options'] = sanitize_text_field($input['sticky_options']); }
    if (isset($input['s_search_icon_color'])) { $settings['s_search_icon_color'] = sanitize_text_field($input['s_search_icon_color']); }
    if (isset($input['s_cart_icon_color'])) { $settings['s_cart_icon_color'] = sanitize_text_field($input['s_cart_icon_color']); }
    if (isset($input['s_cart_count_color'])) { $settings['s_cart_count_color'] = sanitize_text_field($input['s_cart_count_color']); }
    if (isset($input['s_extra_toggle_icon_color'])) { $settings['s_extra_toggle_icon_color'] = sanitize_text_field($input['s_extra_toggle_icon_color']); }
    if (isset($input['s_music_bar_icon_color'])) { $settings['s_music_bar_icon_color'] = sanitize_text_field($input['s_music_bar_icon_color']); }
    if (isset($input['s_button_1_text_color'])) { $settings['s_button_1_text_color'] = sanitize_text_field($input['s_button_1_text_color']); }
    if (isset($input['s_button_1_radius'])) { $settings['s_button_1_radius'] = $input['s_button_1_radius']; }
    if (isset($input['s_button_2_text_color'])) { $settings['s_button_2_text_color'] = sanitize_text_field($input['s_button_2_text_color']); }
    if (isset($input['s_button_2_radius'])) { $settings['s_button_2_radius'] = $input['s_button_2_radius']; }
    if (isset($input['s_search_icon_color_hover'])) { $settings['s_search_icon_color_hover'] = sanitize_text_field($input['s_search_icon_color_hover']); }
    if (isset($input['s_cart_icon_color_hover'])) { $settings['s_cart_icon_color_hover'] = sanitize_text_field($input['s_cart_icon_color_hover']); }
    if (isset($input['s_cart_count_color_hover'])) { $settings['s_cart_count_color_hover'] = sanitize_text_field($input['s_cart_count_color_hover']); }
    if (isset($input['s_extra_toggle_icon_color_hover'])) { $settings['s_extra_toggle_icon_color_hover'] = sanitize_text_field($input['s_extra_toggle_icon_color_hover']); }
    if (isset($input['s_music_bar_icon_hover_color'])) { $settings['s_music_bar_icon_hover_color'] = sanitize_text_field($input['s_music_bar_icon_hover_color']); }
    if (isset($input['s_button_1_text_hover_color'])) { $settings['s_button_1_text_hover_color'] = sanitize_text_field($input['s_button_1_text_hover_color']); }
    if (isset($input['s_button_1_hover_radius'])) { $settings['s_button_1_hover_radius'] = $input['s_button_1_hover_radius']; }
    if (isset($input['s_button_2_text_hover_color'])) { $settings['s_button_2_text_hover_color'] = sanitize_text_field($input['s_button_2_text_hover_color']); }
    if (isset($input['s_button_2_hover_radius'])) { $settings['s_button_2_hover_radius'] = $input['s_button_2_hover_radius']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
