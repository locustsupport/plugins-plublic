<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-site-logo', [
'label' => __('Site Logo', 'theplus'),
    'description' => __('Adds The Plus "Site Logo" widget (tp-site-logo) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'logo_animate' => ['type' => 'string', 'description' => 'Logo', 'enum' => ['double', 'normal']],
        'logo_type' => ['type' => 'string', 'description' => 'logo_type', 'enum' => ['svg']],
        'image_logo' => ['type' => 'integer', 'description' => 'Image Logo (Image ID)'],
        'svg_logo' => ['type' => 'integer', 'description' => 'Only Svg Logo (Image ID)'],
        'logo_max_width' => ['type' => 'object', 'description' => 'Logo Max Width (Slider/Size Object)'],
        'hover_image_logo' => ['type' => 'integer', 'description' => 'Hover Logo Image (Image ID)'],
        'hover_svg_logo' => ['type' => 'integer', 'description' => 'Hover Svg Logo (Image ID)'],
        'hover_logo_max_width' => ['type' => 'object', 'description' => 'Hover Logo Max Width (Slider/Size Object)'],
        'logo_url_type' => ['type' => 'string', 'description' => 'Logo URL Type', 'enum' => ['custom_url', 'home_url']],
        'logo_url' => ['type' => 'object', 'description' => 'Logo URL'],
        'logo_alignment' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'icon', 'left', 'right', 'toggle', '{{WRAPPER}} .plus-site-logo']],
        'sticky_logo' => ['type' => 'string', 'description' => 'Sticky Logo', 'enum' => ['yes', 'no']],
        'sticky_image_logo' => ['type' => 'integer', 'description' => 'Image Logo (Image ID)'],
        'sticky_svg_logo' => ['type' => 'integer', 'description' => 'Only Svg Logo (Image ID)'],
        'sticky_logo_max_width' => ['type' => 'object', 'description' => 'Logo Max Width (Slider/Size Object)'],
        'tpaep_theme_builder' => ['type' => 'string', 'description' => 'tpaep_theme_builder'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports SVG animation injection, dynamic sticky state switching, and responsive brand geometry.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_site_logo_ability',
    'permission_callback' => 'tpaep_mcp_theplus_site_logo_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_site_logo_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_site_logo_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-site-logo';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Site Logo widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['logo_animate'])) { $settings['logo_animate'] = sanitize_text_field($input['logo_animate']); }
    if (isset($input['logo_type'])) { $settings['logo_type'] = sanitize_text_field($input['logo_type']); }
    if (!empty($input['image_logo'])) { $settings['image_logo'] = ['id' => absint($input['image_logo'])]; }
    if (!empty($input['svg_logo'])) { $settings['svg_logo'] = ['id' => absint($input['svg_logo'])]; }
    if (isset($input['logo_max_width'])) { $settings['logo_max_width'] = $input['logo_max_width']; }
    if (!empty($input['hover_image_logo'])) { $settings['hover_image_logo'] = ['id' => absint($input['hover_image_logo'])]; }
    if (!empty($input['hover_svg_logo'])) { $settings['hover_svg_logo'] = ['id' => absint($input['hover_svg_logo'])]; }
    if (isset($input['hover_logo_max_width'])) { $settings['hover_logo_max_width'] = $input['hover_logo_max_width']; }
    if (isset($input['logo_url_type'])) { $settings['logo_url_type'] = sanitize_text_field($input['logo_url_type']); }
    if (isset($input['logo_url'])) { $settings['logo_url'] = $input['logo_url']; }
    if (isset($input['logo_alignment'])) { $settings['logo_alignment'] = $input['logo_alignment']; }
    if (isset($input['sticky_logo'])) { $settings['sticky_logo'] = sanitize_text_field($input['sticky_logo']); }
    if (!empty($input['sticky_image_logo'])) { $settings['sticky_image_logo'] = ['id' => absint($input['sticky_image_logo'])]; }
    if (!empty($input['sticky_svg_logo'])) { $settings['sticky_svg_logo'] = ['id' => absint($input['sticky_svg_logo'])]; }
    if (isset($input['sticky_logo_max_width'])) { $settings['sticky_logo_max_width'] = $input['sticky_logo_max_width']; }
    if (isset($input['tpaep_theme_builder'])) { $settings['tpaep_theme_builder'] = sanitize_text_field($input['tpaep_theme_builder']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
