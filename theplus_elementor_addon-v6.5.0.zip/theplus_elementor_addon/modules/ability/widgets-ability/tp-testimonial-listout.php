<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-testimonial-listout', [
'label' => __('Testimonial Listout (Pro)', 'theplus'),
    'description' => __('Adds The Plus "Testimonial Listout" widget (tp-testimonial-listout) to an Elementor container. Pro version with extra styles.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'          => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'        => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'         => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'style-1', 'style-2', 'style-3', 'style-4']],
        'layout' => ['type' => 'string', 'description' => 'Layout', 'enum' => ['carousel', 'columns', 'grid', 'masonry']],
        'content_alignment_4' => ['type' => 'string', 'description' => 'Content Alignment', 'enum' => ['icon', 'left', 'right', 'style', 'toggle']],
        'style_3_layout' => ['type' => 'string', 'description' => 'Style Layout', 'enum' => ['style']],
        'tlContentFrom' => ['type' => 'string', 'description' => 'Select Source', 'enum' => ['tlcontent', 'tlrepeater']],
        'testiAuthor' => ['type' => 'string', 'description' => 'Testimonial Content'],
        'testiTitle' => ['type' => 'string', 'description' => 'Testimonial Title'],
        'testiLabel' => ['type' => 'string', 'description' => 'Author Name'],
        'testiDesign' => ['type' => 'string', 'description' => 'Author Designation'],
        'show_author_image' => ['type' => 'string', 'description' => 'Show Author Image', 'enum' => ['yes', 'no']],
        'testiImage' => ['type' => 'integer', 'description' => 'Author Image (Image ID)'],
        'testiLogo' => ['type' => 'integer', 'description' => 'Company Logo (Image ID)'],
        'testiAllList' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Manage Testimonials'],
        'desktop_column' => ['type' => 'string', 'description' => 'Desktop Column', 'enum' => ['layout!']],
        'tablet_column' => ['type' => 'string', 'description' => 'Tablet Column', 'enum' => ['layout!']],
        'mobile_column' => ['type' => 'string', 'description' => 'Mobile Column', 'enum' => ['layout!']],
        'columns_gap' => ['type' => 'object', 'description' => 'Columns Gap/Space Between (Dimensions Object)'],
        'post_category' => ['type' => 'string', 'description' => 'Select Category', 'enum' => ['multiple']],
        'display_posts' => ['type' => 'string', 'description' => 'Maximum Posts Display'],
        'post_offset' => ['type' => 'string', 'description' => 'Offset Posts'],
        'post_order_by' => ['type' => 'string', 'description' => 'Order By'],
        'post_order' => ['type' => 'string', 'description' => 'Order'],
        'post_title_tag' => ['type' => 'string', 'description' => 'Title Tag'],
        'display_thumbnail' => ['type' => 'string', 'description' => 'Display Image Size', 'enum' => ['yes', 'no']],
        'show_author_image' => ['type' => 'string', 'description' => 'Display Author Image', 'enum' => ['yes', 'no']],
        'caroByheight' => ['type' => 'string', 'description' => 'Content Limit By', 'enum' => ['height', 'layout', 'text-limit', 'tlContentFrom']],
        'contentHei' => ['type' => 'object', 'description' => 'contentHei (Slider/Size Object)'],
        'titleHei' => ['type' => 'object', 'description' => 'Title Height(px) (Slider/Size Object)'],
        'cntscrollOn' => ['type' => 'string', 'description' => 'Content Scroll', 'enum' => ['conditions', 'name', 'on-hover', 'operator', 'relation', 'terms', 'value', 'visible']],
        'descByLimit' => ['type' => 'string', 'description' => 'descByLimit', 'enum' => ['conditions', 'letters', 'name', 'operator', 'relation', 'terms', 'tlContentFrom', 'value', 'words']],
        'descLimit' => ['type' => 'string', 'description' => 'Maximum Letters/Words'],
        'titleByLimit' => ['type' => 'string', 'description' => 'Title Limit', 'enum' => ['caroByheight', 'layout', 'letters', 'tlContentFrom', 'words']],
        'titleLimit' => ['type' => 'string', 'description' => 'Maximum Letters/Words'],
        'redmorTxt' => ['type' => 'string', 'description' => 'Read More'],
        'redlesTxt' => ['type' => 'string', 'description' => 'Read Less'],
        'title_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'title_hover_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'extra_title_color' => ['type' => 'string', 'description' => 'Extra Title Color (Color Hex/RGBA)'],
        'extra_title_hover_color' => ['type' => 'string', 'description' => 'Extra Title Color (Color Hex/RGBA)'],
        'designation_color' => ['type' => 'string', 'description' => 'Designation Color (Color Hex/RGBA)'],
        'designation_hover_color' => ['type' => 'string', 'description' => 'Designation Color (Color Hex/RGBA)'],
        'excerpt_color' => ['type' => 'string', 'description' => 'Content Color (Color Hex/RGBA)'],
        'excerpt_hover_color' => ['type' => 'string', 'description' => 'Content Color (Color Hex/RGBA)'],
        'content_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'content_inner_padding' => ['type' => 'object', 'description' => 'Inner Padding (Dimensions Object)'],
        'content_bg_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'down_arrow_color' => ['type' => 'string', 'description' => 'Down Arrow Color (Color Hex/RGBA)'],
        'border_bottom_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'down_arrow_hover_color' => ['type' => 'string', 'description' => 'Down Arrow Color (Color Hex/RGBA)'],
        'border_bottom_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'readColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'readmhvrColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'tesSclWidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'tesThumbBrs' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'tesTrackBRs' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'featured_image_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'carousel_unique_id' => ['type' => 'string', 'description' => 'Unique Carousel ID'],
        'slider_direction' => ['type' => 'string', 'description' => 'Slider Mode', 'enum' => ['horizontal', 'vertical']],
        'carousel_direction' => ['type' => 'string', 'description' => 'Slide Direction', 'enum' => ['ltr', 'rtl']],
        'slide_speed' => ['type' => 'object', 'description' => 'Slide Speed (Slider/Size Object)'],
        'slider_desktop_column' => ['type' => 'string', 'description' => 'Desktop Columns'],
        'steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_padding' => ['type' => 'object', 'description' => 'Slide Padding (Dimensions Object)'],
        'slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'multi_drag' => ['type' => 'string', 'description' => 'Multi Drag', 'enum' => ['yes', 'no']],
        'slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'slider_pause_hover' => ['type' => 'string', 'description' => 'Pause On Hover', 'enum' => ['yes', 'no']],
        'slider_adaptive_height' => ['type' => 'string', 'description' => 'Adaptive Height', 'enum' => ['yes', 'no']],
        'slider_animation' => ['type' => 'string', 'description' => 'Animation Type', 'enum' => ['ease', 'linear']],
        'slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['slider_dots', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['slider_arrows', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'slider_arrows', 'slider_arrows_style', 'top-right']],
        'arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'arrow_y_space' => ['type' => 'object', 'description' => 'Position Y (Slider/Size Object)'],
        'outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'slider_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'slider_center_effects' => ['type' => 'string', 'description' => 'Center Slide Effects', 'enum' => ['slider_center_mode']],
        'scale_center_slide' => ['type' => 'object', 'description' => 'Center Slide Scale (Slider/Size Object)'],
        'scale_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Scale (Slider/Size Object)'],
        'opacity_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Opacity (Slider/Size Object)'],
        'slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3']],
        'slide_row_top_space' => ['type' => 'object', 'description' => 'Row Top Space (Slider/Size Object)'],
        'slider_tablet_column' => ['type' => 'string', 'description' => 'Tablet Columns'],
        'tablet_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_tablet' => ['type' => 'string', 'description' => 'Responsive Tablet', 'enum' => ['yes', 'no']],
        'tablet_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'tablet_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'tablet_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'tablet_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'tablet_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['slider_responsive_tablet', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7', 'tablet_slider_dots']],
        'tablet_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'tablet_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'tablet_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'tablet_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'tablet_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'tablet_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['slider_responsive_tablet', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'tablet_slider_arrows']],
        'tablet_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'slider_responsive_tablet', 'tablet_slider_arrows', 'tablet_slider_arrows_style', 'top-right']],
        'tablet_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'tablet_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'tablet_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'tablet_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'tablet_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'tablet_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'tablet_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3', 'slider_responsive_tablet']],
        'tablet_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'tablet_center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'slider_mobile_column' => ['type' => 'string', 'description' => 'Mobile Columns'],
        'mobile_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_mobile' => ['type' => 'string', 'description' => 'Responsive Mobile', 'enum' => ['yes', 'no']],
        'mobile_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'mobile_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'mobile_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'mobile_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'mobile_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['mobile_slider_dots', 'slider_responsive_mobile', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'mobile_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'mobile_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'mobile_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'mobile_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'mobile_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'mobile_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['mobile_slider_arrows', 'slider_responsive_mobile', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'mobile_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'mobile_slider_arrows', 'mobile_slider_arrows_style', 'slider_responsive_mobile', 'top-right']],
        'mobile_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'mobile_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'mobile_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'mobile_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'mobile_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'mobile_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'mobile_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3', 'slider_responsive_mobile']],
        'mobile_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'mobile_center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'pnf_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'pnf_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'pnf_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'messy_column' => ['type' => 'string', 'description' => 'Messy Columns', 'enum' => ['yes', 'no']],
        'desktop_column_1' => ['type' => 'object', 'description' => 'Column 1 (Slider/Size Object)'],
        'desktop_column_2' => ['type' => 'object', 'description' => 'Column 2 (Slider/Size Object)'],
        'desktop_column_3' => ['type' => 'object', 'description' => 'Column 3 (Slider/Size Object)'],
        'desktop_column_4' => ['type' => 'object', 'description' => 'Column 4 (Slider/Size Object)'],
        'desktop_column_5' => ['type' => 'object', 'description' => 'Column 5 (Slider/Size Object)'],
        'desktop_column_6' => ['type' => 'object', 'description' => 'Column 6 (Slider/Size Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports SVG quote animations, multi-style carousels, and dynamic taxonomy filters.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_pro_testimonial_listout_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pro_testimonial_listout_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_pro_testimonial_listout_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_pro_testimonial_listout_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-testimonial-listout';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Testimonial Listout widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['style'])) { $settings['style'] = sanitize_text_field($input['style']); }
    if (isset($input['layout'])) { $settings['layout'] = sanitize_text_field($input['layout']); }
    if (isset($input['content_alignment_4'])) { $settings['content_alignment_4'] = sanitize_text_field($input['content_alignment_4']); }
    if (isset($input['style_3_layout'])) { $settings['style_3_layout'] = sanitize_text_field($input['style_3_layout']); }
    if (isset($input['tlContentFrom'])) { $settings['tlContentFrom'] = sanitize_text_field($input['tlContentFrom']); }
    if (isset($input['testiAuthor'])) { $settings['testiAuthor'] = sanitize_text_field($input['testiAuthor']); }
    if (isset($input['testiTitle'])) { $settings['testiTitle'] = sanitize_text_field($input['testiTitle']); }
    if (isset($input['testiLabel'])) { $settings['testiLabel'] = sanitize_text_field($input['testiLabel']); }
    if (isset($input['testiDesign'])) { $settings['testiDesign'] = sanitize_text_field($input['testiDesign']); }
    if (isset($input['show_author_image'])) { $settings['show_author_image'] = sanitize_text_field($input['show_author_image']); }
    if (!empty($input['testiImage'])) { $settings['testiImage'] = ['id' => absint($input['testiImage'])]; }
    if (!empty($input['testiLogo'])) { $settings['testiLogo'] = ['id' => absint($input['testiLogo'])]; }
    if (isset($input['testiAllList'])) { $settings['testiAllList'] = $input['testiAllList']; }
    if (isset($input['desktop_column'])) { $settings['desktop_column'] = sanitize_text_field($input['desktop_column']); }
    if (isset($input['tablet_column'])) { $settings['tablet_column'] = sanitize_text_field($input['tablet_column']); }
    if (isset($input['mobile_column'])) { $settings['mobile_column'] = sanitize_text_field($input['mobile_column']); }
    if (isset($input['columns_gap'])) { $settings['columns_gap'] = $input['columns_gap']; }
    if (isset($input['post_category'])) { $settings['post_category'] = sanitize_text_field($input['post_category']); }
    if (isset($input['display_posts'])) { $settings['display_posts'] = sanitize_text_field($input['display_posts']); }
    if (isset($input['post_offset'])) { $settings['post_offset'] = sanitize_text_field($input['post_offset']); }
    if (isset($input['post_order_by'])) { $settings['post_order_by'] = sanitize_text_field($input['post_order_by']); }
    if (isset($input['post_order'])) { $settings['post_order'] = sanitize_text_field($input['post_order']); }
    if (isset($input['post_title_tag'])) { $settings['post_title_tag'] = sanitize_text_field($input['post_title_tag']); }
    if (isset($input['display_thumbnail'])) { $settings['display_thumbnail'] = sanitize_text_field($input['display_thumbnail']); }
    if (isset($input['show_author_image'])) { $settings['show_author_image'] = sanitize_text_field($input['show_author_image']); }
    if (isset($input['caroByheight'])) { $settings['caroByheight'] = sanitize_text_field($input['caroByheight']); }
    if (isset($input['contentHei'])) { $settings['contentHei'] = $input['contentHei']; }
    if (isset($input['titleHei'])) { $settings['titleHei'] = $input['titleHei']; }
    if (isset($input['cntscrollOn'])) { $settings['cntscrollOn'] = sanitize_text_field($input['cntscrollOn']); }
    if (isset($input['descByLimit'])) { $settings['descByLimit'] = sanitize_text_field($input['descByLimit']); }
    if (isset($input['descLimit'])) { $settings['descLimit'] = sanitize_text_field($input['descLimit']); }
    if (isset($input['titleByLimit'])) { $settings['titleByLimit'] = sanitize_text_field($input['titleByLimit']); }
    if (isset($input['titleLimit'])) { $settings['titleLimit'] = sanitize_text_field($input['titleLimit']); }
    if (isset($input['redmorTxt'])) { $settings['redmorTxt'] = sanitize_text_field($input['redmorTxt']); }
    if (isset($input['redlesTxt'])) { $settings['redlesTxt'] = sanitize_text_field($input['redlesTxt']); }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['title_hover_color'])) { $settings['title_hover_color'] = sanitize_text_field($input['title_hover_color']); }
    if (isset($input['extra_title_color'])) { $settings['extra_title_color'] = sanitize_text_field($input['extra_title_color']); }
    if (isset($input['extra_title_hover_color'])) { $settings['extra_title_hover_color'] = sanitize_text_field($input['extra_title_hover_color']); }
    if (isset($input['designation_color'])) { $settings['designation_color'] = sanitize_text_field($input['designation_color']); }
    if (isset($input['designation_hover_color'])) { $settings['designation_hover_color'] = sanitize_text_field($input['designation_hover_color']); }
    if (isset($input['excerpt_color'])) { $settings['excerpt_color'] = sanitize_text_field($input['excerpt_color']); }
    if (isset($input['excerpt_hover_color'])) { $settings['excerpt_hover_color'] = sanitize_text_field($input['excerpt_hover_color']); }
    if (isset($input['content_margin'])) { $settings['content_margin'] = $input['content_margin']; }
    if (isset($input['content_inner_padding'])) { $settings['content_inner_padding'] = $input['content_inner_padding']; }
    if (isset($input['content_bg_radius'])) { $settings['content_bg_radius'] = $input['content_bg_radius']; }
    if (isset($input['down_arrow_color'])) { $settings['down_arrow_color'] = sanitize_text_field($input['down_arrow_color']); }
    if (isset($input['border_bottom_color'])) { $settings['border_bottom_color'] = sanitize_text_field($input['border_bottom_color']); }
    if (isset($input['down_arrow_hover_color'])) { $settings['down_arrow_hover_color'] = sanitize_text_field($input['down_arrow_hover_color']); }
    if (isset($input['border_bottom_hover_color'])) { $settings['border_bottom_hover_color'] = sanitize_text_field($input['border_bottom_hover_color']); }
    if (isset($input['readColor'])) { $settings['readColor'] = sanitize_text_field($input['readColor']); }
    if (isset($input['readmhvrColor'])) { $settings['readmhvrColor'] = sanitize_text_field($input['readmhvrColor']); }
    if (isset($input['tesSclWidth'])) { $settings['tesSclWidth'] = $input['tesSclWidth']; }
    if (isset($input['tesThumbBrs'])) { $settings['tesThumbBrs'] = $input['tesThumbBrs']; }
    if (isset($input['tesTrackBRs'])) { $settings['tesTrackBRs'] = $input['tesTrackBRs']; }
    if (isset($input['featured_image_radius'])) { $settings['featured_image_radius'] = $input['featured_image_radius']; }
    if (isset($input['carousel_unique_id'])) { $settings['carousel_unique_id'] = sanitize_text_field($input['carousel_unique_id']); }
    if (isset($input['slider_direction'])) { $settings['slider_direction'] = sanitize_text_field($input['slider_direction']); }
    if (isset($input['carousel_direction'])) { $settings['carousel_direction'] = sanitize_text_field($input['carousel_direction']); }
    if (isset($input['slide_speed'])) { $settings['slide_speed'] = $input['slide_speed']; }
    if (isset($input['slider_desktop_column'])) { $settings['slider_desktop_column'] = sanitize_text_field($input['slider_desktop_column']); }
    if (isset($input['steps_slide'])) { $settings['steps_slide'] = sanitize_text_field($input['steps_slide']); }
    if (isset($input['slider_padding'])) { $settings['slider_padding'] = $input['slider_padding']; }
    if (isset($input['slider_draggable'])) { $settings['slider_draggable'] = sanitize_text_field($input['slider_draggable']); }
    if (isset($input['multi_drag'])) { $settings['multi_drag'] = sanitize_text_field($input['multi_drag']); }
    if (isset($input['slider_infinite'])) { $settings['slider_infinite'] = sanitize_text_field($input['slider_infinite']); }
    if (isset($input['slider_pause_hover'])) { $settings['slider_pause_hover'] = sanitize_text_field($input['slider_pause_hover']); }
    if (isset($input['slider_adaptive_height'])) { $settings['slider_adaptive_height'] = sanitize_text_field($input['slider_adaptive_height']); }
    if (isset($input['slider_animation'])) { $settings['slider_animation'] = sanitize_text_field($input['slider_animation']); }
    if (isset($input['slider_autoplay'])) { $settings['slider_autoplay'] = sanitize_text_field($input['slider_autoplay']); }
    if (isset($input['autoplay_speed'])) { $settings['autoplay_speed'] = $input['autoplay_speed']; }
    if (isset($input['slider_dots'])) { $settings['slider_dots'] = sanitize_text_field($input['slider_dots']); }
    if (isset($input['slider_dots_style'])) { $settings['slider_dots_style'] = sanitize_text_field($input['slider_dots_style']); }
    if (isset($input['dots_border_color'])) { $settings['dots_border_color'] = sanitize_text_field($input['dots_border_color']); }
    if (isset($input['dots_bg_color'])) { $settings['dots_bg_color'] = sanitize_text_field($input['dots_bg_color']); }
    if (isset($input['dots_active_border_color'])) { $settings['dots_active_border_color'] = sanitize_text_field($input['dots_active_border_color']); }
    if (isset($input['dots_active_bg_color'])) { $settings['dots_active_bg_color'] = sanitize_text_field($input['dots_active_bg_color']); }
    if (isset($input['dots_top_padding'])) { $settings['dots_top_padding'] = $input['dots_top_padding']; }
    if (isset($input['hover_show_dots'])) { $settings['hover_show_dots'] = sanitize_text_field($input['hover_show_dots']); }
    if (isset($input['slider_arrows'])) { $settings['slider_arrows'] = sanitize_text_field($input['slider_arrows']); }
    if (isset($input['slider_arrows_style'])) { $settings['slider_arrows_style'] = sanitize_text_field($input['slider_arrows_style']); }
    if (isset($input['arrows_position'])) { $settings['arrows_position'] = sanitize_text_field($input['arrows_position']); }
    if (isset($input['arrow_bg_color'])) { $settings['arrow_bg_color'] = sanitize_text_field($input['arrow_bg_color']); }
    if (isset($input['arrow_icon_color'])) { $settings['arrow_icon_color'] = sanitize_text_field($input['arrow_icon_color']); }
    if (isset($input['arrow_hover_bg_color'])) { $settings['arrow_hover_bg_color'] = sanitize_text_field($input['arrow_hover_bg_color']); }
    if (isset($input['arrow_hover_icon_color'])) { $settings['arrow_hover_icon_color'] = sanitize_text_field($input['arrow_hover_icon_color']); }
    if (isset($input['arrow_y_space'])) { $settings['arrow_y_space'] = $input['arrow_y_space']; }
    if (isset($input['outer_section_arrow'])) { $settings['outer_section_arrow'] = sanitize_text_field($input['outer_section_arrow']); }
    if (isset($input['hover_show_arrow'])) { $settings['hover_show_arrow'] = sanitize_text_field($input['hover_show_arrow']); }
    if (isset($input['slider_center_mode'])) { $settings['slider_center_mode'] = sanitize_text_field($input['slider_center_mode']); }
    if (isset($input['center_padding'])) { $settings['center_padding'] = $input['center_padding']; }
    if (isset($input['slider_center_effects'])) { $settings['slider_center_effects'] = sanitize_text_field($input['slider_center_effects']); }
    if (isset($input['scale_center_slide'])) { $settings['scale_center_slide'] = $input['scale_center_slide']; }
    if (isset($input['scale_normal_slide'])) { $settings['scale_normal_slide'] = $input['scale_normal_slide']; }
    if (isset($input['opacity_normal_slide'])) { $settings['opacity_normal_slide'] = $input['opacity_normal_slide']; }
    if (isset($input['slider_rows'])) { $settings['slider_rows'] = sanitize_text_field($input['slider_rows']); }
    if (isset($input['slide_row_top_space'])) { $settings['slide_row_top_space'] = $input['slide_row_top_space']; }
    if (isset($input['slider_tablet_column'])) { $settings['slider_tablet_column'] = sanitize_text_field($input['slider_tablet_column']); }
    if (isset($input['tablet_steps_slide'])) { $settings['tablet_steps_slide'] = sanitize_text_field($input['tablet_steps_slide']); }
    if (isset($input['slider_responsive_tablet'])) { $settings['slider_responsive_tablet'] = sanitize_text_field($input['slider_responsive_tablet']); }
    if (isset($input['tablet_slider_draggable'])) { $settings['tablet_slider_draggable'] = sanitize_text_field($input['tablet_slider_draggable']); }
    if (isset($input['tablet_slider_infinite'])) { $settings['tablet_slider_infinite'] = sanitize_text_field($input['tablet_slider_infinite']); }
    if (isset($input['tablet_slider_autoplay'])) { $settings['tablet_slider_autoplay'] = sanitize_text_field($input['tablet_slider_autoplay']); }
    if (isset($input['tablet_autoplay_speed'])) { $settings['tablet_autoplay_speed'] = $input['tablet_autoplay_speed']; }
    if (isset($input['tablet_slider_dots'])) { $settings['tablet_slider_dots'] = sanitize_text_field($input['tablet_slider_dots']); }
    if (isset($input['tablet_slider_dots_style'])) { $settings['tablet_slider_dots_style'] = sanitize_text_field($input['tablet_slider_dots_style']); }
    if (isset($input['tablet_dots_border_color'])) { $settings['tablet_dots_border_color'] = sanitize_text_field($input['tablet_dots_border_color']); }
    if (isset($input['tablet_dots_bg_color'])) { $settings['tablet_dots_bg_color'] = sanitize_text_field($input['tablet_dots_bg_color']); }
    if (isset($input['tablet_dots_active_border_color'])) { $settings['tablet_dots_active_border_color'] = sanitize_text_field($input['tablet_dots_active_border_color']); }
    if (isset($input['tablet_dots_active_bg_color'])) { $settings['tablet_dots_active_bg_color'] = sanitize_text_field($input['tablet_dots_active_bg_color']); }
    if (isset($input['tablet_dots_top_padding'])) { $settings['tablet_dots_top_padding'] = $input['tablet_dots_top_padding']; }
    if (isset($input['tablet_hover_show_dots'])) { $settings['tablet_hover_show_dots'] = sanitize_text_field($input['tablet_hover_show_dots']); }
    if (isset($input['tablet_slider_arrows'])) { $settings['tablet_slider_arrows'] = sanitize_text_field($input['tablet_slider_arrows']); }
    if (isset($input['tablet_slider_arrows_style'])) { $settings['tablet_slider_arrows_style'] = sanitize_text_field($input['tablet_slider_arrows_style']); }
    if (isset($input['tablet_arrows_position'])) { $settings['tablet_arrows_position'] = sanitize_text_field($input['tablet_arrows_position']); }
    if (isset($input['tablet_arrow_bg_color'])) { $settings['tablet_arrow_bg_color'] = sanitize_text_field($input['tablet_arrow_bg_color']); }
    if (isset($input['tablet_arrow_icon_color'])) { $settings['tablet_arrow_icon_color'] = sanitize_text_field($input['tablet_arrow_icon_color']); }
    if (isset($input['tablet_arrow_hover_bg_color'])) { $settings['tablet_arrow_hover_bg_color'] = sanitize_text_field($input['tablet_arrow_hover_bg_color']); }
    if (isset($input['tablet_arrow_hover_icon_color'])) { $settings['tablet_arrow_hover_icon_color'] = sanitize_text_field($input['tablet_arrow_hover_icon_color']); }
    if (isset($input['tablet_outer_section_arrow'])) { $settings['tablet_outer_section_arrow'] = sanitize_text_field($input['tablet_outer_section_arrow']); }
    if (isset($input['tablet_hover_show_arrow'])) { $settings['tablet_hover_show_arrow'] = sanitize_text_field($input['tablet_hover_show_arrow']); }
    if (isset($input['tablet_slider_rows'])) { $settings['tablet_slider_rows'] = sanitize_text_field($input['tablet_slider_rows']); }
    if (isset($input['tablet_center_mode'])) { $settings['tablet_center_mode'] = sanitize_text_field($input['tablet_center_mode']); }
    if (isset($input['tablet_center_padding'])) { $settings['tablet_center_padding'] = $input['tablet_center_padding']; }
    if (isset($input['slider_mobile_column'])) { $settings['slider_mobile_column'] = sanitize_text_field($input['slider_mobile_column']); }
    if (isset($input['mobile_steps_slide'])) { $settings['mobile_steps_slide'] = sanitize_text_field($input['mobile_steps_slide']); }
    if (isset($input['slider_responsive_mobile'])) { $settings['slider_responsive_mobile'] = sanitize_text_field($input['slider_responsive_mobile']); }
    if (isset($input['mobile_slider_draggable'])) { $settings['mobile_slider_draggable'] = sanitize_text_field($input['mobile_slider_draggable']); }
    if (isset($input['mobile_slider_infinite'])) { $settings['mobile_slider_infinite'] = sanitize_text_field($input['mobile_slider_infinite']); }
    if (isset($input['mobile_slider_autoplay'])) { $settings['mobile_slider_autoplay'] = sanitize_text_field($input['mobile_slider_autoplay']); }
    if (isset($input['mobile_autoplay_speed'])) { $settings['mobile_autoplay_speed'] = $input['mobile_autoplay_speed']; }
    if (isset($input['mobile_slider_dots'])) { $settings['mobile_slider_dots'] = sanitize_text_field($input['mobile_slider_dots']); }
    if (isset($input['mobile_slider_dots_style'])) { $settings['mobile_slider_dots_style'] = sanitize_text_field($input['mobile_slider_dots_style']); }
    if (isset($input['mobile_dots_border_color'])) { $settings['mobile_dots_border_color'] = sanitize_text_field($input['mobile_dots_border_color']); }
    if (isset($input['mobile_dots_bg_color'])) { $settings['mobile_dots_bg_color'] = sanitize_text_field($input['mobile_dots_bg_color']); }
    if (isset($input['mobile_dots_active_border_color'])) { $settings['mobile_dots_active_border_color'] = sanitize_text_field($input['mobile_dots_active_border_color']); }
    if (isset($input['mobile_dots_active_bg_color'])) { $settings['mobile_dots_active_bg_color'] = sanitize_text_field($input['mobile_dots_active_bg_color']); }
    if (isset($input['mobile_dots_top_padding'])) { $settings['mobile_dots_top_padding'] = $input['mobile_dots_top_padding']; }
    if (isset($input['mobile_hover_show_dots'])) { $settings['mobile_hover_show_dots'] = sanitize_text_field($input['mobile_hover_show_dots']); }
    if (isset($input['mobile_slider_arrows'])) { $settings['mobile_slider_arrows'] = sanitize_text_field($input['mobile_slider_arrows']); }
    if (isset($input['mobile_slider_arrows_style'])) { $settings['mobile_slider_arrows_style'] = sanitize_text_field($input['mobile_slider_arrows_style']); }
    if (isset($input['mobile_arrows_position'])) { $settings['mobile_arrows_position'] = sanitize_text_field($input['mobile_arrows_position']); }
    if (isset($input['mobile_arrow_bg_color'])) { $settings['mobile_arrow_bg_color'] = sanitize_text_field($input['mobile_arrow_bg_color']); }
    if (isset($input['mobile_arrow_icon_color'])) { $settings['mobile_arrow_icon_color'] = sanitize_text_field($input['mobile_arrow_icon_color']); }
    if (isset($input['mobile_arrow_hover_bg_color'])) { $settings['mobile_arrow_hover_bg_color'] = sanitize_text_field($input['mobile_arrow_hover_bg_color']); }
    if (isset($input['mobile_arrow_hover_icon_color'])) { $settings['mobile_arrow_hover_icon_color'] = sanitize_text_field($input['mobile_arrow_hover_icon_color']); }
    if (isset($input['mobile_outer_section_arrow'])) { $settings['mobile_outer_section_arrow'] = sanitize_text_field($input['mobile_outer_section_arrow']); }
    if (isset($input['mobile_hover_show_arrow'])) { $settings['mobile_hover_show_arrow'] = sanitize_text_field($input['mobile_hover_show_arrow']); }
    if (isset($input['mobile_slider_rows'])) { $settings['mobile_slider_rows'] = sanitize_text_field($input['mobile_slider_rows']); }
    if (isset($input['mobile_center_mode'])) { $settings['mobile_center_mode'] = sanitize_text_field($input['mobile_center_mode']); }
    if (isset($input['mobile_center_padding'])) { $settings['mobile_center_padding'] = $input['mobile_center_padding']; }
    if (isset($input['pnf_padding'])) { $settings['pnf_padding'] = $input['pnf_padding']; }
    if (isset($input['pnf_color'])) { $settings['pnf_color'] = sanitize_text_field($input['pnf_color']); }
    if (isset($input['pnf_br'])) { $settings['pnf_br'] = $input['pnf_br']; }
    if (isset($input['messy_column'])) { $settings['messy_column'] = sanitize_text_field($input['messy_column']); }
    if (isset($input['desktop_column_1'])) { $settings['desktop_column_1'] = $input['desktop_column_1']; }
    if (isset($input['desktop_column_2'])) { $settings['desktop_column_2'] = $input['desktop_column_2']; }
    if (isset($input['desktop_column_3'])) { $settings['desktop_column_3'] = $input['desktop_column_3']; }
    if (isset($input['desktop_column_4'])) { $settings['desktop_column_4'] = $input['desktop_column_4']; }
    if (isset($input['desktop_column_5'])) { $settings['desktop_column_5'] = $input['desktop_column_5']; }
    if (isset($input['desktop_column_6'])) { $settings['desktop_column_6'] = $input['desktop_column_6']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
