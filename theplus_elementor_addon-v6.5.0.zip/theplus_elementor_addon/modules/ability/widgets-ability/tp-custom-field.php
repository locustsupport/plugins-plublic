<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-custom-field', [
'label' => __('Custom Field', 'theplus'),
    'description' => __('Adds The Plus "Custom Field" widget (tp-custom-field) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'          => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'        => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'         => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'custom-field-key' => ['type' => 'string', 'description' => 'custom-field-key'],
        'cfkey_type' => ['type' => 'string', 'description' => 'cfkey_type', 'enum' => ['audio', 'date', 'html', 'link', 'oembed', 'text']],
        'key_link_type' => ['type' => 'string', 'description' => 'key_link_type', 'enum' => ['cfkey_type', 'email', 'tel']],
        'field_acf_key' => ['type' => 'string', 'description' => 'field_acf_key', 'enum' => ['yes', 'no']],
        'field_date_format' => ['type' => 'string', 'description' => 'field_date_format', 'enum' => ['cfkey_type', 'field_acf_key']],
        'date_custom_format' => ['type' => 'string', 'description' => 'date_custom_format'],
        'field_link_type' => ['type' => 'string', 'description' => 'field_link_type', 'enum' => ['cfkey_type', 'custom_field', 'post', 'static']],
        'field_link_text' => ['type' => 'string', 'description' => 'field_link_text'],
        'field_link_dynamic_text' => ['type' => 'string', 'description' => 'field_link_dynamic_text'],
        'field_link_target' => ['type' => 'string', 'description' => 'field_link_target', 'enum' => ['yes', 'no']],
        'field_link_download' => ['type' => 'string', 'description' => 'field_link_download', 'enum' => ['yes', 'no']],
        'field_label' => ['type' => 'string', 'description' => 'field_label'],
        'header_tag' => ['type' => 'string', 'description' => 'header_tag', 'enum' => ['cfkey_type', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'span']],
        'field_align' => ['type' => 'object', 'description' => 'field_align', 'enum' => ['center', 'cfkey_type!', 'icon', 'justify', 'left', 'right', '{{WRAPPER}}']],
        'field_links_to_image' => ['type' => 'string', 'description' => 'field_links_to_image', 'enum' => ['cfkey_type', 'custom_field', 'lightbox', 'media', 'post', 'static']],
        'field_link_image' => ['type' => 'string', 'description' => 'field_link_image'],
        'field_link_dynamic_image' => ['type' => 'string', 'description' => 'field_link_dynamic_image'],
        'field_video_type' => ['type' => 'string', 'description' => 'field_video_type', 'enum' => ['cfkey_type']],
        'aspect_ratio' => ['type' => 'string', 'description' => 'aspect_ratio', 'enum' => ['32', '43', '169', 'cfkey_type', 'frontend_available']],
        'field_yt_autoplay' => ['type' => 'string', 'description' => 'field_yt_autoplay', 'enum' => ['yes', 'no']],
        'field_yt_controls' => ['type' => 'string', 'description' => 'field_yt_controls', 'enum' => ['yes', 'no']],
        'field_yt_rel' => ['type' => 'string', 'description' => 'field_yt_rel', 'enum' => ['yes', 'no']],
        'field_yt_showinfo' => ['type' => 'string', 'description' => 'field_yt_showinfo', 'enum' => ['yes', 'no']],
        'field_vimeo_bg' => ['type' => 'string', 'description' => 'field_vimeo_bg', 'enum' => ['yes', 'no']],
        'field_vimeo_autoplay' => ['type' => 'string', 'description' => 'field_vimeo_autoplay', 'enum' => ['yes', 'no']],
        'field_vimeo_title' => ['type' => 'string', 'description' => 'field_vimeo_title', 'enum' => ['yes', 'no']],
        'field_vimeo_loop' => ['type' => 'string', 'description' => 'field_vimeo_loop', 'enum' => ['yes', 'no']],
        'field_vimeo_portrait' => ['type' => 'string', 'description' => 'field_vimeo_portrait', 'enum' => ['yes', 'no']],
        'field_vimeo_byline' => ['type' => 'string', 'description' => 'field_vimeo_byline', 'enum' => ['yes', 'no']],
        'field_vimeo_color' => ['type' => 'string', 'description' => 'field_vimeo_color (Color Hex/RGBA)'],
        'field_vimeo_muted' => ['type' => 'string', 'description' => 'field_vimeo_muted', 'enum' => ['yes', 'no']],
        'display_txt_limit' => ['type' => 'string', 'description' => 'Text Limit', 'enum' => ['yes', 'no']],
        'display_text_by' => ['type' => 'string', 'description' => 'Limit on', 'enum' => ['char', 'display_txt_limit', 'word']],
        'display_txt_input' => ['type' => 'string', 'description' => 'Text Count'],
        'field_color' => ['type' => 'string', 'description' => 'Normal Color (Color Hex/RGBA)'],
        'field_h_color' => ['type' => 'string', 'description' => 'Hover Color (Color Hex/RGBA)'],
        'cf_label_heading' => ['type' => 'string', 'description' => 'Label Styling'],
        'cf_label_offset' => ['type' => 'object', 'description' => 'Right Space (Slider/Size Object)'],
        'cf_label_color' => ['type' => 'string', 'description' => 'Label Color (Color Hex/RGBA)'],
        'cf_img_size' => ['type' => 'object', 'description' => 'Image Size (Slider/Size Object)'],
        'cf_img_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'cf_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'cf_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings.']
    ], 'required' => ['post_id', 'parent_id', 'custom_field_key'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_custom_field_ability',
    'permission_callback' => 'tpaep_mcp_theplus_custom_field_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_custom_field_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_custom_field_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-custom-field';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Custom Field widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['custom-field-key'])) { $settings['custom-field-key'] = sanitize_text_field($input['custom-field-key']); }
    if (isset($input['cfkey_type'])) { $settings['cfkey_type'] = sanitize_text_field($input['cfkey_type']); }
    if (isset($input['key_link_type'])) { $settings['key_link_type'] = sanitize_text_field($input['key_link_type']); }
    if (isset($input['field_acf_key'])) { $settings['field_acf_key'] = sanitize_text_field($input['field_acf_key']); }
    if (isset($input['field_date_format'])) { $settings['field_date_format'] = sanitize_text_field($input['field_date_format']); }
    if (isset($input['date_custom_format'])) { $settings['date_custom_format'] = sanitize_text_field($input['date_custom_format']); }
    if (isset($input['field_link_type'])) { $settings['field_link_type'] = sanitize_text_field($input['field_link_type']); }
    if (isset($input['field_link_text'])) { $settings['field_link_text'] = sanitize_text_field($input['field_link_text']); }
    if (isset($input['field_link_dynamic_text'])) { $settings['field_link_dynamic_text'] = sanitize_text_field($input['field_link_dynamic_text']); }
    if (isset($input['field_link_target'])) { $settings['field_link_target'] = sanitize_text_field($input['field_link_target']); }
    if (isset($input['field_link_download'])) { $settings['field_link_download'] = sanitize_text_field($input['field_link_download']); }
    if (isset($input['field_label'])) { $settings['field_label'] = sanitize_text_field($input['field_label']); }
    if (isset($input['header_tag'])) { $settings['header_tag'] = sanitize_text_field($input['header_tag']); }
    if (isset($input['field_align'])) { $settings['field_align'] = $input['field_align']; }
    if (isset($input['field_links_to_image'])) { $settings['field_links_to_image'] = sanitize_text_field($input['field_links_to_image']); }
    if (isset($input['field_link_image'])) { $settings['field_link_image'] = sanitize_text_field($input['field_link_image']); }
    if (isset($input['field_link_dynamic_image'])) { $settings['field_link_dynamic_image'] = sanitize_text_field($input['field_link_dynamic_image']); }
    if (isset($input['field_video_type'])) { $settings['field_video_type'] = sanitize_text_field($input['field_video_type']); }
    if (isset($input['aspect_ratio'])) { $settings['aspect_ratio'] = sanitize_text_field($input['aspect_ratio']); }
    if (isset($input['field_yt_autoplay'])) { $settings['field_yt_autoplay'] = sanitize_text_field($input['field_yt_autoplay']); }
    if (isset($input['field_yt_controls'])) { $settings['field_yt_controls'] = sanitize_text_field($input['field_yt_controls']); }
    if (isset($input['field_yt_rel'])) { $settings['field_yt_rel'] = sanitize_text_field($input['field_yt_rel']); }
    if (isset($input['field_yt_showinfo'])) { $settings['field_yt_showinfo'] = sanitize_text_field($input['field_yt_showinfo']); }
    if (isset($input['field_vimeo_bg'])) { $settings['field_vimeo_bg'] = sanitize_text_field($input['field_vimeo_bg']); }
    if (isset($input['field_vimeo_autoplay'])) { $settings['field_vimeo_autoplay'] = sanitize_text_field($input['field_vimeo_autoplay']); }
    if (isset($input['field_vimeo_title'])) { $settings['field_vimeo_title'] = sanitize_text_field($input['field_vimeo_title']); }
    if (isset($input['field_vimeo_loop'])) { $settings['field_vimeo_loop'] = sanitize_text_field($input['field_vimeo_loop']); }
    if (isset($input['field_vimeo_portrait'])) { $settings['field_vimeo_portrait'] = sanitize_text_field($input['field_vimeo_portrait']); }
    if (isset($input['field_vimeo_byline'])) { $settings['field_vimeo_byline'] = sanitize_text_field($input['field_vimeo_byline']); }
    if (isset($input['field_vimeo_color'])) { $settings['field_vimeo_color'] = sanitize_text_field($input['field_vimeo_color']); }
    if (isset($input['field_vimeo_muted'])) { $settings['field_vimeo_muted'] = sanitize_text_field($input['field_vimeo_muted']); }
    if (isset($input['display_txt_limit'])) { $settings['display_txt_limit'] = sanitize_text_field($input['display_txt_limit']); }
    if (isset($input['display_text_by'])) { $settings['display_text_by'] = sanitize_text_field($input['display_text_by']); }
    if (isset($input['display_txt_input'])) { $settings['display_txt_input'] = sanitize_text_field($input['display_txt_input']); }
    if (isset($input['field_color'])) { $settings['field_color'] = sanitize_text_field($input['field_color']); }
    if (isset($input['field_h_color'])) { $settings['field_h_color'] = sanitize_text_field($input['field_h_color']); }
    if (isset($input['cf_label_heading'])) { $settings['cf_label_heading'] = sanitize_text_field($input['cf_label_heading']); }
    if (isset($input['cf_label_offset'])) { $settings['cf_label_offset'] = $input['cf_label_offset']; }
    if (isset($input['cf_label_color'])) { $settings['cf_label_color'] = sanitize_text_field($input['cf_label_color']); }
    if (isset($input['cf_img_size'])) { $settings['cf_img_size'] = $input['cf_img_size']; }
    if (isset($input['cf_img_br'])) { $settings['cf_img_br'] = $input['cf_img_br']; }
    if (isset($input['cf_padding'])) { $settings['cf_padding'] = $input['cf_padding']; }
    if (isset($input['cf_br'])) { $settings['cf_br'] = $input['cf_br']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
