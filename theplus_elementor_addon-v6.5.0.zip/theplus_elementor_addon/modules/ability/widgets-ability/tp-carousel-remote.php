<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-carousel-remote', [
'label' => __('Carousel Remote', 'theplus'),
    'description' => __('Adds The Plus "Carousel Remote" widget (tp-carousel-remote) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'             => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'           => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'            => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'carousel_unique_id'  => ['type' => 'string',  'description' => 'Unique ID matching the carousel widget to control'],
        'remote_type'         => ['type' => 'string',  'description' => 'Which widget type to control', 'enum' => ['carousel', 'switcher', 'horizontal']],
        'nxtprvbtn'           => ['type' => 'string',  'description' => 'Show next/prev navigation buttons', 'enum' => ['yes', 'no']],
        'nav_next_slide'      => ['type' => 'string',  'description' => 'Next button label'],
        'nav_prev_slide'      => ['type' => 'string',  'description' => 'Prev button label'],
        'settings'            => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Use tpae/tpae-widget-schema to discover keys.'],
    ], 'required' => ['post_id', 'parent_id', 'carousel_unique_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_carousel_remote_ability',
    'permission_callback' => 'tpaep_mcp_theplus_carousel_remote_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_carousel_remote_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_carousel_remote_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-carousel-remote';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Carousel Remote widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (!empty($input['carousel_unique_id'])) { $settings['carousel_unique_id'] = sanitize_text_field($input['carousel_unique_id']); }
    if (!empty($input['remote_type']))        { $settings['remote_type']        = sanitize_key($input['remote_type']); }
    if (!empty($input['nxtprvbtn']))          { $settings['nxtprvbtn']          = sanitize_key($input['nxtprvbtn']); }
    if (!empty($input['nav_next_slide']))     { $settings['nav_next_slide']     = sanitize_text_field($input['nav_next_slide']); }
    if (!empty($input['nav_prev_slide']))     { $settings['nav_prev_slide']     = sanitize_text_field($input['nav_prev_slide']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
