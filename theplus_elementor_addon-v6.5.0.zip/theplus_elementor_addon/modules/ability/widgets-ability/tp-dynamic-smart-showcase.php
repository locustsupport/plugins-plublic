<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-dynamic-smart-showcase', [
'label' => __('Dynamic Smart Showcase', 'theplus'),
    'description' => __('Adds The Plus "Dynamic Smart Showcase" widget (tp-dynamic-smart-showcase) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'       => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'     => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'      => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['magazine', 'news', 'none']],
        'magazine_style' => ['type' => 'string', 'description' => 'Magazine Layout', 'enum' => ['columns', 'mag_four_x_rows_1', 'mag_one_1_2_h', 'mag_one_1_2_v', 'mag_one_2_2', 'mag_rows_2', 'mag_two_1_2', 'mag_two_3_v', 'mag_two_4', 'style']],
        'news_highlight_style' => ['type' => 'string', 'description' => 'Highlight', 'enum' => ['hl_left', 'hl_right', 'hl_top', 'style']],
        'news_style' => ['type' => 'string', 'description' => 'News Layout', 'enum' => ['columns', 'news_style_1', 'news_style_2', 'style']],
        'left_side_filter_text' => ['type' => 'string', 'description' => 'Heading'],
        'layout' => ['type' => 'string', 'description' => 'Layout', 'enum' => ['carousel', 'style']],
        'query' => ['type' => 'string', 'description' => 'Post Type'],
        'mag_st_6_8_min_height' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'post_category' => ['type' => 'string', 'description' => 'Select Category', 'enum' => ['multiple', 'query']],
        'post_taxonomies' => ['type' => 'string', 'description' => 'Taxonomies', 'enum' => ['query!']],
        'include_slug' => ['type' => 'string', 'description' => 'Taxonomies Slug'],
        'include_posts' => ['type' => 'string', 'description' => 'Include Post(s)'],
        'exclude_posts' => ['type' => 'string', 'description' => 'Exclude Post(s)'],
        'post_tags' => ['type' => 'string', 'description' => 'Select Tags', 'enum' => ['multiple']],
        'display_posts' => ['type' => 'string', 'description' => 'Maximum Posts Display'],
        'news_loop_page' => ['type' => 'string', 'description' => 'News Post Loop'],
        'post_offset' => ['type' => 'string', 'description' => 'Offset Posts'],
        'post_order_by' => ['type' => 'string', 'description' => 'Order By'],
        'post_order' => ['type' => 'string', 'description' => 'Order'],
        'desktop_column' => ['type' => 'string', 'description' => 'Desktop Column', 'enum' => ['layout!']],
        'tablet_column' => ['type' => 'string', 'description' => 'Tablet Column', 'enum' => ['layout!']],
        'mobile_column' => ['type' => 'string', 'description' => 'Mobile Column', 'enum' => ['layout!']],
        'columns_gap' => ['type' => 'object', 'description' => 'Columns Gap/Space Between (Dimensions Object)'],
        'show_tricker' => ['type' => 'string', 'description' => 'Post Ticker', 'enum' => ['yes', 'no']],
        'show_label' => ['type' => 'string', 'description' => 'Label', 'enum' => ['yes', 'no']],
        'news_label' => ['type' => 'string', 'description' => 'Label'],
        'tricker_icon_fontawesome' => ['type' => 'string', 'description' => 'Label Icon'],
        'button_link' => ['type' => 'object', 'description' => 'Label Link'],
        'show_date' => ['type' => 'string', 'description' => 'Date', 'enum' => ['yes', 'no']],
        'show_author_name' => ['type' => 'string', 'description' => 'Author Name', 'enum' => ['yes', 'no']],
        'show_author_img' => ['type' => 'string', 'description' => 'Author Image', 'enum' => ['yes', 'no']],
        'label_res_tab' => ['type' => 'string', 'description' => 'Label Disable in Tablet', 'enum' => ['yes', 'no']],
        'label_res_mob' => ['type' => 'string', 'description' => 'Label Disable in Mobile', 'enum' => ['yes', 'no']],
        'date_res_tab' => ['type' => 'string', 'description' => 'Date Disable in Tablet', 'enum' => ['yes', 'no']],
        'date_res_mob' => ['type' => 'string', 'description' => 'Date Disable in Mobile', 'enum' => ['yes', 'no']],
        'an_res_tab' => ['type' => 'string', 'description' => 'Author Name Disable in Tablet', 'enum' => ['yes', 'no']],
        'an_res_mob' => ['type' => 'string', 'description' => 'Author Name Disable in Mobile', 'enum' => ['yes', 'no']],
        'ai_res_tab' => ['type' => 'string', 'description' => 'Author Image Disable in Tablet', 'enum' => ['yes', 'no']],
        'ai_res_mob' => ['type' => 'string', 'description' => 'Author Image Disable in Mobile', 'enum' => ['yes', 'no']],
        'filter_category' => ['type' => 'string', 'description' => 'Category Wise Filter', 'enum' => ['yes', 'no']],
        'all_filter_category' => ['type' => 'string', 'description' => 'All Filter Category Text'],
        'filter_category_nxt_prv' => ['type' => 'string', 'description' => 'Only Show Next Previous', 'enum' => ['yes', 'no']],
        'filter_style' => ['type' => 'string', 'description' => 'Category Filter Style', 'enum' => ['filter_category']],
        'filter_hover_style' => ['type' => 'string', 'description' => 'Filter Hover Style', 'enum' => ['filter_category']],
        'filter_category_align' => ['type' => 'string', 'description' => 'Filter Alignment', 'enum' => ['center', 'filter_category', 'icon', 'left', 'right', 'toggle']],
        'post_title_tag' => ['type' => 'string', 'description' => 'Title Tag', 'enum' => ['style!']],
        'display_post_category' => ['type' => 'string', 'description' => 'Display Category Post', 'enum' => ['yes', 'no']],
        'post_category_style' => ['type' => 'string', 'description' => 'Post Category Style', 'enum' => ['display_post_category', 'style!']],
        'post_title_count' => ['type' => 'string', 'description' => 'Title Word Limit'],
        'tricker_autoplay' => ['type' => 'string', 'description' => 'Ticker Autoplay', 'enum' => ['yes', 'no']],
        'tricker_speed' => ['type' => 'object', 'description' => 'Ticker Speed (Slider/Size Object)'],
        'title_desc_word_break' => ['type' => 'string', 'description' => 'Title & Description Word Break', 'enum' => ['break-all', 'keep-all', 'normal', 'style!']],
        'display_excerpt' => ['type' => 'string', 'description' => 'Display Excerpt/Content', 'enum' => ['yes', 'no']],
        'post_excerpt_count' => ['type' => 'string', 'description' => 'Excerpt/Content Word Limit'],
        'display_thumbnail' => ['type' => 'string', 'description' => 'Display Image Size', 'enum' => ['yes', 'no']],
        'display_post_meta' => ['type' => 'string', 'description' => 'Display Post Meta', 'enum' => ['yes', 'no']],
        'post_meta_tag_style' => ['type' => 'string', 'description' => 'Post Meta Tag', 'enum' => ['display_post_meta', 'style!']],
        'title_color_high' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'title_hover_color_high' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'title_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'title_hover_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'excerpt_color' => ['type' => 'string', 'description' => 'Content Color (Color Hex/RGBA)'],
        'excerpt_hover_color' => ['type' => 'string', 'description' => 'Content Color (Color Hex/RGBA)'],
        'high_icon' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'post_meta_color_high' => ['type' => 'string', 'description' => 'Post Meta Color (Color Hex/RGBA)'],
        'post_meta_color_hover_high' => ['type' => 'string', 'description' => 'Post Meta Color (Color Hex/RGBA)'],
        'post_meta_color' => ['type' => 'string', 'description' => 'Post Meta Color (Color Hex/RGBA)'],
        'post_meta_color_hover' => ['type' => 'string', 'description' => 'Post Meta Color (Color Hex/RGBA)'],
        'category_inner_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'post_category_bottom_space' => ['type' => 'object', 'description' => 'Bottom Offset (Slider/Size Object)'],
        'category_color' => ['type' => 'string', 'description' => 'Category Color (Color Hex/RGBA)'],
        'category_hover_color' => ['type' => 'string', 'description' => 'Category Color (Color Hex/RGBA)'],
        'category_2_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'category_border' => ['type' => 'string', 'description' => 'Category Border', 'enum' => ['yes', 'no']],
        'category_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['category_border', 'display_post_category', '{{WRAPPER}} .bss-list .post-category-list span a']],
        'box_category_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'category_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'category_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'category_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'category_border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'news_heading_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'news_heading_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'sep_border_color' => ['type' => 'string', 'description' => 'Seprate Border Color', 'enum' => ['yes', 'no']],
        'news_heading_border_top' => ['type' => 'string', 'description' => 'Top Border Color (Color Hex/RGBA)'],
        'news_heading_border_bottom' => ['type' => 'string', 'description' => 'Bottom Border Color (Color Hex/RGBA)'],
        'news_heading_border_right' => ['type' => 'string', 'description' => 'Right Border Color (Color Hex/RGBA)'],
        'news_heading_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'news_heading_color_h' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'news_heading_border_top_h' => ['type' => 'string', 'description' => 'Top Border Color (Color Hex/RGBA)'],
        'news_heading_border_bottom_h' => ['type' => 'string', 'description' => 'Bottom Border Color (Color Hex/RGBA)'],
        'news_heading_border_right_h' => ['type' => 'string', 'description' => 'Right Border Color (Color Hex/RGBA)'],
        'news_heading_radius_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'filter_category_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'filter_category_marign' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'nxt_prev_icon_nxt_size' => ['type' => 'object', 'description' => 'Next Icon Size (Slider/Size Object)'],
        'nxt_prev_icon_nxt_color' => ['type' => 'string', 'description' => 'Next Icon Color (Color Hex/RGBA)'],
        'nxt_prev_icon_prev_size' => ['type' => 'object', 'description' => 'Previous Icon Size (Slider/Size Object)'],
        'nxt_prev_icon_prev_color' => ['type' => 'string', 'description' => 'Previous Icon Color (Color Hex/RGBA)'],
        'filters_text_color' => ['type' => 'string', 'description' => 'Filters Text Color (Color Hex/RGBA)'],
        'filter_category_color' => ['type' => 'string', 'description' => 'Category Filter Color (Color Hex/RGBA)'],
        'filter_category_4_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'filter_category_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'filter_category_hover_color' => ['type' => 'string', 'description' => 'Category Filter Color (Color Hex/RGBA)'],
        'filter_category_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'filter_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'category_count_color' => ['type' => 'string', 'description' => 'Category Count Color (Color Hex/RGBA)'],
        'category_count_bg_color' => ['type' => 'string', 'description' => 'Count Background Color (Color Hex/RGBA)'],
        'news_filter_opt_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'news_filter_opt_radius_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'news_news_loop_content_inner_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'news_loop_content_top_offset' => ['type' => 'object', 'description' => 'Bottom Offset (Slider/Size Object)'],
        'bss_hl_post_padding' => ['type' => 'object', 'description' => 'Inner Padding (Dimensions Object)'],
        'bss_hl_post_padding_outer' => ['type' => 'object', 'description' => 'Outer Padding (Dimensions Object)'],
        'hl_image_height' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'hl_overlay_color_normal' => ['type' => 'string', 'description' => 'Normal Overlay Color (Color Hex/RGBA)'],
        'hl_overlay_color_hover' => ['type' => 'string', 'description' => 'Hover Overlay Color (Color Hex/RGBA)'],
        'hl_img_position' => ['type' => 'string', 'description' => 'Image Position', 'enum' => ['news_style', 'style', '{{WRAPPER}} .bss-list.bss-news .post-inner-loop > .grid-item.active.show.bssfc .post-content-image-bg']],
        'hl_img_size' => ['type' => 'string', 'description' => 'Image Size', 'enum' => ['news_style', 'style', '{{WRAPPER}} .bss-list.bss-news .post-inner-loop > .grid-item.active.show.bssfc .post-content-image-bg']],
        'hl_image_height_st2' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'bss_hl_post_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'normal_content_alignment' => ['type' => 'string', 'description' => 'Normal Content Alignment', 'enum' => ['center', 'flex-end', 'flex-start', 'icon', 'style', 'toggle', '{{WRAPPER}} .bss-list.bss-news .post-inner-loop > .grid-item:not(.bssfc) .bss-content']],
        'n_c_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'n_s_normal_section_box_padding' => ['type' => 'object', 'description' => 'Box Inner Padding (Dimensions Object)'],
        'n_s_normal_section_bootom_space' => ['type' => 'object', 'description' => 'Bottom Space (Slider/Size Object)'],
        'bss_normal_post_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'feature_img_max_width' => ['type' => 'object', 'description' => 'Max Width (Slider/Size Object)'],
        'feature_img_overflow' => ['type' => 'string', 'description' => 'Feature Image Overflow', 'enum' => ['hidden', 'style', 'visible', '{{WRAPPER}} .bss-list.bss-news .grid-item:not(.bssfc)']],
        'feature_img_max_height' => ['type' => 'object', 'description' => 'Max Height (Slider/Size Object)'],
        'n_s_feature_img_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'ticker_label_color' => ['type' => 'string', 'description' => 'Label Color (Color Hex/RGBA)'],
        'ticker_label_bg_color' => ['type' => 'string', 'description' => 'Label Background (Color Hex/RGBA)'],
        'label_icon_right_offset' => ['type' => 'object', 'description' => 'Icon Right Offset (Slider/Size Object)'],
        'label_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'label_icon_color_n' => ['type' => 'string', 'description' => 'Icon Normal Color (Color Hex/RGBA)'],
        'label_icon_color_h' => ['type' => 'string', 'description' => 'Icon Hover Color (Color Hex/RGBA)'],
        'ticker_content_color' => ['type' => 'string', 'description' => 'Content Color (Color Hex/RGBA)'],
        'ticker_content_bg_color' => ['type' => 'string', 'description' => 'Content Background (Color Hex/RGBA)'],
        'ticker_content_date_color' => ['type' => 'string', 'description' => 'Date Color (Color Hex/RGBA)'],
        'ticker_navigation_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'ticker_navigation_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'ticker_navigation_color_h' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'ticker_author_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'ticker_author_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'ticker_author_icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'ticker_author_border_radius' => ['type' => 'object', 'description' => 'Author Image Border Radius (Dimensions Object)'],
        'ticker_whole_border_r' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'content_outer_padding' => ['type' => 'object', 'description' => 'Outer Padding (Dimensions Object)'],
        'content_inner_padding' => ['type' => 'object', 'description' => 'Inner Padding (Dimensions Object)'],
        'box_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['box_border', '{{WRAPPER}} .bss-list.bss-magazine .bss-inner-extra .bss-wrap']],
        'box_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'box_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'box_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'loop_bg_overlay_color' => ['type' => 'string', 'description' => 'Overlay Color (Color Hex/RGBA)'],
        'loop_bg_overlay_h_color' => ['type' => 'string', 'description' => 'Overlay Color (Color Hex/RGBA)'],
        'carousel_unique_id' => ['type' => 'string', 'description' => 'Unique Carousel ID'],
        'slider_direction' => ['type' => 'string', 'description' => 'Slider Mode', 'enum' => ['horizontal', 'vertical']],
        'carousel_direction' => ['type' => 'string', 'description' => 'Slide Direction', 'enum' => ['ltr', 'rtl']],
        'slide_speed' => ['type' => 'object', 'description' => 'Slide Speed (Slider/Size Object)'],
        'slider_desktop_column' => ['type' => 'string', 'description' => 'Desktop Columns', 'enum' => ['1']],
        'steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_padding' => ['type' => 'object', 'description' => 'Slide Padding (Dimensions Object)'],
        'slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'slider_pause_hover' => ['type' => 'string', 'description' => 'Pause On Hover', 'enum' => ['yes', 'no']],
        'slider_adaptive_height' => ['type' => 'string', 'description' => 'Adaptive Height', 'enum' => ['yes', 'no']],
        'slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['slider_dots', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['slider_arrows', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'slider_arrows', 'slider_arrows_style', 'top-right']],
        'arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'slider_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'slider_center_effects' => ['type' => 'string', 'description' => 'Center Slide Effects', 'enum' => ['slider_center_mode']],
        'scale_center_slide' => ['type' => 'object', 'description' => 'Center Slide Scale (Slider/Size Object)'],
        'scale_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Scale (Slider/Size Object)'],
        'opacity_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Opacity (Slider/Size Object)'],
        'slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3']],
        'slide_row_top_space' => ['type' => 'object', 'description' => 'Row Top Space (Slider/Size Object)'],
        'slider_tablet_column' => ['type' => 'string', 'description' => 'Tablet Columns', 'enum' => ['1']],
        'tablet_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_tablet' => ['type' => 'string', 'description' => 'Responsive Tablet', 'enum' => ['yes', 'no']],
        'tablet_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'tablet_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'tablet_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'tablet_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'tablet_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['slider_responsive_tablet', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7', 'tablet_slider_dots']],
        'tablet_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'tablet_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'tablet_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'tablet_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'tablet_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'tablet_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['slider_responsive_tablet', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'tablet_slider_arrows']],
        'tablet_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'slider_responsive_tablet', 'tablet_slider_arrows', 'tablet_slider_arrows_style', 'top-right']],
        'tablet_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'tablet_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'tablet_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'tablet_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'tablet_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'tablet_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'tablet_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3', 'slider_responsive_tablet']],
        'tablet_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'tablet_center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'slider_mobile_column' => ['type' => 'string', 'description' => 'Mobile Columns', 'enum' => ['1']],
        'mobile_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_mobile' => ['type' => 'string', 'description' => 'Responsive Mobile', 'enum' => ['yes', 'no']],
        'mobile_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'mobile_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'mobile_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'mobile_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'mobile_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['mobile_slider_dots', 'slider_responsive_mobile', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'mobile_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'mobile_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'mobile_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'mobile_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'mobile_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'mobile_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['mobile_slider_arrows', 'slider_responsive_mobile', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'mobile_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'mobile_slider_arrows', 'mobile_slider_arrows_style', 'slider_responsive_mobile', 'top-right']],
        'mobile_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'mobile_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'mobile_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'mobile_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'mobile_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'mobile_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'mobile_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3', 'slider_responsive_mobile']],
        'mobile_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'mobile_center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'pnf_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'pnf_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'pnf_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_dynamic_smart_showcase_ability',
    'permission_callback' => 'tpaep_mcp_theplus_dynamic_smart_showcase_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_dynamic_smart_showcase_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_dynamic_smart_showcase_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-dynamic-smart-showcase';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Dynamic Smart Showcase widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['style'])) { $settings['style'] = sanitize_text_field($input['style']); }
    if (isset($input['magazine_style'])) { $settings['magazine_style'] = sanitize_text_field($input['magazine_style']); }
    if (isset($input['news_highlight_style'])) { $settings['news_highlight_style'] = sanitize_text_field($input['news_highlight_style']); }
    if (isset($input['news_style'])) { $settings['news_style'] = sanitize_text_field($input['news_style']); }
    if (isset($input['left_side_filter_text'])) { $settings['left_side_filter_text'] = sanitize_text_field($input['left_side_filter_text']); }
    if (isset($input['layout'])) { $settings['layout'] = sanitize_text_field($input['layout']); }
    if (isset($input['query'])) { $settings['query'] = sanitize_text_field($input['query']); }
    if (isset($input['mag_st_6_8_min_height'])) { $settings['mag_st_6_8_min_height'] = $input['mag_st_6_8_min_height']; }
    if (isset($input['post_category'])) { $settings['post_category'] = sanitize_text_field($input['post_category']); }
    if (isset($input['post_taxonomies'])) { $settings['post_taxonomies'] = sanitize_text_field($input['post_taxonomies']); }
    if (isset($input['include_slug'])) { $settings['include_slug'] = sanitize_text_field($input['include_slug']); }
    if (isset($input['include_posts'])) { $settings['include_posts'] = sanitize_text_field($input['include_posts']); }
    if (isset($input['exclude_posts'])) { $settings['exclude_posts'] = sanitize_text_field($input['exclude_posts']); }
    if (isset($input['post_tags'])) { $settings['post_tags'] = sanitize_text_field($input['post_tags']); }
    if (isset($input['display_posts'])) { $settings['display_posts'] = sanitize_text_field($input['display_posts']); }
    if (isset($input['news_loop_page'])) { $settings['news_loop_page'] = sanitize_text_field($input['news_loop_page']); }
    if (isset($input['post_offset'])) { $settings['post_offset'] = sanitize_text_field($input['post_offset']); }
    if (isset($input['post_order_by'])) { $settings['post_order_by'] = sanitize_text_field($input['post_order_by']); }
    if (isset($input['post_order'])) { $settings['post_order'] = sanitize_text_field($input['post_order']); }
    if (isset($input['desktop_column'])) { $settings['desktop_column'] = sanitize_text_field($input['desktop_column']); }
    if (isset($input['tablet_column'])) { $settings['tablet_column'] = sanitize_text_field($input['tablet_column']); }
    if (isset($input['mobile_column'])) { $settings['mobile_column'] = sanitize_text_field($input['mobile_column']); }
    if (isset($input['columns_gap'])) { $settings['columns_gap'] = $input['columns_gap']; }
    if (isset($input['show_tricker'])) { $settings['show_tricker'] = sanitize_text_field($input['show_tricker']); }
    if (isset($input['show_label'])) { $settings['show_label'] = sanitize_text_field($input['show_label']); }
    if (isset($input['news_label'])) { $settings['news_label'] = sanitize_text_field($input['news_label']); }
    if (isset($input['tricker_icon_fontawesome'])) { $settings['tricker_icon_fontawesome'] = sanitize_text_field($input['tricker_icon_fontawesome']); }
    if (isset($input['button_link'])) { $settings['button_link'] = $input['button_link']; }
    if (isset($input['show_date'])) { $settings['show_date'] = sanitize_text_field($input['show_date']); }
    if (isset($input['show_author_name'])) { $settings['show_author_name'] = sanitize_text_field($input['show_author_name']); }
    if (isset($input['show_author_img'])) { $settings['show_author_img'] = sanitize_text_field($input['show_author_img']); }
    if (isset($input['label_res_tab'])) { $settings['label_res_tab'] = sanitize_text_field($input['label_res_tab']); }
    if (isset($input['label_res_mob'])) { $settings['label_res_mob'] = sanitize_text_field($input['label_res_mob']); }
    if (isset($input['date_res_tab'])) { $settings['date_res_tab'] = sanitize_text_field($input['date_res_tab']); }
    if (isset($input['date_res_mob'])) { $settings['date_res_mob'] = sanitize_text_field($input['date_res_mob']); }
    if (isset($input['an_res_tab'])) { $settings['an_res_tab'] = sanitize_text_field($input['an_res_tab']); }
    if (isset($input['an_res_mob'])) { $settings['an_res_mob'] = sanitize_text_field($input['an_res_mob']); }
    if (isset($input['ai_res_tab'])) { $settings['ai_res_tab'] = sanitize_text_field($input['ai_res_tab']); }
    if (isset($input['ai_res_mob'])) { $settings['ai_res_mob'] = sanitize_text_field($input['ai_res_mob']); }
    if (isset($input['filter_category'])) { $settings['filter_category'] = sanitize_text_field($input['filter_category']); }
    if (isset($input['all_filter_category'])) { $settings['all_filter_category'] = sanitize_text_field($input['all_filter_category']); }
    if (isset($input['filter_category_nxt_prv'])) { $settings['filter_category_nxt_prv'] = sanitize_text_field($input['filter_category_nxt_prv']); }
    if (isset($input['filter_style'])) { $settings['filter_style'] = sanitize_text_field($input['filter_style']); }
    if (isset($input['filter_hover_style'])) { $settings['filter_hover_style'] = sanitize_text_field($input['filter_hover_style']); }
    if (isset($input['filter_category_align'])) { $settings['filter_category_align'] = sanitize_text_field($input['filter_category_align']); }
    if (isset($input['post_title_tag'])) { $settings['post_title_tag'] = sanitize_text_field($input['post_title_tag']); }
    if (isset($input['display_post_category'])) { $settings['display_post_category'] = sanitize_text_field($input['display_post_category']); }
    if (isset($input['post_category_style'])) { $settings['post_category_style'] = sanitize_text_field($input['post_category_style']); }
    if (isset($input['post_title_count'])) { $settings['post_title_count'] = sanitize_text_field($input['post_title_count']); }
    if (isset($input['tricker_autoplay'])) { $settings['tricker_autoplay'] = sanitize_text_field($input['tricker_autoplay']); }
    if (isset($input['tricker_speed'])) { $settings['tricker_speed'] = $input['tricker_speed']; }
    if (isset($input['title_desc_word_break'])) { $settings['title_desc_word_break'] = sanitize_text_field($input['title_desc_word_break']); }
    if (isset($input['display_excerpt'])) { $settings['display_excerpt'] = sanitize_text_field($input['display_excerpt']); }
    if (isset($input['post_excerpt_count'])) { $settings['post_excerpt_count'] = sanitize_text_field($input['post_excerpt_count']); }
    if (isset($input['display_thumbnail'])) { $settings['display_thumbnail'] = sanitize_text_field($input['display_thumbnail']); }
    if (isset($input['display_post_meta'])) { $settings['display_post_meta'] = sanitize_text_field($input['display_post_meta']); }
    if (isset($input['post_meta_tag_style'])) { $settings['post_meta_tag_style'] = sanitize_text_field($input['post_meta_tag_style']); }
    if (isset($input['title_color_high'])) { $settings['title_color_high'] = sanitize_text_field($input['title_color_high']); }
    if (isset($input['title_hover_color_high'])) { $settings['title_hover_color_high'] = sanitize_text_field($input['title_hover_color_high']); }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['title_hover_color'])) { $settings['title_hover_color'] = sanitize_text_field($input['title_hover_color']); }
    if (isset($input['excerpt_color'])) { $settings['excerpt_color'] = sanitize_text_field($input['excerpt_color']); }
    if (isset($input['excerpt_hover_color'])) { $settings['excerpt_hover_color'] = sanitize_text_field($input['excerpt_hover_color']); }
    if (isset($input['high_icon'])) { $settings['high_icon'] = $input['high_icon']; }
    if (isset($input['post_meta_color_high'])) { $settings['post_meta_color_high'] = sanitize_text_field($input['post_meta_color_high']); }
    if (isset($input['post_meta_color_hover_high'])) { $settings['post_meta_color_hover_high'] = sanitize_text_field($input['post_meta_color_hover_high']); }
    if (isset($input['post_meta_color'])) { $settings['post_meta_color'] = sanitize_text_field($input['post_meta_color']); }
    if (isset($input['post_meta_color_hover'])) { $settings['post_meta_color_hover'] = sanitize_text_field($input['post_meta_color_hover']); }
    if (isset($input['category_inner_padding'])) { $settings['category_inner_padding'] = $input['category_inner_padding']; }
    if (isset($input['post_category_bottom_space'])) { $settings['post_category_bottom_space'] = $input['post_category_bottom_space']; }
    if (isset($input['category_color'])) { $settings['category_color'] = sanitize_text_field($input['category_color']); }
    if (isset($input['category_hover_color'])) { $settings['category_hover_color'] = sanitize_text_field($input['category_hover_color']); }
    if (isset($input['category_2_border_hover_color'])) { $settings['category_2_border_hover_color'] = sanitize_text_field($input['category_2_border_hover_color']); }
    if (isset($input['category_border'])) { $settings['category_border'] = sanitize_text_field($input['category_border']); }
    if (isset($input['category_border_style'])) { $settings['category_border_style'] = sanitize_text_field($input['category_border_style']); }
    if (isset($input['box_category_border_width'])) { $settings['box_category_border_width'] = $input['box_category_border_width']; }
    if (isset($input['category_border_color'])) { $settings['category_border_color'] = sanitize_text_field($input['category_border_color']); }
    if (isset($input['category_border_radius'])) { $settings['category_border_radius'] = $input['category_border_radius']; }
    if (isset($input['category_border_hover_color'])) { $settings['category_border_hover_color'] = sanitize_text_field($input['category_border_hover_color']); }
    if (isset($input['category_border_hover_radius'])) { $settings['category_border_hover_radius'] = $input['category_border_hover_radius']; }
    if (isset($input['news_heading_padding'])) { $settings['news_heading_padding'] = $input['news_heading_padding']; }
    if (isset($input['news_heading_color'])) { $settings['news_heading_color'] = sanitize_text_field($input['news_heading_color']); }
    if (isset($input['sep_border_color'])) { $settings['sep_border_color'] = sanitize_text_field($input['sep_border_color']); }
    if (isset($input['news_heading_border_top'])) { $settings['news_heading_border_top'] = sanitize_text_field($input['news_heading_border_top']); }
    if (isset($input['news_heading_border_bottom'])) { $settings['news_heading_border_bottom'] = sanitize_text_field($input['news_heading_border_bottom']); }
    if (isset($input['news_heading_border_right'])) { $settings['news_heading_border_right'] = sanitize_text_field($input['news_heading_border_right']); }
    if (isset($input['news_heading_radius'])) { $settings['news_heading_radius'] = $input['news_heading_radius']; }
    if (isset($input['news_heading_color_h'])) { $settings['news_heading_color_h'] = sanitize_text_field($input['news_heading_color_h']); }
    if (isset($input['news_heading_border_top_h'])) { $settings['news_heading_border_top_h'] = sanitize_text_field($input['news_heading_border_top_h']); }
    if (isset($input['news_heading_border_bottom_h'])) { $settings['news_heading_border_bottom_h'] = sanitize_text_field($input['news_heading_border_bottom_h']); }
    if (isset($input['news_heading_border_right_h'])) { $settings['news_heading_border_right_h'] = sanitize_text_field($input['news_heading_border_right_h']); }
    if (isset($input['news_heading_radius_h'])) { $settings['news_heading_radius_h'] = $input['news_heading_radius_h']; }
    if (isset($input['filter_category_padding'])) { $settings['filter_category_padding'] = $input['filter_category_padding']; }
    if (isset($input['filter_category_marign'])) { $settings['filter_category_marign'] = $input['filter_category_marign']; }
    if (isset($input['nxt_prev_icon_nxt_size'])) { $settings['nxt_prev_icon_nxt_size'] = $input['nxt_prev_icon_nxt_size']; }
    if (isset($input['nxt_prev_icon_nxt_color'])) { $settings['nxt_prev_icon_nxt_color'] = sanitize_text_field($input['nxt_prev_icon_nxt_color']); }
    if (isset($input['nxt_prev_icon_prev_size'])) { $settings['nxt_prev_icon_prev_size'] = $input['nxt_prev_icon_prev_size']; }
    if (isset($input['nxt_prev_icon_prev_color'])) { $settings['nxt_prev_icon_prev_color'] = sanitize_text_field($input['nxt_prev_icon_prev_color']); }
    if (isset($input['filters_text_color'])) { $settings['filters_text_color'] = sanitize_text_field($input['filters_text_color']); }
    if (isset($input['filter_category_color'])) { $settings['filter_category_color'] = sanitize_text_field($input['filter_category_color']); }
    if (isset($input['filter_category_4_border_color'])) { $settings['filter_category_4_border_color'] = sanitize_text_field($input['filter_category_4_border_color']); }
    if (isset($input['filter_category_radius'])) { $settings['filter_category_radius'] = $input['filter_category_radius']; }
    if (isset($input['filter_category_hover_color'])) { $settings['filter_category_hover_color'] = sanitize_text_field($input['filter_category_hover_color']); }
    if (isset($input['filter_category_hover_radius'])) { $settings['filter_category_hover_radius'] = $input['filter_category_hover_radius']; }
    if (isset($input['filter_border_hover_color'])) { $settings['filter_border_hover_color'] = sanitize_text_field($input['filter_border_hover_color']); }
    if (isset($input['category_count_color'])) { $settings['category_count_color'] = sanitize_text_field($input['category_count_color']); }
    if (isset($input['category_count_bg_color'])) { $settings['category_count_bg_color'] = sanitize_text_field($input['category_count_bg_color']); }
    if (isset($input['news_filter_opt_radius'])) { $settings['news_filter_opt_radius'] = $input['news_filter_opt_radius']; }
    if (isset($input['news_filter_opt_radius_h'])) { $settings['news_filter_opt_radius_h'] = $input['news_filter_opt_radius_h']; }
    if (isset($input['news_news_loop_content_inner_padding'])) { $settings['news_news_loop_content_inner_padding'] = $input['news_news_loop_content_inner_padding']; }
    if (isset($input['news_loop_content_top_offset'])) { $settings['news_loop_content_top_offset'] = $input['news_loop_content_top_offset']; }
    if (isset($input['bss_hl_post_padding'])) { $settings['bss_hl_post_padding'] = $input['bss_hl_post_padding']; }
    if (isset($input['bss_hl_post_padding_outer'])) { $settings['bss_hl_post_padding_outer'] = $input['bss_hl_post_padding_outer']; }
    if (isset($input['hl_image_height'])) { $settings['hl_image_height'] = $input['hl_image_height']; }
    if (isset($input['hl_overlay_color_normal'])) { $settings['hl_overlay_color_normal'] = sanitize_text_field($input['hl_overlay_color_normal']); }
    if (isset($input['hl_overlay_color_hover'])) { $settings['hl_overlay_color_hover'] = sanitize_text_field($input['hl_overlay_color_hover']); }
    if (isset($input['hl_img_position'])) { $settings['hl_img_position'] = sanitize_text_field($input['hl_img_position']); }
    if (isset($input['hl_img_size'])) { $settings['hl_img_size'] = sanitize_text_field($input['hl_img_size']); }
    if (isset($input['hl_image_height_st2'])) { $settings['hl_image_height_st2'] = $input['hl_image_height_st2']; }
    if (isset($input['bss_hl_post_br'])) { $settings['bss_hl_post_br'] = $input['bss_hl_post_br']; }
    if (isset($input['normal_content_alignment'])) { $settings['normal_content_alignment'] = sanitize_text_field($input['normal_content_alignment']); }
    if (isset($input['n_c_padding'])) { $settings['n_c_padding'] = $input['n_c_padding']; }
    if (isset($input['n_s_normal_section_box_padding'])) { $settings['n_s_normal_section_box_padding'] = $input['n_s_normal_section_box_padding']; }
    if (isset($input['n_s_normal_section_bootom_space'])) { $settings['n_s_normal_section_bootom_space'] = $input['n_s_normal_section_bootom_space']; }
    if (isset($input['bss_normal_post_br'])) { $settings['bss_normal_post_br'] = $input['bss_normal_post_br']; }
    if (isset($input['feature_img_max_width'])) { $settings['feature_img_max_width'] = $input['feature_img_max_width']; }
    if (isset($input['feature_img_overflow'])) { $settings['feature_img_overflow'] = sanitize_text_field($input['feature_img_overflow']); }
    if (isset($input['feature_img_max_height'])) { $settings['feature_img_max_height'] = $input['feature_img_max_height']; }
    if (isset($input['n_s_feature_img_br'])) { $settings['n_s_feature_img_br'] = $input['n_s_feature_img_br']; }
    if (isset($input['ticker_label_color'])) { $settings['ticker_label_color'] = sanitize_text_field($input['ticker_label_color']); }
    if (isset($input['ticker_label_bg_color'])) { $settings['ticker_label_bg_color'] = sanitize_text_field($input['ticker_label_bg_color']); }
    if (isset($input['label_icon_right_offset'])) { $settings['label_icon_right_offset'] = $input['label_icon_right_offset']; }
    if (isset($input['label_icon_size'])) { $settings['label_icon_size'] = $input['label_icon_size']; }
    if (isset($input['label_icon_color_n'])) { $settings['label_icon_color_n'] = sanitize_text_field($input['label_icon_color_n']); }
    if (isset($input['label_icon_color_h'])) { $settings['label_icon_color_h'] = sanitize_text_field($input['label_icon_color_h']); }
    if (isset($input['ticker_content_color'])) { $settings['ticker_content_color'] = sanitize_text_field($input['ticker_content_color']); }
    if (isset($input['ticker_content_bg_color'])) { $settings['ticker_content_bg_color'] = sanitize_text_field($input['ticker_content_bg_color']); }
    if (isset($input['ticker_content_date_color'])) { $settings['ticker_content_date_color'] = sanitize_text_field($input['ticker_content_date_color']); }
    if (isset($input['ticker_navigation_size'])) { $settings['ticker_navigation_size'] = $input['ticker_navigation_size']; }
    if (isset($input['ticker_navigation_color'])) { $settings['ticker_navigation_color'] = sanitize_text_field($input['ticker_navigation_color']); }
    if (isset($input['ticker_navigation_color_h'])) { $settings['ticker_navigation_color_h'] = sanitize_text_field($input['ticker_navigation_color_h']); }
    if (isset($input['ticker_author_icon_size'])) { $settings['ticker_author_icon_size'] = $input['ticker_author_icon_size']; }
    if (isset($input['ticker_author_color'])) { $settings['ticker_author_color'] = sanitize_text_field($input['ticker_author_color']); }
    if (isset($input['ticker_author_icon_color'])) { $settings['ticker_author_icon_color'] = sanitize_text_field($input['ticker_author_icon_color']); }
    if (isset($input['ticker_author_border_radius'])) { $settings['ticker_author_border_radius'] = $input['ticker_author_border_radius']; }
    if (isset($input['ticker_whole_border_r'])) { $settings['ticker_whole_border_r'] = $input['ticker_whole_border_r']; }
    if (isset($input['content_outer_padding'])) { $settings['content_outer_padding'] = $input['content_outer_padding']; }
    if (isset($input['content_inner_padding'])) { $settings['content_inner_padding'] = $input['content_inner_padding']; }
    if (isset($input['box_border'])) { $settings['box_border'] = sanitize_text_field($input['box_border']); }
    if (isset($input['border_style'])) { $settings['border_style'] = sanitize_text_field($input['border_style']); }
    if (isset($input['box_border_width'])) { $settings['box_border_width'] = $input['box_border_width']; }
    if (isset($input['box_border_color'])) { $settings['box_border_color'] = sanitize_text_field($input['box_border_color']); }
    if (isset($input['border_radius'])) { $settings['border_radius'] = $input['border_radius']; }
    if (isset($input['box_border_hover_color'])) { $settings['box_border_hover_color'] = sanitize_text_field($input['box_border_hover_color']); }
    if (isset($input['border_hover_radius'])) { $settings['border_hover_radius'] = $input['border_hover_radius']; }
    if (isset($input['loop_bg_overlay_color'])) { $settings['loop_bg_overlay_color'] = sanitize_text_field($input['loop_bg_overlay_color']); }
    if (isset($input['loop_bg_overlay_h_color'])) { $settings['loop_bg_overlay_h_color'] = sanitize_text_field($input['loop_bg_overlay_h_color']); }
    if (isset($input['carousel_unique_id'])) { $settings['carousel_unique_id'] = sanitize_text_field($input['carousel_unique_id']); }
    if (isset($input['slider_direction'])) { $settings['slider_direction'] = sanitize_text_field($input['slider_direction']); }
    if (isset($input['carousel_direction'])) { $settings['carousel_direction'] = sanitize_text_field($input['carousel_direction']); }
    if (isset($input['slide_speed'])) { $settings['slide_speed'] = $input['slide_speed']; }
    if (isset($input['slider_desktop_column'])) { $settings['slider_desktop_column'] = sanitize_text_field($input['slider_desktop_column']); }
    if (isset($input['steps_slide'])) { $settings['steps_slide'] = sanitize_text_field($input['steps_slide']); }
    if (isset($input['slider_padding'])) { $settings['slider_padding'] = $input['slider_padding']; }
    if (isset($input['slider_draggable'])) { $settings['slider_draggable'] = sanitize_text_field($input['slider_draggable']); }
    if (isset($input['slider_infinite'])) { $settings['slider_infinite'] = sanitize_text_field($input['slider_infinite']); }
    if (isset($input['slider_pause_hover'])) { $settings['slider_pause_hover'] = sanitize_text_field($input['slider_pause_hover']); }
    if (isset($input['slider_adaptive_height'])) { $settings['slider_adaptive_height'] = sanitize_text_field($input['slider_adaptive_height']); }
    if (isset($input['slider_autoplay'])) { $settings['slider_autoplay'] = sanitize_text_field($input['slider_autoplay']); }
    if (isset($input['autoplay_speed'])) { $settings['autoplay_speed'] = $input['autoplay_speed']; }
    if (isset($input['slider_dots'])) { $settings['slider_dots'] = sanitize_text_field($input['slider_dots']); }
    if (isset($input['slider_dots_style'])) { $settings['slider_dots_style'] = sanitize_text_field($input['slider_dots_style']); }
    if (isset($input['dots_border_color'])) { $settings['dots_border_color'] = sanitize_text_field($input['dots_border_color']); }
    if (isset($input['dots_bg_color'])) { $settings['dots_bg_color'] = sanitize_text_field($input['dots_bg_color']); }
    if (isset($input['dots_active_border_color'])) { $settings['dots_active_border_color'] = sanitize_text_field($input['dots_active_border_color']); }
    if (isset($input['dots_active_bg_color'])) { $settings['dots_active_bg_color'] = sanitize_text_field($input['dots_active_bg_color']); }
    if (isset($input['dots_top_padding'])) { $settings['dots_top_padding'] = $input['dots_top_padding']; }
    if (isset($input['hover_show_dots'])) { $settings['hover_show_dots'] = sanitize_text_field($input['hover_show_dots']); }
    if (isset($input['slider_arrows'])) { $settings['slider_arrows'] = sanitize_text_field($input['slider_arrows']); }
    if (isset($input['slider_arrows_style'])) { $settings['slider_arrows_style'] = sanitize_text_field($input['slider_arrows_style']); }
    if (isset($input['arrows_position'])) { $settings['arrows_position'] = sanitize_text_field($input['arrows_position']); }
    if (isset($input['arrow_bg_color'])) { $settings['arrow_bg_color'] = sanitize_text_field($input['arrow_bg_color']); }
    if (isset($input['arrow_icon_color'])) { $settings['arrow_icon_color'] = sanitize_text_field($input['arrow_icon_color']); }
    if (isset($input['arrow_hover_bg_color'])) { $settings['arrow_hover_bg_color'] = sanitize_text_field($input['arrow_hover_bg_color']); }
    if (isset($input['arrow_hover_icon_color'])) { $settings['arrow_hover_icon_color'] = sanitize_text_field($input['arrow_hover_icon_color']); }
    if (isset($input['outer_section_arrow'])) { $settings['outer_section_arrow'] = sanitize_text_field($input['outer_section_arrow']); }
    if (isset($input['hover_show_arrow'])) { $settings['hover_show_arrow'] = sanitize_text_field($input['hover_show_arrow']); }
    if (isset($input['slider_center_mode'])) { $settings['slider_center_mode'] = sanitize_text_field($input['slider_center_mode']); }
    if (isset($input['center_padding'])) { $settings['center_padding'] = $input['center_padding']; }
    if (isset($input['slider_center_effects'])) { $settings['slider_center_effects'] = sanitize_text_field($input['slider_center_effects']); }
    if (isset($input['scale_center_slide'])) { $settings['scale_center_slide'] = $input['scale_center_slide']; }
    if (isset($input['scale_normal_slide'])) { $settings['scale_normal_slide'] = $input['scale_normal_slide']; }
    if (isset($input['opacity_normal_slide'])) { $settings['opacity_normal_slide'] = $input['opacity_normal_slide']; }
    if (isset($input['slider_rows'])) { $settings['slider_rows'] = sanitize_text_field($input['slider_rows']); }
    if (isset($input['slide_row_top_space'])) { $settings['slide_row_top_space'] = $input['slide_row_top_space']; }
    if (isset($input['slider_tablet_column'])) { $settings['slider_tablet_column'] = sanitize_text_field($input['slider_tablet_column']); }
    if (isset($input['tablet_steps_slide'])) { $settings['tablet_steps_slide'] = sanitize_text_field($input['tablet_steps_slide']); }
    if (isset($input['slider_responsive_tablet'])) { $settings['slider_responsive_tablet'] = sanitize_text_field($input['slider_responsive_tablet']); }
    if (isset($input['tablet_slider_draggable'])) { $settings['tablet_slider_draggable'] = sanitize_text_field($input['tablet_slider_draggable']); }
    if (isset($input['tablet_slider_infinite'])) { $settings['tablet_slider_infinite'] = sanitize_text_field($input['tablet_slider_infinite']); }
    if (isset($input['tablet_slider_autoplay'])) { $settings['tablet_slider_autoplay'] = sanitize_text_field($input['tablet_slider_autoplay']); }
    if (isset($input['tablet_autoplay_speed'])) { $settings['tablet_autoplay_speed'] = $input['tablet_autoplay_speed']; }
    if (isset($input['tablet_slider_dots'])) { $settings['tablet_slider_dots'] = sanitize_text_field($input['tablet_slider_dots']); }
    if (isset($input['tablet_slider_dots_style'])) { $settings['tablet_slider_dots_style'] = sanitize_text_field($input['tablet_slider_dots_style']); }
    if (isset($input['tablet_dots_border_color'])) { $settings['tablet_dots_border_color'] = sanitize_text_field($input['tablet_dots_border_color']); }
    if (isset($input['tablet_dots_bg_color'])) { $settings['tablet_dots_bg_color'] = sanitize_text_field($input['tablet_dots_bg_color']); }
    if (isset($input['tablet_dots_active_border_color'])) { $settings['tablet_dots_active_border_color'] = sanitize_text_field($input['tablet_dots_active_border_color']); }
    if (isset($input['tablet_dots_active_bg_color'])) { $settings['tablet_dots_active_bg_color'] = sanitize_text_field($input['tablet_dots_active_bg_color']); }
    if (isset($input['tablet_dots_top_padding'])) { $settings['tablet_dots_top_padding'] = $input['tablet_dots_top_padding']; }
    if (isset($input['tablet_hover_show_dots'])) { $settings['tablet_hover_show_dots'] = sanitize_text_field($input['tablet_hover_show_dots']); }
    if (isset($input['tablet_slider_arrows'])) { $settings['tablet_slider_arrows'] = sanitize_text_field($input['tablet_slider_arrows']); }
    if (isset($input['tablet_slider_arrows_style'])) { $settings['tablet_slider_arrows_style'] = sanitize_text_field($input['tablet_slider_arrows_style']); }
    if (isset($input['tablet_arrows_position'])) { $settings['tablet_arrows_position'] = sanitize_text_field($input['tablet_arrows_position']); }
    if (isset($input['tablet_arrow_bg_color'])) { $settings['tablet_arrow_bg_color'] = sanitize_text_field($input['tablet_arrow_bg_color']); }
    if (isset($input['tablet_arrow_icon_color'])) { $settings['tablet_arrow_icon_color'] = sanitize_text_field($input['tablet_arrow_icon_color']); }
    if (isset($input['tablet_arrow_hover_bg_color'])) { $settings['tablet_arrow_hover_bg_color'] = sanitize_text_field($input['tablet_arrow_hover_bg_color']); }
    if (isset($input['tablet_arrow_hover_icon_color'])) { $settings['tablet_arrow_hover_icon_color'] = sanitize_text_field($input['tablet_arrow_hover_icon_color']); }
    if (isset($input['tablet_outer_section_arrow'])) { $settings['tablet_outer_section_arrow'] = sanitize_text_field($input['tablet_outer_section_arrow']); }
    if (isset($input['tablet_hover_show_arrow'])) { $settings['tablet_hover_show_arrow'] = sanitize_text_field($input['tablet_hover_show_arrow']); }
    if (isset($input['tablet_slider_rows'])) { $settings['tablet_slider_rows'] = sanitize_text_field($input['tablet_slider_rows']); }
    if (isset($input['tablet_center_mode'])) { $settings['tablet_center_mode'] = sanitize_text_field($input['tablet_center_mode']); }
    if (isset($input['tablet_center_padding'])) { $settings['tablet_center_padding'] = $input['tablet_center_padding']; }
    if (isset($input['slider_mobile_column'])) { $settings['slider_mobile_column'] = sanitize_text_field($input['slider_mobile_column']); }
    if (isset($input['mobile_steps_slide'])) { $settings['mobile_steps_slide'] = sanitize_text_field($input['mobile_steps_slide']); }
    if (isset($input['slider_responsive_mobile'])) { $settings['slider_responsive_mobile'] = sanitize_text_field($input['slider_responsive_mobile']); }
    if (isset($input['mobile_slider_draggable'])) { $settings['mobile_slider_draggable'] = sanitize_text_field($input['mobile_slider_draggable']); }
    if (isset($input['mobile_slider_infinite'])) { $settings['mobile_slider_infinite'] = sanitize_text_field($input['mobile_slider_infinite']); }
    if (isset($input['mobile_slider_autoplay'])) { $settings['mobile_slider_autoplay'] = sanitize_text_field($input['mobile_slider_autoplay']); }
    if (isset($input['mobile_autoplay_speed'])) { $settings['mobile_autoplay_speed'] = $input['mobile_autoplay_speed']; }
    if (isset($input['mobile_slider_dots'])) { $settings['mobile_slider_dots'] = sanitize_text_field($input['mobile_slider_dots']); }
    if (isset($input['mobile_slider_dots_style'])) { $settings['mobile_slider_dots_style'] = sanitize_text_field($input['mobile_slider_dots_style']); }
    if (isset($input['mobile_dots_border_color'])) { $settings['mobile_dots_border_color'] = sanitize_text_field($input['mobile_dots_border_color']); }
    if (isset($input['mobile_dots_bg_color'])) { $settings['mobile_dots_bg_color'] = sanitize_text_field($input['mobile_dots_bg_color']); }
    if (isset($input['mobile_dots_active_border_color'])) { $settings['mobile_dots_active_border_color'] = sanitize_text_field($input['mobile_dots_active_border_color']); }
    if (isset($input['mobile_dots_active_bg_color'])) { $settings['mobile_dots_active_bg_color'] = sanitize_text_field($input['mobile_dots_active_bg_color']); }
    if (isset($input['mobile_dots_top_padding'])) { $settings['mobile_dots_top_padding'] = $input['mobile_dots_top_padding']; }
    if (isset($input['mobile_hover_show_dots'])) { $settings['mobile_hover_show_dots'] = sanitize_text_field($input['mobile_hover_show_dots']); }
    if (isset($input['mobile_slider_arrows'])) { $settings['mobile_slider_arrows'] = sanitize_text_field($input['mobile_slider_arrows']); }
    if (isset($input['mobile_slider_arrows_style'])) { $settings['mobile_slider_arrows_style'] = sanitize_text_field($input['mobile_slider_arrows_style']); }
    if (isset($input['mobile_arrows_position'])) { $settings['mobile_arrows_position'] = sanitize_text_field($input['mobile_arrows_position']); }
    if (isset($input['mobile_arrow_bg_color'])) { $settings['mobile_arrow_bg_color'] = sanitize_text_field($input['mobile_arrow_bg_color']); }
    if (isset($input['mobile_arrow_icon_color'])) { $settings['mobile_arrow_icon_color'] = sanitize_text_field($input['mobile_arrow_icon_color']); }
    if (isset($input['mobile_arrow_hover_bg_color'])) { $settings['mobile_arrow_hover_bg_color'] = sanitize_text_field($input['mobile_arrow_hover_bg_color']); }
    if (isset($input['mobile_arrow_hover_icon_color'])) { $settings['mobile_arrow_hover_icon_color'] = sanitize_text_field($input['mobile_arrow_hover_icon_color']); }
    if (isset($input['mobile_outer_section_arrow'])) { $settings['mobile_outer_section_arrow'] = sanitize_text_field($input['mobile_outer_section_arrow']); }
    if (isset($input['mobile_hover_show_arrow'])) { $settings['mobile_hover_show_arrow'] = sanitize_text_field($input['mobile_hover_show_arrow']); }
    if (isset($input['mobile_slider_rows'])) { $settings['mobile_slider_rows'] = sanitize_text_field($input['mobile_slider_rows']); }
    if (isset($input['mobile_center_mode'])) { $settings['mobile_center_mode'] = sanitize_text_field($input['mobile_center_mode']); }
    if (isset($input['mobile_center_padding'])) { $settings['mobile_center_padding'] = $input['mobile_center_padding']; }
    if (isset($input['pnf_padding'])) { $settings['pnf_padding'] = $input['pnf_padding']; }
    if (isset($input['pnf_color'])) { $settings['pnf_color'] = sanitize_text_field($input['pnf_color']); }
    if (isset($input['pnf_br'])) { $settings['pnf_br'] = $input['pnf_br']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
