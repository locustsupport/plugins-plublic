<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-wp-bodymovin', [
'label' => __('WP Bodymovin', 'theplus'),
    'description' => __('Adds The Plus "WP Bodymovin" widget (tp-wp-bodymovin) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'        => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'      => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'       => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'lottie_source'  => ['type' => 'string',  'enum' => ['url', 'media'], 'description' => 'Lottie animation source type'],
        'lottie_url'     => ['type' => 'string',  'description' => 'URL to Lottie JSON animation file'],
        'lottie_media'   => ['type' => 'integer', 'description' => 'Media attachment ID of Lottie JSON'],
        'lottie_loop'    => ['type' => 'string',  'enum' => ['yes', 'no'], 'description' => 'Loop animation'],
        'lottie_autoplay'=> ['type' => 'string',  'enum' => ['yes', 'no'], 'description' => 'Auto-play animation'],
        'lottie_speed'   => ['type' => 'number',  'description' => 'Playback speed 1=normal'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Use tpae/tpae-widget-schema to discover keys.'],
    ], 'required' => ['post_id', 'parent_id', 'lottie_source'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_wp_bodymovin_ability',
    'permission_callback' => 'tpaep_mcp_theplus_wp_bodymovin_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_wp_bodymovin_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_wp_bodymovin_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-wp-bodymovin';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus WP Bodymovin widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    if (empty($input['lottie_source'])) { return new WP_Error('missing_params', __('lottie_source is required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (!empty($input['lottie_source']))   { $settings['lottie_source']   = sanitize_key($input['lottie_source']); }
    if (!empty($input['lottie_url']))      { $settings['lottie_url']      = esc_url_raw($input['lottie_url']); }
    if (!empty($input['lottie_media']))    { $settings['lottie_media']    = ['id' => absint($input['lottie_media']), 'url' => '']; }
    if (!empty($input['lottie_loop']))     { $settings['lottie_loop']     = sanitize_key($input['lottie_loop']); }
    if (!empty($input['lottie_autoplay'])) { $settings['lottie_autoplay'] = sanitize_key($input['lottie_autoplay']); }
    if (isset($input['lottie_speed']))     { $settings['lottie_speed']    = ['size' => max(0.1, (float)$input['lottie_speed']), 'unit' => '']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
