<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-team-member-listout', [
'label' => __('Team Member Listout (Pro)', 'theplus'),
    'description' => __('Adds The Plus "Team Member Listout" widget (tp-team-member-listout) to an Elementor container. Pro version with extra styles.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'       => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'     => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'      => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'selctSource' => ['type' => 'string', 'description' => 'Select Source', 'enum' => ['post', 'repeater']],
        'memberTitle' => ['type' => 'string', 'description' => 'Member Name'],
        'tmImage' => ['type' => 'integer', 'description' => 'Member Image (Image ID)'],
        'designationTeam' => ['type' => 'string', 'description' => 'Designation'],
        'customUrl' => ['type' => 'object', 'description' => 'Single Page Url '],
        'websiteLink' => ['type' => 'object', 'description' => 'Website '],
        'fbLink' => ['type' => 'object', 'description' => 'Facebook '],
        'twitterLink' => ['type' => 'object', 'description' => 'Twitter '],
        'instaLink' => ['type' => 'object', 'description' => 'Instagram '],
        'gooogleLink' => ['type' => 'object', 'description' => 'Google '],
        'linkdinLink' => ['type' => 'object', 'description' => 'Linkedin '],
        'emailLink' => ['type' => 'object', 'description' => 'Email '],
        'phnLink' => ['type' => 'object', 'description' => 'Phone '],
        'clientCategory' => ['type' => 'string', 'description' => 'Category (For Filter)'],
        'tmList' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Member List'],
        'style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'style-1', 'style-2', 'style-3', 'style-4']],
        'layout' => ['type' => 'string', 'description' => 'Layout', 'enum' => ['carousel', 'columns', 'grid', 'masonry']],
        'content_alignment' => ['type' => 'object', 'description' => 'Content Alignment', 'enum' => ['center', 'icon', 'left', 'right', 'toggle', '{{WRAPPER}} .team-member-list .post-content-bottom']],
        'disable_link' => ['type' => 'string', 'description' => 'Disable Link', 'enum' => ['yes', 'no']],
        'post_category' => ['type' => 'string', 'description' => 'Select Category', 'enum' => ['multiple']],
        'display_posts' => ['type' => 'string', 'description' => 'Maximum Posts Display'],
        'post_offset' => ['type' => 'string', 'description' => 'Offset Posts'],
        'post_order_by' => ['type' => 'string', 'description' => 'Order By'],
        'post_order' => ['type' => 'string', 'description' => 'Order'],
        'desktop_column' => ['type' => 'string', 'description' => 'Desktop Column', 'enum' => ['layout!']],
        'tablet_column' => ['type' => 'string', 'description' => 'Tablet Column', 'enum' => ['layout!']],
        'mobile_column' => ['type' => 'string', 'description' => 'Mobile Column', 'enum' => ['layout!']],
        'columns_gap' => ['type' => 'object', 'description' => 'Columns Gap/Space Between (Dimensions Object)'],
        'filter_category' => ['type' => 'string', 'description' => 'Category Wise Filter', 'enum' => ['yes', 'no']],
        'filter_type' => ['type' => 'string', 'description' => 'Filter Type', 'enum' => ['ajax_base', 'filter_category', 'normal', 'selctSource!']],
        'filter_search_type' => ['type' => 'string', 'description' => 'Search Type', 'enum' => ['filter_category', 'selctSource!', 'slug', 'term_id']],
        'all_filter_category_switch' => ['type' => 'string', 'description' => 'All Filter', 'enum' => ['yes', 'no']],
        'all_filter_category' => ['type' => 'string', 'description' => 'All Filter Category Text'],
        'filter_style' => ['type' => 'string', 'description' => 'Category Filter Style', 'enum' => ['filter_category', 'layout!']],
        'filter_hover_style' => ['type' => 'string', 'description' => 'Filter Hover Style', 'enum' => ['filter_category', 'layout!']],
        'filter_category_align' => ['type' => 'string', 'description' => 'Filter Alignment', 'enum' => ['center', 'filter_category', 'icon', 'layout!', 'left', 'right', 'toggle']],
        'post_extra_option' => ['type' => 'string', 'description' => 'More Post Loading Options', 'enum' => ['lazy_load', 'load_more', 'none']],
        'load_more_btn_text' => ['type' => 'string', 'description' => 'Button Text'],
        'tp_loading_text' => ['type' => 'string', 'description' => 'Loading Text'],
        'loaded_posts_text' => ['type' => 'string', 'description' => 'All Posts Loaded Text'],
        'load_more_post' => ['type' => 'string', 'description' => 'More posts on click/scroll'],
        'load_more_border' => ['type' => 'string', 'description' => 'Load More Border', 'enum' => ['yes', 'no']],
        'load_more_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['load_more_border', 'post_extra_option', '{{WRAPPER}} .ajax_load_more .post-load-more']],
        'load_more_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'load_more_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'load_more_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'load_more_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'load_more_border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'load_more_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'loaded_posts_color' => ['type' => 'string', 'description' => 'Loaded Posts Text Color (Color Hex/RGBA)'],
        'loading_spin_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'loading_spin_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'loading_spin_border_size' => ['type' => 'object', 'description' => 'Border Size (Slider/Size Object)'],
        'load_more_color_hover' => ['type' => 'string', 'description' => 'Text Hover Color (Color Hex/RGBA)'],
        'post_title_tag' => ['type' => 'string', 'description' => 'Title Tag'],
        'featured_image_type' => ['type' => 'string', 'description' => 'Featured Image Type', 'enum' => ['custom', 'full', 'grid', 'layout']],
        'display_designation' => ['type' => 'string', 'description' => 'Display Designation', 'enum' => ['yes', 'no']],
        'display_social_icon' => ['type' => 'string', 'description' => 'Display Social Icon', 'enum' => ['yes', 'no']],
        'display_thumbnail' => ['type' => 'string', 'description' => 'Display Image Size', 'enum' => ['yes', 'no']],
        'loading_options' => ['type' => 'string', 'description' => 'Loading Options', 'enum' => ['layout!', 'selctSource', 'skeleton']],
        'filter_url' => ['type' => 'string', 'description' => 'URL Enable', 'enum' => ['yes', 'no']],
        'title_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'title_hover_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'designation_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'designation_color_hover' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'social_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'social_icon_width' => ['type' => 'object', 'description' => 'Icon Width (Slider/Size Object)'],
        'social_icon_offset' => ['type' => 'object', 'description' => 'Icon Offset (Slider/Size Object)'],
        'social_icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'social_icon_color_hover' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'social_common_color_opt' => ['type' => 'string', 'description' => 'Social Icon Common Options', 'enum' => ['yes', 'no']],
        'scco_n_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'scco_h_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'shape_image' => ['type' => 'integer', 'description' => 'Mask Image (Image ID)'],
        'mask_image_shadow' => ['type' => 'string', 'description' => 'Image Shadow'],
        'extra_layered_image' => ['type' => 'integer', 'description' => 'Extra Layer Image (Image ID)'],
        'layered_image_animation_effect' => ['type' => 'string', 'description' => 'Animation for Extra Layer Image', 'enum' => ['floating', 'none', 'pulse', 'rotating', 'tossing']],
        'layered_image_animation_hover' => ['type' => 'string', 'description' => 'On Hover Animation', 'enum' => ['yes', 'no']],
        'featured_image_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'featured_image_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'featured_image_background' => ['type' => 'string', 'description' => 'Inner Background Color (Color Hex/RGBA)'],
        'featured_image_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'ImageOverlay' => ['type' => 'object', 'description' => 'Overlay Background Color (Color Hex/RGBA)'],
        'ImageOverlayHover' => ['type' => 'object', 'description' => 'Overlay Background Color (Color Hex/RGBA)'],
        'filter_category_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'filter_category_marign' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'filters_text_color' => ['type' => 'string', 'description' => 'Filters Text Color (Color Hex/RGBA)'],
        'filter_category_color' => ['type' => 'string', 'description' => 'Category Filter Color (Color Hex/RGBA)'],
        'filter_category_4_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'filter_category_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'filter_category_hover_color' => ['type' => 'string', 'description' => 'Category Filter Color (Color Hex/RGBA)'],
        'filter_category_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'filter_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'category_count_color' => ['type' => 'string', 'description' => 'Category Count Color (Color Hex/RGBA)'],
        'category_count_bg_color' => ['type' => 'string', 'description' => 'Count Background Color (Color Hex/RGBA)'],
        'content_bi_padding' => ['type' => 'object', 'description' => 'Content Padding (Dimensions Object)'],
        'content_inner_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'box_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['box_border', '{{WRAPPER}} .team-member-list .team-list-content']],
        'box_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'box_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'box_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'carousel_unique_id' => ['type' => 'string', 'description' => 'Unique Carousel ID'],
        'slider_direction' => ['type' => 'string', 'description' => 'Slider Mode', 'enum' => ['horizontal', 'vertical']],
        'carousel_direction' => ['type' => 'string', 'description' => 'Slide Direction', 'enum' => ['ltr', 'rtl']],
        'slide_speed' => ['type' => 'object', 'description' => 'Slide Speed (Slider/Size Object)'],
        'slider_desktop_column' => ['type' => 'string', 'description' => 'Desktop Columns'],
        'steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_padding' => ['type' => 'object', 'description' => 'Slide Padding (Dimensions Object)'],
        'slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'multi_drag' => ['type' => 'string', 'description' => 'Multi Drag', 'enum' => ['yes', 'no']],
        'slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'slider_pause_hover' => ['type' => 'string', 'description' => 'Pause On Hover', 'enum' => ['yes', 'no']],
        'slider_adaptive_height' => ['type' => 'string', 'description' => 'Adaptive Height', 'enum' => ['yes', 'no']],
        'slider_animation' => ['type' => 'string', 'description' => 'Animation Type', 'enum' => ['ease', 'linear']],
        'slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['slider_dots', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['slider_arrows', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'slider_arrows', 'slider_arrows_style', 'top-right']],
        'arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'slider_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'slider_center_effects' => ['type' => 'string', 'description' => 'Center Slide Effects', 'enum' => ['slider_center_mode']],
        'scale_center_slide' => ['type' => 'object', 'description' => 'Center Slide Scale (Slider/Size Object)'],
        'scale_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Scale (Slider/Size Object)'],
        'opacity_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Opacity (Slider/Size Object)'],
        'slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3']],
        'slide_row_top_space' => ['type' => 'object', 'description' => 'Row Top Space (Slider/Size Object)'],
        'slider_tablet_column' => ['type' => 'string', 'description' => 'Tablet Columns'],
        'tablet_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_tablet' => ['type' => 'string', 'description' => 'Responsive Tablet', 'enum' => ['yes', 'no']],
        'tablet_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'tablet_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'tablet_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'tablet_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'tablet_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['slider_responsive_tablet', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7', 'tablet_slider_dots']],
        'tablet_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'tablet_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'tablet_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'tablet_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'tablet_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'tablet_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['slider_responsive_tablet', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'tablet_slider_arrows']],
        'tablet_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'slider_responsive_tablet', 'tablet_slider_arrows', 'tablet_slider_arrows_style', 'top-right']],
        'tablet_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'tablet_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'tablet_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'tablet_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'tablet_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'tablet_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'tablet_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3', 'slider_responsive_tablet']],
        'tablet_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'tablet_center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'slider_mobile_column' => ['type' => 'string', 'description' => 'Mobile Columns'],
        'mobile_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_mobile' => ['type' => 'string', 'description' => 'Responsive Mobile', 'enum' => ['yes', 'no']],
        'mobile_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'mobile_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'mobile_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'mobile_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'mobile_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['mobile_slider_dots', 'slider_responsive_mobile', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'mobile_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'mobile_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'mobile_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'mobile_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'mobile_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'mobile_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['mobile_slider_arrows', 'slider_responsive_mobile', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'mobile_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'mobile_slider_arrows', 'mobile_slider_arrows_style', 'slider_responsive_mobile', 'top-right']],
        'mobile_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'mobile_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'mobile_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'mobile_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'mobile_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'mobile_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'mobile_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3', 'slider_responsive_mobile']],
        'mobile_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'mobile_center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'pnf_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'pnf_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'pnf_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'messy_column' => ['type' => 'string', 'description' => 'Messy Columns', 'enum' => ['yes', 'no']],
        'desktop_column_1' => ['type' => 'object', 'description' => 'Column 1 (Slider/Size Object)'],
        'desktop_column_2' => ['type' => 'object', 'description' => 'Column 2 (Slider/Size Object)'],
        'desktop_column_3' => ['type' => 'object', 'description' => 'Column 3 (Slider/Size Object)'],
        'desktop_column_4' => ['type' => 'object', 'description' => 'Column 4 (Slider/Size Object)'],
        'desktop_column_5' => ['type' => 'object', 'description' => 'Column 5 (Slider/Size Object)'],
        'desktop_column_6' => ['type' => 'object', 'description' => 'Column 6 (Slider/Size Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports SVG social hover effects, multi-style carousels, and dynamic taxonomy filters.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_pro_team_member_listout_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pro_team_member_listout_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_pro_team_member_listout_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_pro_team_member_listout_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-team-member-listout';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Team Member Listout widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['selctSource'])) { $settings['selctSource'] = sanitize_text_field($input['selctSource']); }
    if (isset($input['memberTitle'])) { $settings['memberTitle'] = sanitize_text_field($input['memberTitle']); }
    if (!empty($input['tmImage'])) { $settings['tmImage'] = ['id' => absint($input['tmImage'])]; }
    if (isset($input['designationTeam'])) { $settings['designationTeam'] = sanitize_text_field($input['designationTeam']); }
    if (isset($input['customUrl'])) { $settings['customUrl'] = $input['customUrl']; }
    if (isset($input['websiteLink'])) { $settings['websiteLink'] = $input['websiteLink']; }
    if (isset($input['fbLink'])) { $settings['fbLink'] = $input['fbLink']; }
    if (isset($input['twitterLink'])) { $settings['twitterLink'] = $input['twitterLink']; }
    if (isset($input['instaLink'])) { $settings['instaLink'] = $input['instaLink']; }
    if (isset($input['gooogleLink'])) { $settings['gooogleLink'] = $input['gooogleLink']; }
    if (isset($input['linkdinLink'])) { $settings['linkdinLink'] = $input['linkdinLink']; }
    if (isset($input['emailLink'])) { $settings['emailLink'] = $input['emailLink']; }
    if (isset($input['phnLink'])) { $settings['phnLink'] = $input['phnLink']; }
    if (isset($input['clientCategory'])) { $settings['clientCategory'] = sanitize_text_field($input['clientCategory']); }
    if (isset($input['tmList'])) { $settings['tmList'] = $input['tmList']; }
    if (isset($input['style'])) { $settings['style'] = sanitize_text_field($input['style']); }
    if (isset($input['layout'])) { $settings['layout'] = sanitize_text_field($input['layout']); }
    if (isset($input['content_alignment'])) { $settings['content_alignment'] = $input['content_alignment']; }
    if (isset($input['disable_link'])) { $settings['disable_link'] = sanitize_text_field($input['disable_link']); }
    if (isset($input['post_category'])) { $settings['post_category'] = sanitize_text_field($input['post_category']); }
    if (isset($input['display_posts'])) { $settings['display_posts'] = sanitize_text_field($input['display_posts']); }
    if (isset($input['post_offset'])) { $settings['post_offset'] = sanitize_text_field($input['post_offset']); }
    if (isset($input['post_order_by'])) { $settings['post_order_by'] = sanitize_text_field($input['post_order_by']); }
    if (isset($input['post_order'])) { $settings['post_order'] = sanitize_text_field($input['post_order']); }
    if (isset($input['desktop_column'])) { $settings['desktop_column'] = sanitize_text_field($input['desktop_column']); }
    if (isset($input['tablet_column'])) { $settings['tablet_column'] = sanitize_text_field($input['tablet_column']); }
    if (isset($input['mobile_column'])) { $settings['mobile_column'] = sanitize_text_field($input['mobile_column']); }
    if (isset($input['columns_gap'])) { $settings['columns_gap'] = $input['columns_gap']; }
    if (isset($input['filter_category'])) { $settings['filter_category'] = sanitize_text_field($input['filter_category']); }
    if (isset($input['filter_type'])) { $settings['filter_type'] = sanitize_text_field($input['filter_type']); }
    if (isset($input['filter_search_type'])) { $settings['filter_search_type'] = sanitize_text_field($input['filter_search_type']); }
    if (isset($input['all_filter_category_switch'])) { $settings['all_filter_category_switch'] = sanitize_text_field($input['all_filter_category_switch']); }
    if (isset($input['all_filter_category'])) { $settings['all_filter_category'] = sanitize_text_field($input['all_filter_category']); }
    if (isset($input['filter_style'])) { $settings['filter_style'] = sanitize_text_field($input['filter_style']); }
    if (isset($input['filter_hover_style'])) { $settings['filter_hover_style'] = sanitize_text_field($input['filter_hover_style']); }
    if (isset($input['filter_category_align'])) { $settings['filter_category_align'] = sanitize_text_field($input['filter_category_align']); }
    if (isset($input['post_extra_option'])) { $settings['post_extra_option'] = sanitize_text_field($input['post_extra_option']); }
    if (isset($input['load_more_btn_text'])) { $settings['load_more_btn_text'] = sanitize_text_field($input['load_more_btn_text']); }
    if (isset($input['tp_loading_text'])) { $settings['tp_loading_text'] = sanitize_text_field($input['tp_loading_text']); }
    if (isset($input['loaded_posts_text'])) { $settings['loaded_posts_text'] = sanitize_text_field($input['loaded_posts_text']); }
    if (isset($input['load_more_post'])) { $settings['load_more_post'] = sanitize_text_field($input['load_more_post']); }
    if (isset($input['load_more_border'])) { $settings['load_more_border'] = sanitize_text_field($input['load_more_border']); }
    if (isset($input['load_more_border_style'])) { $settings['load_more_border_style'] = sanitize_text_field($input['load_more_border_style']); }
    if (isset($input['load_more_border_width'])) { $settings['load_more_border_width'] = $input['load_more_border_width']; }
    if (isset($input['load_more_border_color'])) { $settings['load_more_border_color'] = sanitize_text_field($input['load_more_border_color']); }
    if (isset($input['load_more_border_radius'])) { $settings['load_more_border_radius'] = $input['load_more_border_radius']; }
    if (isset($input['load_more_border_hover_color'])) { $settings['load_more_border_hover_color'] = sanitize_text_field($input['load_more_border_hover_color']); }
    if (isset($input['load_more_border_hover_radius'])) { $settings['load_more_border_hover_radius'] = $input['load_more_border_hover_radius']; }
    if (isset($input['load_more_color'])) { $settings['load_more_color'] = sanitize_text_field($input['load_more_color']); }
    if (isset($input['loaded_posts_color'])) { $settings['loaded_posts_color'] = sanitize_text_field($input['loaded_posts_color']); }
    if (isset($input['loading_spin_color'])) { $settings['loading_spin_color'] = sanitize_text_field($input['loading_spin_color']); }
    if (isset($input['loading_spin_size'])) { $settings['loading_spin_size'] = $input['loading_spin_size']; }
    if (isset($input['loading_spin_border_size'])) { $settings['loading_spin_border_size'] = $input['loading_spin_border_size']; }
    if (isset($input['load_more_color_hover'])) { $settings['load_more_color_hover'] = sanitize_text_field($input['load_more_color_hover']); }
    if (isset($input['post_title_tag'])) { $settings['post_title_tag'] = sanitize_text_field($input['post_title_tag']); }
    if (isset($input['featured_image_type'])) { $settings['featured_image_type'] = sanitize_text_field($input['featured_image_type']); }
    if (isset($input['display_designation'])) { $settings['display_designation'] = sanitize_text_field($input['display_designation']); }
    if (isset($input['display_social_icon'])) { $settings['display_social_icon'] = sanitize_text_field($input['display_social_icon']); }
    if (isset($input['display_thumbnail'])) { $settings['display_thumbnail'] = sanitize_text_field($input['display_thumbnail']); }
    if (isset($input['loading_options'])) { $settings['loading_options'] = sanitize_text_field($input['loading_options']); }
    if (isset($input['filter_url'])) { $settings['filter_url'] = sanitize_text_field($input['filter_url']); }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['title_hover_color'])) { $settings['title_hover_color'] = sanitize_text_field($input['title_hover_color']); }
    if (isset($input['designation_color'])) { $settings['designation_color'] = sanitize_text_field($input['designation_color']); }
    if (isset($input['designation_color_hover'])) { $settings['designation_color_hover'] = sanitize_text_field($input['designation_color_hover']); }
    if (isset($input['social_icon_size'])) { $settings['social_icon_size'] = $input['social_icon_size']; }
    if (isset($input['social_icon_width'])) { $settings['social_icon_width'] = $input['social_icon_width']; }
    if (isset($input['social_icon_offset'])) { $settings['social_icon_offset'] = $input['social_icon_offset']; }
    if (isset($input['social_icon_color'])) { $settings['social_icon_color'] = sanitize_text_field($input['social_icon_color']); }
    if (isset($input['social_icon_color_hover'])) { $settings['social_icon_color_hover'] = sanitize_text_field($input['social_icon_color_hover']); }
    if (isset($input['social_common_color_opt'])) { $settings['social_common_color_opt'] = sanitize_text_field($input['social_common_color_opt']); }
    if (isset($input['scco_n_br'])) { $settings['scco_n_br'] = $input['scco_n_br']; }
    if (isset($input['scco_h_br'])) { $settings['scco_h_br'] = $input['scco_h_br']; }
    if (!empty($input['shape_image'])) { $settings['shape_image'] = ['id' => absint($input['shape_image'])]; }
    if (isset($input['mask_image_shadow'])) { $settings['mask_image_shadow'] = sanitize_text_field($input['mask_image_shadow']); }
    if (!empty($input['extra_layered_image'])) { $settings['extra_layered_image'] = ['id' => absint($input['extra_layered_image'])]; }
    if (isset($input['layered_image_animation_effect'])) { $settings['layered_image_animation_effect'] = sanitize_text_field($input['layered_image_animation_effect']); }
    if (isset($input['layered_image_animation_hover'])) { $settings['layered_image_animation_hover'] = sanitize_text_field($input['layered_image_animation_hover']); }
    if (isset($input['featured_image_margin'])) { $settings['featured_image_margin'] = $input['featured_image_margin']; }
    if (isset($input['featured_image_padding'])) { $settings['featured_image_padding'] = $input['featured_image_padding']; }
    if (isset($input['featured_image_background'])) { $settings['featured_image_background'] = sanitize_text_field($input['featured_image_background']); }
    if (isset($input['featured_image_radius'])) { $settings['featured_image_radius'] = $input['featured_image_radius']; }
    if (isset($input['ImageOverlay'])) { $settings['ImageOverlay'] = $input['ImageOverlay']; }
    if (isset($input['ImageOverlayHover'])) { $settings['ImageOverlayHover'] = $input['ImageOverlayHover']; }
    if (isset($input['filter_category_padding'])) { $settings['filter_category_padding'] = $input['filter_category_padding']; }
    if (isset($input['filter_category_marign'])) { $settings['filter_category_marign'] = $input['filter_category_marign']; }
    if (isset($input['filters_text_color'])) { $settings['filters_text_color'] = sanitize_text_field($input['filters_text_color']); }
    if (isset($input['filter_category_color'])) { $settings['filter_category_color'] = sanitize_text_field($input['filter_category_color']); }
    if (isset($input['filter_category_4_border_color'])) { $settings['filter_category_4_border_color'] = sanitize_text_field($input['filter_category_4_border_color']); }
    if (isset($input['filter_category_radius'])) { $settings['filter_category_radius'] = $input['filter_category_radius']; }
    if (isset($input['filter_category_hover_color'])) { $settings['filter_category_hover_color'] = sanitize_text_field($input['filter_category_hover_color']); }
    if (isset($input['filter_category_hover_radius'])) { $settings['filter_category_hover_radius'] = $input['filter_category_hover_radius']; }
    if (isset($input['filter_border_hover_color'])) { $settings['filter_border_hover_color'] = sanitize_text_field($input['filter_border_hover_color']); }
    if (isset($input['category_count_color'])) { $settings['category_count_color'] = sanitize_text_field($input['category_count_color']); }
    if (isset($input['category_count_bg_color'])) { $settings['category_count_bg_color'] = sanitize_text_field($input['category_count_bg_color']); }
    if (isset($input['content_bi_padding'])) { $settings['content_bi_padding'] = $input['content_bi_padding']; }
    if (isset($input['content_inner_padding'])) { $settings['content_inner_padding'] = $input['content_inner_padding']; }
    if (isset($input['box_border'])) { $settings['box_border'] = sanitize_text_field($input['box_border']); }
    if (isset($input['border_style'])) { $settings['border_style'] = sanitize_text_field($input['border_style']); }
    if (isset($input['box_border_width'])) { $settings['box_border_width'] = $input['box_border_width']; }
    if (isset($input['box_border_color'])) { $settings['box_border_color'] = sanitize_text_field($input['box_border_color']); }
    if (isset($input['border_radius'])) { $settings['border_radius'] = $input['border_radius']; }
    if (isset($input['box_border_hover_color'])) { $settings['box_border_hover_color'] = sanitize_text_field($input['box_border_hover_color']); }
    if (isset($input['border_hover_radius'])) { $settings['border_hover_radius'] = $input['border_hover_radius']; }
    if (isset($input['carousel_unique_id'])) { $settings['carousel_unique_id'] = sanitize_text_field($input['carousel_unique_id']); }
    if (isset($input['slider_direction'])) { $settings['slider_direction'] = sanitize_text_field($input['slider_direction']); }
    if (isset($input['carousel_direction'])) { $settings['carousel_direction'] = sanitize_text_field($input['carousel_direction']); }
    if (isset($input['slide_speed'])) { $settings['slide_speed'] = $input['slide_speed']; }
    if (isset($input['slider_desktop_column'])) { $settings['slider_desktop_column'] = sanitize_text_field($input['slider_desktop_column']); }
    if (isset($input['steps_slide'])) { $settings['steps_slide'] = sanitize_text_field($input['steps_slide']); }
    if (isset($input['slider_padding'])) { $settings['slider_padding'] = $input['slider_padding']; }
    if (isset($input['slider_draggable'])) { $settings['slider_draggable'] = sanitize_text_field($input['slider_draggable']); }
    if (isset($input['multi_drag'])) { $settings['multi_drag'] = sanitize_text_field($input['multi_drag']); }
    if (isset($input['slider_infinite'])) { $settings['slider_infinite'] = sanitize_text_field($input['slider_infinite']); }
    if (isset($input['slider_pause_hover'])) { $settings['slider_pause_hover'] = sanitize_text_field($input['slider_pause_hover']); }
    if (isset($input['slider_adaptive_height'])) { $settings['slider_adaptive_height'] = sanitize_text_field($input['slider_adaptive_height']); }
    if (isset($input['slider_animation'])) { $settings['slider_animation'] = sanitize_text_field($input['slider_animation']); }
    if (isset($input['slider_autoplay'])) { $settings['slider_autoplay'] = sanitize_text_field($input['slider_autoplay']); }
    if (isset($input['autoplay_speed'])) { $settings['autoplay_speed'] = $input['autoplay_speed']; }
    if (isset($input['slider_dots'])) { $settings['slider_dots'] = sanitize_text_field($input['slider_dots']); }
    if (isset($input['slider_dots_style'])) { $settings['slider_dots_style'] = sanitize_text_field($input['slider_dots_style']); }
    if (isset($input['dots_border_color'])) { $settings['dots_border_color'] = sanitize_text_field($input['dots_border_color']); }
    if (isset($input['dots_bg_color'])) { $settings['dots_bg_color'] = sanitize_text_field($input['dots_bg_color']); }
    if (isset($input['dots_active_border_color'])) { $settings['dots_active_border_color'] = sanitize_text_field($input['dots_active_border_color']); }
    if (isset($input['dots_active_bg_color'])) { $settings['dots_active_bg_color'] = sanitize_text_field($input['dots_active_bg_color']); }
    if (isset($input['dots_top_padding'])) { $settings['dots_top_padding'] = $input['dots_top_padding']; }
    if (isset($input['hover_show_dots'])) { $settings['hover_show_dots'] = sanitize_text_field($input['hover_show_dots']); }
    if (isset($input['slider_arrows'])) { $settings['slider_arrows'] = sanitize_text_field($input['slider_arrows']); }
    if (isset($input['slider_arrows_style'])) { $settings['slider_arrows_style'] = sanitize_text_field($input['slider_arrows_style']); }
    if (isset($input['arrows_position'])) { $settings['arrows_position'] = sanitize_text_field($input['arrows_position']); }
    if (isset($input['arrow_bg_color'])) { $settings['arrow_bg_color'] = sanitize_text_field($input['arrow_bg_color']); }
    if (isset($input['arrow_icon_color'])) { $settings['arrow_icon_color'] = sanitize_text_field($input['arrow_icon_color']); }
    if (isset($input['arrow_hover_bg_color'])) { $settings['arrow_hover_bg_color'] = sanitize_text_field($input['arrow_hover_bg_color']); }
    if (isset($input['arrow_hover_icon_color'])) { $settings['arrow_hover_icon_color'] = sanitize_text_field($input['arrow_hover_icon_color']); }
    if (isset($input['outer_section_arrow'])) { $settings['outer_section_arrow'] = sanitize_text_field($input['outer_section_arrow']); }
    if (isset($input['hover_show_arrow'])) { $settings['hover_show_arrow'] = sanitize_text_field($input['hover_show_arrow']); }
    if (isset($input['slider_center_mode'])) { $settings['slider_center_mode'] = sanitize_text_field($input['slider_center_mode']); }
    if (isset($input['center_padding'])) { $settings['center_padding'] = $input['center_padding']; }
    if (isset($input['slider_center_effects'])) { $settings['slider_center_effects'] = sanitize_text_field($input['slider_center_effects']); }
    if (isset($input['scale_center_slide'])) { $settings['scale_center_slide'] = $input['scale_center_slide']; }
    if (isset($input['scale_normal_slide'])) { $settings['scale_normal_slide'] = $input['scale_normal_slide']; }
    if (isset($input['opacity_normal_slide'])) { $settings['opacity_normal_slide'] = $input['opacity_normal_slide']; }
    if (isset($input['slider_rows'])) { $settings['slider_rows'] = sanitize_text_field($input['slider_rows']); }
    if (isset($input['slide_row_top_space'])) { $settings['slide_row_top_space'] = $input['slide_row_top_space']; }
    if (isset($input['slider_tablet_column'])) { $settings['slider_tablet_column'] = sanitize_text_field($input['slider_tablet_column']); }
    if (isset($input['tablet_steps_slide'])) { $settings['tablet_steps_slide'] = sanitize_text_field($input['tablet_steps_slide']); }
    if (isset($input['slider_responsive_tablet'])) { $settings['slider_responsive_tablet'] = sanitize_text_field($input['slider_responsive_tablet']); }
    if (isset($input['tablet_slider_draggable'])) { $settings['tablet_slider_draggable'] = sanitize_text_field($input['tablet_slider_draggable']); }
    if (isset($input['tablet_slider_infinite'])) { $settings['tablet_slider_infinite'] = sanitize_text_field($input['tablet_slider_infinite']); }
    if (isset($input['tablet_slider_autoplay'])) { $settings['tablet_slider_autoplay'] = sanitize_text_field($input['tablet_slider_autoplay']); }
    if (isset($input['tablet_autoplay_speed'])) { $settings['tablet_autoplay_speed'] = $input['tablet_autoplay_speed']; }
    if (isset($input['tablet_slider_dots'])) { $settings['tablet_slider_dots'] = sanitize_text_field($input['tablet_slider_dots']); }
    if (isset($input['tablet_slider_dots_style'])) { $settings['tablet_slider_dots_style'] = sanitize_text_field($input['tablet_slider_dots_style']); }
    if (isset($input['tablet_dots_border_color'])) { $settings['tablet_dots_border_color'] = sanitize_text_field($input['tablet_dots_border_color']); }
    if (isset($input['tablet_dots_bg_color'])) { $settings['tablet_dots_bg_color'] = sanitize_text_field($input['tablet_dots_bg_color']); }
    if (isset($input['tablet_dots_active_border_color'])) { $settings['tablet_dots_active_border_color'] = sanitize_text_field($input['tablet_dots_active_border_color']); }
    if (isset($input['tablet_dots_active_bg_color'])) { $settings['tablet_dots_active_bg_color'] = sanitize_text_field($input['tablet_dots_active_bg_color']); }
    if (isset($input['tablet_dots_top_padding'])) { $settings['tablet_dots_top_padding'] = $input['tablet_dots_top_padding']; }
    if (isset($input['tablet_hover_show_dots'])) { $settings['tablet_hover_show_dots'] = sanitize_text_field($input['tablet_hover_show_dots']); }
    if (isset($input['tablet_slider_arrows'])) { $settings['tablet_slider_arrows'] = sanitize_text_field($input['tablet_slider_arrows']); }
    if (isset($input['tablet_slider_arrows_style'])) { $settings['tablet_slider_arrows_style'] = sanitize_text_field($input['tablet_slider_arrows_style']); }
    if (isset($input['tablet_arrows_position'])) { $settings['tablet_arrows_position'] = sanitize_text_field($input['tablet_arrows_position']); }
    if (isset($input['tablet_arrow_bg_color'])) { $settings['tablet_arrow_bg_color'] = sanitize_text_field($input['tablet_arrow_bg_color']); }
    if (isset($input['tablet_arrow_icon_color'])) { $settings['tablet_arrow_icon_color'] = sanitize_text_field($input['tablet_arrow_icon_color']); }
    if (isset($input['tablet_arrow_hover_bg_color'])) { $settings['tablet_arrow_hover_bg_color'] = sanitize_text_field($input['tablet_arrow_hover_bg_color']); }
    if (isset($input['tablet_arrow_hover_icon_color'])) { $settings['tablet_arrow_hover_icon_color'] = sanitize_text_field($input['tablet_arrow_hover_icon_color']); }
    if (isset($input['tablet_outer_section_arrow'])) { $settings['tablet_outer_section_arrow'] = sanitize_text_field($input['tablet_outer_section_arrow']); }
    if (isset($input['tablet_hover_show_arrow'])) { $settings['tablet_hover_show_arrow'] = sanitize_text_field($input['tablet_hover_show_arrow']); }
    if (isset($input['tablet_slider_rows'])) { $settings['tablet_slider_rows'] = sanitize_text_field($input['tablet_slider_rows']); }
    if (isset($input['tablet_center_mode'])) { $settings['tablet_center_mode'] = sanitize_text_field($input['tablet_center_mode']); }
    if (isset($input['tablet_center_padding'])) { $settings['tablet_center_padding'] = $input['tablet_center_padding']; }
    if (isset($input['slider_mobile_column'])) { $settings['slider_mobile_column'] = sanitize_text_field($input['slider_mobile_column']); }
    if (isset($input['mobile_steps_slide'])) { $settings['mobile_steps_slide'] = sanitize_text_field($input['mobile_steps_slide']); }
    if (isset($input['slider_responsive_mobile'])) { $settings['slider_responsive_mobile'] = sanitize_text_field($input['slider_responsive_mobile']); }
    if (isset($input['mobile_slider_draggable'])) { $settings['mobile_slider_draggable'] = sanitize_text_field($input['mobile_slider_draggable']); }
    if (isset($input['mobile_slider_infinite'])) { $settings['mobile_slider_infinite'] = sanitize_text_field($input['mobile_slider_infinite']); }
    if (isset($input['mobile_slider_autoplay'])) { $settings['mobile_slider_autoplay'] = sanitize_text_field($input['mobile_slider_autoplay']); }
    if (isset($input['mobile_autoplay_speed'])) { $settings['mobile_autoplay_speed'] = $input['mobile_autoplay_speed']; }
    if (isset($input['mobile_slider_dots'])) { $settings['mobile_slider_dots'] = sanitize_text_field($input['mobile_slider_dots']); }
    if (isset($input['mobile_slider_dots_style'])) { $settings['mobile_slider_dots_style'] = sanitize_text_field($input['mobile_slider_dots_style']); }
    if (isset($input['mobile_dots_border_color'])) { $settings['mobile_dots_border_color'] = sanitize_text_field($input['mobile_dots_border_color']); }
    if (isset($input['mobile_dots_bg_color'])) { $settings['mobile_dots_bg_color'] = sanitize_text_field($input['mobile_dots_bg_color']); }
    if (isset($input['mobile_dots_active_border_color'])) { $settings['mobile_dots_active_border_color'] = sanitize_text_field($input['mobile_dots_active_border_color']); }
    if (isset($input['mobile_dots_active_bg_color'])) { $settings['mobile_dots_active_bg_color'] = sanitize_text_field($input['mobile_dots_active_bg_color']); }
    if (isset($input['mobile_dots_top_padding'])) { $settings['mobile_dots_top_padding'] = $input['mobile_dots_top_padding']; }
    if (isset($input['mobile_hover_show_dots'])) { $settings['mobile_hover_show_dots'] = sanitize_text_field($input['mobile_hover_show_dots']); }
    if (isset($input['mobile_slider_arrows'])) { $settings['mobile_slider_arrows'] = sanitize_text_field($input['mobile_slider_arrows']); }
    if (isset($input['mobile_slider_arrows_style'])) { $settings['mobile_slider_arrows_style'] = sanitize_text_field($input['mobile_slider_arrows_style']); }
    if (isset($input['mobile_arrows_position'])) { $settings['mobile_arrows_position'] = sanitize_text_field($input['mobile_arrows_position']); }
    if (isset($input['mobile_arrow_bg_color'])) { $settings['mobile_arrow_bg_color'] = sanitize_text_field($input['mobile_arrow_bg_color']); }
    if (isset($input['mobile_arrow_icon_color'])) { $settings['mobile_arrow_icon_color'] = sanitize_text_field($input['mobile_arrow_icon_color']); }
    if (isset($input['mobile_arrow_hover_bg_color'])) { $settings['mobile_arrow_hover_bg_color'] = sanitize_text_field($input['mobile_arrow_hover_bg_color']); }
    if (isset($input['mobile_arrow_hover_icon_color'])) { $settings['mobile_arrow_hover_icon_color'] = sanitize_text_field($input['mobile_arrow_hover_icon_color']); }
    if (isset($input['mobile_outer_section_arrow'])) { $settings['mobile_outer_section_arrow'] = sanitize_text_field($input['mobile_outer_section_arrow']); }
    if (isset($input['mobile_hover_show_arrow'])) { $settings['mobile_hover_show_arrow'] = sanitize_text_field($input['mobile_hover_show_arrow']); }
    if (isset($input['mobile_slider_rows'])) { $settings['mobile_slider_rows'] = sanitize_text_field($input['mobile_slider_rows']); }
    if (isset($input['mobile_center_mode'])) { $settings['mobile_center_mode'] = sanitize_text_field($input['mobile_center_mode']); }
    if (isset($input['mobile_center_padding'])) { $settings['mobile_center_padding'] = $input['mobile_center_padding']; }
    if (isset($input['pnf_padding'])) { $settings['pnf_padding'] = $input['pnf_padding']; }
    if (isset($input['pnf_color'])) { $settings['pnf_color'] = sanitize_text_field($input['pnf_color']); }
    if (isset($input['pnf_br'])) { $settings['pnf_br'] = $input['pnf_br']; }
    if (isset($input['messy_column'])) { $settings['messy_column'] = sanitize_text_field($input['messy_column']); }
    if (isset($input['desktop_column_1'])) { $settings['desktop_column_1'] = $input['desktop_column_1']; }
    if (isset($input['desktop_column_2'])) { $settings['desktop_column_2'] = $input['desktop_column_2']; }
    if (isset($input['desktop_column_3'])) { $settings['desktop_column_3'] = $input['desktop_column_3']; }
    if (isset($input['desktop_column_4'])) { $settings['desktop_column_4'] = $input['desktop_column_4']; }
    if (isset($input['desktop_column_5'])) { $settings['desktop_column_5'] = $input['desktop_column_5']; }
    if (isset($input['desktop_column_6'])) { $settings['desktop_column_6'] = $input['desktop_column_6']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
