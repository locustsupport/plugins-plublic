<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-tabs-tours', [
'label' => __('Tabs Tours (Pro)', 'theplus'),
    'description' => __('Adds The Plus "Tabs Tours" widget (tp-tabs-tours) to an Elementor container. Pro version with extra layout styles.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'     => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'   => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'    => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'tabs_type' => ['type' => 'string', 'description' => 'Layout', 'enum' => ['columns', 'horizontal', 'prefix_class', 'vertical']],
        'nav_align' => ['type' => 'string', 'description' => 'Alignment', 'enum' => ['icon', 'text-center', 'text-left', 'text-right']],
        'tabs_align_horizontal' => ['type' => 'string', 'description' => 'Position', 'enum' => ['bottom', 'icon', 'tabs_type', 'top']],
        'tabs_align_vertical' => ['type' => 'string', 'description' => 'tabs_align_vertical', 'enum' => ['icon', 'left', 'right', 'tabs_type']],
        'tab_title' => ['type' => 'string', 'description' => 'Title'],
        'content_source' => ['type' => 'string', 'description' => 'Type', 'enum' => ['content', 'page_template']],
        'tab_content' => ['type' => 'string', 'description' => 'Content'],
        'content_template_type' => ['type' => 'string', 'description' => 'content_template_type', 'enum' => ['content_source', 'dropdown', 'manually']],
        'content_template' => ['type' => 'string', 'description' => 'Templates', 'enum' => ['content_source', 'content_template_type', 'show_label']],
        'content_template_id' => ['type' => 'string', 'description' => 'Elementor Templates Shortcode'],
        'backend_preview_template' => ['type' => 'string', 'description' => 'Backend Visibility', 'enum' => ['yes', 'no']],
        'backend_Note' => ['type' => 'string', 'description' => 'backend_Note'],
        'tab_title_description' => ['type' => 'string', 'description' => 'Description'],
        'tab_title_hint' => ['type' => 'string', 'description' => 'Hint'],
        'display_icon' => ['type' => 'string', 'description' => 'display_icon', 'enum' => ['yes', 'no']],
        'icon_style' => ['type' => 'string', 'description' => 'Icon Type', 'enum' => ['display_icon', 'font_awesome', 'font_awesome_5', 'icon_mind']],
        'icon_fs_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome'],
        'icon_fontawesome' => ['type' => 'string', 'description' => 'Select Icon'],
        'icon_f5_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome 5'],
        'icon_fontawesome_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'icon_mind_popover_toggle' => ['type' => 'string', 'description' => 'Icons Mind'],
        'icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['display_icon', 'icon_style']],
        'image_popover_toggle' => ['type' => 'string', 'description' => 'Image'],
        'icon_image' => ['type' => 'integer', 'description' => 'Icon Image (Image ID)'],
        'display_icon1' => ['type' => 'string', 'description' => 'display_icon1', 'enum' => ['yes', 'no']],
        'icon_fontawesome_type' => ['type' => 'string', 'description' => 'Icon Type', 'enum' => ['display_icon1', 'font_awesome', 'font_awesome_5']],
        'fs_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome'],
        'icon_fontawesome1' => ['type' => 'string', 'description' => 'Select Icon'],
        'f5_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome 5'],
        'icon_fontawesome1_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'tab_hashid' => ['type' => 'string', 'description' => 'tab_hashid'],
        'tabs' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'tabs'],
        'on_hover_tabs' => ['type' => 'string', 'description' => 'On Hover Tab', 'enum' => ['yes', 'no']],
        'second_click_close' => ['type' => 'string', 'description' => 'Second Click Closed', 'enum' => ['yes', 'no']],
        'on_tabs_arrow' => ['type' => 'string', 'description' => 'Arrow', 'enum' => ['yes', 'no']],
        'on_tabs_arrow_type' => ['type' => 'string', 'description' => 'Type', 'enum' => ['icon', 'left', 'on_tabs_arrow', 'right', 'toggle']],
        'autoplay_popover_toggle' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'tabs_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'tabs_autoplaypause' => ['type' => 'string', 'description' => 'Play/Pause Button', 'enum' => ['yes', 'no']],
        'autoplayicon' => ['type' => 'string', 'description' => 'Play Icon'],
        'autopauseicon' => ['type' => 'string', 'description' => 'Pause Icon'],
        'tabs_autoplay_duration' => ['type' => 'object', 'description' => 'Duration'],
        'tabs_autoplay_border_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'tabs_autoplay_border_size' => ['type' => 'object', 'description' => 'Border Size'],
        'default_active_tab' => ['type' => 'string', 'description' => 'Active Tab'],
        'tabs_swiper' => ['type' => 'string', 'description' => 'tabs_swiper', 'enum' => ['yes', 'no']],
        'tabs_mode' => ['type' => 'string', 'description' => 'Mode', 'enum' => ['slide', 'swipe', 'tabs_swiper', 'tabs_type']],
        'swiper_loop' => ['type' => 'string', 'description' => 'Loop', 'enum' => ['yes', 'no']],
        'swiper_centermode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'tab_columns_popover_toggle' => ['type' => 'string', 'description' => 'Tab Columns'],
        'tabs_columns' => ['type' => 'string', 'description' => 'Tab Columns', 'enum' => ['yes', 'no']],
        'tabs_columns_no' => ['type' => 'object', 'description' => 'Column', 'enum' => ['1', '2', '3', '4', '5', '6', 'tabs_columns', '{{WRAPPER}} .theplus-tabs-wrapper ul.plus-tabs-nav li']],
        'tabs_columns_padding' => ['type' => 'object', 'description' => 'Column Padding (Dimensions Object)'],
        'connection_unique_id' => ['type' => 'string', 'description' => 'Carousel Connection ID'],
        'icon_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'icon_space' => ['type' => 'object', 'description' => 'Spacing (Slider/Size Object)'],
        'icon_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'icon_active_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'full_icon' => ['type' => 'string', 'description' => 'Full Width Icon', 'enum' => ['yes', 'no']],
        'icon_o_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'outer_space' => ['type' => 'object', 'description' => 'Spacing (Slider/Size Object)'],
        'res_outer_icon' => ['type' => 'object', 'description' => 'Hide Outer Icon', 'enum' => ['yes', 'no']],
        'icon_o_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'icon_o_ah_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'nav_vertical_width' => ['type' => 'object', 'description' => 'Navigation Width (Slider/Size Object)'],
        'nav_vertical_titlewidth' => ['type' => 'object', 'description' => 'Navigation Title Width (Slider/Size Object)'],
        'nav_vertical_align' => ['type' => 'string', 'description' => 'Vertical Alignment', 'enum' => ['align-bottom', 'align-center', 'align-top', 'icon', 'tabs_type']],
        'nav_full_width' => ['type' => 'string', 'description' => 'Nav Full-Width', 'enum' => ['yes', 'no']],
        'nav_title_display' => ['type' => 'string', 'description' => 'Title On/Off', 'enum' => ['yes', 'no']],
        'nav_same_width' => ['type' => 'string', 'description' => 'Nav Equal Width', 'enum' => ['yes', 'no']],
        'nav_same_width_size' => ['type' => 'object', 'description' => 'Width Size (Slider/Size Object)'],
        'title_color_option' => ['type' => 'string', 'description' => 'Color', 'enum' => ['gradient', 'icon', 'solid']],
        'title_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'title_gradient_color1' => ['type' => 'string', 'description' => 'Color 1 (Color Hex/RGBA)'],
        'title_gradient_color1_control' => ['type' => 'object', 'description' => 'Color 1 Location (Slider/Size Object)'],
        'title_gradient_color2' => ['type' => 'string', 'description' => 'Color 2 (Color Hex/RGBA)'],
        'title_gradient_color2_control' => ['type' => 'object', 'description' => 'Color 2 Location (Slider/Size Object)'],
        'title_gradient_style' => ['type' => 'string', 'description' => 'Gradient Style', 'enum' => ['of_type', 'title_color_option']],
        'title_gradient_angle' => ['type' => 'object', 'description' => 'Gradient Angle (Slider/Size Object)'],
        'title_gradient_position' => ['type' => 'string', 'description' => 'Position', 'enum' => ['of_type', 'title_color_option', 'title_gradient_style', '{{WRAPPER}} .theplus-tabs-wrapper .plus-tabs-nav .plus-tab-header span:not(.tab-icon-wrap),{{WRAPPER}} .theplus-tabs-wrapper.mobile-accordion .elementor-tab-mobile-title span:not(.tab-icon-wrap)']],
        'title_active_color_option' => ['type' => 'string', 'description' => 'Color', 'enum' => ['gradient', 'icon', 'solid']],
        'title_active_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'title_active_gradient_color1' => ['type' => 'string', 'description' => 'Color 1 (Color Hex/RGBA)'],
        'title_active_gradient_color1_control' => ['type' => 'object', 'description' => 'Color 1 Location (Slider/Size Object)'],
        'title_active_gradient_color2' => ['type' => 'string', 'description' => 'Color 2 (Color Hex/RGBA)'],
        'title_active_gradient_color2_control' => ['type' => 'object', 'description' => 'Color 2 Location (Slider/Size Object)'],
        'title_active_gradient_style' => ['type' => 'string', 'description' => 'Gradient Style', 'enum' => ['of_type', 'title_active_color_option']],
        'title_active_gradient_angle' => ['type' => 'object', 'description' => 'Gradient Angle (Slider/Size Object)'],
        'title_active_gradient_position' => ['type' => 'string', 'description' => 'Position', 'enum' => ['of_type', 'title_active_color_option', 'title_active_gradient_style', '{{WRAPPER}} .theplus-tabs-wrapper .plus-tabs-nav .plus-tab-header:hover span:not(.tab-icon-wrap),{{WRAPPER}} .theplus-tabs-wrapper .plus-tabs-nav .plus-tab-header.active span:not(.tab-icon-wrap),{{WRAPPER}} .theplus-tabs-wrapper.mobile-accordion .elementor-tab-mobile-title.active span:not(.tab-icon-wrap)']],
        'title_desc_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'title_desc_max_width' => ['type' => 'object', 'description' => 'Max. Width (Slider/Size Object)'],
        'title_desc_word_break' => ['type' => 'string', 'description' => 'Word Break', 'enum' => ['break-all', 'break-word', 'keep-all', '{{WRAPPER}} .tp-tab-title-description']],
        'title_desc_color_n' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'title_desc_color_a' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'title_hint_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'title_hint_position' => ['type' => 'string', 'description' => 'Position', 'enum' => ['tp_hint_pos_left', 'tp_hint_pos_right']],
        'title_hint_position_top' => ['type' => 'object', 'description' => 'Top (Slider/Size Object)'],
        'title_hint_position_left' => ['type' => 'object', 'description' => 'Left (Slider/Size Object)'],
        'title_hint_position_right' => ['type' => 'object', 'description' => 'Right (Slider/Size Object)'],
        'title_hint_arrow_offset' => ['type' => 'object', 'description' => 'Arrow Offset (Slider/Size Object)'],
        'title_hint_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'title_hint_arrow_color' => ['type' => 'string', 'description' => 'Arrow (Color Hex/RGBA)'],
        'title_hint_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'title_hint_color_a' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'title_hint_arrow_color_a' => ['type' => 'string', 'description' => 'Arrow (Color Hex/RGBA)'],
        'title_hint_br_a' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'tab_title_underline_display' => ['type' => 'string', 'description' => 'Underline', 'enum' => ['yes', 'no']],
        'underline_color' => ['type' => 'string', 'description' => 'Underline Color (Color Hex/RGBA)'],
        'underline_top_margin' => ['type' => 'object', 'description' => 'Top Margin (Slider/Size Object)'],
        'underline_width' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'underline_height' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'nav_inner_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'nav_inner_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'nav_title_space' => ['type' => 'object', 'description' => 'Space Between Navigation (Slider/Size Object)'],
        'nav_box_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'nav_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['nav_box_border', '{{WRAPPER}} .theplus-tabs-wrapper .plus-tabs-nav .plus-tab-header']],
        'nav_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'nav_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'nav_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'nav_border_active_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'nav_border_active_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'nav_box_bf' => ['type' => 'string', 'description' => 'Backdrop Filter', 'enum' => ['yes', 'no']],
        'nav_box_bf_blur' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'nav_box_bf_grayscale' => ['type' => 'object', 'description' => 'Grayscale (Slider/Size Object)'],
        'nav_bg_box_overflow' => ['type' => 'string', 'description' => 'Overflow', 'enum' => ['yes', 'no']],
        'arrow_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'arrow_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'arrow_offset_v_right' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'arrow_offset_v_left' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'arrow_offset_h_top' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'arrow_offset_h_bottom' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'arrow_offset_v_right_in' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'arrow_offset_v_left_in' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'arrow_offset_h_to_in' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'arrow_offset_h_bottom_in' => ['type' => 'object', 'description' => 'Offset (Slider/Size Object)'],
        'nav_bg_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'nav_bg_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'nav_bg_box_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'nav_bg_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['nav_bg_box_border', '{{WRAPPER}} .theplus-tabs-wrapper .theplus-tabs-nav-wrapper .plus-tabs-nav']],
        'nav_bg_box_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'nav_bg_box_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'nav_bg_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'nav_bg_box_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'nav_bg_border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'nav_bg_box_bf' => ['type' => 'string', 'description' => 'Backdrop Filter', 'enum' => ['yes', 'no']],
        'nav_bg_box_bf_blur' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'nav_bg_box_bf_grayscale' => ['type' => 'object', 'description' => 'Grayscale (Slider/Size Object)'],
        'swiper_next_icon' => ['type' => 'string', 'description' => 'Next Icon'],
        'swiper_prev_icon' => ['type' => 'string', 'description' => 'Previous Icon'],
        'swiper_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'swiper_bg_size' => ['type' => 'object', 'description' => 'Background Size (Slider/Size Object)'],
        'swiper_icon_disable_opacity' => ['type' => 'object', 'description' => 'Navigation Disabled Opacity (Slider/Size Object)'],
        'swiper_icon_color_n' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'swiper_icon_br_n' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'swiper_icon_color_h' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'swiper_icon_br_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'desc_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'section_desc_bg_styling' => ['type' => 'string', 'description' => 'Background'],
        'content_tab_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'content_tab_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'content_box_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'content_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['content_box_border', '{{WRAPPER}} .theplus-tabs-wrapper .theplus-tabs-content-wrapper']],
        'content_box_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'content_box_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'content_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'content_box_border_h' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'content_border_style_h' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['content_box_border_h', '{{WRAPPER}} .theplus-tabs-wrapper .theplus-tabs-content-wrapper:hover']],
        'content_box_border_width_h' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'content_box_border_color_h' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'content_border_radius_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'content_box_bf' => ['type' => 'string', 'description' => 'Backdrop Filter', 'enum' => ['yes', 'no']],
        'content_box_bf_blur' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'content_box_bf_grayscale' => ['type' => 'object', 'description' => 'Grayscale (Slider/Size Object)'],
        'nav_tab_opacity' => ['type' => 'object', 'description' => 'Navigation Opacity (Slider/Size Object)'],
        'nav_tab_scale' => ['type' => 'object', 'description' => 'Navigation Scale/Zoom (Slider/Size Object)'],
        'nav_tab_opacity_active' => ['type' => 'object', 'description' => 'Navigation Active Opacity (Slider/Size Object)'],
        'nav_tab_scale_active' => ['type' => 'object', 'description' => 'Navigation Active Scale/Zoom (Slider/Size Object)'],
        'tab_nav_responsive' => ['type' => 'string', 'description' => 'Tab Navigation Responsive', 'enum' => ['nav_full', 'nav_one', 'tab_accordion']],
        'responsive_note' => ['type' => 'string', 'description' => 'responsive_note'],
        'tab_accordion_options' => ['type' => 'string', 'description' => 'Accordion Navigation Options'],
        'nav_vertical_title_space' => ['type' => 'object', 'description' => 'Space Between Navigation (Slider/Size Object)'],
        'accordion_box_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'accordion_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['accordion_box_border', 'tab_nav_responsive', '{{WRAPPER}} .theplus-tabs-wrapper.mobile-accordion .elementor-tab-mobile-title']],
        'accordion_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'accordion_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'accordion_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'accordion_border_active_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'accordion_border_active_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'fat_tablet' => ['type' => 'string', 'description' => 'First Tab Active in Tablet', 'enum' => ['yes', 'no']],
        'fat_mobile' => ['type' => 'string', 'description' => 'First Tab Active in Mobile', 'enum' => ['yes', 'no']],
        'fat_close_tablet' => ['type' => 'string', 'description' => 'Force All Close in Tablet', 'enum' => ['yes', 'no']],
        'fat_close_mobile' => ['type' => 'string', 'description' => 'Force All Close in Mobile', 'enum' => ['yes', 'no']],
        'description_field_show' => ['type' => 'string', 'description' => 'Description Field Show on Active Tab', 'enum' => ['yes', 'no']],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports SVG icon transitions, nested template integration, and responsive accordion fallbacks.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_pro_tabs_tours_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pro_tabs_tours_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_pro_tabs_tours_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_pro_tabs_tours_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-tabs-tours';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Tabs Tours widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['tabs_type'])) { $settings['tabs_type'] = sanitize_text_field($input['tabs_type']); }
    if (isset($input['nav_align'])) { $settings['nav_align'] = sanitize_text_field($input['nav_align']); }
    if (isset($input['tabs_align_horizontal'])) { $settings['tabs_align_horizontal'] = sanitize_text_field($input['tabs_align_horizontal']); }
    if (isset($input['tabs_align_vertical'])) { $settings['tabs_align_vertical'] = sanitize_text_field($input['tabs_align_vertical']); }
    if (isset($input['tab_title'])) { $settings['tab_title'] = sanitize_text_field($input['tab_title']); }
    if (isset($input['content_source'])) { $settings['content_source'] = sanitize_text_field($input['content_source']); }
    if (isset($input['tab_content'])) { $settings['tab_content'] = sanitize_text_field($input['tab_content']); }
    if (isset($input['content_template_type'])) { $settings['content_template_type'] = sanitize_text_field($input['content_template_type']); }
    if (isset($input['content_template'])) { $settings['content_template'] = sanitize_text_field($input['content_template']); }
    if (isset($input['content_template_id'])) { $settings['content_template_id'] = sanitize_text_field($input['content_template_id']); }
    if (isset($input['backend_preview_template'])) { $settings['backend_preview_template'] = sanitize_text_field($input['backend_preview_template']); }
    if (isset($input['backend_Note'])) { $settings['backend_Note'] = sanitize_text_field($input['backend_Note']); }
    if (isset($input['tab_title_description'])) { $settings['tab_title_description'] = sanitize_text_field($input['tab_title_description']); }
    if (isset($input['tab_title_hint'])) { $settings['tab_title_hint'] = sanitize_text_field($input['tab_title_hint']); }
    if (isset($input['display_icon'])) { $settings['display_icon'] = sanitize_text_field($input['display_icon']); }
    if (isset($input['icon_style'])) { $settings['icon_style'] = sanitize_text_field($input['icon_style']); }
    if (isset($input['icon_fs_popover_toggle'])) { $settings['icon_fs_popover_toggle'] = sanitize_text_field($input['icon_fs_popover_toggle']); }
    if (isset($input['icon_fontawesome'])) { $settings['icon_fontawesome'] = sanitize_text_field($input['icon_fontawesome']); }
    if (isset($input['icon_f5_popover_toggle'])) { $settings['icon_f5_popover_toggle'] = sanitize_text_field($input['icon_f5_popover_toggle']); }
    if (isset($input['icon_fontawesome_5'])) { $settings['icon_fontawesome_5'] = sanitize_text_field($input['icon_fontawesome_5']); }
    if (isset($input['icon_mind_popover_toggle'])) { $settings['icon_mind_popover_toggle'] = sanitize_text_field($input['icon_mind_popover_toggle']); }
    if (isset($input['icons_mind'])) { $settings['icons_mind'] = sanitize_text_field($input['icons_mind']); }
    if (isset($input['image_popover_toggle'])) { $settings['image_popover_toggle'] = sanitize_text_field($input['image_popover_toggle']); }
    if (!empty($input['icon_image'])) { $settings['icon_image'] = ['id' => absint($input['icon_image'])]; }
    if (isset($input['display_icon1'])) { $settings['display_icon1'] = sanitize_text_field($input['display_icon1']); }
    if (isset($input['icon_fontawesome_type'])) { $settings['icon_fontawesome_type'] = sanitize_text_field($input['icon_fontawesome_type']); }
    if (isset($input['fs_popover_toggle'])) { $settings['fs_popover_toggle'] = sanitize_text_field($input['fs_popover_toggle']); }
    if (isset($input['icon_fontawesome1'])) { $settings['icon_fontawesome1'] = sanitize_text_field($input['icon_fontawesome1']); }
    if (isset($input['f5_popover_toggle'])) { $settings['f5_popover_toggle'] = sanitize_text_field($input['f5_popover_toggle']); }
    if (isset($input['icon_fontawesome1_5'])) { $settings['icon_fontawesome1_5'] = sanitize_text_field($input['icon_fontawesome1_5']); }
    if (isset($input['tab_hashid'])) { $settings['tab_hashid'] = sanitize_text_field($input['tab_hashid']); }
    if (isset($input['tabs'])) { $settings['tabs'] = $input['tabs']; }
    if (isset($input['on_hover_tabs'])) { $settings['on_hover_tabs'] = sanitize_text_field($input['on_hover_tabs']); }
    if (isset($input['second_click_close'])) { $settings['second_click_close'] = sanitize_text_field($input['second_click_close']); }
    if (isset($input['on_tabs_arrow'])) { $settings['on_tabs_arrow'] = sanitize_text_field($input['on_tabs_arrow']); }
    if (isset($input['on_tabs_arrow_type'])) { $settings['on_tabs_arrow_type'] = sanitize_text_field($input['on_tabs_arrow_type']); }
    if (isset($input['autoplay_popover_toggle'])) { $settings['autoplay_popover_toggle'] = sanitize_text_field($input['autoplay_popover_toggle']); }
    if (isset($input['tabs_autoplay'])) { $settings['tabs_autoplay'] = sanitize_text_field($input['tabs_autoplay']); }
    if (isset($input['tabs_autoplaypause'])) { $settings['tabs_autoplaypause'] = sanitize_text_field($input['tabs_autoplaypause']); }
    if (isset($input['autoplayicon'])) { $settings['autoplayicon'] = sanitize_text_field($input['autoplayicon']); }
    if (isset($input['autopauseicon'])) { $settings['autopauseicon'] = sanitize_text_field($input['autopauseicon']); }
    if (isset($input['tabs_autoplay_duration'])) { $settings['tabs_autoplay_duration'] = $input['tabs_autoplay_duration']; }
    if (isset($input['tabs_autoplay_border_color'])) { $settings['tabs_autoplay_border_color'] = sanitize_text_field($input['tabs_autoplay_border_color']); }
    if (isset($input['tabs_autoplay_border_size'])) { $settings['tabs_autoplay_border_size'] = $input['tabs_autoplay_border_size']; }
    if (isset($input['default_active_tab'])) { $settings['default_active_tab'] = sanitize_text_field($input['default_active_tab']); }
    if (isset($input['tabs_swiper'])) { $settings['tabs_swiper'] = sanitize_text_field($input['tabs_swiper']); }
    if (isset($input['tabs_mode'])) { $settings['tabs_mode'] = sanitize_text_field($input['tabs_mode']); }
    if (isset($input['swiper_loop'])) { $settings['swiper_loop'] = sanitize_text_field($input['swiper_loop']); }
    if (isset($input['swiper_centermode'])) { $settings['swiper_centermode'] = sanitize_text_field($input['swiper_centermode']); }
    if (isset($input['tab_columns_popover_toggle'])) { $settings['tab_columns_popover_toggle'] = sanitize_text_field($input['tab_columns_popover_toggle']); }
    if (isset($input['tabs_columns'])) { $settings['tabs_columns'] = sanitize_text_field($input['tabs_columns']); }
    if (isset($input['tabs_columns_no'])) { $settings['tabs_columns_no'] = $input['tabs_columns_no']; }
    if (isset($input['tabs_columns_padding'])) { $settings['tabs_columns_padding'] = $input['tabs_columns_padding']; }
    if (isset($input['connection_unique_id'])) { $settings['connection_unique_id'] = sanitize_text_field($input['connection_unique_id']); }
    if (isset($input['icon_size'])) { $settings['icon_size'] = $input['icon_size']; }
    if (isset($input['icon_space'])) { $settings['icon_space'] = $input['icon_space']; }
    if (isset($input['icon_color'])) { $settings['icon_color'] = sanitize_text_field($input['icon_color']); }
    if (isset($input['icon_active_color'])) { $settings['icon_active_color'] = sanitize_text_field($input['icon_active_color']); }
    if (isset($input['full_icon'])) { $settings['full_icon'] = sanitize_text_field($input['full_icon']); }
    if (isset($input['icon_o_size'])) { $settings['icon_o_size'] = $input['icon_o_size']; }
    if (isset($input['outer_space'])) { $settings['outer_space'] = $input['outer_space']; }
    if (isset($input['res_outer_icon'])) { $settings['res_outer_icon'] = $input['res_outer_icon']; }
    if (isset($input['icon_o_color'])) { $settings['icon_o_color'] = sanitize_text_field($input['icon_o_color']); }
    if (isset($input['icon_o_ah_color'])) { $settings['icon_o_ah_color'] = sanitize_text_field($input['icon_o_ah_color']); }
    if (isset($input['nav_vertical_width'])) { $settings['nav_vertical_width'] = $input['nav_vertical_width']; }
    if (isset($input['nav_vertical_titlewidth'])) { $settings['nav_vertical_titlewidth'] = $input['nav_vertical_titlewidth']; }
    if (isset($input['nav_vertical_align'])) { $settings['nav_vertical_align'] = sanitize_text_field($input['nav_vertical_align']); }
    if (isset($input['nav_full_width'])) { $settings['nav_full_width'] = sanitize_text_field($input['nav_full_width']); }
    if (isset($input['nav_title_display'])) { $settings['nav_title_display'] = sanitize_text_field($input['nav_title_display']); }
    if (isset($input['nav_same_width'])) { $settings['nav_same_width'] = sanitize_text_field($input['nav_same_width']); }
    if (isset($input['nav_same_width_size'])) { $settings['nav_same_width_size'] = $input['nav_same_width_size']; }
    if (isset($input['title_color_option'])) { $settings['title_color_option'] = sanitize_text_field($input['title_color_option']); }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['title_gradient_color1'])) { $settings['title_gradient_color1'] = sanitize_text_field($input['title_gradient_color1']); }
    if (isset($input['title_gradient_color1_control'])) { $settings['title_gradient_color1_control'] = $input['title_gradient_color1_control']; }
    if (isset($input['title_gradient_color2'])) { $settings['title_gradient_color2'] = sanitize_text_field($input['title_gradient_color2']); }
    if (isset($input['title_gradient_color2_control'])) { $settings['title_gradient_color2_control'] = $input['title_gradient_color2_control']; }
    if (isset($input['title_gradient_style'])) { $settings['title_gradient_style'] = sanitize_text_field($input['title_gradient_style']); }
    if (isset($input['title_gradient_angle'])) { $settings['title_gradient_angle'] = $input['title_gradient_angle']; }
    if (isset($input['title_gradient_position'])) { $settings['title_gradient_position'] = sanitize_text_field($input['title_gradient_position']); }
    if (isset($input['title_active_color_option'])) { $settings['title_active_color_option'] = sanitize_text_field($input['title_active_color_option']); }
    if (isset($input['title_active_color'])) { $settings['title_active_color'] = sanitize_text_field($input['title_active_color']); }
    if (isset($input['title_active_gradient_color1'])) { $settings['title_active_gradient_color1'] = sanitize_text_field($input['title_active_gradient_color1']); }
    if (isset($input['title_active_gradient_color1_control'])) { $settings['title_active_gradient_color1_control'] = $input['title_active_gradient_color1_control']; }
    if (isset($input['title_active_gradient_color2'])) { $settings['title_active_gradient_color2'] = sanitize_text_field($input['title_active_gradient_color2']); }
    if (isset($input['title_active_gradient_color2_control'])) { $settings['title_active_gradient_color2_control'] = $input['title_active_gradient_color2_control']; }
    if (isset($input['title_active_gradient_style'])) { $settings['title_active_gradient_style'] = sanitize_text_field($input['title_active_gradient_style']); }
    if (isset($input['title_active_gradient_angle'])) { $settings['title_active_gradient_angle'] = $input['title_active_gradient_angle']; }
    if (isset($input['title_active_gradient_position'])) { $settings['title_active_gradient_position'] = sanitize_text_field($input['title_active_gradient_position']); }
    if (isset($input['title_desc_margin'])) { $settings['title_desc_margin'] = $input['title_desc_margin']; }
    if (isset($input['title_desc_max_width'])) { $settings['title_desc_max_width'] = $input['title_desc_max_width']; }
    if (isset($input['title_desc_word_break'])) { $settings['title_desc_word_break'] = sanitize_text_field($input['title_desc_word_break']); }
    if (isset($input['title_desc_color_n'])) { $settings['title_desc_color_n'] = sanitize_text_field($input['title_desc_color_n']); }
    if (isset($input['title_desc_color_a'])) { $settings['title_desc_color_a'] = sanitize_text_field($input['title_desc_color_a']); }
    if (isset($input['title_hint_padding'])) { $settings['title_hint_padding'] = $input['title_hint_padding']; }
    if (isset($input['title_hint_position'])) { $settings['title_hint_position'] = sanitize_text_field($input['title_hint_position']); }
    if (isset($input['title_hint_position_top'])) { $settings['title_hint_position_top'] = $input['title_hint_position_top']; }
    if (isset($input['title_hint_position_left'])) { $settings['title_hint_position_left'] = $input['title_hint_position_left']; }
    if (isset($input['title_hint_position_right'])) { $settings['title_hint_position_right'] = $input['title_hint_position_right']; }
    if (isset($input['title_hint_arrow_offset'])) { $settings['title_hint_arrow_offset'] = $input['title_hint_arrow_offset']; }
    if (isset($input['title_hint_color'])) { $settings['title_hint_color'] = sanitize_text_field($input['title_hint_color']); }
    if (isset($input['title_hint_arrow_color'])) { $settings['title_hint_arrow_color'] = sanitize_text_field($input['title_hint_arrow_color']); }
    if (isset($input['title_hint_br'])) { $settings['title_hint_br'] = $input['title_hint_br']; }
    if (isset($input['title_hint_color_a'])) { $settings['title_hint_color_a'] = sanitize_text_field($input['title_hint_color_a']); }
    if (isset($input['title_hint_arrow_color_a'])) { $settings['title_hint_arrow_color_a'] = sanitize_text_field($input['title_hint_arrow_color_a']); }
    if (isset($input['title_hint_br_a'])) { $settings['title_hint_br_a'] = $input['title_hint_br_a']; }
    if (isset($input['tab_title_underline_display'])) { $settings['tab_title_underline_display'] = sanitize_text_field($input['tab_title_underline_display']); }
    if (isset($input['underline_color'])) { $settings['underline_color'] = sanitize_text_field($input['underline_color']); }
    if (isset($input['underline_top_margin'])) { $settings['underline_top_margin'] = $input['underline_top_margin']; }
    if (isset($input['underline_width'])) { $settings['underline_width'] = $input['underline_width']; }
    if (isset($input['underline_height'])) { $settings['underline_height'] = $input['underline_height']; }
    if (isset($input['nav_inner_padding'])) { $settings['nav_inner_padding'] = $input['nav_inner_padding']; }
    if (isset($input['nav_inner_margin'])) { $settings['nav_inner_margin'] = $input['nav_inner_margin']; }
    if (isset($input['nav_title_space'])) { $settings['nav_title_space'] = $input['nav_title_space']; }
    if (isset($input['nav_box_border'])) { $settings['nav_box_border'] = sanitize_text_field($input['nav_box_border']); }
    if (isset($input['nav_border_style'])) { $settings['nav_border_style'] = sanitize_text_field($input['nav_border_style']); }
    if (isset($input['nav_border_width'])) { $settings['nav_border_width'] = $input['nav_border_width']; }
    if (isset($input['nav_border_color'])) { $settings['nav_border_color'] = sanitize_text_field($input['nav_border_color']); }
    if (isset($input['nav_border_radius'])) { $settings['nav_border_radius'] = $input['nav_border_radius']; }
    if (isset($input['nav_border_active_color'])) { $settings['nav_border_active_color'] = sanitize_text_field($input['nav_border_active_color']); }
    if (isset($input['nav_border_active_radius'])) { $settings['nav_border_active_radius'] = $input['nav_border_active_radius']; }
    if (isset($input['nav_box_bf'])) { $settings['nav_box_bf'] = sanitize_text_field($input['nav_box_bf']); }
    if (isset($input['nav_box_bf_blur'])) { $settings['nav_box_bf_blur'] = $input['nav_box_bf_blur']; }
    if (isset($input['nav_box_bf_grayscale'])) { $settings['nav_box_bf_grayscale'] = $input['nav_box_bf_grayscale']; }
    if (isset($input['nav_bg_box_overflow'])) { $settings['nav_bg_box_overflow'] = sanitize_text_field($input['nav_bg_box_overflow']); }
    if (isset($input['arrow_size'])) { $settings['arrow_size'] = $input['arrow_size']; }
    if (isset($input['arrow_color'])) { $settings['arrow_color'] = sanitize_text_field($input['arrow_color']); }
    if (isset($input['arrow_offset_v_right'])) { $settings['arrow_offset_v_right'] = $input['arrow_offset_v_right']; }
    if (isset($input['arrow_offset_v_left'])) { $settings['arrow_offset_v_left'] = $input['arrow_offset_v_left']; }
    if (isset($input['arrow_offset_h_top'])) { $settings['arrow_offset_h_top'] = $input['arrow_offset_h_top']; }
    if (isset($input['arrow_offset_h_bottom'])) { $settings['arrow_offset_h_bottom'] = $input['arrow_offset_h_bottom']; }
    if (isset($input['arrow_offset_v_right_in'])) { $settings['arrow_offset_v_right_in'] = $input['arrow_offset_v_right_in']; }
    if (isset($input['arrow_offset_v_left_in'])) { $settings['arrow_offset_v_left_in'] = $input['arrow_offset_v_left_in']; }
    if (isset($input['arrow_offset_h_to_in'])) { $settings['arrow_offset_h_to_in'] = $input['arrow_offset_h_to_in']; }
    if (isset($input['arrow_offset_h_bottom_in'])) { $settings['arrow_offset_h_bottom_in'] = $input['arrow_offset_h_bottom_in']; }
    if (isset($input['nav_bg_padding'])) { $settings['nav_bg_padding'] = $input['nav_bg_padding']; }
    if (isset($input['nav_bg_margin'])) { $settings['nav_bg_margin'] = $input['nav_bg_margin']; }
    if (isset($input['nav_bg_box_border'])) { $settings['nav_bg_box_border'] = sanitize_text_field($input['nav_bg_box_border']); }
    if (isset($input['nav_bg_border_style'])) { $settings['nav_bg_border_style'] = sanitize_text_field($input['nav_bg_border_style']); }
    if (isset($input['nav_bg_box_border_width'])) { $settings['nav_bg_box_border_width'] = $input['nav_bg_box_border_width']; }
    if (isset($input['nav_bg_box_border_color'])) { $settings['nav_bg_box_border_color'] = sanitize_text_field($input['nav_bg_box_border_color']); }
    if (isset($input['nav_bg_border_radius'])) { $settings['nav_bg_border_radius'] = $input['nav_bg_border_radius']; }
    if (isset($input['nav_bg_box_border_hover_color'])) { $settings['nav_bg_box_border_hover_color'] = sanitize_text_field($input['nav_bg_box_border_hover_color']); }
    if (isset($input['nav_bg_border_hover_radius'])) { $settings['nav_bg_border_hover_radius'] = $input['nav_bg_border_hover_radius']; }
    if (isset($input['nav_bg_box_bf'])) { $settings['nav_bg_box_bf'] = sanitize_text_field($input['nav_bg_box_bf']); }
    if (isset($input['nav_bg_box_bf_blur'])) { $settings['nav_bg_box_bf_blur'] = $input['nav_bg_box_bf_blur']; }
    if (isset($input['nav_bg_box_bf_grayscale'])) { $settings['nav_bg_box_bf_grayscale'] = $input['nav_bg_box_bf_grayscale']; }
    if (isset($input['swiper_next_icon'])) { $settings['swiper_next_icon'] = sanitize_text_field($input['swiper_next_icon']); }
    if (isset($input['swiper_prev_icon'])) { $settings['swiper_prev_icon'] = sanitize_text_field($input['swiper_prev_icon']); }
    if (isset($input['swiper_icon_size'])) { $settings['swiper_icon_size'] = $input['swiper_icon_size']; }
    if (isset($input['swiper_bg_size'])) { $settings['swiper_bg_size'] = $input['swiper_bg_size']; }
    if (isset($input['swiper_icon_disable_opacity'])) { $settings['swiper_icon_disable_opacity'] = $input['swiper_icon_disable_opacity']; }
    if (isset($input['swiper_icon_color_n'])) { $settings['swiper_icon_color_n'] = sanitize_text_field($input['swiper_icon_color_n']); }
    if (isset($input['swiper_icon_br_n'])) { $settings['swiper_icon_br_n'] = $input['swiper_icon_br_n']; }
    if (isset($input['swiper_icon_color_h'])) { $settings['swiper_icon_color_h'] = sanitize_text_field($input['swiper_icon_color_h']); }
    if (isset($input['swiper_icon_br_h'])) { $settings['swiper_icon_br_h'] = $input['swiper_icon_br_h']; }
    if (isset($input['desc_color'])) { $settings['desc_color'] = sanitize_text_field($input['desc_color']); }
    if (isset($input['section_desc_bg_styling'])) { $settings['section_desc_bg_styling'] = sanitize_text_field($input['section_desc_bg_styling']); }
    if (isset($input['content_tab_padding'])) { $settings['content_tab_padding'] = $input['content_tab_padding']; }
    if (isset($input['content_tab_margin'])) { $settings['content_tab_margin'] = $input['content_tab_margin']; }
    if (isset($input['content_box_border'])) { $settings['content_box_border'] = sanitize_text_field($input['content_box_border']); }
    if (isset($input['content_border_style'])) { $settings['content_border_style'] = sanitize_text_field($input['content_border_style']); }
    if (isset($input['content_box_border_width'])) { $settings['content_box_border_width'] = $input['content_box_border_width']; }
    if (isset($input['content_box_border_color'])) { $settings['content_box_border_color'] = sanitize_text_field($input['content_box_border_color']); }
    if (isset($input['content_border_radius'])) { $settings['content_border_radius'] = $input['content_border_radius']; }
    if (isset($input['content_box_border_h'])) { $settings['content_box_border_h'] = sanitize_text_field($input['content_box_border_h']); }
    if (isset($input['content_border_style_h'])) { $settings['content_border_style_h'] = sanitize_text_field($input['content_border_style_h']); }
    if (isset($input['content_box_border_width_h'])) { $settings['content_box_border_width_h'] = $input['content_box_border_width_h']; }
    if (isset($input['content_box_border_color_h'])) { $settings['content_box_border_color_h'] = sanitize_text_field($input['content_box_border_color_h']); }
    if (isset($input['content_border_radius_h'])) { $settings['content_border_radius_h'] = $input['content_border_radius_h']; }
    if (isset($input['content_box_bf'])) { $settings['content_box_bf'] = sanitize_text_field($input['content_box_bf']); }
    if (isset($input['content_box_bf_blur'])) { $settings['content_box_bf_blur'] = $input['content_box_bf_blur']; }
    if (isset($input['content_box_bf_grayscale'])) { $settings['content_box_bf_grayscale'] = $input['content_box_bf_grayscale']; }
    if (isset($input['nav_tab_opacity'])) { $settings['nav_tab_opacity'] = $input['nav_tab_opacity']; }
    if (isset($input['nav_tab_scale'])) { $settings['nav_tab_scale'] = $input['nav_tab_scale']; }
    if (isset($input['nav_tab_opacity_active'])) { $settings['nav_tab_opacity_active'] = $input['nav_tab_opacity_active']; }
    if (isset($input['nav_tab_scale_active'])) { $settings['nav_tab_scale_active'] = $input['nav_tab_scale_active']; }
    if (isset($input['tab_nav_responsive'])) { $settings['tab_nav_responsive'] = sanitize_text_field($input['tab_nav_responsive']); }
    if (isset($input['responsive_note'])) { $settings['responsive_note'] = sanitize_text_field($input['responsive_note']); }
    if (isset($input['tab_accordion_options'])) { $settings['tab_accordion_options'] = sanitize_text_field($input['tab_accordion_options']); }
    if (isset($input['nav_vertical_title_space'])) { $settings['nav_vertical_title_space'] = $input['nav_vertical_title_space']; }
    if (isset($input['accordion_box_border'])) { $settings['accordion_box_border'] = sanitize_text_field($input['accordion_box_border']); }
    if (isset($input['accordion_border_style'])) { $settings['accordion_border_style'] = sanitize_text_field($input['accordion_border_style']); }
    if (isset($input['accordion_border_width'])) { $settings['accordion_border_width'] = $input['accordion_border_width']; }
    if (isset($input['accordion_border_color'])) { $settings['accordion_border_color'] = sanitize_text_field($input['accordion_border_color']); }
    if (isset($input['accordion_border_radius'])) { $settings['accordion_border_radius'] = $input['accordion_border_radius']; }
    if (isset($input['accordion_border_active_color'])) { $settings['accordion_border_active_color'] = sanitize_text_field($input['accordion_border_active_color']); }
    if (isset($input['accordion_border_active_radius'])) { $settings['accordion_border_active_radius'] = $input['accordion_border_active_radius']; }
    if (isset($input['fat_tablet'])) { $settings['fat_tablet'] = sanitize_text_field($input['fat_tablet']); }
    if (isset($input['fat_mobile'])) { $settings['fat_mobile'] = sanitize_text_field($input['fat_mobile']); }
    if (isset($input['fat_close_tablet'])) { $settings['fat_close_tablet'] = sanitize_text_field($input['fat_close_tablet']); }
    if (isset($input['fat_close_mobile'])) { $settings['fat_close_mobile'] = sanitize_text_field($input['fat_close_mobile']); }
    if (isset($input['description_field_show'])) { $settings['description_field_show'] = sanitize_text_field($input['description_field_show']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
