<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-protected-content', [
'label' => __('Protected Content', 'theplus'),
    'description' => __('Adds The Plus "Protected Content" widget (tp-protected-content) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'content_type' => ['type' => 'string', 'description' => 'What to show when authorized', 'enum' => ['content', 'page_template', 'redirect']],
        'protected_content_field' => ['type' => 'string', 'description' => 'HTML content shown to authorized users'],
        'redirect_link' => ['type' => 'string', 'description' => 'URL to redirect unauthorized users'],
        'pc_protection_type' => ['type' => 'string', 'description' => 'Access control type', 'enum' => ['role', 'single_password', 'multi_password']],
        'protection_password' => ['type' => 'string', 'description' => 'Password when using single password mode'],
        'settings' => ['type' => 'object', 'description' => 'Raw Elementor control key/value pairs. Use tpae/tpae-widget-schema to discover keys.'],
    ], 'required' => ['post_id', 'parent_id', 'pc_protection_type'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_protected_content_ability',
    'permission_callback' => 'tpaep_mcp_theplus_protected_content_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_protected_content_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_protected_content_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-protected-content';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Protected Content widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (!empty($input['content_type'])) { $settings['content_type'] = sanitize_key($input['content_type']); }
    if (!empty($input['protected_content_field'])) { $settings['protected_content_field'] = wp_kses_post($input['protected_content_field']); }
    if (!empty($input['redirect_link'])) { $settings['redirect_link'] = ['url' => esc_url_raw($input['redirect_link'])]; }
    if (!empty($input['pc_protection_type'])) { $settings['pc_protection_type'] = sanitize_key($input['pc_protection_type']); }
    if (!empty($input['protection_password'])) { $settings['protection_password'] = sanitize_text_field($input['protection_password']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
