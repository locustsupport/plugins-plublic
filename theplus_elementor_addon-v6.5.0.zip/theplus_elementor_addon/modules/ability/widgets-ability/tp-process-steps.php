<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-process-steps', [
'label' => __('Process Steps', 'theplus'),
    'description' => __('Adds The Plus "Process Steps" widget (tp-process-steps) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'ps_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'style_1', 'style_2']],
        'pro_ste_display_counter' => ['type' => 'string', 'description' => 'Display Counter', 'enum' => ['yes', 'no']],
        'pro_ste_display_counter_style' => ['type' => 'string', 'description' => 'Counter Style', 'enum' => ['custom-text', 'decimal-leading-zero', 'lower-alpha', 'lower-greek', 'lower-roman', 'number-normal', 'pro_ste_display_counter', 'upper-alpha', 'upper-roman']],
        'pro_ste_display_special_bg' => ['type' => 'string', 'description' => 'Special Background', 'enum' => ['yes', 'no']],
        'pro_ste_display_info_box' => ['type' => 'string', 'description' => 'Normal Layout In Mobile', 'enum' => ['yes', 'no']],
        'img_st2_align' => ['type' => 'object', 'description' => 'Circle Alignment', 'enum' => ['center', 'flex-end', 'flex-start', 'icon', 'pro_ste_display_info_box', 'ps_style', '{{WRAPPER}} .tp-process-steps-widget.style_2.mobile .tp-process-steps-wrapper .tp-ps-left-imt']],
        'content_st2_align' => ['type' => 'object', 'description' => 'Content Alignment', 'enum' => ['center', 'icon', 'justify', 'left', 'pro_ste_display_info_box', 'ps_style', 'right', '{{WRAPPER}} .tp-process-steps-widget.style_2.mobile .tp-process-steps-wrapper .tp-ps-right-content']],
        'default_active' => ['type' => 'string', 'description' => 'Default Active', 'enum' => ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '50', 'custom']],
        'default_active_custom' => ['type' => 'string', 'description' => 'Custom'],
        'loop_title' => ['type' => 'string', 'description' => 'Title'],
        'loop_content_desc' => ['type' => 'string', 'description' => 'Description'],
        'loop_image_icon' => ['type' => 'string', 'description' => 'Select Icon', 'enum' => ['icon', 'lottie', 'text']],
        'lottieUrl' => ['type' => 'object', 'description' => 'Lottie URL'],
        'lottieWidth' => ['type' => 'object', 'description' => 'Lottie Width (Slider/Size Object)'],
        'lottieHeight' => ['type' => 'object', 'description' => 'Lottie Height (Slider/Size Object)'],
        'loop_select_image' => ['type' => 'integer', 'description' => 'Use Image As icon (Image ID)'],
        'loop_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['font_awesome', 'icon_mind', 'loop_image_icon']],
        'icon_fs_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome', 'enum' => ['yes', 'no']],
        'loop_icon_fontawesome' => ['type' => 'string', 'description' => 'Icon Library'],
        'icon_mind_popover_toggle' => ['type' => 'string', 'description' => 'Icons Mind', 'enum' => ['yes', 'no']],
        'loop_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['loop_icon_style', 'loop_image_icon']],
        'loop_select_text' => ['type' => 'string', 'description' => 'Text'],
        'loop_icn_link' => ['type' => 'string', 'description' => 'Icon Link', 'enum' => ['yes', 'no']],
        'loop_url_link' => ['type' => 'object', 'description' => 'Link'],
        'dis_counter_custom_text' => ['type' => 'string', 'description' => 'Custom Text'],
        'loop_content' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Process/Steps'],
        'connection_switch' => ['type' => 'string', 'description' => 'Carousel Anything Connection', 'enum' => ['yes', 'no']],
        'connection_unique_id' => ['type' => 'string', 'description' => 'Connection Carousel ID'],
        'connection_hover_click' => ['type' => 'string', 'description' => 'Effect on', 'enum' => ['con_pro_click', 'con_pro_hover', 'connection_switch']],
        'heading_tag' => ['type' => 'string', 'description' => 'Tag', 'enum' => ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']],
        'title_text_color_n' => ['type' => 'string', 'description' => 'Text Color Normal (Color Hex/RGBA)'],
        'title_text_color_h' => ['type' => 'string', 'description' => 'Text Color Hover (Color Hex/RGBA)'],
        'description_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'title_description_color_n' => ['type' => 'string', 'description' => 'Description Color Normal (Color Hex/RGBA)'],
        'title_description_color_h' => ['type' => 'string', 'description' => 'Description Color Hover (Color Hex/RGBA)'],
        'tab_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'tab_icon_color_n' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'tab_icon_color_h' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'tab_image_size' => ['type' => 'object', 'description' => 'Image Size (Slider/Size Object)'],
        'tab_image_border_radius_n' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'tab_text_color_n' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'tab_text_color_h' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'tab_bg_size' => ['type' => 'object', 'description' => 'Background Size (Slider/Size Object)'],
        'pro_ste_minimum_height' => ['type' => 'object', 'description' => 'Minimum Height of Content (Slider/Size Object)'],
        'tab_bg_border_radius_n' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'tab_bg_border_radius_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'transform_n' => ['type' => 'string', 'description' => 'Transform CSS'],
        'overlay_color_n' => ['type' => 'string', 'description' => 'Overlay Color (Color Hex/RGBA)'],
        'transform_h' => ['type' => 'string', 'description' => 'Transform CSS'],
        'overlay_color_h' => ['type' => 'string', 'description' => 'Overlay Color (Color Hex/RGBA)'],
        'tab_bg_bf' => ['type' => 'string', 'description' => 'Backdrop Filter', 'enum' => ['yes', 'no']],
        'tab_bg_bf_blur' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'tab_bg_bf_grayscale' => ['type' => 'object', 'description' => 'Grayscale (Slider/Size Object)'],
        'lottieWidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'lottieHeight' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'lottieSpeed' => ['type' => 'object', 'description' => 'Speed (Slider/Size Object)'],
        'lottieLoop' => ['type' => 'string', 'description' => 'Loop Animation', 'enum' => ['yes', 'no']],
        'lottiehover' => ['type' => 'string', 'description' => 'Hover Animation', 'enum' => ['yes', 'no']],
        'seprator_color_n' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'seprator_border_style_n' => ['type' => 'string', 'description' => 'Border Type', 'enum' => ['border_img_custom', 'dashed', 'dotted', 'groove', 'inset', 'outset', 'ridge', 'solid', '{{WRAPPER}} .tp-process-steps-widget.style_1 .tp-process-steps-wrapper .tp-ps-left-imt:after,
{{WRAPPER}} .tp-process-steps-widget.style_2 .tp-ps-left-imt:before,
{{WRAPPER}} .tp-process-steps-widget.style_2 .tp-process-steps-wrapper .tp-ps-left-imt:after']],
        'seprator_border_width_n' => ['type' => 'object', 'description' => 'Border Size (Slider/Size Object)'],
        'seprator_cusom_img' => ['type' => 'integer', 'description' => 'Separator/Line Image (Image ID)'],
        'seprator_main_top_offset' => ['type' => 'object', 'description' => 'Separator/Line Offset (Slider/Size Object)'],
        'seprator_main_size' => ['type' => 'object', 'description' => 'Separator/Line Size (Slider/Size Object)'],
        'seprator_img_height_width' => ['type' => 'object', 'description' => 'Image Maximum Size (Slider/Size Object)'],
        'seprator_cusom_img_button_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'seprator_color_h' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'display_counter_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'display_counter_left_offset' => ['type' => 'object', 'description' => 'Left Offset (Slider/Size Object)'],
        'display_counter_top_offset' => ['type' => 'object', 'description' => 'Top Offset (Slider/Size Object)'],
        'display_counter_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'display_counter_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'display_counter_color_h' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'display_counter_radius_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'content_bg_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'content_bg_margin_st2' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'content_bg_margin_right' => ['type' => 'object', 'description' => 'Left Content Right Margin (Slider/Size Object)'],
        'content_bg_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'content_bg_radius_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'content_bg_bf' => ['type' => 'string', 'description' => 'Backdrop Filter', 'enum' => ['yes', 'no']],
        'content_bg_bf_blur' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'content_bg_bf_grayscale' => ['type' => 'object', 'description' => 'Grayscale (Slider/Size Object)'],
        'Horizontal_bg_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'Horizontal_bg_margin_st22' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports SVG draw animations, multi-stop step colors, and responsive connector logic.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_pro_process_steps_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pro_process_steps_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_pro_process_steps_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_pro_process_steps_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-process-steps';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Process Steps widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['ps_style'])) { $settings['ps_style'] = sanitize_text_field($input['ps_style']); }
    if (isset($input['pro_ste_display_counter'])) { $settings['pro_ste_display_counter'] = sanitize_text_field($input['pro_ste_display_counter']); }
    if (isset($input['pro_ste_display_counter_style'])) { $settings['pro_ste_display_counter_style'] = sanitize_text_field($input['pro_ste_display_counter_style']); }
    if (isset($input['pro_ste_display_special_bg'])) { $settings['pro_ste_display_special_bg'] = sanitize_text_field($input['pro_ste_display_special_bg']); }
    if (isset($input['pro_ste_display_info_box'])) { $settings['pro_ste_display_info_box'] = sanitize_text_field($input['pro_ste_display_info_box']); }
    if (isset($input['img_st2_align'])) { $settings['img_st2_align'] = $input['img_st2_align']; }
    if (isset($input['content_st2_align'])) { $settings['content_st2_align'] = $input['content_st2_align']; }
    if (isset($input['default_active'])) { $settings['default_active'] = sanitize_text_field($input['default_active']); }
    if (isset($input['default_active_custom'])) { $settings['default_active_custom'] = sanitize_text_field($input['default_active_custom']); }
    if (isset($input['loop_title'])) { $settings['loop_title'] = sanitize_text_field($input['loop_title']); }
    if (isset($input['loop_content_desc'])) { $settings['loop_content_desc'] = sanitize_text_field($input['loop_content_desc']); }
    if (isset($input['loop_image_icon'])) { $settings['loop_image_icon'] = sanitize_text_field($input['loop_image_icon']); }
    if (isset($input['lottieUrl'])) { $settings['lottieUrl'] = $input['lottieUrl']; }
    if (isset($input['lottieWidth'])) { $settings['lottieWidth'] = $input['lottieWidth']; }
    if (isset($input['lottieHeight'])) { $settings['lottieHeight'] = $input['lottieHeight']; }
    if (!empty($input['loop_select_image'])) { $settings['loop_select_image'] = ['id' => absint($input['loop_select_image'])]; }
    if (isset($input['loop_icon_style'])) { $settings['loop_icon_style'] = sanitize_text_field($input['loop_icon_style']); }
    if (isset($input['icon_fs_popover_toggle'])) { $settings['icon_fs_popover_toggle'] = sanitize_text_field($input['icon_fs_popover_toggle']); }
    if (isset($input['loop_icon_fontawesome'])) { $settings['loop_icon_fontawesome'] = sanitize_text_field($input['loop_icon_fontawesome']); }
    if (isset($input['icon_mind_popover_toggle'])) { $settings['icon_mind_popover_toggle'] = sanitize_text_field($input['icon_mind_popover_toggle']); }
    if (isset($input['loop_icons_mind'])) { $settings['loop_icons_mind'] = sanitize_text_field($input['loop_icons_mind']); }
    if (isset($input['loop_select_text'])) { $settings['loop_select_text'] = sanitize_text_field($input['loop_select_text']); }
    if (isset($input['loop_icn_link'])) { $settings['loop_icn_link'] = sanitize_text_field($input['loop_icn_link']); }
    if (isset($input['loop_url_link'])) { $settings['loop_url_link'] = $input['loop_url_link']; }
    if (isset($input['dis_counter_custom_text'])) { $settings['dis_counter_custom_text'] = sanitize_text_field($input['dis_counter_custom_text']); }
    if (isset($input['loop_content'])) { $settings['loop_content'] = $input['loop_content']; }
    if (isset($input['connection_switch'])) { $settings['connection_switch'] = sanitize_text_field($input['connection_switch']); }
    if (isset($input['connection_unique_id'])) { $settings['connection_unique_id'] = sanitize_text_field($input['connection_unique_id']); }
    if (isset($input['connection_hover_click'])) { $settings['connection_hover_click'] = sanitize_text_field($input['connection_hover_click']); }
    if (isset($input['heading_tag'])) { $settings['heading_tag'] = sanitize_text_field($input['heading_tag']); }
    if (isset($input['title_text_color_n'])) { $settings['title_text_color_n'] = sanitize_text_field($input['title_text_color_n']); }
    if (isset($input['title_text_color_h'])) { $settings['title_text_color_h'] = sanitize_text_field($input['title_text_color_h']); }
    if (isset($input['description_margin'])) { $settings['description_margin'] = $input['description_margin']; }
    if (isset($input['title_description_color_n'])) { $settings['title_description_color_n'] = sanitize_text_field($input['title_description_color_n']); }
    if (isset($input['title_description_color_h'])) { $settings['title_description_color_h'] = sanitize_text_field($input['title_description_color_h']); }
    if (isset($input['tab_icon_size'])) { $settings['tab_icon_size'] = $input['tab_icon_size']; }
    if (isset($input['tab_icon_color_n'])) { $settings['tab_icon_color_n'] = sanitize_text_field($input['tab_icon_color_n']); }
    if (isset($input['tab_icon_color_h'])) { $settings['tab_icon_color_h'] = sanitize_text_field($input['tab_icon_color_h']); }
    if (isset($input['tab_image_size'])) { $settings['tab_image_size'] = $input['tab_image_size']; }
    if (isset($input['tab_image_border_radius_n'])) { $settings['tab_image_border_radius_n'] = $input['tab_image_border_radius_n']; }
    if (isset($input['tab_text_color_n'])) { $settings['tab_text_color_n'] = sanitize_text_field($input['tab_text_color_n']); }
    if (isset($input['tab_text_color_h'])) { $settings['tab_text_color_h'] = sanitize_text_field($input['tab_text_color_h']); }
    if (isset($input['tab_bg_size'])) { $settings['tab_bg_size'] = $input['tab_bg_size']; }
    if (isset($input['pro_ste_minimum_height'])) { $settings['pro_ste_minimum_height'] = $input['pro_ste_minimum_height']; }
    if (isset($input['tab_bg_border_radius_n'])) { $settings['tab_bg_border_radius_n'] = $input['tab_bg_border_radius_n']; }
    if (isset($input['tab_bg_border_radius_h'])) { $settings['tab_bg_border_radius_h'] = $input['tab_bg_border_radius_h']; }
    if (isset($input['transform_n'])) { $settings['transform_n'] = sanitize_text_field($input['transform_n']); }
    if (isset($input['overlay_color_n'])) { $settings['overlay_color_n'] = sanitize_text_field($input['overlay_color_n']); }
    if (isset($input['transform_h'])) { $settings['transform_h'] = sanitize_text_field($input['transform_h']); }
    if (isset($input['overlay_color_h'])) { $settings['overlay_color_h'] = sanitize_text_field($input['overlay_color_h']); }
    if (isset($input['tab_bg_bf'])) { $settings['tab_bg_bf'] = sanitize_text_field($input['tab_bg_bf']); }
    if (isset($input['tab_bg_bf_blur'])) { $settings['tab_bg_bf_blur'] = $input['tab_bg_bf_blur']; }
    if (isset($input['tab_bg_bf_grayscale'])) { $settings['tab_bg_bf_grayscale'] = $input['tab_bg_bf_grayscale']; }
    if (isset($input['lottieWidth'])) { $settings['lottieWidth'] = $input['lottieWidth']; }
    if (isset($input['lottieHeight'])) { $settings['lottieHeight'] = $input['lottieHeight']; }
    if (isset($input['lottieSpeed'])) { $settings['lottieSpeed'] = $input['lottieSpeed']; }
    if (isset($input['lottieLoop'])) { $settings['lottieLoop'] = sanitize_text_field($input['lottieLoop']); }
    if (isset($input['lottiehover'])) { $settings['lottiehover'] = sanitize_text_field($input['lottiehover']); }
    if (isset($input['seprator_color_n'])) { $settings['seprator_color_n'] = sanitize_text_field($input['seprator_color_n']); }
    if (isset($input['seprator_border_style_n'])) { $settings['seprator_border_style_n'] = sanitize_text_field($input['seprator_border_style_n']); }
    if (isset($input['seprator_border_width_n'])) { $settings['seprator_border_width_n'] = $input['seprator_border_width_n']; }
    if (!empty($input['seprator_cusom_img'])) { $settings['seprator_cusom_img'] = ['id' => absint($input['seprator_cusom_img'])]; }
    if (isset($input['seprator_main_top_offset'])) { $settings['seprator_main_top_offset'] = $input['seprator_main_top_offset']; }
    if (isset($input['seprator_main_size'])) { $settings['seprator_main_size'] = $input['seprator_main_size']; }
    if (isset($input['seprator_img_height_width'])) { $settings['seprator_img_height_width'] = $input['seprator_img_height_width']; }
    if (isset($input['seprator_cusom_img_button_radius'])) { $settings['seprator_cusom_img_button_radius'] = $input['seprator_cusom_img_button_radius']; }
    if (isset($input['seprator_color_h'])) { $settings['seprator_color_h'] = sanitize_text_field($input['seprator_color_h']); }
    if (isset($input['display_counter_padding'])) { $settings['display_counter_padding'] = $input['display_counter_padding']; }
    if (isset($input['display_counter_left_offset'])) { $settings['display_counter_left_offset'] = $input['display_counter_left_offset']; }
    if (isset($input['display_counter_top_offset'])) { $settings['display_counter_top_offset'] = $input['display_counter_top_offset']; }
    if (isset($input['display_counter_color'])) { $settings['display_counter_color'] = sanitize_text_field($input['display_counter_color']); }
    if (isset($input['display_counter_radius'])) { $settings['display_counter_radius'] = $input['display_counter_radius']; }
    if (isset($input['display_counter_color_h'])) { $settings['display_counter_color_h'] = sanitize_text_field($input['display_counter_color_h']); }
    if (isset($input['display_counter_radius_h'])) { $settings['display_counter_radius_h'] = $input['display_counter_radius_h']; }
    if (isset($input['content_bg_padding'])) { $settings['content_bg_padding'] = $input['content_bg_padding']; }
    if (isset($input['content_bg_margin_st2'])) { $settings['content_bg_margin_st2'] = $input['content_bg_margin_st2']; }
    if (isset($input['content_bg_margin_right'])) { $settings['content_bg_margin_right'] = $input['content_bg_margin_right']; }
    if (isset($input['content_bg_radius'])) { $settings['content_bg_radius'] = $input['content_bg_radius']; }
    if (isset($input['content_bg_radius_h'])) { $settings['content_bg_radius_h'] = $input['content_bg_radius_h']; }
    if (isset($input['content_bg_bf'])) { $settings['content_bg_bf'] = sanitize_text_field($input['content_bg_bf']); }
    if (isset($input['content_bg_bf_blur'])) { $settings['content_bg_bf_blur'] = $input['content_bg_bf_blur']; }
    if (isset($input['content_bg_bf_grayscale'])) { $settings['content_bg_bf_grayscale'] = $input['content_bg_bf_grayscale']; }
    if (isset($input['Horizontal_bg_padding'])) { $settings['Horizontal_bg_padding'] = $input['Horizontal_bg_padding']; }
    if (isset($input['Horizontal_bg_margin_st22'])) { $settings['Horizontal_bg_margin_st22'] = $input['Horizontal_bg_margin_st22']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
