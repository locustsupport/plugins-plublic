<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-navigation-menu', [
'label' => __('Navigation Menu', 'theplus'),
    'description' => __('Adds The Plus "Navigation Menu" widget (tp-navigation-menu) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'TypeMenu' => ['type' => 'string', 'description' => 'Menu Type', 'enum' => ['custom', 'standard']],
        'navbar_menu_type' => ['type' => 'string', 'description' => 'Menu Direction', 'enum' => ['columns', 'horizontal', 'vertical', 'vertical-side']],
        'depth' => ['type' => 'string', 'description' => 'Menu Level', 'enum' => ['0', '1', '2', '3', '4', '5', '6']],
        'SmenuType' => ['type' => 'string', 'description' => 'Sub Menu Type', 'enum' => ['depth', 'link', 'mega-menu']],
        'LinkFilter' => ['type' => 'object', 'description' => 'Link'],
        'filterlabel' => ['type' => 'string', 'description' => 'Menu Text'],
        'blockTemp' => ['type' => 'string', 'description' => 'Template', 'enum' => ['SmenuType', 'depth']],
        'megaMType' => ['type' => 'string', 'description' => 'Mega Menu Type', 'enum' => ['SmenuType', 'container', 'depth', 'full-width']],
        'megaMwid' => ['type' => 'object', 'description' => 'Container Width (Slider/Size Object)'],
        'megaMAlign' => ['type' => 'string', 'description' => 'Dropdown Menu Alignment', 'enum' => ['center', 'megaMType']],
        'moblieMmenu' => ['type' => 'string', 'description' => 'Moblie Mega Menu Link', 'enum' => ['yes', 'no']],
        'MLinkFilter' => ['type' => 'object', 'description' => 'Link'],
        'Mfilterlabel' => ['type' => 'string', 'description' => 'Menu Text'],
        'minWidth' => ['type' => 'object', 'description' => 'Submenu Minimum Width (Px) (Slider/Size Object)'],
        'showlabel' => ['type' => 'string', 'description' => 'Label', 'enum' => ['yes', 'no']],
        'labeltxt' => ['type' => 'string', 'description' => 'Title'],
        'labelcolor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'labelBgcolor' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'menuiconTy' => ['type' => 'string', 'description' => 'Menu Icon Type', 'enum' => ['icon', 'img']],
        'icon_popover' => ['type' => 'string', 'description' => 'Icon', 'enum' => ['yes', 'no']],
        'preicon' => ['type' => 'string', 'description' => 'Select Icon'],
        'img_popover' => ['type' => 'string', 'description' => 'Image', 'enum' => ['yes', 'no']],
        'menuImg' => ['type' => 'integer', 'description' => 'Upload Icon Image (Image ID)'],
        'iconPadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'iconcolor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'iconHvrPadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'iconHvrcolor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'iconActPadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'iconActcolor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'navDesc' => ['type' => 'string', 'description' => 'Description'],
        'classTxt' => ['type' => 'string', 'description' => 'Custom Class'],
        'nav_alignment' => ['type' => 'string', 'description' => 'Alignment', 'enum' => ['icon', 'text-center', 'text-left', 'text-right', 'toggle']],
        'ItemMenu' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Navigation Menu'],
        'vertical_side_open_right' => ['type' => 'string', 'description' => 'Open Direction', 'enum' => ['navbar_menu_type', 'vso_left', 'vso_right']],
        'navbar' => ['type' => 'string', 'description' => 'navbar', 'enum' => ['TypeMenu']],
        'menu_hover_click' => ['type' => 'string', 'description' => 'Menu Hover/Click', 'enum' => ['click', 'hover']],
        'menu_transition' => ['type' => 'string', 'description' => 'Menu Effects', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4']],
        'vertical_side_title_bar' => ['type' => 'string', 'description' => 'Vertical Side Title Bar', 'enum' => ['yes', 'no']],
        'vertical_side_type' => ['type' => 'string', 'description' => 'Title Bar Hover/Click', 'enum' => ['click', 'hover', 'navbar_menu_type', 'normal', 'vertical_side_title_bar']],
        'vertical_side_click_open' => ['type' => 'string', 'description' => 'Default Open Click', 'enum' => ['yes', 'no']],
        'vertical_side_title_text' => ['type' => 'string', 'description' => 'Title'],
        'vertical_side_title_link' => ['type' => 'object', 'description' => 'Title Link'],
        'loop_icon_prefix' => ['type' => 'string', 'description' => 'Prefix Icon'],
        'loop_icon_postfix' => ['type' => 'string', 'description' => 'Postfix Icon'],
        'enable_sticky_menu' => ['type' => 'string', 'description' => 'Sticky Menu', 'enum' => ['yes', 'no']],
        'enable_sticky_osup_menu' => ['type' => 'string', 'description' => 'On Mouse Scroll Up Sticky', 'enum' => ['yes', 'no']],
        'show_mobile_menu' => ['type' => 'string', 'description' => 'Responsive Mobile Menu', 'enum' => ['yes', 'no']],
        'mobile_menu_type' => ['type' => 'string', 'description' => 'Menu Type', 'enum' => ['off-canvas', 'show_mobile_menu', 'swiper', 'toggle']],
        'menuWidth' => ['type' => 'object', 'description' => 'Custom Width (Slider/Size Object)'],
        'open_mobile_menu' => ['type' => 'object', 'description' => 'Open Mobile Menu (Slider/Size Object)'],
        'mobile_menu_toggle_style' => ['type' => 'string', 'description' => 'Toggle Style', 'enum' => ['mobile_menu_type', 'show_mobile_menu', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5']],
        'mmts_custom' => ['type' => 'string', 'description' => 'Custom', 'enum' => ['custom_icon', 'custom_img', 'mobile_menu_toggle_style', 'show_mobile_menu']],
        'mmts_custom_icon' => ['type' => 'string', 'description' => 'Open Custom Icon'],
        'mmts_custom_icon_c' => ['type' => 'string', 'description' => 'Close Custom Icon'],
        'mmts_custom_image' => ['type' => 'integer', 'description' => 'Open Custom Image (Image ID)'],
        'mmts_custom_image_c' => ['type' => 'integer', 'description' => 'Close Custom Image (Image ID)'],
        'mobile_toggle_alignment' => ['type' => 'string', 'description' => 'Toggle Alignment', 'enum' => ['center', 'flex-end', 'flex-start', 'icon', 'mobile_menu_type', 'show_mobile_menu', 'toggle', '{{WRAPPER}} .plus-mobile-nav-toggle.mobile-toggle']],
        'mobile_nav_alignment' => ['type' => 'string', 'description' => 'Navigation Alignment', 'enum' => ['center', 'icon', 'left', 'mobile_menu_content', 'right', 'show_mobile_menu', 'toggle', '{{WRAPPER}} .plus-mobile-menu-content .nav li a']],
        'mobile_menu_content' => ['type' => 'string', 'description' => 'Menu Content', 'enum' => ['normal-menu', 'show_mobile_menu', 'template-menu']],
        'mobile_navbar' => ['type' => 'string', 'description' => 'Select Menu', 'enum' => ['mobile_menu_content', 'show_mobile_menu']],
        'mobile_navbar_template' => ['type' => 'string', 'description' => 'Elementor Templates', 'enum' => ['mobile_menu_content', 'mobile_menu_type!', 'show_mobile_menu']],
        'mobile_navbar_outer_click' => ['type' => 'string', 'description' => 'Mobile Click Close Menu', 'enum' => ['yes', 'no']],
        'tpaep_theme_builder' => ['type' => 'string', 'description' => 'tpaep_theme_builder'],
        'outer_nav_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'outer_nav_min_width' => ['type' => 'object', 'description' => 'Navigation Minimum Width (Slider/Size Object)'],
        'outer_nav_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'tab_vs_title_color_n' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'tab_vs_title_color_h' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'vs_prefix_icn_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'tab_vs_prefix_color_n' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'tab_vs_prefix_color_h' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'vs_postfix_icn_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'tab_vs_postfix_color_n' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'tab_vs_postfix_color_h' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'vertical_side_whole_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'tab_vs_whole_border_radius_n' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'tab_vs_whole_border_radius_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'main_menu_outer_padding' => ['type' => 'object', 'description' => 'Outer Padding (Dimensions Object)'],
        'main_menu_inner_padding' => ['type' => 'object', 'description' => 'Inner Padding (Dimensions Object)'],
        'main_menu_indicator_style' => ['type' => 'string', 'description' => 'Main Menu Indicator Style', 'enum' => ['none', 'style-1']],
        'main_menu_indicator_size' => ['type' => 'object', 'description' => 'Indicator Icon Size (Slider/Size Object)'],
        'mm_triangle_shape' => ['type' => 'string', 'description' => 'Dropdown Arrow', 'enum' => ['yes', 'no']],
        'mm_triangle_shape_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'mm_triangle_shape_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'main_menu_normal_color' => ['type' => 'string', 'description' => 'Normal Color (Color Hex/RGBA)'],
        'main_menu_normal_icon_cls_color' => ['type' => 'string', 'description' => 'Normal Icon Color (Color Hex/RGBA)'],
        'main_menu_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'main_menu_normal_icon_color' => ['type' => 'string', 'description' => 'Indicator Color (Color Hex/RGBA)'],
        'main_menu_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'main_menu_normal_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['dashed', 'dotted', 'groove', 'main_menu_border', 'none', 'solid', '{{WRAPPER}} .plus-navigation-menu .navbar-nav>li>a']],
        'main_menu_normal_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'main_menu_normal_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'main_menu_normal_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'main_menu_hover_color' => ['type' => 'string', 'description' => 'Hover Color (Color Hex/RGBA)'],
        'main_menu_hover_icon_cls_color' => ['type' => 'string', 'description' => 'Hover Icon Color (Color Hex/RGBA)'],
        'main_menu_hover_icon_color' => ['type' => 'string', 'description' => 'Hover Indicator Color (Color Hex/RGBA)'],
        'main_menu_hover_border_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'main_menu_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        'main_menu_active_color' => ['type' => 'string', 'description' => 'Active Color (Color Hex/RGBA)'],
        'main_menu_active_icon_cls_color' => ['type' => 'string', 'description' => 'Active Icon Color (Color Hex/RGBA)'],
        'main_menu_active_icon_color' => ['type' => 'string', 'description' => 'Active Indicator Color (Color Hex/RGBA)'],
        'main_menu_active_border_color' => ['type' => 'string', 'description' => 'Active Border Color (Color Hex/RGBA)'],
        'main_menu_active_radius' => ['type' => 'object', 'description' => 'Active Border Radius (Dimensions Object)'],
        'smain_menu_outer_padding' => ['type' => 'object', 'description' => 'Outer Padding (Dimensions Object)'],
        'smain_menu_inner_padding' => ['type' => 'object', 'description' => 'Inner Padding (Dimensions Object)'],
        'smain_menu_indicator_style' => ['type' => 'string', 'description' => 'Main Menu Indicator Style', 'enum' => ['none', 'style-1']],
        'smain_menu_normal_color' => ['type' => 'string', 'description' => 'Normal Color (Color Hex/RGBA)'],
        'smain_menu_normal_icon_cls_color' => ['type' => 'string', 'description' => 'Normal Icon Color (Color Hex/RGBA)'],
        'smain_menu_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'smain_menu_normal_icon_color' => ['type' => 'string', 'description' => 'Indicator Color (Color Hex/RGBA)'],
        'smain_menu_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'smain_menu_normal_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['.plus-nav-sticky-sec.plus-fixed-sticky .elementor-element.elementor-element-{{ID}} .plus-navigation-menu .navbar-nav>li>a', 'dashed', 'dotted', 'groove', 'none', 'smain_menu_border', 'solid']],
        'smain_menu_normal_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'smain_menu_normal_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'smain_menu_normal_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'smain_menu_hover_color' => ['type' => 'string', 'description' => 'Hover Color (Color Hex/RGBA)'],
        'smain_menu_hover_icon_cls_color' => ['type' => 'string', 'description' => 'Hover Icon Color (Color Hex/RGBA)'],
        'smain_menu_hover_icon_color' => ['type' => 'string', 'description' => 'Hover Indicator Color (Color Hex/RGBA)'],
        'smain_menu_hover_border_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'smain_menu_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        'smain_menu_active_color' => ['type' => 'string', 'description' => 'Active Color (Color Hex/RGBA)'],
        'smain_menu_active_icon_cls_color' => ['type' => 'string', 'description' => 'Active Icon Color (Color Hex/RGBA)'],
        'smain_menu_active_icon_color' => ['type' => 'string', 'description' => 'Active Indicator Color (Color Hex/RGBA)'],
        'smain_menu_active_border_color' => ['type' => 'string', 'description' => 'Active Border Color (Color Hex/RGBA)'],
        'smain_menu_active_radius' => ['type' => 'object', 'description' => 'Active Border Radius (Dimensions Object)'],
        'secbackdropshadown' => ['type' => 'string', 'description' => 'Backdrop Filter', 'enum' => ['yes', 'no']],
        'secbackdropshadown_blur' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'secbackdropshadown_grayscale' => ['type' => 'object', 'description' => 'Grayscale (Slider/Size Object)'],
        'secbackdropshadowh' => ['type' => 'string', 'description' => 'Backdrop Filter', 'enum' => ['yes', 'no']],
        'secbackdropshadowh_blur' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'secbackdropshadowh_grayscale' => ['type' => 'object', 'description' => 'Grayscale (Slider/Size Object)'],
        'so_whole_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'smain_height_size' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'smain_con_width' => ['type' => 'object', 'description' => 'Sticky Width (Slider/Size Object)'],
        'smain_con_top' => ['type' => 'object', 'description' => 'Top (Slider/Size Object)'],
        'smain_con_align' => ['type' => 'string', 'description' => 'Container Alignment', 'enum' => ['body div.elementor-element.e-con.plus-nav-sticky-sec.plus-fixed-sticky', 'center', 'icon', 'left', 'right']],
        'smain_con_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'sub_menu_width' => ['type' => 'object', 'description' => 'Sub Menu Width (Slider/Size Object)'],
        'sub_menu_outer_padding' => ['type' => 'object', 'description' => 'Outer Padding (Dimensions Object)'],
        'sub_menu_outer_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'sub_menu_outer_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['dashed', 'dotted', 'groove', 'none', 'solid', 'sub_menu_outer_border', '{{WRAPPER}} .plus-navigation-menu .nav li.dropdown .dropdown-menu']],
        'sub_menu_outer_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'sub_menu_outer_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'sub_menu_outer_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'sub_menu_inner_padding' => ['type' => 'object', 'description' => 'Inner Padding (Dimensions Object)'],
        'sub_menu_indicator_style' => ['type' => 'string', 'description' => 'Sub Menu Indicator Style', 'enum' => ['none', 'style-1', 'style-2']],
        'sub_menu_normal_color' => ['type' => 'string', 'description' => 'Normal Color (Color Hex/RGBA)'],
        'sub_menu_normal_icon_cls_color' => ['type' => 'string', 'description' => 'Normal Icon Color (Color Hex/RGBA)'],
        'sub_menu_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'sub_menu_normal_icon_color' => ['type' => 'string', 'description' => 'Indicator Color (Color Hex/RGBA)'],
        'sub_menu_hover_color' => ['type' => 'string', 'description' => 'Hover Color (Color Hex/RGBA)'],
        'sub_menu_hover_icon_cls_color' => ['type' => 'string', 'description' => 'Hover Icon Color (Color Hex/RGBA)'],
        'sub_menu_hover_icon_color' => ['type' => 'string', 'description' => 'Hover Indicator Color (Color Hex/RGBA)'],
        'sub_menu_active_color' => ['type' => 'string', 'description' => 'Active Color (Color Hex/RGBA)'],
        'sub_menu_active_icon_cls_color' => ['type' => 'string', 'description' => 'Active Icon Color (Color Hex/RGBA)'],
        'sub_menu_active_icon_color' => ['type' => 'string', 'description' => 'Active Indicator Color (Color Hex/RGBA)'],
        'description_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'description_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'description_alignment' => ['type' => 'string', 'description' => 'Alignment', 'enum' => ['bottom', 'icon', 'middle', 'toggle', 'top', '{{WRAPPER}} .plus-navigation-menu .nav>li']],
        'description_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'mobile_nav_toggle_height' => ['type' => 'object', 'description' => 'Toggle Height (Slider/Size Object)'],
        'toggle_menu_gap' => ['type' => 'object', 'description' => 'toggle_menu_gap (Slider/Size Object)'],
        'mobile_nav_toggle_icon_st5' => ['type' => 'object', 'description' => 'Mobile Toggle Open Icon Size (Slider/Size Object)'],
        'mobile_nav_toggle_icon_st5_c' => ['type' => 'object', 'description' => 'Mobile Toggle Close Icon Size (Slider/Size Object)'],
        'mobile_nav_size_open' => ['type' => 'string', 'description' => 'Navigation Width', 'enum' => ['custom', 'full', 'show_mobile_menu']],
        'mobile_nav_cust_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'toggle_nav_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'toggle_nav_active_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'mobile_main_menu_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'mobile_main_menu_inner_padding' => ['type' => 'object', 'description' => 'Inner Padding (Dimensions Object)'],
        'mobile_main_menu_normal_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'mobile_main_menu_normal_icon_cls_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'mobile_main_menu_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'mobile_main_menu_normal_icon_color' => ['type' => 'string', 'description' => 'Indicator Color (Color Hex/RGBA)'],
        'mobile_main_menu_active_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'mobile_main_menu_active_icon_cls_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'mobile_main_menu_active_icon_color' => ['type' => 'string', 'description' => 'Active Indicator Color (Color Hex/RGBA)'],
        'mobile_menu_border_main' => ['type' => 'object', 'description' => 'Border Bottom Size (Slider/Size Object)'],
        'mobile_menu_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'mobile_sub_menu_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'mobile_sub_menu_inner_padding' => ['type' => 'object', 'description' => 'Inner Padding (Dimensions Object)'],
        'mobile_sub_menu_normal_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'mobile_sub_menu_normal_icon_cls_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'mobile_sub_menu_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'mobile_sub_menu_normal_icon_color' => ['type' => 'string', 'description' => 'Indicator Color (Color Hex/RGBA)'],
        'mobile_sub_menu_active_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'mobile_sub_menu_active_icon_cls_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'mobile_sub_menu_active_icon_color' => ['type' => 'string', 'description' => 'Indicator Color (Color Hex/RGBA)'],
        'smobile_menu_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'smobile_menu_active_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'tp_mob_scroll_overflow' => ['type' => 'string', 'description' => 'Scroll Overflow', 'enum' => ['yes', 'no']],
        'main_menu_label_padd' => ['type' => 'object', 'description' => 'Outer Padding (Dimensions Object)'],
        'main_menu_label_right' => ['type' => 'object', 'description' => 'Horizontal Offset (Slider/Size Object)'],
        'main_menu_label_top' => ['type' => 'object', 'description' => 'Vertical Offset (Slider/Size Object)'],
        'main_menu_label_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'sub_menu_label_padd' => ['type' => 'object', 'description' => 'Outer Padding (Dimensions Object)'],
        'sub_menu_label_right' => ['type' => 'object', 'description' => 'Horizontal Offset (Slider/Size Object)'],
        'sub_menu_label_top' => ['type' => 'object', 'description' => 'Vertical Offset (Slider/Size Object)'],
        'sub_menu_label_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'mobile_main_menu_label_padd' => ['type' => 'object', 'description' => 'Outer Padding (Dimensions Object)'],
        'mobile_main_menu_label_right' => ['type' => 'object', 'description' => 'Horizontal Offset (Slider/Size Object)'],
        'mobile_main_menu_label_top' => ['type' => 'object', 'description' => 'Vertical Offset (Slider/Size Object)'],
        'mobile_main_menu_label_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'mobile_sub_menu_label_padd' => ['type' => 'object', 'description' => 'Outer Padding (Dimensions Object)'],
        'mobile_sub_menu_label_right' => ['type' => 'object', 'description' => 'Horizontal Offset (Slider/Size Object)'],
        'mobile_sub_menu_label_top' => ['type' => 'object', 'description' => 'Vertical Offset (Slider/Size Object)'],
        'mobile_sub_menu_label_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'main_menu_hover_style' => ['type' => 'string', 'description' => 'Main Menu Hover Effects', 'enum' => ['none', 'style-1', 'style-2']],
        'border-height' => ['type' => 'object', 'description' => 'Border Width (Slider/Size Object)'],
        'alignment-border-adjust' => ['type' => 'object', 'description' => 'Alignment Border Adjust (Slider/Size Object)'],
        'main_menu_hover_style_1_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'main_menu_hover_style_2_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'main_menu_hover_style_1_width' => ['type' => 'object', 'description' => 'Border Width (Slider/Size Object)'],
        'main_menu_hover_inverse' => ['type' => 'string', 'description' => 'On Hover Inverse Effect Main Menu', 'enum' => ['yes', 'no']],
        'main_menu_hover_selected_opacity' => ['type' => 'object', 'description' => 'Selected Menu Opacity (Slider/Size Object)'],
        'main_menu_hover_remaining_opacity' => ['type' => 'object', 'description' => 'Remaining Menus Opacity (Slider/Size Object)'],
        'sub_menu_hover_inverse' => ['type' => 'string', 'description' => 'On Hover Inverse Effect Sub Menu', 'enum' => ['yes', 'no']],
        'sub_menu_hover_selected_opacity' => ['type' => 'object', 'description' => 'Selected Menu Opacity (Slider/Size Object)'],
        'sub_menu_hover_remaining_opacity' => ['type' => 'object', 'description' => 'Remaining Menus Opacity (Slider/Size Object)'],
        'main_menu_last_open_sub_menu' => ['type' => 'string', 'description' => 'Main Menu Last Open Sub-menu Left', 'enum' => ['yes', 'no']],
        'main_menu_last_open_sub_menu_item' => ['type' => 'string', 'description' => 'Open Last Menu Left Side'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports mega menus, mobile triggers, and advanced submenu animations.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_navigation_menu_ability',
    'permission_callback' => 'tpaep_mcp_theplus_navigation_menu_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_navigation_menu_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_navigation_menu_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-navigation-menu';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Navigation Menu widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['TypeMenu'])) { $settings['TypeMenu'] = sanitize_text_field($input['TypeMenu']); }
    if (isset($input['navbar_menu_type'])) { $settings['navbar_menu_type'] = sanitize_text_field($input['navbar_menu_type']); }
    if (isset($input['depth'])) { $settings['depth'] = sanitize_text_field($input['depth']); }
    if (isset($input['SmenuType'])) { $settings['SmenuType'] = sanitize_text_field($input['SmenuType']); }
    if (isset($input['LinkFilter'])) { $settings['LinkFilter'] = $input['LinkFilter']; }
    if (isset($input['filterlabel'])) { $settings['filterlabel'] = sanitize_text_field($input['filterlabel']); }
    if (isset($input['blockTemp'])) { $settings['blockTemp'] = sanitize_text_field($input['blockTemp']); }
    if (isset($input['megaMType'])) { $settings['megaMType'] = sanitize_text_field($input['megaMType']); }
    if (isset($input['megaMwid'])) { $settings['megaMwid'] = $input['megaMwid']; }
    if (isset($input['megaMAlign'])) { $settings['megaMAlign'] = sanitize_text_field($input['megaMAlign']); }
    if (isset($input['moblieMmenu'])) { $settings['moblieMmenu'] = sanitize_text_field($input['moblieMmenu']); }
    if (isset($input['MLinkFilter'])) { $settings['MLinkFilter'] = $input['MLinkFilter']; }
    if (isset($input['Mfilterlabel'])) { $settings['Mfilterlabel'] = sanitize_text_field($input['Mfilterlabel']); }
    if (isset($input['minWidth'])) { $settings['minWidth'] = $input['minWidth']; }
    if (isset($input['showlabel'])) { $settings['showlabel'] = sanitize_text_field($input['showlabel']); }
    if (isset($input['labeltxt'])) { $settings['labeltxt'] = sanitize_text_field($input['labeltxt']); }
    if (isset($input['labelcolor'])) { $settings['labelcolor'] = sanitize_text_field($input['labelcolor']); }
    if (isset($input['labelBgcolor'])) { $settings['labelBgcolor'] = sanitize_text_field($input['labelBgcolor']); }
    if (isset($input['menuiconTy'])) { $settings['menuiconTy'] = sanitize_text_field($input['menuiconTy']); }
    if (isset($input['icon_popover'])) { $settings['icon_popover'] = sanitize_text_field($input['icon_popover']); }
    if (isset($input['preicon'])) { $settings['preicon'] = sanitize_text_field($input['preicon']); }
    if (isset($input['img_popover'])) { $settings['img_popover'] = sanitize_text_field($input['img_popover']); }
    if (!empty($input['menuImg'])) { $settings['menuImg'] = ['id' => absint($input['menuImg'])]; }
    if (isset($input['iconPadding'])) { $settings['iconPadding'] = $input['iconPadding']; }
    if (isset($input['iconcolor'])) { $settings['iconcolor'] = sanitize_text_field($input['iconcolor']); }
    if (isset($input['iconHvrPadding'])) { $settings['iconHvrPadding'] = $input['iconHvrPadding']; }
    if (isset($input['iconHvrcolor'])) { $settings['iconHvrcolor'] = sanitize_text_field($input['iconHvrcolor']); }
    if (isset($input['iconActPadding'])) { $settings['iconActPadding'] = $input['iconActPadding']; }
    if (isset($input['iconActcolor'])) { $settings['iconActcolor'] = sanitize_text_field($input['iconActcolor']); }
    if (isset($input['navDesc'])) { $settings['navDesc'] = sanitize_text_field($input['navDesc']); }
    if (isset($input['classTxt'])) { $settings['classTxt'] = sanitize_text_field($input['classTxt']); }
    if (isset($input['nav_alignment'])) { $settings['nav_alignment'] = sanitize_text_field($input['nav_alignment']); }
    if (isset($input['ItemMenu'])) { $settings['ItemMenu'] = $input['ItemMenu']; }
    if (isset($input['vertical_side_open_right'])) { $settings['vertical_side_open_right'] = sanitize_text_field($input['vertical_side_open_right']); }
    if (isset($input['navbar'])) { $settings['navbar'] = sanitize_text_field($input['navbar']); }
    if (isset($input['menu_hover_click'])) { $settings['menu_hover_click'] = sanitize_text_field($input['menu_hover_click']); }
    if (isset($input['menu_transition'])) { $settings['menu_transition'] = sanitize_text_field($input['menu_transition']); }
    if (isset($input['vertical_side_title_bar'])) { $settings['vertical_side_title_bar'] = sanitize_text_field($input['vertical_side_title_bar']); }
    if (isset($input['vertical_side_type'])) { $settings['vertical_side_type'] = sanitize_text_field($input['vertical_side_type']); }
    if (isset($input['vertical_side_click_open'])) { $settings['vertical_side_click_open'] = sanitize_text_field($input['vertical_side_click_open']); }
    if (isset($input['vertical_side_title_text'])) { $settings['vertical_side_title_text'] = sanitize_text_field($input['vertical_side_title_text']); }
    if (isset($input['vertical_side_title_link'])) { $settings['vertical_side_title_link'] = $input['vertical_side_title_link']; }
    if (isset($input['loop_icon_prefix'])) { $settings['loop_icon_prefix'] = sanitize_text_field($input['loop_icon_prefix']); }
    if (isset($input['loop_icon_postfix'])) { $settings['loop_icon_postfix'] = sanitize_text_field($input['loop_icon_postfix']); }
    if (isset($input['enable_sticky_menu'])) { $settings['enable_sticky_menu'] = sanitize_text_field($input['enable_sticky_menu']); }
    if (isset($input['enable_sticky_osup_menu'])) { $settings['enable_sticky_osup_menu'] = sanitize_text_field($input['enable_sticky_osup_menu']); }
    if (isset($input['show_mobile_menu'])) { $settings['show_mobile_menu'] = sanitize_text_field($input['show_mobile_menu']); }
    if (isset($input['mobile_menu_type'])) { $settings['mobile_menu_type'] = sanitize_text_field($input['mobile_menu_type']); }
    if (isset($input['menuWidth'])) { $settings['menuWidth'] = $input['menuWidth']; }
    if (isset($input['open_mobile_menu'])) { $settings['open_mobile_menu'] = $input['open_mobile_menu']; }
    if (isset($input['mobile_menu_toggle_style'])) { $settings['mobile_menu_toggle_style'] = sanitize_text_field($input['mobile_menu_toggle_style']); }
    if (isset($input['mmts_custom'])) { $settings['mmts_custom'] = sanitize_text_field($input['mmts_custom']); }
    if (isset($input['mmts_custom_icon'])) { $settings['mmts_custom_icon'] = sanitize_text_field($input['mmts_custom_icon']); }
    if (isset($input['mmts_custom_icon_c'])) { $settings['mmts_custom_icon_c'] = sanitize_text_field($input['mmts_custom_icon_c']); }
    if (!empty($input['mmts_custom_image'])) { $settings['mmts_custom_image'] = ['id' => absint($input['mmts_custom_image'])]; }
    if (!empty($input['mmts_custom_image_c'])) { $settings['mmts_custom_image_c'] = ['id' => absint($input['mmts_custom_image_c'])]; }
    if (isset($input['mobile_toggle_alignment'])) { $settings['mobile_toggle_alignment'] = sanitize_text_field($input['mobile_toggle_alignment']); }
    if (isset($input['mobile_nav_alignment'])) { $settings['mobile_nav_alignment'] = sanitize_text_field($input['mobile_nav_alignment']); }
    if (isset($input['mobile_menu_content'])) { $settings['mobile_menu_content'] = sanitize_text_field($input['mobile_menu_content']); }
    if (isset($input['mobile_navbar'])) { $settings['mobile_navbar'] = sanitize_text_field($input['mobile_navbar']); }
    if (isset($input['mobile_navbar_template'])) { $settings['mobile_navbar_template'] = sanitize_text_field($input['mobile_navbar_template']); }
    if (isset($input['mobile_navbar_outer_click'])) { $settings['mobile_navbar_outer_click'] = sanitize_text_field($input['mobile_navbar_outer_click']); }
    if (isset($input['tpaep_theme_builder'])) { $settings['tpaep_theme_builder'] = sanitize_text_field($input['tpaep_theme_builder']); }
    if (isset($input['outer_nav_padding'])) { $settings['outer_nav_padding'] = $input['outer_nav_padding']; }
    if (isset($input['outer_nav_min_width'])) { $settings['outer_nav_min_width'] = $input['outer_nav_min_width']; }
    if (isset($input['outer_nav_radius'])) { $settings['outer_nav_radius'] = $input['outer_nav_radius']; }
    if (isset($input['tab_vs_title_color_n'])) { $settings['tab_vs_title_color_n'] = sanitize_text_field($input['tab_vs_title_color_n']); }
    if (isset($input['tab_vs_title_color_h'])) { $settings['tab_vs_title_color_h'] = sanitize_text_field($input['tab_vs_title_color_h']); }
    if (isset($input['vs_prefix_icn_size'])) { $settings['vs_prefix_icn_size'] = $input['vs_prefix_icn_size']; }
    if (isset($input['tab_vs_prefix_color_n'])) { $settings['tab_vs_prefix_color_n'] = sanitize_text_field($input['tab_vs_prefix_color_n']); }
    if (isset($input['tab_vs_prefix_color_h'])) { $settings['tab_vs_prefix_color_h'] = sanitize_text_field($input['tab_vs_prefix_color_h']); }
    if (isset($input['vs_postfix_icn_size'])) { $settings['vs_postfix_icn_size'] = $input['vs_postfix_icn_size']; }
    if (isset($input['tab_vs_postfix_color_n'])) { $settings['tab_vs_postfix_color_n'] = sanitize_text_field($input['tab_vs_postfix_color_n']); }
    if (isset($input['tab_vs_postfix_color_h'])) { $settings['tab_vs_postfix_color_h'] = sanitize_text_field($input['tab_vs_postfix_color_h']); }
    if (isset($input['vertical_side_whole_padding'])) { $settings['vertical_side_whole_padding'] = $input['vertical_side_whole_padding']; }
    if (isset($input['tab_vs_whole_border_radius_n'])) { $settings['tab_vs_whole_border_radius_n'] = $input['tab_vs_whole_border_radius_n']; }
    if (isset($input['tab_vs_whole_border_radius_h'])) { $settings['tab_vs_whole_border_radius_h'] = $input['tab_vs_whole_border_radius_h']; }
    if (isset($input['main_menu_outer_padding'])) { $settings['main_menu_outer_padding'] = $input['main_menu_outer_padding']; }
    if (isset($input['main_menu_inner_padding'])) { $settings['main_menu_inner_padding'] = $input['main_menu_inner_padding']; }
    if (isset($input['main_menu_indicator_style'])) { $settings['main_menu_indicator_style'] = sanitize_text_field($input['main_menu_indicator_style']); }
    if (isset($input['main_menu_indicator_size'])) { $settings['main_menu_indicator_size'] = $input['main_menu_indicator_size']; }
    if (isset($input['mm_triangle_shape'])) { $settings['mm_triangle_shape'] = sanitize_text_field($input['mm_triangle_shape']); }
    if (isset($input['mm_triangle_shape_color'])) { $settings['mm_triangle_shape_color'] = sanitize_text_field($input['mm_triangle_shape_color']); }
    if (isset($input['mm_triangle_shape_size'])) { $settings['mm_triangle_shape_size'] = $input['mm_triangle_shape_size']; }
    if (isset($input['main_menu_normal_color'])) { $settings['main_menu_normal_color'] = sanitize_text_field($input['main_menu_normal_color']); }
    if (isset($input['main_menu_normal_icon_cls_color'])) { $settings['main_menu_normal_icon_cls_color'] = sanitize_text_field($input['main_menu_normal_icon_cls_color']); }
    if (isset($input['main_menu_icon_size'])) { $settings['main_menu_icon_size'] = $input['main_menu_icon_size']; }
    if (isset($input['main_menu_normal_icon_color'])) { $settings['main_menu_normal_icon_color'] = sanitize_text_field($input['main_menu_normal_icon_color']); }
    if (isset($input['main_menu_border'])) { $settings['main_menu_border'] = sanitize_text_field($input['main_menu_border']); }
    if (isset($input['main_menu_normal_border_style'])) { $settings['main_menu_normal_border_style'] = sanitize_text_field($input['main_menu_normal_border_style']); }
    if (isset($input['main_menu_normal_border_color'])) { $settings['main_menu_normal_border_color'] = sanitize_text_field($input['main_menu_normal_border_color']); }
    if (isset($input['main_menu_normal_border_width'])) { $settings['main_menu_normal_border_width'] = $input['main_menu_normal_border_width']; }
    if (isset($input['main_menu_normal_radius'])) { $settings['main_menu_normal_radius'] = $input['main_menu_normal_radius']; }
    if (isset($input['main_menu_hover_color'])) { $settings['main_menu_hover_color'] = sanitize_text_field($input['main_menu_hover_color']); }
    if (isset($input['main_menu_hover_icon_cls_color'])) { $settings['main_menu_hover_icon_cls_color'] = sanitize_text_field($input['main_menu_hover_icon_cls_color']); }
    if (isset($input['main_menu_hover_icon_color'])) { $settings['main_menu_hover_icon_color'] = sanitize_text_field($input['main_menu_hover_icon_color']); }
    if (isset($input['main_menu_hover_border_color'])) { $settings['main_menu_hover_border_color'] = sanitize_text_field($input['main_menu_hover_border_color']); }
    if (isset($input['main_menu_hover_radius'])) { $settings['main_menu_hover_radius'] = $input['main_menu_hover_radius']; }
    if (isset($input['main_menu_active_color'])) { $settings['main_menu_active_color'] = sanitize_text_field($input['main_menu_active_color']); }
    if (isset($input['main_menu_active_icon_cls_color'])) { $settings['main_menu_active_icon_cls_color'] = sanitize_text_field($input['main_menu_active_icon_cls_color']); }
    if (isset($input['main_menu_active_icon_color'])) { $settings['main_menu_active_icon_color'] = sanitize_text_field($input['main_menu_active_icon_color']); }
    if (isset($input['main_menu_active_border_color'])) { $settings['main_menu_active_border_color'] = sanitize_text_field($input['main_menu_active_border_color']); }
    if (isset($input['main_menu_active_radius'])) { $settings['main_menu_active_radius'] = $input['main_menu_active_radius']; }
    if (isset($input['smain_menu_outer_padding'])) { $settings['smain_menu_outer_padding'] = $input['smain_menu_outer_padding']; }
    if (isset($input['smain_menu_inner_padding'])) { $settings['smain_menu_inner_padding'] = $input['smain_menu_inner_padding']; }
    if (isset($input['smain_menu_indicator_style'])) { $settings['smain_menu_indicator_style'] = sanitize_text_field($input['smain_menu_indicator_style']); }
    if (isset($input['smain_menu_normal_color'])) { $settings['smain_menu_normal_color'] = sanitize_text_field($input['smain_menu_normal_color']); }
    if (isset($input['smain_menu_normal_icon_cls_color'])) { $settings['smain_menu_normal_icon_cls_color'] = sanitize_text_field($input['smain_menu_normal_icon_cls_color']); }
    if (isset($input['smain_menu_icon_size'])) { $settings['smain_menu_icon_size'] = $input['smain_menu_icon_size']; }
    if (isset($input['smain_menu_normal_icon_color'])) { $settings['smain_menu_normal_icon_color'] = sanitize_text_field($input['smain_menu_normal_icon_color']); }
    if (isset($input['smain_menu_border'])) { $settings['smain_menu_border'] = sanitize_text_field($input['smain_menu_border']); }
    if (isset($input['smain_menu_normal_border_style'])) { $settings['smain_menu_normal_border_style'] = sanitize_text_field($input['smain_menu_normal_border_style']); }
    if (isset($input['smain_menu_normal_border_color'])) { $settings['smain_menu_normal_border_color'] = sanitize_text_field($input['smain_menu_normal_border_color']); }
    if (isset($input['smain_menu_normal_border_width'])) { $settings['smain_menu_normal_border_width'] = $input['smain_menu_normal_border_width']; }
    if (isset($input['smain_menu_normal_radius'])) { $settings['smain_menu_normal_radius'] = $input['smain_menu_normal_radius']; }
    if (isset($input['smain_menu_hover_color'])) { $settings['smain_menu_hover_color'] = sanitize_text_field($input['smain_menu_hover_color']); }
    if (isset($input['smain_menu_hover_icon_cls_color'])) { $settings['smain_menu_hover_icon_cls_color'] = sanitize_text_field($input['smain_menu_hover_icon_cls_color']); }
    if (isset($input['smain_menu_hover_icon_color'])) { $settings['smain_menu_hover_icon_color'] = sanitize_text_field($input['smain_menu_hover_icon_color']); }
    if (isset($input['smain_menu_hover_border_color'])) { $settings['smain_menu_hover_border_color'] = sanitize_text_field($input['smain_menu_hover_border_color']); }
    if (isset($input['smain_menu_hover_radius'])) { $settings['smain_menu_hover_radius'] = $input['smain_menu_hover_radius']; }
    if (isset($input['smain_menu_active_color'])) { $settings['smain_menu_active_color'] = sanitize_text_field($input['smain_menu_active_color']); }
    if (isset($input['smain_menu_active_icon_cls_color'])) { $settings['smain_menu_active_icon_cls_color'] = sanitize_text_field($input['smain_menu_active_icon_cls_color']); }
    if (isset($input['smain_menu_active_icon_color'])) { $settings['smain_menu_active_icon_color'] = sanitize_text_field($input['smain_menu_active_icon_color']); }
    if (isset($input['smain_menu_active_border_color'])) { $settings['smain_menu_active_border_color'] = sanitize_text_field($input['smain_menu_active_border_color']); }
    if (isset($input['smain_menu_active_radius'])) { $settings['smain_menu_active_radius'] = $input['smain_menu_active_radius']; }
    if (isset($input['secbackdropshadown'])) { $settings['secbackdropshadown'] = sanitize_text_field($input['secbackdropshadown']); }
    if (isset($input['secbackdropshadown_blur'])) { $settings['secbackdropshadown_blur'] = $input['secbackdropshadown_blur']; }
    if (isset($input['secbackdropshadown_grayscale'])) { $settings['secbackdropshadown_grayscale'] = $input['secbackdropshadown_grayscale']; }
    if (isset($input['secbackdropshadowh'])) { $settings['secbackdropshadowh'] = sanitize_text_field($input['secbackdropshadowh']); }
    if (isset($input['secbackdropshadowh_blur'])) { $settings['secbackdropshadowh_blur'] = $input['secbackdropshadowh_blur']; }
    if (isset($input['secbackdropshadowh_grayscale'])) { $settings['secbackdropshadowh_grayscale'] = $input['secbackdropshadowh_grayscale']; }
    if (isset($input['so_whole_padding'])) { $settings['so_whole_padding'] = $input['so_whole_padding']; }
    if (isset($input['smain_height_size'])) { $settings['smain_height_size'] = $input['smain_height_size']; }
    if (isset($input['smain_con_width'])) { $settings['smain_con_width'] = $input['smain_con_width']; }
    if (isset($input['smain_con_top'])) { $settings['smain_con_top'] = $input['smain_con_top']; }
    if (isset($input['smain_con_align'])) { $settings['smain_con_align'] = sanitize_text_field($input['smain_con_align']); }
    if (isset($input['smain_con_br'])) { $settings['smain_con_br'] = $input['smain_con_br']; }
    if (isset($input['sub_menu_width'])) { $settings['sub_menu_width'] = $input['sub_menu_width']; }
    if (isset($input['sub_menu_outer_padding'])) { $settings['sub_menu_outer_padding'] = $input['sub_menu_outer_padding']; }
    if (isset($input['sub_menu_outer_border'])) { $settings['sub_menu_outer_border'] = sanitize_text_field($input['sub_menu_outer_border']); }
    if (isset($input['sub_menu_outer_border_style'])) { $settings['sub_menu_outer_border_style'] = sanitize_text_field($input['sub_menu_outer_border_style']); }
    if (isset($input['sub_menu_outer_border_color'])) { $settings['sub_menu_outer_border_color'] = sanitize_text_field($input['sub_menu_outer_border_color']); }
    if (isset($input['sub_menu_outer_border_width'])) { $settings['sub_menu_outer_border_width'] = $input['sub_menu_outer_border_width']; }
    if (isset($input['sub_menu_outer_radius'])) { $settings['sub_menu_outer_radius'] = $input['sub_menu_outer_radius']; }
    if (isset($input['sub_menu_inner_padding'])) { $settings['sub_menu_inner_padding'] = $input['sub_menu_inner_padding']; }
    if (isset($input['sub_menu_indicator_style'])) { $settings['sub_menu_indicator_style'] = sanitize_text_field($input['sub_menu_indicator_style']); }
    if (isset($input['sub_menu_normal_color'])) { $settings['sub_menu_normal_color'] = sanitize_text_field($input['sub_menu_normal_color']); }
    if (isset($input['sub_menu_normal_icon_cls_color'])) { $settings['sub_menu_normal_icon_cls_color'] = sanitize_text_field($input['sub_menu_normal_icon_cls_color']); }
    if (isset($input['sub_menu_icon_size'])) { $settings['sub_menu_icon_size'] = $input['sub_menu_icon_size']; }
    if (isset($input['sub_menu_normal_icon_color'])) { $settings['sub_menu_normal_icon_color'] = sanitize_text_field($input['sub_menu_normal_icon_color']); }
    if (isset($input['sub_menu_hover_color'])) { $settings['sub_menu_hover_color'] = sanitize_text_field($input['sub_menu_hover_color']); }
    if (isset($input['sub_menu_hover_icon_cls_color'])) { $settings['sub_menu_hover_icon_cls_color'] = sanitize_text_field($input['sub_menu_hover_icon_cls_color']); }
    if (isset($input['sub_menu_hover_icon_color'])) { $settings['sub_menu_hover_icon_color'] = sanitize_text_field($input['sub_menu_hover_icon_color']); }
    if (isset($input['sub_menu_active_color'])) { $settings['sub_menu_active_color'] = sanitize_text_field($input['sub_menu_active_color']); }
    if (isset($input['sub_menu_active_icon_cls_color'])) { $settings['sub_menu_active_icon_cls_color'] = sanitize_text_field($input['sub_menu_active_icon_cls_color']); }
    if (isset($input['sub_menu_active_icon_color'])) { $settings['sub_menu_active_icon_color'] = sanitize_text_field($input['sub_menu_active_icon_color']); }
    if (isset($input['description_padding'])) { $settings['description_padding'] = $input['description_padding']; }
    if (isset($input['description_margin'])) { $settings['description_margin'] = $input['description_margin']; }
    if (isset($input['description_alignment'])) { $settings['description_alignment'] = sanitize_text_field($input['description_alignment']); }
    if (isset($input['description_color'])) { $settings['description_color'] = sanitize_text_field($input['description_color']); }
    if (isset($input['mobile_nav_toggle_height'])) { $settings['mobile_nav_toggle_height'] = $input['mobile_nav_toggle_height']; }
    if (isset($input['toggle_menu_gap'])) { $settings['toggle_menu_gap'] = $input['toggle_menu_gap']; }
    if (isset($input['mobile_nav_toggle_icon_st5'])) { $settings['mobile_nav_toggle_icon_st5'] = $input['mobile_nav_toggle_icon_st5']; }
    if (isset($input['mobile_nav_toggle_icon_st5_c'])) { $settings['mobile_nav_toggle_icon_st5_c'] = $input['mobile_nav_toggle_icon_st5_c']; }
    if (isset($input['mobile_nav_size_open'])) { $settings['mobile_nav_size_open'] = sanitize_text_field($input['mobile_nav_size_open']); }
    if (isset($input['mobile_nav_cust_radius'])) { $settings['mobile_nav_cust_radius'] = $input['mobile_nav_cust_radius']; }
    if (isset($input['toggle_nav_color'])) { $settings['toggle_nav_color'] = sanitize_text_field($input['toggle_nav_color']); }
    if (isset($input['toggle_nav_active_color'])) { $settings['toggle_nav_active_color'] = sanitize_text_field($input['toggle_nav_active_color']); }
    if (isset($input['mobile_main_menu_margin'])) { $settings['mobile_main_menu_margin'] = $input['mobile_main_menu_margin']; }
    if (isset($input['mobile_main_menu_inner_padding'])) { $settings['mobile_main_menu_inner_padding'] = $input['mobile_main_menu_inner_padding']; }
    if (isset($input['mobile_main_menu_normal_color'])) { $settings['mobile_main_menu_normal_color'] = sanitize_text_field($input['mobile_main_menu_normal_color']); }
    if (isset($input['mobile_main_menu_normal_icon_cls_color'])) { $settings['mobile_main_menu_normal_icon_cls_color'] = sanitize_text_field($input['mobile_main_menu_normal_icon_cls_color']); }
    if (isset($input['mobile_main_menu_icon_size'])) { $settings['mobile_main_menu_icon_size'] = $input['mobile_main_menu_icon_size']; }
    if (isset($input['mobile_main_menu_normal_icon_color'])) { $settings['mobile_main_menu_normal_icon_color'] = sanitize_text_field($input['mobile_main_menu_normal_icon_color']); }
    if (isset($input['mobile_main_menu_active_color'])) { $settings['mobile_main_menu_active_color'] = sanitize_text_field($input['mobile_main_menu_active_color']); }
    if (isset($input['mobile_main_menu_active_icon_cls_color'])) { $settings['mobile_main_menu_active_icon_cls_color'] = sanitize_text_field($input['mobile_main_menu_active_icon_cls_color']); }
    if (isset($input['mobile_main_menu_active_icon_color'])) { $settings['mobile_main_menu_active_icon_color'] = sanitize_text_field($input['mobile_main_menu_active_icon_color']); }
    if (isset($input['mobile_menu_border_main'])) { $settings['mobile_menu_border_main'] = $input['mobile_menu_border_main']; }
    if (isset($input['mobile_menu_border_color'])) { $settings['mobile_menu_border_color'] = sanitize_text_field($input['mobile_menu_border_color']); }
    if (isset($input['mobile_sub_menu_margin'])) { $settings['mobile_sub_menu_margin'] = $input['mobile_sub_menu_margin']; }
    if (isset($input['mobile_sub_menu_inner_padding'])) { $settings['mobile_sub_menu_inner_padding'] = $input['mobile_sub_menu_inner_padding']; }
    if (isset($input['mobile_sub_menu_normal_color'])) { $settings['mobile_sub_menu_normal_color'] = sanitize_text_field($input['mobile_sub_menu_normal_color']); }
    if (isset($input['mobile_sub_menu_normal_icon_cls_color'])) { $settings['mobile_sub_menu_normal_icon_cls_color'] = sanitize_text_field($input['mobile_sub_menu_normal_icon_cls_color']); }
    if (isset($input['mobile_sub_menu_icon_size'])) { $settings['mobile_sub_menu_icon_size'] = $input['mobile_sub_menu_icon_size']; }
    if (isset($input['mobile_sub_menu_normal_icon_color'])) { $settings['mobile_sub_menu_normal_icon_color'] = sanitize_text_field($input['mobile_sub_menu_normal_icon_color']); }
    if (isset($input['mobile_sub_menu_active_color'])) { $settings['mobile_sub_menu_active_color'] = sanitize_text_field($input['mobile_sub_menu_active_color']); }
    if (isset($input['mobile_sub_menu_active_icon_cls_color'])) { $settings['mobile_sub_menu_active_icon_cls_color'] = sanitize_text_field($input['mobile_sub_menu_active_icon_cls_color']); }
    if (isset($input['mobile_sub_menu_active_icon_color'])) { $settings['mobile_sub_menu_active_icon_color'] = sanitize_text_field($input['mobile_sub_menu_active_icon_color']); }
    if (isset($input['smobile_menu_color'])) { $settings['smobile_menu_color'] = sanitize_text_field($input['smobile_menu_color']); }
    if (isset($input['smobile_menu_active_color'])) { $settings['smobile_menu_active_color'] = sanitize_text_field($input['smobile_menu_active_color']); }
    if (isset($input['tp_mob_scroll_overflow'])) { $settings['tp_mob_scroll_overflow'] = sanitize_text_field($input['tp_mob_scroll_overflow']); }
    if (isset($input['main_menu_label_padd'])) { $settings['main_menu_label_padd'] = $input['main_menu_label_padd']; }
    if (isset($input['main_menu_label_right'])) { $settings['main_menu_label_right'] = $input['main_menu_label_right']; }
    if (isset($input['main_menu_label_top'])) { $settings['main_menu_label_top'] = $input['main_menu_label_top']; }
    if (isset($input['main_menu_label_border_radius'])) { $settings['main_menu_label_border_radius'] = $input['main_menu_label_border_radius']; }
    if (isset($input['sub_menu_label_padd'])) { $settings['sub_menu_label_padd'] = $input['sub_menu_label_padd']; }
    if (isset($input['sub_menu_label_right'])) { $settings['sub_menu_label_right'] = $input['sub_menu_label_right']; }
    if (isset($input['sub_menu_label_top'])) { $settings['sub_menu_label_top'] = $input['sub_menu_label_top']; }
    if (isset($input['sub_menu_label_border_radius'])) { $settings['sub_menu_label_border_radius'] = $input['sub_menu_label_border_radius']; }
    if (isset($input['mobile_main_menu_label_padd'])) { $settings['mobile_main_menu_label_padd'] = $input['mobile_main_menu_label_padd']; }
    if (isset($input['mobile_main_menu_label_right'])) { $settings['mobile_main_menu_label_right'] = $input['mobile_main_menu_label_right']; }
    if (isset($input['mobile_main_menu_label_top'])) { $settings['mobile_main_menu_label_top'] = $input['mobile_main_menu_label_top']; }
    if (isset($input['mobile_main_menu_label_border_radius'])) { $settings['mobile_main_menu_label_border_radius'] = $input['mobile_main_menu_label_border_radius']; }
    if (isset($input['mobile_sub_menu_label_padd'])) { $settings['mobile_sub_menu_label_padd'] = $input['mobile_sub_menu_label_padd']; }
    if (isset($input['mobile_sub_menu_label_right'])) { $settings['mobile_sub_menu_label_right'] = $input['mobile_sub_menu_label_right']; }
    if (isset($input['mobile_sub_menu_label_top'])) { $settings['mobile_sub_menu_label_top'] = $input['mobile_sub_menu_label_top']; }
    if (isset($input['mobile_sub_menu_label_border_radius'])) { $settings['mobile_sub_menu_label_border_radius'] = $input['mobile_sub_menu_label_border_radius']; }
    if (isset($input['main_menu_hover_style'])) { $settings['main_menu_hover_style'] = sanitize_text_field($input['main_menu_hover_style']); }
    if (isset($input['border-height'])) { $settings['border-height'] = $input['border-height']; }
    if (isset($input['alignment-border-adjust'])) { $settings['alignment-border-adjust'] = $input['alignment-border-adjust']; }
    if (isset($input['main_menu_hover_style_1_color'])) { $settings['main_menu_hover_style_1_color'] = sanitize_text_field($input['main_menu_hover_style_1_color']); }
    if (isset($input['main_menu_hover_style_2_color'])) { $settings['main_menu_hover_style_2_color'] = sanitize_text_field($input['main_menu_hover_style_2_color']); }
    if (isset($input['main_menu_hover_style_1_width'])) { $settings['main_menu_hover_style_1_width'] = $input['main_menu_hover_style_1_width']; }
    if (isset($input['main_menu_hover_inverse'])) { $settings['main_menu_hover_inverse'] = sanitize_text_field($input['main_menu_hover_inverse']); }
    if (isset($input['main_menu_hover_selected_opacity'])) { $settings['main_menu_hover_selected_opacity'] = $input['main_menu_hover_selected_opacity']; }
    if (isset($input['main_menu_hover_remaining_opacity'])) { $settings['main_menu_hover_remaining_opacity'] = $input['main_menu_hover_remaining_opacity']; }
    if (isset($input['sub_menu_hover_inverse'])) { $settings['sub_menu_hover_inverse'] = sanitize_text_field($input['sub_menu_hover_inverse']); }
    if (isset($input['sub_menu_hover_selected_opacity'])) { $settings['sub_menu_hover_selected_opacity'] = $input['sub_menu_hover_selected_opacity']; }
    if (isset($input['sub_menu_hover_remaining_opacity'])) { $settings['sub_menu_hover_remaining_opacity'] = $input['sub_menu_hover_remaining_opacity']; }
    if (isset($input['main_menu_last_open_sub_menu'])) { $settings['main_menu_last_open_sub_menu'] = sanitize_text_field($input['main_menu_last_open_sub_menu']); }
    if (isset($input['main_menu_last_open_sub_menu_item'])) { $settings['main_menu_last_open_sub_menu_item'] = sanitize_text_field($input['main_menu_last_open_sub_menu_item']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
