<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-table', [
'label' => __('Table', 'theplus'),
    'description' => __('Adds The Plus "Table" widget (tp-table) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'Style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'none', 'style-1', 'style-2', 'style-3', 'style-4']],
        'typeList' => ['type' => 'string', 'description' => 'List Type', 'enum' => ['OL', 'Style', 'UL']],
        'selectorHeading' => ['type' => 'string', 'description' => 'selectorHeading', 'enum' => ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'multiple']],
        'ChildToggle' => ['type' => 'string', 'description' => 'Child Collapsed', 'enum' => ['yes', 'no']],
        'tp_full_width' => ['type' => 'string', 'description' => 'Full Width', 'enum' => ['yes', 'no']],
        'showText' => ['type' => 'string', 'description' => 'Content', 'enum' => ['yes', 'no']],
        'contentText' => ['type' => 'string', 'description' => 'Title'],
        'TableDescText' => ['type' => 'string', 'description' => 'Description'],
        'showIcon' => ['type' => 'string', 'description' => 'Icon', 'enum' => ['yes', 'no']],
        'PrefixIcon' => ['type' => 'string', 'description' => 'Select Icon'],
        'ToggleIcon' => ['type' => 'string', 'description' => 'Toggle', 'enum' => ['yes', 'no']],
        'DefaultToggle' => ['type' => 'object', 'description' => 'Default On', 'enum' => ['yes', 'no']],
        'openIcon' => ['type' => 'string', 'description' => 'Select Open Icon'],
        'closeIcon' => ['type' => 'string', 'description' => 'Select Close Icon'],
        'smoothScroll' => ['type' => 'string', 'description' => 'Smooth Scroll', 'enum' => ['yes', 'no']],
        'smoothDuration' => ['type' => 'object', 'description' => 'Smooth Duration (Slider/Size Object)'],
        'scrollOffset' => ['type' => 'object', 'description' => 'Scroll Offset (Slider/Size Object)'],
        'fixedPosition' => ['type' => 'string', 'description' => 'Fixed', 'enum' => ['yes', 'no']],
        'fixedOffset' => ['type' => 'object', 'description' => 'Fixed Offset (Slider/Size Object)'],
        'hashtag' => ['type' => 'string', 'description' => 'Hash Tag', 'enum' => ['yes', 'no']],
        'hashtagtext' => ['type' => 'string', 'description' => 'Tag'],
        'copyText' => ['type' => 'string', 'description' => 'Copy Text', 'enum' => ['yes', 'no']],
        'hashtaghover' => ['type' => 'string', 'description' => 'Hash Tag On Hover', 'enum' => ['yes', 'no']],
        'headingsOffset' => ['type' => 'object', 'description' => 'Heading Active Offset  (Slider/Size Object)'],
        'contentSelector' => ['type' => 'string', 'description' => 'Restricted Container Area'],
        'tpaep_theme_builder' => ['type' => 'string', 'description' => 'tpaep_theme_builder'],
        'TextPadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'TextMargin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'TextNormalColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'TextHoverColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'DescTextNormalColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'DescTextHoverColor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'IconSize' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'IconNormalColor' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'IconHoverColor' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'ToggleIconSize' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'ToggleIconNormalColor' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'ToggleIconHoverColor' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'TextBorderRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'TextBorderRadiusHover' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'contentPadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'Style4Padding' => ['type' => 'object', 'description' => 'Child Padding (Slider/Size Object)'],
        'outerMargin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'leftOffset' => ['type' => 'object', 'description' => 'Left Space (Slider/Size Object)'],
        'bottomOffset' => ['type' => 'object', 'description' => 'Bottom Space (Slider/Size Object)'],
        'TableSetMinHeight' => ['type' => 'string', 'description' => 'Height', 'enum' => ['yes', 'no']],
        'TableMinHeight' => ['type' => 'object', 'description' => 'Minimum Height (Slider/Size Object)'],
        'TableMaxHeight' => ['type' => 'object', 'description' => 'Maximum Height (Slider/Size Object)'],
        'ScrollBarWidth' => ['type' => 'object', 'description' => 'ScrollBar Width (Slider/Size Object)'],
        'ScrollBarThumb' => ['type' => 'string', 'description' => 'ScrollBar Thumb Color (Color Hex/RGBA)'],
        'ScrollBarTrack' => ['type' => 'string', 'description' => 'ScrollBar Track Color (Color Hex/RGBA)'],
        'LineWidth' => ['type' => 'object', 'description' => 'Line Width (Slider/Size Object)'],
        'Line2Width' => ['type' => 'object', 'description' => 'Active Line Width (Slider/Size Object)'],
        'LineColor' => ['type' => 'string', 'description' => 'Line Color (Color Hex/RGBA)'],
        'LineActiveColor' => ['type' => 'string', 'description' => 'Line Color (Color Hex/RGBA)'],
        'Level1NormalColor' => ['type' => 'string', 'description' => 'Normal Color (Color Hex/RGBA)'],
        'Level1ActiveColor' => ['type' => 'string', 'description' => 'Active Color (Color Hex/RGBA)'],
        'LevelSubNormalColor' => ['type' => 'string', 'description' => 'Normal Color (Color Hex/RGBA)'],
        'LevelSubActiveColor' => ['type' => 'string', 'description' => 'Active Color (Color Hex/RGBA)'],
        'hashcolor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'hashcolorh' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'Hashcopycolor' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'boxPadding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'boxBorderRadius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'boxBorderRadiusHover' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports multi-source data sync, interactive sorting physics, and responsive column stack logic.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_pro_table_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pro_table_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_pro_table_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_pro_table_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-table';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Table widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['Style'])) { $settings['Style'] = sanitize_text_field($input['Style']); }
    if (isset($input['typeList'])) { $settings['typeList'] = sanitize_text_field($input['typeList']); }
    if (isset($input['selectorHeading'])) { $settings['selectorHeading'] = sanitize_text_field($input['selectorHeading']); }
    if (isset($input['ChildToggle'])) { $settings['ChildToggle'] = sanitize_text_field($input['ChildToggle']); }
    if (isset($input['tp_full_width'])) { $settings['tp_full_width'] = sanitize_text_field($input['tp_full_width']); }
    if (isset($input['showText'])) { $settings['showText'] = sanitize_text_field($input['showText']); }
    if (isset($input['contentText'])) { $settings['contentText'] = sanitize_text_field($input['contentText']); }
    if (isset($input['TableDescText'])) { $settings['TableDescText'] = sanitize_text_field($input['TableDescText']); }
    if (isset($input['showIcon'])) { $settings['showIcon'] = sanitize_text_field($input['showIcon']); }
    if (isset($input['PrefixIcon'])) { $settings['PrefixIcon'] = sanitize_text_field($input['PrefixIcon']); }
    if (isset($input['ToggleIcon'])) { $settings['ToggleIcon'] = sanitize_text_field($input['ToggleIcon']); }
    if (isset($input['DefaultToggle'])) { $settings['DefaultToggle'] = $input['DefaultToggle']; }
    if (isset($input['openIcon'])) { $settings['openIcon'] = sanitize_text_field($input['openIcon']); }
    if (isset($input['closeIcon'])) { $settings['closeIcon'] = sanitize_text_field($input['closeIcon']); }
    if (isset($input['smoothScroll'])) { $settings['smoothScroll'] = sanitize_text_field($input['smoothScroll']); }
    if (isset($input['smoothDuration'])) { $settings['smoothDuration'] = $input['smoothDuration']; }
    if (isset($input['scrollOffset'])) { $settings['scrollOffset'] = $input['scrollOffset']; }
    if (isset($input['fixedPosition'])) { $settings['fixedPosition'] = sanitize_text_field($input['fixedPosition']); }
    if (isset($input['fixedOffset'])) { $settings['fixedOffset'] = $input['fixedOffset']; }
    if (isset($input['hashtag'])) { $settings['hashtag'] = sanitize_text_field($input['hashtag']); }
    if (isset($input['hashtagtext'])) { $settings['hashtagtext'] = sanitize_text_field($input['hashtagtext']); }
    if (isset($input['copyText'])) { $settings['copyText'] = sanitize_text_field($input['copyText']); }
    if (isset($input['hashtaghover'])) { $settings['hashtaghover'] = sanitize_text_field($input['hashtaghover']); }
    if (isset($input['headingsOffset'])) { $settings['headingsOffset'] = $input['headingsOffset']; }
    if (isset($input['contentSelector'])) { $settings['contentSelector'] = sanitize_text_field($input['contentSelector']); }
    if (isset($input['tpaep_theme_builder'])) { $settings['tpaep_theme_builder'] = sanitize_text_field($input['tpaep_theme_builder']); }
    if (isset($input['TextPadding'])) { $settings['TextPadding'] = $input['TextPadding']; }
    if (isset($input['TextMargin'])) { $settings['TextMargin'] = $input['TextMargin']; }
    if (isset($input['TextNormalColor'])) { $settings['TextNormalColor'] = sanitize_text_field($input['TextNormalColor']); }
    if (isset($input['TextHoverColor'])) { $settings['TextHoverColor'] = sanitize_text_field($input['TextHoverColor']); }
    if (isset($input['DescTextNormalColor'])) { $settings['DescTextNormalColor'] = sanitize_text_field($input['DescTextNormalColor']); }
    if (isset($input['DescTextHoverColor'])) { $settings['DescTextHoverColor'] = sanitize_text_field($input['DescTextHoverColor']); }
    if (isset($input['IconSize'])) { $settings['IconSize'] = $input['IconSize']; }
    if (isset($input['IconNormalColor'])) { $settings['IconNormalColor'] = sanitize_text_field($input['IconNormalColor']); }
    if (isset($input['IconHoverColor'])) { $settings['IconHoverColor'] = sanitize_text_field($input['IconHoverColor']); }
    if (isset($input['ToggleIconSize'])) { $settings['ToggleIconSize'] = $input['ToggleIconSize']; }
    if (isset($input['ToggleIconNormalColor'])) { $settings['ToggleIconNormalColor'] = sanitize_text_field($input['ToggleIconNormalColor']); }
    if (isset($input['ToggleIconHoverColor'])) { $settings['ToggleIconHoverColor'] = sanitize_text_field($input['ToggleIconHoverColor']); }
    if (isset($input['TextBorderRadius'])) { $settings['TextBorderRadius'] = $input['TextBorderRadius']; }
    if (isset($input['TextBorderRadiusHover'])) { $settings['TextBorderRadiusHover'] = $input['TextBorderRadiusHover']; }
    if (isset($input['contentPadding'])) { $settings['contentPadding'] = $input['contentPadding']; }
    if (isset($input['Style4Padding'])) { $settings['Style4Padding'] = $input['Style4Padding']; }
    if (isset($input['outerMargin'])) { $settings['outerMargin'] = $input['outerMargin']; }
    if (isset($input['leftOffset'])) { $settings['leftOffset'] = $input['leftOffset']; }
    if (isset($input['bottomOffset'])) { $settings['bottomOffset'] = $input['bottomOffset']; }
    if (isset($input['TableSetMinHeight'])) { $settings['TableSetMinHeight'] = sanitize_text_field($input['TableSetMinHeight']); }
    if (isset($input['TableMinHeight'])) { $settings['TableMinHeight'] = $input['TableMinHeight']; }
    if (isset($input['TableMaxHeight'])) { $settings['TableMaxHeight'] = $input['TableMaxHeight']; }
    if (isset($input['ScrollBarWidth'])) { $settings['ScrollBarWidth'] = $input['ScrollBarWidth']; }
    if (isset($input['ScrollBarThumb'])) { $settings['ScrollBarThumb'] = sanitize_text_field($input['ScrollBarThumb']); }
    if (isset($input['ScrollBarTrack'])) { $settings['ScrollBarTrack'] = sanitize_text_field($input['ScrollBarTrack']); }
    if (isset($input['LineWidth'])) { $settings['LineWidth'] = $input['LineWidth']; }
    if (isset($input['Line2Width'])) { $settings['Line2Width'] = $input['Line2Width']; }
    if (isset($input['LineColor'])) { $settings['LineColor'] = sanitize_text_field($input['LineColor']); }
    if (isset($input['LineActiveColor'])) { $settings['LineActiveColor'] = sanitize_text_field($input['LineActiveColor']); }
    if (isset($input['Level1NormalColor'])) { $settings['Level1NormalColor'] = sanitize_text_field($input['Level1NormalColor']); }
    if (isset($input['Level1ActiveColor'])) { $settings['Level1ActiveColor'] = sanitize_text_field($input['Level1ActiveColor']); }
    if (isset($input['LevelSubNormalColor'])) { $settings['LevelSubNormalColor'] = sanitize_text_field($input['LevelSubNormalColor']); }
    if (isset($input['LevelSubActiveColor'])) { $settings['LevelSubActiveColor'] = sanitize_text_field($input['LevelSubActiveColor']); }
    if (isset($input['hashcolor'])) { $settings['hashcolor'] = sanitize_text_field($input['hashcolor']); }
    if (isset($input['hashcolorh'])) { $settings['hashcolorh'] = sanitize_text_field($input['hashcolorh']); }
    if (isset($input['Hashcopycolor'])) { $settings['Hashcopycolor'] = sanitize_text_field($input['Hashcopycolor']); }
    if (isset($input['boxPadding'])) { $settings['boxPadding'] = $input['boxPadding']; }
    if (isset($input['boxBorderRadius'])) { $settings['boxBorderRadius'] = $input['boxBorderRadius']; }
    if (isset($input['boxBorderRadiusHover'])) { $settings['boxBorderRadiusHover'] = $input['boxBorderRadiusHover']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
