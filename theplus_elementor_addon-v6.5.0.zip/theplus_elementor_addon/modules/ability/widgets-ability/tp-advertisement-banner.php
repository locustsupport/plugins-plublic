<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-advertisement-banner', [
'label' => __('Advertisement Banner', 'theplus'),
    'description' => __('Adds The Plus "Advertisement Banner" widget (tp_advertisement_banner) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'        => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'      => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'       => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'add_style' => ['type' => 'string', 'description' => 'Styles', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7', 'style-8']],
        'banner_img' => ['type' => 'integer', 'description' => 'Banner Image'],
        'title' => ['type' => 'string', 'description' => 'Title'],
        'subtitle' => ['type' => 'string', 'description' => 'Sub Title'],
        'hov_styles' => ['type' => 'string', 'description' => 'Hover Styles', 'enum' => ['addbanner-image-blur', 'addbanner-image-vertical', 'hover-tilt', 'simple']],
        'display_button' => ['type' => 'string', 'description' => 'Button', 'enum' => ['yes', 'no']],
        'button_style' => ['type' => 'string', 'description' => 'Button Style', 'enum' => ['style-1', 'style-10', 'style-11', 'style-12', 'style-13', 'style-14', 'style-15', 'style-16', 'style-17', 'style-18', 'style-19', 'style-2', 'style-20', 'style-21', 'style-22', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7', 'style-8', 'style-9']],
        'button_text' => ['type' => 'string', 'description' => 'Button Text'],
        'button_hover_text' => ['type' => 'string', 'description' => 'Hover Text'],
        'button_link' => ['type' => 'string', 'description' => 'Button Link'],
        'icon_hover_style' => ['type' => 'string', 'description' => 'Icon Hover Style', 'enum' => ['hover-bottom', 'hover-top']],
        'button_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['font_awesome', 'font_awesome_5', 'icon_mind']],
        'font_awesome_toggle' => ['type' => 'string', 'description' => 'Font Awesome'],
        'button_icon' => ['type' => 'string', 'description' => 'Icon'],
        'font_awesome5_toggle' => ['type' => 'string', 'description' => 'Font Awesome 5'],
        'button_icons_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'icon_mind_toggle' => ['type' => 'string', 'description' => 'Icon Mind'],
        'button_icons_mind' => ['type' => 'string', 'description' => 'Icon Library'],
        'before_after' => ['type' => 'string', 'description' => 'Icon Position', 'enum' => ['after', 'before']],
        'icon_spacing' => ['type' => 'object', 'description' => 'Icon Spacing'],
        'icon_size' => ['type' => 'object', 'description' => 'Icon Size'],
        'title_color_normal' => ['type' => 'string', 'description' => 'Title Color'],
        'title_color_hover' => ['type' => 'string', 'description' => 'Title Hover Color'],
        'subtitle_color_normal' => ['type' => 'string', 'description' => 'Sub Title Color'],
        'subtitle_color_hover' => ['type' => 'string', 'description' => 'Sub Title Hover Color'],
        'button_padding' => ['type' => 'object', 'description' => 'Padding'],
        'button_top_space' => ['type' => 'object', 'description' => 'Button Above Space'],
        'btn_hover_style' => ['type' => 'string', 'description' => 'Button Style', 'enum' => ['hover-bottom', 'hover-left', 'hover-right', 'hover-top']],
        'bottom_svg_icon_size' => ['type' => 'object', 'description' => 'Svg Icon Size'],
        'btn_text_color' => ['type' => 'string', 'description' => 'Text Color'],
        'button_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['dashed', 'dotted', 'groove', 'none', 'solid']],
        'button_border_width' => ['type' => 'object', 'description' => 'Border Width'],
        'button_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'button_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'btn_bottom_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'bottom_border_height' => ['type' => 'object', 'description' => 'Border Height'],
        'btn_text_hover_color' => ['type' => 'string', 'description' => 'Text Hover Color'],
        'button_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color'],
        'button_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius'],
        'btn_bottom_border_hover_color' => ['type' => 'string', 'description' => 'Border Hover Color'],
        'button_main_background' => ['type' => 'string', 'description' => 'Background Color'],
        'content_hover_effects' => ['type' => 'string', 'description' => 'Content Hover Effects'],
        'hover_shadow_color' => ['type' => 'string', 'description' => 'Shadow Color'],
        'content_background_border_radious' => ['type' => 'object', 'description' => 'Border Radius'],
        'content_background_border_radious_hover' => ['type' => 'object', 'description' => 'Border Radius'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings (e.g. title_typography_font_family, etc.)'],
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_advertisement_banner_ability',
    'permission_callback' => 'tpaep_mcp_theplus_advertisement_banner_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_advertisement_banner_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_advertisement_banner_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp_advertisement_banner';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Advertisement Banner widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['add_style'])) { $settings['add_style'] = sanitize_text_field($input['add_style']); }
    if (!empty($input['banner_img'])) { $settings['banner_img'] = ['id' => absint($input['banner_img'])]; }
    if (isset($input['title'])) { $settings['title'] = sanitize_text_field($input['title']); }
    if (isset($input['subtitle'])) { $settings['subtitle'] = sanitize_text_field($input['subtitle']); }
    if (isset($input['hov_styles'])) { $settings['hov_styles'] = sanitize_text_field($input['hov_styles']); }
    if (isset($input['display_button'])) { $settings['display_button'] = sanitize_text_field($input['display_button']); }
    if (isset($input['button_style'])) { $settings['button_style'] = sanitize_text_field($input['button_style']); }
    if (isset($input['button_text'])) { $settings['button_text'] = sanitize_text_field($input['button_text']); }
    if (isset($input['button_hover_text'])) { $settings['button_hover_text'] = sanitize_text_field($input['button_hover_text']); }
    if (!empty($input['button_link'])) { $settings['button_link'] = ['url' => esc_url_raw($input['button_link'])]; }
    if (isset($input['icon_hover_style'])) { $settings['icon_hover_style'] = sanitize_text_field($input['icon_hover_style']); }
    if (isset($input['button_icon_style'])) { $settings['button_icon_style'] = sanitize_text_field($input['button_icon_style']); }
    if (isset($input['font_awesome_toggle'])) { $settings['font_awesome_toggle'] = sanitize_text_field($input['font_awesome_toggle']); }
    if (isset($input['button_icon'])) { $settings['button_icon'] = sanitize_text_field($input['button_icon']); }
    if (isset($input['font_awesome5_toggle'])) { $settings['font_awesome5_toggle'] = sanitize_text_field($input['font_awesome5_toggle']); }
    if (isset($input['button_icons_5'])) { $settings['button_icons_5'] = sanitize_text_field($input['button_icons_5']); }
    if (isset($input['icon_mind_toggle'])) { $settings['icon_mind_toggle'] = sanitize_text_field($input['icon_mind_toggle']); }
    if (isset($input['button_icons_mind'])) { $settings['button_icons_mind'] = sanitize_text_field($input['button_icons_mind']); }
    if (isset($input['before_after'])) { $settings['before_after'] = sanitize_text_field($input['before_after']); }
    if (isset($input['icon_spacing'])) { $settings['icon_spacing'] = $input['icon_spacing']; }
    if (isset($input['icon_size'])) { $settings['icon_size'] = $input['icon_size']; }
    if (isset($input['title_color_normal'])) { $settings['title_color_normal'] = sanitize_text_field($input['title_color_normal']); }
    if (isset($input['title_color_hover'])) { $settings['title_color_hover'] = sanitize_text_field($input['title_color_hover']); }
    if (isset($input['subtitle_color_normal'])) { $settings['subtitle_color_normal'] = sanitize_text_field($input['subtitle_color_normal']); }
    if (isset($input['subtitle_color_hover'])) { $settings['subtitle_color_hover'] = sanitize_text_field($input['subtitle_color_hover']); }
    if (isset($input['button_padding'])) { $settings['button_padding'] = $input['button_padding']; }
    if (isset($input['button_top_space'])) { $settings['button_top_space'] = $input['button_top_space']; }
    if (isset($input['btn_hover_style'])) { $settings['btn_hover_style'] = sanitize_text_field($input['btn_hover_style']); }
    if (isset($input['bottom_svg_icon_size'])) { $settings['bottom_svg_icon_size'] = $input['bottom_svg_icon_size']; }
    if (isset($input['btn_text_color'])) { $settings['btn_text_color'] = sanitize_text_field($input['btn_text_color']); }
    if (isset($input['button_border_style'])) { $settings['button_border_style'] = sanitize_text_field($input['button_border_style']); }
    if (isset($input['button_border_width'])) { $settings['button_border_width'] = $input['button_border_width']; }
    if (isset($input['button_border_color'])) { $settings['button_border_color'] = sanitize_text_field($input['button_border_color']); }
    if (isset($input['button_radius'])) { $settings['button_radius'] = $input['button_radius']; }
    if (isset($input['btn_bottom_border_color'])) { $settings['btn_bottom_border_color'] = sanitize_text_field($input['btn_bottom_border_color']); }
    if (isset($input['bottom_border_height'])) { $settings['bottom_border_height'] = $input['bottom_border_height']; }
    if (isset($input['btn_text_hover_color'])) { $settings['btn_text_hover_color'] = sanitize_text_field($input['btn_text_hover_color']); }
    if (isset($input['button_border_hover_color'])) { $settings['button_border_hover_color'] = sanitize_text_field($input['button_border_hover_color']); }
    if (isset($input['button_hover_radius'])) { $settings['button_hover_radius'] = $input['button_hover_radius']; }
    if (isset($input['btn_bottom_border_hover_color'])) { $settings['btn_bottom_border_hover_color'] = sanitize_text_field($input['btn_bottom_border_hover_color']); }
    if (isset($input['button_main_background'])) { $settings['button_main_background'] = sanitize_text_field($input['button_main_background']); }
    if (isset($input['content_hover_effects'])) { $settings['content_hover_effects'] = sanitize_text_field($input['content_hover_effects']); }
    if (isset($input['hover_shadow_color'])) { $settings['hover_shadow_color'] = sanitize_text_field($input['hover_shadow_color']); }
    if (isset($input['content_background_border_radious'])) { $settings['content_background_border_radious'] = $input['content_background_border_radious']; }
    if (isset($input['content_background_border_radious_hover'])) { $settings['content_background_border_radious_hover'] = $input['content_background_border_radious_hover']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
