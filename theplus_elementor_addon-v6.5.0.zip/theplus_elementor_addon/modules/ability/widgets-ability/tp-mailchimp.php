<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-mailchimp', [
'label' => __('Mailchimp', 'theplus'),
    'description' => __('Adds The Plus "Mailchimp" widget (tp-mailchimp-subscribe) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'form_style' => ['type' => 'string', 'description' => 'Form layout style', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4', 'style-5']],
        'name_switch' => ['type' => 'string', 'description' => 'Show name field', 'enum' => ['yes', 'no']],
        'email_field_placeholder' => ['type' => 'string', 'description' => 'Email field placeholder'],
        'button_text' => ['type' => 'string', 'description' => 'Submit button label'],
        'success_message' => ['type' => 'string', 'description' => 'Message after successful subscription'],
        'gdpr_switch' => ['type' => 'string', 'description' => 'Show GDPR consent checkbox', 'enum' => ['yes', 'no']],
        'gdpr_text' => ['type' => 'string', 'description' => 'GDPR consent text'],
        'settings' => ['type' => 'object', 'description' => 'Raw Elementor control key/value pairs. Use tpae/tpae-widget-schema to discover keys.'],
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_mailchimp_ability',
    'permission_callback' => 'tpaep_mcp_theplus_mailchimp_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_mailchimp_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_mailchimp_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-mailchimp-subscribe';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Mailchimp widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (!empty($input['form_style'])) { $settings['form_style'] = sanitize_key($input['form_style']); }
    if (!empty($input['name_switch'])) { $settings['name_switch'] = sanitize_key($input['name_switch']); }
    if (!empty($input['email_field_placeholder'])) { $settings['email_field_placeholder'] = sanitize_text_field($input['email_field_placeholder']); }
    if (!empty($input['button_text'])) { $settings['button_text'] = sanitize_text_field($input['button_text']); }
    if (!empty($input['success_message'])) { $settings['success_message'] = sanitize_text_field($input['success_message']); }
    if (!empty($input['gdpr_switch'])) { $settings['gdpr_switch'] = sanitize_key($input['gdpr_switch']); }
    if (!empty($input['gdpr_text'])) { $settings['gdpr_text'] = sanitize_text_field($input['gdpr_text']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
