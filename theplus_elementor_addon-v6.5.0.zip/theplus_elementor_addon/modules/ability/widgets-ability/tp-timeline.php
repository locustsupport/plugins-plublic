<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-timeline', [
'label' => __('Timeline', 'theplus'),
    'description' => __('Adds The Plus "Timeline" widget (tp-timeline) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'style-1', 'style-2']],
        'timeline_inline_masonry' => ['type' => 'string', 'description' => 'Masonry Layout', 'enum' => ['yes', 'no']],
        'timeline_content_align' => ['type' => 'string', 'description' => 'Content Alignment', 'enum' => ['center', 'icon', 'left', 'right', 'toggle']],
        'loop_pin_select_icon' => ['type' => 'string', 'description' => 'Select Icon', 'enum' => ['icon']],
        'pin_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['font_awesome', 'font_awesome_5', 'icon_mind', 'loop_pin_select_icon']],
        'icon_fs_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome', 'enum' => ['yes', 'no']],
        'pin_icon_fontawesome' => ['type' => 'string', 'description' => 'Icon Library'],
        'icon_f5_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome 5', 'enum' => ['yes', 'no']],
        'pin_icon_fontawesome_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'icon_mind_popover_toggle' => ['type' => 'string', 'description' => 'Icons Mind', 'enum' => ['yes', 'no']],
        'pin_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['loop_pin_select_icon', 'pin_icon_style']],
        'loop_pin_image' => ['type' => 'integer', 'description' => 'Use Image As icon (Image ID)'],
        'pin_title' => ['type' => 'string', 'description' => 'Pin Title'],
        'pin_title_position' => ['type' => 'string', 'description' => 'Pin Position', 'enum' => ['bottom', 'left', 'pin_title!', 'right', 'top']],
        'loop_content_title' => ['type' => 'string', 'description' => 'Title'],
        'loop_content_desc' => ['type' => 'string', 'description' => 'Description'],
        'loop_content_options' => ['type' => 'string', 'description' => 'Content Type', 'enum' => ['iframe', 'template']],
        'loop_featured_image' => ['type' => 'integer', 'description' => 'Featured Image (Image ID)'],
        'loop_featured_iframe' => ['type' => 'string', 'description' => 'Custom HTML/Iframe Code'],
        'loop_content_template' => ['type' => 'string', 'description' => 'Elementor Templates', 'enum' => ['loop_content_options']],
        'loop_link' => ['type' => 'object', 'description' => 'Link'],
        'loop_display_button' => ['type' => 'string', 'description' => 'Display Button', 'enum' => ['yes', 'no']],
        'loop_button_text' => ['type' => 'string', 'description' => 'Button Text'],
        'loop_content_alignment' => ['type' => 'string', 'description' => 'Content Alignment', 'enum' => ['text-center', 'text-left', 'text-right']],
        'loop_alignment_section' => ['type' => 'string', 'description' => 'Section Alignment', 'enum' => ['icon', 'left', 'right', 'toggle']],
        'loop_animation_effects' => ['type' => 'string', 'description' => 'In Animation Effect'],
        'loop_animation_delay' => ['type' => 'object', 'description' => 'Animation Delay (Slider/Size Object)'],
        'loop_top_offset' => ['type' => 'object', 'description' => 'Top Offset Space (Slider/Size Object)'],
        'content_loop_section' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'content_loop_section'],
        'pin_center_style' => ['type' => 'string', 'description' => 'Pin Center Style'],
        'start_pin_select_icon' => ['type' => 'string', 'description' => 'Select Icon', 'enum' => ['icon', 'text']],
        'start_pin_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['font_awesome', 'font_awesome_5', 'icon_mind', 'start_pin_select_icon']],
        'icon_fs_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome', 'enum' => ['yes', 'no']],
        'start_pin_icon_fontawesome' => ['type' => 'string', 'description' => 'Icon Library'],
        'icon_f5_popover_toggle' => ['type' => 'string', 'description' => 'Font Awesome 5', 'enum' => ['yes', 'no']],
        'start_pin_icon_fontawesome_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'icon_mind_popover_toggle' => ['type' => 'string', 'description' => 'Icons Mind', 'enum' => ['yes', 'no']],
        'start_pin_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['start_pin_icon_style', 'start_pin_select_icon']],
        'start_pin_image' => ['type' => 'integer', 'description' => 'Use Image As icon (Image ID)'],
        'start_pin_title' => ['type' => 'string', 'description' => 'Start Pin Text'],
        'end_pin_select_icon' => ['type' => 'string', 'description' => 'Select Icon', 'enum' => ['icon', 'text']],
        'end_pin_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['end_pin_select_icon', 'font_awesome', 'font_awesome_5', 'icon_mind']],
        'end_pin_icon_fontawesome_toggle' => ['type' => 'string', 'description' => 'Font Awesome', 'enum' => ['yes', 'no']],
        'end_pin_icon_fontawesome' => ['type' => 'string', 'description' => 'Icon Library'],
        'end_pin_icon_5_toggle' => ['type' => 'string', 'description' => 'Font Awesome 5', 'enum' => ['yes', 'no']],
        'end_pin_icon_fontawesome_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'end_pin_icons_mind_toggle' => ['type' => 'string', 'description' => 'Icons Mind', 'enum' => ['yes', 'no']],
        'end_pin_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['end_pin_icon_style', 'end_pin_select_icon']],
        'end_pin_image' => ['type' => 'integer', 'description' => 'Use Image As icon (Image ID)'],
        'end_pin_title' => ['type' => 'string', 'description' => 'End Pin Text'],
        'pin_title_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'pin_title_bg_color' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'pin_title_radius' => ['type' => 'object', 'description' => 'Pin Border Radius (Dimensions Object)'],
        'pin_title_hover_color' => ['type' => 'string', 'description' => 'Hover Color (Color Hex/RGBA)'],
        'pin_title_hover_bg_color' => ['type' => 'string', 'description' => 'Hover Background Color (Color Hex/RGBA)'],
        'pin_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'pin_icon_bg_cir_size' => ['type' => 'object', 'description' => 'Icon Background Size (Slider/Size Object)'],
        'pin_text_center_switch' => ['type' => 'string', 'description' => 'Pin Text Center Align', 'enum' => ['yes', 'no']],
        'pin_icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'pin_icon_bg_color' => ['type' => 'string', 'description' => 'Icon Background Color (Color Hex/RGBA)'],
        'pin_icon_border_color' => ['type' => 'string', 'description' => 'Icon Border Color (Color Hex/RGBA)'],
        'pin_icon_radius' => ['type' => 'object', 'description' => 'Icon Border Radius (Dimensions Object)'],
        'pin_icon_hover_color' => ['type' => 'string', 'description' => 'Hover Color (Color Hex/RGBA)'],
        'pin_icon_hover_bg_color' => ['type' => 'string', 'description' => 'Hover Background Color (Color Hex/RGBA)'],
        'pin_icon_hover_border_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'title_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'title_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'title_hover_color' => ['type' => 'string', 'description' => 'Hover Color (Color Hex/RGBA)'],
        'title_border_hover_color' => ['type' => 'string', 'description' => 'Border Hover Color (Color Hex/RGBA)'],
        'desc_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'desc_hover_color' => ['type' => 'string', 'description' => 'Hover Color (Color Hex/RGBA)'],
        'display_button' => ['type' => 'string', 'description' => 'Display Button', 'enum' => ['yes', 'no']],
        'button_text' => ['type' => 'string', 'description' => 'Button Text'],
        'button_padding' => ['type' => 'object', 'description' => 'Button Padding (Dimensions Object)'],
        'button_top_offset' => ['type' => 'object', 'description' => 'Button Top Offset (Slider/Size Object)'],
        'btn_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'button_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['dashed', 'display_button', 'dotted', 'groove', 'none', 'solid', '{{WRAPPER}} .pt_plus_button.button-style-8 .button-link-wrap']],
        'button_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'button_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'button_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'btn_text_hover_color' => ['type' => 'string', 'description' => 'Text Hover Color (Color Hex/RGBA)'],
        'button_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'button_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius (Dimensions Object)'],
        'loop_content_border' => ['type' => 'string', 'description' => 'Border', 'enum' => ['yes', 'no']],
        'loop_content_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['loop_content_border', '{{WRAPPER}} .timeline-style-2 .timeline-item-wrap .timeline-inner-block .timeline-item .timeline-item-content']],
        'loop_content_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'loop_content_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'loop_content_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'loop_content_arrow_color' => ['type' => 'string', 'description' => 'Arrow Color (Color Hex/RGBA)'],
        'loop_content_arrow_style' => ['type' => 'string', 'description' => 'Arrow Style', 'enum' => ['style-1', 'style-2']],
        'loop_content_hover_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'loop_content_hover_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'loop_content_arrow_hover_color' => ['type' => 'string', 'description' => 'Arrow Hover Color (Color Hex/RGBA)'],
        'divide_line_border_color' => ['type' => 'string', 'description' => 'Divide Border Color (Color Hex/RGBA)'],
        'pin_start_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'pin_start_image_size' => ['type' => 'object', 'description' => 'Image Size (Slider/Size Object)'],
        'pin_start_text_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'pin_start_text_icon_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'pin_start_text_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'pin_start_text_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'pin_end_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'pin_end_image_size' => ['type' => 'object', 'description' => 'Image Size (Slider/Size Object)'],
        'pin_end_text_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'pin_end_text_icon_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'pin_end_text_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'pin_end_text_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'content_gap_between' => ['type' => 'object', 'description' => 'Divider Gap Content (Slider/Size Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports dynamic WP post sources, custom SVG path animations, and staggered entry effects.']
    ], 'required' => ['post_id', 'parent_id', 'timeline_items'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_timeline_ability',
    'permission_callback' => 'tpaep_mcp_theplus_timeline_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_timeline_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_timeline_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-timeline';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Timeline widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['style'])) { $settings['style'] = sanitize_text_field($input['style']); }
    if (isset($input['timeline_inline_masonry'])) { $settings['timeline_inline_masonry'] = sanitize_text_field($input['timeline_inline_masonry']); }
    if (isset($input['timeline_content_align'])) { $settings['timeline_content_align'] = sanitize_text_field($input['timeline_content_align']); }
    if (isset($input['loop_pin_select_icon'])) { $settings['loop_pin_select_icon'] = sanitize_text_field($input['loop_pin_select_icon']); }
    if (isset($input['pin_icon_style'])) { $settings['pin_icon_style'] = sanitize_text_field($input['pin_icon_style']); }
    if (isset($input['icon_fs_popover_toggle'])) { $settings['icon_fs_popover_toggle'] = sanitize_text_field($input['icon_fs_popover_toggle']); }
    if (isset($input['pin_icon_fontawesome'])) { $settings['pin_icon_fontawesome'] = sanitize_text_field($input['pin_icon_fontawesome']); }
    if (isset($input['icon_f5_popover_toggle'])) { $settings['icon_f5_popover_toggle'] = sanitize_text_field($input['icon_f5_popover_toggle']); }
    if (isset($input['pin_icon_fontawesome_5'])) { $settings['pin_icon_fontawesome_5'] = sanitize_text_field($input['pin_icon_fontawesome_5']); }
    if (isset($input['icon_mind_popover_toggle'])) { $settings['icon_mind_popover_toggle'] = sanitize_text_field($input['icon_mind_popover_toggle']); }
    if (isset($input['pin_icons_mind'])) { $settings['pin_icons_mind'] = sanitize_text_field($input['pin_icons_mind']); }
    if (!empty($input['loop_pin_image'])) { $settings['loop_pin_image'] = ['id' => absint($input['loop_pin_image'])]; }
    if (isset($input['pin_title'])) { $settings['pin_title'] = sanitize_text_field($input['pin_title']); }
    if (isset($input['pin_title_position'])) { $settings['pin_title_position'] = sanitize_text_field($input['pin_title_position']); }
    if (isset($input['loop_content_title'])) { $settings['loop_content_title'] = sanitize_text_field($input['loop_content_title']); }
    if (isset($input['loop_content_desc'])) { $settings['loop_content_desc'] = sanitize_text_field($input['loop_content_desc']); }
    if (isset($input['loop_content_options'])) { $settings['loop_content_options'] = sanitize_text_field($input['loop_content_options']); }
    if (!empty($input['loop_featured_image'])) { $settings['loop_featured_image'] = ['id' => absint($input['loop_featured_image'])]; }
    if (isset($input['loop_featured_iframe'])) { $settings['loop_featured_iframe'] = sanitize_text_field($input['loop_featured_iframe']); }
    if (isset($input['loop_content_template'])) { $settings['loop_content_template'] = sanitize_text_field($input['loop_content_template']); }
    if (isset($input['loop_link'])) { $settings['loop_link'] = $input['loop_link']; }
    if (isset($input['loop_display_button'])) { $settings['loop_display_button'] = sanitize_text_field($input['loop_display_button']); }
    if (isset($input['loop_button_text'])) { $settings['loop_button_text'] = sanitize_text_field($input['loop_button_text']); }
    if (isset($input['loop_content_alignment'])) { $settings['loop_content_alignment'] = sanitize_text_field($input['loop_content_alignment']); }
    if (isset($input['loop_alignment_section'])) { $settings['loop_alignment_section'] = sanitize_text_field($input['loop_alignment_section']); }
    if (isset($input['loop_animation_effects'])) { $settings['loop_animation_effects'] = sanitize_text_field($input['loop_animation_effects']); }
    if (isset($input['loop_animation_delay'])) { $settings['loop_animation_delay'] = $input['loop_animation_delay']; }
    if (isset($input['loop_top_offset'])) { $settings['loop_top_offset'] = $input['loop_top_offset']; }
    if (isset($input['content_loop_section'])) { $settings['content_loop_section'] = $input['content_loop_section']; }
    if (isset($input['pin_center_style'])) { $settings['pin_center_style'] = sanitize_text_field($input['pin_center_style']); }
    if (isset($input['start_pin_select_icon'])) { $settings['start_pin_select_icon'] = sanitize_text_field($input['start_pin_select_icon']); }
    if (isset($input['start_pin_icon_style'])) { $settings['start_pin_icon_style'] = sanitize_text_field($input['start_pin_icon_style']); }
    if (isset($input['icon_fs_popover_toggle'])) { $settings['icon_fs_popover_toggle'] = sanitize_text_field($input['icon_fs_popover_toggle']); }
    if (isset($input['start_pin_icon_fontawesome'])) { $settings['start_pin_icon_fontawesome'] = sanitize_text_field($input['start_pin_icon_fontawesome']); }
    if (isset($input['icon_f5_popover_toggle'])) { $settings['icon_f5_popover_toggle'] = sanitize_text_field($input['icon_f5_popover_toggle']); }
    if (isset($input['start_pin_icon_fontawesome_5'])) { $settings['start_pin_icon_fontawesome_5'] = sanitize_text_field($input['start_pin_icon_fontawesome_5']); }
    if (isset($input['icon_mind_popover_toggle'])) { $settings['icon_mind_popover_toggle'] = sanitize_text_field($input['icon_mind_popover_toggle']); }
    if (isset($input['start_pin_icons_mind'])) { $settings['start_pin_icons_mind'] = sanitize_text_field($input['start_pin_icons_mind']); }
    if (!empty($input['start_pin_image'])) { $settings['start_pin_image'] = ['id' => absint($input['start_pin_image'])]; }
    if (isset($input['start_pin_title'])) { $settings['start_pin_title'] = sanitize_text_field($input['start_pin_title']); }
    if (isset($input['end_pin_select_icon'])) { $settings['end_pin_select_icon'] = sanitize_text_field($input['end_pin_select_icon']); }
    if (isset($input['end_pin_icon_style'])) { $settings['end_pin_icon_style'] = sanitize_text_field($input['end_pin_icon_style']); }
    if (isset($input['end_pin_icon_fontawesome_toggle'])) { $settings['end_pin_icon_fontawesome_toggle'] = sanitize_text_field($input['end_pin_icon_fontawesome_toggle']); }
    if (isset($input['end_pin_icon_fontawesome'])) { $settings['end_pin_icon_fontawesome'] = sanitize_text_field($input['end_pin_icon_fontawesome']); }
    if (isset($input['end_pin_icon_5_toggle'])) { $settings['end_pin_icon_5_toggle'] = sanitize_text_field($input['end_pin_icon_5_toggle']); }
    if (isset($input['end_pin_icon_fontawesome_5'])) { $settings['end_pin_icon_fontawesome_5'] = sanitize_text_field($input['end_pin_icon_fontawesome_5']); }
    if (isset($input['end_pin_icons_mind_toggle'])) { $settings['end_pin_icons_mind_toggle'] = sanitize_text_field($input['end_pin_icons_mind_toggle']); }
    if (isset($input['end_pin_icons_mind'])) { $settings['end_pin_icons_mind'] = sanitize_text_field($input['end_pin_icons_mind']); }
    if (!empty($input['end_pin_image'])) { $settings['end_pin_image'] = ['id' => absint($input['end_pin_image'])]; }
    if (isset($input['end_pin_title'])) { $settings['end_pin_title'] = sanitize_text_field($input['end_pin_title']); }
    if (isset($input['pin_title_color'])) { $settings['pin_title_color'] = sanitize_text_field($input['pin_title_color']); }
    if (isset($input['pin_title_bg_color'])) { $settings['pin_title_bg_color'] = sanitize_text_field($input['pin_title_bg_color']); }
    if (isset($input['pin_title_radius'])) { $settings['pin_title_radius'] = $input['pin_title_radius']; }
    if (isset($input['pin_title_hover_color'])) { $settings['pin_title_hover_color'] = sanitize_text_field($input['pin_title_hover_color']); }
    if (isset($input['pin_title_hover_bg_color'])) { $settings['pin_title_hover_bg_color'] = sanitize_text_field($input['pin_title_hover_bg_color']); }
    if (isset($input['pin_icon_size'])) { $settings['pin_icon_size'] = $input['pin_icon_size']; }
    if (isset($input['pin_icon_bg_cir_size'])) { $settings['pin_icon_bg_cir_size'] = $input['pin_icon_bg_cir_size']; }
    if (isset($input['pin_text_center_switch'])) { $settings['pin_text_center_switch'] = sanitize_text_field($input['pin_text_center_switch']); }
    if (isset($input['pin_icon_color'])) { $settings['pin_icon_color'] = sanitize_text_field($input['pin_icon_color']); }
    if (isset($input['pin_icon_bg_color'])) { $settings['pin_icon_bg_color'] = sanitize_text_field($input['pin_icon_bg_color']); }
    if (isset($input['pin_icon_border_color'])) { $settings['pin_icon_border_color'] = sanitize_text_field($input['pin_icon_border_color']); }
    if (isset($input['pin_icon_radius'])) { $settings['pin_icon_radius'] = $input['pin_icon_radius']; }
    if (isset($input['pin_icon_hover_color'])) { $settings['pin_icon_hover_color'] = sanitize_text_field($input['pin_icon_hover_color']); }
    if (isset($input['pin_icon_hover_bg_color'])) { $settings['pin_icon_hover_bg_color'] = sanitize_text_field($input['pin_icon_hover_bg_color']); }
    if (isset($input['pin_icon_hover_border_color'])) { $settings['pin_icon_hover_border_color'] = sanitize_text_field($input['pin_icon_hover_border_color']); }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['title_border_color'])) { $settings['title_border_color'] = sanitize_text_field($input['title_border_color']); }
    if (isset($input['title_hover_color'])) { $settings['title_hover_color'] = sanitize_text_field($input['title_hover_color']); }
    if (isset($input['title_border_hover_color'])) { $settings['title_border_hover_color'] = sanitize_text_field($input['title_border_hover_color']); }
    if (isset($input['desc_color'])) { $settings['desc_color'] = sanitize_text_field($input['desc_color']); }
    if (isset($input['desc_hover_color'])) { $settings['desc_hover_color'] = sanitize_text_field($input['desc_hover_color']); }
    if (isset($input['display_button'])) { $settings['display_button'] = sanitize_text_field($input['display_button']); }
    if (isset($input['button_text'])) { $settings['button_text'] = sanitize_text_field($input['button_text']); }
    if (isset($input['button_padding'])) { $settings['button_padding'] = $input['button_padding']; }
    if (isset($input['button_top_offset'])) { $settings['button_top_offset'] = $input['button_top_offset']; }
    if (isset($input['btn_text_color'])) { $settings['btn_text_color'] = sanitize_text_field($input['btn_text_color']); }
    if (isset($input['button_border_style'])) { $settings['button_border_style'] = sanitize_text_field($input['button_border_style']); }
    if (isset($input['button_border_width'])) { $settings['button_border_width'] = $input['button_border_width']; }
    if (isset($input['button_border_color'])) { $settings['button_border_color'] = sanitize_text_field($input['button_border_color']); }
    if (isset($input['button_radius'])) { $settings['button_radius'] = $input['button_radius']; }
    if (isset($input['btn_text_hover_color'])) { $settings['btn_text_hover_color'] = sanitize_text_field($input['btn_text_hover_color']); }
    if (isset($input['button_border_hover_color'])) { $settings['button_border_hover_color'] = sanitize_text_field($input['button_border_hover_color']); }
    if (isset($input['button_hover_radius'])) { $settings['button_hover_radius'] = $input['button_hover_radius']; }
    if (isset($input['loop_content_border'])) { $settings['loop_content_border'] = sanitize_text_field($input['loop_content_border']); }
    if (isset($input['loop_content_border_style'])) { $settings['loop_content_border_style'] = sanitize_text_field($input['loop_content_border_style']); }
    if (isset($input['loop_content_border_width'])) { $settings['loop_content_border_width'] = $input['loop_content_border_width']; }
    if (isset($input['loop_content_border_color'])) { $settings['loop_content_border_color'] = sanitize_text_field($input['loop_content_border_color']); }
    if (isset($input['loop_content_border_radius'])) { $settings['loop_content_border_radius'] = $input['loop_content_border_radius']; }
    if (isset($input['loop_content_arrow_color'])) { $settings['loop_content_arrow_color'] = sanitize_text_field($input['loop_content_arrow_color']); }
    if (isset($input['loop_content_arrow_style'])) { $settings['loop_content_arrow_style'] = sanitize_text_field($input['loop_content_arrow_style']); }
    if (isset($input['loop_content_hover_border_color'])) { $settings['loop_content_hover_border_color'] = sanitize_text_field($input['loop_content_hover_border_color']); }
    if (isset($input['loop_content_hover_border_radius'])) { $settings['loop_content_hover_border_radius'] = $input['loop_content_hover_border_radius']; }
    if (isset($input['loop_content_arrow_hover_color'])) { $settings['loop_content_arrow_hover_color'] = sanitize_text_field($input['loop_content_arrow_hover_color']); }
    if (isset($input['divide_line_border_color'])) { $settings['divide_line_border_color'] = sanitize_text_field($input['divide_line_border_color']); }
    if (isset($input['pin_start_icon_size'])) { $settings['pin_start_icon_size'] = $input['pin_start_icon_size']; }
    if (isset($input['pin_start_image_size'])) { $settings['pin_start_image_size'] = $input['pin_start_image_size']; }
    if (isset($input['pin_start_text_padding'])) { $settings['pin_start_text_padding'] = $input['pin_start_text_padding']; }
    if (isset($input['pin_start_text_icon_color'])) { $settings['pin_start_text_icon_color'] = sanitize_text_field($input['pin_start_text_icon_color']); }
    if (isset($input['pin_start_text_border_color'])) { $settings['pin_start_text_border_color'] = sanitize_text_field($input['pin_start_text_border_color']); }
    if (isset($input['pin_start_text_border_radius'])) { $settings['pin_start_text_border_radius'] = $input['pin_start_text_border_radius']; }
    if (isset($input['pin_end_icon_size'])) { $settings['pin_end_icon_size'] = $input['pin_end_icon_size']; }
    if (isset($input['pin_end_image_size'])) { $settings['pin_end_image_size'] = $input['pin_end_image_size']; }
    if (isset($input['pin_end_text_padding'])) { $settings['pin_end_text_padding'] = $input['pin_end_text_padding']; }
    if (isset($input['pin_end_text_icon_color'])) { $settings['pin_end_text_icon_color'] = sanitize_text_field($input['pin_end_text_icon_color']); }
    if (isset($input['pin_end_text_border_color'])) { $settings['pin_end_text_border_color'] = sanitize_text_field($input['pin_end_text_border_color']); }
    if (isset($input['pin_end_text_border_radius'])) { $settings['pin_end_text_border_radius'] = $input['pin_end_text_border_radius']; }
    if (isset($input['content_gap_between'])) { $settings['content_gap_between'] = $input['content_gap_between']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
