<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-hotspot', [
'label' => __('Hotspot', 'theplus'),
    'description' => __('Adds The Plus "Hotspot" widget (tp-hotspot) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'hotspot_image' => ['type' => 'integer', 'description' => 'Hotspot Image (Image ID)'],
        'pin_title' => ['type' => 'string', 'description' => 'Title'],
        'select_option' => ['type' => 'string', 'description' => 'Pin Type', 'enum' => ['icon', 'lottie', 'text']],
        'lottieUrl' => ['type' => 'object', 'description' => 'Lottie URL'],
        'icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['font_awesome', 'font_awesome_5', 'icon_mind', 'select_option']],
        'icon_fontawesome' => ['type' => 'string', 'description' => 'Icon'],
        'icon_fontawesome_5' => ['type' => 'string', 'description' => 'Icon Library'],
        'icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['icon_style', 'select_option']],
        'pin_image' => ['type' => 'integer', 'description' => 'pin_image (Image ID)'],
        'pin_image_hover' => ['type' => 'integer', 'description' => 'Pin Hover Image (Image ID)'],
        'pin_text' => ['type' => 'string', 'description' => 'pin_text'],
        'icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'pin_bg_color' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'icon_hover_color' => ['type' => 'string', 'description' => 'Icon Hover Color (Color Hex/RGBA)'],
        'pin_hover_bg_color' => ['type' => 'string', 'description' => 'Background Hover Color (Color Hex/RGBA)'],
        'd_left_auto' => ['type' => 'string', 'description' => 'Left (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_xposition' => ['type' => 'object', 'description' => 'Left (Slider/Size Object)'],
        'd_right_auto' => ['type' => 'string', 'description' => 'Right (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_rightposition' => ['type' => 'object', 'description' => 'Right (Slider/Size Object)'],
        'd_top_auto' => ['type' => 'string', 'description' => 'Top (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_yposition' => ['type' => 'object', 'description' => 'Top (Slider/Size Object)'],
        'd_bottom_auto' => ['type' => 'string', 'description' => 'Bottom (Auto / %)', 'enum' => ['yes', 'no']],
        'd_pos_bottomposition' => ['type' => 'object', 'description' => 'Bottom (Slider/Size Object)'],
        't_responsive' => ['type' => 'string', 'description' => 'Responsive Values', 'enum' => ['yes', 'no']],
        't_left_auto' => ['type' => 'string', 'description' => 'Left (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_xposition' => ['type' => 'object', 'description' => 'Left (Slider/Size Object)'],
        't_right_auto' => ['type' => 'string', 'description' => 'Right (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_rightposition' => ['type' => 'object', 'description' => 'Right (Slider/Size Object)'],
        't_top_auto' => ['type' => 'string', 'description' => 'Top (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_yposition' => ['type' => 'object', 'description' => 'Top (Slider/Size Object)'],
        't_bottom_auto' => ['type' => 'string', 'description' => 'Bottom (Auto / %)', 'enum' => ['yes', 'no']],
        't_pos_bottomposition' => ['type' => 'object', 'description' => 'Bottom (Slider/Size Object)'],
        'm_responsive' => ['type' => 'string', 'description' => 'Responsive Values', 'enum' => ['yes', 'no']],
        'm_left_auto' => ['type' => 'string', 'description' => 'Left (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_xposition' => ['type' => 'object', 'description' => 'Left (Slider/Size Object)'],
        'm_right_auto' => ['type' => 'string', 'description' => 'Right (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_rightposition' => ['type' => 'object', 'description' => 'Right (Slider/Size Object)'],
        'm_top_auto' => ['type' => 'string', 'description' => 'Top (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_yposition' => ['type' => 'object', 'description' => 'Top (Slider/Size Object)'],
        'm_bottom_auto' => ['type' => 'string', 'description' => 'Bottom (Auto / %)', 'enum' => ['yes', 'no']],
        'm_pos_bottomposition' => ['type' => 'object', 'description' => 'Bottom (Slider/Size Object)'],
        'plus_tooltip_content_type' => ['type' => 'string', 'description' => 'Content Type', 'enum' => ['content_wysiwyg', 'normal_desc']],
        'plus_tooltip_content_desc' => ['type' => 'string', 'description' => 'Description'],
        'plus_tooltip_content_wysiwyg' => ['type' => 'string', 'description' => 'Tooltip Content'],
        'plus_tooltip_content_align' => ['type' => 'string', 'description' => 'Text Alignment', 'enum' => ['center', 'icon', 'left', 'plus_tooltip_content_type', 'right', '{{WRAPPER}} .pin-hotspot-loop{{CURRENT_ITEM}} .tippy-tooltip .tippy-content']],
        'plus_tooltip_content_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'image_effect' => ['type' => 'string', 'description' => 'Continues Effect', 'enum' => ['floating', 'hover_drop_waves', 'image-drop_waves', 'normal-drop_waves', 'pulse', 'tossing']],
        'drop_waves_color' => ['type' => 'string', 'description' => 'Drop Wave Color (Color Hex/RGBA)'],
        'hs_link_switch' => ['type' => 'string', 'description' => 'Link', 'enum' => ['yes', 'no']],
        'hs_link' => ['type' => 'object', 'description' => 'Link'],
        'pin_hotspot' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Add Multiple Pin Hotspot'],
        'pin_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'icon_width' => ['type' => 'object', 'description' => 'Pin Width (Slider/Size Object)'],
        'icon_radius' => ['type' => 'object', 'description' => 'Icon Radius (Dimensions Object)'],
        'pin_image_size' => ['type' => 'object', 'description' => 'Pin Image Size (Slider/Size Object)'],
        'pin_image_width' => ['type' => 'object', 'description' => 'Pin Image Width (Slider/Size Object)'],
        'image_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'text_padding' => ['type' => 'object', 'description' => 'Text Padding (Dimensions Object)'],
        'text_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'lottiedisplay' => ['type' => 'string', 'description' => 'Display', 'enum' => ['block', 'flex', 'inherit', 'initial', 'inline-block', 'inline-flex']],
        'lottieWidth' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'lottieHeight' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'lottieVertical' => ['type' => 'string', 'description' => 'Vertical Align', 'enum' => ['bottom', 'middle', 'top']],
        'lottieSpeed' => ['type' => 'object', 'description' => 'Speed (Slider/Size Object)'],
        'lottieLoop' => ['type' => 'string', 'description' => 'Loop Animation', 'enum' => ['yes', 'no']],
        'lottiehover' => ['type' => 'string', 'description' => 'Hover Animation', 'enum' => ['yes', 'no']],
        'icon_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'icon_background' => ['type' => 'string', 'description' => 'Background (Color Hex/RGBA)'],
        'cs_drop_waves_color' => ['type' => 'string', 'description' => 'Drop Wave Color (Color Hex/RGBA)'],
        'icon_color_h' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'icon_background_h' => ['type' => 'string', 'description' => 'Background (Color Hex/RGBA)'],
        'cs_tooltip_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'cs_tooltip_background' => ['type' => 'string', 'description' => 'Background (Color Hex/RGBA)'],
        'cs_tooltip_border_r' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'cs_tooltip_box_bf' => ['type' => 'string', 'description' => 'Backdrop Filter', 'enum' => ['yes', 'no']],
        'cs_tooltip_box_bf_blur' => ['type' => 'object', 'description' => 'Blur (Slider/Size Object)'],
        'cs_tooltip_box_bf_grayscale' => ['type' => 'object', 'description' => 'Grayscale (Slider/Size Object)'],
        'cs_tooltip_arrows_color' => ['type' => 'string', 'description' => 'Arrows Color (Color Hex/RGBA)'],
        'hotspot_img_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'overlay_color_option' => ['type' => 'string', 'description' => 'Hover Overlay Color', 'enum' => ['yes', 'no']],
        'tooltip_delay_visible' => ['type' => 'string', 'description' => 'tooltip_delay_visible', 'enum' => ['yes', 'no']],
        'tooltip_delay_time' => ['type' => 'object', 'description' => 'tooltip_delay_time (Slider/Size Object)'],
        'hot_spot_transform' => ['type' => 'string', 'description' => 'Transform css'],
        'animation_effects' => ['type' => 'string', 'description' => 'Choose Animation Effect'],
        'animation_delay' => ['type' => 'object', 'description' => 'Animation Delay (Slider/Size Object)'],
        'as_switch' => ['type' => 'string', 'description' => 'Animation Stagger', 'enum' => ['yes', 'no']],
        'animation_stagger' => ['type' => 'object', 'description' => 'Animation Stagger (Slider/Size Object)'],
        'animation_duration_default' => ['type' => 'string', 'description' => 'Animation Duration', 'enum' => ['yes', 'no']],
        'animate_duration' => ['type' => 'object', 'description' => 'Duration Speed (Slider/Size Object)'],
        'animation_out_effects' => ['type' => 'string', 'description' => 'Out Animation Effect', 'enum' => ['animation_effects!']],
        'animation_out_delay' => ['type' => 'object', 'description' => 'Out Animation Delay (Slider/Size Object)'],
        'animation_out_duration_default' => ['type' => 'string', 'description' => 'Out Animation Duration', 'enum' => ['yes', 'no']],
        'animation_out_duration' => ['type' => 'object', 'description' => 'Duration Speed (Slider/Size Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports pin animations, pulse effects, and custom tooltips.']
    ], 'required' => ['post_id', 'parent_id', 'hotspot_image'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_hotspot_ability',
    'permission_callback' => 'tpaep_mcp_theplus_hotspot_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_hotspot_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_hotspot_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-hotspot';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Hotspot widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (!empty($input['hotspot_image'])) { $settings['hotspot_image'] = ['id' => absint($input['hotspot_image'])]; }
    if (isset($input['pin_title'])) { $settings['pin_title'] = sanitize_text_field($input['pin_title']); }
    if (isset($input['select_option'])) { $settings['select_option'] = sanitize_text_field($input['select_option']); }
    if (isset($input['lottieUrl'])) { $settings['lottieUrl'] = $input['lottieUrl']; }
    if (isset($input['icon_style'])) { $settings['icon_style'] = sanitize_text_field($input['icon_style']); }
    if (isset($input['icon_fontawesome'])) { $settings['icon_fontawesome'] = sanitize_text_field($input['icon_fontawesome']); }
    if (isset($input['icon_fontawesome_5'])) { $settings['icon_fontawesome_5'] = sanitize_text_field($input['icon_fontawesome_5']); }
    if (isset($input['icons_mind'])) { $settings['icons_mind'] = sanitize_text_field($input['icons_mind']); }
    if (!empty($input['pin_image'])) { $settings['pin_image'] = ['id' => absint($input['pin_image'])]; }
    if (!empty($input['pin_image_hover'])) { $settings['pin_image_hover'] = ['id' => absint($input['pin_image_hover'])]; }
    if (isset($input['pin_text'])) { $settings['pin_text'] = sanitize_text_field($input['pin_text']); }
    if (isset($input['icon_color'])) { $settings['icon_color'] = sanitize_text_field($input['icon_color']); }
    if (isset($input['pin_bg_color'])) { $settings['pin_bg_color'] = sanitize_text_field($input['pin_bg_color']); }
    if (isset($input['icon_hover_color'])) { $settings['icon_hover_color'] = sanitize_text_field($input['icon_hover_color']); }
    if (isset($input['pin_hover_bg_color'])) { $settings['pin_hover_bg_color'] = sanitize_text_field($input['pin_hover_bg_color']); }
    if (isset($input['d_left_auto'])) { $settings['d_left_auto'] = sanitize_text_field($input['d_left_auto']); }
    if (isset($input['d_pos_xposition'])) { $settings['d_pos_xposition'] = $input['d_pos_xposition']; }
    if (isset($input['d_right_auto'])) { $settings['d_right_auto'] = sanitize_text_field($input['d_right_auto']); }
    if (isset($input['d_pos_rightposition'])) { $settings['d_pos_rightposition'] = $input['d_pos_rightposition']; }
    if (isset($input['d_top_auto'])) { $settings['d_top_auto'] = sanitize_text_field($input['d_top_auto']); }
    if (isset($input['d_pos_yposition'])) { $settings['d_pos_yposition'] = $input['d_pos_yposition']; }
    if (isset($input['d_bottom_auto'])) { $settings['d_bottom_auto'] = sanitize_text_field($input['d_bottom_auto']); }
    if (isset($input['d_pos_bottomposition'])) { $settings['d_pos_bottomposition'] = $input['d_pos_bottomposition']; }
    if (isset($input['t_responsive'])) { $settings['t_responsive'] = sanitize_text_field($input['t_responsive']); }
    if (isset($input['t_left_auto'])) { $settings['t_left_auto'] = sanitize_text_field($input['t_left_auto']); }
    if (isset($input['t_pos_xposition'])) { $settings['t_pos_xposition'] = $input['t_pos_xposition']; }
    if (isset($input['t_right_auto'])) { $settings['t_right_auto'] = sanitize_text_field($input['t_right_auto']); }
    if (isset($input['t_pos_rightposition'])) { $settings['t_pos_rightposition'] = $input['t_pos_rightposition']; }
    if (isset($input['t_top_auto'])) { $settings['t_top_auto'] = sanitize_text_field($input['t_top_auto']); }
    if (isset($input['t_pos_yposition'])) { $settings['t_pos_yposition'] = $input['t_pos_yposition']; }
    if (isset($input['t_bottom_auto'])) { $settings['t_bottom_auto'] = sanitize_text_field($input['t_bottom_auto']); }
    if (isset($input['t_pos_bottomposition'])) { $settings['t_pos_bottomposition'] = $input['t_pos_bottomposition']; }
    if (isset($input['m_responsive'])) { $settings['m_responsive'] = sanitize_text_field($input['m_responsive']); }
    if (isset($input['m_left_auto'])) { $settings['m_left_auto'] = sanitize_text_field($input['m_left_auto']); }
    if (isset($input['m_pos_xposition'])) { $settings['m_pos_xposition'] = $input['m_pos_xposition']; }
    if (isset($input['m_right_auto'])) { $settings['m_right_auto'] = sanitize_text_field($input['m_right_auto']); }
    if (isset($input['m_pos_rightposition'])) { $settings['m_pos_rightposition'] = $input['m_pos_rightposition']; }
    if (isset($input['m_top_auto'])) { $settings['m_top_auto'] = sanitize_text_field($input['m_top_auto']); }
    if (isset($input['m_pos_yposition'])) { $settings['m_pos_yposition'] = $input['m_pos_yposition']; }
    if (isset($input['m_bottom_auto'])) { $settings['m_bottom_auto'] = sanitize_text_field($input['m_bottom_auto']); }
    if (isset($input['m_pos_bottomposition'])) { $settings['m_pos_bottomposition'] = $input['m_pos_bottomposition']; }
    if (isset($input['plus_tooltip_content_type'])) { $settings['plus_tooltip_content_type'] = sanitize_text_field($input['plus_tooltip_content_type']); }
    if (isset($input['plus_tooltip_content_desc'])) { $settings['plus_tooltip_content_desc'] = sanitize_text_field($input['plus_tooltip_content_desc']); }
    if (isset($input['plus_tooltip_content_wysiwyg'])) { $settings['plus_tooltip_content_wysiwyg'] = sanitize_text_field($input['plus_tooltip_content_wysiwyg']); }
    if (isset($input['plus_tooltip_content_align'])) { $settings['plus_tooltip_content_align'] = sanitize_text_field($input['plus_tooltip_content_align']); }
    if (isset($input['plus_tooltip_content_color'])) { $settings['plus_tooltip_content_color'] = sanitize_text_field($input['plus_tooltip_content_color']); }
    if (isset($input['image_effect'])) { $settings['image_effect'] = sanitize_text_field($input['image_effect']); }
    if (isset($input['drop_waves_color'])) { $settings['drop_waves_color'] = sanitize_text_field($input['drop_waves_color']); }
    if (isset($input['hs_link_switch'])) { $settings['hs_link_switch'] = sanitize_text_field($input['hs_link_switch']); }
    if (isset($input['hs_link'])) { $settings['hs_link'] = $input['hs_link']; }
    if (isset($input['pin_hotspot'])) { $settings['pin_hotspot'] = $input['pin_hotspot']; }
    if (isset($input['pin_icon_size'])) { $settings['pin_icon_size'] = $input['pin_icon_size']; }
    if (isset($input['icon_width'])) { $settings['icon_width'] = $input['icon_width']; }
    if (isset($input['icon_radius'])) { $settings['icon_radius'] = $input['icon_radius']; }
    if (isset($input['pin_image_size'])) { $settings['pin_image_size'] = $input['pin_image_size']; }
    if (isset($input['pin_image_width'])) { $settings['pin_image_width'] = $input['pin_image_width']; }
    if (isset($input['image_border_radius'])) { $settings['image_border_radius'] = $input['image_border_radius']; }
    if (isset($input['text_padding'])) { $settings['text_padding'] = $input['text_padding']; }
    if (isset($input['text_border_radius'])) { $settings['text_border_radius'] = $input['text_border_radius']; }
    if (isset($input['lottiedisplay'])) { $settings['lottiedisplay'] = sanitize_text_field($input['lottiedisplay']); }
    if (isset($input['lottieWidth'])) { $settings['lottieWidth'] = $input['lottieWidth']; }
    if (isset($input['lottieHeight'])) { $settings['lottieHeight'] = $input['lottieHeight']; }
    if (isset($input['lottieVertical'])) { $settings['lottieVertical'] = sanitize_text_field($input['lottieVertical']); }
    if (isset($input['lottieSpeed'])) { $settings['lottieSpeed'] = $input['lottieSpeed']; }
    if (isset($input['lottieLoop'])) { $settings['lottieLoop'] = sanitize_text_field($input['lottieLoop']); }
    if (isset($input['lottiehover'])) { $settings['lottiehover'] = sanitize_text_field($input['lottiehover']); }
    if (isset($input['icon_color'])) { $settings['icon_color'] = sanitize_text_field($input['icon_color']); }
    if (isset($input['icon_background'])) { $settings['icon_background'] = sanitize_text_field($input['icon_background']); }
    if (isset($input['cs_drop_waves_color'])) { $settings['cs_drop_waves_color'] = sanitize_text_field($input['cs_drop_waves_color']); }
    if (isset($input['icon_color_h'])) { $settings['icon_color_h'] = sanitize_text_field($input['icon_color_h']); }
    if (isset($input['icon_background_h'])) { $settings['icon_background_h'] = sanitize_text_field($input['icon_background_h']); }
    if (isset($input['cs_tooltip_color'])) { $settings['cs_tooltip_color'] = sanitize_text_field($input['cs_tooltip_color']); }
    if (isset($input['cs_tooltip_background'])) { $settings['cs_tooltip_background'] = sanitize_text_field($input['cs_tooltip_background']); }
    if (isset($input['cs_tooltip_border_r'])) { $settings['cs_tooltip_border_r'] = $input['cs_tooltip_border_r']; }
    if (isset($input['cs_tooltip_box_bf'])) { $settings['cs_tooltip_box_bf'] = sanitize_text_field($input['cs_tooltip_box_bf']); }
    if (isset($input['cs_tooltip_box_bf_blur'])) { $settings['cs_tooltip_box_bf_blur'] = $input['cs_tooltip_box_bf_blur']; }
    if (isset($input['cs_tooltip_box_bf_grayscale'])) { $settings['cs_tooltip_box_bf_grayscale'] = $input['cs_tooltip_box_bf_grayscale']; }
    if (isset($input['cs_tooltip_arrows_color'])) { $settings['cs_tooltip_arrows_color'] = sanitize_text_field($input['cs_tooltip_arrows_color']); }
    if (isset($input['hotspot_img_br'])) { $settings['hotspot_img_br'] = $input['hotspot_img_br']; }
    if (isset($input['overlay_color_option'])) { $settings['overlay_color_option'] = sanitize_text_field($input['overlay_color_option']); }
    if (isset($input['tooltip_delay_visible'])) { $settings['tooltip_delay_visible'] = sanitize_text_field($input['tooltip_delay_visible']); }
    if (isset($input['tooltip_delay_time'])) { $settings['tooltip_delay_time'] = $input['tooltip_delay_time']; }
    if (isset($input['hot_spot_transform'])) { $settings['hot_spot_transform'] = sanitize_text_field($input['hot_spot_transform']); }
    if (isset($input['animation_effects'])) { $settings['animation_effects'] = sanitize_text_field($input['animation_effects']); }
    if (isset($input['animation_delay'])) { $settings['animation_delay'] = $input['animation_delay']; }
    if (isset($input['as_switch'])) { $settings['as_switch'] = sanitize_text_field($input['as_switch']); }
    if (isset($input['animation_stagger'])) { $settings['animation_stagger'] = $input['animation_stagger']; }
    if (isset($input['animation_duration_default'])) { $settings['animation_duration_default'] = sanitize_text_field($input['animation_duration_default']); }
    if (isset($input['animate_duration'])) { $settings['animate_duration'] = $input['animate_duration']; }
    if (isset($input['animation_out_effects'])) { $settings['animation_out_effects'] = sanitize_text_field($input['animation_out_effects']); }
    if (isset($input['animation_out_delay'])) { $settings['animation_out_delay'] = $input['animation_out_delay']; }
    if (isset($input['animation_out_duration_default'])) { $settings['animation_out_duration_default'] = sanitize_text_field($input['animation_out_duration_default']); }
    if (isset($input['animation_out_duration'])) { $settings['animation_out_duration'] = $input['animation_out_duration']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
