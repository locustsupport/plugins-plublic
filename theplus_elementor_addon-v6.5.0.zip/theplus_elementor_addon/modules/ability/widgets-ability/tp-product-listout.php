<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-product-listout', [
'label' => __('Product Listout', 'theplus'),
    'description' => __('Adds The Plus "Product Listout" widget (tp-product-listout) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'product_post_listing' => ['type' => 'string', 'description' => 'Product Listing Types', 'enum' => ['archive_listing', 'cross_sells', 'page_listing', 'recently_viewed', 'related_product', 'search_list', 'upsell', 'wishlist']],
        'related_product_by' => ['type' => 'string', 'description' => 'Related Post Type', 'enum' => ['both', 'category', 'product_post_listing', 'tags']],
        'style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['columns', 'custom', 'style-1', 'style-2', 'style-3']],
        'skin_template' => ['type' => 'string', 'description' => 'Select a template', 'enum' => ['style']],
        'multiple_skin_enable' => ['type' => 'string', 'description' => 'Multiple Loops', 'enum' => ['yes', 'no']],
        'skin_template2' => ['type' => 'string', 'description' => 'Loop Template 2', 'enum' => ['multiple_skin_enable', 'style']],
        'skin_template3' => ['type' => 'string', 'description' => 'Loop Template 3', 'enum' => ['multiple_skin_enable', 'style']],
        'skin_template4' => ['type' => 'string', 'description' => 'Loop Template 4', 'enum' => ['multiple_skin_enable', 'style']],
        'skin_template5' => ['type' => 'string', 'description' => 'Loop Template 5', 'enum' => ['multiple_skin_enable', 'style']],
        'template_order' => ['type' => 'string', 'description' => 'Template Order', 'enum' => ['random', 'reverse', 'style']],
        'layout' => ['type' => 'string', 'description' => 'Layout', 'enum' => ['carousel', 'columns', 'grid', 'masonry', 'metro']],
        'post_category' => ['type' => 'string', 'description' => 'Select Category', 'enum' => ['multiple', 'product_post_listing!']],
        'include_products' => ['type' => 'string', 'description' => 'Include Product(s)'],
        'exclude_products' => ['type' => 'string', 'description' => 'Exclude Product(s)'],
        'display_posts' => ['type' => 'string', 'description' => 'Maximum Posts Display'],
        'post_offset' => ['type' => 'string', 'description' => 'Offset Posts'],
        'post_order_by' => ['type' => 'string', 'description' => 'Order By'],
        'post_order' => ['type' => 'string', 'description' => 'Order'],
        'display_product' => ['type' => 'string', 'description' => 'Display Product', 'enum' => ['all', 'averagerating', 'featured', 'hightolowprice', 'instock', 'instock_backorder', 'latest', 'lowtohighprice', 'on_sale', 'outofstock', 'product_post_listing!', 'recent', 'top_rated', 'top_sales']],
        'desktop_column' => ['type' => 'string', 'description' => 'Desktop Column', 'enum' => ['layout!']],
        'tablet_column' => ['type' => 'string', 'description' => 'Tablet Column', 'enum' => ['layout!']],
        'mobile_column' => ['type' => 'string', 'description' => 'Mobile Column', 'enum' => ['layout!']],
        'metro_column' => ['type' => 'string', 'description' => 'Metro Column', 'enum' => ['3', '4', '5', '6', 'layout']],
        'metro_style_3' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_3' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_4' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_4' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_5' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_5' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_6' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['layout', 'metro_column']],
        'metro_custom_col_6' => ['type' => 'string', 'description' => 'Custom Layout'],
        'responsive_tablet_metro' => ['type' => 'string', 'description' => 'Tablet Responsive', 'enum' => ['yes', 'no']],
        'tablet_metro_column' => ['type' => 'string', 'description' => 'Metro Column', 'enum' => ['3', '4', '5', '6', 'layout', 'responsive_tablet_metro']],
        'tablet_metro_style_3' => ['type' => 'string', 'description' => 'Tablet Metro Style', 'enum' => ['layout', 'responsive_tablet_metro', 'tablet_metro_column']],
        'metro_custom_col_tab' => ['type' => 'string', 'description' => 'Custom Layout'],
        'columns_gap' => ['type' => 'object', 'description' => 'Columns Gap/Space Between (Dimensions Object)'],
        'filter_category' => ['type' => 'string', 'description' => 'Category Wise Filter', 'enum' => ['yes', 'no']],
        'TaxonomyType' => ['type' => 'string', 'description' => 'Select Taxonomy', 'enum' => ['filter_category']],
        'filter_type' => ['type' => 'string', 'description' => 'Filter Type', 'enum' => ['ajax_base', 'filter_category', 'normal']],
        'filter_search_type' => ['type' => 'string', 'description' => 'Search Type', 'enum' => ['filter_category', 'slug', 'term_id']],
        'all_filter_category_switch' => ['type' => 'string', 'description' => 'All Filter', 'enum' => ['yes', 'no']],
        'all_filter_category' => ['type' => 'string', 'description' => 'All Filter Category Text'],
        'filter_style' => ['type' => 'string', 'description' => 'Category Filter Style', 'enum' => ['filter_category', 'layout!', 'product_post_listing!']],
        'filter_hover_style' => ['type' => 'string', 'description' => 'Filter Hover Style', 'enum' => ['filter_category', 'layout!', 'product_post_listing!']],
        'filter_category_align' => ['type' => 'string', 'description' => 'Filter Alignment', 'enum' => ['center', 'filter_category', 'icon', 'layout!', 'left', 'product_post_listing!', 'right', 'toggle']],
        'post_extra_option' => ['type' => 'string', 'description' => 'More Post Loading Options', 'enum' => ['layout!', 'product_post_listing!']],
        'paginationType' => ['type' => 'string', 'description' => 'Pagination Type', 'enum' => ['ajaxbased', 'layout!', 'post_extra_option', 'product_post_listing!', 'standard']],
        'pagination_next' => ['type' => 'string', 'description' => 'Pagination Next'],
        'pagination_prev' => ['type' => 'string', 'description' => 'Pagination Previous'],
        'pagination_color' => ['type' => 'string', 'description' => 'Pagination Text Color (Color Hex/RGBA)'],
        'pagination_hover_color' => ['type' => 'string', 'description' => 'Pagination Hover Color (Color Hex/RGBA)'],
        'load_more_btn_text' => ['type' => 'string', 'description' => 'Button Text'],
        'tp_loading_text' => ['type' => 'string', 'description' => 'Loading Text'],
        'loaded_posts_text' => ['type' => 'string', 'description' => 'All Posts Loaded Text'],
        'load_more_post' => ['type' => 'string', 'description' => 'More posts on click/scroll'],
        'loading_text_color' => ['type' => 'string', 'description' => 'Loading Text Color (Color Hex/RGBA)'],
        'load_more_border' => ['type' => 'string', 'description' => 'Load More Border', 'enum' => ['yes', 'no']],
        'load_more_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['layout!', 'load_more_border', 'post_extra_option', 'product_post_listing!', '{{WRAPPER}} .ajax_load_more .post-load-more']],
        'load_more_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'load_more_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'load_more_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'load_more_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'load_more_border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'loaded_posts_color' => ['type' => 'string', 'description' => 'Loaded Posts Text Color (Color Hex/RGBA)'],
        'load_more_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'loading_spin_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'loading_spin_size' => ['type' => 'object', 'description' => 'Size (Slider/Size Object)'],
        'loading_spin_border_size' => ['type' => 'object', 'description' => 'Border Size (Slider/Size Object)'],
        'load_more_color_hover' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'post_title_tag' => ['type' => 'string', 'description' => 'Title Tag'],
        'variation_price_on' => ['type' => 'string', 'description' => 'Variable Product Price Range', 'enum' => ['yes', 'no']],
        'hide_outofstock_product' => ['type' => 'string', 'description' => 'Hide Out of Stock Product', 'enum' => ['yes', 'no']],
        'hover_image_on_off' => ['type' => 'string', 'description' => 'On Hover Image Change', 'enum' => ['yes', 'no']],
        'display_catagory' => ['type' => 'string', 'description' => 'Display Category', 'enum' => ['yes', 'no']],
        'display_rating' => ['type' => 'string', 'description' => 'Display Rating', 'enum' => ['yes', 'no']],
        'display_cart_button' => ['type' => 'string', 'description' => 'Cart Button Display', 'enum' => ['yes', 'no']],
        'dcb_single_product' => ['type' => 'string', 'description' => 'Add to Cart Text'],
        'dcb_variation_product' => ['type' => 'string', 'description' => 'Select Options Text'],
        'display_yith_list' => ['type' => 'string', 'description' => 'Display YITH Buttons', 'enum' => ['yes', 'no']],
        'display_yith_compare' => ['type' => 'string', 'description' => 'display_yith_compare', 'enum' => ['yes', 'no']],
        'display_yith_wishlist' => ['type' => 'string', 'description' => 'display_yith_wishlist', 'enum' => ['yes', 'no']],
        'display_yith_quickview' => ['type' => 'string', 'description' => 'Quick View', 'enum' => ['yes', 'no']],
        'display_theplus_quickview' => ['type' => 'string', 'description' => 'Display TP Quickview', 'enum' => ['yes', 'no']],
        'tpqc' => ['type' => 'string', 'description' => 'Quickview', 'enum' => ['custom_template', 'display_theplus_quickview']],
        'custom_template_select' => ['type' => 'string', 'description' => 'Template', 'enum' => ['display_theplus_quickview', 'tpqc']],
        'featured_image_type' => ['type' => 'string', 'description' => 'Featured Image Type', 'enum' => ['custom', 'full', 'grid', 'layout']],
        'display_thumbnail' => ['type' => 'string', 'description' => 'Display Image Size', 'enum' => ['yes', 'no']],
        'loading_options' => ['type' => 'string', 'description' => 'Loading Options', 'enum' => ['layout!', 'product_post_listing!', 'skeleton']],
        'filter_url' => ['type' => 'string', 'description' => 'URL Enable', 'enum' => ['yes', 'no']],
        'empty_posts_message' => ['type' => 'string', 'description' => 'empty_posts_message'],
        'pnfmsg_recvp' => ['type' => 'string', 'description' => 'Not Visited Any Product Notice', 'enum' => ['yes', 'no']],
        'tpaep_theme_builder' => ['type' => 'string', 'description' => 'tpaep_theme_builder'],
        'catagory_marign' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'catagory_color' => ['type' => 'string', 'description' => 'Category Color (Color Hex/RGBA)'],
        'catagory_hover_color' => ['type' => 'string', 'description' => 'Category Color (Color Hex/RGBA)'],
        'catagory_metro_background' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'post-catagory_metro_hover_background' => ['type' => 'string', 'description' => 'Background Hover Color (Color Hex/RGBA)'],
        'title_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'title_hover_color' => ['type' => 'string', 'description' => 'Title Color (Color Hex/RGBA)'],
        'title_metro_background' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'title_metro_hover_background' => ['type' => 'string', 'description' => 'Background Hover Color (Color Hex/RGBA)'],
        'rating_marign' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'rating_color' => ['type' => 'string', 'description' => 'Rating Color (Color Hex/RGBA)'],
        'rating_align' => ['type' => 'object', 'description' => 'Alignment', 'enum' => ['center', 'flex-end', 'flex-start', 'icon', '{{WRAPPER}} .product-list .woocommerce-product-rating']],
        'price_marign' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'price_color' => ['type' => 'string', 'description' => 'Price Color (Color Hex/RGBA)'],
        'price_hover_color' => ['type' => 'string', 'description' => 'Price Color (Color Hex/RGBA)'],
        'sale_price_color' => ['type' => 'string', 'description' => 'Previous Price Color (Color Hex/RGBA)'],
        'sale_price_hover_color' => ['type' => 'string', 'description' => 'Previous Price Color (Color Hex/RGBA)'],
        'price_metro_background' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'price_metro_hover_background' => ['type' => 'string', 'description' => 'Background Hover Color (Color Hex/RGBA)'],
        'b_dis_badge_switch' => ['type' => 'string', 'description' => 'Display Badge', 'enum' => ['yes', 'no']],
        'out_of_stock' => ['type' => 'string', 'description' => 'Out of Stock Text'],
        'b_outofstock_switch' => ['type' => 'string', 'description' => 'Out of Stock style', 'enum' => ['yes', 'no']],
        'b_outofstock_price' => ['type' => 'string', 'description' => 'Out of Stock Price', 'enum' => ['yes', 'no']],
        'b_outofstock_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'b_outofstock_bg' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'b_onsale_switch' => ['type' => 'string', 'description' => 'On sale Style', 'enum' => ['yes', 'no']],
        'b_onsale_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'b_onsale_bg' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'content_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'content_alignment' => ['type' => 'string', 'description' => 'Content Alignment', 'enum' => ['center', 'icon', 'left', 'right', 'toggle']],
        'image_border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'featured_image_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'featured_image_radius_hover' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'button_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'btn_text_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'btn_icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'button_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['dashed', 'dotted', 'groove', 'none', 'solid', 'style!', '{{WRAPPER}} .product-list .product-list-content .add_to_cart.product_type_simple']],
        'button_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'button_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'button_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'btn_text_hover_color' => ['type' => 'string', 'description' => 'Text Color (Color Hex/RGBA)'],
        'btn_icon_hover_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'button_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'button_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'quick_view_icon_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'quick_view_background' => ['type' => 'string', 'description' => 'Background Color (Color Hex/RGBA)'],
        'quick_view_icon_hover_color' => ['type' => 'string', 'description' => 'Icon Color (Color Hex/RGBA)'],
        'quick_view_hover_background' => ['type' => 'string', 'description' => 'Background Hover Color (Color Hex/RGBA)'],
        'yith_b_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'yith_b_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'yith_b_width' => ['type' => 'object', 'description' => 'Width (Slider/Size Object)'],
        'yith_b_height' => ['type' => 'object', 'description' => 'Height (Slider/Size Object)'],
        'yith_b_icon_size' => ['type' => 'object', 'description' => 'Icon Size (Slider/Size Object)'],
        'yith_b_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'yith_b_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'yith_b_color_h' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'yith_b_radius_h' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'yith_bb_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'yith_bb_margin' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'yith_bb_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'filter_category_padding' => ['type' => 'object', 'description' => 'Inner Padding (Dimensions Object)'],
        'filter_category_marign' => ['type' => 'object', 'description' => 'Margin (Dimensions Object)'],
        'filters_text_color' => ['type' => 'string', 'description' => 'Filters Text Color (Color Hex/RGBA)'],
        'filter_category_color' => ['type' => 'string', 'description' => 'Category Filter Color (Color Hex/RGBA)'],
        'filter_category_4_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'filter_category_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'filter_category_hover_color' => ['type' => 'string', 'description' => 'Category Filter Color (Color Hex/RGBA)'],
        'filter_category_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'filter_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color (Color Hex/RGBA)'],
        'category_count_color' => ['type' => 'string', 'description' => 'Category Count Color (Color Hex/RGBA)'],
        'category_count_bg_color' => ['type' => 'string', 'description' => 'Count Background Color (Color Hex/RGBA)'],
        'content_inner_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'box_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['box_border', '{{WRAPPER}} .product-list .post-inner-loop .grid-item .product-list-content']],
        'box_border_width' => ['type' => 'object', 'description' => 'Border Width (Dimensions Object)'],
        'box_border_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'border_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'box_border_hover_color' => ['type' => 'string', 'description' => 'Border Color (Color Hex/RGBA)'],
        'border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'carousel_unique_id' => ['type' => 'string', 'description' => 'Unique Carousel ID'],
        'slider_direction' => ['type' => 'string', 'description' => 'Slider Mode', 'enum' => ['horizontal', 'vertical']],
        'carousel_direction' => ['type' => 'string', 'description' => 'Slide Direction', 'enum' => ['ltr', 'rtl']],
        'slide_speed' => ['type' => 'object', 'description' => 'Slide Speed (Slider/Size Object)'],
        'slider_desktop_column' => ['type' => 'string', 'description' => 'Desktop Columns'],
        'steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_padding' => ['type' => 'object', 'description' => 'Slide Padding (Dimensions Object)'],
        'slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'multi_drag' => ['type' => 'string', 'description' => 'Multi Drag', 'enum' => ['yes', 'no']],
        'slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'slider_pause_hover' => ['type' => 'string', 'description' => 'Pause On Hover', 'enum' => ['yes', 'no']],
        'slider_adaptive_height' => ['type' => 'string', 'description' => 'Adaptive Height', 'enum' => ['yes', 'no']],
        'slider_animation' => ['type' => 'string', 'description' => 'Animation Type', 'enum' => ['ease', 'linear']],
        'slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['slider_dots', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['slider_arrows', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'slider_arrows', 'slider_arrows_style', 'top-right']],
        'arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'slider_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'slider_center_effects' => ['type' => 'string', 'description' => 'Center Slide Effects', 'enum' => ['slider_center_mode']],
        'scale_center_slide' => ['type' => 'object', 'description' => 'Center Slide Scale (Slider/Size Object)'],
        'scale_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Scale (Slider/Size Object)'],
        'opacity_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Opacity (Slider/Size Object)'],
        'slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3']],
        'slide_row_top_space' => ['type' => 'object', 'description' => 'Row Top Space (Slider/Size Object)'],
        'slider_tablet_column' => ['type' => 'string', 'description' => 'Tablet Columns'],
        'tablet_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_tablet' => ['type' => 'string', 'description' => 'Responsive Tablet', 'enum' => ['yes', 'no']],
        'tablet_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'tablet_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'tablet_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'tablet_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'tablet_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['slider_responsive_tablet', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7', 'tablet_slider_dots']],
        'tablet_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'tablet_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'tablet_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'tablet_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'tablet_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'tablet_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['slider_responsive_tablet', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'tablet_slider_arrows']],
        'tablet_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'slider_responsive_tablet', 'tablet_slider_arrows', 'tablet_slider_arrows_style', 'top-right']],
        'tablet_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'tablet_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'tablet_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'tablet_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'tablet_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'tablet_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'tablet_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3', 'slider_responsive_tablet']],
        'tablet_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'tablet_center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'slider_mobile_column' => ['type' => 'string', 'description' => 'Mobile Columns'],
        'mobile_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_mobile' => ['type' => 'string', 'description' => 'Responsive Mobile', 'enum' => ['yes', 'no']],
        'mobile_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'mobile_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'mobile_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'mobile_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed (Slider/Size Object)'],
        'mobile_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['mobile_slider_dots', 'slider_responsive_mobile', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'mobile_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color (Color Hex/RGBA)'],
        'mobile_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color (Color Hex/RGBA)'],
        'mobile_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color (Color Hex/RGBA)'],
        'mobile_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color (Color Hex/RGBA)'],
        'mobile_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding (Slider/Size Object)'],
        'mobile_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['mobile_slider_arrows', 'slider_responsive_mobile', 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'mobile_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['bottm-left', 'bottom-center', 'bottom-right', 'mobile_slider_arrows', 'mobile_slider_arrows_style', 'slider_responsive_mobile', 'top-right']],
        'mobile_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color (Color Hex/RGBA)'],
        'mobile_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color (Color Hex/RGBA)'],
        'mobile_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color (Color Hex/RGBA)'],
        'mobile_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color (Color Hex/RGBA)'],
        'mobile_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'mobile_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'mobile_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3', 'slider_responsive_mobile']],
        'mobile_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'mobile_center_padding' => ['type' => 'object', 'description' => 'Center Padding (Slider/Size Object)'],
        'pnf_padding' => ['type' => 'object', 'description' => 'Padding (Dimensions Object)'],
        'pnf_color' => ['type' => 'string', 'description' => 'Color (Color Hex/RGBA)'],
        'pnf_br' => ['type' => 'object', 'description' => 'Border Radius (Dimensions Object)'],
        'messy_column' => ['type' => 'string', 'description' => 'Messy Columns', 'enum' => ['yes', 'no']],
        'desktop_column_1' => ['type' => 'object', 'description' => 'Column 1 (Slider/Size Object)'],
        'desktop_column_2' => ['type' => 'object', 'description' => 'Column 2 (Slider/Size Object)'],
        'desktop_column_3' => ['type' => 'object', 'description' => 'Column 3 (Slider/Size Object)'],
        'desktop_column_4' => ['type' => 'object', 'description' => 'Column 4 (Slider/Size Object)'],
        'desktop_column_5' => ['type' => 'object', 'description' => 'Column 5 (Slider/Size Object)'],
        'desktop_column_6' => ['type' => 'object', 'description' => 'Column 6 (Slider/Size Object)'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Supports multi-category filters, smart grid animations, and WooCommerce SKU/stock toggles.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_product_listout_ability',
    'permission_callback' => 'tpaep_mcp_theplus_product_listout_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_product_listout_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_product_listout_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-product-listout';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Product Listout widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (isset($input['product_post_listing'])) { $settings['product_post_listing'] = sanitize_text_field($input['product_post_listing']); }
    if (isset($input['related_product_by'])) { $settings['related_product_by'] = sanitize_text_field($input['related_product_by']); }
    if (isset($input['style'])) { $settings['style'] = sanitize_text_field($input['style']); }
    if (isset($input['skin_template'])) { $settings['skin_template'] = sanitize_text_field($input['skin_template']); }
    if (isset($input['multiple_skin_enable'])) { $settings['multiple_skin_enable'] = sanitize_text_field($input['multiple_skin_enable']); }
    if (isset($input['skin_template2'])) { $settings['skin_template2'] = sanitize_text_field($input['skin_template2']); }
    if (isset($input['skin_template3'])) { $settings['skin_template3'] = sanitize_text_field($input['skin_template3']); }
    if (isset($input['skin_template4'])) { $settings['skin_template4'] = sanitize_text_field($input['skin_template4']); }
    if (isset($input['skin_template5'])) { $settings['skin_template5'] = sanitize_text_field($input['skin_template5']); }
    if (isset($input['template_order'])) { $settings['template_order'] = sanitize_text_field($input['template_order']); }
    if (isset($input['layout'])) { $settings['layout'] = sanitize_text_field($input['layout']); }
    if (isset($input['post_category'])) { $settings['post_category'] = sanitize_text_field($input['post_category']); }
    if (isset($input['include_products'])) { $settings['include_products'] = sanitize_text_field($input['include_products']); }
    if (isset($input['exclude_products'])) { $settings['exclude_products'] = sanitize_text_field($input['exclude_products']); }
    if (isset($input['display_posts'])) { $settings['display_posts'] = sanitize_text_field($input['display_posts']); }
    if (isset($input['post_offset'])) { $settings['post_offset'] = sanitize_text_field($input['post_offset']); }
    if (isset($input['post_order_by'])) { $settings['post_order_by'] = sanitize_text_field($input['post_order_by']); }
    if (isset($input['post_order'])) { $settings['post_order'] = sanitize_text_field($input['post_order']); }
    if (isset($input['display_product'])) { $settings['display_product'] = sanitize_text_field($input['display_product']); }
    if (isset($input['desktop_column'])) { $settings['desktop_column'] = sanitize_text_field($input['desktop_column']); }
    if (isset($input['tablet_column'])) { $settings['tablet_column'] = sanitize_text_field($input['tablet_column']); }
    if (isset($input['mobile_column'])) { $settings['mobile_column'] = sanitize_text_field($input['mobile_column']); }
    if (isset($input['metro_column'])) { $settings['metro_column'] = sanitize_text_field($input['metro_column']); }
    if (isset($input['metro_style_3'])) { $settings['metro_style_3'] = sanitize_text_field($input['metro_style_3']); }
    if (isset($input['metro_custom_col_3'])) { $settings['metro_custom_col_3'] = sanitize_text_field($input['metro_custom_col_3']); }
    if (isset($input['metro_style_4'])) { $settings['metro_style_4'] = sanitize_text_field($input['metro_style_4']); }
    if (isset($input['metro_custom_col_4'])) { $settings['metro_custom_col_4'] = sanitize_text_field($input['metro_custom_col_4']); }
    if (isset($input['metro_style_5'])) { $settings['metro_style_5'] = sanitize_text_field($input['metro_style_5']); }
    if (isset($input['metro_custom_col_5'])) { $settings['metro_custom_col_5'] = sanitize_text_field($input['metro_custom_col_5']); }
    if (isset($input['metro_style_6'])) { $settings['metro_style_6'] = sanitize_text_field($input['metro_style_6']); }
    if (isset($input['metro_custom_col_6'])) { $settings['metro_custom_col_6'] = sanitize_text_field($input['metro_custom_col_6']); }
    if (isset($input['responsive_tablet_metro'])) { $settings['responsive_tablet_metro'] = sanitize_text_field($input['responsive_tablet_metro']); }
    if (isset($input['tablet_metro_column'])) { $settings['tablet_metro_column'] = sanitize_text_field($input['tablet_metro_column']); }
    if (isset($input['tablet_metro_style_3'])) { $settings['tablet_metro_style_3'] = sanitize_text_field($input['tablet_metro_style_3']); }
    if (isset($input['metro_custom_col_tab'])) { $settings['metro_custom_col_tab'] = sanitize_text_field($input['metro_custom_col_tab']); }
    if (isset($input['columns_gap'])) { $settings['columns_gap'] = $input['columns_gap']; }
    if (isset($input['filter_category'])) { $settings['filter_category'] = sanitize_text_field($input['filter_category']); }
    if (isset($input['TaxonomyType'])) { $settings['TaxonomyType'] = sanitize_text_field($input['TaxonomyType']); }
    if (isset($input['filter_type'])) { $settings['filter_type'] = sanitize_text_field($input['filter_type']); }
    if (isset($input['filter_search_type'])) { $settings['filter_search_type'] = sanitize_text_field($input['filter_search_type']); }
    if (isset($input['all_filter_category_switch'])) { $settings['all_filter_category_switch'] = sanitize_text_field($input['all_filter_category_switch']); }
    if (isset($input['all_filter_category'])) { $settings['all_filter_category'] = sanitize_text_field($input['all_filter_category']); }
    if (isset($input['filter_style'])) { $settings['filter_style'] = sanitize_text_field($input['filter_style']); }
    if (isset($input['filter_hover_style'])) { $settings['filter_hover_style'] = sanitize_text_field($input['filter_hover_style']); }
    if (isset($input['filter_category_align'])) { $settings['filter_category_align'] = sanitize_text_field($input['filter_category_align']); }
    if (isset($input['post_extra_option'])) { $settings['post_extra_option'] = sanitize_text_field($input['post_extra_option']); }
    if (isset($input['paginationType'])) { $settings['paginationType'] = sanitize_text_field($input['paginationType']); }
    if (isset($input['pagination_next'])) { $settings['pagination_next'] = sanitize_text_field($input['pagination_next']); }
    if (isset($input['pagination_prev'])) { $settings['pagination_prev'] = sanitize_text_field($input['pagination_prev']); }
    if (isset($input['pagination_color'])) { $settings['pagination_color'] = sanitize_text_field($input['pagination_color']); }
    if (isset($input['pagination_hover_color'])) { $settings['pagination_hover_color'] = sanitize_text_field($input['pagination_hover_color']); }
    if (isset($input['load_more_btn_text'])) { $settings['load_more_btn_text'] = sanitize_text_field($input['load_more_btn_text']); }
    if (isset($input['tp_loading_text'])) { $settings['tp_loading_text'] = sanitize_text_field($input['tp_loading_text']); }
    if (isset($input['loaded_posts_text'])) { $settings['loaded_posts_text'] = sanitize_text_field($input['loaded_posts_text']); }
    if (isset($input['load_more_post'])) { $settings['load_more_post'] = sanitize_text_field($input['load_more_post']); }
    if (isset($input['loading_text_color'])) { $settings['loading_text_color'] = sanitize_text_field($input['loading_text_color']); }
    if (isset($input['load_more_border'])) { $settings['load_more_border'] = sanitize_text_field($input['load_more_border']); }
    if (isset($input['load_more_border_style'])) { $settings['load_more_border_style'] = sanitize_text_field($input['load_more_border_style']); }
    if (isset($input['load_more_border_width'])) { $settings['load_more_border_width'] = $input['load_more_border_width']; }
    if (isset($input['load_more_border_color'])) { $settings['load_more_border_color'] = sanitize_text_field($input['load_more_border_color']); }
    if (isset($input['load_more_border_radius'])) { $settings['load_more_border_radius'] = $input['load_more_border_radius']; }
    if (isset($input['load_more_border_hover_color'])) { $settings['load_more_border_hover_color'] = sanitize_text_field($input['load_more_border_hover_color']); }
    if (isset($input['load_more_border_hover_radius'])) { $settings['load_more_border_hover_radius'] = $input['load_more_border_hover_radius']; }
    if (isset($input['loaded_posts_color'])) { $settings['loaded_posts_color'] = sanitize_text_field($input['loaded_posts_color']); }
    if (isset($input['load_more_color'])) { $settings['load_more_color'] = sanitize_text_field($input['load_more_color']); }
    if (isset($input['loading_spin_color'])) { $settings['loading_spin_color'] = sanitize_text_field($input['loading_spin_color']); }
    if (isset($input['loading_spin_size'])) { $settings['loading_spin_size'] = $input['loading_spin_size']; }
    if (isset($input['loading_spin_border_size'])) { $settings['loading_spin_border_size'] = $input['loading_spin_border_size']; }
    if (isset($input['load_more_color_hover'])) { $settings['load_more_color_hover'] = sanitize_text_field($input['load_more_color_hover']); }
    if (isset($input['post_title_tag'])) { $settings['post_title_tag'] = sanitize_text_field($input['post_title_tag']); }
    if (isset($input['variation_price_on'])) { $settings['variation_price_on'] = sanitize_text_field($input['variation_price_on']); }
    if (isset($input['hide_outofstock_product'])) { $settings['hide_outofstock_product'] = sanitize_text_field($input['hide_outofstock_product']); }
    if (isset($input['hover_image_on_off'])) { $settings['hover_image_on_off'] = sanitize_text_field($input['hover_image_on_off']); }
    if (isset($input['display_catagory'])) { $settings['display_catagory'] = sanitize_text_field($input['display_catagory']); }
    if (isset($input['display_rating'])) { $settings['display_rating'] = sanitize_text_field($input['display_rating']); }
    if (isset($input['display_cart_button'])) { $settings['display_cart_button'] = sanitize_text_field($input['display_cart_button']); }
    if (isset($input['dcb_single_product'])) { $settings['dcb_single_product'] = sanitize_text_field($input['dcb_single_product']); }
    if (isset($input['dcb_variation_product'])) { $settings['dcb_variation_product'] = sanitize_text_field($input['dcb_variation_product']); }
    if (isset($input['display_yith_list'])) { $settings['display_yith_list'] = sanitize_text_field($input['display_yith_list']); }
    if (isset($input['display_yith_compare'])) { $settings['display_yith_compare'] = sanitize_text_field($input['display_yith_compare']); }
    if (isset($input['display_yith_wishlist'])) { $settings['display_yith_wishlist'] = sanitize_text_field($input['display_yith_wishlist']); }
    if (isset($input['display_yith_quickview'])) { $settings['display_yith_quickview'] = sanitize_text_field($input['display_yith_quickview']); }
    if (isset($input['display_theplus_quickview'])) { $settings['display_theplus_quickview'] = sanitize_text_field($input['display_theplus_quickview']); }
    if (isset($input['tpqc'])) { $settings['tpqc'] = sanitize_text_field($input['tpqc']); }
    if (isset($input['custom_template_select'])) { $settings['custom_template_select'] = sanitize_text_field($input['custom_template_select']); }
    if (isset($input['featured_image_type'])) { $settings['featured_image_type'] = sanitize_text_field($input['featured_image_type']); }
    if (isset($input['display_thumbnail'])) { $settings['display_thumbnail'] = sanitize_text_field($input['display_thumbnail']); }
    if (isset($input['loading_options'])) { $settings['loading_options'] = sanitize_text_field($input['loading_options']); }
    if (isset($input['filter_url'])) { $settings['filter_url'] = sanitize_text_field($input['filter_url']); }
    if (isset($input['empty_posts_message'])) { $settings['empty_posts_message'] = sanitize_text_field($input['empty_posts_message']); }
    if (isset($input['pnfmsg_recvp'])) { $settings['pnfmsg_recvp'] = sanitize_text_field($input['pnfmsg_recvp']); }
    if (isset($input['tpaep_theme_builder'])) { $settings['tpaep_theme_builder'] = sanitize_text_field($input['tpaep_theme_builder']); }
    if (isset($input['catagory_marign'])) { $settings['catagory_marign'] = $input['catagory_marign']; }
    if (isset($input['catagory_color'])) { $settings['catagory_color'] = sanitize_text_field($input['catagory_color']); }
    if (isset($input['catagory_hover_color'])) { $settings['catagory_hover_color'] = sanitize_text_field($input['catagory_hover_color']); }
    if (isset($input['catagory_metro_background'])) { $settings['catagory_metro_background'] = sanitize_text_field($input['catagory_metro_background']); }
    if (isset($input['post-catagory_metro_hover_background'])) { $settings['post-catagory_metro_hover_background'] = sanitize_text_field($input['post-catagory_metro_hover_background']); }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['title_hover_color'])) { $settings['title_hover_color'] = sanitize_text_field($input['title_hover_color']); }
    if (isset($input['title_metro_background'])) { $settings['title_metro_background'] = sanitize_text_field($input['title_metro_background']); }
    if (isset($input['title_metro_hover_background'])) { $settings['title_metro_hover_background'] = sanitize_text_field($input['title_metro_hover_background']); }
    if (isset($input['rating_marign'])) { $settings['rating_marign'] = $input['rating_marign']; }
    if (isset($input['rating_color'])) { $settings['rating_color'] = sanitize_text_field($input['rating_color']); }
    if (isset($input['rating_align'])) { $settings['rating_align'] = $input['rating_align']; }
    if (isset($input['price_marign'])) { $settings['price_marign'] = $input['price_marign']; }
    if (isset($input['price_color'])) { $settings['price_color'] = sanitize_text_field($input['price_color']); }
    if (isset($input['price_hover_color'])) { $settings['price_hover_color'] = sanitize_text_field($input['price_hover_color']); }
    if (isset($input['sale_price_color'])) { $settings['sale_price_color'] = sanitize_text_field($input['sale_price_color']); }
    if (isset($input['sale_price_hover_color'])) { $settings['sale_price_hover_color'] = sanitize_text_field($input['sale_price_hover_color']); }
    if (isset($input['price_metro_background'])) { $settings['price_metro_background'] = sanitize_text_field($input['price_metro_background']); }
    if (isset($input['price_metro_hover_background'])) { $settings['price_metro_hover_background'] = sanitize_text_field($input['price_metro_hover_background']); }
    if (isset($input['b_dis_badge_switch'])) { $settings['b_dis_badge_switch'] = sanitize_text_field($input['b_dis_badge_switch']); }
    if (isset($input['out_of_stock'])) { $settings['out_of_stock'] = sanitize_text_field($input['out_of_stock']); }
    if (isset($input['b_outofstock_switch'])) { $settings['b_outofstock_switch'] = sanitize_text_field($input['b_outofstock_switch']); }
    if (isset($input['b_outofstock_price'])) { $settings['b_outofstock_price'] = sanitize_text_field($input['b_outofstock_price']); }
    if (isset($input['b_outofstock_color'])) { $settings['b_outofstock_color'] = sanitize_text_field($input['b_outofstock_color']); }
    if (isset($input['b_outofstock_bg'])) { $settings['b_outofstock_bg'] = sanitize_text_field($input['b_outofstock_bg']); }
    if (isset($input['b_onsale_switch'])) { $settings['b_onsale_switch'] = sanitize_text_field($input['b_onsale_switch']); }
    if (isset($input['b_onsale_color'])) { $settings['b_onsale_color'] = sanitize_text_field($input['b_onsale_color']); }
    if (isset($input['b_onsale_bg'])) { $settings['b_onsale_bg'] = sanitize_text_field($input['b_onsale_bg']); }
    if (isset($input['content_padding'])) { $settings['content_padding'] = $input['content_padding']; }
    if (isset($input['content_alignment'])) { $settings['content_alignment'] = sanitize_text_field($input['content_alignment']); }
    if (isset($input['image_border_radius'])) { $settings['image_border_radius'] = $input['image_border_radius']; }
    if (isset($input['featured_image_radius'])) { $settings['featured_image_radius'] = $input['featured_image_radius']; }
    if (isset($input['featured_image_radius_hover'])) { $settings['featured_image_radius_hover'] = $input['featured_image_radius_hover']; }
    if (isset($input['button_padding'])) { $settings['button_padding'] = $input['button_padding']; }
    if (isset($input['btn_text_color'])) { $settings['btn_text_color'] = sanitize_text_field($input['btn_text_color']); }
    if (isset($input['btn_icon_color'])) { $settings['btn_icon_color'] = sanitize_text_field($input['btn_icon_color']); }
    if (isset($input['button_border_style'])) { $settings['button_border_style'] = sanitize_text_field($input['button_border_style']); }
    if (isset($input['button_border_width'])) { $settings['button_border_width'] = $input['button_border_width']; }
    if (isset($input['button_border_color'])) { $settings['button_border_color'] = sanitize_text_field($input['button_border_color']); }
    if (isset($input['button_radius'])) { $settings['button_radius'] = $input['button_radius']; }
    if (isset($input['btn_text_hover_color'])) { $settings['btn_text_hover_color'] = sanitize_text_field($input['btn_text_hover_color']); }
    if (isset($input['btn_icon_hover_color'])) { $settings['btn_icon_hover_color'] = sanitize_text_field($input['btn_icon_hover_color']); }
    if (isset($input['button_border_hover_color'])) { $settings['button_border_hover_color'] = sanitize_text_field($input['button_border_hover_color']); }
    if (isset($input['button_hover_radius'])) { $settings['button_hover_radius'] = $input['button_hover_radius']; }
    if (isset($input['quick_view_icon_color'])) { $settings['quick_view_icon_color'] = sanitize_text_field($input['quick_view_icon_color']); }
    if (isset($input['quick_view_background'])) { $settings['quick_view_background'] = sanitize_text_field($input['quick_view_background']); }
    if (isset($input['quick_view_icon_hover_color'])) { $settings['quick_view_icon_hover_color'] = sanitize_text_field($input['quick_view_icon_hover_color']); }
    if (isset($input['quick_view_hover_background'])) { $settings['quick_view_hover_background'] = sanitize_text_field($input['quick_view_hover_background']); }
    if (isset($input['yith_b_padding'])) { $settings['yith_b_padding'] = $input['yith_b_padding']; }
    if (isset($input['yith_b_margin'])) { $settings['yith_b_margin'] = $input['yith_b_margin']; }
    if (isset($input['yith_b_width'])) { $settings['yith_b_width'] = $input['yith_b_width']; }
    if (isset($input['yith_b_height'])) { $settings['yith_b_height'] = $input['yith_b_height']; }
    if (isset($input['yith_b_icon_size'])) { $settings['yith_b_icon_size'] = $input['yith_b_icon_size']; }
    if (isset($input['yith_b_color'])) { $settings['yith_b_color'] = sanitize_text_field($input['yith_b_color']); }
    if (isset($input['yith_b_radius'])) { $settings['yith_b_radius'] = $input['yith_b_radius']; }
    if (isset($input['yith_b_color_h'])) { $settings['yith_b_color_h'] = sanitize_text_field($input['yith_b_color_h']); }
    if (isset($input['yith_b_radius_h'])) { $settings['yith_b_radius_h'] = $input['yith_b_radius_h']; }
    if (isset($input['yith_bb_padding'])) { $settings['yith_bb_padding'] = $input['yith_bb_padding']; }
    if (isset($input['yith_bb_margin'])) { $settings['yith_bb_margin'] = $input['yith_bb_margin']; }
    if (isset($input['yith_bb_br'])) { $settings['yith_bb_br'] = $input['yith_bb_br']; }
    if (isset($input['filter_category_padding'])) { $settings['filter_category_padding'] = $input['filter_category_padding']; }
    if (isset($input['filter_category_marign'])) { $settings['filter_category_marign'] = $input['filter_category_marign']; }
    if (isset($input['filters_text_color'])) { $settings['filters_text_color'] = sanitize_text_field($input['filters_text_color']); }
    if (isset($input['filter_category_color'])) { $settings['filter_category_color'] = sanitize_text_field($input['filter_category_color']); }
    if (isset($input['filter_category_4_border_color'])) { $settings['filter_category_4_border_color'] = sanitize_text_field($input['filter_category_4_border_color']); }
    if (isset($input['filter_category_radius'])) { $settings['filter_category_radius'] = $input['filter_category_radius']; }
    if (isset($input['filter_category_hover_color'])) { $settings['filter_category_hover_color'] = sanitize_text_field($input['filter_category_hover_color']); }
    if (isset($input['filter_category_hover_radius'])) { $settings['filter_category_hover_radius'] = $input['filter_category_hover_radius']; }
    if (isset($input['filter_border_hover_color'])) { $settings['filter_border_hover_color'] = sanitize_text_field($input['filter_border_hover_color']); }
    if (isset($input['category_count_color'])) { $settings['category_count_color'] = sanitize_text_field($input['category_count_color']); }
    if (isset($input['category_count_bg_color'])) { $settings['category_count_bg_color'] = sanitize_text_field($input['category_count_bg_color']); }
    if (isset($input['content_inner_padding'])) { $settings['content_inner_padding'] = $input['content_inner_padding']; }
    if (isset($input['box_border'])) { $settings['box_border'] = sanitize_text_field($input['box_border']); }
    if (isset($input['border_style'])) { $settings['border_style'] = sanitize_text_field($input['border_style']); }
    if (isset($input['box_border_width'])) { $settings['box_border_width'] = $input['box_border_width']; }
    if (isset($input['box_border_color'])) { $settings['box_border_color'] = sanitize_text_field($input['box_border_color']); }
    if (isset($input['border_radius'])) { $settings['border_radius'] = $input['border_radius']; }
    if (isset($input['box_border_hover_color'])) { $settings['box_border_hover_color'] = sanitize_text_field($input['box_border_hover_color']); }
    if (isset($input['border_hover_radius'])) { $settings['border_hover_radius'] = $input['border_hover_radius']; }
    if (isset($input['carousel_unique_id'])) { $settings['carousel_unique_id'] = sanitize_text_field($input['carousel_unique_id']); }
    if (isset($input['slider_direction'])) { $settings['slider_direction'] = sanitize_text_field($input['slider_direction']); }
    if (isset($input['carousel_direction'])) { $settings['carousel_direction'] = sanitize_text_field($input['carousel_direction']); }
    if (isset($input['slide_speed'])) { $settings['slide_speed'] = $input['slide_speed']; }
    if (isset($input['slider_desktop_column'])) { $settings['slider_desktop_column'] = sanitize_text_field($input['slider_desktop_column']); }
    if (isset($input['steps_slide'])) { $settings['steps_slide'] = sanitize_text_field($input['steps_slide']); }
    if (isset($input['slider_padding'])) { $settings['slider_padding'] = $input['slider_padding']; }
    if (isset($input['slider_draggable'])) { $settings['slider_draggable'] = sanitize_text_field($input['slider_draggable']); }
    if (isset($input['multi_drag'])) { $settings['multi_drag'] = sanitize_text_field($input['multi_drag']); }
    if (isset($input['slider_infinite'])) { $settings['slider_infinite'] = sanitize_text_field($input['slider_infinite']); }
    if (isset($input['slider_pause_hover'])) { $settings['slider_pause_hover'] = sanitize_text_field($input['slider_pause_hover']); }
    if (isset($input['slider_adaptive_height'])) { $settings['slider_adaptive_height'] = sanitize_text_field($input['slider_adaptive_height']); }
    if (isset($input['slider_animation'])) { $settings['slider_animation'] = sanitize_text_field($input['slider_animation']); }
    if (isset($input['slider_autoplay'])) { $settings['slider_autoplay'] = sanitize_text_field($input['slider_autoplay']); }
    if (isset($input['autoplay_speed'])) { $settings['autoplay_speed'] = $input['autoplay_speed']; }
    if (isset($input['slider_dots'])) { $settings['slider_dots'] = sanitize_text_field($input['slider_dots']); }
    if (isset($input['slider_dots_style'])) { $settings['slider_dots_style'] = sanitize_text_field($input['slider_dots_style']); }
    if (isset($input['dots_border_color'])) { $settings['dots_border_color'] = sanitize_text_field($input['dots_border_color']); }
    if (isset($input['dots_bg_color'])) { $settings['dots_bg_color'] = sanitize_text_field($input['dots_bg_color']); }
    if (isset($input['dots_active_border_color'])) { $settings['dots_active_border_color'] = sanitize_text_field($input['dots_active_border_color']); }
    if (isset($input['dots_active_bg_color'])) { $settings['dots_active_bg_color'] = sanitize_text_field($input['dots_active_bg_color']); }
    if (isset($input['dots_top_padding'])) { $settings['dots_top_padding'] = $input['dots_top_padding']; }
    if (isset($input['hover_show_dots'])) { $settings['hover_show_dots'] = sanitize_text_field($input['hover_show_dots']); }
    if (isset($input['slider_arrows'])) { $settings['slider_arrows'] = sanitize_text_field($input['slider_arrows']); }
    if (isset($input['slider_arrows_style'])) { $settings['slider_arrows_style'] = sanitize_text_field($input['slider_arrows_style']); }
    if (isset($input['arrows_position'])) { $settings['arrows_position'] = sanitize_text_field($input['arrows_position']); }
    if (isset($input['arrow_bg_color'])) { $settings['arrow_bg_color'] = sanitize_text_field($input['arrow_bg_color']); }
    if (isset($input['arrow_icon_color'])) { $settings['arrow_icon_color'] = sanitize_text_field($input['arrow_icon_color']); }
    if (isset($input['arrow_hover_bg_color'])) { $settings['arrow_hover_bg_color'] = sanitize_text_field($input['arrow_hover_bg_color']); }
    if (isset($input['arrow_hover_icon_color'])) { $settings['arrow_hover_icon_color'] = sanitize_text_field($input['arrow_hover_icon_color']); }
    if (isset($input['outer_section_arrow'])) { $settings['outer_section_arrow'] = sanitize_text_field($input['outer_section_arrow']); }
    if (isset($input['hover_show_arrow'])) { $settings['hover_show_arrow'] = sanitize_text_field($input['hover_show_arrow']); }
    if (isset($input['slider_center_mode'])) { $settings['slider_center_mode'] = sanitize_text_field($input['slider_center_mode']); }
    if (isset($input['center_padding'])) { $settings['center_padding'] = $input['center_padding']; }
    if (isset($input['slider_center_effects'])) { $settings['slider_center_effects'] = sanitize_text_field($input['slider_center_effects']); }
    if (isset($input['scale_center_slide'])) { $settings['scale_center_slide'] = $input['scale_center_slide']; }
    if (isset($input['scale_normal_slide'])) { $settings['scale_normal_slide'] = $input['scale_normal_slide']; }
    if (isset($input['opacity_normal_slide'])) { $settings['opacity_normal_slide'] = $input['opacity_normal_slide']; }
    if (isset($input['slider_rows'])) { $settings['slider_rows'] = sanitize_text_field($input['slider_rows']); }
    if (isset($input['slide_row_top_space'])) { $settings['slide_row_top_space'] = $input['slide_row_top_space']; }
    if (isset($input['slider_tablet_column'])) { $settings['slider_tablet_column'] = sanitize_text_field($input['slider_tablet_column']); }
    if (isset($input['tablet_steps_slide'])) { $settings['tablet_steps_slide'] = sanitize_text_field($input['tablet_steps_slide']); }
    if (isset($input['slider_responsive_tablet'])) { $settings['slider_responsive_tablet'] = sanitize_text_field($input['slider_responsive_tablet']); }
    if (isset($input['tablet_slider_draggable'])) { $settings['tablet_slider_draggable'] = sanitize_text_field($input['tablet_slider_draggable']); }
    if (isset($input['tablet_slider_infinite'])) { $settings['tablet_slider_infinite'] = sanitize_text_field($input['tablet_slider_infinite']); }
    if (isset($input['tablet_slider_autoplay'])) { $settings['tablet_slider_autoplay'] = sanitize_text_field($input['tablet_slider_autoplay']); }
    if (isset($input['tablet_autoplay_speed'])) { $settings['tablet_autoplay_speed'] = $input['tablet_autoplay_speed']; }
    if (isset($input['tablet_slider_dots'])) { $settings['tablet_slider_dots'] = sanitize_text_field($input['tablet_slider_dots']); }
    if (isset($input['tablet_slider_dots_style'])) { $settings['tablet_slider_dots_style'] = sanitize_text_field($input['tablet_slider_dots_style']); }
    if (isset($input['tablet_dots_border_color'])) { $settings['tablet_dots_border_color'] = sanitize_text_field($input['tablet_dots_border_color']); }
    if (isset($input['tablet_dots_bg_color'])) { $settings['tablet_dots_bg_color'] = sanitize_text_field($input['tablet_dots_bg_color']); }
    if (isset($input['tablet_dots_active_border_color'])) { $settings['tablet_dots_active_border_color'] = sanitize_text_field($input['tablet_dots_active_border_color']); }
    if (isset($input['tablet_dots_active_bg_color'])) { $settings['tablet_dots_active_bg_color'] = sanitize_text_field($input['tablet_dots_active_bg_color']); }
    if (isset($input['tablet_dots_top_padding'])) { $settings['tablet_dots_top_padding'] = $input['tablet_dots_top_padding']; }
    if (isset($input['tablet_hover_show_dots'])) { $settings['tablet_hover_show_dots'] = sanitize_text_field($input['tablet_hover_show_dots']); }
    if (isset($input['tablet_slider_arrows'])) { $settings['tablet_slider_arrows'] = sanitize_text_field($input['tablet_slider_arrows']); }
    if (isset($input['tablet_slider_arrows_style'])) { $settings['tablet_slider_arrows_style'] = sanitize_text_field($input['tablet_slider_arrows_style']); }
    if (isset($input['tablet_arrows_position'])) { $settings['tablet_arrows_position'] = sanitize_text_field($input['tablet_arrows_position']); }
    if (isset($input['tablet_arrow_bg_color'])) { $settings['tablet_arrow_bg_color'] = sanitize_text_field($input['tablet_arrow_bg_color']); }
    if (isset($input['tablet_arrow_icon_color'])) { $settings['tablet_arrow_icon_color'] = sanitize_text_field($input['tablet_arrow_icon_color']); }
    if (isset($input['tablet_arrow_hover_bg_color'])) { $settings['tablet_arrow_hover_bg_color'] = sanitize_text_field($input['tablet_arrow_hover_bg_color']); }
    if (isset($input['tablet_arrow_hover_icon_color'])) { $settings['tablet_arrow_hover_icon_color'] = sanitize_text_field($input['tablet_arrow_hover_icon_color']); }
    if (isset($input['tablet_outer_section_arrow'])) { $settings['tablet_outer_section_arrow'] = sanitize_text_field($input['tablet_outer_section_arrow']); }
    if (isset($input['tablet_hover_show_arrow'])) { $settings['tablet_hover_show_arrow'] = sanitize_text_field($input['tablet_hover_show_arrow']); }
    if (isset($input['tablet_slider_rows'])) { $settings['tablet_slider_rows'] = sanitize_text_field($input['tablet_slider_rows']); }
    if (isset($input['tablet_center_mode'])) { $settings['tablet_center_mode'] = sanitize_text_field($input['tablet_center_mode']); }
    if (isset($input['tablet_center_padding'])) { $settings['tablet_center_padding'] = $input['tablet_center_padding']; }
    if (isset($input['slider_mobile_column'])) { $settings['slider_mobile_column'] = sanitize_text_field($input['slider_mobile_column']); }
    if (isset($input['mobile_steps_slide'])) { $settings['mobile_steps_slide'] = sanitize_text_field($input['mobile_steps_slide']); }
    if (isset($input['slider_responsive_mobile'])) { $settings['slider_responsive_mobile'] = sanitize_text_field($input['slider_responsive_mobile']); }
    if (isset($input['mobile_slider_draggable'])) { $settings['mobile_slider_draggable'] = sanitize_text_field($input['mobile_slider_draggable']); }
    if (isset($input['mobile_slider_infinite'])) { $settings['mobile_slider_infinite'] = sanitize_text_field($input['mobile_slider_infinite']); }
    if (isset($input['mobile_slider_autoplay'])) { $settings['mobile_slider_autoplay'] = sanitize_text_field($input['mobile_slider_autoplay']); }
    if (isset($input['mobile_autoplay_speed'])) { $settings['mobile_autoplay_speed'] = $input['mobile_autoplay_speed']; }
    if (isset($input['mobile_slider_dots'])) { $settings['mobile_slider_dots'] = sanitize_text_field($input['mobile_slider_dots']); }
    if (isset($input['mobile_slider_dots_style'])) { $settings['mobile_slider_dots_style'] = sanitize_text_field($input['mobile_slider_dots_style']); }
    if (isset($input['mobile_dots_border_color'])) { $settings['mobile_dots_border_color'] = sanitize_text_field($input['mobile_dots_border_color']); }
    if (isset($input['mobile_dots_bg_color'])) { $settings['mobile_dots_bg_color'] = sanitize_text_field($input['mobile_dots_bg_color']); }
    if (isset($input['mobile_dots_active_border_color'])) { $settings['mobile_dots_active_border_color'] = sanitize_text_field($input['mobile_dots_active_border_color']); }
    if (isset($input['mobile_dots_active_bg_color'])) { $settings['mobile_dots_active_bg_color'] = sanitize_text_field($input['mobile_dots_active_bg_color']); }
    if (isset($input['mobile_dots_top_padding'])) { $settings['mobile_dots_top_padding'] = $input['mobile_dots_top_padding']; }
    if (isset($input['mobile_hover_show_dots'])) { $settings['mobile_hover_show_dots'] = sanitize_text_field($input['mobile_hover_show_dots']); }
    if (isset($input['mobile_slider_arrows'])) { $settings['mobile_slider_arrows'] = sanitize_text_field($input['mobile_slider_arrows']); }
    if (isset($input['mobile_slider_arrows_style'])) { $settings['mobile_slider_arrows_style'] = sanitize_text_field($input['mobile_slider_arrows_style']); }
    if (isset($input['mobile_arrows_position'])) { $settings['mobile_arrows_position'] = sanitize_text_field($input['mobile_arrows_position']); }
    if (isset($input['mobile_arrow_bg_color'])) { $settings['mobile_arrow_bg_color'] = sanitize_text_field($input['mobile_arrow_bg_color']); }
    if (isset($input['mobile_arrow_icon_color'])) { $settings['mobile_arrow_icon_color'] = sanitize_text_field($input['mobile_arrow_icon_color']); }
    if (isset($input['mobile_arrow_hover_bg_color'])) { $settings['mobile_arrow_hover_bg_color'] = sanitize_text_field($input['mobile_arrow_hover_bg_color']); }
    if (isset($input['mobile_arrow_hover_icon_color'])) { $settings['mobile_arrow_hover_icon_color'] = sanitize_text_field($input['mobile_arrow_hover_icon_color']); }
    if (isset($input['mobile_outer_section_arrow'])) { $settings['mobile_outer_section_arrow'] = sanitize_text_field($input['mobile_outer_section_arrow']); }
    if (isset($input['mobile_hover_show_arrow'])) { $settings['mobile_hover_show_arrow'] = sanitize_text_field($input['mobile_hover_show_arrow']); }
    if (isset($input['mobile_slider_rows'])) { $settings['mobile_slider_rows'] = sanitize_text_field($input['mobile_slider_rows']); }
    if (isset($input['mobile_center_mode'])) { $settings['mobile_center_mode'] = sanitize_text_field($input['mobile_center_mode']); }
    if (isset($input['mobile_center_padding'])) { $settings['mobile_center_padding'] = $input['mobile_center_padding']; }
    if (isset($input['pnf_padding'])) { $settings['pnf_padding'] = $input['pnf_padding']; }
    if (isset($input['pnf_color'])) { $settings['pnf_color'] = sanitize_text_field($input['pnf_color']); }
    if (isset($input['pnf_br'])) { $settings['pnf_br'] = $input['pnf_br']; }
    if (isset($input['messy_column'])) { $settings['messy_column'] = sanitize_text_field($input['messy_column']); }
    if (isset($input['desktop_column_1'])) { $settings['desktop_column_1'] = $input['desktop_column_1']; }
    if (isset($input['desktop_column_2'])) { $settings['desktop_column_2'] = $input['desktop_column_2']; }
    if (isset($input['desktop_column_3'])) { $settings['desktop_column_3'] = $input['desktop_column_3']; }
    if (isset($input['desktop_column_4'])) { $settings['desktop_column_4'] = $input['desktop_column_4']; }
    if (isset($input['desktop_column_5'])) { $settings['desktop_column_5'] = $input['desktop_column_5']; }
    if (isset($input['desktop_column_6'])) { $settings['desktop_column_6'] = $input['desktop_column_6']; }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
