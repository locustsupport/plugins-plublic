<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
wp_register_ability('tpaep/tpaep-scroll-sequence', [
'label' => __('Scroll Sequence', 'theplus'),
    'description' => __('Adds The Plus "Scroll Sequence" widget (tp-scroll-sequence) to an Elementor container.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id' => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id' => ['type' => 'string', 'description' => 'Target Elementor container ID'],
        'position' => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'imageUpldType' => ['type' => 'string', 'description' => 'Image source type', 'enum' => ['gallery', 'remote']],
        'imagePath' => ['type' => 'string', 'description' => 'Base URL of remote image folder'],
        'imagePrefix' => ['type' => 'string', 'description' => 'Filename prefix e.g. frame_'],
        'imageDigit' => ['type' => 'string', 'description' => 'Number padding format', 'enum' => ['1', '01', '001', '0001']],
        'imageType' => ['type' => 'string', 'description' => 'Image file extension', 'enum' => ['JPG', 'PNG', 'WebP']],
        'totalImage' => ['type' => 'integer', 'description' => 'Total number of frames'],
        'preloadImg' => ['type' => 'integer', 'description' => 'Preload percentage 1-100'],
        'stickySec' => ['type' => 'string', 'description' => 'Stick section during scroll', 'enum' => ['yes', 'no']],
        'settings' => ['type' => 'object', 'description' => 'Raw Elementor control key/value pairs. Use tpae/tpae-widget-schema to discover keys.'],
    ], 'required' => ['post_id', 'parent_id', 'totalImage'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => ['element_id' => ['type' => 'string'], 'widget_type' => ['type' => 'string'], 'post_id' => ['type' => 'integer']]],
    'execute_callback' => 'tpaep_mcp_theplus_scroll_sequence_ability',
    'permission_callback' => 'tpaep_mcp_theplus_scroll_sequence_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);
function tpaep_mcp_theplus_scroll_sequence_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}
function tpaep_mcp_theplus_scroll_sequence_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-scroll-sequence';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Scroll Sequence widget is not registered.', 'theplus')); }
    $post_id = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }
    $settings = [];
    if (!empty($input['imageUpldType'])) { $settings['imageUpldType'] = sanitize_key($input['imageUpldType']); }
    if (!empty($input['imagePath'])) { $settings['imagePath'] = esc_url_raw($input['imagePath']); }
    if (!empty($input['imagePrefix'])) { $settings['imagePrefix'] = sanitize_text_field($input['imagePrefix']); }
    if (!empty($input['imageDigit'])) { $settings['imageDigit'] = sanitize_key($input['imageDigit']); }
    if (!empty($input['imageType'])) { $settings['imageType'] = sanitize_key($input['imageType']); }
    if (isset($input['totalImage'])) { $settings['totalImage'] = intval($input['totalImage']); }
    if (isset($input['preloadImg'])) { $settings['preloadImg'] = intval($input['preloadImg']); }
    if (!empty($input['stickySec'])) { $settings['stickySec'] = sanitize_key($input['stickySec']); }
    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = ['id' => tpaep_mcp_generate_elementor_element_id(), 'elType' => 'widget', 'widgetType' => $widget_type, 'isInner' => false, 'settings' => $settings, 'elements' => []];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
