<?php
/**
 * The file that defines the widget plugin.
 *
 * @link       https://posimyth.com/
 * @since      1.0.0
 *
 * @package    ThePlus
 */

namespace TheplusAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Background;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Theplus_Elements_Widgets' ) ) {

	/**
	 * Define Theplus_Elements_Widgets class
	 */
	class Theplus_Elements_Widgets extends Widget_Base {

		/**
		 * Get Name.
		 *
		 * @since 5.3.5
		 * @version 5.4.2
		 */
		public function get_name() {
			return 'plus-elementor-widget';
		}

		/**
		 * Get Title.
		 *
		 * This class is not a placeable widget -- it is registered with the widgets
		 * manager purely so its constructor can attach the
		 * elementor/element/before_section_end control hooks. It declared no title,
		 * so Element_Base::get_title() returned '' and an unnamed entry appeared in
		 * the editor panel.
		 *
		 * @since 6.5.0
		 */
		public function get_title() {
			return esc_html__( 'The Plus Addons Extensions', 'theplus' );
		}

		/**
		 * Hide from the editor panel.
		 *
		 * Widget_Base::show_in_panel() defaults to true, which is what put the
		 * blank entry in Elementor's "General" category.
		 *
		 * @since 6.5.0
		 */
		public function show_in_panel() {
			return false;
		}

		/**
		 * Whether the shared control-injector hooks have been attached.
		 *
		 * @var bool
		 * @since 6.5.0
		 */
		private static $tpae_actions_attached = false;

		/**
		 * Call __construct.
		 *
		 * The injector hooks are global, so they are attached once per request rather
		 * than once per instance.
		 *
		 * @param array      $data Element data.
		 * @param array|null $args Element arguments.
		 * @since 1.0.0
		 * @version 6.5.0
		 */
		public function __construct( $data = [], $args = null ) {
			parent::__construct( $data, $args );

			if ( ! self::$tpae_actions_attached ) {
				self::$tpae_actions_attached = true;

				$this->add_actions();
			}
		}

		/**
		 * Call add_actions.
		 *
		 * @since 1.0.0
		 * @version 5.4.2
		 */
		protected function add_actions() {
			
			$theplus_options = get_option( 'theplus_options' );
			$extras_elements = ! empty( $theplus_options['extras_elements'] ) ? $theplus_options['extras_elements'] : [];

			if ( in_array( 'plus_magic_scroll', $extras_elements ) ) {
				add_action( 'elementor/element/before_section_end', array( $this, 'register_controls_widget_magic_scroll' ), 10, 3 );
			}

			if ( in_array( 'plus_mouse_move_parallax', $extras_elements ) ) {
				add_action( 'elementor/element/before_section_end', array( $this, 'register_controls_widget_mouseparallax' ), 10, 3 );
			}

			if ( in_array( 'plus_tilt_parallax', $extras_elements ) ) {
				add_action( 'elementor/element/before_section_end', array( $this, 'register_controls_widget_tilt_parallax' ), 10, 3 );
			}

			if ( in_array( 'plus_overlay_effect', $extras_elements ) ) {
				add_action( 'elementor/element/before_section_end', array( $this, 'register_controls_widget_reveal_effect' ), 10, 3 );
			}

			add_action( 'elementor/element/before_section_end', array( $this, 'register_controls_widget_gsap_scroll' ), 10, 3 );
		}

		/**
		 * Call register_controls_widget_magic_scroll.
		 *
		 * @since 1.0.0
		 * @version 5.4.2
		 *
		 * @param WP_Widget $widget   The widget instance.
		 * @param int       $widget_id The widget ID.
		 * @param array     $args      An array of widget arguments.
		 */
		public function register_controls_widget_magic_scroll( $widget, $widget_id, $args ) {
			static $widgets = array(
				'section_plus_extra_adv', /* Section */
			);

			if ( ! in_array( $widget_id, $widgets ) ) {
				return;
			}

			$widget->add_control(
				'magic_scroll',
				array(
					'label'       => esc_html__( 'Magic Scroll', 'theplus' ),
					'type'        => Controls_Manager::SWITCHER,
					'label_on'    => esc_html__( 'Yes', 'theplus' ),
					'label_off'   => esc_html__( 'No', 'theplus' ),
					'render_type' => 'template',
				)
			);
			$widget->add_group_control(
				\Theplus_Magic_Scroll_Option_Style_Group::get_type(),
				array(
					'label'       => esc_html__( 'Scroll Options', 'theplus' ),
					'name'        => 'scroll_option',
					'render_type' => 'template',
					'condition'   => array(
						'magic_scroll' => array( 'yes' ),
					),
				)
			);
			$widget->start_controls_tabs( 'tabs_magic_scroll' );
			$widget->start_controls_tab(
				'tab_scroll_from',
				array(
					'label'     => esc_html__( 'Initial', 'theplus' ),
					'condition' => array(
						'magic_scroll' => array( 'yes' ),
					),
				)
			);
			$widget->add_group_control(
				\Theplus_Magic_Scroll_From_Style_Group::get_type(),
				array(
					'label'     => esc_html__( 'Initial Position', 'theplus' ),
					'name'      => 'scroll_from',
					'condition' => array(
						'magic_scroll' => array( 'yes' ),
					),
				)
			);
			$widget->end_controls_tab();
			$widget->start_controls_tab(
				'tab_scroll_to',
				array(
					'label'     => esc_html__( 'Final', 'theplus' ),
					'condition' => array(
						'magic_scroll' => array( 'yes' ),
					),
				)
			);
			$widget->add_group_control(
				\Theplus_Magic_Scroll_To_Style_Group::get_type(),
				array(
					'label'     => esc_html__( 'Final Position', 'theplus' ),
					'name'      => 'scroll_to',
					'condition' => array(
						'magic_scroll' => array( 'yes' ),
					),
				)
			);

			$widget->end_controls_tab();
			$widget->end_controls_tabs();
		}

		/**
		 * Call register_controls_widget_gsap_scroll.
		 *
		 * @since 1.0.0
		 * @version 5.4.2
		 *
		 * @param WP_Widget $widget   The widget instance.
		 * @param int       $widget_id The widget ID.
		 * @param array     $args      An array of widget arguments.
		 */
		public function register_controls_widget_gsap_scroll( $widget, $widget_id, $args ) {
			static $widgets = array(
				'section_plus_extra_adv',
				'section_plus_extra_adv_hs', /* Section */
			);
			if ( ! in_array( $widget_id, $widgets ) ) {
				return;
			}
			$widget->add_control(
				'gsapScroll',
				array(
					'label'       => esc_html__( 'Horizontal Scroll', 'theplus' ),
					'type'        => Controls_Manager::SWITCHER,
					'label_on'    => esc_html__( 'Yes', 'theplus' ),
					'label_off'   => esc_html__( 'No', 'theplus' ),
					'render_type' => 'template',
					'separator'   => 'before',
					'default'     => '',
				)
			);

			$gsap_repeater = new \Elementor\Repeater();
			$gsap_repeater->add_control(
				'hsscrollOpttp',
				array(
					'label'     => __( 'Scroll Options', 'theplus' ),
					'type'      => Controls_Manager::POPOVER_TOGGLE,
					'label_off' => __( 'Enable', 'theplus' ),
					'label_on'  => __( 'Disable', 'theplus' ),
					'default'   => '',
				)
			);
			$gsap_repeater->start_popover();
				$gsap_repeater->add_responsive_control(
					'triggerStarth',
					array(
						'label'       => esc_html__( 'Trigger Start', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'separator'   => 'before',
						'range'       => array(
							'px' => array(
								'min'  => 0,
								'max'  => 1,
								'step' => 0.01,
							),
						),
						'default'     => array(
							'size' => 0.5,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'hsscrollOpttp' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'triggerEndh',
					array(
						'label'       => esc_html__( 'Trigger End', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'separator'   => 'before',
						'range'       => array(
							'px' => array(
								'min'  => 0,
								'max'  => 1,
								'step' => 0.01,
							),
						),
						'default'     => array(
							'size' => 0.4,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'hsscrollOpttp' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'scrollStarth',
					array(
						'label'       => esc_html__( 'Scroll Start', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'separator'   => 'before',
						'range'       => array(
							'px' => array(
								'min'  => 0,
								'max'  => 1,
								'step' => 0.01,
							),
						),
						'default'     => array(
							'unit' => 'px',
							'size' => 0.8,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'hsscrollOpttp' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'scrollEndh',
					array(
						'label'       => esc_html__( 'Scroll End', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'separator'   => 'before',
						'range'       => array(
							'px' => array(
								'min'  => 0,
								'max'  => 1,
								'step' => 0.01,
							),
						),
						'default'     => array(
							'size' => 0.2,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'hsscrollOpttp' => array( 'yes' ),
						),
					)
				);
			$gsap_repeater->end_popover();

			$gsap_repeater->add_control(
				'vertical',
				array(
					'label'     => __( 'Vertical', 'theplus' ),
					'type'      => Controls_Manager::POPOVER_TOGGLE,
					'label_off' => __( 'Enable', 'theplus' ),
					'label_on'  => __( 'Disable', 'theplus' ),
					'default'   => '',
				)
			);
			$gsap_repeater->start_popover();
				$gsap_repeater->add_responsive_control(
					'verticalStart',
					array(
						'label'       => esc_html__( 'Start', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'separator'   => 'before',
						'range'       => array(
							'px' => array(
								'min'  => -200,
								'max'  => 200,
								'step' => 1,
							),
						),
						'default'     => array(
							'size' => 0,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'vertical' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'verticalEnd',
					array(
						'label'       => esc_html__( 'End', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'separator'   => 'before',
						'range'       => array(
							'px' => array(
								'min'  => -200,
								'max'  => 200,
								'step' => 1,
							),
						),
						'default'     => array(
							'size' => 50,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'vertical' => array( 'yes' ),
						),
					)
				);
			$gsap_repeater->end_popover();

			$gsap_repeater->add_control(
				'horizontal',
				array(
					'label'     => __( 'Horizontal', 'theplus' ),
					'type'      => Controls_Manager::POPOVER_TOGGLE,
					'label_off' => __( 'Enable', 'theplus' ),
					'label_on'  => __( 'Disable', 'theplus' ),
					'default'   => '',
				)
			);
			$gsap_repeater->start_popover();
				$gsap_repeater->add_responsive_control(
					'horiStart',
					array(
						'label'       => esc_html__( 'Start', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'separator'   => 'before',
						'range'       => array(
							'px' => array(
								'min'  => -200,
								'max'  => 200,
								'step' => 1,
							),
						),
						'default'     => array(
							'size' => 0,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'horizontal' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'horiEnd',
					array(
						'label'       => esc_html__( 'End', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -200,
								'max'  => 200,
								'step' => 1,
							),
						),
						'default'     => array(
							'size' => 50,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'horizontal' => array( 'yes' ),
						),
					)
				);
			$gsap_repeater->end_popover();

			$gsap_repeater->add_control(
				'opacity',
				array(
					'label'     => __( 'Opacity', 'theplus' ),
					'type'      => Controls_Manager::POPOVER_TOGGLE,
					'label_off' => __( 'Enable', 'theplus' ),
					'label_on'  => __( 'Disable', 'theplus' ),
					'default'   => '',
				)
			);
			$gsap_repeater->start_popover();
				$gsap_repeater->add_responsive_control(
					'opacityStart',
					array(
						'label'       => esc_html__( 'Start', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => 0,
								'max'  => 1,
								'step' => 0.1,
							),
						),
						'default'     => array(
							'size' => 0.2,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'opacity' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'opacityEnd',
					array(
						'label'       => esc_html__( 'End', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => 0,
								'max'  => 1,
								'step' => 0.1,
							),
						),
						'default'     => array(
							'size' => 1,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'opacity' => array( 'yes' ),
						),
					)
				);
			$gsap_repeater->end_popover();

			$gsap_repeater->add_control(
				'rotate',
				array(
					'label'     => __( 'Rotate', 'theplus' ),
					'type'      => Controls_Manager::POPOVER_TOGGLE,
					'label_off' => __( 'Enable', 'theplus' ),
					'label_on'  => __( 'Disable', 'theplus' ),
					'default'   => '',
				)
			);
			$gsap_repeater->start_popover();
				$gsap_repeater->add_control(
					'positiontpsr',
					array(
						'label'     => esc_html__( 'Position', 'theplus' ),
						'type'      => Controls_Manager::SELECT,
						'default'   => 'center center',
						'options'   => array(
							'left top'      => esc_html__( 'Left Top', 'theplus' ),
							'left center'   => esc_html__( 'Left Center', 'theplus' ),
							'left bottom'   => esc_html__( 'Left Bottom', 'theplus' ),
							'center top'    => esc_html__( 'Center Top', 'theplus' ),
							'center center' => esc_html__( 'Center Center', 'theplus' ),
							'center bottom' => esc_html__( 'Center Bottom', 'theplus' ),
							'right top'     => esc_html__( 'Right Top', 'theplus' ),
							'right center'  => esc_html__( 'Right Center', 'theplus' ),
							'right bottom'  => esc_html__( 'Right Bottom', 'theplus' ),
						),
						'condition' => array(
							'rotate' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'rotateXstart',
					array(
						'label'       => esc_html__( 'RotateX Start', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -360,
								'max'  => 360,
								'step' => 1,
							),
						),
						'default'     => array(
							'size' => 0,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'rotate' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'rotateXEnd',
					array(
						'label'       => esc_html__( 'RotateX End', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -360,
								'max'  => 360,
								'step' => 1,
							),
						),
						'default'     => array(
							'size' => 0,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'rotate' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'rotateYStart',
					array(
						'label'       => esc_html__( 'RotateY Start', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -360,
								'max'  => 360,
								'step' => 1,
							),
						),
						'default'     => array(
							'size' => 0,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'rotate' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'rotateYEnd',
					array(
						'label'       => esc_html__( 'RotateY End', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -360,
								'max'  => 360,
								'step' => 1,
							),
						),
						'default'     => array(
							'size' => 0,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'rotate' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'rotateZStart',
					array(
						'label'       => esc_html__( 'RotateZ Start', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -360,
								'max'  => 360,
								'step' => 1,
							),
						),
						'default'     => array(
							'size' => 0,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'rotate' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'rotateZEnd',
					array(
						'label'       => esc_html__( 'RotateZ End', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -360,
								'max'  => 360,
								'step' => 1,
							),
						),
						'default'     => array(
							'size' => 0,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'rotate' => array( 'yes' ),
						),
					)
				);
			$gsap_repeater->end_popover();

			$gsap_repeater->add_control(
				'scalehs',
				array(
					'label'     => __( 'Scale', 'theplus' ),
					'type'      => Controls_Manager::POPOVER_TOGGLE,
					'label_off' => __( 'Enable', 'theplus' ),
					'label_on'  => __( 'Disable', 'theplus' ),
					'default'   => '',
				)
			);
			$gsap_repeater->start_popover();
				$gsap_repeater->add_responsive_control(
					'scaleXhsss',
					array(
						'label'       => esc_html__( 'ScaleX Start', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -10,
								'max'  => 10,
								'step' => 0.1,
							),
						),
						'default'     => array(
							'size' => 1,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'scalehs' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'scaleXhsse',
					array(
						'label'       => esc_html__( 'ScaleX End', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -10,
								'max'  => 10,
								'step' => 0.1,
							),
						),
						'default'     => array(
							'size' => 1,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'scalehs' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'scaleYhsss',
					array(
						'label'       => esc_html__( 'ScaleY Start', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -10,
								'max'  => 10,
								'step' => 0.1,
							),
						),
						'default'     => array(
							'size' => 1,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'scalehs' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'scaleYhsse',
					array(
						'label'       => esc_html__( 'ScaleY End', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -10,
								'max'  => 10,
								'step' => 1,
							),
						),
						'default'     => array(
							'size' => 1,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'scalehs' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'scaleZhss',
					array(
						'label'       => esc_html__( 'ScaleZ Start', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -10,
								'max'  => 10,
								'step' => 1,
							),
						),
						'default'     => array(
							'size' => 1,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'scalehs' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'scaleZhse',
					array(
						'label'       => esc_html__( 'ScaleZ End', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -10,
								'max'  => 10,
								'step' => 1,
							),
						),
						'default'     => array(
							'size' => 1,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'scalehs' => array( 'yes' ),
						),
					)
				);
			$gsap_repeater->end_popover();

			$gsap_repeater->add_control(
				'skewhs',
				array(
					'label'     => __( 'Skew', 'theplus' ),
					'type'      => Controls_Manager::POPOVER_TOGGLE,
					'label_off' => __( 'Enable', 'theplus' ),
					'label_on'  => __( 'Disable', 'theplus' ),
					'default'   => '',
				)
			);
			$gsap_repeater->start_popover();
				$gsap_repeater->add_responsive_control(
					'skewXhsss',
					array(
						'label'       => esc_html__( 'SkewX Start', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -10,
								'max'  => 10,
								'step' => 0.1,
							),
						),
						'default'     => array(
							'size' => 0,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'skewhs' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'skewXhsse',
					array(
						'label'       => esc_html__( 'SkewX End', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -10,
								'max'  => 10,
								'step' => 0.1,
							),
						),
						'default'     => array(
							'size' => 0,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'skewhs' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'skewYhsss',
					array(
						'label'       => esc_html__( 'SkewY Start', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -10,
								'max'  => 10,
								'step' => 0.1,
							),
						),
						'default'     => array(
							'size' => 0,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'skewhs' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'skewYhsse',
					array(
						'label'       => esc_html__( 'SkewY End', 'theplus' ),
						'type'        => Controls_Manager::SLIDER,
						'range'       => array(
							'px' => array(
								'min'  => -10,
								'max'  => 10,
								'step' => 0.1,
							),
						),
						'default'     => array(
							'size' => 0,
						),
						'render_type' => 'ui',
						'condition'   => array(
							'skewhs' => array( 'yes' ),
						),
					)
				);
			$gsap_repeater->end_popover();

			$gsap_repeater->add_control(
				'borderHs',
				array(
					'label'     => __( 'Border Radius', 'theplus' ),
					'type'      => Controls_Manager::POPOVER_TOGGLE,
					'label_off' => __( 'Enable', 'theplus' ),
					'label_on'  => __( 'Disable', 'theplus' ),
					'default'   => '',
				)
			);
			$gsap_repeater->start_popover();
				$gsap_repeater->add_responsive_control(
					'fromBRhs',
					array(
						'label'      => esc_html__( 'Start Border Radius', 'theplus' ),
						'type'       => Controls_Manager::DIMENSIONS,
						'size_units' => array( 'px', '%' ),
						'condition'  => array(
							'borderHs' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_responsive_control(
					'toBRhs',
					array(
						'label'      => esc_html__( 'End Border Radius', 'theplus' ),
						'type'       => Controls_Manager::DIMENSIONS,
						'size_units' => array( 'px', '%' ),
						'condition'  => array(
							'borderHs' => array( 'yes' ),
						),
					)
				);
			$gsap_repeater->end_popover();

			$gsap_repeater->add_control(
				'bgColorhs',
				array(
					'label'     => __( 'Background Color', 'theplus' ),
					'type'      => Controls_Manager::POPOVER_TOGGLE,
					'label_off' => __( 'Enable', 'theplus' ),
					'label_on'  => __( 'Disable', 'theplus' ),
					'default'   => '',
				)
			);
			$gsap_repeater->start_popover();
				$gsap_repeater->add_control(
					'fromColorhs',
					array(
						'label'     => esc_html__( 'Start Color', 'theplus' ),
						'type'      => Controls_Manager::COLOR,
						'default'   => '',
						'condition' => array(
							'bgColorhs' => array( 'yes' ),
						),
					)
				);
				$gsap_repeater->add_control(
					'toColorhs',
					array(
						'label'     => esc_html__( 'End Color', 'theplus' ),
						'type'      => Controls_Manager::COLOR,
						'default'   => '',
						'condition' => array(
							'bgColorhs' => array( 'yes' ),
						),
					)
				);
			$gsap_repeater->end_popover();

			$gsap_repeater->add_control(
				'hsdeveloptp',
				array(
					'label'     => esc_html__( 'Developer', 'theplus' ),
					'type'      => Controls_Manager::SWITCHER,
					'label_on'  => esc_html__( 'Enable', 'theplus' ),
					'label_off' => esc_html__( 'Disable', 'theplus' ),
					'default'   => '',
				)
			);
			$gsap_repeater->add_control(
				'hsdevNametp',
				array(
					'label'       => esc_html__( 'Trigger Name', 'theplus' ),
					'type'        => Controls_Manager::TEXT,
					'dynamic'     => array(
						'active' => true,
					),
					'default'     => '',
					'placeholder' => esc_html__( 'You can set your unique start and end trigger name.', 'theplus' ),
					'condition'   => array(
						'hsdeveloptp' => array( 'yes' ),
					),
				)
			);

			$widget->add_control(
				'GSAPFrame',
				array(
					'label'     => esc_html__( 'Add Frame', 'theplus' ),
					'type'      => Controls_Manager::REPEATER,
					'default'   => array(
						array(),
					),
					'fields'    => $gsap_repeater->get_controls(),
					'condition' => array(
						'gsapScroll' => array( 'yes' ),
					),
				)
			);
			$widget->add_control(
				'HSwidth',
				array(
					'label'     => esc_html__( 'Visibility', 'theplus' ),
					'type'      => Controls_Manager::SWITCHER,
					'label_on'  => esc_html__( 'On', 'theplus' ),
					'label_off' => esc_html__( 'Off', 'theplus' ),
					'default'   => '',
					'condition' => array(
						'gsapScroll' => 'yes',
					),
				)
			);
			$widget->add_control(
				'resWidth',
				array(
					'label'       => esc_html__( 'Responsive Width', 'theplus' ),
					'type'        => Controls_Manager::NUMBER,
					'min'         => 300,
					'max'         => 2000,
					'step'        => 5,
					'default'     => 300,
					'description' => esc_html__( 'ex. 900 < Scroll Normal Site', 'theplus' ),
					'condition'   => array(
						'HSwidth'    => 'yes',
						'gsapScroll' => 'yes',
					),
				)
			);
			$widget->add_control(
				'effeNotice',
				array(
					'type'        => Controls_Manager::RAW_HTML,
					'raw'         => wp_kses_post(
						sprintf(
							'<p class="tp-controller-label-text"><i> %s </i></p>',
							esc_html__( 'These effects will exclusively work with our Horizontal Scroll. This enables you to custom animate widgets based on the scroll viewport during scrolling.', 'theplus' ),
						)
					),
					'label_block' => true,
				)
			);
		}

		/**
		 * Call register_controls_widget_mouseparallax.
		 *
		 * @since 1.0.0
		 * @version 5.4.2
		 *
		 * @param WP_Widget $widget   The widget instance.
		 * @param int       $widget_id The widget ID.
		 * @param array     $args      An array of widget arguments.
		 */
		public function register_controls_widget_mouseparallax( $widget, $widget_id, $args ) {
			static $widgets = array(
				'section_plus_extra_adv', /* Section */
			);

			if ( ! in_array( $widget_id, $widgets ) ) {
				return;
			}

			$widget->add_control(
				'plus_mouse_move_parallax',
				array(
					'label'       => esc_html__( 'Mouse Move Parallax', 'theplus' ),
					'type'        => Controls_Manager::SWITCHER,
					'label_on'    => esc_html__( 'Yes', 'theplus' ),
					'label_off'   => esc_html__( 'No', 'theplus' ),
					'render_type' => 'template',
					'separator'   => 'before',
				)
			);
			$widget->add_group_control(
				\Theplus_Mouse_Move_Parallax_Group::get_type(),
				array(
					'label'       => esc_html__( 'Parallax Options', 'theplus' ),
					'name'        => 'plus_mouse_parallax',
					'render_type' => 'template',
					'condition'   => array(
						'plus_mouse_move_parallax' => array( 'yes' ),
					),
				)
			);
		}

		/**
		 * Call register_controls_widget_tilt_parallax.
		 *
		 * @since 1.0.0
		 * @version 5.4.2
		 *
		 * @param WP_Widget $widget   The widget instance.
		 * @param int       $widget_id The widget ID.
		 * @param array     $args      An array of widget arguments.
		 */
		public function register_controls_widget_tilt_parallax( $widget, $widget_id, $args ) {
			static $widgets = array(
				'section_plus_extra_adv', /* Section */
			);

			if ( ! in_array( $widget_id, $widgets ) ) {
				return;
			}

			$widget->add_control(
				'plus_tilt_parallax',
				array(
					'label'       => esc_html__( 'Tilt 3D Parallax', 'theplus' ),
					'type'        => Controls_Manager::SWITCHER,
					'label_on'    => esc_html__( 'Yes', 'theplus' ),
					'label_off'   => esc_html__( 'No', 'theplus' ),
					'render_type' => 'template',
					'separator'   => 'before',
				)
			);
			$widget->add_group_control(
				\Theplus_Tilt_Parallax_Group::get_type(),
				array(
					'label'       => esc_html__( 'Tilt Options', 'theplus' ),
					'name'        => 'plus_tilt_opt',
					'render_type' => 'template',
					'condition'   => array(
						'plus_tilt_parallax' => array( 'yes' ),
					),
				)
			);
		}

		/**
		 * Call register_controls_widget_reveal_effect.
		 *
		 * @since 1.0.0
		 * @version 5.4.2
		 *
		 * @param WP_Widget $widget   The widget instance.
		 * @param int       $widget_id The widget ID.
		 * @param array     $args      An array of widget arguments.
		 */
		public function register_controls_widget_reveal_effect( $widget, $widget_id, $args ) {
			static $widgets = array(
				'section_plus_extra_adv', /* Section */
			);

			if ( ! in_array( $widget_id, $widgets ) ) {
				return;
			}

			$widget->add_control(
				'plus_overlay_effect',
				array(
					'label'       => esc_html__( 'Overlay Special Effect', 'theplus' ),
					'type'        => Controls_Manager::SWITCHER,
					'label_on'    => esc_html__( 'Yes', 'theplus' ),
					'label_off'   => esc_html__( 'No', 'theplus' ),
					'render_type' => 'template',
					'separator'   => 'before',
				)
			);
			$widget->add_group_control(
				\Theplus_Overlay_Special_Effect_Group::get_type(),
				array(
					'label'       => esc_html__( 'Overlay Color', 'theplus' ),
					'name'        => 'plus_overlay_spcial',
					'render_type' => 'template',
					'condition'   => array(
						'plus_overlay_effect' => array( 'yes' ),
					),
				)
			);
		}

	}

}
