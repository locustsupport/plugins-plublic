<?php
/**
 * Widget Dependency Registry (Pro)
 *
 * Centralized configuration of CSS/JS dependencies for all widgets and extensions.
 *
 * Structure:
 *   'widget-slug' => array(
 *       'context'    => 'view'|'edit',  // Optional. Defaults to 'view' (frontend).
 *       'dependency' => array(
 *           'css' => array( ...file paths... ),
 *           'js'  => array( ...file paths... ),
 *       ),
 *   )
 *
 * @package theplus_elementor_addon
 * @since   6.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tpae_base = L_THEPLUS_PATH . DIRECTORY_SEPARATOR;
$tpae_pro_base = THEPLUS_PATH . DIRECTORY_SEPARATOR;

return [
		
		'tp-adv-text-block' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/text-block/tp-text-block.css',
				],
			],
		],
		'tp-text-block-animation' => [
			'dependency' => [
				'js' => [
					$tpae_base . 'assets/js/main/text-block/tp-text-block.min.js',
					$tpae_base . 'assets/js/main/text-animation/tp-text-animation.js',
					$tpae_base . 'assets/js/extra/gsap/gsap.min.js',
					$tpae_base . 'assets/js/extra/gsap/ScrollToPlugin.min.js',
					$tpae_base . 'assets/js/extra/gsap/ScrollTrigger.min.js',
					$tpae_base . 'assets/js/extra/gsap/ScrambleText.js',
					$tpae_base . 'assets/js/extra/gsap/SplitText.min.js',
					$tpae_base . 'assets/js/extra/gsap/TextPlugin.min.js',
				],
			],
		],
		'tp-advanced-typography' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/adv-typography/plus-adv-typography.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/adv-typography/plus-adv-typography.min.js',
				],
			],
		],
		'tp-advanced-circle' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/circletype.min.js',
				],
			],
		],
		'tp-advanced-buttons' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-adv-button.css',
				],
			],
		],

		'tp_cta_st_1' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-cta-style-1.css',
				],
			],
		],
		'tp_cta_st_2' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-cta-style-2.css',
				],
			],
		],
		'tp_cta_st_3' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-cta-style-3.css',
				],
			],
		],
		'tp_cta_st_4' => [
			'dependency' => [

				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-cta-style-4.css',
				],
			],
		],
		'tp_cta_st_5' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-cta-style-5.css',
				],
			],
		],
		'tp_cta_st_6' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-cta-style-6.css',
				],
			],
		],
		'tp_cta_st_7' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-cta-style-7.css',
				],
			],
		],
		'tp_cta_st_8' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-cta-style-8.css',
				],
			],
		],
		'tp_cta_st_9' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-cta-style-9.css',
				],
			],
		],
		'tp_cta_st_10' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-cta-style-10.css',
				],
			],
		],
		'tp_cta_st_11' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-cta-style-11.css',
				],
			],
		],
		'tp_cta_st_12' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-cta-style-12.css',
				],
			],
		],
		'tp_cta_st_13' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-cta-style-13.css',
				],
			],
		],
		'tp_cta_st_14' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-cta-style-14.css',
				],
			],
		],
		'tp_download_st_1' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-download-style-1.css',
				],
			],
		],
		'tp_download_st_2' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-download-style-2.css',
				],
			],
		],
		'tp_download_st_3' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-download-style-3.css',
				],
			],
		],
		'tp_download_st_4' =>  [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-download-style-4.css',
				],
			],
		],
		'tp_download_st_5' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/advanced-buttons/plus-download-style-5.css',
				],
			],
		],
		'tp-advanced-buttons-js' => [
			'dependency' => [
				'js' => [					
					$tpae_pro_base . 'assets/js/main/advanced-buttons/plus-advanced-buttons.min.js',
				],
			],
		],
		'tp_advertisement_banner' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/addbanner/plus-addbanner-style.css',
				],
			],
		],
		'tp_add_banner-style-1' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/addbanner/plus-addbanner-style-1.css',
				],
			],
		],
		'tp_add_banner-style-2' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/addbanner/plus-addbanner-style-2.css',
				],
			],
		],
		'tp_add_banner-style-3' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/addbanner/plus-addbanner-style-3.css',
				],
			],
		],
		'tp_add_banner-style-4' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/addbanner/plus-addbanner-style-4.css',
				],
			],
		],
		'tp_add_banner-style-5' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/addbanner/plus-addbanner-style-5.css',
				],
			],
		],
		'tp_add_banner-style-6' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/addbanner/plus-addbanner-style-6.css',
				],
			],
		],
		'tp_add_banner-style-7' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/addbanner/plus-addbanner-style-7.css',
				],
			],
		],
		'tp_add_banner-style-8' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/addbanner/plus-addbanner-style-8.css',
				],
			],
		],
		'tp-accordion' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/tabs-tours/plus-tabs-tours.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/accordion/plus-accordion.min.js',
				],
			],
		],
		'tp-age-gate' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/age-gate/plus-method.css',
				],
				'js' => [
					$tpae_base . 'assets/js/main/age-gate/plus-age-gate.min.js',
				],
			],
		],
		'tp-age-gate-method-1' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/age-gate/plus-method-1.css',
				],
			],
		],
		'tp-age-gate-method-2' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/age-gate/plus-method-2.css',
				],
			],
		],
		'tp-age-gate-method-3' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/age-gate/plus-method-3.css',
				],
			],
		],
		'tp-animated-service-boxes' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
			        $tpae_pro_base . 'assets/css/main/animated-service-box/plus-asb-style.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/animated-service-box/plus-service-box.min.js',
				],
			],
		],
		'tp-image-accordion' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/animated-service-box/plus-image-accordion.css',
				],
			],
		],
		'tp-image-accordion-style-2' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/animated-service-box/plus-image-accordion-style-2.css',
				],
			],
		],
		'tp-sliding-boxes' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/animated-service-box/plus-sliding-box.css',
				],
			],
		],
		'tp-article-box-style-1' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/animated-service-box/plus-article-box-1.css',
				],
			],
		],
		'tp-article-box-style-2' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/animated-service-box/plus-article-box-2.css',
				],
			],
		],
		'tp-info-banner-style-1' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/animated-service-box/plus-info-banner-style-1.css',
				],
			],
		],
		'tp-info-banner-style-2' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/animated-service-box/plus-info-banner-style-2.css',
				],
			],
		],
		'tp-hover-section' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/animated-service-box/plus-hover-section.css',
				],
			],
		],
		'tp-icon' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/icon/icon.css',
				],
			],
		],
		'tp-fancy-box' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/animated-service-box/plus-fancy-box.css',
				],
			],
		],
		'tp-services-element' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/animated-service-box/plus-service-element.css',
				],
			],
		],
		'tp-services-element-style-1' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/animated-service-box/plus-services-style-1.css',
				],
			],
		],
		'tp-services-element-style-2' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/animated-service-box/plus-services-style-2.css',
				],
			],
		],
		'tp-portfolio-style-1' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/animated-service-box/plus-portfolio-style-1.css',
				],
			],
		],
		'tp-portfolio-style-2' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/animated-service-box/plus-portfolio-style-2.css',
				],
			],
		],
		'tp-audio-player' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/audio-player/plus-ap.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/audio-player/plus-audio-player.min.js',					
				],
			],
		],
		'tp-audio-player-style-1' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/audio-player/plus-ap-style-1.css',
				],
			],
		],
		'tp-audio-player-style-2' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/audio-player/plus-ap-style-2.css',
				],
			],
		],
		'tp-audio-player-style-3' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/audio-player/plus-ap-style-3.css',
				],
			],
		],
		'tp-audio-player-style-4' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/audio-player/plus-ap-style-4.css',
				],
			],
		],
		'tp-audio-player-style-5' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/audio-player/plus-ap-style-5.css',
				],
			],
		],
		'tp-audio-player-style-6' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/audio-player/plus-ap-style-6.css',
				],
			],
		],
		'tp-audio-player-style-7' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/audio-player/plus-ap-style-7.css',
				],
			],
		],
		'tp-audio-player-style-8' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/audio-player/plus-ap-style-8.css',
				],
			],
		],
		'tp-audio-player-style-9' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/audio-player/plus-ap-style-9.css',
				],
			],
		],
		'tp-before-after' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/before-after/plus-before-after.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/before-after/plus-before-after.min.js',
				],
			],
		],
		'tp-blockquote' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/block-quote/plus-block-quote.css',
				],
			],
		],
		'tp-blockquote-bl_1' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/block-quote/plus-block-layout1.css',
				],
			],
		],
		'tp-blockquote-bl_2' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/block-quote/plus-block-layout2.css',
				],
			],
		],
		'tp-blockquote-bl_3' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/block-quote/plus-block-layout3.css',
				],
			],
		],
		'tp-blog-listout' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_base . 'assets/css/main/blog-list/plus-bloglist-style.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/blog-listing/blog-listing.min.js',
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-posts-listing.min.js',
				],
			],
		],
		'tp-bloglistout-style-1' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/blog-list/plus-bloglist-style-1.css',
				],
			],
		],
		'tp-bloglistout-style-5' => array(
			'dependency' => array(
				'css' => array(
					$tpae_base . 'assets/css/main/blog-list/plus-bloglist-style-5.css',
				),
			),
		),
		'tp-bloglistout-style-2' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/blog-list/plus-bloglist-style-2.css',
				],
			],
		],
		'tp-bloglistout-style-3' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/blog-list/plus-bloglist-style-3.css',
				],
			],
		],
		'tp-bloglistout-style-4' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/blog-list/plus-bloglist-style-4.css',
				],
			],
		],
		'tp-bloglistout-preloder' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/blog-list/plus-preloader.css',
				],
			],
		],
		'tp-dynamic-smart-showcase' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_pro_base . 'assets/css/main/dynamic-smart-showcase/dynamic-showcase.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/dynamic-smart-showcase/plus-dynamic-smart-showcase.min.js',					
					$tpae_pro_base . 'assets/js/main/dynamic-smart-showcase/plus-bss-filter.min.js',
				],
			],
		],
		'tp-dynamic-smart-showcase-mag_one_2_2' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/dynamic-smart-showcase/dynamic-ss-style-1.css',
				],				
			],
		],
		'tp-dynamic-smart-showcase-mag_one_1_2_v' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/dynamic-smart-showcase/dynamic-ss-style-2.css',
				],				
			],
		],
		'tp-dynamic-smart-showcase-mag_one_1_2_h' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/dynamic-smart-showcase/dynamic-ss-style-3.css',
				],				
			],
		],
		'tp-dynamic-smart-showcase-mag_rows_2' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/dynamic-smart-showcase/dynamic-ss-style-4.css',
				],				
			],
		],
		'tp-dynamic-smart-showcase-mag_four_x_rows_1' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/dynamic-smart-showcase/dynamic-ss-style-5.css',
				],				
			],
		],
		'tp-dynamic-smart-showcase-mag_two_3_v' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/dynamic-smart-showcase/dynamic-ss-style-6.css',
				],				
			],
		],
		'tp-dynamic-smart-showcase-mag_two_1_2' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/dynamic-smart-showcase/dynamic-ss-style-7.css',
				],				
			],
		],
		'tp-dynamic-smart-showcase-mag_two_4' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/dynamic-smart-showcase/dynamic-ss-style-8.css',
				],				
			],
		],
		'tp-dynamic-smart-showcase-post-ticker' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/dynamic-smart-showcase/dynamic-smart-post-ticker.css',
				],				
			],
		],
		'tp-breadcrumbs-bar' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/breadcrumbs-bar/plus-breadcrumbs-bar.css',
				],				
			],
		],
		'tp-breadcrumbs-bar-style_1' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/breadcrumbs-bar/plus-bb-style1.css',
				],				
			],
		],
		'tp-breadcrumbs-bar-style_2' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/breadcrumbs-bar/plus-bb-style2.css',
				],				
			],
		],
		'plus-post-filter' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/plus-category-filter/plus-post-filter.min.css',
                    $tpae_pro_base . 'assets/css/main/plus-category-filter/plus-filter-style-3.css',

				],
			],
		],
		'plus-post-filter-style-1' => [
            'dependency' => [
                'css' => [
                    $tpae_pro_base . 'assets/css/main/plus-category-filter/plus-filter-style-1.css',
                ],
            ],
        ],
        'plus-post-filter-style-2' => [
            'dependency' => [
                'css' => [
                    $tpae_pro_base . 'assets/css/main/plus-category-filter/plus-filter-style-2.css',
                ],
            ],
        ],
        'plus-post-filter-style-3' => [
            'dependency' => [
                'css' => [
                    // $tpae_pro_base . 'assets/css/main/plus-category-filter/plus-filter-style-3.css',
                ],
            ],
        ],
        'plus-post-filter-style-4' => [
            'dependency' => [
                'css' => [
                    $tpae_pro_base . 'assets/css/main/plus-category-filter/plus-filter-style-4.css',
                ],
            ],
        ],
        'plus-post-filter-h-style-1' => [
            'dependency' => [
                'css' => [
                    $tpae_pro_base . 'assets/css/main/plus-category-filter/plus-filter-h-style-1.css',
                ],
            ],
        ],
        'plus-post-filter-h-style-2' => [
            'dependency' => [
                'css' => [
                    $tpae_pro_base . 'assets/css/main/plus-category-filter/plus-filter-h-style-2.css',
                ],
            ],
        ],
        'plus-post-filter-h-style-3' => [
            'dependency' => [
                'css' => [
                    $tpae_pro_base . 'assets/css/main/plus-category-filter/plus-filter-h-style-3.css',
                ],
            ],
        ],
        'plus-post-filter-h-style-4' => [
            'dependency' => [
                'css' => [
                    $tpae_pro_base . 'assets/css/main/plus-category-filter/plus-filter-h-style-4.css',
                ],
            ],
        ],
		'plus-pagination' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/plus-extra-adv/plus-pagination.css',
				],
			],
		],
		'plus-listing-metro' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/imagesloaded.pkgd.min.js',
					$tpae_pro_base . 'assets/js/extra/isotope.pkgd.js',
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-posts-metro-list.min.js',
				],
			],
		],
		'plus-listing-masonry' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/imagesloaded.pkgd.min.js',
					$tpae_pro_base . 'assets/js/extra/isotope.pkgd.js',
					$tpae_pro_base . 'assets/js/extra/packery-mode.pkgd.min.js',
				],
			],
		],
		'tp-button' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style.css',
				],
			],
		],
		'tp-button-style-1' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-1.css',
				],
			],
		],
		'tp-button-style-2' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-2.css',
				],
			],
		],
		'tp-button-style-3' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-3.css',
				],
			],
		],
		'tp-button-style-4' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-4.css',
				],
			],
		],
		'tp-button-style-5' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-5.css',
				],
			],
		],
		'tp-button-style-6' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-6.css',
				],
			],
		],
		'tp-button-style-7' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-7.css',
				],
			],
		],
		'tp-button-style-8' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-8.css',
				],
			],
		],
		'tp-button-style-9' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-9.css',
				],
			],
		],
		'tp-button-style-10' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-10.css',
				],
			],
		],
		'tp-button-style-11' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-11.css',
				],
			],
		],
		'tp-button-style-12' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-12.css',
				],
			],
		],
		'tp-button-style-13' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-13.css',
				],
			],
		],
		'tp-button-style-14' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-14.css',
				],
			],
		],
		'tp-button-style-15' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-15.css',
				],
			],
		],
		'tp-button-style-16' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-16.css',
				],
			],
		],
		'tp-button-style-17' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-17.css',
				],
			],
		],
		'tp-button-style-18' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-18.css',
				],
			],
		],
		'tp-button-style-19' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-19.css',
				],
			],
		],
		'tp-button-style-20' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-20.css',
				],
			],
		],
		'tp-button-style-21' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-21.css',
				],
			],
		],
		'tp-button-style-22' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-22.css',
				],
			],
		],
		'tp-button-style-24' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/tp-button/tp-button-style-24.css',
				],
			],
		],
		'tp-wp-bodymovin' => [
		],
		'tp-carousel-anything' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/extra/slick.min.css',
					$tpae_base . 'assets/css/main/carousel/plus-carousel.css',
					$tpae_base . 'assets/css/main/carousel-anything/plus-carousel-anything.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/slick.min.js',
					$tpae_pro_base . 'assets/js/main/general/plus-slick-carousel.min.js',
					$tpae_pro_base . 'assets/js/main/carousel-anything/plus-carousel-anything.min.js',
				],
			],
		],
		'tp-carousel-remote' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/carousel-remote/plus-carousel.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/slick.min.js',					
					$tpae_pro_base . 'assets/js/main/carousel-remote/plus-carousel-remote.min.js',
				],
			],
		],
		'tp-carousel-dot' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/carousel-remote/plus-dots.css',
				],
			],
		],
		'tp-carousel-tooltip' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/carousel-remote/plus-tooltip.css',
				],
			],
		],
		'tp-plus-horizontal-connection' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/carousel-remote/plus-horizontal-connection.css',
				],
			],
		],
		'tp-carousel-pagination' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/carousel-remote/plus-pagination.css',
				],
			],
		],
		'tp-cascading-image' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/image-factory/plus-image-factory.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/cascading-image/plus-cascading-image.min.js',
				],
			],
		],
		'tp-cascading-image-animetions' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/main/cascading-image/plus-cascading-animetions.js',
					$tpae_base . 'assets/js/main/image-animetion/tp-image-animetion.js',
					$tpae_base . 'assets/js/extra/gsap/gsap.min.js',
					$tpae_base . 'assets/js/extra/gsap/ScrollToPlugin.min.js',
					$tpae_base . 'assets/js/extra/gsap/ScrollTrigger.min.js',
				],
			],
		],
		'tp-chart' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/chart.js', 
					$tpae_pro_base . 'assets/js/main/chart/plus-chart.min.js', 
				], 
			],
		],
		'tp-circle-menu' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/circle-menu/plus-circle-menu.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/jquery.circlemenu.js',
					$tpae_pro_base . 'assets/js/main/circle-menu/plus-circle-menu.min.js',
				],
			],
		],
		'tp-clients-listout' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_pro_base . 'assets/css/main/client-list/plus-client-list.css',				
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-posts-listing.min.js',
					$tpae_pro_base . 'assets/js/main/client-listing/client-listing.min.js',
				],
			],
		],
		'tp-contact-form-7' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_base . 'assets/css/main/forms-style/plus-cf7-style.css',
				],
				'js' => [
					$tpae_base . 'assets/js/main/forms-style/plus-cf7-form.js',
				],
			],
		],
		'tp-coupon-code' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/coupon-code/plus-coupon-code.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/coupon-code/plus-coupon-code.min.js',
				],
			],
		],
		'tp-coupon-standard' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/coupon-code/plus-standard.css',
				],
			],
		],
		'tp-coupon-peel' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/coupon-code/plus-peel.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/peeljs.js',
				],
			],
		],
		'tp-coupon-scratch' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/coupon-code/plus-scratch.css',
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/extra/html2canvas.min.js',
				],
			],
		],
		'tp-coupon-slideOut' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/coupon-code/plus-slide.css',
				],
			],
		],
		'tp-dynamic-listing' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_pro_base . 'assets/css/main/dynamic-listing/plus-dynamic-listing.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/dynamic-listing/plus-dynamic-listing.min.js',
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-posts-listing.min.js',
				],
			],
		],
		'tp-dynamic-listout-qview' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/extra/jquery.fancybox.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/jquery.fancybox.min.js',
					$tpae_pro_base . 'assets/js/main/dynamic-listing/plus-dynamic-listing-qview.min.js',
				],
			],
		],
		'tp-custom-field' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/custom-field/plus-custom-field.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/custom-field/plus-custom-field.min.js',					
				],
			],
		],
		'tp-countdown' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/countdown/plus-cd-style.css',
					$tpae_pro_base . 'assets/css/main/countdown/plus.countdwon.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/jquery.downCount.js',
					$tpae_pro_base . 'assets/js/main/countdown/plus-countdown.min.js',
				],
			],
		],
		'tp-countdown-style-1' => [
			'dependency' => [
				'css' => [										
					$tpae_base . 'assets/css/main/countdown/plus-cd-s-1.css',
				],
			],
		],
		'tp-countdown-style-2' => [
			'dependency' => [
				'css' => [		
					$tpae_base . 'assets/css/extra/countdown/flipdown.min.css',								
					$tpae_base . 'assets/css/main/countdown/plus-cd-s-2.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/countdown/flipdown.min.js',
				],
			],
		],
		'tp-countdown-style-3' => [
			'dependency' => [
				'css' => [										
					$tpae_base . 'assets/css/main/countdown/plus-cd-s-3.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/countdown/progressbar.min.js',
				],
			],
		],
		'tp-dark-mode' => [
			'dependency' => [
				'css' => [										
					$tpae_base . 'assets/css/main/darkmode/plus-dark-mode.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/darkmode.min.js',
					$tpae_base . 'assets/js/main/darkmode/plus-dark-mode.min.js',
				],
			],
		],
		'tp-draw-svg' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/draw-svg/plus-draw-svg.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/vivus.min.js',
					$tpae_pro_base . 'assets/js/main/draw-svg/plus-draw-svg.min.js',
				],
			],
		],
		'tp-dynamic-device' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/dynamic-device/plus-dynamic-device.min.css',					
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/dynamic-device/plus-dynamic-device.min.js',
				],
			],
		],
		'tp-everest-form' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/forms-style/plus-everest-form.css',
				],
			],
		],
		'tp-plus-form' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/plus-form/plus-form-widget.min.css',
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/main/plus-form/plus-form-widget.min.js',
				],
			],
		],
		'tp-smooth-scroll' => [
			'dependency' => [
				'js' => [					
					$tpae_base . 'assets/js/extra/smooth-scroll.js',
					$tpae_base . 'assets/js/main/smooth-scroll/plus-smooth-scroll.min.js',
				],
			],
		],
		'tp-smooth-scroll-lenis' => [
            'dependency' => [
                'js' => [                   
                    $tpae_base . 'assets/js/extra/lenis/lenis.min.js',
                ],
            ],
        ],
		'tp-flip-box' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/info-box/plus-infobox-style.css',
				],
			],
		],
		'tp-flip-box-adv'=> [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/flip-box/tp-flip-box.css',
				],
				'js' => [
				    $tpae_pro_base . 'assets/js/main/flip-box/tp-flip-box.min.js',
					$tpae_base . 'assets/js/extra/gsap/gsap.min.js',
					$tpae_base . 'assets/js/extra/gsap/ScrollTrigger.min.js',
				],
			],
		],
		'tp-gallery-listout' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_base . 'assets/css/main/gallery-list/plus-gallery-list.css',					
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/gallery-listing/gallery-list.min.js',
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-posts-listing.min.js',
				],
			],
		],
		'tp-gallery-listout-style-1' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/gallery-list/plus-gl-style1.css',					
				],
			],
		],
		'tp-gallery-listout-style-2' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/gallery-list/plus-gl-style2.css',					
				],
			],
		],
		'tp-gallery-listout-style-3' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/gallery-list/plus-gl-style3.css',					
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/jquery.hoverdir.js',
				],
			],
		],
		'tp-gallery-listout-style-4' => [
			'dependency' => [
				'css' => [					
					 $tpae_pro_base . 'assets/css/main/gallery-list/plus-gl-style4.css',					
				],
			],
		],
		'tp-map-googlemap' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/google-map/plus-gmap.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/google-map/plus-google-map.min.js',
					$tpae_pro_base . 'assets/js/main/google-map/plus-gmap.min.js',
				]
			],
		],
		'tp-map-osm' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/extra/osmmap/leaflet.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/osmmap/markerclusterer.js',
					$tpae_pro_base . 'assets/js/extra/osmmap/leaflet.js',
					$tpae_pro_base . 'assets/js/main/google-map/plus-osm-map.min.js',
					$tpae_pro_base . 'assets/js/main/google-map/plus-gmap.min.js',
				]
			],
		],
		'tp-gravityt-form' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/forms-style/plus-gravity-form.css',
				],
				'js' => [
					$tpae_base . 'assets/js/main/forms-style/plus-gravity-form.js',
				]
			],
		],		
		'tp-heading-animation' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-animation/tp-heading-animation.css',
				],
				'js' => [
					$tpae_base . 'assets/js/main/heading-animation/plus-heading-animation.min.js',
				]
			],
		],
		'tp-heading-animation-style-1' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-animation/heading-animation-style-1.css',
				],
			],
		],
		'tp-heading-animation-style-2' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-animation/heading-animation-style-2.css',
				],
			],
		],
		'tp-heading-animation-style-3' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-animation/heading-animation-style-3.css',
				],
			],
		],
		'tp-heading-animation-style-4' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-animation/heading-animation-style-4.css',
				],
			],
		],
		'tp-heading-animation-style-5' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-animation/heading-animation-style-5.css',
				],
			],
		],
		'tp-heading-animation-style-6' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-animation/heading-animation-style-6.css',
				],
			],
		],
		'tp-header-extras' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/header-extras/plus-header-extras.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/header-extras/plus-header-extras.min.js',
				],
			],
		],
		'tp-header-audio' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/buzz.min.js',
				],
			],
		],
		'tp-gsap-heading-animation' => [
			'dependency' => [
				'js' => [
					$tpae_base . 'assets/js/main/heading-title/tp-heading-title.js',
					$tpae_base . 'assets/js/main/text-animation/tp-text-animation.js',
					$tpae_base . 'assets/js/extra/gsap/gsap.min.js',
					$tpae_base . 'assets/js/extra/gsap/ScrollToPlugin.min.js',
					$tpae_base . 'assets/js/extra/gsap/ScrollTrigger.min.js',
					$tpae_base . 'assets/js/extra/gsap/ScrambleText.js',
					$tpae_base . 'assets/js/extra/gsap/SplitText.min.js',
					$tpae_base . 'assets/js/extra/gsap/TextPlugin.min.js',
				],
			],
		],
		'tp-heading-title' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-title/plus-ht-style.css',
				],
			],
		],
		'tp-heading-title-style_1' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-title/plus-ht-style-1.css',
				],
			],
		],
		'tp-heading-title-style_2' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-title/plus-ht-style-2.css',
				],
			],
		],
		'tp-heading-title-style_3' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-title/plus-ht-style-3.css',
				],
			],
		],
		'tp-heading-title-style_4' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-title/plus-ht-style-4.css',
				],
			],
		],
		'tp-heading-title-style_5' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-title/plus-ht-style-5.css',
				],
			],
		],
		'tp-heading-title-style_6' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-title/plus-ht-style-6.css',
				],
			],
		],
		'tp-heading-title-style_7' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-title/plus-ht-style-7.css',
				],
			],
		],
		'tp-heading-title-style_8' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-title/plus-ht-style-8.css',
				],
			],
		],
		'tp-heading-title-style_9' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-title/plus-ht-style-9.css',
				],
			],
		],
		'tp-heading-title-style_10' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-title/plus-ht-style-10.css',
				],
			],
		],
		'tp-heading-title-style_11' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/heading-title/plus-ht-style-11.css',
				],
			],
		],
		'tp-heading-title-splite-animation' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/jquery.waypoints.min.js',
					$tpae_pro_base . 'assets/js/extra/splittext.min.js',					
					$tpae_pro_base . 'assets/js/extra/tweenmax/tweenmax.min.js',
					$tpae_pro_base . 'assets/js/main/heading-title/plus-heading-title.min.js',
				],				
			],
		],
		'tp-hotspot' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/extra/tippy.css',
					$tpae_pro_base . 'assets/css/main/hotspot/plus-hotspot.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/tippy.all.min.js',
					$tpae_pro_base . 'assets/js/main/hotspot/plus-hotspot.min.js',
				],
			],
		],
		'tp-horizontal-scroll-advance' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/horizontal-scroll/plus-horizontal-scroll.min.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/gsap/gsap.min.js',
					$tpae_base . 'assets/js/extra/gsap/ScrollTrigger.min.js',
					$tpae_base . 'assets/js/extra/gsap/ScrollToPlugin.min.js',
					$tpae_pro_base . 'assets/js/main/horizontal-scroll/plus-horizontal-scroll.min.js',
				],
			],
		],
		'tp-image-factory' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/image-factory/plus-image-factory.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/image-factory/plus-image-factory.min.js',
				],
			],
		],
		'tp-image-gsapfactory' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/main/image-factory/plus-gsap-image.min.js',
					$tpae_base . 'assets/js/main/image-animetion/tp-image-animetion.js',
					$tpae_base . 'assets/js/extra/gsap/gsap.min.js',
					$tpae_base . 'assets/js/extra/gsap/ScrollToPlugin.min.js',
					$tpae_base . 'assets/js/extra/gsap/ScrollTrigger.min.js',
				],
			],
		],
		
		'tp-info-box' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/info-box/plus-infobox-style.css',
				],
			],
		],
		'tp-info-box-style_1' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/info-box/plus-infobox-style-1.css',
				],
			],
		],
		'tp-info-box-style_2' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/info-box/plus-infobox-style-2.css',
				],
			],
		],
		'tp-info-box-style_3' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/info-box/plus-infobox-style-3.css',
				],
			],
		],
		'tp-info-box-style_4' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/info-box/plus-infobox-style-4.css',
				],
			],
		],
		'tp-info-box-style_7' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/info-box/plus-infobox-style-5.css',
				],
			],
		],
		'tp-info-box-style_11' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/info-box/plus-infobox-style-6.css',
				],
			],
		],
		'tp-bg-hover-ani' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/info-box/plus-bg-hover-ani.css',
				],
			],
		],
		'tp-info-box-js' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/main/info-box/plus-info-box.min.js',
				],
			],
		],
		'tp-mailchimp-subscribe' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/mailchimp/plus-mailchimp.css',
				],
			],
		],
		'tp-messagebox' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/messagebox/plus-messagebox.min.css',
				],
			],
		],
		'tp-messagebox-js' => [
			'dependency' => [
				'js' => [
					$tpae_base . 'assets/js/main/messagebox/plus-messagebox.min.js',
				],
			],
		],
		'tp-morphing-layouts' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/shape-morph/plus-shape-morph.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/anime.min.js',
					$tpae_pro_base . 'assets/js/main/shape-morph/theplus-shape-morph.min.js',
				],
			],
		],
		'tp-morphing-scroll' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/scrollmonitor.js',
				],
			],
		],
		'tp-mouse-cursor' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/mouse-cursor-widget/plus-mouse-cursors.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/mouse-cursor-widget/plus-mouse-cursors.min.js',
				],
			],
		],
		'tp-mouse-cursor-gsap' => [
			'dependency' => [
				'js' => [
					$tpae_base . 'assets/js/extra/gsap/gsap.min.js',
				],
			],
		],	
		'tp-navigation-menu' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/navigation-menu/plus-nav-menu.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/navigation-menu/plus-nav-menu.min.js',
				],
			],
		],
		'tp-navigation-scroll' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/headroom.min.js',
				],
			],
		],
		'tp-navigation-menu-lite' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/navigation-menu-lite/plus-nav-menu-lite.min.css',
				],
				'js' => [
					$tpae_base . 'assets/js/main/navigation-menu-lite/plus-nav-menu-lite.min.js',
				],
			],
		],
		'tp-ninja-form' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/forms-style/plus-ninja-form.css',
				],
			],
		],
		'tp-number-counter' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/number-counter/plus-nc.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/numscroller.js',
				],
			],
		],
		'tp-number-counter-style-1' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/number-counter/plus-nc-style-1.css',
				],
			],
		],
		'tp-number-counter-style-2' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/number-counter/plus-nc-style-2.css',
				],
			],
		],
		'tp-post-featured-image' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/post-feature-image/plus-post-image.min.css',					
				],
				'js' => [
					$tpae_base . 'assets/js/main/post-feature-image/plus-post-feature-image.min.js',
				],
			],
		],
		'tp-post-featured-image-js' => [
			'dependency' => [
				'js' => [
					$tpae_base . 'assets/js/main/post-feature-image/plus-post-feature-image.min.js',
				],
			],
		],
		'tp-post-title' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/post-title/plus-post-title.min.css',					
				],				
			],
		],
		'tp-post-content' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/post-content/plus-post-content.min.css',					
				],				
			],
		],
		'tp-post-meta' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/post-meta-info/plus-post-meta-info.min.css',
				],
				
			],
		],
		'tp-post-author' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/post-author/plus-post-author.min.css',
				],				
			],
		],
		'tp-post-comment' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/post-comment/plus-post-comment.min.css',
				],				
			],
		],
		'tp-post-navigation' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_base . 'assets/css/main/post-navigation/plus-post-navigation.min.css',
				],				
			],
		],
		'tp-off-canvas' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/off-canvas/plus-off-canvas.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/offcanvas/plus-offcanvas.js',
				],
			],
		],
		'tp-page-scroll' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/page-scroll/plus-page-scroll.css',
				],
				'js'  => [
					$tpae_pro_base . 'assets/js/main/page-scroll/plus-page-scroll.min.js',
				],
			],
		],
		'tp-page-scroll-np-button' => [
            'dependency' => [
                'css' => [
                     $tpae_pro_base . 'assets/css/main/page-scroll/plus-np-button.css',
                ],
            ],
        ],
        'tp-page-scroll-paginate' => [
            'dependency' => [
                'css' => [
                    $tpae_pro_base . 'assets/css/main/page-scroll/plus-paginate.css',
                ],
            ],
        ],
		'tp-fullpage' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/extra/fullpage.css',
				],
				'js'  => [					
					$tpae_base . 'assets/js/extra/fullpage.js',
				],
			],
		],
		'tp-pagepiling' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/extra/jquery.pagepiling.css',
					$tpae_pro_base . 'assets/css/main/page-scroll/plus-pilling.css',
				],
				'js'  => [
					$tpae_pro_base . 'assets/js/extra/jquery.pagepiling.min.js',
				],
			],
		],
		'tp-multiscroll' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/page-scroll/plus-multiscroll.css',
			   	],
				'js'  => [
					$tpae_pro_base . 'assets/js/extra/jquery.multiscroll.min.js',
				],
			],
		],
		'tp-horizontal-scroll' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/page-scroll/plus-horizontal.css',
			   	],
				'js'  => [
					$tpae_pro_base . 'assets/js/extra/jquery.jInvertScroll.min.js',
				],
			],
		],
		'tp-mobile-menu' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_pro_base . 'assets/css/main/mobile-menu/plus-mobile-menu.min.css',
				],
				'js'  => [
					$tpae_pro_base . 'assets/js/main/mobile-menu/plus-mobile-menu.min.js',
				],
			],
		],
		'tp-pricing-list' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/pricing-list/plus-pricing-list.css',
				],
			],
		],
		'tp-pricing-list-style_1' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/pricing-list/plus-pricing-style1.css',
				],
			],
		],
		'tp-pricing-list-style_2' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/pricing-list/plus-pricing-style2.css',
				],
			],
		],
		'tp-pricing-list-style_3' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/pricing-list/plus-pricing-style3.css',
				],
			],
		],
		'tp-pricing-table' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/pricing-table/plus-pricing-table.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/pricing-table/plus-pricing-table.min.js',
				],
			],
		],
		'tp-pricing-table-style-1' => array(
			'dependency' => array(
				'css' => array(
					$tpae_base . 'assets/css/main/pricing-table/plus-pricing-style-1.css',
				),
			),
		),
		'tp-pricing-table-style-2' => array(
			'dependency' => array(
				'css' => array(
					$tpae_pro_base . 'assets/css/main/pricing-table/plus-pricing-style-2.css',
				),
			),
		),
		'tp-pricing-table-style-3' => array(
			'dependency' => array(
				'css' => array(
					$tpae_pro_base . 'assets/css/main/pricing-table/plus-pricing-style-3.css',
				),
			),
		),
		'tp-pricing-ribbon' => array(
			'dependency' => array(
				'css' => array(
					$tpae_pro_base . 'assets/css/main/pricing-table/plus-table-ribbon.css',
				),
			),
		),
		'tp-product-listout' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_pro_base . 'assets/css/main/product-list/plus-product-list.css',					
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-posts-listing.min.js',     
					$tpae_pro_base . 'assets/js/main/product-listing/plus-product-listing.min.js',
				],
			],
		],
		'tp-product-listout-swatches' => [
			'dependency' => [
				'css' => [			
					$tpae_pro_base . 'assets/css/main/woo-swatches/woo-swatches-front.min.css',
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/main/woo-swatches/woo-swatches-front.min.js',					
				],
			],
		],
		'tp-product-listout-qcw' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/product-list/plus-product-list-yith.css',
					$tpae_pro_base . 'assets/css/extra/jquery.fancybox.min.css',
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/main/product-listing/plus-product-listing-qcw.min.js',
					$tpae_pro_base . 'assets/js/extra/jquery.fancybox.min.js',
				],
			],
		],
		'tp-ajax-based-pagination' => [
			'dependency' => [
				'js' => [					
					$tpae_pro_base . 'assets/js/main/ajax-pagination/plus-ajax-pagination.min.js',				
				],
			],
		],
		'plus-product-listout-yithcss' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/product-list/plus-product-list-yith.css',
				],
			],
		],
		'plus-product-listout-quickview' => [
			'dependency' => [				
				'js' => [					
					$tpae_pro_base . 'assets/js/main/product-listing/plus-product-listing-yith-qcw.min.js',
				],
			],
		],
		'tp-ajax-base-filter' => [
			'dependency' => [				
				'js' => [					
					$tpae_pro_base . 'assets/js/widgets-features/cat-wise-filter/cat-wise-filter.min.js',
				],
			],
		],
		'plus-key-animations' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/plus-animation/plus-key-animations.min.css',
				],
			],
		],
		'tp-protected-content' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/plus-extra-adv/plus-password-protected.css',
				],
			],
		],
		'tp-progress-bar' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/progress-piechart/plus-progress.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/jquery.waypoints.min.js',
					$tpae_base . 'assets/js/main/progress-bar/plus-progress-bar.min.js',
				],
			],
		],
		'tp-piechart' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/progress-piechart/plus-piechart.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/circle-progress.js',
				],
			],
		],
		'tp-process-steps' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/process-steps/plus-process-steps.css',
				],
			],
		],
		'tp-process-bg' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/process-steps/plus-process-bg.css',
				],
			],
		],
		'tp-process-counter' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/process-steps/plus-process-counter.css',
				],
			],
		],
		'tp-process-steps-js' => [
			'dependency' => [
				'js' => [					
					$tpae_pro_base . 'assets/js/main/process-steps/plus-process-steps.min.js',
				],
			],
		],
		'tp-row-background' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/row-background/plus-row-background.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/row-background/plus-row-background.min.js',
				],
			],
		],
		'plus-vegas-gallery' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/extra/vegas.css',					
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/extra/vegas.js',
				],
			],
		],
		'plus-row-animated-color' => [
			'dependency' => [
				'js' => [					
					$tpae_pro_base . 'assets/js/extra/effect.min.js',
					$tpae_pro_base . 'assets/js/main/row-background/plus-row-animate-color.js',
				],
			],
		],
		'plus-row-segmentation' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/anime.min.js',
					$tpae_pro_base . 'assets/js/extra/imagesloaded.pkgd.min.js',
					$tpae_pro_base . 'assets/js/extra/segmentation.js',
					$tpae_pro_base . 'assets/js/main/row-background/plus-row-segmentation.min.js',
				],
			],
		],
		'plus-row-scroll-color' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/scrolling_background_color.js',
					$tpae_pro_base . 'assets/js/extra/scrollmonitor.js',
					$tpae_pro_base . 'assets/js/main/row-background/plus-scroll-bg-color.min.js',
				],
			],
		],
		'plus-row-canvas-particle' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/particles.min.js',
				],
			],
		],
		'plus-row-canvas-particleground' => [
			'dependency' => [
				'js' => [					
					$tpae_pro_base . 'assets/js/extra/jquery.particleground.js', //canvas style 6
				],
			],
		],
		'plus-row-canvas-8' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/main/row-background/plus-row-canvas-style-8.min.js',
				],
			],
		],
		'tp-scroll-navigation' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/scroll-navigation/plus-scroll-navigation.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/pagescroll2id.js',
					$tpae_pro_base . 'assets/js/main/scroll-navigation/plus-scroll-navigation.min.js',
				],
			],
		],
		'tp-scroll-navigation-style-1' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/scroll-navigation/plus-sn-style-1.css',
				],
			],
		],
		'tp-scroll-navigation-style-2' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/scroll-navigation/plus-scroll-style2.css',
				],
			],
		],
		'tp-scroll-navigation-style-3' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/scroll-navigation/plus-scroll-style3.css',
				],
			],
		],
		'tp-scroll-navigation-style-4' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/scroll-navigation/plus-scroll-style4.css',
				],
			],
		],
		'tp-scroll-navigation-style-5' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/scroll-navigation/plus-scroll-style5.css',
				],
			],
		],
		'tp-display-counter' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/scroll-navigation/plus-counter-style.css',
				],
			],
		],
		'tp-scroll-sequence' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/scroll-sequence/tp-scroll-sequence.min.css',
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/main/scroll-sequence/tp-scroll-sequence.min.js',
				],
			],
		],
		'tp-search-filter' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_pro_base . 'assets/css/main/search-filter/plus-search-filter.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/search-filter/plus-search-filter.min.js',
				],
			],
		],
		'tp-search-datepicker' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/extra/datepicker.min.css',
					$tpae_pro_base . 'assets/css/extra/jsdelivr.daterangepicker.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/datepicker.min.js',
					$tpae_pro_base . 'assets/js/extra/moment.min.js',
					$tpae_pro_base . 'assets/js/extra/jsdelivr.daterangepicker.min.js',
				],
			],
		],
		'tp-search-slider' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/extra/nouislider.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/nouislider.min.js',
				],
			],
		],
		'tp-search-bar' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_pro_base . 'assets/css/main/search-bar/plus-search-bar.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/search-bar/plus-search-bar.min.js',
				],
			],
		],
		'tp-shape-divider' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/shape-divider/plus-shape-divider.min.css',
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/main/shape-divider/plus-shape-divider.min.js',
				],
			],
		],
		'tp-site-logo' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/site-logo/plus-site-logo.css',
				],		
			],
		],
		'tp-social-embed' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-embed/plus-social-embed.min.css',
				],		
			],
		],
		'tp-social-feed' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_pro_base . 'assets/css/main/social-feed/plus-social-feed.min.css',
					$tpae_pro_base . 'assets/css/extra/jquery.fancybox.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-posts-listing.min.js',
					$tpae_pro_base . 'assets/js/main/social-feed/plus-social-feed.min.js',
					$tpae_pro_base . 'assets/js/extra/jquery.fancybox.min.js',
				],
			],
		],
		'tp-social-icon' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style.css',
				],				
			],
		],
		'tp-social-icon-style-1' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-1.css',
				],				
			],
		],
		'tp-social-icon-style-2' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-2.css',
				],				
			],
		],
		'tp-social-icon-style-3' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-3.css',
				],				
			],
		],
		'tp-social-icon-style-4' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-4.css',
				],				
			],
		],
		'tp-social-icon-style-5' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-5.css',
				],				
			],
		],
		'tp-social-icon-style-6' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-6.css',
				],				
			],
		],
		'tp-social-icon-style-7' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-7.css',
				],				
			],
		],
		'tp-social-icon-style-8' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-8.css',
				],				
			],
		],
		'tp-social-icon-style-9' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-9.css',
				],				
			],
		],
		'tp-social-icon-style-10' => [	
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-10.css',
				],				
			],
		],
		'tp-social-icon-style-11' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-11.css',
				],				
			],
		],
		'tp-social-icon-style-12' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-12.css',
				],				
			],
		],
		'tp-social-icon-style-13' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-13.css',
				],				
			],
		],
		'tp-social-icon-style-14' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-14.css',
				],				
			],
		],
		'tp-social-icon-style-15' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/social-icon/plus-social-icon-style-15.css',
				],				
			],
		],
		'tp-social-reviews' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_pro_base . 'assets/css/main/social-reviews/plus-social-reviews.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-posts-listing.min.js',
					$tpae_pro_base . 'assets/js/main/social-reviews/plus-social-reviews.min.js',
				],
			],
		],
		'tp-social-reviews-style-1' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/social-reviews/plus-sr-style1.css',
				],
			],
		],
		'tp-social-reviews-style-2' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/social-reviews/plus-sr-style2.css',
				],
			],
		],
		'tp-social-reviews-style-3' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/social-reviews/plus-sr-style3.css',
				],
			],
		],
		'tp-social-sharing' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/social-sharing/plus-social-sharing.css',
				],
				'js' => [
					
					$tpae_pro_base . 'assets/js/main/social-sharing/plus-social-sharing.min.js',
				],
			],
		],
		'tp-social-1-2-layout' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/social-sharing/plus-layout1-2.css',
				],
			],
		],
		'tp-social-toggle-style-1' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/social-sharing/plus-toggle.css',
				],
			],
		],
		'tp-social-toggle-style-2' => [
            'dependency' => [
                'css' => [
                    $tpae_pro_base . 'assets/css/main/social-sharing/plus-tooggle-2.css',
                ],
            ],
        ],
		'tp-style-list' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/stylist-list/plus-style-list.css',
				],
				'js' => [
					$tpae_base . 'assets/js/main/stylist-list/plus-stylist-list.min.js',
				],
			],
		],
		'tp-switcher' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/switcher/plus-switcher.css',
				],
				'js' => [
					$tpae_base . 'assets/js/main/switcher/plus-switcher.min.js',
				],
			],
		],
		'tp-syntax-highlighter' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/syntax-highlighter/plus-syntax-highlighter.css',
				],
			],
		],
		'tp-syntax-highlighter-icons' => [
			'dependency' => [
				'js' => [
					$tpae_base . 'assets/js/extra/syntax-highlighter/tp-copy-dow-icons.js',
				],
			],
		],
		'prism_default' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/syntax-highlighter/plus-default-theme.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/syntax-highlighter/prism-default.js',
				],
			],
		],
		'prism_coy' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/syntax-highlighter/plus-copy-theme.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/syntax-highlighter/prism-coy.js',
				],
			],
		],
		'prism_dark' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/syntax-highlighter/plus-dark-theme.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/syntax-highlighter/prism-dark.js',
				],
			],
		],
		'prism_funky' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/syntax-highlighter/plus-funky-theme.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/syntax-highlighter/prism-funky.js',
				],
			],
		],
		'prism_okaidia' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/syntax-highlighter/plus-okaidia-theme.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/syntax-highlighter/prism-okaidia.js',
				],
			],
		],
		'prism_solarizedlight' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/syntax-highlighter/plus-solarized.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/syntax-highlighter/prism-solarizedlight.js',
				],
			],
		],
		'prism_tomorrownight' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/syntax-highlighter/plus-tomorrow-theme.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/syntax-highlighter/prism-tomorrownight.js',
				],
			],
		],
		'prism_twilight' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/syntax-highlighter/plus-twilight-theme.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/syntax-highlighter/prism-twilight.js',
				],
			],
		],
		'tp-table' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/data-table/plus-data-table.css',
				],
				'js' => [
					$tpae_base . 'assets/js/extra/jquery.datatables.min.js',
					$tpae_base . 'assets/js/main/data-table/plus-data-table.min.js',
				],
			],
		],
		'tp-table-content' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/extra/tocbot.css',
					$tpae_pro_base . 'assets/css/main/table-content/plus-table-content.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/tocbot.min.js',
					$tpae_pro_base . 'assets/js/main/table-content/plus-table-content.min.js',
				],
			],
		],
		'tp-table-content-style-1' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/table-content/plus-content-style1.css',
				],
			],
		],
		'tp-table-content-style-2' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/table-content/plus-content-style2.css',
				],
			],
		],
		'tp-table-content-style-3' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/table-content/plus-content-style3.css',
				],
			],
		],
		'tp-table-content-style-4' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/table-content/plus-content-style4.css',
				],
			],
		],
		'tp-tabs-tours' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/tabs-tours/plus-tabs-tours.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/tabs-tours/plus-tabs-tours.min.js',
				],
			],
		],
		'tp-team-member-listout' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_base . 'assets/css/main/team-member-list/plus-team-member-style.css',	
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-posts-listing.min.js',
					$tpae_pro_base . 'assets/js/main/team-member-listout/team-member.min.js',
				],
			],
		],
		'tp-team-member-style-1' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/team-member-list/plus-team-member-style-1.css',
				],
			],
		],
		'tp-team-member-style-2' => [
			'dependency' => [
				'css' => [					
				    $tpae_pro_base . 'assets/css/main/team-member-list/plus-team-member-style-2.css',
				],
			],
		],
		'tp-team-member-style-3' => [
			'dependency' => [
				'css' => [					
					$tpae_base . 'assets/css/main/team-member-list/plus-team-member-style-3.css',
				],
			],
		],
		'tp-team-member-style-4' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/team-member-list/plus-team-member-style-4.css',
				],
			],
		],
		'tp-carousel-style' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/carousel/plus-carousel.css',
				],
			],
		],
		'tp-carousel-style-1' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/carousel/plus-carousel-style-1.css',
				],
			],
		],
		'tp-carousel-style-2' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/carousel/plus-carousel-style-2.css',
				],
			],
		],
		'tp-carousel-style-3' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/carousel/plus-carousel-style-3.css',
				],
			],
		],
		'tp-carousel-style-4' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/carousel/plus-carousel-style-4.css',
				],
			],
		],
		'tp-carousel-style-5' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/carousel/plus-carousel-style-5.css',
				],
			],
		],
		'tp-carousel-style-6' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/carousel/plus-carousel-style-6.css',
				],
			],
		],
		'tp-carousel-style-7' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/carousel/plus-carousel-style-7.css',
				],
			],
		],
		'tp-arrows-style' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/arrows/plus-arrows-style.css',
				],
			],
		],
		'tp-arrows-style-1' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/arrows/plus-arrows-style-1.css',
				],
			],
		],
		'tp-arrows-style-2' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/arrows/plus-arrows-style-2.css',
				],
			],
		],
		'tp-arrows-style-3' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/arrows/plus-arrows-style-3-4.css',
				],
			],
		],
		'tp-arrows-style-4' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/arrows/plus-arrows-style-3-4.css',
				],
			],
		],
		'tp-arrows-style-5' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/arrows/plus-arrows-style-5.css',
				],
			],
		],
		'tp-arrows-style-6' => [
			'dependency' => [
				'css' => [
					 $tpae_pro_base . 'assets/css/main/arrows/plus-arrows-style-6.css',
				],
			],
		],
		'tp-testimonial-listout' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_base . 'assets/css/main/testimonial/plus-testimonial.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/imagesloaded.pkgd.min.js',
					$tpae_pro_base . 'assets/js/main/testimonial/plus-testimonial.min.js',
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-posts-listing.min.js',
				],
			],
		],
		'tp-testimonial-style-1' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/testimonial/plus-ts1.css',
				],
			],
		],
		'tp-testimonial-style-2' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/testimonial/plus-ts2.css',
				],
			],
		],
		'tp-testimonial-style-3' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/testimonial/plus-ts3.css',
				],
			],
		],
		'tp-testimonial-style-4' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/testimonial/plus-ts4.css',
				],
			],
		],
		'tp-timeline' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/timeline/plus-timeline.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/timeline/plus-timeline.min.js',					
				],
			],
		],
		'tp-timeline-animation' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/jquery.waypoints.min.js',
					$tpae_pro_base . 'assets/js/extra/velocity/velocity.min.js',
					$tpae_pro_base . 'assets/js/extra/velocity/velocity.ui.js',
					$tpae_pro_base . 'assets/js/main/general/plus-animation-load.min.js',				
				],
			],
		],
		'tp-timeline-masonry' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/imagesloaded.pkgd.min.js',
					$tpae_pro_base . 'assets/js/extra/isotope.pkgd.js',
					$tpae_pro_base . 'assets/js/extra/packery-mode.pkgd.min.js',					
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-posts-listing.min.js',	
				],
			],
		],
		'tp-timeline-style-1' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/timeline/plus-timeline-style-1.css',
				],
			],
		],
		'tp-timeline-style-2' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/timeline/plus-timeline-style-2.css',
				],
			],
		],
		'tp-unfold' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/unfold/plus-unfold.min.css',
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/main/unfold/plus-unfold.min.js',
				],
			],
		],
		'tp-video-player' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/video-player/plus-video-player.css',
				],
				'js' => [
					$tpae_base . 'assets/js/main/video-player/plus-video-player.min.js',
				],
			],
		],
		'tp-dynamic-categories' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_pro_base . 'assets/css/main/dynamic-categories/plus-dynamic-categories.css',
				],
				'js'  => [
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-posts-listing.min.js',
				],
			],
		],
		'tp-dynamic-categories-style_1' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/dynamic-categories/dynamic-style-1.css',
				],
			],
		],
		'tp-dynamic-categories-style_2' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/dynamic-categories/dynamic-style-2.css',
				],
			],
		],
		'tp-dynamic-categories-style_3' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/dynamic-categories/dynamic-style-3.css',
				],
			],
		],
		'tp-dynamic-categories-st3' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/main/dynamic-category/plus-dynamic-category.min.js',	
				],
			],
		],
		'tp-wp-forms' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/forms-style/plus-wpforms-form.css',
				],
			],
		],
		'tp-woo-cart' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-cart/plus-woo-cart.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/woo-cart/plus-woo-cart.min.js',	
				],
			],
		],
		'tp-woo-checkout' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-checkout/plus-woo-checkout.min.css',
				],
			],
		],
		'tp-woo-compare' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-compare/plus-woo-compare.min.css',

				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/woo-compare/plus-woo-compare.min.js',
				],
			],
		],
		'tp-woo-compare-list' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-compare/plus-woo-compare-list.min.css',

				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/woo-compare/woo-compare-list.min.js',
				],
			],
		],
		'tp-woo-compare-count' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-compare/plus-woo-compare-count.min.css',

				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/woo-compare/woo-compare-count.min.js',
				],
			],
		],
		'tp-woo-compare-button' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/main/woo-compare/woo-compare-btn.min.js',
				],
			],
		],
		'tp-woo-multi-step' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-multi-step/plus-woo-multi-step.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/woo-multi-step/plus-woo-multi-step.min.js',
				],
			],
		],
		'tp-woo-multi-step-style-1' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-multi-step/plus-multi-step-s1.min.css',
				],
			],
		],
		'tp-woo-multi-step-style-2' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-multi-step/plus-multi-step-s2.min.css',
				],
			],
		],
		'tp-woo-multi-step-style-3' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-multi-step/plus-multi-step-s3.min.css',
				],
			],
		],
		'tp-woo-multi-step-style-4' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-multi-step/plus-multi-step-s4.min.css',
				],
			],
		],
		'tp-woo-multi-step-style-5' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-multi-step/plus-multi-step-s5.min.css',
				],
			],
		],
		'tp-woo-multi-step-coupon' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/main/woo-multi-step/plus-multi-step-coupon.min.js',
				],
			],
		],
		'tp-woo-multi-step-backend' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/main/woo-multi-step/plus-multi-step-backend.min.js',
				],
			],
		],
		'tp-woo-myaccount' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-my-account/plus-woo-my-account.css',
				],
			],
		],
		'tp-woo-wishlist' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-wishlist/plus-woo-wishlist.min.css',

				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/woo-wishlist/plus-woo-wishlist.min.js',
				],
			],
		],
		'tp-woo-wishlist-product-listing' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-wishlist/plus-woo-wishlist.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-product-woo-listing.min.js',
				],
			],
		],
		'tp-woo-wishlist-dynamic-listing' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-product-woo-listing.min.js'
				],
			],
		],
		'tp_ma_l_1' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-my-account/plus-account-style1.css',
				],
			],
		],
		'tp_ma_l_2' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-my-account/plus-account-style2.css',
				],
			],
		],
		'tp-woo-order-track' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-order-track/plus-woo-order-track.min.css',
				],			
			],
		],
		'tp-woo-single-basic' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/woo-single-basic/plus-woo-single-basic.min.css',
				],
			],
		],
		'tp-woo-single-pricing' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/woo-single-pricing/plus-woo-single-pricing.min.css',
				],				
				'js' => [					
					$tpae_pro_base . 'assets/js/main/woo-single-pricing/plus-add-to-cart.min.js',
				],
			],
		],
		'tp-woo-single-price-progress' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/woo-single-pricing/plus-woo-single-pricing-progress.min.css',
				],				
				'js' => [					
					$tpae_pro_base . 'assets/js/main/woo-single-pricing/plus-woo-single-price-progress.min.js',
				],
			],
		],
		'tp-woo-single-image' => [
			'dependency' => [
				'css' => [
					$tpae_base .  'assets/css/extra/tp-bootstrap-grid.css',
					$tpae_pro_base . 'assets/css/main/woo-single-image/plus-woo-single-image.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/imagesloaded.pkgd.min.js',
					$tpae_pro_base . 'assets/js/extra/isotope.pkgd.js',
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-posts-listing.min.js',
				],
			],
		],		
		'tp-single-style_1' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-single-image/plus-image-style1.css',
				],
			],
		],
		'tp-single-style_3' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-single-image/plus-image-style2.css',
				],
			],
		],
		'tp-single-hover' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/woo-single-image/plus-image-hover.css',
				],
			],
		],
		'tp-woo-single-tabs' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/woo-single-tabs/plus-woo-single-tabs.min.css',
				],
			],
		],
		'tp-woo-thank-you' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/woo-thank-you/plus-woo-thank-you.min.css',
				],
			],
		],
		'tp-product-recent-view' => [
            'dependency' => [
                'js' => [
					$tpae_pro_base . 'assets/js/main/posts-listing/plus-product-woo-listing.min.js'
                ],
            ],
        ],
		'tp-wp-quickview' => [
            'dependency' => [
                'css' => [
                    $tpae_pro_base . 'assets/css/extra/jquery.fancybox.min.css',
                    $tpae_pro_base . 'assets/css/main/wp-quick-view/plus-wp-quick-view.min.css',
                ],
                'js' => [
                    $tpae_pro_base . 'assets/js/extra/jquery.fancybox.min.js',
                    $tpae_pro_base . 'assets/js/main/wp-quick-view/plus-wp-quick-view.min.js',
                ],
            ],
        ],
		'tp-wp-login-register' => [
			'dependency' => [
				'css' => [					
					$tpae_pro_base . 'assets/css/main/wp-login-register/plus-wp-login-register.min.css',
				],
			],
		],
		'tp-wp-login-register-ex' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/main/login-register/plus-login-register.min.js',
				],
			],
		],
		'plus-lottie-player' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/lottie-player.js',
				],
			],
		],
		'plus-velocity' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/jquery.waypoints.min.js',
					$tpae_pro_base . 'assets/js/extra/velocity/velocity.min.js',
					$tpae_pro_base . 'assets/js/extra/velocity/velocity.ui.js',
					$tpae_pro_base . 'assets/js/main/general/plus-animation-load.min.js',
				],
			],
		],
		'plus-alignmnet-effect' => [
			'dependency' => [
				'css' => [
					$tpae_base .  'assets/css/main/plus-extra-adv/plus-alignmnet.css',
				],
			],
		],
		'plus-responsive-visibility' => [
			'dependency' => [
				'css' => [
					$tpae_base .  'assets/css/main/plus-extra-adv/plus-responsive-visibility.css',
				],
			],
		],
		'plus-widget-error' => [
			'dependency' => [
				'css' => [
					$tpae_base .  'assets/css/main/plus-extra-adv/plus-widget-error.css',
				],
			],
		],
		'plus-magic-scroll' => [
			'dependency' => [
				'js' => [					
					$tpae_pro_base . 'assets/js/extra/tweenmax/timelinemax.min.js',
					$tpae_pro_base . 'assets/js/extra/tweenmax/tweenmax.min.js',
					$tpae_pro_base . 'assets/js/extra/scrollmagic/scrollmagic.min.js',
					$tpae_pro_base . 'assets/js/extra/scrollmagic/animation.gsap.min.js',
					$tpae_pro_base . 'assets/js/main/general/plus-magic-scroll.min.js',
				],
			],
		],
		'plus-tooltip' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/extra/tippy.css',
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/extra/tippy.all.min.js',
				],
			],
		],
		'plus-mousemove-parallax' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/tweenmax/tweenmax.min.js',
					$tpae_pro_base . 'assets/js/main/general/plus-mouse-move-parallax.min.js',
				],
			],
		],
		'plus-tilt-parallax' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/plus-animation/plus-tilt-animation.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/tilt.jquery.min.js',
					$tpae_pro_base . 'assets/js/main/general/plus-tilt-parallax.min.js',
				],
			],
		],
		'plus-reveal-animation' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/plus-extra-adv/plus-reveal-animate.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/jquery.waypoints.min.js',
					$tpae_pro_base . 'assets/js/main/general/plus-reveal-animation.min.js',
				],
			],
		],
		'plus-floating-animation' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/plus-continues-effect/plus-floating-animation.css',
				],
			],
		],
		'plus-pulse-animation' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/plus-continues-effect/plus-pulse-animation.css',
				],
			],
		],
		'plus-tossing-animation' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/plus-continues-effect/plus-tossing-animation.css',
				],
			],
		],
		'plus-drop-waves-animation' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/plus-continues-effect/plus-drop-waves.css',
				],
			],
		],
		'plus-rotating-animation' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/plus-continues-effect/plus-rotating-animation.css',
				],
			],
		],
		'plus-continue-scale-animation' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/plus-continues-effect/plus-kenburns-animation.css',
				],
			],
		],
		'plus-content-hover-effect' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/plus-extra-adv/plus-content-hover-effect.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/general/plus-content-hover-effect.min.js',
				],
			],
		],
		'plus-carousel' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/extra/slick.min.css',
					$tpae_base . 'assets/css/main/carousel/plus-carousel.css'
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/slick.min.js',
					$tpae_pro_base . 'assets/js/main/general/plus-slick-carousel.min.js',
				],
			],
		],
		'plus-imagesloaded' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/imagesloaded.pkgd.min.js',
				],
			],
		],
		'plus-isotope' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/isotope.pkgd.js',
				],
			],
		],
		'plus-hover3d' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/jquery.hover3d.min.js',
					$tpae_pro_base . 'assets/js/main/general/plus-hover-tilt.js',
				],
			],
		],
		'plus-wavify' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/tweenmax/tweenmax.min.js',
					$tpae_pro_base . 'assets/js/extra/wavify.js',
				],
			],
		],
		'plus-lity-popup' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/extra/lity.css',
					$tpae_pro_base . 'assets/css/main/plus-extra-adv/plus-lity.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/lity.min.js',
				],
			],
		],
		'plus-extras-column' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/plus-extra-adv/plus-sticky-column.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/resizesensor.min.js',
					$tpae_pro_base . 'assets/js/extra/sticky-sidebar.min.js',					
					$tpae_pro_base . 'assets/js/main/column-stickly/plus-column-stickly.min.js',
				],
			],
		],
		'plus-event-tracker' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/main/event-tracker/plus-event-tracker.min.js',
				],
			],
		],
		'plus-lazyLoad' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/lazy_load/tp-lazy_load.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/lazyload.min.js',
					$tpae_pro_base . 'assets/js/main/lazy_load/tp-lazy_load.js',
				],
			],
		],
		'plus-column-cursor' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/mouse-cursor/plus-mouse-cursor.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/main/mouse-cursor/plus-mouse-cursor.min.js',
				],
			],
		],
		'plus-extras-section-skrollr' => [
			'dependency' => [
				'js' => [
					$tpae_pro_base . 'assets/js/extra/skrollr.min.js',
					$tpae_pro_base . 'assets/js/main/general/plus-section-skrollr.min.js',
				],
			],
		],
		'plus-adv-typo-extra-js-css' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/extra/imagerevealbase.css',
				],
				'js' => [										
					$tpae_pro_base . 'assets/js/extra/charming.min.js',					
					$tpae_pro_base . 'assets/js/extra/imagesloaded.pkgd.min.js',					
					$tpae_pro_base . 'assets/js/extra/tweenmax/tweenmax.min.js',
					$tpae_pro_base . 'assets/js/extra/imagerevealdemo.js',
				],
			],
		],
		'plus-swiper' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/extra/swiper-bundle.min.css',
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/extra/swiper-bundle.min.js',
				],
			],
		],
		'plus-listing-load-more' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/listing-extra/ajax-load-more.css',
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/widgets-features/load-more/ajax-load-more.min.js',
				],
			],
		],
		'plus-wishlist-listing-load-more' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/listing-extra/ajax-load-more.css',
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/widgets-features/load-more/wishlist-load-more.min.js',
				],
			],
		],
		'plus-listing-lazy-load' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/listing-extra/ajax-load-more.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/widgets-features/lazy-load/ajax-lazy-load.min.js',
				],
			],
		],
		'plus-wishlist-listing-lazy-load' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/main/listing-extra/ajax-load-more.css',
				],
				'js' => [					
					$tpae_pro_base . 'assets/js/widgets-features/lazy-load/wishlist-lazy-load.min.js',
				],
			],
		],
		'plus-list-skeleton' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/widgets-features/tp-skeleton/plus-skeleton.min.css',
				],
			],
		],
		'plus-temp-notice' => [
			'dependency' => [
				'css' => [
					$tpae_base . 'assets/css/main/plus-extra-adv/plus-temp-notice.css',
				],
			],
		],
		'plus-backend-editor' => [
			'dependency' => [
				'css' => [
					$tpae_pro_base . 'assets/css/extra/tippy.css',
					$tpae_pro_base . 'assets/css/main/plus-extra-adv/plus-content-hover-effect.min.css',
				],
				'js' => [
					$tpae_pro_base . 'assets/js/extra/swiper-bundle.min.js',
					$tpae_pro_base . 'assets/js/extra/jquery.waypoints.min.js',
					$tpae_pro_base . 'assets/js/extra/general/modernizr.min.js',
					$tpae_pro_base . 'assets/js/extra/velocity/velocity.min.js',
					$tpae_pro_base . 'assets/js/extra/velocity/velocity.ui.js',					
					$tpae_pro_base . 'assets/js/extra/tilt.jquery.min.js',
					$tpae_pro_base . 'assets/js/extra/tippy.all.min.js',
					$tpae_pro_base . 'assets/js/extra/tweenmax/timelinemax.min.js',
					$tpae_pro_base . 'assets/js/extra/tweenmax/tweenmax.min.js',
					$tpae_pro_base . 'assets/js/extra/tweenmax/jquery-parallax.js',
					$tpae_pro_base . 'assets/js/extra/scrollmagic/scrollmagic.min.js',
					$tpae_pro_base . 'assets/js/extra/scrollmagic/animation.gsap.min.js',
					$tpae_pro_base . 'assets/js/main/plus-extra-adv/plus-backend-editor.min.js',
					$tpae_pro_base . 'assets/js/main/general/plus-animation-load.min.js',
					$tpae_pro_base . 'assets/js/main/general/plus-magic-scroll.min.js',
					$tpae_pro_base . 'assets/js/main/general/plus-mouse-move-parallax.min.js',
					$tpae_pro_base . 'assets/js/main/general/plus-reveal-animation.min.js',
					$tpae_pro_base . 'assets/js/main/general/plus-content-hover-effect.min.js',
					$tpae_pro_base . 'assets/js/extra/splittext.min.js',
					$tpae_pro_base . 'assets/js/main/heading-title/plus-heading-title.min.js',
					$tpae_base . 'assets/js/admin/tp-advanced-shadow-layout.js',
				],
			],
		],
	];
;
