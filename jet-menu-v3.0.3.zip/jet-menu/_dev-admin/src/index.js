import domReady from "@wordpress/dom-ready";
import {createRoot} from "@wordpress/element";
import apiFetch from "@wordpress/api-fetch";
import App from "./components/App";
import "./components/dynamic-visibility/api/registry";

import "./style.scss";
import "./components/styles.scss";

domReady(() => {
	apiFetch.use(apiFetch.createNonceMiddleware(window.JetMenusAdmin?.nonce));

	if (window.JetMenusAdmin?.restUrl) {
		apiFetch.use(apiFetch.createRootURLMiddleware(window.JetMenusAdmin.restUrl));
	}


	const el = document.getElementById("jet-menus-app");
	if (el) createRoot(el).render(<App/>);
});