const defaultConfig = require("@wordpress/scripts/config/webpack.config");
const path = require("path");

module.exports = {
    ...defaultConfig,
    entry: {
        index: path.resolve(__dirname, "src/index.js"),
		"meta-modal": path.resolve(__dirname, "src/meta-modal/index.js"),
    },
    output: {
        ...defaultConfig.output,
        path: path.resolve(__dirname, "../assets/admin/js/nav-settings"),
        filename: "[name].js",
        clean: true,
    },
};
