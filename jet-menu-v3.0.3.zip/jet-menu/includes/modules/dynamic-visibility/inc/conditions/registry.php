<?php

namespace Jet_Menu\Modules\Dynamic_Visibility\Conditions;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Registry {

	private $conditions = array();

	public function __construct() {
		$this->register_defaults();
		$this->register_custom();
	}

	/**
	 * Public registration method.
	 *
	 * @param Base_Condition $condition
	 */
	public function register_condition( $condition ) {

		if ( ! is_object( $condition ) || ! $condition instanceof Base_Condition ) {
			return;
		}

		$key = $condition->get_key();

		if ( ! $key ) {
			return;
		}

		$this->conditions[ $key ] = $condition;
	}

	public function has( $key ) {
		return isset( $this->conditions[ $key ] );
	}

	public function get( $key ) {
		return isset( $this->conditions[ $key ] ) ? $this->conditions[ $key ] : false;
	}

	public function all() {
		return $this->conditions;
	}

	/**
	 * Built-in conditions registration.
	 */
	protected function register_defaults() {

		$path = jet_menu()->plugin_path( 'includes/modules/dynamic-visibility/inc/conditions/' );

		require_once $path . 'base-condition.php';

		// User
		require_once $path . 'logged-in.php';
		require_once $path . 'user-role.php';

		// Page context
		require_once $path . 'is-front-page.php';
		require_once $path . 'is-home.php';
		require_once $path . 'is-singular.php';
		require_once $path . 'is-page.php';
		require_once $path . 'is-archive.php';
		require_once $path . 'is-search.php';
		require_once $path . 'is-404.php';

		// WooCommerce
		require_once $path . 'wc-is-cart.php';
		require_once $path . 'wc-is-checkout.php';
		require_once $path . 'wc-is-account.php';
		require_once $path . 'wc-is-shop.php';
		require_once $path . 'wc-is-product.php';
		require_once $path . 'wc-is-product-category.php';
		require_once $path . 'wc-is-product-tag.php';

		// Register built-in
		$this->register_condition( new Logged_In() );
		$this->register_condition( new User_Role() );

		$this->register_condition( new Is_Front_Page() );
		$this->register_condition( new Is_Home() );
		$this->register_condition( new Is_Singular() );
		$this->register_condition( new Is_Page() );
		$this->register_condition( new Is_Archive() );
		$this->register_condition( new Is_Search() );
		$this->register_condition( new Is_404() );

		$this->register_condition( new WC_Is_Cart() );
		$this->register_condition( new WC_Is_Checkout() );
		$this->register_condition( new WC_Is_Account() );
		$this->register_condition( new WC_Is_Shop() );
		$this->register_condition( new WC_Is_Product() );
		$this->register_condition( new WC_Is_Product_Category() );
		$this->register_condition( new WC_Is_Product_Tag() );
	}

	/**
	 * Allow 3rd-party registration.
	 */
	protected function register_custom() {
		/**
		 * Example:
		 * add_action( 'jet-menu/modules/dynamic-visibility/register-condition', function( $registry ) {
		 *     $registry->register_condition( new My_Custom_Condition() );
		 * } );
		 */
		do_action( 'jet-menu/modules/dynamic-visibility/register-condition', $this );
	}
}