<?php

namespace Jet_Menu\Modules\Dynamic_Visibility\Conditions;

if ( ! defined( 'WPINC' ) ) {
	die;
}

class WC_Is_Product extends Base_Condition {

	public function get_key() {
		return 'wc_is_product';
	}

	public function check( $rule, $context ) {
		return function_exists( 'is_product' ) ? is_product() : false;
	}
}
