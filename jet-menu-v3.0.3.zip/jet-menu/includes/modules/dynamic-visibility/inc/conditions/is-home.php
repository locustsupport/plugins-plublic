<?php

namespace Jet_Menu\Modules\Dynamic_Visibility\Conditions;

if ( ! defined( 'WPINC' ) ) {
	die;
}

class Is_Home extends Base_Condition {

	public function get_key() {
		return 'is_home';
	}

	public function check( $rule, $context ) {
		return is_home();
	}
}
