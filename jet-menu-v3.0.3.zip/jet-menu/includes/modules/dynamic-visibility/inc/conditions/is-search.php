<?php

namespace Jet_Menu\Modules\Dynamic_Visibility\Conditions;

if ( ! defined( 'WPINC' ) ) {
	die;
}

class Is_Search extends Base_Condition {

	public function get_key() {
		return 'is_search';
	}

	public function check( $rule, $context ) {
		return is_search();
	}
}
