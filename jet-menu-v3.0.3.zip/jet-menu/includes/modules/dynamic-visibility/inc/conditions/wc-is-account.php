<?php

namespace Jet_Menu\Modules\Dynamic_Visibility\Conditions;

if ( ! defined( 'WPINC' ) ) {
	die;
}

class WC_Is_Account extends Base_Condition {

	public function get_key() {
		return 'wc_is_account';
	}

	public function check( $rule, $context ) {
		return function_exists( 'is_account_page' ) ? is_account_page() : false;
	}
}
