<?php

namespace Jet_Menu\Modules\Dynamic_Visibility\Conditions;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class User_Role extends Base_Condition {

	public function get_key() {
		return 'user_role';
	}

	public function check( $rule, $context ) {

		$operator = $this->get_rule_operator( $rule, 'in' ); // in|not_in
		$roles    = $this->get_rule_value( $rule, 'roles', array() );
		$roles    = is_array( $roles ) ? $roles : array();

		$user       = wp_get_current_user();
		$user_roles = isset( $user->roles ) && is_array( $user->roles ) ? $user->roles : array();

		$has_intersection = (bool) array_intersect( $user_roles, $roles );

		if ( 'in' === $operator ) {
			return $has_intersection;
		}

		if ( 'not_in' === $operator ) {
			return ! $has_intersection;
		}

		return false;
	}
}