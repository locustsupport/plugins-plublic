<?php

namespace Jet_Menu\Modules\Dynamic_Visibility\Conditions;

if ( ! defined( 'WPINC' ) ) {
	die;
}

class Is_Archive extends Base_Condition {

	public function get_key() {
		return 'is_archive';
	}

	public function check( $rule, $context ) {
		return is_archive();
	}
}
