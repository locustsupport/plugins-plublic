<?php

namespace Jet_Menu\Modules\Dynamic_Visibility;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Context {

	protected $data = array();

	public function __construct( $data = array() ) {
		$this->data = is_array( $data ) ? $data : array();
	}

	public function get( $key, $default = null ) {

		if ( isset( $this->data[ $key ] ) ) {
			return $this->data[ $key ];
		}

		return $default;
	}
}
