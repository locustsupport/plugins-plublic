# Chaty Pro 3.3.4 — custom security patch

This is a custom-patched copy of the originally supplied Chaty Pro 3.3.4 package.
The vendor/plugin version header is intentionally unchanged to avoid representing this build as an official Premio 3.5.9 release.

## CVE-2026-6251 — Authenticated SQL Injection

Patched `admin/class-admin-base.php::fetch_custom_field()` by:

- verifying the nonce before any database query;
- requiring the `manage_options` capability;
- converting `widget_id` to an integer with `absint()`;
- using `$wpdb->prepare()` with a `%d` placeholder;
- handling missing rows safely; and
- applying safer output escaping to generated custom-field HTML.

## CVE-2026-73360 — Unauthenticated reflected XSS

Patched `js/cht-front-script.min.js` by adding context-safe HTML escaping for DOM-derived current-page title/URL data before those values are concatenated into generated HTML, including Chat View merge-tag output and hidden contact-form fields.

## Important

The upstream recommended remediation remains an official update to Chaty Pro 3.5.9 or later. Version-only vulnerability scanners may continue to flag this custom build because the plugin header remains 3.3.4.
