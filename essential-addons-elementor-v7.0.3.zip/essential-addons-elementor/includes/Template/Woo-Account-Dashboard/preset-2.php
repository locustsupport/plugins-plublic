<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly.
/**
 * Template Name: Preset 2
 */
?>
<div class="eael-account-dashboard-wrapper preset-2">
    <div class="eael-account-dashboard-body">
        <div class="eael-account-dashboard-container">
            <?php $this->get_account_dashboard_navbar($current_user); ?>
            <?php $this->get_account_dashboard_content($current_user, $is_editor); ?>
        </div>
    </div>
</div>