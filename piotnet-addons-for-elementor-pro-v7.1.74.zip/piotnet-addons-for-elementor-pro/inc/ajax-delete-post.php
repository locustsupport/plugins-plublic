<?php
    if ( ! defined( 'ABSPATH' ) ) { exit; }
    
	add_action( 'wp_ajax_pafe_delete_post', 'pafe_delete_post' );
	function pafe_delete_post() {
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( [ 'message' => 'Authentication required.' ], 401 );
		}

		check_ajax_referer( 'pafe_delete_post', 'nonce' );

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		if ( empty( $id ) ) {
			wp_send_json_error( [ 'message' => 'Missing post ID.' ], 400 );
		}

		if ( ! current_user_can( 'delete_post', $id ) ) {
			wp_send_json_error( [ 'message' => 'You do not have permission to delete the post.' ], 403 );
		}

		$force_delete = ! empty( $_POST['force_delete'] ) && absint( $_POST['force_delete'] ) === 1;
		$deleted = wp_delete_post( $id, $force_delete );

		if ( false === $deleted || null === $deleted ) {
			wp_send_json_error( [ 'message' => 'Delete failed.' ], 500 );
		}

		wp_send_json_success( [ 'deleted' => $id ] );
	}
?>