<?php
namespace Elementor\PafeCustomControls;

use \Elementor\Base_Data_Control;

class Select_Files_Control extends Base_Data_Control {

	const Select_Files = 'pafe_custom_control_select_files';

	/**
	 * Set control type.
	 */
	public function get_type() {
		return self::Select_Files;
	}

	/**
	 * Enqueue control scripts and styles.
	 */
	public function enqueue() {

	}

	/**
	 * Set default settings
	 */
	protected function get_default_settings() {
		return [
			'default' => '',
		];
	}

	/**
	 * control field markup
	 */
	public function content_template() {
		?>
		<div class="elementor-control-field">
			<# if ( data.label ) {#>
				<label for="<?php $this->print_control_uid(); ?>" class="elementor-control-title">{{{ data.label }}}</label>
			<# } #>
			<div class="elementor-control-input-wrapper elementor-control-unit-5">
				<?php
					$upload     = wp_upload_dir();
					$upload_dir = $upload['basedir'];
					$dir        = trailingslashit( $upload_dir ) . 'piotnet-addons-for-elementor/widget-creator';
					$dir_tree   = [];

					// Make sure the base directory exists; otherwise scandir() throws warnings in PHP 8.
					if ( ! is_dir( $dir ) ) {
						wp_mkdir_p( $dir );
					}

					if ( is_dir( $dir ) ) {
						$ffs = scandir( $dir );
						if ( ! is_array( $ffs ) ) {
							$ffs = [];
						}

						foreach ( $ffs as $ff ) {
							if ( $ff === '.' || $ff === '..' || substr( $ff, 0, 1 ) === '.' ) {
								continue;
							}

							$sub_path = $dir . '/' . $ff;

							if ( is_dir( $sub_path ) ) {
								$ffs_inside = scandir( $sub_path );
								if ( ! is_array( $ffs_inside ) ) {
									$ffs_inside = [];
								}

								$dir_tree_item = [];
								foreach ( $ffs_inside as $ff_inside ) {
									if ( $ff_inside === '.' || $ff_inside === '..' || substr( $ff_inside, 0, 1 ) === '.' ) {
										continue;
									}
									$ext_inside = strtolower( pathinfo( $ff_inside, PATHINFO_EXTENSION ) );
									if ( ! in_array( $ext_inside, [ 'css', 'js' ], true ) ) {
										continue;
									}
									if ( is_file( $sub_path . '/' . $ff_inside ) ) {
										$dir_tree_item[] = $ff_inside;
									}
								}

								if ( ! empty( $dir_tree_item ) ) {
									$dir_tree[ $ff ] = $dir_tree_item;
								}
							} else {
								// Files placed directly inside widget-creator/ (no sub-folder).
								$ext_root = strtolower( pathinfo( $ff, PATHINFO_EXTENSION ) );
								if ( ! in_array( $ext_root, [ 'css', 'js' ], true ) ) {
									continue;
								}
								if ( ! isset( $dir_tree[''] ) ) {
									$dir_tree[''] = [];
								}
								$dir_tree[''][] = $ff;
							}
						}
					}
				?>
				<ul class="pafe-widget-creator-assets-folder">
					<#
						var value = ( data.controlValue && typeof data.controlValue === 'string' )
							? data.controlValue.split(',')
							: [];
					#>
					<?php foreach ( $dir_tree as $folder => $files ) : ?>
						<li>
							<?php echo esc_html( $folder !== '' ? $folder : '/' ); ?>
							<ul>
								<?php foreach ( $files as $file ) :
									$file_value = $folder !== '' ? $folder . '/' . $file : $file;
								?>
									<li>
										<#
											var checked = ( -1 !== value.indexOf( '<?php echo esc_js( $file_value ); ?>' ) ) ? 'checked' : '';
										#>
										<label>
											<input type="checkbox" name="pafe_widget_creator_assets_files" {{ checked }} value="<?php echo esc_attr( $file_value ); ?>"><?php echo esc_html( $file ); ?>
										</label>
									</li>
								<?php endforeach; ?>
							</ul>
						</li>
					<?php endforeach; ?>
				</ul>
				<input type="hidden" data-setting="{{ data.name }}" id="<?php $this->print_control_uid(); ?>" >
			</div>
		</div>
		<?php
	}
}
