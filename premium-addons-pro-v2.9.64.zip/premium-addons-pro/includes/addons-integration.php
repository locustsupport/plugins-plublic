<?php
/**
 * PAPRO Addons Integration.
 */

namespace PremiumAddonsPro\Includes;

use PremiumAddonsPro\Admin\Includes\Admin_Helper as Papro_Admin_Helper;

// Premium Addons Classes.
use PremiumAddons\Admin\Includes\Admin_Helper;
use PremiumAddons\Includes\Helper_Functions;
use PremiumAddons\Includes\Assets_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

/**
 * Class Addons_Integration.
 */
class Addons_Integration {

	/**
	 * Class instance
	 *
	 * @var instance
	 */
	private static $instance = null;

	/**
	 * Modules
	 *
	 * @var modules
	 */
	private static $modules = null;

	/**
	 * Class Constructor
	 */
	public function __construct() {

		if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
			return;
		}

		self::$modules = Admin_Helper::get_enabled_elements();

		$load_prev_scripts = in_array( true, array( self::$modules['premium-blob'], self::$modules['premium-parallax'], self::$modules['premium-image-hotspots'], self::$modules['premium-img-layers'] ), true );

		// Load widgets files.
		add_action( 'elementor/widgets/register', array( $this, 'register_pro_elements' ) );

		// Enqueue Editor assets.
		add_action( 'elementor/editor/before_enqueue_scripts', array( $this, 'enqueue_editor_scripts' ) );

		// Enqueue Preview CSS files.
		add_action( 'elementor/preview/enqueue_styles', array( $this, 'enqueue_preview_styles' ) );

		if ( $load_prev_scripts ) {
			// Enqueue Preview JS files.
			add_action( 'elementor/preview/enqueue_scripts', array( $this, 'enqueue_preview_scripts' ) );
		}

		// Register Frontend CSS files.
		add_action( 'elementor/frontend/after_register_styles', array( $this, 'register_frontend_styles' ) );

		// Registers Frontend JS files.
		add_action( 'elementor/frontend/after_register_scripts', array( $this, 'register_frontend_scripts' ) );

		// Registers AJAX Hooks.
		add_action( 'wp_ajax_handle_table_data', array( $this, 'handle_table_data' ) );
		add_action( 'wp_ajax_nopriv_handle_table_data', array( $this, 'handle_table_data' ) );

		add_action( 'wp_ajax_get_fb_page_token', array( $this, 'get_fb_page_token' ) );

		add_action( 'wp_ajax_get_instagram_token', array( $this, 'get_instagram_token' ) );

		add_action( 'wp_ajax_clear_reviews_data', array( $this, 'clear_reviews_data' ) );
		add_action( 'wp_ajax_get_papro_key', array( $this, 'get_papro_key' ) );

		$this->load_papro_extensions();

		if ( self::$modules['premium-behance'] ) {
			define( 'PREMIUM_BEHANCE_API_KEY', 'XQhsS66hLTKjUoj8Gky7FOFJxNMh23uu' );
		}
	}

	/**
	 * Get Facebook page token for Facebook Reviews
	 *
	 * @since 1.5.9
	 * @access public
	 *
	 * @return void
	 */
	public function get_fb_page_token() {

		check_ajax_referer( 'papro-social-elements', 'security' );

		$api_url = 'https://appfb.premiumaddons.com/wp-json/fbapp/v2/pages';

		$response = wp_remote_get(
			$api_url,
			array(
				'timeout'   => 15,
				'sslverify' => false,
			)
		);

		$body = wp_remote_retrieve_body( $response );
		$body = json_decode( $body, true );

		wp_send_json_success( $body );
	}

	/**
	 * Get Instagram account token for Instagram Feed widget
	 *
	 * @since 1.9.1
	 * @access public
	 *
	 * @return void
	 */
	public function get_instagram_token() {

		check_ajax_referer( 'papro-social-elements', 'security' );

		$api_url = 'https://appfb.premiumaddons.com/wp-json/fbapp/v2/instagram';

		$response = wp_remote_get(
			$api_url,
			array(
				'timeout'   => 15,
				'sslverify' => false,
			)
		);

		$body = wp_remote_retrieve_body( $response );
		$body = json_decode( $body, true );

		$transient_name = 'papro_insta_feed_' . $body;

		$expire_time = 59 * DAY_IN_SECONDS;

		set_transient( $transient_name, true, $expire_time );

		wp_send_json_success( $body );
	}


	/**
	 * Handle Table Data
	 *
	 * Check if table data is cached, send request if not
	 *
	 * @since 2.0.6
	 * @access public
	 */
	public function handle_table_data() {

		check_ajax_referer( 'papro-feed', 'security' );

		if ( ! isset( $_POST['id'] ) ) {
			wp_send_json_error();
		}

		$widget_id = sanitize_text_field( wp_unslash( $_POST['id'] ) );

		$transient_name = sprintf( 'papro_table_%s', $widget_id );

		$response = get_transient( $transient_name );

		// We need to check if there are saved data.
		if ( ! isset( $_POST['expire'] ) ) {
			wp_send_json_success( json_decode( $response ) );
		}

		// We need to save data.
		if ( ! isset( $_POST['tableData'] ) ) {
			wp_send_json_error();
		}

		$expire = sanitize_text_field( wp_unslash( $_POST['expire'] ) );

		// If no data is cached, then send a new request.
		if ( false === $response ) {

			$response = $_POST['tableData'];

			if ( 'nocache' === $expire ) {
				$expire_time = 0;
			} else {
				$expire_time = Helper_Functions::transient_expire( $expire );
			}

			set_transient( $transient_name, $response, $expire_time );

		}

		wp_send_json_success();
	}

	/**
	 * Clear Reviews Data
	 *
	 * @since 2.4.2
	 * @access public
	 */
	public function clear_reviews_data() {

		check_ajax_referer( 'papro-social-elements', 'security' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'User is not authorized!' );
		}

		if ( ! isset( $_POST['transient'] ) ) {
			wp_send_json_error();
		}

		$transient = sanitize_text_field( wp_unslash( $_POST['transient'] ) );

		delete_transient( $transient );

		delete_option( $transient );

		wp_send_json_success();
	}

	/**
	 * Get PAPRO Key
	 *
	 * @since 2.9.1
	 * @access public
	 */
	public function get_papro_key() {

		check_ajax_referer( 'papro-social-elements', 'security' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'User is not authorized!' );
		}

		$data = array(
			'key' => Papro_Admin_Helper::get_license_key(),
		);

		wp_send_json_success( $data );
	}

	/**
	 * Enqueue Editor assets
	 *
	 * @since 1.4.5
	 * @access public
	 *
	 * @return void
	 */
	public function enqueue_editor_scripts() {

		$fb_reviews = self::$modules['premium-facebook-reviews'];

		$fb_feed = self::$modules['premium-facebook-feed'];

		$instagram_feed = self::$modules['premium-instagram-feed'];

		wp_enqueue_script(
			'papro-editor',
			PREMIUM_PRO_ADDONS_URL . 'assets/editor/js/editor.js',
			array(),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		if ( self::$modules['premium-blob'] ) {
			wp_enqueue_script(
				'pa-blob-path',
				PREMIUM_PRO_ADDONS_URL . 'assets/editor/js/generate-path.js',
				array(),
				PREMIUM_PRO_ADDONS_VERSION,
				true
			);
		}

		$data = array(
			'ajaxurl' => esc_url( admin_url( 'admin-ajax.php' ) ),
			'nonce'   => wp_create_nonce( 'papro-social-elements' ),
			'key'     => Papro_Admin_Helper::get_license_key(),
		);

		if ( $fb_reviews || $fb_feed || $instagram_feed ) {

			wp_register_script(
				'papro-fb-helper',
				PREMIUM_PRO_ADDONS_URL . 'assets/editor/js/fb-helper-min.js',
				array(),
				PREMIUM_PRO_ADDONS_VERSION,
				false
			);

			wp_register_script(
				'papro-fb-connect',
				PREMIUM_PRO_ADDONS_URL . 'assets/editor/js/fb-connect.js',
				array( 'papro-fb-helper' ),
				PREMIUM_PRO_ADDONS_VERSION,
				false
			);

			wp_localize_script( 'papro-fb-connect', 'settings', $data );

			wp_enqueue_script( 'papro-fb-helper' );
			wp_enqueue_script( 'papro-fb-connect' );

		}

		wp_enqueue_script(
			'papro-reviews-cache',
			PREMIUM_PRO_ADDONS_URL . 'assets/editor/js/fb-cache.js',
			array(),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_localize_script( 'papro-reviews-cache', 'settings', $data );
	}

	/**
	 * Register Front CSS files
	 *
	 * @since 1.2.8
	 * @access public
	 */
	public function register_frontend_styles() {

		$dir    = 'min-css';
		$suffix = '.min';

		wp_register_style(
			'pa-global',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/pa-global' . $suffix . '.css',
			array(),
			PREMIUM_PRO_ADDONS_VERSION,
			'all'
		);

		wp_register_style(
			'pa-flipclock',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/flipclock' . $suffix . '.css',
			array(),
			PREMIUM_PRO_ADDONS_VERSION,
			'all'
		);

		if ( ! self::$modules['premium-assets-generator'] ) {

			wp_register_style(
				'premium-pro',
				PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/premium-addons' . $suffix . '.css',
				array(),
				PREMIUM_PRO_ADDONS_VERSION,
				'all'
			);
		}

		if ( defined( 'ELEMENTOR_PRO_ASSETS_URL' ) ) {
			wp_register_style(
				'pa-loop-item',
				ELEMENTOR_PRO_ASSETS_URL . 'css/modules/loop-grid-cta.min.css',
				array(),
				ELEMENTOR_PRO_VERSION,
				'all'
			);
		}
	}

	/**
	 * Enqueue Preview CSS files
	 *
	 * @since 1.2.8
	 * @access public
	 */
	public function enqueue_preview_styles() {

		wp_enqueue_style( 'tooltipster' );

		wp_enqueue_style( 'premium-pro' );

		wp_enqueue_style( 'pa-flipclock' );
	}

	/**
	 * Enqueue preview editor scripts.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function enqueue_preview_scripts() {

		wp_enqueue_script(
			'pa-freehand',
			PREMIUM_PRO_ADDONS_URL . 'assets/editor/js/papro-editor-behavior.min.js',
			array( 'jquery', 'jquery-ui-draggable', 'jquery-ui-sortable', 'jquery-ui-resizable' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);
	}

	/**
	 * Load widgets require function
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function register_pro_elements( $widgets_manager ) {

		static $classes_list = null;

		$enabled_elements = array_filter(
			self::$modules,
			function ( $value, $key ) {
				return strpos( $key, 'premium-' ) === 0 && filter_var( $value, FILTER_VALIDATE_BOOLEAN );
			},
			ARRAY_FILTER_USE_BOTH
		);

		if ( null === $classes_list ) {

			$map_file = PREMIUM_PRO_ADDONS_PATH . 'includes/helpers/widget-class-map.php';

			if ( file_exists( $map_file ) ) {

				$classes_list = include $map_file;

				$enabled_elements = array_intersect_key( $enabled_elements, $classes_list );

			} else {
				$enabled_elements = array();
			}
		}

		foreach ( $enabled_elements as $key => $value ) {

			$class = PAPRO_Helper::get_widget_class_name( $key );

			if ( ! $class ) {
				continue;
			}

			$this->load_widget_files( $class );

			$widgets_manager->register( new $class() );

		}
	}

	/**
	 * Load widget files
	 *
	 * @param string $class widget class
	 *
	 * @since 2.9.52
	 * @access public
	 *
	 * @return void
	 */
	public function load_widget_files( $class ) {

		$social_classes = array(
			'PremiumAddonsPro\Widgets\Premium_Facebook_Reviews',
			'PremiumAddonsPro\Widgets\Premium_Yelp_Reviews',
			'PremiumAddonsPro\Widgets\Premium_Google_Reviews',
			'PremiumAddonsPro\Widgets\Premium_Instagram_Feed',
		);

		if ( in_array( $class, $social_classes, true ) ) {
			require_once PREMIUM_ADDONS_PATH . 'widgets/dep/urlopen.php';
			require_once PREMIUM_PRO_ADDONS_PATH . 'includes/deps/reviews.php';
		}

		if ( 'PremiumAddonsPro\Widgets\Premium_Smart_Post_Listing' === $class ) {
			require_once PREMIUM_PRO_ADDONS_PATH . 'includes/pa-smart-post-listing-helper.php';
		}
	}

	/**
	 * Registers required JS files
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function register_frontend_scripts() {

		$dir    = 'min-js';
		$suffix = '.min';

		$current_page = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';

		$magic_section       = self::$modules['premium-magic-section'];
		$site_cursor_enabled = $this->is_site_cursor_enabled();

		$data = array(
			'ajaxurl'      => esc_url( admin_url( 'admin-ajax.php' ) ),
			'nonce'        => wp_create_nonce( 'papro-feed' ),
			'magicSection' => $magic_section ? true : false,
		);

		if ( self::$modules['premium-behance'] ) {
			wp_localize_script(
				'elementor-frontend',
				'PaBehanceSettings',
				array(
					'key' => PREMIUM_BEHANCE_API_KEY,
				)
			);

		}

		if ( $site_cursor_enabled ) {

			if ( ! wp_style_is( 'font-awesome-5-all', 'enqueued' ) ) {
				wp_enqueue_style( 'font-awesome-5-all' );
			}

			if ( ! wp_style_is( 'pa-global', 'enqueued' ) ) {
				wp_enqueue_style( 'pa-global' );
			}

			if ( ! wp_script_is( 'lottie-js', 'enqueued' ) ) {
				wp_enqueue_script( 'lottie-js' );
			}

			if ( ! wp_script_is( 'pa-tweenmax', 'enqueued' ) ) {
				wp_enqueue_script( 'pa-tweenmax' );
			}

			if ( ! wp_script_is( 'premium-cursor-handler', 'enqueued' ) ) {
				wp_enqueue_script( 'premium-cursor-handler' );
			}
		}

		wp_register_script(
			'pa-magazine',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/premium-smart-post-listing' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_localize_script( 'pa-magazine', 'PremiumProSettings', $data );
		wp_localize_script(
			'pa-magazine',
			'PremiumSMLSettings',
			array(
				'nonce' => wp_create_nonce( 'pa-blog-widget-nonce' ),
			)
		);

		if ( ! self::$modules['premium-assets-generator'] ) {

			wp_register_script(
				'premium-pro',
				PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/premium-addons' . $suffix . '.js',
				array( 'jquery' ),
				PREMIUM_PRO_ADDONS_VERSION,
				true
			);

			wp_localize_script( 'premium-pro', 'PremiumProSettings', $data );

		} else {
			wp_localize_script( 'elementor-frontend', 'PremiumProSettings', $data );
		}

		wp_register_script(
			'tabs-slick',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/slick' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'premium-cursor-handler',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/min-js/pa-cursor.min.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'social-dot',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/doT' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'jquery-socialfeed',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/socialfeed' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-moment',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/moment' . $suffix . '.js',
			array(),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-instafeed',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/instafeed' . $suffix . '.js',
			array(),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-charts',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/charts' . $suffix . '.js',
			array(),
			PREMIUM_PRO_ADDONS_VERSION,
			false
		);

		wp_register_script(
			'pa-wordcloud',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/wordCloud' . $suffix . '.js',
			array(),
			PREMIUM_PRO_ADDONS_VERSION,
			false
		);

		wp_register_script(
			'pa-awesomecloud',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/awesomecloud' . $suffix . '.js',
			array(),
			PREMIUM_PRO_ADDONS_VERSION,
			false
		);

		wp_register_script(
			'pa-tagcanvas',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/tagcanvas' . $suffix . '.js',
			array(),
			PREMIUM_PRO_ADDONS_VERSION,
			false
		);

		wp_register_script(
			'event-move',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/event-move' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-imgcompare',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/imgcompare' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-behance',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/embed-behance' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'table-sorter',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/tablesorter' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'multi-scroll',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/multiscroll' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'papro-hscroll',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/premium-hscroll' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-particles',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/particles' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-gradient',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/premium-gradient' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-kenburns',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/premium-kenburns' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-cursor',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/premium-cursor' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-parallax',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/premium-parallax' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-blob-path',
			PREMIUM_PRO_ADDONS_URL . 'assets/editor/js/generate-path.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-blob',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/premium-blob' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-badge',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/premium-badge' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-mscroll',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/premium-mscroll' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-svgsnap',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/snap-svg' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-flipclock',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/flipclock' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-scroll-effects',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/pa-scroll-effects' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-waypoints',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/waypoints' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);

		wp_register_script(
			'pa-glass',
			PREMIUM_PRO_ADDONS_URL . 'assets/frontend/' . $dir . '/liquid-glass' . $suffix . '.js',
			array( 'jquery' ),
			PREMIUM_PRO_ADDONS_VERSION,
			true
		);
	}

	/**
	 * Check if site cursor is enabled.
	 *
	 * @access public
	 * @since 2.8.7
	 *
	 * @return bool
	 */
	public function is_site_cursor_enabled() {

		$cursor_module_enabled = self::$modules['premium-global-cursor'];

		if ( ! $cursor_module_enabled ) {
			return false;
		}

		$is_edit_mode = Helper_Functions::is_edit_mode();

		if ( $is_edit_mode ) {
			return true;
		}

		$gcursor_settings = PAPRO_Helper::get_site_cursor_settings();

		if ( ! $gcursor_settings || ! isset( $gcursor_settings['enabled'] ) ) {
			return false;
		}

		$site_cusror_enabled = $gcursor_settings['enabled'];

		return $site_cusror_enabled;
	}

	/**
	 * Load PAPRO Extensions
	 *
	 * @since 2.9.24
	 * @access public
	 */
	public function load_papro_extensions() {

		//Load PAPRO Extensions only on Elementor pages.
		// if ( is_admin() && ! Helper_Functions::is_edit_mode() ) {
		//  return;
		// }

		$extensions = array(
			'premium-section-parallax',
			'premium-section-particles',
			'premium-section-gradient',
			'premium-section-kenburns',
			'premium-section-lottie',
			'premium-section-blob',
			'premium-global-cursor',
			'premium-global-badge',
			'premium-global-mscroll',
		);

		$keys = array(
			'premium-parallax',
			'premium-particles',
			'premium-gradient',
			'premium-kenburns',
			'premium-lottie',
			'premium-blob',
			'premium-global-cursor',
			'premium-global-badge',
			'premium-mscroll',
		);

		foreach ( $extensions as $index => $extension ) {

			$class_name = str_replace( '-', ' ', $extension );

			$class_name = str_replace( ' ', '', ucwords( $class_name ) );

			$key = $keys[ $index ];

			$class_name = 'PremiumAddonsPro\\Modules\\' . $class_name . '\Module';

			if ( self::$modules[ $key ] ) {
				$class_name::instance();
			}
		}
	}

	/**
	 *
	 * Creates and returns an instance of the class
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return object
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) ) {

			self::$instance = new self();

		}

		return self::$instance;
	}
}
