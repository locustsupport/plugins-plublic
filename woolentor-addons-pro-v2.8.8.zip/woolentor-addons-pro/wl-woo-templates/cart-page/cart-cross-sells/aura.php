<?php
/**
 * Cart Cross Sells — Aura Template
 *
 * @package WooLentor Pro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
    return;
}

$cross_sell_ids = WC()->cart->get_cross_sells();

if ( empty( $cross_sell_ids ) ) {
    return;
}

$products_count = absint( $settings['products_count'] );
$cross_sells    = array_slice(
    wc_get_products( [
        'include' => $cross_sell_ids,
        'limit'   => $products_count,
        'status'  => 'publish',
    ] ),
    0,
    $products_count
);

$cross_sells = array_filter( $cross_sells, function( $p ) {
    return $p && $p->is_visible();
} );

if ( empty( $cross_sells ) ) {
    return;
}

$columns = absint( $settings['columns'] );
?>

<?php
$cross_sells_classes = [ 'wl-cross-sells-wrap', 'wl-cross-sells--aura' ];
if ( empty( $settings['show_separator'] ) ) {
    $cross_sells_classes[] = 'wl-cross-sells--no-sep';
}
?>
<div class="<?php echo esc_attr( implode( ' ', $cross_sells_classes ) ); ?>">

    <?php 
        if ( ! empty( $settings['section_title'] ) ) {
            $title_tag = woolentor_validate_html_tag( $settings['title_tag'] );
            echo sprintf('<%s class="wl-cross-sells__title">%s</%s>',
                esc_attr( $title_tag ),
                esc_html( $settings['section_title'] ),
                esc_attr( $title_tag )
            );
        } 
    ?>

    <div class="wl-cross-sells-grid wl-cross-sells-grid--cols-<?php echo esc_attr( $columns ); ?>">

        <?php foreach ( $cross_sells as $product ) :
            $product_id   = $product->get_id();
            $product_link = $product->get_permalink();
        ?>
        <div class="wl-cross-sell-card">

            <a href="<?php echo esc_url( $product_link ); ?>"
               class="wl-cross-sell-card__thumb"
               tabindex="-1"
               aria-hidden="true">
                <?php echo wp_kses_post( $product->get_image( $settings['image_size'] ) ); ?>
            </a>

            <div class="wl-cross-sell-card__info">
                <a href="<?php echo esc_url( $product_link ); ?>"
                   class="wl-cross-sell-card__name">
                    <?php echo esc_html( $product->get_name() ); ?>
                </a>
                <?php if ( $settings['show_price'] ) : ?>
                <span class="wl-cross-sell-card__price">
                    <?php echo wp_kses_post( $product->get_price_html() ); ?>
                </span>
                <?php endif; ?>
            </div>

            <?php 
                if ( $settings['show_add_to_cart'] && $product->is_purchasable() && $product->is_in_stock() ) : 
                    // Add to cart Button Classes
                    $btn_class = 'wl-cross-sell-card__atc product_type_' . $product->get_type();

                    $btn_class .= $product->is_purchasable() && $product->is_in_stock() ? ' add_to_cart_button' : '';

                    $btn_class .= $product->supports( 'ajax_add_to_cart' ) && $product->is_purchasable() && $product->is_in_stock() ? ' ajax_add_to_cart' : '';
            ?>
            <a href="<?php echo esc_url( $product->add_to_cart_url() ); ?>"
               class="<?php echo esc_attr($btn_class); ?>"
               data-quantity="1"
               data-product_id="<?php echo absint( $product_id ); ?>"
               data-product_sku="<?php echo esc_attr( $product->get_sku() ); ?>"
               aria-label="<?php echo esc_attr( sprintf( __( 'Add %s to cart', 'woolentor-pro' ), $product->get_name() ) ); ?>">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
            </a>
            <?php endif; ?>

        </div>
        <?php endforeach; ?>

    </div><!-- .wl-cross-sells-grid -->

</div><!-- .wl-cross-sells--aura -->
