<?php
/**
 * Cart Table — Aura Template
 *
 * Variables available:
 *   $settings   (array)  Normalised Elementor widget settings.
 *   $cart_items (array)  WC()->cart->get_cart() result.
 *   $cart_base  (WooLentor_Cart_Page_Base) Helper instance.
 *
 * @package WooLentor Pro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
    return;
}

// Always fire woocommerce_before_cart BEFORE the empty-cart check so that
// woocommerce_output_all_notices() runs and the .woocommerce-notices-wrapper
// is rendered — this makes the "removed. Undo?" notice visible even when
// the last item was just removed.
do_action( 'woocommerce_before_cart' );

if ( empty( $cart_items ) ) {
    wc_get_template( 'cart/cart-empty.php' );
    return;
}
?>

<div class="wl-cart-page-wrap wl-cart-table-wrap wl-cart-table--aura">

    <?php if ( $settings['show_heading'] ) :
        $heading_tag    = woolentor_validate_html_tag( $settings['heading_tag'] );
        $item_count     = absint( $settings['cart_item_count'] );
        $counter_suffix = $item_count === 1 ? $settings['counter_suffix_singular'] : $settings['counter_suffix_plural'];

        echo sprintf("<%s class='wl-cart-heading'><span class='wl-cart-heading__title'>%s</span>",
            esc_attr( $heading_tag ),
            esc_html( $settings['heading_text'] )
        ); 

        if ( $settings['show_counter'] ) :
    ?>
        <span class="wl-cart-heading__counter">
            <?php if ( ! empty( $settings['counter_separator'] ) ) : ?>
                <span class="wl-cart-heading__sep" aria-hidden="true"><?php echo esc_html( $settings['counter_separator'] ); ?></span>
            <?php endif; ?>
            <?php echo esc_html( $item_count . ' ' . $counter_suffix ); ?>
        </span>
    <?php endif;
        echo sprintf("</%s>", esc_attr( $heading_tag ) );
        endif;
    ?>

    <form action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post" enctype="multipart/form-data">

        <?php do_action( 'woocommerce_before_cart_table' ); ?>

        <?php do_action( 'woocommerce_before_cart_contents' ); ?>

        <?php foreach ( $cart_items as $cart_item_key => $cart_item ) :
            /** @var WC_Product $_product */
            $_product = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );

            if ( ! $_product || ! $_product->exists() || $cart_item['quantity'] === 0 ) {
                continue;
            }

            if ( ! apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
                continue;
            }

            $product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
            $is_on_sale        = $_product->is_on_sale();
            $regular_price     = (float) $_product->get_regular_price();
            $sale_price        = (float) $_product->get_sale_price();
            $quantity          = (int) $cart_item['quantity'];
        ?>

        <article class="wl-cart-item <?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>"
                 data-key="<?php echo esc_attr( $cart_item_key ); ?>">

            <?php // ── Product Image ──────────────────────────────────────────────── ?>
            <?php if ( $settings['show_image'] ) : ?>
            <div class="wl-cart-item__image">
                <?php
                $thumbnail = apply_filters(
                    'woocommerce_cart_item_thumbnail',
                    $_product->get_image( $settings['image_size'] ),
                    $cart_item,
                    $cart_item_key
                );
                ?>
                <?php if ( $product_permalink ) : ?>
                    <a href="<?php echo esc_url( $product_permalink ); ?>" tabindex="-1">
                        <?php echo wp_kses_post( $thumbnail ); ?>
                    </a>
                <?php else : ?>
                    <?php echo wp_kses_post( $thumbnail ); ?>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php // ── Product Meta ───────────────────────────────────────────────── ?>
            <div class="wl-cart-item__meta">

                <?php // Brand / Vendor label ?>
                <?php if ( $settings['show_vendor'] ) :
                    // For variations, look up taxonomy terms on the parent product
                    $lookup_id = $_product->is_type( 'variation' ) ? $_product->get_parent_id() : $_product->get_id();
                    $vendor_label = '';

                    if ( 'taxonomy' === $settings['vendor_source'] ) {
                        $taxonomy = sanitize_key( $settings['vendor_taxonomy'] );
                        if ( $taxonomy && 'none' !== $taxonomy && taxonomy_exists( $taxonomy ) ) {
                            $terms = get_the_terms( $lookup_id, $taxonomy );
                            if ( $terms && ! is_wp_error( $terms ) ) {
                                $vendor_label = implode( ', ', wp_list_pluck( $terms, 'name' ) );
                            }
                        }
                    } else {
                        $vendor_label = get_post_meta( $lookup_id, sanitize_key( $settings['vendor_meta_key'] ), true );
                    }

                    if ( $vendor_label ) : ?>
                    <span class="wl-cart-item__vendor"><?php echo esc_html( $vendor_label ); ?></span>
                <?php endif; endif; ?>

                <?php // Product name ?>
                <h3 class="wl-cart-item__name">
                    <?php if ( $product_permalink ) : ?>
                        <a href="<?php echo esc_url( $product_permalink ); ?>">
                            <?php echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) ); ?>
                        </a>
                    <?php else : ?>
                        <?php echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) ); ?>
                    <?php endif; ?>
                </h3>

                <?php // Variation attributes — read $cart_item['variation'] directly so values
                      // that appear in the product name are still shown (wc_get_formatted_cart_item_data
                      // silently skips them via wc_is_attribute_in_product_name). ?>
                <?php if ( $settings['show_attributes'] && ! empty( $cart_item['variation'] ) ) : ?>
                <div class="wl-cart-item__attrs">
                    <?php foreach ( $cart_item['variation'] as $raw_attr => $raw_value ) :
                        if ( '' === $raw_value ) continue;

                        // Resolve taxonomy name (strip 'attribute_' prefix)
                        $taxonomy = str_replace( 'attribute_', '', $raw_attr );

                        // Human-readable label
                        $label = wc_attribute_label( $taxonomy, $_product );

                        // Resolve term name for taxonomy-based attributes
                        if ( taxonomy_exists( $taxonomy ) ) {
                            $term = get_term_by( 'slug', $raw_value, $taxonomy );
                            $display_value = ( $term && ! is_wp_error( $term ) ) ? $term->name : $raw_value;
                        } else {
                            $display_value = apply_filters( 'woocommerce_variation_option_name', $raw_value, null, $taxonomy, $_product );
                        }
                    ?>
                    <span class="wl-cart-item__attr">
                        <span class="wl-cart-item__attr-label"><?php echo esc_html( $label ); ?>:</span>
                        <span class="wl-cart-item__attr-value"><?php echo esc_html( $display_value ); ?></span>
                    </span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <?php do_action( 'woocommerce_after_cart_item_name', $cart_item, $cart_item_key ); ?>

                <?php // Stock status ?>
                <?php if ( $settings['show_stock_status'] && $_product->is_in_stock() ) : ?>
                <span class="wl-cart-item__stock" aria-live="polite">
                    <span class="wl-cart-item__stock-dot" aria-hidden="true"></span>
                    <?php echo esc_html( $settings['stock_status_text'] ); ?>
                </span>
                <?php endif; ?>

                <?php // Controls row ?>
                <div class="wl-cart-item__controls">

                    <?php // Quantity stepper ?>
                    <?php if ( $settings['show_qty'] ) :
                        $min_qty  = apply_filters( 'woocommerce_quantity_input_min', $_product->get_min_purchase_quantity(), $_product );
                        $max_qty  = apply_filters( 'woocommerce_quantity_input_max', $_product->get_max_purchase_quantity(), $_product );
                        $step_qty = apply_filters( 'woocommerce_quantity_input_step', 1, $_product );
                        $max_attr = $max_qty < 0 ? '' : $max_qty;
                    ?>
                    <div class="wl-qty-stepper" role="group" aria-label="<?php esc_attr_e( 'Product quantity', 'woolentor-pro' ); ?>">
                        <button type="button"
                                class="wl-qty-stepper__btn wl-qty-stepper__btn--minus"
                                aria-label="<?php esc_attr_e( 'Decrease quantity', 'woolentor-pro' ); ?>"
                                data-step="<?php echo esc_attr( $step_qty ); ?>"
                                data-min="<?php echo esc_attr( $min_qty ); ?>">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M5 12h14"/></svg>
                        </button>

                        <input type="number"
                               class="input-text qty text"
                               name="cart[<?php echo esc_attr( $cart_item_key ); ?>][qty]"
                               value="<?php echo esc_attr( $quantity ); ?>"
                               min="<?php echo esc_attr( $min_qty ); ?>"
                               max="<?php echo esc_attr( $max_attr ); ?>"
                               step="<?php echo esc_attr( $step_qty ); ?>"
                               inputmode="numeric"
                               aria-label="<?php esc_attr_e( 'Quantity', 'woolentor-pro' ); ?>" />

                        <button type="button"
                                class="wl-qty-stepper__btn wl-qty-stepper__btn--plus"
                                aria-label="<?php esc_attr_e( 'Increase quantity', 'woolentor-pro' ); ?>"
                                data-step="<?php echo esc_attr( $step_qty ); ?>"
                                data-max="<?php echo esc_attr( $max_qty < 0 ? 9999 : $max_qty ); ?>">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
                        </button>
                    </div>
                    <?php endif; ?>

                    <?php // Remove button ?>
                    <?php if ( $settings['show_remove'] ) : ?>
                    <a href="<?php echo esc_url( wc_get_cart_remove_url( $cart_item_key ) ); ?>"
                       class="wl-cart-item__action-link wl-cart-item__remove"
                       aria-label="<?php echo esc_attr( sprintf( __( 'Remove %s from cart', 'woolentor-pro' ), $_product->get_name() ) ); ?>"
                       data-product_id="<?php echo absint( $_product->get_id() ); ?>"
                       data-product_sku="<?php echo esc_attr( $_product->get_sku() ); ?>"
                       data-cart_item_key="<?php echo esc_attr( $cart_item_key ); ?>">
                        <?php echo esc_html( $settings['remove_label'] ); ?>
                    </a>
                    <?php endif; ?>

                </div><!-- .wl-cart-item__controls -->

            </div><!-- .wl-cart-item__meta -->

            <?php // ── Price column ───────────────────────────────────────────────── ?>
            <div class="wl-cart-item__price">

                <?php // Current / sale price ?>
                <span class="wl-cart-item__price-current">
                    <?php echo wp_kses_post( apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key ) ); ?>
                </span>

                <?php // Original / regular price (only when on sale) ?>
                <?php if ( $settings['show_regular_price'] && $is_on_sale && $regular_price > $sale_price ) : ?>
                <span class="wl-cart-item__price-regular">
                    <?php echo wp_kses_post( wc_price( $regular_price ) ); ?>
                </span>
                <?php endif; ?>

                <?php // Savings badge ?>
                <?php if ( $settings['show_savings_badge'] && $is_on_sale && $regular_price > $sale_price ) :
                    $saving = ( $regular_price - $sale_price ) * $quantity;
                    $label  = $settings['savings_badge_label'];
                    $label  = str_replace( '%s', wp_kses_post( wc_price( $saving ) ), $label );
                ?>
                <span class="wl-cart-item__savings-badge">
                    <?php echo wp_kses_post( $label ); ?>
                </span>
                <?php endif; ?>

            </div><!-- .wl-cart-item__price -->

        </article>

        <?php endforeach; ?>

        <?php do_action( 'woocommerce_after_cart_contents' ); ?>

        <?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>

        <button type="submit"
                class="wl-update-cart-btn screen-reader-text"
                name="update_cart"
                value="<?php esc_attr_e( 'Update cart', 'woocommerce' ); ?>">
            <?php esc_html_e( 'Update cart', 'woocommerce' ); ?>
        </button>

        <?php do_action( 'woocommerce_cart_actions' ); ?>

    </form>

    <?php do_action( 'woocommerce_after_cart' ); ?>

</div><!-- .wl-cart-table--aura -->

