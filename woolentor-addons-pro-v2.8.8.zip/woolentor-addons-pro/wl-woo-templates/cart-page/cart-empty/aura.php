<?php
/**
 * Cart Empty — Aura Template
 *
 * @package WooLentor Pro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$button_url    = ! empty( $settings['button_url'] ) ? $settings['button_url'] : get_permalink( wc_get_page_id( 'shop' ) );
$button_target = ! empty( $settings['button_target'] ) ? ' target="_blank"' : '';
$button_norel  = ! empty( $settings['button_rel'] ) ? ' rel="nofollow"' : '';
?>

<div class="wl-cart-page-wrap wl-cart-empty-wrap wl-cart-empty--aura">

    <?php if ( ! empty( $settings['icon']['value'] ) ) : ?>
    <div class="wl-cart-empty__icon" aria-hidden="true">
        <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
    </div>
    <?php endif; ?>

    <?php if ( ! empty( $settings['heading'] ) ) : ?>
    <h2 class="wl-cart-empty__heading"><?php echo esc_html( $settings['heading'] ); ?></h2>
    <?php endif; ?>

    <?php if ( ! empty( $settings['sub_text'] ) ) : ?>
    <p class="wl-cart-empty__sub"><?php echo esc_html( $settings['sub_text'] ); ?></p>
    <?php endif; ?>

    <?php if ( ! empty( $settings['button_label'] ) && ! empty( $button_url ) ) : ?>
    <a href="<?php echo esc_url( $button_url ); ?>"
       class="wl-cart-empty-btn button"
       <?php echo $button_target . $button_norel; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
        <?php echo esc_html( $settings['button_label'] ); ?>
    </a>
    <?php endif; ?>

    <?php
    // Remove WooCommerce's default "Your cart is currently empty." message
    // because this widget already provides its own branded empty state.
    // Notices (including the undo link) are preserved because
    // woocommerce_output_all_notices runs at priority 5.
    remove_action( 'woocommerce_cart_is_empty', 'wc_empty_cart_message', 10 );
    do_action( 'woocommerce_cart_is_empty' );
    add_action( 'woocommerce_cart_is_empty', 'wc_empty_cart_message', 10 );
    ?>

</div><!-- .wl-cart-empty--aura -->
