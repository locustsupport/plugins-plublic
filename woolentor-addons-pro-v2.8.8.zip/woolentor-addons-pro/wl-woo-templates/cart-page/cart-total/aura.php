<?php
/**
 * Cart Total — Aura Template
 *
 * @package WooLentor Pro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
    return;
}
?>

<div class="wl-cart-page-wrap wl-cart-total-wrap wl-cart-total--aura">

    <?php // ── Order summary title ────────────────────────────────────────────── ?>
    <?php 
        if ( $settings['show_title'] ) : 
            $title_tag = woolentor_validate_html_tag( $settings['title_tag'] );
    ?>
    <div class="wl-order-summary-heading">
        <?php echo sprintf('<%s class="wl-order-summary-heading__title">%s</%s>', esc_attr($title_tag), esc_html($settings['title_text']), esc_attr($title_tag) ); ?>
        <?php if ( $settings['show_title_badge'] && ! empty( $settings['title_badge_text'] ) ) : ?>
        <span class="wl-order-summary-heading__badge">
            <span aria-hidden="true">·</span> <?php echo esc_html( $settings['title_badge_text'] ); ?>
        </span>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="wl-cart-total-card">

        <?php // ── Coupon form ────────────────────────────────────────────────── ?>
        <?php if ( $settings['show_coupon'] && wc_coupons_enabled() ) : ?>
        <form class="wl-coupon-form" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
            <div class="wl-coupon-row">
                <input type="text"
                       name="coupon_code"
                       class="wl-coupon-input input-text"
                       placeholder="<?php echo esc_attr( $settings['coupon_placeholder'] ); ?>"
                       aria-label="<?php esc_attr_e( 'Coupon code', 'woolentor-pro' ); ?>" />

                <button type="submit"
                        class="wl-coupon-btn button"
                        name="apply_coupon"
                        value="<?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?>">
                    <?php echo esc_html( $settings['coupon_button_label'] ); ?>
                </button>
            </div>
            <?php wp_nonce_field( 'apply-coupon', '_wpnonce' ); ?>
        </form>
        <?php endif; ?>

        <?php // ── Shipping options ───────────────────────────────────────────── ?>
        <?php if ( $settings['show_shipping'] && WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) :
            // Ensure shipping rates are calculated (Elementor renders outside standard WC cart context)
            if ( empty( WC()->shipping()->get_packages() ) ) {
                WC()->cart->calculate_shipping();
            }
            $packages = WC()->shipping()->get_packages();
            if ( ! empty( $packages ) ) :
        ?>

        <div class="wl-shipping-section">
            <p class="wl-ship-label"><?php echo esc_html( $settings['shipping_section_label'] ); ?></p>
            <div class="wl-ship-opts woocommerce-shipping-methods" id="shipping_method">
                <?php foreach ( $packages as $i => $package ) :
                    $chosen_method  = isset( WC()->session->chosen_shipping_methods[ $i ] ) ? WC()->session->chosen_shipping_methods[ $i ] : '';
                    $product_names  = [];
                    foreach ( $package['contents'] as $item ) {
                        $product_names[] = $item['data']->get_name();
                    }
                    foreach ( $package['rates'] as $method ) :
                        $is_checked = ( $method->id === $chosen_method );
                ?>
                <label for="shipping_method_<?php echo absint( $i ) . '_' . esc_attr( $method->id ); ?>" class="wl-ship-opt <?php echo $is_checked ? 'wl-ship-opt--selected' : ''; ?>">
                    <input type="radio"
                           name="shipping_method[<?php echo absint( $i ); ?>]"
                           data-index="<?php echo absint( $i ); ?>"
                           id="shipping_method_<?php echo absint( $i ) . '_' . esc_attr( $method->id ); ?>"
                           value="<?php echo esc_attr( $method->id ); ?>"
                           class="shipping_method"
                           <?php checked( $is_checked ); ?> />
                    <span class="wl-ship-radio" aria-hidden="true"></span>
                    <div class="wl-ship-opt-info">
                        <div class="wl-ship-opt-row">
                            <span class="wl-ship-opt-name"><?php echo wp_kses_post( $method->get_label() ); ?></span>
                            <span class="wl-ship-opt-price <?php echo $method->cost == 0 ? 'wl-ship-opt-price--free' : ''; ?>">
                                <?php
                                if ( $method->cost == 0 ) {
                                    esc_html_e( 'Free', 'woolentor-pro' );
                                } else {
                                    echo wp_kses_post( wc_price( $method->cost ) );
                                }
                                ?>
                            </span>
                        </div>
                    </div>
                </label>
                <?php endforeach; ?>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; endif; ?>

        <?php do_action( 'woocommerce_before_cart_totals' ); ?>

        <?php // ── Itemised totals ────────────────────────────────────────────── ?>
        <div class="wl-totals-section">

            <?php if ( $settings['show_subtotal'] ) : ?>
            <div class="wl-totals-row">
                <span class="wl-totals-label"><?php esc_html_e( 'Subtotal', 'woocommerce' ); ?></span>
                <span class="wl-totals-value"><?php wc_cart_totals_subtotal_html(); ?></span>
            </div>
            <?php endif; ?>

            <?php // Coupons ?>
            <?php if ( $settings['show_discount_row'] ) :
                foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
                <div class="wl-totals-row wl-totals-row--discount">
                    <span class="wl-totals-label">
                        <?php wc_cart_totals_coupon_label( $coupon ); ?>
                    </span>
                    <span class="wl-totals-value">
                        <?php wc_cart_totals_coupon_html( $coupon ); ?>
                    </span>
                </div>
                <?php endforeach;
            endif; ?>

            <?php // Shipping total — show chosen method cost only (method selector is above) ?>
            <?php if ( $settings['show_shipping'] && WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) : ?>
            <div class="wl-totals-row">
                <span class="wl-totals-label"><?php esc_html_e( 'Shipping', 'woocommerce' ); ?></span>
                <span class="wl-totals-value"><?php echo wp_kses_post( WC()->cart->get_cart_shipping_total() ); ?></span>
            </div>
            <?php endif; ?>

            <?php // Fees ?>
            <?php foreach ( WC()->cart->get_fees() as $fee ) : ?>
            <div class="wl-totals-row">
                <span class="wl-totals-label"><?php echo esc_html( $fee->name ); ?></span>
                <span class="wl-totals-value"><?php wc_cart_totals_fee_html( $fee ); ?></span>
            </div>
            <?php endforeach; ?>

            <?php // Tax ?>
            <?php if ( $settings['show_tax_row'] && wc_tax_enabled() && WC()->cart->get_taxes_total() > 0 ) : ?>
                <?php foreach ( WC()->cart->get_tax_totals() as $code => $tax ) : ?>
                <div class="wl-totals-row">
                    <span class="wl-totals-label"><?php echo esc_html( $tax->label ); ?></span>
                    <span class="wl-totals-value"><?php echo wp_kses_post( $tax->formatted_amount ); ?></span>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <?php do_action( 'woocommerce_cart_totals_before_order_total' ); ?>

        </div><!-- .wl-totals-section -->

        <?php do_action( 'woocommerce_cart_totals_after_order_total' ); ?>

        <?php // ── Grand total ────────────────────────────────────────────────── ?>
        <div class="wl-grand-total">
            <div class="wl-grand-total__label">
                <?php esc_html_e( 'Total', 'woocommerce' ); ?>
                <small><?php
                    $tax_display = get_option( 'woocommerce_tax_display_cart' );
                    if ( wc_tax_enabled() ) {
                        echo esc_html( 'incl' === $tax_display
                            ? __( 'Including tax', 'woocommerce' )
                            : __( 'Excluding tax', 'woocommerce' ) );
                    }
                ?></small>
            </div>
            <div class="wl-grand-total__value">
                <?php wc_cart_totals_order_total_html(); ?>
            </div>
        </div>

        <?php // ── Checkout CTA ───────────────────────────────────────────────── ?>
        <a href="<?php echo esc_url( wc_get_checkout_url() ); ?>"
           class="wl-checkout-btn checkout-button button alt wc-forward">
            <?php echo esc_html( $settings['checkout_button_label'] ); ?>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        </a>

        <?php // ── Shipping destination ───────────────────────────────────────── ?>
        <?php if ( $settings['show_shipping_dest'] ) :
            $dest_city    = WC()->customer->get_shipping_city();
            $dest_country = WC()->customer->get_shipping_country();
            $dest_country_name = ! empty( $dest_country )
                ? ( WC()->countries->get_countries()[ $dest_country ] ?? '' )
                : '';
            $dest_parts = array_filter( [ $dest_city, $dest_country_name ] );
            if ( ! empty( $dest_parts ) ) :
        ?>
        <div class="wl-shipping-destination">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
            <span class="wl-shipping-destination__text">
                <?php printf(
                    esc_html__( 'Shipping to %s', 'woolentor-pro' ),
                    esc_html( implode( ', ', $dest_parts ) )
                ); ?>
            </span>
            <?php if ( ! empty( $settings['shipping_dest_change_text'] ) ) : ?>
            <a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="wl-shipping-destination__change shipping-calculator-button">
                <?php echo esc_html( $settings['shipping_dest_change_text'] ); ?>
            </a>
            <?php endif; ?>
        </div>
        <?php
            echo '<div class="wl-shipping-calculator">';
                woocommerce_shipping_calculator( $settings['shipping_dest_change_text'] );
            echo '</div>';
        ?>
        <?php endif; endif; ?>

        <?php // ── Trust signals ──────────────────────────────────────────────── ?>
        <?php if ( $settings['show_trust'] && ! empty( $settings['trust_items'] ) ) : ?>
        <div class="wl-trust-signals" role="list">
            <?php foreach ( $settings['trust_items'] as $item ) : ?>
            <div class="wl-trust-cell" role="listitem">
                <?php if ( ! empty( $item['trust_icon']['value'] ) ) : ?>
                <span class="wl-trust-cell__icon" aria-hidden="true">
                    <?php \Elementor\Icons_Manager::render_icon( $item['trust_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                </span>
                <?php endif; ?>
                <?php if ( ! empty( $item['trust_heading'] ) ) : ?>
                <strong class="wl-trust-cell__heading"><?php echo esc_html( $item['trust_heading'] ); ?></strong>
                <?php endif; ?>
                <?php if ( ! empty( $item['trust_sub'] ) ) : ?>
                <span class="wl-trust-cell__sub"><?php echo esc_html( $item['trust_sub'] ); ?></span>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

    </div><!-- .wl-cart-total-card -->

</div><!-- .wl-cart-total--aura -->
