<?php
/**
 * Cart Cross Sells — Aura Widget
 *
 * @package WooLentor Pro
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'WooLentor_Cart_Page_Base_Widget' ) ) {
    require_once WOOLENTOR_ADDONS_PL_PATH_PRO . 'includes/addons/cart-page/base/class.cart-page-base-widget.php';
}

class Woolentor_Cart_Cross_Sells_Aura_Widget extends WooLentor_Cart_Page_Base_Widget {

    protected $cart_style       = 'aura';
    protected $cart_style_label = 'Aura';
    protected $widget_type      = 'cart-cross-sells';

    public function get_name() {
        return 'woolentor-cart-cross-sells-aura';
    }

    public function get_title() {
        return esc_html__( 'WL: Cart Cross Sells — Aura', 'woolentor-pro' );
    }

    public function get_icon() {
        return 'woolentor-widget-new-icon eicon-woocommerce';
    }

    public function get_keywords() {
        return [ 'cart', 'cross', 'sells', 'upsell', 'aura', 'woocommerce', 'woolentor' ];
    }

    protected function register_content_controls() {

        $this->start_controls_section( 'section_general', [
            'label' => esc_html__( 'General', 'woolentor-pro' ),
        ] );

            $this->add_control( 'section_title', [
                'label'   => esc_html__( 'Section Title', 'woolentor-pro' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( 'Pairs well with', 'woolentor-pro' ),
            ] );

            $this->add_control( 'title_tag', [
                'label'     => esc_html__( 'Title HTML Tag', 'woolentor-pro' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'h2',
                'options'   => woolentor_html_tag_lists(),
            ] );

            $this->add_control( 'products_count', [
                'label'   => esc_html__( 'Products to Show', 'woolentor-pro' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 4,
                'min'     => 1,
                'max'     => 12,
            ] );

            $this->add_responsive_control( 'columns', [
                'label'          => esc_html__( 'Columns', 'woolentor-pro' ),
                'type'           => Controls_Manager::SELECT,
                'default'        => '2',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options'        => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ],
            ] );

            $this->add_control( 'show_price', [
                'label'        => esc_html__( 'Show Price', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'show_add_to_cart', [
                'label'        => esc_html__( 'Show Add to Cart Button', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_group_control( Group_Control_Image_Size::get_type(), [
                'name'    => 'product_image',
                'default' => 'woocommerce_thumbnail',
            ] );

            $this->add_control( 'show_separator', [
                'label'        => esc_html__( 'Show Top Separator', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
                'separator'    => 'before',
            ] );

        $this->end_controls_section();

    }

    protected function register_style_controls() {

        // ── Section Separator ─────────────────────────────────────────────────
        $this->start_controls_section( 'style_separator', [
            'label'     => esc_html__( 'Section Separator', 'woolentor-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_separator' => 'yes' ],
        ] );

            $this->add_control( 'separator_color', [
                'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cross-sells--aura' => 'border-top-color: {{VALUE}};' ],
            ] );

            $this->add_responsive_control( 'separator_margin_top', [
                'label'      => esc_html__( 'Margin Top', 'woolentor-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 100 ] ],
                'default'    => [ 'size' => 40 ],
                'selectors'  => [ '{{WRAPPER}} .wl-cross-sells--aura' => 'margin-top: {{SIZE}}{{UNIT}};' ],
            ] );

            $this->add_responsive_control( 'separator_padding_top', [
                'label'      => esc_html__( 'Padding Top', 'woolentor-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 100 ] ],
                'default'    => [ 'size' => 36 ],
                'selectors'  => [ '{{WRAPPER}} .wl-cross-sells--aura' => 'padding-top: {{SIZE}}{{UNIT}};' ],
            ] );

        $this->end_controls_section();

        // ── Section Title ─────────────────────────────────────────────────────
        $this->start_controls_section( 'style_title', [
            'label' => esc_html__( 'Section Title', 'woolentor-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

            $this->add_control( 'title_color', [
                'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cross-sells__title' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .wl-cross-sells__title',
            ] );

            $this->add_responsive_control( 'title_margin_bottom', [
                'label'      => esc_html__( 'Margin Bottom', 'woolentor-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 60 ] ],
                'default'    => [ 'size' => 14 ],
                'selectors'  => [ '{{WRAPPER}} .wl-cross-sells__title' => 'margin-bottom: {{SIZE}}{{UNIT}};' ],
            ] );

        $this->end_controls_section();

        // ── Product Card ──────────────────────────────────────────────────────
        $this->start_controls_section( 'style_card', [
            'label' => esc_html__( 'Product Card', 'woolentor-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

            $this->add_control( 'card_bg', [
                'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cross-sell-card' => 'background-color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Border::get_type(), [
                'name'     => 'card_border',
                'selector' => '{{WRAPPER}} .wl-cross-sell-card',
            ] );

            $this->add_control( 'card_border_radius', [
                'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-cross-sell-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_responsive_control( 'card_padding', [
                'label'      => esc_html__( 'Padding', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .wl-cross-sell-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_responsive_control( 'card_gap', [
                'label'      => esc_html__( 'Grid Gap', 'woolentor-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
                'default'    => [ 'size' => 14 ],
                'selectors'  => [ '{{WRAPPER}} .wl-cross-sells-grid' => 'gap: {{SIZE}}{{UNIT}};' ],
            ] );

            $this->add_control( 'card_hover_border_color', [
                'label'     => esc_html__( 'Hover Border Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cross-sell-card:hover' => 'border-color: {{VALUE}};' ],
            ] );

        $this->end_controls_section();

        // ── Product Image ─────────────────────────────────────────────────────
        $this->start_controls_section( 'style_image', [
            'label' => esc_html__( 'Product Image', 'woolentor-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

            $this->add_responsive_control( 'image_width', [
                'label'      => esc_html__( 'Width', 'woolentor-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 30, 'max' => 150 ] ],
                'default'    => [ 'size' => 56 ],
                'selectors'  => [
                    '{{WRAPPER}} .wl-cross-sell-card__thumb' => 'width: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ] );

            $this->add_control( 'image_border_radius', [
                'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-cross-sell-card__thumb' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

        $this->end_controls_section();

        // ── Product Name ──────────────────────────────────────────────────────
        $this->start_controls_section( 'style_name', [
            'label' => esc_html__( 'Product Name', 'woolentor-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

            $this->add_control( 'name_color', [
                'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cross-sell-card__name' => 'color: {{VALUE}};' ],
            ] );

            $this->add_control( 'name_hover_color', [
                'label'     => esc_html__( 'Hover Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cross-sell-card__name:hover' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'name_typography',
                'selector' => '{{WRAPPER}} .wl-cross-sell-card__name',
            ] );

        $this->end_controls_section();

        // ── Product Price ─────────────────────────────────────────────────────
        $this->start_controls_section( 'style_price', [
            'label'     => esc_html__( 'Product Price', 'woolentor-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_price' => 'yes' ],
        ] );

            $this->add_control( 'price_color', [
                'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cross-sell-card__price' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'price_typography',
                'selector' => '{{WRAPPER}} .wl-cross-sell-card__price',
            ] );

        $this->end_controls_section();

        // ── Add to Cart Button ────────────────────────────────────────────────
        $this->start_controls_section( 'style_atc', [
            'label'     => esc_html__( 'Add to Cart Button', 'woolentor-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_add_to_cart' => 'yes' ],
        ] );

            $this->add_responsive_control( 'atc_size', [
                'label'      => esc_html__( 'Size', 'woolentor-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 20, 'max' => 60 ] ],
                'default'    => [ 'size' => 30 ],
                'selectors'  => [
                    '{{WRAPPER}} .wl-cross-sell-card__atc' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ] );

            $this->start_controls_tabs( 'atc_tabs' );

                $this->start_controls_tab( 'atc_normal', [ 'label' => esc_html__( 'Normal', 'woolentor-pro' ) ] );
                    $this->add_control( 'atc_bg', [
                        'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-cross-sell-card__atc' => 'background-color: {{VALUE}} !important;' ],
                    ] );
                    $this->add_control( 'atc_color', [
                        'label'     => esc_html__( 'Icon Color', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-cross-sell-card__atc' => 'color: {{VALUE}} !important;' ],
                    ] );
                $this->end_controls_tab();

                $this->start_controls_tab( 'atc_hover', [ 'label' => esc_html__( 'Hover', 'woolentor-pro' ) ] );
                    $this->add_control( 'atc_hover_bg', [
                        'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-cross-sell-card__atc:hover' => 'background-color: {{VALUE}} !important;' ],
                    ] );
                    $this->add_control( 'atc_hover_color', [
                        'label'     => esc_html__( 'Icon Color', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-cross-sell-card__atc:hover' => 'color: {{VALUE}} !important;' ],
                    ] );
                $this->end_controls_tab();

            $this->end_controls_tabs();

            $this->add_control( 'atc_border_radius', [
                'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-cross-sell-card__atc' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

        $this->end_controls_section();

    }

    protected function prepare_settings( $settings ) {
        $get = function( $key, $default = null ) use ( $settings ) {
            return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
        };

        return array_merge( $settings, [
            'cart_style'       => $this->cart_style,
            'widget_type'      => $this->widget_type,
            'section_title'    => $get( 'section_title', esc_html__( 'Pairs well with', 'woolentor-pro' ) ),
            'title_tag'        => $get( 'title_tag', 'h2' ),
            'products_count'   => absint( $get( 'products_count', 4 ) ),
            'columns'          => absint( $get( 'columns', 2 ) ),
            'show_price'       => $get( 'show_price', 'yes' ) === 'yes',
            'show_add_to_cart' => $get( 'show_add_to_cart', 'yes' ) === 'yes',
            'show_separator'   => $get( 'show_separator', 'yes' ) === 'yes',
            'image_size'       => isset( $settings['product_image_size'] ) ? $settings['product_image_size'] : 'woocommerce_thumbnail',
        ] );
    }

}
