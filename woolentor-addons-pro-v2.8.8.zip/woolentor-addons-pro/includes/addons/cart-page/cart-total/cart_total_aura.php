<?php
/**
 * Cart Total — Aura Widget
 *
 * @package WooLentor Pro
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'WooLentor_Cart_Page_Base_Widget' ) ) {
    require_once WOOLENTOR_ADDONS_PL_PATH_PRO . 'includes/addons/cart-page/base/class.cart-page-base-widget.php';
}

class Woolentor_Cart_Total_Aura_Widget extends WooLentor_Cart_Page_Base_Widget {

    protected $cart_style       = 'aura';
    protected $cart_style_label = 'Aura';
    protected $widget_type      = 'cart-total';

    public function get_name() {
        return 'woolentor-cart-total-aura';
    }

    public function get_title() {
        return esc_html__( 'WL: Cart Total — Aura', 'woolentor-pro' );
    }

    public function get_icon() {
        return 'woolentor-widget-new-icon eicon-woocommerce';
    }

    public function get_keywords() {
        return [ 'cart', 'total', 'order', 'summary', 'aura', 'woocommerce', 'woolentor' ];
    }

    // ─── Content controls ─────────────────────────────────────────────────────

    protected function register_content_controls() {

        // ── Order Summary Title ───────────────────────────────────────────────
        $this->start_controls_section( 'section_title', [
            'label' => esc_html__( 'Order Summary Title', 'woolentor-pro' ),
        ] );

            $this->add_control( 'show_title', [
                'label'        => esc_html__( 'Show Title', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'title_tag', [
                'label'     => esc_html__( 'HTML Tag', 'woolentor-pro' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'h2',
                'options'   => woolentor_html_tag_lists(),
                'condition' => [ 'show_title' => 'yes' ],
            ] );

            $this->add_control( 'title_text', [
                'label'     => esc_html__( 'Title Text', 'woolentor-pro' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__( 'Order summary', 'woolentor-pro' ),
                'condition' => [ 'show_title' => 'yes' ],
            ] );

            $this->add_control( 'show_title_badge', [
                'label'        => esc_html__( 'Show Badge', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'    => [ 'show_title' => 'yes' ],
            ] );

            $this->add_control( 'title_badge_text', [
                'label'     => esc_html__( 'Badge Text', 'woolentor-pro' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__( 'secure', 'woolentor-pro' ),
                'condition' => [ 'show_title' => 'yes', 'show_title_badge' => 'yes' ],
            ] );

        $this->end_controls_section();

        // ── Coupon ────────────────────────────────────────────────────────────
        $this->start_controls_section( 'section_coupon', [
            'label' => esc_html__( 'Coupon / Promo Code', 'woolentor-pro' ),
        ] );

            $this->add_control( 'show_coupon', [
                'label'        => esc_html__( 'Show Coupon Form', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'coupon_placeholder', [
                'label'     => esc_html__( 'Input Placeholder', 'woolentor-pro' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__( 'Promo code', 'woolentor-pro' ),
                'condition' => [ 'show_coupon' => 'yes' ],
            ] );

            $this->add_control( 'coupon_button_label', [
                'label'     => esc_html__( 'Button Label', 'woolentor-pro' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__( 'Apply', 'woolentor-pro' ),
                'condition' => [ 'show_coupon' => 'yes' ],
            ] );

        $this->end_controls_section();

        // ── Shipping Options ──────────────────────────────────────────────────
        $this->start_controls_section( 'section_shipping', [
            'label' => esc_html__( 'Shipping Options', 'woolentor-pro' ),
        ] );

            $this->add_control( 'show_shipping', [
                'label'        => esc_html__( 'Show Shipping Options', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'shipping_section_label', [
                'label'     => esc_html__( 'Section Label', 'woolentor-pro' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__( 'Delivery method', 'woolentor-pro' ),
                'condition' => [ 'show_shipping' => 'yes' ],
            ] );

        $this->end_controls_section();

        // ── Totals ────────────────────────────────────────────────────────────
        $this->start_controls_section( 'section_totals', [
            'label' => esc_html__( 'Order Totals', 'woolentor-pro' ),
        ] );

            $this->add_control( 'show_subtotal', [
                'label'        => esc_html__( 'Show Subtotal Row', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'show_discount_row', [
                'label'        => esc_html__( 'Show Discount Row', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'show_tax_row', [
                'label'        => esc_html__( 'Show Tax Row', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

        $this->end_controls_section();

        // ── Checkout Button ───────────────────────────────────────────────────
        $this->start_controls_section( 'section_checkout', [
            'label' => esc_html__( 'Checkout Button', 'woolentor-pro' ),
        ] );

            $this->add_control( 'checkout_button_label', [
                'label'   => esc_html__( 'Button Label', 'woolentor-pro' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( 'Proceed to secure checkout', 'woolentor-pro' ),
            ] );

        $this->end_controls_section();

        // ── Shipping Destination ──────────────────────────────────────────────
        $this->start_controls_section( 'section_shipping_dest', [
            'label' => esc_html__( 'Shipping Destination', 'woolentor-pro' ),
        ] );

            $this->add_control( 'show_shipping_dest', [
                'label'        => esc_html__( 'Show Shipping Destination', 'woolentor-pro' ),
                'description'  => esc_html__( 'Displays the customer\'s current shipping address with a change link at the bottom of the card.', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'shipping_dest_change_text', [
                'label'     => esc_html__( 'Change Link Text', 'woolentor-pro' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__( 'Change', 'woolentor-pro' ),
                'condition' => [ 'show_shipping_dest' => 'yes' ],
            ] );

        $this->end_controls_section();

        // ── Trust Signals ─────────────────────────────────────────────────────
        $this->start_controls_section( 'section_trust', [
            'label' => esc_html__( 'Trust Signals', 'woolentor-pro' ),
        ] );

            $this->add_control( 'show_trust', [
                'label'        => esc_html__( 'Show Trust Signals', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $repeater = new Repeater();

            $repeater->add_control( 'trust_icon', [
                'label' => esc_html__( 'Icon', 'woolentor-pro' ),
                'type'  => Controls_Manager::ICONS,
            ] );

            $repeater->add_control( 'trust_heading', [
                'label'   => esc_html__( 'Heading', 'woolentor-pro' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( 'Trust signal', 'woolentor-pro' ),
            ] );

            $repeater->add_control( 'trust_sub', [
                'label'   => esc_html__( 'Sub-label', 'woolentor-pro' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( 'Description text', 'woolentor-pro' ),
            ] );

            $this->add_control( 'trust_items', [
                'label'       => esc_html__( 'Items', 'woolentor-pro' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'trust_icon'    => [
                            'value'   => 'eicon-lock',
                            'library' => 'eicons',
                        ],
                        'trust_heading' => esc_html__( 'Secure checkout', 'woolentor-pro' ),
                        'trust_sub'     => esc_html__( 'SSL encrypted', 'woolentor-pro' ),
                    ],
                    [
                        'trust_icon'    => [
                            'value'   => 'eicon-history',
                            'library' => 'eicons',
                        ],
                        'trust_heading' => esc_html__( '30-day returns', 'woolentor-pro' ),
                        'trust_sub'     => esc_html__( 'No questions asked', 'woolentor-pro' ),
                    ],
                    [
                        'trust_icon'    => [
                            'value' => 'fas fa-shield-alt',
                            'library' => 'font-awesome',
                        ],
                        'trust_heading' => esc_html__( '2-year warranty', 'woolentor-pro' ),
                        'trust_sub'     => esc_html__( 'From manufacturer', 'woolentor-pro' ),
                    ],
                ],
                'title_field' => '{{{ trust_heading }}}',
                'condition'   => [ 'show_trust' => 'yes' ],
            ] );

        $this->end_controls_section();

    }

    // ─── Style controls ───────────────────────────────────────────────────────

    protected function register_style_controls() {

        // ── Title ─────────────────────────────────────────────────────────────
        $this->start_controls_section( 'style_title', [
            'label'     => esc_html__( 'Order Summary Title', 'woolentor-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_title' => 'yes' ],
        ] );

            $this->add_control( 'title_color', [
                'label'     => esc_html__( 'Title Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-order-summary-heading__title' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .wl-order-summary-heading__title',
            ] );

            $this->add_control( 'title_badge_color', [
                'label'     => esc_html__( 'Badge Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-order-summary-heading__badge' => 'color: {{VALUE}};' ],
                'separator' => 'before',
                'condition' => [ 'show_title_badge' => 'yes' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'      => 'title_badge_typography',
                'selector'  => '{{WRAPPER}} .wl-order-summary-heading__badge',
                'condition' => [ 'show_title_badge' => 'yes' ],
            ] );

            $this->add_responsive_control( 'title_margin', [
                'label'      => esc_html__( 'Margin', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'separator'  => 'before',
                'selectors'  => [ '{{WRAPPER}} .wl-order-summary-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

        $this->end_controls_section();

        // ── Card ──────────────────────────────────────────────────────────────
        $this->start_controls_section( 'style_card', [
            'label' => esc_html__( 'Summary Card', 'woolentor-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

            $this->add_control( 'card_bg_color', [
                'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-total-card' => 'background-color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Border::get_type(), [
                'name'     => 'card_border',
                'selector' => '{{WRAPPER}} .wl-cart-total-card',
            ] );

            $this->add_control( 'card_border_radius', [
                'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-cart-total-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_responsive_control( 'card_padding', [
                'label'      => esc_html__( 'Padding', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-cart-total-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

        $this->end_controls_section();

        // ── Coupon ────────────────────────────────────────────────────────────
        $this->start_controls_section( 'style_coupon', [
            'label'     => esc_html__( 'Coupon Form', 'woolentor-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_coupon' => 'yes' ],
        ] );

            $this->add_control( 'coupon_input_heading', [
                'label' => esc_html__( 'Input', 'woolentor-pro' ),
                'type'  => Controls_Manager::HEADING,
            ] );

            $this->add_control( 'coupon_input_color', [
                'label'     => esc_html__( 'Text Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-coupon-input' => 'color: {{VALUE}};' ],
            ] );

            $this->add_control( 'coupon_input_placeholder_color', [
                'label'     => esc_html__( 'Placeholder Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-coupon-input::placeholder' => 'color: {{VALUE}};' ],
            ] );

            $this->add_control( 'coupon_input_bg', [
                'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-coupon-input' => 'background-color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Border::get_type(), [
                'name'     => 'coupon_input_border',
                'selector' => '{{WRAPPER}} .wl-coupon-input',
            ] );

            $this->add_control( 'coupon_input_radius', [
                'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-coupon-input' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_responsive_control( 'coupon_input_padding', [
                'label'      => esc_html__( 'Padding', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .wl-coupon-input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'coupon_input_typography',
                'selector' => '{{WRAPPER}} .wl-coupon-input',
            ] );

            $this->add_control( 'coupon_btn_heading', [
                'label'     => esc_html__( 'Button', 'woolentor-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ] );

            $this->start_controls_tabs( 'coupon_btn_tabs' );

                $this->start_controls_tab( 'coupon_btn_normal', [ 'label' => esc_html__( 'Normal', 'woolentor-pro' ) ] );
                    $this->add_control( 'coupon_btn_color', [
                        'label'     => esc_html__( 'Text Color', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-coupon-btn' => 'color: {{VALUE}};' ],
                    ] );
                    $this->add_control( 'coupon_btn_bg', [
                        'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-coupon-btn' => 'background-color: {{VALUE}};' ],
                    ] );
                $this->end_controls_tab();

                $this->start_controls_tab( 'coupon_btn_hover', [ 'label' => esc_html__( 'Hover', 'woolentor-pro' ) ] );
                    $this->add_control( 'coupon_btn_hover_color', [
                        'label'     => esc_html__( 'Text Color', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-coupon-btn:hover' => 'color: {{VALUE}};' ],
                    ] );
                    $this->add_control( 'coupon_btn_hover_bg', [
                        'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-coupon-btn:hover' => 'background-color: {{VALUE}};' ],
                    ] );
                $this->end_controls_tab();

            $this->end_controls_tabs();

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'coupon_btn_typography',
                'selector' => '{{WRAPPER}} .wl-coupon-btn',
            ] );

            $this->add_control( 'coupon_btn_radius', [
                'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-coupon-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_responsive_control( 'coupon_btn_padding', [
                'label'      => esc_html__( 'Padding', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .wl-coupon-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

        $this->end_controls_section();

        // ── Shipping Options ──────────────────────────────────────────────────
        $this->start_controls_section( 'style_shipping', [
            'label'     => esc_html__( 'Shipping Options', 'woolentor-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_shipping' => 'yes' ],
        ] );

            $this->add_control( 'ship_label_color', [
                'label'     => esc_html__( 'Section Label Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-ship-label' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'ship_label_typography',
                'selector' => '{{WRAPPER}} .wl-ship-label',
            ] );

            $this->add_control( 'ship_opt_heading', [
                'label'     => esc_html__( 'Option Card', 'woolentor-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ] );

            $this->add_control( 'ship_opt_bg', [
                'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-ship-opt' => 'background-color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Border::get_type(), [
                'name'     => 'ship_opt_border',
                'selector' => '{{WRAPPER}} .wl-ship-opt',
            ] );

            $this->add_control( 'ship_opt_radius', [
                'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-ship-opt' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_responsive_control( 'ship_opt_padding', [
                'label'      => esc_html__( 'Padding', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .wl-ship-opt' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_control( 'ship_opt_selected_bg', [
                'label'     => esc_html__( 'Selected Background', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-ship-opt--selected' => 'background-color: {{VALUE}};' ],
            ] );

            $this->add_control( 'ship_opt_selected_border_color', [
                'label'     => esc_html__( 'Selected Border Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-ship-opt--selected' => 'border-color: {{VALUE}};' ],
            ] );

            $this->add_control( 'ship_radio_heading', [
                'label'     => esc_html__( 'Radio Indicator', 'woolentor-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ] );

            $this->add_control( 'ship_radio_border_color', [
                'label'     => esc_html__( 'Border Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-ship-radio' => 'border-color: {{VALUE}};' ],
            ] );

            $this->add_control( 'ship_radio_selected_border_color', [
                'label'     => esc_html__( 'Selected Border Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-ship-opt--selected .wl-ship-radio' => 'border-color: {{VALUE}};' ],
            ] );

            $this->add_control( 'ship_radio_dot_color', [
                'label'     => esc_html__( 'Dot Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-ship-radio::after' => 'background: {{VALUE}};' ],
            ] );

            $this->add_control( 'ship_name_heading', [
                'label'     => esc_html__( 'Method Name', 'woolentor-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ] );

            $this->add_control( 'ship_name_color', [
                'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-ship-opt-name' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'ship_name_typography',
                'selector' => '{{WRAPPER}} .wl-ship-opt-name',
            ] );

            $this->add_control( 'ship_price_heading', [
                'label'     => esc_html__( 'Method Price', 'woolentor-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ] );

            $this->add_control( 'ship_price_color', [
                'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-ship-opt-price' => 'color: {{VALUE}};' ],
            ] );

            $this->add_control( 'ship_price_free_color', [
                'label'     => esc_html__( 'Free Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-ship-opt-price--free' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'ship_price_typography',
                'selector' => '{{WRAPPER}} .wl-ship-opt-price',
            ] );

        $this->end_controls_section();

        // ── Order Totals ──────────────────────────────────────────────────────
        $this->start_controls_section( 'style_totals', [
            'label' => esc_html__( 'Order Totals Rows', 'woolentor-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

            $this->add_control( 'totals_label_color', [
                'label'     => esc_html__( 'Label Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-totals-label' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'totals_label_typography',
                'selector' => '{{WRAPPER}} .wl-totals-label',
            ] );

            $this->add_control( 'totals_value_color', [
                'label'     => esc_html__( 'Value Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-totals-value' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'totals_value_typography',
                'selector' => '{{WRAPPER}} .wl-totals-value',
            ] );

            $this->add_control( 'totals_discount_heading', [
                'label'     => esc_html__( 'Discount Row', 'woolentor-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [ 'show_discount_row' => 'yes' ],
            ] );

            $this->add_control( 'totals_discount_color', [
                'label'     => esc_html__( 'Discount Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-totals-row--discount' => 'color: {{VALUE}};' ],
                'condition' => [ 'show_discount_row' => 'yes' ],
            ] );

            $this->add_control( 'totals_discount_value_color', [
                'label'     => esc_html__( 'Discount Value Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-totals-row--discount .wl-totals-value' => 'color: {{VALUE}};' ],
                'condition' => [ 'show_discount_row' => 'yes' ],
            ] );

            $this->add_control( 'totals_divider_heading', [
                'label'     => esc_html__( 'Divider', 'woolentor-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ] );

            $this->add_control( 'totals_divider_color', [
                'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .wl-totals-section' => 'border-top-color: {{VALUE}};',
                    '{{WRAPPER}} .wl-grand-total'    => 'border-top-color: {{VALUE}};',
                ],
            ] );

        $this->end_controls_section();

        // ── Grand Total ───────────────────────────────────────────────────────
        $this->start_controls_section( 'style_grand_total', [
            'label' => esc_html__( 'Grand Total', 'woolentor-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

            $this->add_control( 'grand_label_color', [
                'label'     => esc_html__( 'Label Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-grand-total__label' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'grand_label_typography',
                'selector' => '{{WRAPPER}} .wl-grand-total__label',
            ] );

            $this->add_control( 'grand_tax_color', [
                'label'     => esc_html__( 'Tax Note Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-grand-total__label small' => 'color: {{VALUE}};' ],
            ] );

            $this->add_control( 'grand_value_color', [
                'label'     => esc_html__( 'Value Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-grand-total__value' => 'color: {{VALUE}};' ],
                'separator' => 'before',
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'grand_value_typography',
                'selector' => '{{WRAPPER}} .wl-grand-total__value',
            ] );

        $this->end_controls_section();

        // ── Checkout Button ───────────────────────────────────────────────────
        $this->start_controls_section( 'style_checkout_btn', [
            'label' => esc_html__( 'Checkout Button', 'woolentor-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

            $this->start_controls_tabs( 'checkout_btn_tabs' );

                $this->start_controls_tab( 'checkout_btn_normal', [ 'label' => esc_html__( 'Normal', 'woolentor-pro' ) ] );
                    $this->add_control( 'checkout_btn_color', [
                        'label'     => esc_html__( 'Text Color', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-checkout-btn' => 'color: {{VALUE}} !important;' ],
                    ] );
                    $this->add_control( 'checkout_btn_bg', [
                        'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-checkout-btn' => 'background-color: {{VALUE}} !important;' ],
                    ] );
                $this->end_controls_tab();

                $this->start_controls_tab( 'checkout_btn_hover', [ 'label' => esc_html__( 'Hover', 'woolentor-pro' ) ] );
                    $this->add_control( 'checkout_btn_hover_color', [
                        'label'     => esc_html__( 'Text Color', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-checkout-btn:hover' => 'color: {{VALUE}} !important;' ],
                    ] );
                    $this->add_control( 'checkout_btn_hover_bg', [
                        'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-checkout-btn:hover' => 'background-color: {{VALUE}} !important;' ],
                    ] );
                $this->end_controls_tab();

            $this->end_controls_tabs();

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'checkout_btn_typography',
                'selector' => '{{WRAPPER}} .wl-checkout-btn',
            ] );

            $this->add_control( 'checkout_btn_border_radius', [
                'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-checkout-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_responsive_control( 'checkout_btn_padding', [
                'label'      => esc_html__( 'Padding', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .wl-checkout-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

        $this->end_controls_section();

        // ── Shipping Destination ──────────────────────────────────────────────
        $this->start_controls_section( 'style_shipping_dest', [
            'label'     => esc_html__( 'Shipping Destination', 'woolentor-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_shipping_dest' => 'yes' ],
        ] );

            $this->add_control( 'ship_dest_bg', [
                'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-shipping-destination' => 'background-color: {{VALUE}};' ],
            ] );

            $this->add_control( 'ship_dest_radius', [
                'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-shipping-destination' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_responsive_control( 'ship_dest_padding', [
                'label'      => esc_html__( 'Padding', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .wl-shipping-destination' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_control( 'ship_dest_icon_color', [
                'label'     => esc_html__( 'Icon Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-shipping-destination svg' => 'color: {{VALUE}};' ],
                'separator' => 'before',
            ] );

            $this->add_control( 'ship_dest_text_color', [
                'label'     => esc_html__( 'Text Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-shipping-destination__text' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'ship_dest_text_typography',
                'selector' => '{{WRAPPER}} .wl-shipping-destination__text',
            ] );

            $this->add_control( 'ship_dest_change_color', [
                'label'     => esc_html__( 'Change Link Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-shipping-destination__change' => 'color: {{VALUE}};' ],
                'separator' => 'before',
            ] );

            $this->add_control( 'ship_dest_change_hover_color', [
                'label'     => esc_html__( 'Change Link Hover Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-shipping-destination__change:hover' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'ship_dest_change_typography',
                'selector' => '{{WRAPPER}} .wl-shipping-destination__change',
            ] );

        $this->end_controls_section();

        // ── Trust Signals ─────────────────────────────────────────────────────
        $this->start_controls_section( 'style_trust', [
            'label'     => esc_html__( 'Trust Signals', 'woolentor-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_trust' => 'yes' ],
        ] );

            $this->add_control( 'trust_divider_color', [
                'label'     => esc_html__( 'Divider Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-trust-signals' => 'border-top-color: {{VALUE}};' ],
            ] );

            $this->add_responsive_control( 'trust_icon_size', [
                'label'      => esc_html__( 'Icon Size', 'woolentor-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [ 'px' => [ 'min' => 10, 'max' => 60 ] ],
                'default'    => [ 'size' => 20 ],
                'selectors'  => [
                    '{{WRAPPER}} .wl-trust-cell__icon i'   => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .wl-trust-cell__icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ] );

            $this->add_control( 'trust_icon_color', [
                'label'     => esc_html__( 'Icon Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .wl-trust-cell__icon i'   => 'color: {{VALUE}};',
                    '{{WRAPPER}} .wl-trust-cell__icon svg' => 'color: {{VALUE}};',
                ],
            ] );

            $this->add_control( 'trust_heading_color', [
                'label'     => esc_html__( 'Heading Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-trust-cell__heading' => 'color: {{VALUE}};' ],
                'separator' => 'before',
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'trust_heading_typography',
                'selector' => '{{WRAPPER}} .wl-trust-cell__heading',
            ] );

            $this->add_control( 'trust_sub_color', [
                'label'     => esc_html__( 'Sub-label Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-trust-cell__sub' => 'color: {{VALUE}};' ],
                'separator' => 'before',
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'trust_sub_typography',
                'selector' => '{{WRAPPER}} .wl-trust-cell__sub',
            ] );

        $this->end_controls_section();

    }

    // ─── Settings normalisation ───────────────────────────────────────────────

    protected function prepare_settings( $settings ) {
        $get = function( $key, $default = null ) use ( $settings ) {
            return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
        };

        return array_merge( $settings, [
            'cart_style'                => $this->cart_style,
            'widget_type'               => $this->widget_type,
            'show_title'                => $get( 'show_title', 'yes' ) === 'yes',
            'title_tag'                 => $get( 'title_tag', 'h2' ),
            'title_text'                => $get( 'title_text', esc_html__( 'Order summary', 'woolentor-pro' ) ),
            'show_title_badge'          => $get( 'show_title_badge', 'yes' ) === 'yes',
            'title_badge_text'          => $get( 'title_badge_text', esc_html__( 'secure', 'woolentor-pro' ) ),
            'show_coupon'               => $get( 'show_coupon', 'yes' ) === 'yes',
            'coupon_placeholder'        => $get( 'coupon_placeholder', esc_html__( 'Promo code', 'woolentor-pro' ) ),
            'coupon_button_label'       => $get( 'coupon_button_label', esc_html__( 'Apply', 'woolentor-pro' ) ),
            'show_shipping'             => $get( 'show_shipping', 'yes' ) === 'yes',
            'shipping_section_label'    => $get( 'shipping_section_label', esc_html__( 'Delivery method', 'woolentor-pro' ) ),
            'show_subtotal'             => $get( 'show_subtotal', 'yes' ) === 'yes',
            'show_discount_row'         => $get( 'show_discount_row', 'yes' ) === 'yes',
            'show_tax_row'              => $get( 'show_tax_row', 'yes' ) === 'yes',
            'checkout_button_label'     => $get( 'checkout_button_label', esc_html__( 'Proceed to secure checkout', 'woolentor-pro' ) ),
            'show_trust'                => $get( 'show_trust', 'yes' ) === 'yes',
            'trust_items'               => $get( 'trust_items', [] ),
            'show_shipping_dest'        => $get( 'show_shipping_dest', 'yes' ) === 'yes',
            'shipping_dest_change_text' => $get( 'shipping_dest_change_text', esc_html__( 'Change', 'woolentor-pro' ) ),
        ] );
    }

}
