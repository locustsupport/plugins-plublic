<?php
/**
 * Cart Page Base Widget
 * Abstract Elementor widget base shared by all cart page style widgets.
 *
 * @package WooLentor Pro
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'WooLentor_Cart_Page_Base' ) ) {
    require_once WOOLENTOR_ADDONS_PL_PATH_PRO . 'includes/addons/cart-page/base/class.cart-page-base.php';
}

abstract class WooLentor_Cart_Page_Base_Widget extends Widget_Base {

    /** Style key, e.g. 'aura'. Set by each child widget. */
    protected $cart_style = '';

    /** Human-readable style label. Set by each child widget. */
    protected $cart_style_label = '';

    /**
     * Widget type key: 'cart-table' | 'cart-total' | 'cart-cross-sells' | 'cart-empty'.
     * Set by each child widget.
     */
    protected $widget_type = '';

    /** @var WooLentor_Cart_Page_Base */
    protected $cart_page_base;

    public function __construct( $data = [], $args = null ) {
        parent::__construct( $data, $args );

        if ( class_exists( '\WooLentor_Cart_Page_Base' ) ) {
            $this->cart_page_base = \WooLentor_Cart_Page_Base::instance();
        }

        $this->enqueue_style_assets();
    }

    // ─── Shared Elementor metadata ────────────────────────────────────────────

    public function get_categories() {
        return [ 'woolentor-addons-pro' ];
    }

    public function get_help_url() {
        return 'https://woolentor.com/documentation/';
    }

    public function get_script_depends() {
        return [ 'woolentor-widgets-scripts' ];
    }

    public function get_style_depends() {
        $handles = [ 'woolentor-cart-page-base' ];
        if ( ! empty( $this->cart_style ) ) {
            $handles[] = 'woolentor-cart-page-' . $this->cart_style;
        }
        return $handles;
    }

    // ─── Control registration ─────────────────────────────────────────────────

    protected function register_controls() {
        // Content controls — each widget type implements this fully
        $this->register_content_controls();

        // Style-specific controls — optional hook for child classes
        $this->register_style_specific_controls();

        // Shared visual style controls
        $this->register_style_controls();
    }

    /**
     * Register all content controls for this widget type.
     * Each child class MUST implement this.
     */
    abstract protected function register_content_controls();

    /**
     * Optional: register controls that are unique to a specific style variant.
     * Override in a child style class (e.g. Aura adds warm-tone colour overrides).
     */
    protected function register_style_specific_controls() {}

    /**
     * Register visual style controls (colors, typography, spacing).
     * Override in each child class to expose the correct selectors.
     */
    protected function register_style_controls() {}

    // ─── Render ───────────────────────────────────────────────────────────────

    protected function render() {
        if ( ! $this->cart_page_base ) {
            return;
        }

        $settings      = $this->get_settings_for_display();
        $cart_settings = $this->prepare_settings( $settings );

        $this->cart_page_base->render( $this->widget_type, $this->cart_style, $cart_settings );
    }

    /**
     * Convert Elementor settings to the normalised settings array that the
     * template will receive.  Override in child classes to add extra keys.
     *
     * @param  array $settings Raw Elementor settings.
     * @return array
     */
    protected function prepare_settings( $settings ) {
        return array_merge( $settings, [
            'cart_style'  => $this->cart_style,
            'widget_type' => $this->widget_type,
        ] );
    }

    // ─── Asset enqueue ────────────────────────────────────────────────────────

    protected function enqueue_style_assets() {
        $version = defined( 'WOOLENTOR_VERSION_PRO' ) ? WOOLENTOR_VERSION_PRO : '1.0.0';

        // ── CSS ───────────────────────────────────────────────────────────────

        // Base CSS shared across all cart-page styles
        wp_enqueue_style(
            'woolentor-cart-page-base',
            WOOLENTOR_ADDONS_PL_URL_PRO . 'assets/css/cart-page/base.css',
            [],
            $version
        );

        // Style-specific CSS
        if ( ! empty( $this->cart_style ) ) {
            wp_enqueue_style(
                'woolentor-cart-page-' . $this->cart_style,
                WOOLENTOR_ADDONS_PL_URL_PRO . 'assets/css/cart-page/' . $this->cart_style . '.css',
                [ 'woolentor-cart-page-base' ],
                $version
            );
        }

        // ── JS ────────────────────────────────────────────────────────────────

        // Register once — subsequent calls are no-ops because of the handle check
        if ( ! wp_script_is( 'woolentor-cart-page', 'registered' ) ) {
            wp_register_script(
                'woolentor-cart-page',
                WOOLENTOR_ADDONS_PL_URL_PRO . 'assets/js/cart-page/cart-page.js',
                [],
                $version,
                true  // footer
            );

            // Localize params once alongside the registration
            wp_localize_script(
                'woolentor-cart-page',
                'wlCartPageParams',
                [
                    'ajaxUrl' => esc_url( admin_url( 'admin-ajax.php' ) ),
                    'nonce'   => wp_create_nonce( 'wl-cart-page-nonce' ),
                ]
            );
        }

        wp_enqueue_script( 'woolentor-cart-page' );
    }

}
