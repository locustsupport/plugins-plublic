<?php
/**
 * Cart Table — Aura Widget
 *
 * @package WooLentor Pro
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'WooLentor_Cart_Page_Base_Widget' ) ) {
    require_once WOOLENTOR_ADDONS_PL_PATH_PRO . 'includes/addons/cart-page/base/class.cart-page-base-widget.php';
}

class Woolentor_Cart_Table_Aura_Widget extends WooLentor_Cart_Page_Base_Widget {

    protected $cart_style       = 'aura';
    protected $cart_style_label = 'Aura';
    protected $widget_type      = 'cart-table';

    public function get_name() {
        return 'woolentor-cart-table-aura';
    }

    public function get_title() {
        return esc_html__( 'WL: Cart Table — Aura', 'woolentor-pro' );
    }

    public function get_icon() {
        return 'woolentor-widget-new-icon eicon-woocommerce';
    }

    public function get_keywords() {
        return [ 'cart', 'table', 'aura', 'woocommerce', 'woolentor', '2026' ];
    }

    // ─── Content controls ─────────────────────────────────────────────────────

    protected function register_content_controls() {

        // ── Cart Heading ──────────────────────────────────────────────────────
        $this->start_controls_section( 'section_heading', [
            'label' => esc_html__( 'Cart Heading', 'woolentor-pro' ),
        ] );

            $this->add_control( 'show_heading', [
                'label'        => esc_html__( 'Show Heading', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'heading_tag', [
                'label'     => esc_html__( 'HTML Tag', 'woolentor-pro' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'h2',
                'options' => woolentor_html_tag_lists(),
                'condition' => [ 'show_heading' => 'yes' ],
            ] );

            $this->add_control( 'heading_text', [
                'label'     => esc_html__( 'Heading Text', 'woolentor-pro' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__( 'In your cart', 'woolentor-pro' ),
                'condition' => [ 'show_heading' => 'yes' ],
            ] );

            $this->add_control( 'show_counter', [
                'label'        => esc_html__( 'Show Item Counter', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'    => [ 'show_heading' => 'yes' ],
            ] );

            $this->add_control( 'counter_separator', [
                'label'     => esc_html__( 'Counter Separator', 'woolentor-pro' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => '·',
                'condition' => [ 'show_heading' => 'yes', 'show_counter' => 'yes' ],
            ] );

            $this->add_control( 'counter_suffix_singular', [
                'label'       => esc_html__( 'Suffix — Singular', 'woolentor-pro' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__( 'item', 'woolentor-pro' ),
                'description' => esc_html__( 'Used when cart has exactly 1 item.', 'woolentor-pro' ),
                'condition'   => [ 'show_heading' => 'yes', 'show_counter' => 'yes' ],
            ] );

            $this->add_control( 'counter_suffix_plural', [
                'label'       => esc_html__( 'Suffix — Plural', 'woolentor-pro' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__( 'items', 'woolentor-pro' ),
                'description' => esc_html__( 'Used when cart has 0 or 2+ items.', 'woolentor-pro' ),
                'condition'   => [ 'show_heading' => 'yes', 'show_counter' => 'yes' ],
            ] );

        $this->end_controls_section();

        // ── General ──────────────────────────────────────────────────────────
        $this->start_controls_section( 'section_general', [
            'label' => esc_html__( 'General', 'woolentor-pro' ),
        ] );

            $this->add_group_control(
                Group_Control_Image_Size::get_type(),
                [
                    'name'    => 'product_image',
                    'default' => 'woocommerce_thumbnail',
                ]
            );

        $this->end_controls_section();

        // ── Product Display ───────────────────────────────────────────────────
        $this->start_controls_section( 'section_product_display', [
            'label' => esc_html__( 'Product Display', 'woolentor-pro' ),
        ] );

            $this->add_control( 'show_image', [
                'label'        => esc_html__( 'Show Image', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'show_vendor', [
                'label'        => esc_html__( 'Show Brand / Vendor Label', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'vendor_source', [
                'label'     => esc_html__( 'Brand Source', 'woolentor-pro' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'taxonomy',
                'options'   => [
                    'taxonomy' => esc_html__( 'Product Taxonomy', 'woolentor-pro' ),
                    'meta'     => esc_html__( 'Custom Meta Key', 'woolentor-pro' ),
                ],
                'condition' => [ 'show_vendor' => 'yes' ],
            ] );

            $this->add_control( 'vendor_taxonomy', [
                'label'       => esc_html__( 'Brand Taxonomy', 'woolentor-pro' ),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'product_brand',
                'options'     => woolentor_pro_get_taxonomies( 'product', true ),
                'description' => esc_html__( 'Defaults to WooCommerce built-in Brands. Choose any registered product taxonomy.', 'woolentor-pro' ),
                'condition'   => [
                    'show_vendor'   => 'yes',
                    'vendor_source' => 'taxonomy',
                ],
            ] );

            $this->add_control( 'vendor_meta_key', [
                'label'       => esc_html__( 'Meta Key', 'woolentor-pro' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => '_vendor_label',
                'description' => esc_html__( 'Post meta key for the vendor / brand label.', 'woolentor-pro' ),
                'condition'   => [
                    'show_vendor'   => 'yes',
                    'vendor_source' => 'meta',
                ],
            ] );

            $this->add_control( 'show_attributes', [
                'label'        => esc_html__( 'Show Variation Attributes', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'show_stock_status', [
                'label'        => esc_html__( 'Show Stock Status', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'stock_status_text', [
                'label'     => esc_html__( 'In Stock Label', 'woolentor-pro' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__( 'In stock', 'woolentor-pro' ),
                'condition' => [ 'show_stock_status' => 'yes' ],
            ] );

        $this->end_controls_section();

        // ── Quantity ──────────────────────────────────────────────────────────
        $this->start_controls_section( 'section_quantity', [
            'label' => esc_html__( 'Quantity', 'woolentor-pro' ),
        ] );

            $this->add_control( 'show_qty', [
                'label'        => esc_html__( 'Show Quantity Stepper', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

        $this->end_controls_section();

        // ── Actions ───────────────────────────────────────────────────────────
        $this->start_controls_section( 'section_actions', [
            'label' => esc_html__( 'Actions', 'woolentor-pro' ),
        ] );

            $this->add_control( 'show_remove', [
                'label'        => esc_html__( 'Show Remove Button', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'remove_label', [
                'label'     => esc_html__( 'Remove Label', 'woolentor-pro' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__( 'Remove', 'woolentor-pro' ),
                'condition' => [ 'show_remove' => 'yes' ],
            ] );

        $this->end_controls_section();

        // ── Price ─────────────────────────────────────────────────────────────
        $this->start_controls_section( 'section_price', [
            'label' => esc_html__( 'Price', 'woolentor-pro' ),
        ] );

            $this->add_control( 'show_regular_price', [
                'label'        => esc_html__( 'Show Original / Regular Price', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'show_savings_badge', [
                'label'        => esc_html__( 'Show Savings Badge', 'woolentor-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'woolentor-pro' ),
                'label_off'    => esc_html__( 'Hide', 'woolentor-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ] );

            $this->add_control( 'savings_badge_label', [
                'label'       => esc_html__( 'Savings Badge Label', 'woolentor-pro' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__( 'You save %s', 'woolentor-pro' ),
                'description' => esc_html__( 'Use %s as placeholder for the saving amount.', 'woolentor-pro' ),
                'condition'   => [ 'show_savings_badge' => 'yes' ],
            ] );

        $this->end_controls_section();

    }

    // ─── Style controls ───────────────────────────────────────────────────────

    protected function register_style_controls() {

        // ── Heading ───────────────────────────────────────────────────────────
        $this->start_controls_section( 'style_heading', [
            'label'     => esc_html__( 'Cart Heading', 'woolentor-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_heading' => 'yes' ],
        ] );

            $this->add_responsive_control( 'heading_margin', [
                'label'      => esc_html__( 'Margin', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-cart-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_control( 'heading_title_heading', [
                'label' => esc_html__( 'Title', 'woolentor-pro' ),
                'type'  => Controls_Manager::HEADING,
            ] );

            $this->add_control( 'heading_title_color', [
                'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-heading__title' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'heading_title_typography',
                'selector' => '{{WRAPPER}} .wl-cart-heading__title',
            ] );

            $this->add_control( 'heading_counter_heading', [
                'label'     => esc_html__( 'Counter', 'woolentor-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [ 'show_counter' => 'yes' ],
            ] );

            $this->add_control( 'heading_counter_color', [
                'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-heading__counter' => 'color: {{VALUE}};' ],
                'condition' => [ 'show_counter' => 'yes' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'      => 'heading_counter_typography',
                'selector'  => '{{WRAPPER}} .wl-cart-heading__counter',
                'condition' => [ 'show_counter' => 'yes' ],
            ] );

        $this->end_controls_section();

        // ── Item Card ─────────────────────────────────────────────────────────
        $this->start_controls_section( 'style_card', [
            'label' => esc_html__( 'Item Card', 'woolentor-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

            $this->add_control( 'card_bg_color', [
                'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-item' => 'background-color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Border::get_type(), [
                'name'     => 'card_border',
                'selector' => '{{WRAPPER}} .wl-cart-item',
            ] );

            $this->add_control( 'card_border_radius', [
                'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-cart-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_responsive_control( 'card_padding', [
                'label'      => esc_html__( 'Padding', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-cart-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_responsive_control( 'card_gap', [
                'label'      => esc_html__( 'Gap Between Items', 'woolentor-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 60 ] ],
                'default'    => [ 'size' => 15 ],
                'selectors'  => [ '{{WRAPPER}} .wl-cart-table-wrap form' => 'gap: {{SIZE}}{{UNIT}};' ],
            ] );

            $this->add_group_control( Group_Control_Box_Shadow::get_type(), [
                'name'     => 'card_hover_shadow',
                'label'    => esc_html__( 'Hover Shadow', 'woolentor-pro' ),
                'selector' => '{{WRAPPER}} .wl-cart-item:hover',
            ] );

        $this->end_controls_section();

        // ── Image ─────────────────────────────────────────────────────────────
        $this->start_controls_section( 'style_image', [
            'label'     => esc_html__( 'Image', 'woolentor-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_image' => 'yes' ],
        ] );

            $this->add_control( 'image_border_radius', [
                'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-cart-item__image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_responsive_control( 'image_width', [
                'label'      => esc_html__( 'Image Width', 'woolentor-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 40, 'max' => 300 ] ],
                'default'    => [ 'size' => 130 ],
                'selectors'  => [ '{{WRAPPER}} .wl-cart-item__image' => 'width: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
            ] );

        $this->end_controls_section();

        // ── Vendor Label ──────────────────────────────────────────────────────
        $this->start_controls_section( 'style_vendor', [
            'label'     => esc_html__( 'Vendor Label', 'woolentor-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_vendor' => 'yes' ],
        ] );

            $this->add_control( 'vendor_color', [
                'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-item__vendor' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'vendor_typography',
                'selector' => '{{WRAPPER}} .wl-cart-item__vendor',
            ] );

        $this->end_controls_section();

        // ── Product Name ──────────────────────────────────────────────────────
        $this->start_controls_section( 'style_product_name', [
            'label' => esc_html__( 'Product Name', 'woolentor-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

            $this->add_control( 'name_color', [
                'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-item__name a' => 'color: {{VALUE}};' ],
            ] );

            $this->add_control( 'name_hover_color', [
                'label'     => esc_html__( 'Hover Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-item__name a:hover' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'name_typography',
                'selector' => '{{WRAPPER}} .wl-cart-item__name a',
            ] );

        $this->end_controls_section();

        // ── Stock Status ──────────────────────────────────────────────────────
        $this->start_controls_section( 'style_stock', [
            'label'     => esc_html__( 'Stock Status', 'woolentor-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_stock_status' => 'yes' ],
        ] );

            $this->add_control( 'stock_color', [
                'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .wl-cart-item__stock'     => 'color: {{VALUE}};',
                    '{{WRAPPER}} .wl-cart-item__stock-dot' => 'background: {{VALUE}};',
                ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'stock_typography',
                'selector' => '{{WRAPPER}} .wl-cart-item__stock',
            ] );

        $this->end_controls_section();

        // ── Qty Stepper ───────────────────────────────────────────────────────
        $this->start_controls_section( 'style_qty', [
            'label'     => esc_html__( 'Quantity Stepper', 'woolentor-pro' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_qty' => 'yes' ],
        ] );

            $this->add_control( 'qty_bg_color', [
                'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-qty-stepper' => 'background-color: {{VALUE}};' ],
            ] );

            $this->add_control( 'qty_border_color', [
                'label'     => esc_html__( 'Border Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-qty-stepper' => 'border-color: {{VALUE}};' ],
            ] );

            $this->add_control( 'qty_btn_color', [
                'label'     => esc_html__( 'Button Icon Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-qty-stepper button' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'qty_input_typography',
                'label'    => esc_html__( 'Input Typography', 'woolentor-pro' ),
                'selector' => '{{WRAPPER}} .wl-qty-stepper input',
            ] );

        $this->end_controls_section();

        // ── Action Links ──────────────────────────────────────────────────────
        $this->start_controls_section( 'style_actions', [
            'label' => esc_html__( 'Action Links', 'woolentor-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

            $this->add_control( 'action_color', [
                'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-item__action-link' => 'color: {{VALUE}};' ],
            ] );

            $this->add_control( 'action_hover_color', [
                'label'     => esc_html__( 'Hover Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-item__action-link:hover' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'action_typography',
                'selector' => '{{WRAPPER}} .wl-cart-item__action-link',
            ] );

        $this->end_controls_section();

        // ── Price ─────────────────────────────────────────────────────────────
        $this->start_controls_section( 'style_price', [
            'label' => esc_html__( 'Price', 'woolentor-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

            $this->add_control( 'price_color', [
                'label'     => esc_html__( 'Current Price Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-item__price-current' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'price_typography',
                'label'    => esc_html__( 'Current Price Typography', 'woolentor-pro' ),
                'selector' => '{{WRAPPER}} .wl-cart-item__price-current',
            ] );

            $this->add_control( 'regular_price_color', [
                'label'     => esc_html__( 'Original Price Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-item__price-regular' => 'color: {{VALUE}};' ],
                'condition' => [ 'show_regular_price' => 'yes' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'      => 'regular_price_typography',
                'label'     => esc_html__( 'Original Price Typography', 'woolentor-pro' ),
                'selector'  => '{{WRAPPER}} .wl-cart-item__price-regular',
                'condition' => [ 'show_regular_price' => 'yes' ],
            ] );

            $this->add_control( 'savings_badge_heading', [
                'label'     => esc_html__( 'Savings Badge', 'woolentor-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [ 'show_savings_badge' => 'yes' ],
            ] );

            $this->add_control( 'savings_badge_color', [
                'label'     => esc_html__( 'Text Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-item__savings-badge' => 'color: {{VALUE}};' ],
                'condition' => [ 'show_savings_badge' => 'yes' ],
            ] );

            $this->add_control( 'savings_badge_bg_color', [
                'label'     => esc_html__( 'Background Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-item__savings-badge' => 'background-color: {{VALUE}};' ],
                'condition' => [ 'show_savings_badge' => 'yes' ],
            ] );

            $this->add_control( 'savings_badge_border_radius', [
                'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-cart-item__savings-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
                'condition'  => [ 'show_savings_badge' => 'yes' ],
            ] );

        $this->end_controls_section();

    }

    // ─── Settings normalisation ───────────────────────────────────────────────

    protected function prepare_settings( $settings ) {
        $get = function( $key, $default = null ) use ( $settings ) {
            return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
        };

        $item_count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;

        return array_merge( $settings, [
            'cart_style'              => $this->cart_style,
            'widget_type'             => $this->widget_type,
            'show_heading'            => $get( 'show_heading', 'yes' ) === 'yes',
            'heading_tag'             => $get( 'heading_tag', 'h2' ),
            'heading_text'            => $get( 'heading_text', esc_html__( 'In your cart', 'woolentor-pro' ) ),
            'show_counter'            => $get( 'show_counter', 'yes' ) === 'yes',
            'counter_separator'       => $get( 'counter_separator', '·' ),
            'counter_suffix_singular' => $get( 'counter_suffix_singular', esc_html__( 'item', 'woolentor-pro' ) ),
            'counter_suffix_plural'   => $get( 'counter_suffix_plural', esc_html__( 'items', 'woolentor-pro' ) ),
            'cart_item_count'         => $item_count,
            'show_image'              => $get( 'show_image', 'yes' ) === 'yes',
            'image_size'          => isset( $settings['product_image_size'] ) ? $settings['product_image_size'] : 'woocommerce_thumbnail',
            'show_vendor'         => $get( 'show_vendor', 'yes' ) === 'yes',
            'vendor_source'       => $get( 'vendor_source', 'taxonomy' ),
            'vendor_taxonomy'     => $get( 'vendor_taxonomy', 'product_brand' ),
            'vendor_meta_key'     => $get( 'vendor_meta_key', '_vendor_label' ),
            'show_attributes'     => $get( 'show_attributes', 'yes' ) === 'yes',
            'show_stock_status'   => $get( 'show_stock_status', 'yes' ) === 'yes',
            'stock_status_text'   => $get( 'stock_status_text', esc_html__( 'In stock', 'woolentor-pro' ) ),
            'show_qty'            => $get( 'show_qty', 'yes' ) === 'yes',
            'show_remove'         => $get( 'show_remove', 'yes' ) === 'yes',
            'remove_label'        => $get( 'remove_label', esc_html__( 'Remove', 'woolentor-pro' ) ),
            'show_regular_price'  => $get( 'show_regular_price', 'yes' ) === 'yes',
            'show_savings_badge'  => $get( 'show_savings_badge', 'yes' ) === 'yes',
            'savings_badge_label' => $get( 'savings_badge_label', esc_html__( 'You save %s', 'woolentor-pro' ) ),
        ] );
    }

}
