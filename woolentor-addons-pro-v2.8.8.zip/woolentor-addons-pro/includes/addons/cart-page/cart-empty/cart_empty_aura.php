<?php
/**
 * Cart Empty — Aura Widget
 *
 * @package WooLentor Pro
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'WooLentor_Cart_Page_Base_Widget' ) ) {
    require_once WOOLENTOR_ADDONS_PL_PATH_PRO . 'includes/addons/cart-page/base/class.cart-page-base-widget.php';
}

class Woolentor_Cart_Empty_Aura_Widget extends WooLentor_Cart_Page_Base_Widget {

    protected $cart_style       = 'aura';
    protected $cart_style_label = 'Aura';
    protected $widget_type      = 'cart-empty';

    public function get_name() {
        return 'woolentor-cart-empty-aura';
    }

    public function get_title() {
        return esc_html__( 'WL: Cart Empty — Aura', 'woolentor-pro' );
    }

    public function get_icon() {
        return 'woolentor-widget-new-icon eicon-woocommerce';
    }

    public function get_keywords() {
        return [ 'cart', 'empty', 'aura', 'woocommerce', 'woolentor' ];
    }

    protected function register_content_controls() {

        $this->start_controls_section( 'section_content', [
            'label' => esc_html__( 'Content', 'woolentor-pro' ),
        ] );

            $this->add_control( 'icon', [
                'label'   => esc_html__( 'Icon', 'woolentor-pro' ),
                'type'    => Controls_Manager::ICONS,
                'default' => [
                    'value'   => 'fas fa-cart-arrow-down',
                    'library' => 'font-awesome',
                ],
            ] );

            $this->add_control( 'heading', [
                'label'   => esc_html__( 'Heading', 'woolentor-pro' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( 'Your cart is empty', 'woolentor-pro' ),
            ] );

            $this->add_control( 'sub_text', [
                'label'   => esc_html__( 'Sub Text', 'woolentor-pro' ),
                'type'    => Controls_Manager::TEXTAREA,
                'default' => esc_html__( 'Looks like you haven\'t added anything to your cart yet.', 'woolentor-pro' ),
                'rows'    => 3,
            ] );

            $this->add_control( 'button_label', [
                'label'   => esc_html__( 'Button Label', 'woolentor-pro' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( 'Continue shopping', 'woolentor-pro' ),
            ] );

            $this->add_control( 'button_url', [
                'label'         => esc_html__( 'Button URL', 'woolentor-pro' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => esc_html__( 'Leave blank to use shop page', 'woolentor-pro' ),
                'show_external' => true,
            ] );

        $this->end_controls_section();

    }

    protected function register_style_controls() {

        $this->start_controls_section( 'style_content', [
            'label' => esc_html__( 'Content', 'woolentor-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

            $this->add_responsive_control( 'icon_size', [
                'label'      => esc_html__( 'Icon Size', 'woolentor-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [ 'px' => [ 'min' => 20, 'max' => 200 ] ],
                'default'    => [ 'size' => 64 ],
                'selectors'  => [
                    '{{WRAPPER}} .wl-cart-empty__icon i'   => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .wl-cart-empty__icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ] );

            $this->add_control( 'icon_color', [
                'label'     => esc_html__( 'Icon Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .wl-cart-empty__icon i'   => 'color: {{VALUE}};',
                    '{{WRAPPER}} .wl-cart-empty__icon svg' => 'color: {{VALUE}};',
                ],
            ] );

            $this->add_control( 'heading_color', [
                'label'     => esc_html__( 'Heading Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-empty__heading' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'heading_typography',
                'selector' => '{{WRAPPER}} .wl-cart-empty__heading',
            ] );

            $this->add_control( 'sub_color', [
                'label'     => esc_html__( 'Sub Text Color', 'woolentor-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wl-cart-empty__sub' => 'color: {{VALUE}};' ],
            ] );

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'sub_typography',
                'label'    => esc_html__( 'Sub Text Typography', 'woolentor-pro' ),
                'selector' => '{{WRAPPER}} .wl-cart-empty__sub',
            ] );

        $this->end_controls_section();

        $this->start_controls_section( 'style_button', [
            'label' => esc_html__( 'Button', 'woolentor-pro' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

            $this->start_controls_tabs( 'btn_tabs' );

                $this->start_controls_tab( 'btn_normal', [ 'label' => esc_html__( 'Normal', 'woolentor-pro' ) ] );
                    $this->add_control( 'btn_color', [
                        'label'     => esc_html__( 'Text Color', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-cart-empty-btn' => 'color: {{VALUE}};' ],
                    ] );
                    $this->add_control( 'btn_bg', [
                        'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-cart-empty-btn' => 'background-color: {{VALUE}};' ],
                    ] );
                $this->end_controls_tab();

                $this->start_controls_tab( 'btn_hover', [ 'label' => esc_html__( 'Hover', 'woolentor-pro' ) ] );
                    $this->add_control( 'btn_hover_color', [
                        'label'     => esc_html__( 'Text Color', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-cart-empty-btn:hover' => 'color: {{VALUE}};' ],
                    ] );
                    $this->add_control( 'btn_hover_bg', [
                        'label'     => esc_html__( 'Background', 'woolentor-pro' ),
                        'type'      => Controls_Manager::COLOR,
                        'selectors' => [ '{{WRAPPER}} .wl-cart-empty-btn:hover' => 'background-color: {{VALUE}};' ],
                    ] );
                $this->end_controls_tab();

            $this->end_controls_tabs();

            $this->add_group_control( Group_Control_Typography::get_type(), [
                'name'     => 'btn_typography',
                'selector' => '{{WRAPPER}} .wl-cart-empty-btn',
            ] );

            $this->add_control( 'btn_border_radius', [
                'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .wl-cart-empty-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

            $this->add_responsive_control( 'btn_padding', [
                'label'      => esc_html__( 'Padding', 'woolentor-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .wl-cart-empty-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ] );

        $this->end_controls_section();

    }

    protected function prepare_settings( $settings ) {
        $get = function( $key, $default = null ) use ( $settings ) {
            return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
        };

        $button_url_data = ! empty( $settings['button_url'] ) ? $settings['button_url'] : [];
        $button_url      = ! empty( $button_url_data['url'] ) ? $button_url_data['url'] : '';
        if ( empty( $button_url ) ) {
            $button_url = get_permalink( wc_get_page_id( 'shop' ) );
        }

        return array_merge( $settings, [
            'cart_style'    => $this->cart_style,
            'widget_type'   => $this->widget_type,
            'heading'       => $get( 'heading', esc_html__( 'Your cart is empty', 'woolentor-pro' ) ),
            'sub_text'      => $get( 'sub_text', '' ),
            'button_label'  => $get( 'button_label', esc_html__( 'Continue shopping', 'woolentor-pro' ) ),
            'button_url'    => $button_url,
            'button_target' => ! empty( $button_url_data['is_external'] ) ? '_blank' : '',
            'button_rel'    => ! empty( $button_url_data['nofollow'] ) ? 'nofollow' : '',
            'icon'          => $get( 'icon', [] ),
        ] );
    }

}
