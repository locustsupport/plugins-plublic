<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Woolentor_Wl_Checkout_Notices_Widget extends Widget_Base {

    public function get_name() {
        return 'wl-checkout-notices';
    }

    public function get_title() {
        return __( 'WL: Checkout Notices', 'woolentor-pro' );
    }

    public function get_icon() {
        return 'woolentor-widget-new-icon eicon-alert';
    }

    public function get_help_url() {
        return 'https://woolentor.com/documentation/';
    }

    public function get_categories() {
        return array( 'woolentor-addons-pro' );
    }

    public function get_script_depends(){
        return [
            'woolentor-checkout'
        ];
    }

    public function get_keywords(){
        return ['checkout notices','error message','notice','checkout error','validation message'];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_notices_content',
            [
                'label' => esc_html__( 'Checkout Notices', 'woolentor-pro' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

            $this->add_control(
                'notices_info',
                [
                    'type' => Controls_Manager::RAW_HTML,
                    'raw'  => esc_html__( 'This widget marks where checkout notices (validation errors, coupon/payment messages) will be displayed. Place it anywhere in your Checkout or Checkout Top Content template.', 'woolentor-pro' ),
                    'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
                ]
            );

        $this->end_controls_section();

    }

    protected function render() {
        ?>
        <div id="woolentor-checkout-notices" class="woolentor-checkout-notices">
            <?php if ( Plugin::instance()->editor->is_edit_mode() ) : ?>
                <div class="woolentor-checkout-notices-placeholder"><?php esc_html_e( 'Checkout notices will appear here.', 'woolentor-pro' ); ?></div>
            <?php endif; ?>
        </div>
        <?php
    }

}
