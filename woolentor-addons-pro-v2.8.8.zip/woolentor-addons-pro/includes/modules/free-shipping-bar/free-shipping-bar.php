<?php
namespace WoolentorPro\Modules\FreeShippingBar;
use WooLentorPro\Traits\ModuleBase;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Free Shipping Bar — Pro Extension
 *
 * Loaded by the free module when WooLentor Pro is active.
 * Bootstrap only: define constants → include class files → init.
 */
class Free_Shipping_Bar_Pro {
    use ModuleBase;

    const SECTION = 'woolentor_free_shipping_bar_settings';
    const ANALYTICS_OPTION = 'woolentor_fsb_analytics';
    const AB_COOKIE = 'wl_fsb_ab';

    private function __construct() {
        $this->define_constants();
        $this->includes();
        $this->init();
    }

    private function define_constants() {
        define( 'WoolentorPro\Modules\FreeShippingBar\MODULE_PATH', __DIR__ );
        define( 'WoolentorPro\Modules\FreeShippingBar\MODULE_INCLUDES_PATH', __DIR__ . '/includes' );
        define( 'WoolentorPro\Modules\FreeShippingBar\MODULE_URL', plugins_url( '', __FILE__ ) );
        define( 'WoolentorPro\Modules\FreeShippingBar\ENABLED', self::$_enabled );
    }

    private function includes() {
        require_once MODULE_INCLUDES_PATH . '/classes/Admin.php';
        require_once MODULE_INCLUDES_PATH . '/classes/Frontend.php';
    }

    private function init() {
        if ( $this->is_request( 'admin' ) || $this->is_request( 'rest' ) ) {
            Admin::instance();
        }
        
        // wp_doing_ajax() ensures Analytics AJAX hooks register on admin-ajax.php requests
        if( self::$_enabled ){
            if ( $this->is_request( 'frontend' ) || $this->is_request( 'block' ) ) {
                Frontend::instance();
            }
        }
    }

    /**
     * Shared setting reader for all sub-classes.
     */
    public static function setting( $key, $default = '' ) {
        return woolentor_get_option( $key, self::SECTION, $default );
    }

    /**
     * Backward-compat delegate — free module's Admin/Fields.php calls this.
     */
    public function sitting_fields() {
        return Admin\Fields::instance()->sitting_fields();
    }
}
