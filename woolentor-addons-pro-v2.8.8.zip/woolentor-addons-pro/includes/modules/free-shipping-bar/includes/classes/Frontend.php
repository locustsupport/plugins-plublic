<?php
namespace WoolentorPro\Modules\FreeShippingBar;
use WooLentorPro\Traits\Singleton;

if ( ! defined( 'ABSPATH' ) ) exit;

class Frontend {
    use Singleton;

    private function __construct() {
        $this->includes();
        $this->init_hooks();
    }

    private function includes() {
        require_once __DIR__ . '/Frontend/Geo_Targeting.php';
        require_once __DIR__ . '/Frontend/Visibility.php';
        require_once __DIR__ . '/Frontend/AB_Testing.php';
        require_once __DIR__ . '/Frontend/Analytics.php';
        require_once __DIR__ . '/Frontend/Assets.php';
        require_once __DIR__ . '/Frontend/Countdown.php';
        require_once __DIR__ . '/Frontend/Multi_Bar.php';
    }

    private function init_hooks() {
        Frontend\Geo_Targeting::instance();
        Frontend\Visibility::instance();
        Frontend\AB_Testing::instance();
        Frontend\Analytics::instance();
        Frontend\Assets::instance();
        Frontend\Countdown::instance();
        Frontend\Multi_Bar::instance();

        add_filter( 'woolentor_fsb_localize_data', [ $this, 'extend_localize_data' ], 10, 1 );
        add_filter( 'woolentor_fsb_get_threshold',  [ $this, 'override_threshold_from_best_bar' ], 20, 1 );
    }

    /**
     * Override the free-module threshold so that Shipping_Handler,
     * shortcode, widget, and JS all use the winning additional bar's threshold.
     */
    private static $resolving_threshold = false;

    public function override_threshold_from_best_bar( $threshold ) {
        if ( self::$resolving_threshold ) {
            return $threshold;
        }
        self::$resolving_threshold = true;
        $bar = Frontend\Multi_Bar::instance()->get_best_bar();
        self::$resolving_threshold = false;
        if ( $bar && $bar['threshold'] > 0 ) {
            return (float) $bar['threshold'];
        }
        return $threshold;
    }

    /**
     * Append pro-specific keys to the wlFSB JS config object.
     */
    public function extend_localize_data( $data ) {
        // Multiple-bar override: find the best matching additional bar (if any)
        $bar_override = Frontend\Multi_Bar::instance()->get_best_bar();
        if ( $bar_override ) {
            $data['threshold']    = $bar_override['threshold'];
            $data['msgInitial']   = $bar_override['msg_initial'];
            $data['msgSuccess']   = $bar_override['msg_success'];
            $data['position']     = $bar_override['bar_position'];
            $data['showOnDevice'] = $bar_override['show_on_device'];
            $data['barId']        = 'bar_' . $bar_override['_index'];
            $data['barSkin']      = $bar_override['bar_skin'];
            $data['barBgColor']   = $bar_override['bar_bg_color'];
            $data['barTextColor'] = $bar_override['bar_text_color'];
            $data['barFillColor'] = $bar_override['bar_fill_color'];

            // Countdown from the additional bar
            if ( ( $bar_override['enable_countdown'] ?? 'off' ) === 'on' && ! empty( $bar_override['countdown_end_date'] ) ) {
                $data['countdownEnabled'] = true;
                $data['countdownEnd']     = strtotime( $bar_override['countdown_end_date'] ) * 1000;
                $data['countdownMsg']     = $bar_override['countdown_message'] ?: esc_html__( 'Offer ends in {timer}!', 'woolentor-pro' );
            }
        } else {
            $data['barId'] = 'default';
        }

        // A/B testing
        if ( Free_Shipping_Bar_Pro::setting( 'enable_ab_test', 'off' ) === 'on' ) {
            $variant          = Frontend\AB_Testing::instance()->get_variant();
            $data['abVariant'] = $variant;
            $data['msgInitial'] = Free_Shipping_Bar_Pro::setting(
                $variant === 'b' ? 'ab_variant_b_msg' : 'ab_variant_a_msg',
                $data['msgInitial']
            );
        }

        // Countdown timer (main settings — skipped if additional bar already set it)
        if ( empty( $data['countdownEnabled'] ) && Free_Shipping_Bar_Pro::setting( 'enable_countdown', 'off' ) === 'on' ) {
            $end_date = Free_Shipping_Bar_Pro::setting( 'countdown_end_date', '' );
            if ( $end_date ) {
                $data['countdownEnabled'] = true;
                $data['countdownEnd']     = strtotime( $end_date ) * 1000;
                $data['countdownMsg']     = Free_Shipping_Bar_Pro::setting( 'countdown_message', esc_html__( 'Offer ends in {timer}!', 'woolentor-pro' ) );
            }
        }

        // Analytics
        if ( Free_Shipping_Bar_Pro::setting( 'enable_analytics', 'off' ) === 'on' ) {
            $data['analyticsEnabled'] = true;
            $data['analyticsNonce']   = wp_create_nonce( 'woolentor-fsb-analytics' );
        }

        return $data;
    }
}
