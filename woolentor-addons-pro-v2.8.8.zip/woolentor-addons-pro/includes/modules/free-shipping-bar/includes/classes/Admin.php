<?php
namespace WoolentorPro\Modules\FreeShippingBar;
use WooLentorPro\Traits\Singleton;

if (!defined('ABSPATH')){
    exit;
}

class Admin {
    use Singleton;

    private function __construct() {
        $this->includes();
        $this->init();
    }

    private function includes() {
        require_once __DIR__ . '/Admin/Fields.php';
    }

    private function init() {}
}
