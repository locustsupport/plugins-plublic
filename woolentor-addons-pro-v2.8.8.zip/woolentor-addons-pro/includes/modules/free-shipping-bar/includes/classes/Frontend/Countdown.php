<?php
namespace WoolentorPro\Modules\FreeShippingBar\Frontend;
use WooLentorPro\Traits\Singleton;
use WoolentorPro\Modules\FreeShippingBar\Free_Shipping_Bar_Pro;

if ( ! defined( 'ABSPATH' ) ) exit;

class Countdown {
    use Singleton;

    private function __construct() {
        add_action( 'woolentor_fsb_bar_inner_html', [ $this, 'render' ] );
    }

    public function render() {
        if ( Free_Shipping_Bar_Pro::setting( 'enable_countdown', 'off' ) !== 'on' ) {
            return;
        }
        echo '<p class="wl-fsb-countdown" style="display:none;" aria-live="polite"></p>';
    }
}
