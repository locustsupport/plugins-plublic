<?php
namespace WoolentorPro\Modules\FreeShippingBar\Frontend;
use WooLentorPro\Traits\Singleton;
use WoolentorPro\Modules\FreeShippingBar\Free_Shipping_Bar_Pro;

if ( ! defined( 'ABSPATH' ) ) exit;

class Assets {
    use Singleton;

    private function __construct() {
        add_action( 'woolentor_fsb_enqueue_assets', [ $this, 'enqueue' ] );
        add_filter( 'woolentor_fsb_bar_classes', [ $this, 'skin_classes' ], 10, 1 );
    }

    public function enqueue() {
        $pro_assets = \WoolentorPro\Modules\FreeShippingBar\MODULE_URL . '/assets/';

        wp_enqueue_style(
            'woolentor-fsb-pro',
            $pro_assets . 'css/free-shipping-bar-pro.css',
            [ 'woolentor-free-shipping-bar' ],
            WOOLENTOR_VERSION_PRO
        );

        wp_enqueue_script(
            'woolentor-fsb-pro',
            $pro_assets . 'js/free-shipping-bar-pro.js',
            [ 'woolentor-free-shipping-bar' ],
            WOOLENTOR_VERSION_PRO,
            true
        );

        // Add pro inline CSS (skin + animation + custom) right after enqueueing the style
        // so it is guaranteed to be attached before styles are printed.
        $this->add_inline_css();
    }

    public function skin_classes( $classes ) {
        $skin      = Free_Shipping_Bar_Pro::setting( 'bar_skin', 'default' );
        $animation = Free_Shipping_Bar_Pro::setting( 'bar_animation', 'none' );

        if ( $skin && $skin !== 'default' ) {
            $classes[] = 'wl-fsb-skin-' . sanitize_html_class( $skin );
        }

        if ( $animation && $animation !== 'none' ) {
            $classes[] = 'wl-fsb-anim-' . sanitize_html_class( $animation );
        }

        return $classes;
    }

    public function add_inline_css() {
        $custom_css = trim( Free_Shipping_Bar_Pro::setting( 'bar_custom_css', '' ) );
        if ( $custom_css ) {
            wp_add_inline_style( 'woolentor-fsb-pro', $custom_css );
        }
    }
}
