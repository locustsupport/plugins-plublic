=== LOCUS-T Update Manager ===
Contributors: locus-t
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.0.1

Centralized WordPress plugin and theme updater using a JSON manifest.

== Installation ==
1. Upload and activate the plugin.
2. Go to Settings > LOCUS-T Updater.
3. The default manifest URL is:
   https://raw.githubusercontent.com/locustsupport/plugins-plublic/main/updates.json
4. Upload updates.json to the root of the GitHub repository.
5. Click Check Updates Now.

== Manifest identifiers ==
Plugins use the exact plugin basename, for example:
jet-menu/jet-menu.php

Themes use the exact theme stylesheet/folder slug, for example:
betheme

== Important ==
The manifest is authoritative only for packages listed in it. Other plugins and themes continue to use their normal update sources.
