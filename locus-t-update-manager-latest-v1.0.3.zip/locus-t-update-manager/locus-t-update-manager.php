<?php
/**
 * Plugin Name: LOCUS-T Update Manager
 * Description: Centralized update source for managed WordPress plugins and themes using a JSON manifest.
 * Version: 1.0.3
 * Author: LOCUS-T
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class LOCUST_Update_Manager {
    const VERSION                 = '1.0.3';
    const SELF_PLUGIN             = 'locus-t-update-manager/locus-t-update-manager.php';
    const OPTION_MANIFEST         = 'ltum_manifest_url';
    const TRANSIENT_MANIFEST      = 'ltum_manifest_cache';
    const TRANSIENT_ADMIN_REFRESH = 'ltum_admin_refresh_lock';
    const CACHE_TTL               = 900; // 15 minutes for normal/background requests.
    const ADMIN_REFRESH_TTL       = 60;  // Avoid repeated GitHub requests during rapid admin navigation.
    const DEFAULT_MANIFEST        = 'https://raw.githubusercontent.com/locustsupport/plugins-plublic/main/updates.json';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Register update-source hooks only after all active plugins are loaded.
        // This lets LOCUS-T run after vendor updaters and keep the central manifest authoritative.
        add_action( 'plugins_loaded', array( $this, 'register_update_hooks' ), PHP_INT_MAX );

        // Client-facing stealth mode. By default the manager is hidden in wp-admin.
        // Define LOCUST_UPDATE_MANAGER_ADMIN as true in wp-config.php to reveal it.
        add_filter( 'all_plugins', array( $this, 'hide_self_from_plugin_list' ), 9999 );

        // Never opt the manager into WordPress background auto-updates.
        // Updates remain discoverable so they can be applied manually through a remote management platform.
        add_filter( 'auto_update_plugin', array( $this, 'disable_self_auto_update' ), 9999, 2 );

        // Refresh the central manifest automatically on WordPress update-related screens.
        add_action( 'current_screen', array( $this, 'maybe_refresh_manifest_on_update_screen' ), 20 );

        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
        add_action( 'admin_post_ltum_save_settings', array( $this, 'save_settings' ) );
        add_action( 'admin_post_ltum_check_updates', array( $this, 'check_updates_now' ) );
        add_action( 'admin_notices', array( $this, 'admin_notices' ) );
    }

    /**
     * Register update filters after all active plugins have loaded.
     *
     * PHP_INT_MAX is intentional: premium/vendor updaters often attach late filters to
     * update_plugins. Managed packages in updates.json should win only for those entries.
     */
    public function register_update_hooks() {
        $priority = PHP_INT_MAX;

        add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'filter_plugin_updates' ), $priority );
        add_filter( 'site_transient_update_plugins', array( $this, 'filter_plugin_updates' ), $priority );
        add_filter( 'pre_set_site_transient_update_themes', array( $this, 'filter_theme_updates' ), $priority );
        add_filter( 'site_transient_update_themes', array( $this, 'filter_theme_updates' ), $priority );
        add_filter( 'plugins_api', array( $this, 'plugin_information' ), $priority, 3 );

        // When WordPress performs a normal Plugin_Upgrader update, force the package URL
        // from the LOCUS-T manifest for managed plugins. This does not modify vendor licensing;
        // it only selects the package already defined in updates.json.
        add_filter( 'upgrader_package_options', array( $this, 'force_managed_package_options' ), $priority );

        // Hide our own update row only after the managed update response has been injected.
        add_filter( 'site_transient_update_plugins', array( $this, 'hide_self_update_from_client_ui' ), $priority );
    }

    /**
     * Reveal the manager UI only for LOCUS-T maintenance/admin sessions.
     *
     * Add this to wp-config.php when troubleshooting:
     * define( 'LOCUST_UPDATE_MANAGER_ADMIN', true );
     */
    public function admin_mode_enabled() {
        $enabled = defined( 'LOCUST_UPDATE_MANAGER_ADMIN' ) && true === LOCUST_UPDATE_MANAGER_ADMIN;
        return (bool) apply_filters( 'ltum_admin_visible', $enabled );
    }

    public function hide_self_from_plugin_list( $plugins ) {
        if ( $this->admin_mode_enabled() || ! is_array( $plugins ) ) {
            return $plugins;
        }

        unset( $plugins[ self::SELF_PLUGIN ] );
        return $plugins;
    }

    /**
     * Hide the manager's own update row/count only on native client-facing wp-admin screens.
     * Remote/AJAX/REST/cron/WP-CLI requests retain the update data so external management
     * tools can still detect and apply the update manually.
     */
    public function hide_self_update_from_client_ui( $transient ) {
        if ( $this->admin_mode_enabled() || ! is_admin() || ! is_object( $transient ) ) {
            return $transient;
        }

        if ( ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() )
            || ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() )
            || ( defined( 'REST_REQUEST' ) && REST_REQUEST )
            || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
            return $transient;
        }

        if ( ! function_exists( 'get_current_screen' ) ) {
            return $transient;
        }

        $screen = get_current_screen();
        if ( ! is_object( $screen ) ) {
            return $transient;
        }

        $id   = isset( $screen->id ) ? (string) $screen->id : '';
        $base = isset( $screen->base ) ? (string) $screen->base : '';
        $native_update_screen = in_array( $base, array( 'plugins', 'update-core' ), true )
            || in_array( $id, array( 'plugins', 'plugins-network', 'update-core', 'update-core-network' ), true );

        if ( ! $native_update_screen ) {
            return $transient;
        }

        if ( isset( $transient->response ) && is_array( $transient->response ) ) {
            unset( $transient->response[ self::SELF_PLUGIN ] );
        }

        if ( isset( $transient->no_update ) && is_array( $transient->no_update ) ) {
            unset( $transient->no_update[ self::SELF_PLUGIN ] );
        }

        return $transient;
    }

    /**
     * Disable WordPress background auto-updates for the manager itself.
     * The update remains detectable and can be applied manually by an external manager.
     */
    public function disable_self_auto_update( $update, $item ) {
        $plugin = '';

        if ( is_object( $item ) && ! empty( $item->plugin ) ) {
            $plugin = plugin_basename( $item->plugin );
        } elseif ( is_array( $item ) && ! empty( $item['plugin'] ) ) {
            $plugin = plugin_basename( $item['plugin'] );
        }

        if ( self::SELF_PLUGIN === $plugin ) {
            return false;
        }

        return $update;
    }

    /**
     * Fetch a fresh manifest when an administrator opens Plugins, Themes or Updates.
     * A short lock prevents repeated remote requests during rapid page navigation.
     */
    public function maybe_refresh_manifest_on_update_screen( $screen ) {
        if ( ! is_object( $screen ) ) {
            return;
        }

        if ( ! current_user_can( 'update_plugins' ) && ! current_user_can( 'update_themes' ) ) {
            return;
        }

        $id   = isset( $screen->id ) ? (string) $screen->id : '';
        $base = isset( $screen->base ) ? (string) $screen->base : '';

        $relevant = in_array( $base, array( 'plugins', 'themes', 'update-core' ), true )
            || in_array( $id, array( 'plugins', 'themes', 'update-core', 'plugins-network', 'themes-network', 'update-core-network', 'settings_page_locus-t-update-manager' ), true );

        if ( ! $relevant ) {
            return;
        }

        $is_manager_page = 'settings_page_locus-t-update-manager' === $id;

        if ( ! $is_manager_page && get_site_transient( self::TRANSIENT_ADMIN_REFRESH ) ) {
            return;
        }

        set_site_transient( self::TRANSIENT_ADMIN_REFRESH, 1, self::ADMIN_REFRESH_TTL );
        delete_site_transient( self::TRANSIENT_MANIFEST );
        $this->get_manifest( true );
    }

    public function get_manifest_url() {
        $url = get_option( self::OPTION_MANIFEST, self::DEFAULT_MANIFEST );
        $url = esc_url_raw( trim( (string) $url ) );
        return $url ? $url : self::DEFAULT_MANIFEST;
    }

    private function normalize_manifest( $manifest ) {
        if ( ! is_array( $manifest ) ) {
            return false;
        }

        if ( ! isset( $manifest['plugins'] ) || ! is_array( $manifest['plugins'] ) ) {
            $manifest['plugins'] = array();
        }

        if ( ! isset( $manifest['themes'] ) || ! is_array( $manifest['themes'] ) ) {
            $manifest['themes'] = array();
        }

        return $manifest;
    }

    public function get_manifest( $force = false ) {
        if ( ! $force ) {
            $cached = get_site_transient( self::TRANSIENT_MANIFEST );
            if ( is_array( $cached ) ) {
                return $cached;
            }
        }

        $url = $this->get_manifest_url();

        $response = wp_remote_get(
            $url,
            array(
                'timeout'     => 15,
                'redirection' => 5,
                'sslverify'   => true,
                'headers'     => array(
                    'Accept' => 'application/json',
                ),
                'user-agent'  => 'LOCUS-T-Update-Manager/' . self::VERSION . '; ' . home_url( '/' ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        if ( 200 !== $code ) {
            return new WP_Error( 'ltum_http_error', sprintf( 'Manifest returned HTTP %d.', $code ) );
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( JSON_ERROR_NONE !== json_last_error() ) {
            return new WP_Error( 'ltum_json_error', 'Manifest contains invalid JSON: ' . json_last_error_msg() );
        }

        $data = $this->normalize_manifest( $data );
        if ( false === $data ) {
            return new WP_Error( 'ltum_manifest_error', 'Manifest must be a JSON object.' );
        }

        set_site_transient( self::TRANSIENT_MANIFEST, $data, self::CACHE_TTL );
        return $data;
    }

    private function valid_package( $item ) {
        if ( ! is_array( $item ) || empty( $item['version'] ) || empty( $item['package'] ) ) {
            return false;
        }

        $package = esc_url_raw( $item['package'] );
        if ( ! $package || 0 !== strpos( strtolower( $package ), 'https://' ) ) {
            return false;
        }

        return true;
    }

    /**
     * Resolve a manifest plugin entry to the actual installed plugin basename.
     * Exact matches are preferred, then a same-directory/slug match is used.
     * This handles premium plugins whose main bootstrap filename changes between releases.
     */
    private function resolve_installed_plugin_file( $manifest_plugin_file, $item, $installed ) {
        $manifest_plugin_file = plugin_basename( $manifest_plugin_file );

        if ( isset( $installed[ $manifest_plugin_file ] ) ) {
            return $manifest_plugin_file;
        }

        $manifest_dir = dirname( $manifest_plugin_file );
        $manifest_slug = ! empty( $item['slug'] ) ? sanitize_key( $item['slug'] ) : '';

        foreach ( $installed as $installed_file => $plugin_data ) {
            $installed_file = plugin_basename( $installed_file );
            $installed_dir  = dirname( $installed_file );

            if ( '.' !== $manifest_dir && $manifest_dir === $installed_dir ) {
                return $installed_file;
            }

            if ( $manifest_slug && sanitize_key( $installed_dir ) === $manifest_slug ) {
                return $installed_file;
            }
        }

        return '';
    }

    /**
     * Find a managed manifest entry for an installed plugin basename.
     */
    private function get_managed_plugin_item( $plugin_file, $manifest = null ) {
        $plugin_file = plugin_basename( $plugin_file );

        if ( null === $manifest ) {
            $manifest = $this->get_manifest();
        }

        if ( is_wp_error( $manifest ) || empty( $manifest['plugins'] ) || ! is_array( $manifest['plugins'] ) ) {
            return false;
        }

        if ( isset( $manifest['plugins'][ $plugin_file ] ) && $this->valid_package( $manifest['plugins'][ $plugin_file ] ) ) {
            return $manifest['plugins'][ $plugin_file ];
        }

        $plugin_dir = dirname( $plugin_file );

        foreach ( $manifest['plugins'] as $manifest_file => $item ) {
            if ( ! $this->valid_package( $item ) ) {
                continue;
            }

            $manifest_file = plugin_basename( $manifest_file );
            $manifest_dir  = dirname( $manifest_file );
            $manifest_slug = ! empty( $item['slug'] ) ? sanitize_key( $item['slug'] ) : '';

            if ( ( '.' !== $plugin_dir && $plugin_dir === $manifest_dir )
                || ( $manifest_slug && sanitize_key( $plugin_dir ) === $manifest_slug ) ) {
                return $item;
            }
        }

        return false;
    }

    /**
     * Force Plugin_Upgrader to use the package URL defined in updates.json for managed plugins.
     * This is a second safety net in addition to the update_plugins transient override.
     */
    public function force_managed_package_options( $options ) {
        if ( ! is_array( $options ) || empty( $options['hook_extra'] ) || ! is_array( $options['hook_extra'] ) ) {
            return $options;
        }

        $plugin_file = '';
        if ( ! empty( $options['hook_extra']['plugin'] ) ) {
            $plugin_file = plugin_basename( $options['hook_extra']['plugin'] );
        }

        if ( ! $plugin_file ) {
            return $options;
        }

        $item = $this->get_managed_plugin_item( $plugin_file );
        if ( false === $item ) {
            return $options;
        }

        $package = esc_url_raw( $item['package'] );
        if ( $package ) {
            $options['package'] = $package;
        }

        return $options;
    }

    public function filter_plugin_updates( $transient ) {
        if ( ! is_object( $transient ) ) {
            return $transient;
        }

        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $installed = get_plugins();
        $manifest  = $this->get_manifest();

        if ( is_wp_error( $manifest ) || empty( $manifest['plugins'] ) ) {
            return $transient;
        }

        if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
            $transient->response = array();
        }
        if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
            $transient->no_update = array();
        }

        foreach ( $manifest['plugins'] as $manifest_plugin_file => $item ) {
            if ( ! $this->valid_package( $item ) ) {
                continue;
            }

            $plugin_file = $this->resolve_installed_plugin_file( $manifest_plugin_file, $item, $installed );
            if ( ! $plugin_file || empty( $installed[ $plugin_file ] ) ) {
                continue;
            }

            // For managed packages, the central manifest is authoritative.
            // Remove any vendor/WordPress.org response/no-update object first.
            unset( $transient->response[ $plugin_file ], $transient->no_update[ $plugin_file ] );

            $current = isset( $installed[ $plugin_file ]['Version'] ) ? (string) $installed[ $plugin_file ]['Version'] : '0';
            $remote  = (string) $item['version'];

            if ( ! version_compare( $remote, $current, '>' ) ) {
                continue;
            }

            $slug = ! empty( $item['slug'] ) ? sanitize_key( $item['slug'] ) : dirname( $plugin_file );
            if ( '.' === $slug || empty( $slug ) ) {
                $slug = sanitize_key( basename( $plugin_file, '.php' ) );
            }

            $update = (object) array(
                'id'            => ! empty( $item['id'] ) ? esc_url_raw( $item['id'] ) : $plugin_file,
                'slug'          => $slug,
                'plugin'        => $plugin_file,
                'new_version'   => $remote,
                'url'           => ! empty( $item['url'] ) ? esc_url_raw( $item['url'] ) : '',
                'package'       => esc_url_raw( $item['package'] ),
                'tested'        => ! empty( $item['tested'] ) ? sanitize_text_field( $item['tested'] ) : '',
                'requires_php'  => ! empty( $item['requires_php'] ) ? sanitize_text_field( $item['requires_php'] ) : '',
                'compatibility' => new stdClass(),
            );

            if ( ! empty( $item['icons'] ) && is_array( $item['icons'] ) ) {
                $update->icons = array_map( 'esc_url_raw', $item['icons'] );
            }

            if ( ! empty( $item['banners'] ) && is_array( $item['banners'] ) ) {
                $update->banners = array_map( 'esc_url_raw', $item['banners'] );
            }

            $transient->response[ $plugin_file ] = $update;
        }

        return $transient;
    }

    public function filter_theme_updates( $transient ) {
        if ( ! is_object( $transient ) ) {
            return $transient;
        }

        $manifest = $this->get_manifest();
        if ( is_wp_error( $manifest ) || empty( $manifest['themes'] ) ) {
            return $transient;
        }

        if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
            $transient->response = array();
        }

        foreach ( $manifest['themes'] as $theme_slug => $item ) {
            $theme_slug = sanitize_key( $theme_slug );
            $theme      = wp_get_theme( $theme_slug );

            if ( ! $theme->exists() || ! $this->valid_package( $item ) ) {
                continue;
            }

            // The manifest is authoritative for managed themes.
            unset( $transient->response[ $theme_slug ] );

            $current = (string) $theme->get( 'Version' );
            $remote  = (string) $item['version'];

            if ( ! version_compare( $remote, $current, '>' ) ) {
                continue;
            }

            $transient->response[ $theme_slug ] = array(
                'theme'        => $theme_slug,
                'new_version'  => $remote,
                'url'          => ! empty( $item['url'] ) ? esc_url_raw( $item['url'] ) : '',
                'package'      => esc_url_raw( $item['package'] ),
                'requires'     => ! empty( $item['requires'] ) ? sanitize_text_field( $item['requires'] ) : '',
                'requires_php' => ! empty( $item['requires_php'] ) ? sanitize_text_field( $item['requires_php'] ) : '',
            );
        }

        return $transient;
    }

    public function plugin_information( $result, $action, $args ) {
        if ( 'plugin_information' !== $action || empty( $args->slug ) ) {
            return $result;
        }

        $manifest = $this->get_manifest();
        if ( is_wp_error( $manifest ) || empty( $manifest['plugins'] ) ) {
            return $result;
        }

        foreach ( $manifest['plugins'] as $plugin_file => $item ) {
            $slug = ! empty( $item['slug'] ) ? sanitize_key( $item['slug'] ) : dirname( plugin_basename( $plugin_file ) );
            if ( '.' === $slug || empty( $slug ) ) {
                $slug = sanitize_key( basename( $plugin_file, '.php' ) );
            }

            if ( $slug !== $args->slug ) {
                continue;
            }

            $sections = array();
            if ( ! empty( $item['description'] ) ) {
                $sections['description'] = wp_kses_post( $item['description'] );
            }
            if ( ! empty( $item['changelog'] ) ) {
                $sections['changelog'] = wp_kses_post( $item['changelog'] );
            }

            return (object) array(
                'name'          => ! empty( $item['name'] ) ? sanitize_text_field( $item['name'] ) : $slug,
                'slug'          => $slug,
                'version'       => ! empty( $item['version'] ) ? sanitize_text_field( $item['version'] ) : '',
                'author'        => ! empty( $item['author'] ) ? wp_kses_post( $item['author'] ) : 'LOCUS-T',
                'homepage'      => ! empty( $item['url'] ) ? esc_url_raw( $item['url'] ) : '',
                'requires'      => ! empty( $item['requires'] ) ? sanitize_text_field( $item['requires'] ) : '',
                'tested'        => ! empty( $item['tested'] ) ? sanitize_text_field( $item['tested'] ) : '',
                'requires_php'  => ! empty( $item['requires_php'] ) ? sanitize_text_field( $item['requires_php'] ) : '',
                'last_updated'  => ! empty( $item['last_updated'] ) ? sanitize_text_field( $item['last_updated'] ) : '',
                'download_link' => ! empty( $item['package'] ) ? esc_url_raw( $item['package'] ) : '',
                'sections'      => $sections,
            );
        }

        return $result;
    }

    public function admin_menu() {
        if ( ! $this->admin_mode_enabled() ) {
            return;
        }

        add_options_page(
            'LOCUS-T Update Manager',
            'LOCUS-T Updater',
            'manage_options',
            'locus-t-update-manager',
            array( $this, 'render_admin_page' )
        );
    }

    public function save_settings() {
        if ( ! $this->admin_mode_enabled() || ! current_user_can( 'manage_options' ) ) {
            wp_die( 'You do not have permission to perform this action.' );
        }

        check_admin_referer( 'ltum_save_settings' );

        $url = isset( $_POST['manifest_url'] ) ? esc_url_raw( wp_unslash( $_POST['manifest_url'] ) ) : '';
        if ( empty( $url ) || 0 !== strpos( strtolower( $url ), 'https://' ) ) {
            wp_safe_redirect( add_query_arg( 'ltum_notice', 'invalid_url', admin_url( 'options-general.php?page=locus-t-update-manager' ) ) );
            exit;
        }

        update_option( self::OPTION_MANIFEST, $url, false );
        delete_site_transient( self::TRANSIENT_MANIFEST );

        wp_safe_redirect( add_query_arg( 'ltum_notice', 'saved', admin_url( 'options-general.php?page=locus-t-update-manager' ) ) );
        exit;
    }

    public function check_updates_now() {
        if ( ! $this->admin_mode_enabled() || ( ! current_user_can( 'update_plugins' ) && ! current_user_can( 'update_themes' ) ) ) {
            wp_die( 'You do not have permission to check updates.' );
        }

        check_admin_referer( 'ltum_check_updates' );

        delete_site_transient( self::TRANSIENT_MANIFEST );
        delete_site_transient( self::TRANSIENT_ADMIN_REFRESH );
        delete_site_transient( 'update_plugins' );
        delete_site_transient( 'update_themes' );

        if ( function_exists( 'wp_clean_plugins_cache' ) ) {
            wp_clean_plugins_cache( true );
        }
        if ( function_exists( 'wp_clean_themes_cache' ) ) {
            wp_clean_themes_cache( true );
        }

        wp_update_plugins();
        wp_update_themes();

        wp_safe_redirect( add_query_arg( 'ltum_notice', 'checked', admin_url( 'options-general.php?page=locus-t-update-manager' ) ) );
        exit;
    }

    public function admin_notices() {
        if ( ! $this->admin_mode_enabled() ) {
            return;
        }

        if ( empty( $_GET['page'] ) || 'locus-t-update-manager' !== $_GET['page'] || empty( $_GET['ltum_notice'] ) ) {
            return;
        }

        $notice = sanitize_key( wp_unslash( $_GET['ltum_notice'] ) );
        $messages = array(
            'saved'       => array( 'success', 'Manifest URL saved.' ),
            'checked'     => array( 'success', 'Update caches cleared and WordPress checked again.' ),
            'invalid_url' => array( 'error', 'Please enter a valid HTTPS manifest URL.' ),
        );

        if ( empty( $messages[ $notice ] ) ) {
            return;
        }

        printf(
            '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
            esc_attr( $messages[ $notice ][0] ),
            esc_html( $messages[ $notice ][1] )
        );
    }

    private function package_status( $current, $remote ) {
        if ( empty( $current ) ) {
            return 'Not installed';
        }
        if ( version_compare( $remote, $current, '>' ) ) {
            return 'Update available';
        }
        if ( version_compare( $remote, $current, '<' ) ) {
            return 'Installed is newer';
        }
        return 'Up to date';
    }

    public function render_admin_page() {
        if ( ! $this->admin_mode_enabled() || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $manifest = $this->get_manifest();
        $plugins  = get_plugins();
        $themes   = wp_get_themes();
        ?>
        <div class="wrap">
            <h1>LOCUS-T Update Manager</h1>
            <p>Manage selected plugin and theme updates from one centralized JSON manifest.</p>

            <h2>Update Source</h2>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'ltum_save_settings' ); ?>
                <input type="hidden" name="action" value="ltum_save_settings">
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="manifest_url">Manifest URL</label></th>
                        <td>
                            <input type="url" class="regular-text code" style="width:100%;max-width:850px" id="manifest_url" name="manifest_url" value="<?php echo esc_attr( $this->get_manifest_url() ); ?>" required>
                            <p class="description">Only packages explicitly listed in this manifest are overridden by this updater.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button( 'Save Update Source' ); ?>
            </form>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:10px;">
                <?php wp_nonce_field( 'ltum_check_updates' ); ?>
                <input type="hidden" name="action" value="ltum_check_updates">
                <?php submit_button( 'Check Updates Now', 'secondary', 'submit', false ); ?>
            </form>

            <h2>Connection</h2>
            <?php if ( is_wp_error( $manifest ) ) : ?>
                <div class="notice notice-error inline"><p><strong>Unable to load manifest:</strong> <?php echo esc_html( $manifest->get_error_message() ); ?></p></div>
            <?php else : ?>
                <div class="notice notice-success inline"><p><strong>Connected.</strong> Found <?php echo esc_html( count( $manifest['plugins'] ) ); ?> managed plugin(s) and <?php echo esc_html( count( $manifest['themes'] ) ); ?> managed theme(s).</p></div>

                <h2>Managed Packages</h2>
                <table class="widefat striped" style="max-width:1100px;">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Package</th>
                            <th>Identifier</th>
                            <th>Installed</th>
                            <th>Manifest</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $rows = 0;
                    foreach ( $manifest['plugins'] as $plugin_file => $item ) :
                        $manifest_plugin_file = plugin_basename( $plugin_file );
                        $resolved_plugin_file = $this->resolve_installed_plugin_file( $manifest_plugin_file, $item, $plugins );
                        $plugin_file = $resolved_plugin_file ? $resolved_plugin_file : $manifest_plugin_file;
                        $installed_version = isset( $plugins[ $plugin_file ]['Version'] ) ? $plugins[ $plugin_file ]['Version'] : '';
                        $name = ! empty( $item['name'] ) ? $item['name'] : ( isset( $plugins[ $plugin_file ]['Name'] ) ? $plugins[ $plugin_file ]['Name'] : $plugin_file );
                        $remote = ! empty( $item['version'] ) ? $item['version'] : '';
                        $rows++;
                        ?>
                        <tr>
                            <td>Plugin</td>
                            <td><?php echo esc_html( $name ); ?></td>
                            <td><code><?php echo esc_html( $plugin_file ); ?></code></td>
                            <td><?php echo esc_html( $installed_version ? $installed_version : '—' ); ?></td>
                            <td><?php echo esc_html( $remote ? $remote : '—' ); ?></td>
                            <td><?php echo esc_html( $this->package_status( $installed_version, $remote ) ); ?></td>
                        </tr>
                    <?php endforeach; ?>

                    <?php foreach ( $manifest['themes'] as $theme_slug => $item ) :
                        $theme_slug = sanitize_key( $theme_slug );
                        $theme = isset( $themes[ $theme_slug ] ) ? $themes[ $theme_slug ] : wp_get_theme( $theme_slug );
                        $installed_version = $theme->exists() ? (string) $theme->get( 'Version' ) : '';
                        $name = ! empty( $item['name'] ) ? $item['name'] : ( $theme->exists() ? $theme->get( 'Name' ) : $theme_slug );
                        $remote = ! empty( $item['version'] ) ? $item['version'] : '';
                        $rows++;
                        ?>
                        <tr>
                            <td>Theme</td>
                            <td><?php echo esc_html( $name ); ?></td>
                            <td><code><?php echo esc_html( $theme_slug ); ?></code></td>
                            <td><?php echo esc_html( $installed_version ? $installed_version : '—' ); ?></td>
                            <td><?php echo esc_html( $remote ? $remote : '—' ); ?></td>
                            <td><?php echo esc_html( $this->package_status( $installed_version, $remote ) ); ?></td>
                        </tr>
                    <?php endforeach; ?>

                    <?php if ( 0 === $rows ) : ?>
                        <tr><td colspan="6">No packages are currently defined in the manifest.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>

                <p style="margin-top:16px;"><strong>Note:</strong> The plugin/theme folder inside each ZIP must match the existing installed folder name.</p>
            <?php endif; ?>
        </div>
        <?php
    }
}

LOCUST_Update_Manager::instance();
