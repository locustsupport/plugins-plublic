=== LOCUS-T Update Manager ===
Contributors: locus-t
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.0.2

Centralized WordPress plugin and theme updater using a JSON manifest.

== Version 1.0.2 ==
* Hides LOCUS-T Update Manager from normal client wp-admin screens by default.
* Hides the manager's own update notice from client-facing WordPress update screens.
* Disables WordPress background auto-updates for the manager itself so releases can be applied manually through your remote management workflow.
* Automatically refreshes the remote manifest when Plugins, Themes, or Dashboard > Updates is opened, with a short 60-second request lock.
* Keeps the existing 15-minute manifest cache for normal/background requests.

== LOCUS-T Admin Mode ==
The manager is hidden by default after activation/update.

To reveal the plugin row and Settings > LOCUS-T Updater page, add this to wp-config.php before the "That's all" line:

define( 'LOCUST_UPDATE_MANAGER_ADMIN', true );

Remove the line (or set it to false) to hide the manager again.

== Update Source ==
Default manifest URL:
https://raw.githubusercontent.com/locustsupport/plugins-plublic/main/updates.json

== Manager Updates ==
Keep this package in the manifest:

locus-t-update-manager/locus-t-update-manager.php

Point its package URL to a permanent ZIP name such as:
https://raw.githubusercontent.com/locustsupport/plugins-plublic/main/locus-t-update-manager.zip

To release a new manager version:
1. Replace locus-t-update-manager.zip in the repository.
2. Change the manager version in updates.json.
3. WordPress sites will detect it through the normal update system.
4. The update remains available for manual deployment through your remote management platform.

== Manifest identifiers ==
Plugins use the exact plugin basename, for example:
jet-menu/jet-menu.php

Themes use the exact theme stylesheet/folder slug, for example:
betheme

== Important ==
The manifest is authoritative only for packages listed in it. Other plugins and themes continue to use their normal update sources.

Hiding applies to WordPress admin UI only. Users with filesystem, SSH, FTP, backup, database, or server-level access can still discover installed files.


== Changelog ==

= 1.0.3 =
* Registers update overrides after vendor plugins at maximum priority.
* Resolves managed plugins by folder/slug when the bootstrap PHP filename changes.
* Forces the standard WordPress Plugin_Upgrader package option to the URL in updates.json.
